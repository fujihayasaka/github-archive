import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as fetchTree } from "./server-fetch-tree-DW-GjGy--LIDHmmgR.js";
import { n as getQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { n as codeViewLayoutRoute, t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
var codeViewFileTreeLayoutRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewFileTreeLayoutRoute", {
	path: "/:owner/:repo",
	queries: [mainQuery({ queryDeps: ({ pathname }) => ({ pathname: `${pathname}/_file_tree_layout` }) })],
	shouldRevalidate: ({ currentParams, nextParams }) => {
		return currentParams.owner !== nextParams.owner || currentParams.repo !== nextParams.repo;
	}
});
function fileTreeCacheKey(owner, repo, branch) {
	return [
		owner,
		repo,
		branch,
		"fileTree"
	];
}
var EMPTY_RESPONSE = null;
var EMPTY_TREE = {
	fileTree: {},
	foldersToFetch: []
};
/**
* Route-level query that fires during navigation to prefetch file tree data.
* This is a best-effort optimization — if the layout data isn't cached yet,
* it returns early and the useFileTree hook handles loading at render time.
*/
var fileTreeQuery = {
	queryName: "fileTree",
	queryDeps: ({ pathname, params }) => ({
		pathname: `${pathname}/_file_tree`,
		params
	}),
	queryFn: async ({ queryDeps }) => {
		const { params } = queryDeps;
		await updateFileTree({
			owner: params.owner,
			repo: params.repo,
			params
		});
		return EMPTY_RESPONSE;
	},
	staleTime: 0,
	gcTime: 0
};
/**
* Called by the route-level query during navigation. Resolves the branch name
* from the layout cache, seeds the dedicated file tree cache if needed, then
* fetches any missing tree segments for the current path.
*/
async function updateFileTree({ owner, repo, params }) {
	const queryClient = getQueryClient();
	const layoutQueryKey = codeViewLayoutRoute.queries.mainQuery.makeQueryKey({ pathname: `/${owner}/${repo}/_layout` });
	const layoutData = queryClient.getQueryData(layoutQueryKey);
	if (!layoutData) return;
	const branch = layoutData.payload.refInfo.name;
	const path = extractPathFromParams(params, branch);
	const cacheKey = fileTreeCacheKey(owner, repo, branch);
	if (!queryClient.getQueryData(cacheKey)) {
		const fileTreeLayoutQueryKey = codeViewFileTreeLayoutRoute.queries.mainQuery.makeQueryKey({ pathname: `/${owner}/${repo}/_file_tree_layout` });
		const fileTreeLayoutData = queryClient.getQueryData(fileTreeLayoutQueryKey);
		if (!fileTreeLayoutData) return;
		queryClient.setQueryData(cacheKey, {
			fileTree: fileTreeLayoutData.payload.fileTree,
			foldersToFetch: fileTreeLayoutData.payload.foldersToFetch,
			fileTreeProcessingTime: fileTreeLayoutData.payload.fileTreeProcessingTime
		});
	}
	await loadFileTreePath({
		owner,
		repo,
		branch,
		path
	});
}
/**
* Fetches missing file tree segments for the given path and merges them into
* the dedicated file tree cache. Can be called from the route query (navigation
* time), from the useFileTree hook (render time), or imperatively (e.g. after
* a web commit).
*/
async function loadFileTreePath({ owner, repo, branch, path }) {
	const queryClient = getQueryClient();
	const cacheKey = fileTreeCacheKey(owner, repo, branch);
	const pathsToLoad = getPathsToLoad(path, queryClient.getQueryData(cacheKey)?.fileTree ?? {});
	if (!pathsToLoad) return;
	const inflightKey = `${owner}/${repo}:${branch}:${pathsToLoad.start}:${pathsToLoad.stop}`;
	if (inflight.has(inflightKey)) return;
	const promise = fetchMissingItems({
		owner,
		repo,
		branch,
		pathsToLoad
	});
	inflight.set(inflightKey, promise);
	try {
		const { fileTree: newFileTree, foldersToFetch } = await promise;
		queryClient.setQueryData(cacheKey, (old) => {
			if (!old) return {
				fileTree: newFileTree,
				foldersToFetch,
				fileTreeProcessingTime: 0
			};
			return {
				...old,
				fileTree: mergeFileTree(old.fileTree, newFileTree),
				foldersToFetch: [...new Set([...old.foldersToFetch, ...foldersToFetch])]
			};
		});
	} finally {
		inflight.delete(inflightKey);
	}
}
var inflight = /* @__PURE__ */ new Map();
async function fetchMissingItems({ owner, repo, branch, pathsToLoad }) {
	if (pathsToLoad.start === pathsToLoad.stop) return fetchSingleItem({
		owner,
		repo,
		branch,
		path: pathsToLoad.start
	});
	const response = await verifiedFetchJSON(`/${owner}/${repo}/_file_tree`, {
		method: "POST",
		body: {
			branch,
			start: pathsToLoad.start,
			stop: pathsToLoad.stop
		}
	});
	if (!response.ok) return EMPTY_TREE;
	const data = await response.json();
	if (!data?.payload?.fileTree) throw new Error(`Unable to find payload for fileTree query`);
	return data.payload.fileTree;
}
async function fetchSingleItem({ owner, repo, branch, path }) {
	const response = await fetchTree(repositoryTreePath({
		repo: {
			ownerLogin: owner,
			name: repo
		},
		commitish: branch,
		action: "tree",
		path
	}));
	return {
		fileTree: { [path]: response.tree },
		foldersToFetch: []
	};
}
function mergeFileTree(oldTree, newTree) {
	const fileTree = { ...oldTree };
	const newPaths = Object.keys(newTree).sort((a, b) => a < b ? 1 : -1);
	for (const path of newPaths) {
		const { dir, name } = pathInfo(path);
		const existingDir = fileTree[dir];
		if (existingDir) fileTree[dir] = mergeDirectory(existingDir, {
			path,
			name,
			contentType: "directory"
		});
		if (newTree[path]) fileTree[path] = newTree[path];
	}
	return fileTree;
}
function mergeDirectory(entry, newItem) {
	if (entry.items.some((item) => item.path === newItem.path)) return entry;
	const items = [...entry.items, newItem];
	items.sort((a, b) => {
		if (a.contentType === b.contentType) return a.name < b.name ? -1 : 1;
		if (a.contentType === "directory" && b.contentType !== "directory") return -1;
		return 1;
	});
	return {
		items,
		totalCount: items.length
	};
}
/**
* Given a fileTree and a path, returns the range of paths that need to be loaded.
* Returns null if everything is already loaded.
*/
function getPathsToLoad(path, fileTree) {
	if (!path) return null;
	const pathSegments = path.split("/");
	let currentPath = "";
	let parentPath = "";
	let stopPath = null;
	for (const segment of pathSegments) {
		currentPath = currentPath ? `${currentPath}/${segment}` : segment;
		if (currentPath in fileTree) {
			parentPath = currentPath;
			continue;
		}
		const parentData = fileTree[parentPath];
		if (parentData) {
			const item = parentData.items.find((it) => it.path === currentPath);
			if (item) {
				if (item.contentType === "file") break;
			} else {
				stopPath = parentPath || currentPath;
				break;
			}
		}
		if (!stopPath) stopPath = currentPath;
		parentPath = currentPath;
	}
	if (!stopPath) return null;
	return {
		start: path,
		stop: stopPath
	};
}
function pathInfo(path) {
	const segments = path.split("/");
	const name = segments.pop() || "";
	return {
		dir: segments.join("/"),
		name
	};
}
function extractPathFromParams(params, branch) {
	const pathWithBranch = `${params.branch}/${params["*"] || ""}`;
	return pathWithBranch.startsWith(branch) ? pathWithBranch.slice(branch.length + 1) : "";
}
export { updateFileTree as a, loadFileTreePath as i, fileTreeCacheKey as n, fileTreeQuery as r, codeViewFileTreeLayoutRoute as t };
