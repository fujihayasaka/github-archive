import { t as addBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
function fetchPoll(url, options, timeBetweenRequests = 1e3, acceptedStatusCodes = [200], pollStatusCodes = [202]) {
	return (async function poll(wait) {
		const request = new Request(url, options);
		addBaseFetchHeaders(request.headers);
		const response = await self.fetch(request);
		if (pollStatusCodes.includes(response.status)) {
			await new Promise((resolve) => setTimeout(resolve, wait));
			return poll(wait * 1.5);
		}
		if (acceptedStatusCodes.includes(response.status)) return response;
		if (response.status < 200 || response.status >= 300) throw new Error(`HTTP ${response.status}${response.statusText || ""}`);
		throw new Error(`Unexpected ${response.status} response status from poll endpoint`);
	})(timeBetweenRequests);
}
export { fetchPoll as t };
