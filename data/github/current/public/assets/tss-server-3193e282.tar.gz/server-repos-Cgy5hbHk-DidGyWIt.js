performance.mark("js-parse-end:server-repos-Cgy5hbHk-DidGyWIt.js");
import { gr as RepoIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { g as useLocation$1, t as Link$1, y as useNavigation } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { n as useRouteQuery, r as useSuspenseRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as Pagination } from "./server-Pagination-B4OyqKu2-DIEgelho.js";
import { a as getSortFromQuery, i as addSortToQuery } from "./server-query-DlQMbiaN-CidcEdMM.js";
import { c as reposFinderPageRoute, i as ReposListLoadingSkeleton, l as sortingOptionsWithRelevance, o as getScreenReaderMessage, r as ReposList, s as reposFinderLayoutRoute, u as useCompactModeSetting } from "./server-repos-finder-page-route-CLW2IkJh-kX9Pej9X.js";
import { n as useReposFinderStateContext } from "./server-ReposFinderStateContext-DmypLpye-wNDNZQST.js";
import { useEffect, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:repos-Cgy5hbHk.js");
function getNoRepoMessage({ currentPage, filtered, pageCount, userInfo }) {
	const { directOrTeamMember, admin } = userInfo || {};
	if (pageCount > 0 && currentPage > pageCount) return {
		heading: "No more repositories.",
		description: "Visit a lower page."
	};
	else if (filtered) return {
		heading: "No repositories matched your search.",
		description: "Try a different search query."
	};
	else if (admin) return { heading: "This organization has no repositories." };
	else if (directOrTeamMember) return { heading: "Your teams don't have access to any repositories." };
	else return { heading: "This organization has no public repositories." };
}
function NoReposMessage({ currentPage, filtered, pageCount, userInfo }) {
	return /* @__PURE__ */ jsx(NoReposBlankslate, { message: getNoRepoMessage({
		currentPage,
		filtered,
		pageCount,
		userInfo
	}) });
}
NoReposMessage.displayName = "NoReposMessage";
function NoReposBlankslate({ message }) {
	return /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
		/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(RepoIcon, { size: 24 }) }),
		/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: message.heading }),
		message.description && /* @__PURE__ */ jsx(BlankslateContainer.Description, { children: message.description })
	] });
}
NoReposBlankslate.displayName = "NoReposBlankslate";
var debounceAnnounce = debounce(announce$1, 300);
function getEmptyMessage({ filtered, currentPage, pageCount, errorMessage }) {
	if (errorMessage) return {
		heading: "Invalid query",
		description: errorMessage
	};
	if (pageCount > 0 && currentPage > pageCount) return {
		heading: "No more repositories.",
		description: "Visit a lower page."
	};
	if (filtered) return {
		heading: "No repositories matched your search.",
		description: "Try a different search query."
	};
	return { heading: "Enter a query to start searching." };
}
/**
* Hook to manage screen reader announcements for the repos finder page.
* Announces search results and empty states to screen reader users.
* @param isFetching - Whether a fetch is currently in progress.
* @param currentPage - The current page number.
* @param fetchedQuery - The query string that was fetched.
* @param results - The current list results.
* @param defaultSortingKey - The default sorting key to use.
* @param errorMessage - Optional error message to announce when the query is invalid or results in an error.
* @returns An object containing the empty messages for display.
*/
function useFinderScreenReaderAnnouncements(isFetching, currentPage, fetchedQuery, results, defaultSortingKey, errorMessage) {
	const $ = c(13);
	let emptyMessages;
	let t0;
	if ($[0] !== currentPage || $[1] !== defaultSortingKey || $[2] !== errorMessage || $[3] !== fetchedQuery || $[4] !== isFetching || $[5] !== results) {
		emptyMessages = getEmptyMessage({
			filtered: !!fetchedQuery,
			currentPage,
			pageCount: results.pageCount,
			errorMessage
		});
		t0 = getScreenReaderMessage(sortingOptionsWithRelevance, defaultSortingKey, () => emptyMessages, isFetching, currentPage, fetchedQuery, results);
		$[0] = currentPage;
		$[1] = defaultSortingKey;
		$[2] = errorMessage;
		$[3] = fetchedQuery;
		$[4] = isFetching;
		$[5] = results;
		$[6] = emptyMessages;
		$[7] = t0;
	} else {
		emptyMessages = $[6];
		t0 = $[7];
	}
	const message = t0;
	let t1;
	let t2;
	if ($[8] !== message) {
		t1 = () => {
			if (message) debounceAnnounce(message);
		};
		t2 = [message];
		$[8] = message;
		$[9] = t1;
		$[10] = t2;
	} else {
		t1 = $[9];
		t2 = $[10];
	}
	useEffect(t1, t2);
	let t3;
	if ($[11] !== emptyMessages) {
		t3 = { emptyMessages };
		$[11] = emptyMessages;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
}
/**
* Hook to manage the state of the repos finder page results.
* Handles the display logic for showing empty results when the query is cleared.
*
* @param payload - The page payload containing repository search results
*/
function useReposFinderState(payload) {
	const $ = c(6);
	const { fetchedQuery, currentPage, fetchResults } = useReposFinderStateContext();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			repositories: [],
			repositoryCount: 0,
			pageCount: 1
		};
		$[0] = t0;
	} else t0 = $[0];
	const results = !!fetchedQuery ? payload : t0;
	let t1;
	if ($[1] !== currentPage || $[2] !== fetchResults || $[3] !== fetchedQuery || $[4] !== results) {
		t1 = {
			fetchedQuery,
			results,
			currentPage,
			fetchResults
		};
		$[1] = currentPage;
		$[2] = fetchResults;
		$[3] = fetchedQuery;
		$[4] = results;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
var DEFAULT_SORTING_KEY = "relevance";
function isSameLocation(a, b) {
	return a.pathname === b.pathname && a.search === b.search;
}
function ReposFinderPage() {
	const $ = c(2);
	const navigation = useNavigation();
	const location = useLocation$1();
	if (Boolean(navigation.location && !isSameLocation(navigation.location, location))) {
		let t0;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t0 = jsx(ReposListLoadingSkeleton, {});
			$[0] = t0;
		} else t0 = $[0];
		return t0;
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = jsx(ReposFinderPageContent, {});
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
ReposFinderPage.displayName = "ReposFinderPage";
function ReposFinderPageContent() {
	const { data: payload } = useSuspenseRouteQuery(reposFinderPageRoute, "mainQuery");
	const { data: { compactMode } } = useRouteQuery(reposFinderLayoutRoute, "mainQuery");
	const { fetchedQuery, results, currentPage, fetchResults } = useReposFinderState(payload);
	const hasQuery = Boolean(fetchedQuery && fetchedQuery.trim().length > 0);
	const { updateCompactModeSetting } = useCompactModeSetting(compactMode, "repos_finder_compact_mode");
	const { emptyMessages } = useFinderScreenReaderAnnouncements(false, currentPage, fetchedQuery, results, DEFAULT_SORTING_KEY, hasQuery ? payload.errorMessage : void 0);
	const reposListRef = useRef(void 0);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
		className: "tmp-my-3",
		children: /* @__PURE__ */ jsx("div", {
			"data-hpc": true,
			children: /* @__PURE__ */ jsx(ReposList, {
				listRef: reposListRef,
				query: fetchedQuery,
				showNameWithOwner: true,
				compactMode,
				onCompactModeChanged: updateCompactModeSetting,
				repositoryCount: results.repositoryCount,
				repos: results.repositories,
				onSortingItemSelect: (sort) => fetchResults({ q: addSortToQuery(fetchedQuery, sort) }),
				sortingItemSelected: getSortFromQuery(fetchedQuery),
				defaultSortingKey: DEFAULT_SORTING_KEY,
				sortingOptions: sortingOptionsWithRelevance,
				directionRestrictedKeys: ["relevance"],
				noReposMessage: /* @__PURE__ */ jsx(NoReposBlankslate, { message: emptyMessages }),
				linkAs: Link$1
			})
		})
	}), results.pageCount > 1 && /* @__PURE__ */ jsx(Pagination, {
		pageCount: results.pageCount,
		currentPage,
		onPageChange: (e, page) => {
			e.preventDefault();
			reposListRef.current?.focus();
			window.scrollTo({ top: 0 });
			fetchResults({
				q: fetchedQuery,
				page
			});
		}
	})] });
}
ReposFinderPageContent.displayName = "ReposFinderPageContent";
var SplitComponent = ReposFinderPageContent;
export { SplitComponent as component };
