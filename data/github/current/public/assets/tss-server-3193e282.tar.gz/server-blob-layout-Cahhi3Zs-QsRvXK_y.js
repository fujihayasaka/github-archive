performance.mark("js-parse-end:server-blob-layout-Cahhi3Zs-QsRvXK_y.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:blob-layout-Cahhi3Zs.js");
var codeViewBlobLayoutServerFn_createServerFn_handler = createServerRpc({
	id: "c83dfe310299fc5ef2a93f49a7327eabe3cf9dedae2230f9a88bf953a13368cb",
	name: "codeViewBlobLayoutServerFn",
	filename: "src/routes/code-view/blob-layout.tsx"
}, (opts) => codeViewBlobLayoutServerFn.__executeServer(opts));
var codeViewBlobLayoutServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewBlobLayoutServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewBlobLayoutRoute");
});
var codeViewBlobLayoutStyledBlobServerFn_createServerFn_handler = createServerRpc({
	id: "8504c6d56c3efae37bf79d9b8c60c5a14489f3720fd612aa3cb53417d9f5a9da",
	name: "codeViewBlobLayoutStyledBlobServerFn",
	filename: "src/routes/code-view/blob-layout.tsx"
}, (opts) => codeViewBlobLayoutStyledBlobServerFn.__executeServer(opts));
var codeViewBlobLayoutStyledBlobServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewBlobLayoutStyledBlobServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_codeViewBlobLayoutRoute.StyledBlob"
	});
});
var deferredMetadataServerFn_createServerFn_handler = createServerRpc({
	id: "140174379d70ac1fb8fe0e39cc460887e8bbb07eb0ae1ce7e2488ed81b793b6f",
	name: "deferredMetadataServerFn",
	filename: "src/routes/code-view/blob-layout.tsx"
}, (opts) => deferredMetadataServerFn.__executeServer(opts));
var deferredMetadataServerFn = createServerFn().inputValidator(queryValidator.base).handler(deferredMetadataServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_deferredMetadata"
	});
});
export { codeViewBlobLayoutServerFn_createServerFn_handler, codeViewBlobLayoutStyledBlobServerFn_createServerFn_handler, deferredMetadataServerFn_createServerFn_handler };
