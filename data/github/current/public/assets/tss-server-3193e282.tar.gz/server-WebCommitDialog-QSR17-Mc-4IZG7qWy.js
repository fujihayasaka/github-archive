import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ct as FileDiffIcon, Dt as FileIcon, Jt as GitPullRequestIcon, bn as Link, bt as FileAddedIcon, dr as Radio, fr as RadioGroup_default, kt as FileRemovedIcon, ni as SyncIcon, o as AlertIcon, pi as Tooltip$1, ut as DiffRenamedIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { f as sendStats } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { i as LinkButton, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { i as Textarea, r as Select$1, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { r as CopilotAuthTokenProvider } from "./server-copilot-auth-token-BzqAQyH0-Dwg6bEJM.js";
import { H as makeCAPIRequest } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { a as useShortcut } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { c as useFileTreeControlContext, t as DuplicateOnKeydownButton } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { n as FeatureRequest } from "./server-FeatureRequest-BkET-vSV-lmJnXnOw.js";
import { r as useCodeViewAddQueuedBanner } from "./server-CodeViewBannersContext-CEdzkK6e-znl4nx1w.js";
import { t as resetMemoizeFetchJSON } from "./server-use-latest-commit-CEaptRlH-Dq4wXeZZ.js";
import { t as FlashError } from "./server-FlashError-IPp9CZEl-D14JRFXM.js";
import { t as CheckboxGroup_default } from "./server-CheckboxGroup-D-9z19be-BHUG_g4C.js";
import { n as wait } from "./server-eventloop-tasks-XdjS6iVt-BpyiM497.js";
import { t as CopilotChatMessageStreamer } from "./server-copilot-chat-message-streamer-DwhhquJZ-Be7HnjXD.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { i as loadFileTreePath } from "./server-file-tree-query-BoZ7HlYc-BElKzBR6.js";
import React, { useCallback, useEffect, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { formatPatch, structuredPatch } from "diff";
var TextExpander_module_default = {
	TextExpanderWrapper: "TextExpander-module_OqLT7a_TextExpanderWrapper",
	textInput: "TextExpander-module_OqLT7a_textInput"
};
function TextExpander({ suggestionsUrlIssue, suggestionsUrlMention, suggestionsUrlEmoji, value, setValue, textareaProps, className }) {
	const textExpanderRef = useRef(null);
	const textareaRef = useRef(null);
	const textExpanderValueHandler = (ev) => {
		if (ev.code === "Enter" && !(ev.metaKey || ev.ctrlKey) || ev.code === "Tab" && textareaRef.current?.value !== value) ev.stopPropagation();
	};
	const onTextExpanderCommitted = useCallback(() => {
		setValue(textareaRef.current?.value || value);
	}, [setValue, value]);
	useEffect(() => {
		const innerTextExpanderRef = textExpanderRef.current;
		innerTextExpanderRef?.addEventListener("text-expander-committed", onTextExpanderCommitted);
		return () => {
			innerTextExpanderRef?.removeEventListener("text-expander-committed", onTextExpanderCommitted);
		};
	}, [onTextExpanderCommitted]);
	return /* @__PURE__ */ jsx("div", {
		className: clsx(TextExpander_module_default.TextExpanderWrapper, className),
		children: /* @__PURE__ */ jsx("text-expander", {
			keys: ": @ #",
			"data-issue-url": suggestionsUrlIssue,
			"data-mention-url": suggestionsUrlMention,
			"data-emoji-url": suggestionsUrlEmoji,
			ref: textExpanderRef,
			children: /* @__PURE__ */ jsx(Textarea, {
				onChange: (event) => setValue(event.target.value),
				onKeyDown: textExpanderValueHandler,
				ref: textareaRef,
				value,
				className: TextExpander_module_default.textInput,
				...textareaProps
			})
		})
	});
}
TextExpander.displayName = "TextExpander";
var BranchProtectionNotEnforcedBanner_module_default = {
	BranchProtectionNotEnforcedBannerActions: "BranchProtectionNotEnforcedBanner-module_cZPVrq_BranchProtectionNotEnforcedBannerActions",
	BranchProtectionNotEnforcedBannerFlash: "BranchProtectionNotEnforcedBanner-module_cZPVrq_BranchProtectionNotEnforcedBannerFlash"
};
function BranchProtectionNotEnforcedBanner({ branch, protectionNotEnforcedInfo }) {
	const cta = protectionNotEnforcedInfo.upsellCtaInfo.cta;
	const organization = protectionNotEnforcedInfo.organization;
	const { branchProtected, rulesetsProtected } = protectionNotEnforcedInfo;
	const { showUpgradeButton, askAdmin, ctaPath } = cta;
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className: BranchProtectionNotEnforcedBanner_module_default.BranchProtectionNotEnforcedBannerFlash,
		children: [
			/* @__PURE__ */ jsx(BannerMessage, {
				organization,
				branchProtected,
				rulesetsProtected,
				protectionNotEnforcedInfo,
				askAdmin,
				branch
			}),
			showUpgradeButton && /* @__PURE__ */ jsx(LinkButton, {
				...testIdProps("Upgrade-Btn"),
				href: ctaPath,
				className: clsx(LinkButton_module_default.linkButton, BranchProtectionNotEnforcedBanner_module_default.BranchProtectionNotEnforcedBannerActions),
				children: "Upgrade"
			}),
			/* @__PURE__ */ jsx("div", {
				"aria-live": "polite",
				className: BranchProtectionNotEnforcedBanner_module_default.BranchProtectionNotEnforcedBannerActions,
				children: /* @__PURE__ */ jsx(FeatureRequest, {
					featureRequestInfo: protectionNotEnforcedInfo.featureRequestInfo,
					requestedMessage: "You've successfully submitted a request to your organization's admins for this feature."
				})
			})
		]
	});
}
BranchProtectionNotEnforcedBanner.displayName = "BranchProtectionNotEnforcedBanner";
var BannerMessage = ({ askAdmin, branch, organization, branchProtected, rulesetsProtected, protectionNotEnforcedInfo }) => {
	if (organization) {
		if (branchProtected && !rulesetsProtected) return /* @__PURE__ */ jsx(ProtectedBranchOrganizationMessage, {
			branchProtectionPath: protectionNotEnforcedInfo.editRepositoryBranchesPath,
			askAdmin,
			branch
		});
		return /* @__PURE__ */ jsx(RulesetUpsellOrganizationMessage, {
			rulesetsPath: protectionNotEnforcedInfo.editRepositoryRulesetsPath,
			askAdmin,
			branch
		});
	}
	if (branchProtected && !rulesetsProtected) return /* @__PURE__ */ jsx(ProtectedBranchPersonalMessage, {
		branchProtectionPath: protectionNotEnforcedInfo.editRepositoryBranchesPath,
		askAdmin,
		branch
	});
	return /* @__PURE__ */ jsx(RulesetsUpsellPersonalMessage, {
		rulesetsPath: protectionNotEnforcedInfo.editRepositoryRulesetsPath,
		askAdmin,
		branch
	});
};
BannerMessage.displayName = "BannerMessage";
function ProtectedBranchOrganizationMessage({ branchProtectionPath, branch, askAdmin }) {
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("pb-org"),
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			"Your ",
			LinkToIf(!askAdmin, "protected branch rules", branchProtectionPath),
			" ",
			/* @__PURE__ */ jsx("strong", { children: branch }),
			" branch won't be enforced on this private repository until you upgrade this organization to a GitHub Team or Enterprise account."
		]
	});
}
ProtectedBranchOrganizationMessage.displayName = "ProtectedBranchOrganizationMessage";
function ProtectedBranchPersonalMessage({ branchProtectionPath, branch, askAdmin }) {
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("pb-personal"),
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			"Your ",
			LinkToIf(!askAdmin, "protected branch rules", branchProtectionPath),
			" ",
			/* @__PURE__ */ jsx("strong", { children: branch }),
			" branch won't be enforced on this private repository until you move to a GitHub Team or Enterprise account."
		]
	});
}
ProtectedBranchPersonalMessage.displayName = "ProtectedBranchPersonalMessage";
function RulesetsUpsellPersonalMessage({ rulesetsPath, askAdmin, branch }) {
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("ru-personal"),
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			"The ",
			LinkToIf(!askAdmin, "rulesets", rulesetsPath),
			" targeting your ",
			/* @__PURE__ */ jsx("strong", { children: branch }),
			" branch won't be enforced on this private repository until you move to a GitHub Team organization account."
		]
	});
}
RulesetsUpsellPersonalMessage.displayName = "RulesetsUpsellPersonalMessage";
function RulesetUpsellOrganizationMessage({ rulesetsPath, askAdmin, branch }) {
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("ru-org"),
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			"The ",
			LinkToIf(!askAdmin, "rulesets", rulesetsPath),
			" targeting your ",
			/* @__PURE__ */ jsx("strong", { children: branch }),
			!askAdmin ? " branch won't be enforced on this private repository until you upgrade this organization to GitHub Team." : " branch won't be enforced on this private repository until your organization admins upgrade this organization account to GitHub Team."
		]
	});
}
RulesetUpsellOrganizationMessage.displayName = "RulesetUpsellOrganizationMessage";
function LinkToIf(condition, text, link) {
	return condition ? /* @__PURE__ */ jsx(Link, {
		href: link,
		role: "link",
		...testIdProps("linked-text"),
		inline: true,
		children: text
	}) : text;
}
LinkToIf.displayName = "LinkToIf";
function CommitButton({ preventSubmit, preventSubmitMessage, isSaving, saveHandler, saveButtonMessage, saveButtonType, buttonHotkey }) {
	const Button = /* @__PURE__ */ jsx(ButtonComponent, {
		onClick: preventSubmit ? () => {} : saveHandler,
		"aria-disabled": preventSubmit || isSaving,
		inactive: preventSubmit || isSaving,
		variant: saveButtonType,
		"data-hotkey": buttonHotkey,
		...testIdProps("submit-commit-button"),
		children: isSaving ? "Saving..." : saveButtonMessage
	});
	return preventSubmit && preventSubmitMessage ? /* @__PURE__ */ jsx(Tooltip$1, {
		text: preventSubmitMessage,
		type: "description",
		children: Button
	}) : Button;
}
CommitButton.displayName = "CommitButton";
var FileStatusIcon = ({ status }) => {
	switch (status) {
		case "A": return /* @__PURE__ */ jsx(FileAddedIcon, { className: "color-fg-success" });
		case "D": return /* @__PURE__ */ jsx(FileRemovedIcon, { className: "color-fg-danger" });
		case "M": return /* @__PURE__ */ jsx(FileDiffIcon, { className: "color-fg-attention" });
		case "R": return /* @__PURE__ */ jsx(DiffRenamedIcon, { className: "color-fg-muted" });
		default: return /* @__PURE__ */ jsx(FileIcon, {});
	}
};
FileStatusIcon.displayName = "FileStatusIcon";
var WebCommitDialog_module_default = {
	branchNameInput: "WebCommitDialog-module_RaiqUW_branchNameInput",
	branchNamePre: "WebCommitDialog-module_RaiqUW_branchNamePre",
	commitDescription: "WebCommitDialog-module_RaiqUW_commitDescription",
	commitDescriptionInput: "WebCommitDialog-module_RaiqUW_commitDescriptionInput",
	commitEmailFormControl: "WebCommitDialog-module_RaiqUW_commitEmailFormControl",
	commitFileIcon: "WebCommitDialog-module_RaiqUW_commitFileIcon",
	commitMessageInput: "WebCommitDialog-module_RaiqUW_commitMessageInput",
	commitMessageLabel: "WebCommitDialog-module_RaiqUW_commitMessageLabel",
	commitOptionLabel: "WebCommitDialog-module_RaiqUW_commitOptionLabel",
	fileCheckboxGroup: "WebCommitDialog-module_RaiqUW_fileCheckboxGroup",
	fileCheckboxLabel: "WebCommitDialog-module_RaiqUW_fileCheckboxLabel",
	FormControl_Label: "WebCommitDialog-module_RaiqUW_FormControl_Label",
	generatingCommitMessageFeedback: "WebCommitDialog-module_RaiqUW_generatingCommitMessageFeedback",
	generatingCommitMessageFeedbackCopy: "WebCommitDialog-module_RaiqUW_generatingCommitMessageFeedbackCopy",
	generatingCommitMessageInput: "WebCommitDialog-module_RaiqUW_generatingCommitMessageInput",
	pullRequestHelpLink: "WebCommitDialog-module_RaiqUW_pullRequestHelpLink",
	quickPullBranchInputContainer: "WebCommitDialog-module_RaiqUW_quickPullBranchInputContainer",
	WebCommitDialogDialog: "WebCommitDialog-module_RaiqUW_WebCommitDialogDialog",
	WebCommitDialogFooterActions: "WebCommitDialog-module_RaiqUW_WebCommitDialogFooterActions"
};
var COMMIT_MESSAGE_INPUT_ID = "commit-message-input";
var COMMIT_DESCRIPTION_INPUT_ID = "commit-description-input";
var BRANCH_NAME_INPUT_ID = "branch-name-input";
function WebCommitDialog$1({ additionalFooterContent, disableQuickPull, dialogProps, helpUrl, placeholderMessage, refName, webCommitInfo, dialogState, onSave, setDialogState, fileStatuses, selectedFiles, setSelectedFiles, message, setMessage, description, setDescription, isQuickPull, setIsQuickPull, prTargetBranch, setPRTargetBranch, setAuthorEmail, errorMessage, errorDetails, returnFocusRef, directCommitDisabled, diffList, preventSubmit, preventSubmitMessage, showGeneratingCommitMessageLoading, showGeneratingCommitMessageLoaded, hasShownGeneratedCommitMessage, onCopilotCommitGenerationCancel, onRegenerateCommitMessageClick }) {
	const { authorEmails, canCommitStatus, canCreatePullRequest, dcoSignoffEnabled, dcoSignoffHelpUrl, defaultEmail, defaultNewBranchName, forkedRepo, repoHeadEmpty, suggestionsUrlEmoji, suggestionsUrlIssue, suggestionsUrlMention } = webCommitInfo;
	const [branchNamedWrong, setBranchNamedWrong] = React.useState(false);
	const isSaving = dialogState === "saving";
	const branchNameInputRef = React.useRef(null);
	const flashErrorRef = React.useRef(null);
	const { submitCommitDialogShortcut } = useShortcut();
	const handleChoiceOneChange = (selectedValue) => {
		setIsQuickPull?.(selectedValue === "pr");
	};
	const commitMessageInputRef = React.useRef(null);
	useEffect(() => {
		if (commitMessageInputRef.current) commitMessageInputRef.current.focus();
	}, []);
	const isIMEOpen = React.useRef(false);
	let webCommitTitle = isQuickPull ? "Propose changes" : "Commit changes";
	if (dcoSignoffEnabled) webCommitTitle = `Sign off and ${webCommitTitle.toLocaleLowerCase()}`;
	const quickPullChoice = !forkedRepo && !repoHeadEmpty && !disableQuickPull;
	const saveHandler = async () => {
		if (isQuickPull && quickPullChoice && prTargetBranch === "HEAD") {
			setBranchNamedWrong(true);
			branchNameInputRef.current?.focus();
			return;
		}
		setBranchNamedWrong(false);
		onSave();
	};
	const checkboxHandler = useCallback((event) => {
		const path = event.target.value;
		setSelectedFiles?.((prevSelectedFiles) => {
			const newSelectedFiles = new Set(prevSelectedFiles);
			if (newSelectedFiles.has(path)) newSelectedFiles.delete(path);
			else newSelectedFiles.add(path);
			return newSelectedFiles;
		});
	}, [setSelectedFiles]);
	useEffect(() => {
		if (errorMessage && flashErrorRef.current) flashErrorRef.current.focus();
	}, [errorMessage]);
	const filteredAuthorEmails = authorEmails.filter((email) => email);
	const saveButtonType = canCommitStatus !== "allowed" && !isQuickPull ? "danger" : "primary";
	const saveButtonMessage = canCommitStatus === "can_bypass" && !isQuickPull ? "Bypass rules and commit changes" : webCommitTitle;
	return /* @__PURE__ */ jsxs(Dialog, {
		"aria-labelledby": "web-commit-dialog-header",
		onClose: (gesture) => {
			if (gesture !== "close-button") return;
			if (!isIMEOpen.current) setDialogState("closed");
		},
		title: webCommitTitle,
		returnFocusRef,
		width: "large",
		renderFooter: () => /* @__PURE__ */ jsxs("div", {
			className: WebCommitDialog_module_default.WebCommitDialogFooterActions,
			children: [
				additionalFooterContent,
				/* @__PURE__ */ jsx(ButtonComponent, {
					onClick: () => {
						setDialogState("closed");
					},
					children: "Cancel"
				}),
				/* @__PURE__ */ jsx(CommitButton, {
					preventSubmit: preventSubmit || false,
					preventSubmitMessage,
					isSaving,
					saveHandler,
					saveButtonMessage,
					saveButtonType,
					buttonHotkey: submitCommitDialogShortcut.hotkey
				}),
				/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
					buttonFocusId: COMMIT_MESSAGE_INPUT_ID,
					buttonHotkey: submitCommitDialogShortcut.hotkey,
					onlyAddHotkeyScopeButton: true,
					onButtonClick: saveHandler
				}),
				/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
					buttonFocusId: COMMIT_DESCRIPTION_INPUT_ID,
					buttonHotkey: submitCommitDialogShortcut.hotkey,
					onlyAddHotkeyScopeButton: true,
					onButtonClick: saveHandler
				}),
				/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
					buttonFocusId: BRANCH_NAME_INPUT_ID,
					buttonHotkey: submitCommitDialogShortcut.hotkey,
					onlyAddHotkeyScopeButton: true,
					onButtonClick: saveHandler
				})
			]
		}),
		className: WebCommitDialog_module_default.WebCommitDialogDialog,
		...dialogProps,
		children: [/* @__PURE__ */ jsx(FlashError, {
			prefix: "There was an error committing your changes:",
			errorMessageUsingPrefix: errorDetails?.ruleViolations ? "Please address the rule violations and try again." : errorMessage,
			ruleErrors: errorDetails?.ruleViolations,
			helpUrl,
			flashRef: flashErrorRef
		}), /* @__PURE__ */ jsxs("form", {
			onSubmit: (event_0) => {
				saveHandler();
				event_0.preventDefault();
			},
			children: [
				/* @__PURE__ */ jsxs(FormControl$1, {
					id: COMMIT_MESSAGE_INPUT_ID,
					children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, {
							className: WebCommitDialog_module_default.commitMessageLabel,
							children: /* @__PURE__ */ jsx("span", { children: "Commit message" })
						}),
						/* @__PURE__ */ jsx(TextInput$1, {
							onChange: (event_1) => setMessage(event_1.target.value),
							placeholder: showGeneratingCommitMessageLoading ? "Copilot is thinking..." : placeholderMessage,
							value: message,
							ref: commitMessageInputRef,
							className: WebCommitDialog_module_default.commitMessageInput,
							onKeyDown: () => onCopilotCommitGenerationCancel?.(),
							"aria-describedby": showGeneratingCommitMessageLoaded ? "commit-message-generated" : void 0,
							trailingAction: showGeneratingCommitMessageLoaded ? /* @__PURE__ */ jsx(TextInput$1.Action, {
								onClick: () => onRegenerateCommitMessageClick?.(),
								icon: SyncIcon,
								"aria-label": "Regenerate commit message"
							}) : void 0
						}),
						showGeneratingCommitMessageLoaded && /* @__PURE__ */ jsxs("div", {
							id: "commit-message-generated",
							"aria-live": "polite",
							style: {
								position: "absolute",
								width: "1px",
								height: "1px",
								padding: 0,
								margin: "-1px",
								overflow: "hidden",
								whiteSpace: "nowrap",
								border: 0
							},
							children: ["Copilot commit message generated: ", message]
						})
					]
				}),
				/* @__PURE__ */ jsxs(FormControl$1, {
					className: WebCommitDialog_module_default.commitDescription,
					children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Extended description" }),
						/* @__PURE__ */ jsx(TextExpander, {
							suggestionsUrlIssue,
							suggestionsUrlMention,
							suggestionsUrlEmoji,
							value: description,
							setValue: setDescription,
							textareaProps: {
								placeholder: showGeneratingCommitMessageLoading ? "Copilot is thinking..." : "Add an optional extended description...",
								onCompositionStart: () => isIMEOpen.current = true,
								onCompositionEnd: () => isIMEOpen.current = false,
								id: COMMIT_DESCRIPTION_INPUT_ID,
								onFocus: () => onCopilotCommitGenerationCancel?.()
							},
							className: WebCommitDialog_module_default.commitDescriptionInput
						}),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: hasShownGeneratedCommitMessage && /* @__PURE__ */ jsx("div", {
							className: WebCommitDialog_module_default.generatingCommitMessageFeedback,
							children: /* @__PURE__ */ jsx("span", {
								className: WebCommitDialog_module_default.generatingCommitMessageFeedbackCopy,
								children: "Message and description suggested by Copilot."
							})
						}) })
					]
				}),
				filteredAuthorEmails.length > 1 ? /* @__PURE__ */ jsxs(FormControl$1, {
					className: WebCommitDialog_module_default.commitEmailFormControl,
					children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Commit Email" }),
						/* @__PURE__ */ jsx(Select$1, {
							onChange: (ev) => {
								setAuthorEmail(ev.target.value);
							},
							defaultValue: defaultEmail,
							children: authorEmails.map((email_0) => /* @__PURE__ */ jsx(Select$1.Option, {
								value: email_0,
								children: email_0
							}, email_0))
						}),
						dcoSignoffEnabled && /* @__PURE__ */ jsxs(FormControl$1.Caption, { children: [
							"Choose an email address for",
							" ",
							/* @__PURE__ */ jsx(Link, {
								href: dcoSignoffHelpUrl,
								target: "_blank",
								rel: "noreferrer",
								inline: true,
								children: "signing off"
							}),
							" ",
							"on this commit"
						] })
					]
				}) : dcoSignoffEnabled ? /* @__PURE__ */ jsxs("div", {
					className: WebCommitDialog_module_default.commitEmailFormControl,
					children: [
						"You are",
						" ",
						/* @__PURE__ */ jsx(Link, {
							href: dcoSignoffHelpUrl,
							target: "_blank",
							rel: "noreferrer",
							inline: true,
							children: "signing off"
						}),
						" ",
						"on this commit as ",
						defaultEmail
					]
				}) : null,
				webCommitInfo.protectionNotEnforcedInfo?.upsellCtaInfo.visible && /* @__PURE__ */ jsx(BranchProtectionNotEnforcedBanner, {
					branch: refName,
					protectionNotEnforcedInfo: webCommitInfo.protectionNotEnforcedInfo
				}),
				quickPullChoice && /* @__PURE__ */ jsxs(RadioGroup_default, {
					name: "pr-choice",
					onChange: handleChoiceOneChange,
					children: [
						/* @__PURE__ */ jsx(RadioGroup_default.Label, {
							visuallyHidden: true,
							children: "Direct commit or PR"
						}),
						/* @__PURE__ */ jsxs(FormControl$1, { children: [
							canCommitStatus !== "blocked" && !directCommitDisabled && /* @__PURE__ */ jsx(Radio, {
								"aria-checked": !isQuickPull,
								"aria-describedby": canCommitStatus === "can_bypass" && !isQuickPull ? "bypass-warning" : void 0,
								value: "direct",
								defaultChecked: !isQuickPull
							}),
							/* @__PURE__ */ jsx(FormControl$1.Label, {
								className: WebCommitDialog_module_default.commitOptionLabel,
								children: directCommitDisabled ? /* @__PURE__ */ jsx(Fragment$1, { children: "Direct commits are disabled for closed pull requests." }) : canCommitStatus !== "blocked" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
									"Commit directly to the ",
									/* @__PURE__ */ jsx("pre", {
										className: WebCommitDialog_module_default.branchNamePre,
										children: refName
									}),
									" branch"
								] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [
									"You can’t commit to ",
									/* @__PURE__ */ jsx("pre", {
										className: WebCommitDialog_module_default.branchNamePre,
										children: refName
									}),
									" because it is a",
									" ",
									/* @__PURE__ */ jsx(Link, {
										href: `${helpUrl}/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests`,
										inline: true,
										children: "protected branch"
									})
								] })
							}),
							canCommitStatus !== "blocked" && canCommitStatus === "can_bypass" && !isQuickPull && /* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Some rules will be bypassed by committing directly" })
						] }),
						/* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(Radio, {
							"aria-checked": isQuickPull,
							value: "pr",
							defaultChecked: isQuickPull
						}), /* @__PURE__ */ jsxs(FormControl$1.Label, {
							className: WebCommitDialog_module_default.FormControl_Label,
							children: [
								"Create a ",
								/* @__PURE__ */ jsx("strong", { children: "new branch" }),
								" for this commit",
								canCreatePullRequest ?? true ? " and start a pull request" : "",
								" ",
								/* @__PURE__ */ jsx(Link, {
									href: `${helpUrl}/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests`,
									inline: true,
									className: WebCommitDialog_module_default.pullRequestHelpLink,
									children: "Learn more about pull requests"
								})
							]
						})] }),
						isQuickPull && /* @__PURE__ */ jsx("div", {
							className: WebCommitDialog_module_default.quickPullBranchInputContainer,
							children: /* @__PURE__ */ jsxs(FormControl$1, {
								id: BRANCH_NAME_INPUT_ID,
								children: [
									/* @__PURE__ */ jsx(FormControl$1.Label, {
										visuallyHidden: true,
										children: "Branch Name"
									}),
									/* @__PURE__ */ jsx(TextInput$1, {
										ref: branchNameInputRef,
										"aria-label": "PR target branch",
										leadingVisual: GitPullRequestIcon,
										onChange: (event_2) => setPRTargetBranch?.(event_2.target.value),
										placeholder: defaultNewBranchName,
										value: prTargetBranch,
										className: WebCommitDialog_module_default.branchNameInput
									}),
									branchNamedWrong && /* @__PURE__ */ jsx(FormControl$1.Validation, {
										variant: "error",
										children: "New branch name can not be \"HEAD\""
									})
								]
							})
						})
					]
				}),
				fileStatuses && selectedFiles && /* @__PURE__ */ jsxs(CheckboxGroup_default, {
					className: WebCommitDialog_module_default.fileCheckboxGroup,
					children: [/* @__PURE__ */ jsx(CheckboxGroup_default.Label, { children: "Changes to commit" }), Object.entries(fileStatuses).map(([path_0, status]) => /* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(Checkbox, {
						value: path_0,
						checked: selectedFiles.has(path_0),
						onChange: checkboxHandler
					}), /* @__PURE__ */ jsxs(FormControl$1.Label, {
						className: WebCommitDialog_module_default.fileCheckboxLabel,
						children: [/* @__PURE__ */ jsx("div", {
							className: WebCommitDialog_module_default.commitFileIcon,
							children: /* @__PURE__ */ jsx(FileStatusIcon, { status })
						}), path_0]
					})] }, path_0))]
				}),
				diffList
			]
		})]
	});
}
WebCommitDialog$1.displayName = "WebCommitDialog";
var CHARACTERS_PER_TOKEN = 4;
async function handleStreamingMessage(streamer) {
	const messages = [];
	for await (const message of streamer.stream()) messages.push(message);
	if (messages.length === 0) throw new Error("No messages found in stream");
	if (messages.length > 1) throw new Error("More than one message found in stream");
	return messages[0];
}
function validateAndExtractCommitMessage(agentResponse) {
	const commitMessageResponse = agentResponse?.choices?.[0]?.message;
	if (!commitMessageResponse) throw new Error("No message found in agent response");
	if (!commitMessageResponse.content) throw new Error("No content found in commit message");
	let parsedContent;
	try {
		parsedContent = JSON.parse(commitMessageResponse.content);
	} catch {
		throw new Error("Invalid JSON in commit message response");
	}
	if (parsedContent.title === void 0 || parsedContent.title === null) throw new Error("No title field found in commit message response");
	if (parsedContent.description === void 0 || parsedContent.description === null) throw new Error("No description field found in commit message response");
	if (parsedContent.title.trim() === "") return;
	return {
		commitMessage: parsedContent.title,
		description: parsedContent.description
	};
}
function formatChangedFilesAsDiffs(files) {
	return files.map((file) => {
		return {
			type: "github.diff-hunk",
			data: {
				type: "diff-hunk",
				changeReference: "",
				fileName: file.path,
				headerContext: "",
				diff: formatPatch(file.patch)
			}
		};
	});
}
function formatChangedFiles(initialFileContent, currentFileContent, initialPath, completeFilePath) {
	return [{
		patch: structuredPatch(initialPath, completeFilePath, initialFileContent, currentFileContent),
		path: completeFilePath
	}];
}
function createDiffReferences(initialFileContent, currentFileContent, initialPath, completeFilePath) {
	return formatChangedFilesAsDiffs(formatChangedFiles(initialFileContent, currentFileContent, initialPath, completeFilePath));
}
function getFileStatus(isNewFile, isDeletedFile, contentChanged, oldPath, fileName) {
	if (isDeletedFile) return "D";
	return isNewFile ? "A" : fileName !== oldPath ? contentChanged ? "M" : "R" : "M";
}
function useTrackWebCommitAcceptance() {
	const $ = c(2);
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t0;
	if ($[0] !== sendClickAnalyticsEvent) {
		t0 = async (t1) => {
			const { message, description, placeholderMessage, generatedCommitMessage, showingGeneratedCommitMessage, showingGeneratedCommitDescription, isNewFile, isDelete, contentChanged, oldPath, fileName, content, regenerateCallCount, version } = t1;
			sendClickAnalyticsEvent({
				category: "web_commit_dialog",
				action: "submit",
				showing_generated_commit_message: showingGeneratedCommitMessage,
				showing_generated_commit_description: showingGeneratedCommitDescription,
				full_message_acceptence: message === placeholderMessage || message === generatedCommitMessage?.commitMessage,
				message_similarity: stringSimilarity(message, generatedCommitMessage?.commitMessage ?? ""),
				full_description_acceptence: description === generatedCommitMessage?.description,
				description_similarity: stringSimilarity(description, generatedCommitMessage?.description ?? ""),
				message_description_similarity: stringSimilarity(generatedCommitMessage?.commitMessage ?? "", generatedCommitMessage?.description ?? ""),
				file_status: getFileStatus(isNewFile, isDelete, contentChanged, oldPath, fileName),
				empty_description: description.trim() === "",
				change_chars_count: content?.replace(/\s+/g, "").length,
				regenerate_call_count: regenerateCallCount ?? 0,
				version
			});
		};
		$[0] = sendClickAnalyticsEvent;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function useTrackWebCommitRegenerated() {
	const $ = c(2);
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t0;
	if ($[0] !== sendClickAnalyticsEvent) {
		t0 = async (t1) => {
			const { version, regenerateCallCount, uniquelyGeneratedMessagesCount } = t1;
			sendClickAnalyticsEvent({
				category: "web_commit_dialog",
				action: "regenerate",
				version,
				regenerate_call_count: regenerateCallCount,
				uniquely_generated_messages_count: uniquelyGeneratedMessagesCount
			});
		};
		$[0] = sendClickAnalyticsEvent;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function calculateInputTokenUsage(copilotReferences) {
	if (!copilotReferences || copilotReferences.length === 0 || !copilotReferences[0]?.data) throw new Error("Copilot references are empty or undefined");
	let requestCharCount = 0;
	const { changeReference, diff, fileName, headerContext } = copilotReferences[0]?.data;
	requestCharCount += changeReference.length + diff.length + fileName.length + headerContext.length;
	return Math.ceil(requestCharCount / CHARACTERS_PER_TOKEN);
}
function calculateOutputTokenUsage(commitMessage) {
	if (!commitMessage || !commitMessage.choices[0]?.message.content) throw new Error("Commit message is empty or undefined");
	const chars = commitMessage.choices[0].message.content.length;
	return Math.ceil(chars / CHARACTERS_PER_TOKEN);
}
function stringSimilarity(str1, str2, substringLength = 2, caseSensitive = false) {
	if (!caseSensitive) {
		str1 = str1.toLowerCase();
		str2 = str2.toLowerCase();
	}
	if (str1.length < substringLength || str2.length < substringLength) return 0;
	const map = /* @__PURE__ */ new Map();
	for (let i = 0; i < str1.length - (substringLength - 1); i++) {
		const substr1 = str1.slice(i, i + substringLength);
		map.set(substr1, map.has(substr1) ? map.get(substr1) + 1 : 1);
	}
	let match = 0;
	for (let j = 0; j < str2.length - (substringLength - 1); j++) {
		const substr2 = str2.slice(j, j + substringLength);
		const count = map.has(substr2) ? map.get(substr2) : 0;
		if (count > 0) {
			map.set(substr2, count - 1);
			match++;
		}
	}
	return match * 2 / (str1.length + str2.length - (substringLength - 1) * 2);
}
function dryMessagesPrompt(generatedMessages) {
	let content = "## Additional context from previous messages\n\nDo not repeat or closely paraphrase any of these previously used messages. Instead, generate a new commit message that has a different focus, wording, or level of detail. If you cannot think of a new message, change the perspective, focus on different details, or rephrase creatively.\n\n<!-- BEGIN PREVIOUS MESSAGES -->\n";
	for (const message of generatedMessages) content += `### Previous message\n\n${message}\n\n`;
	content += "<!-- END PREVIOUS MESSAGES -->\n\n";
	return content;
}
function returnFallback(message) {
	return {
		commitMessage: message,
		description: ""
	};
}
var EXPECTED_ERROR_STATUS_CODES = [402, 429];
function sendErrorAndLatencyStats(incrementKey, startTime) {
	const duration = performance.now() - startTime;
	sendStats({
		incrementKey,
		requestUrl: window.location.href
	});
	sendStats({
		distributionKey: "GENERATED_COMMIT_MESSAGE_LATENCY",
		distributionValue: Math.round(duration),
		requestUrl: window.location.href
	});
}
function useGenerateCommitMessage(placeholderMessage, copilotGenerateCommitMessageAuthInfo, initialPath, completeFilePath, initialFileContent, currentFileContent, isNewFile, generatedMessages, regenerateCallCount) {
	const shouldUseFallback = copilotGenerateCommitMessageAuthInfo === void 0 || !copilotGenerateCommitMessageAuthInfo.copilotAccessAllowed || initialFileContent === void 0 || currentFileContent === void 0 || initialPath === void 0 || completeFilePath === void 0 || !initialFileContent && !currentFileContent;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const { data: generatedCommitMessage, isFetching } = useQuery({
		queryKey: [
			"generate-commit-message",
			currentFileContent,
			completeFilePath,
			regenerateCallCount
		],
		queryFn: async () => {
			const startTime = performance.now();
			const token = await new CopilotAuthTokenProvider(copilotGenerateCommitMessageAuthInfo.ssoOrganizations.map((org) => org.id)).getAuthToken();
			const references = isNewFile && initialFileContent === currentFileContent ? createDiffReferences("", currentFileContent, initialPath, completeFilePath) : createDiffReferences(initialFileContent, currentFileContent, initialPath, completeFilePath);
			let content = "";
			if (generatedMessages && generatedMessages.length > 0) content += dryMessagesPrompt(generatedMessages);
			const result = await makeCAPIRequest({
				authToken: token,
				basePath: copilotGenerateCommitMessageAuthInfo.apiUrl,
				body: {
					messages: [{
						role: "user",
						content,
						copilot_references: references
					}],
					temperature: .3,
					response_format: {
						type: "json_schema",
						json_schema: {
							description: "The schema to abide by when generating commit message output",
							name: "commit_message_response",
							strict: true,
							schema: {
								type: "object",
								properties: {
									title: {
										type: "string",
										description: "The commit message title/summary"
									},
									description: {
										type: "string",
										description: "The commit message description/body"
									}
								},
								required: ["title", "description"],
								additionalProperties: false
							}
						}
					}
				},
				integrationId: "commit-msg-gen",
				method: "POST",
				path: "/agents/github-commit-message-generation",
				streamingResponse: true
			});
			try {
				if (!result.ok) throw new Error("Failed to generate commit message");
				const reader = result.body?.getReader();
				if (!reader) throw new Error("No reader found in response body");
				const message = await handleStreamingMessage(new CopilotChatMessageStreamer(reader));
				const validatedMessage = validateAndExtractCommitMessage(message);
				sendErrorAndLatencyStats("GENERATED_COMMIT_MESSAGE_SUCCESS", startTime);
				const inputTokenCount = calculateInputTokenUsage(references);
				const outputTokenCount = calculateOutputTokenUsage(message);
				sendClickAnalyticsEvent({
					category: "copilot_generate_commit_message",
					action: "generate",
					input_token_count: inputTokenCount,
					output_token_count: outputTokenCount,
					total_token_count: inputTokenCount + outputTokenCount
				});
				if (validatedMessage) return validatedMessage;
				else return returnFallback(placeholderMessage);
			} catch {
				if (!EXPECTED_ERROR_STATUS_CODES.includes(result.status)) sendErrorAndLatencyStats("GENERATED_COMMIT_MESSAGE_ERROR", startTime);
				return returnFallback(placeholderMessage);
			}
		},
		enabled: !shouldUseFallback,
		meta: { action: "get-generated-commit-message" }
	});
	if (shouldUseFallback) return {
		generatedCommitMessage: returnFallback(placeholderMessage),
		isFetching: false
	};
	return {
		generatedCommitMessage,
		isFetching
	};
}
async function fetchCommitQuorumCheckJSON(url) {
	const response = await verifiedFetchJSON(url);
	if (response.ok) return (await response.json()).data.hasQuorum;
	else return { statusText: response.statusText };
}
/**
* Polls the given URL with backoff until the commit has quorum
* or until the max number of retries is reached
* This allows us to check if git has quorum before redirecting
* @param url - The URL to poll for commit availability
* @returns A promise that resolves when the commit has quorum, the max number of retries is reached, or an error occurs
*/
async function pollUntilCommitHasQuorum(url) {
	let hasQuorum = false;
	let retries = 0;
	try {
		while (hasQuorum === false && retries < 3) {
			const commitQuorumCheckResponse = await fetchCommitQuorumCheckJSON(`${url}?attempt_number=${retries + 1}`);
			if (typeof commitQuorumCheckResponse === "boolean") {
				hasQuorum = hasQuorum || commitQuorumCheckResponse;
				if (!hasQuorum) {
					retries++;
					await wait(retries * 1e3);
				}
			} else break;
		}
	} catch {}
}
function WebCommitDialog(props) {
	const { content, contentChanged, fileName, isDelete, isNewFile, oldPath, ownerName, placeholderMessage, refName, generateCommitMessageInfo, webCommitInfo, setDialogState, setSecretDetected, setSecretBypassMetadata } = props;
	const { authorEmails, canCommitStatus, commitOid, defaultEmail, defaultNewBranchName, forkedRepo, guidanceTask, pr, repoHeadEmpty, saveUrl } = webCommitInfo;
	const navigate = useNavigate$1();
	const trackWebCommitAcceptance = useTrackWebCommitAcceptance();
	const trackWebCommitRegenerated = useTrackWebCommitRegenerated();
	const repo = useCurrentRepository();
	const [generatedMessages, setGeneratedMessages] = React.useState([]);
	const [regenerateCallCount, setRegenerateCallCount] = React.useState(0);
	const { generatedCommitMessage, isFetching } = useGenerateCommitMessage(placeholderMessage, generateCommitMessageInfo?.copilotGenerateCommitMessageAuthInfo, generateCommitMessageInfo?.initialPath, generateCommitMessageInfo?.completeFilePath, generateCommitMessageInfo?.initialFileContent, content, isNewFile, generatedMessages, regenerateCallCount);
	const generateCommitMessageEnabled = generateCommitMessageInfo?.copilotGenerateCommitMessageAuthInfo?.copilotAccessAllowed;
	const generatingCommitMessage = generateCommitMessageEnabled && isFetching;
	const [message, setMessage] = React.useState(generatingCommitMessage ? "" : placeholderMessage);
	const [description, setDescription] = React.useState("");
	const [showingGeneratedCommitMessage, setShowingGeneratedCommitMessage] = React.useState(false);
	const [showingGeneratedCommitDescription, setShowingGeneratedCommitDescription] = React.useState(false);
	const [userCancelledCopilotCommitGeneration, setUserCancelledCopilotCommitGeneration] = React.useState(false);
	const [hasShownGeneratedCommitMessage, setHasShownGeneratedCommitMessage] = React.useState(false);
	useEffect(() => {
		if (generatedCommitMessage?.commitMessage && !isFetching && !userCancelledCopilotCommitGeneration) {
			setMessage(generatedCommitMessage.commitMessage);
			setShowingGeneratedCommitMessage(generatedCommitMessage.commitMessage !== placeholderMessage);
			if (!hasShownGeneratedCommitMessage) setHasShownGeneratedCommitMessage(generatedCommitMessage.commitMessage !== placeholderMessage);
			let uniqueGeneratedMessages = generatedMessages;
			if (!generatedMessages.includes(generatedCommitMessage.commitMessage)) {
				uniqueGeneratedMessages = [...generatedMessages, generatedCommitMessage.commitMessage];
				setGeneratedMessages(uniqueGeneratedMessages);
			}
			if (regenerateCallCount > 0) trackWebCommitRegenerated({
				version: "1",
				regenerateCallCount,
				uniquelyGeneratedMessagesCount: uniqueGeneratedMessages.length
			});
			if (generatedCommitMessage?.description !== void 0) {
				setDescription(generatedCommitMessage.description);
				if (generatedCommitMessage?.description) setShowingGeneratedCommitDescription(true);
			}
		}
	}, [
		generatedCommitMessage?.commitMessage,
		generatedCommitMessage?.description,
		isFetching,
		placeholderMessage,
		userCancelledCopilotCommitGeneration,
		hasShownGeneratedCommitMessage,
		generatedMessages,
		regenerateCallCount,
		trackWebCommitRegenerated
	]);
	const [isQuickPull, setIsQuickPull] = React.useState(canCommitStatus !== "allowed" || !!forkedRepo);
	const [prTargetBranch, setPRTargetBranch] = React.useState(defaultNewBranchName);
	const [authorEmail, setAuthorEmail] = React.useState(authorEmails.length ? defaultEmail : void 0);
	const [errorMessage, setErrorMessage] = React.useState("");
	const [errorDetails, setErrorDetails] = React.useState();
	const { refreshTree } = useFileTreeControlContext();
	const addQueuedBanner = useCodeViewAddQueuedBanner();
	const commitMessageInputRef = React.useRef(null);
	useEffect(() => {
		if (commitMessageInputRef.current) commitMessageInputRef.current.focus();
	}, []);
	const quickPullChoice = !forkedRepo && !repoHeadEmpty;
	useEffect(() => {
		if (props.dialogState === "closed" || props.dialogState === "saved") setGeneratedMessages([]);
	}, [props.dialogState]);
	const handleCopilotCommitGenerationInterruption = React.useCallback(() => {
		if (!userCancelledCopilotCommitGeneration) setUserCancelledCopilotCommitGeneration(true);
	}, [userCancelledCopilotCommitGeneration]);
	const handleCopilotRegenerateCommitMessage = React.useCallback(() => {
		if (!userCancelledCopilotCommitGeneration && !isFetching) {
			setMessage("");
			setShowingGeneratedCommitMessage(false);
			setDescription("");
			setShowingGeneratedCommitDescription(false);
			setRegenerateCallCount((prev) => prev + 1);
		}
	}, [userCancelledCopilotCommitGeneration, isFetching]);
	const showGeneratingCommitMessageLoading = generatingCommitMessage && !userCancelledCopilotCommitGeneration;
	const showGeneratingCommitMessageLoaded = generateCommitMessageEnabled && (showingGeneratedCommitMessage || showingGeneratedCommitDescription) && !isFetching;
	const onSave = async () => {
		setDialogState("saving");
		const quickPullBase = forkedRepo ? `${ownerName}:${refName}` : refName;
		const sharedData = {
			message,
			placeholder_message: placeholderMessage,
			description,
			author_email: authorEmail ?? void 0,
			"commit-choice": quickPullChoice ? isQuickPull ? "quick-pull" : "direct" : void 0,
			target_branch: quickPullChoice ? isQuickPull ? prTargetBranch : refName : void 0,
			quick_pull: isQuickPull ? quickPullBase : "",
			guidance_task: guidanceTask ?? "",
			commit: commitOid,
			same_repo: !forkedRepo && !repoHeadEmpty ? 1 : void 0,
			pr: pr ?? ""
		};
		let data;
		if (isDelete) data = {
			...sharedData,
			_method: "delete"
		};
		else data = {
			...sharedData,
			content_changed: contentChanged,
			filename: isNewFile ? fileName : oldPath,
			new_filename: fileName,
			value: content
		};
		const formData = new FormData();
		for (const [key, dataValue] of Object.entries(data)) if (dataValue !== void 0) formData.set(key, dataValue);
		try {
			const json = await (await verifiedFetch(saveUrl, {
				method: "post",
				body: formData,
				headers: { Accept: "application/json" }
			})).json();
			if (json.data.commitQuorumPollPath) await pollUntilCommitHasQuorum(json.data.commitQuorumPollPath);
			if (json.data.redirect) {
				trackWebCommitAcceptance({
					message: data.message,
					description: data.description,
					placeholderMessage,
					generatedCommitMessage,
					showingGeneratedCommitMessage,
					showingGeneratedCommitDescription,
					isNewFile,
					isDelete,
					contentChanged,
					oldPath,
					fileName,
					content,
					regenerateCallCount,
					version: "1"
				});
				const redirectUrl = json.data.redirect;
				const url = redirectUrl.startsWith(window.location.origin) ? redirectUrl.replace(window.location.origin, "") : redirectUrl;
				resetMemoizeFetchJSON();
				if (refreshTree?.current !== void 0) refreshTree.current = true;
				if (fileName) try {
					await loadFileTreePath({
						owner: repo.ownerLogin,
						repo: repo.name,
						branch: refName,
						path: fileName
					});
				} catch {}
				if (json.data.message) addQueuedBanner({
					message: json.data.message,
					variant: "default"
				});
				setDialogState("saved");
				setTimeout(() => {
					navigate(url);
				}, 50);
				return;
			} else if (json.data.error && json.data.secretBypassMetadata) {
				setSecretDetected?.(true);
				setSecretBypassMetadata?.(json.data.secretBypassMetadata);
				setDialogState("closed");
			} else if (json.data.error) {
				setDialogState("pending");
				setErrorMessage(json.data.error);
				if (json.data.error_details) setErrorDetails(json.data.error_details);
			} else {
				setErrorMessage("File could not be edited");
				setDialogState("pending");
			}
		} catch {
			setErrorMessage("File could not be edited");
			setDialogState("pending");
		}
	};
	return /* @__PURE__ */ jsx(WebCommitDialog$1, {
		onSave,
		message,
		setMessage,
		description,
		setDescription,
		isQuickPull,
		setIsQuickPull,
		prTargetBranch,
		setPRTargetBranch,
		setAuthorEmail,
		errorMessage,
		errorDetails,
		isFetching,
		showGeneratingCommitMessageLoading,
		showGeneratingCommitMessageLoaded,
		hasShownGeneratedCommitMessage,
		onCopilotCommitGenerationCancel: handleCopilotCommitGenerationInterruption,
		onRegenerateCommitMessageClick: handleCopilotRegenerateCommitMessage,
		...props
	});
}
WebCommitDialog.displayName = "WebCommitDialog";
export { WebCommitDialog as t };
