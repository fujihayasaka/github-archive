import { o as useId$1, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { c as Text$1, f as getAccessibleKeybindingHintString, i as ButtonComponent, l as VisuallyHidden, n as AriaStatus, p as useIsMacOS } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Et as FileDirectoryOpenFillIcon, F as ChevronDownIcon, Gi as useSlots, L as ChevronRightIcon, Ri as isSlot, Wi as useSafeTimeout, an as IconButton, n as ActionList, pi as Tooltip$1, wt as FileDirectoryFillIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as isResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as useControllableState } from "./server-useControllableState-vGARN752-BYRiGAOs.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import React, { useEffect } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
var classes$1 = {
	"TreeViewRootUlStyles": "prc-TreeView-TreeViewRootUlStyles-Mzrmj",
	"TreeViewItem": "prc-TreeView-TreeViewItem-Ter5f",
	"TreeViewItemContainer": "prc-TreeView-TreeViewItemContainer-z6qqQ",
	"TreeViewItemSkeleton": "prc-TreeView-TreeViewItemSkeleton-FGlnx",
	"TreeViewItemToggle": "prc-TreeView-TreeViewItemToggle-hq3Xq",
	"TreeViewItemToggleHover": "prc-TreeView-TreeViewItemToggleHover-H9tbt",
	"TreeViewItemToggleEnd": "prc-TreeView-TreeViewItemToggleEnd-nWt9I",
	"TreeViewItemContent": "prc-TreeView-TreeViewItemContent-RKsCI",
	"TreeViewItemContentText": "prc-TreeView-TreeViewItemContentText-FFaKp",
	"TreeViewItemVisual": "prc-TreeView-TreeViewItemVisual-naWzj",
	"TreeViewItemLeadingAction": "prc-TreeView-TreeViewItemLeadingAction-vmOIV",
	"TreeViewItemTrailingAction": "prc-TreeView-TreeViewItemTrailingAction-h9M5g",
	"TreeViewItemTrailingActionButton": "prc-TreeView-TreeViewItemTrailingActionButton-pCTdP",
	"TreeViewItemLevelLine": "prc-TreeView-TreeViewItemLevelLine-F-0-2",
	"TreeViewDirectoryIcon": "prc-TreeView-TreeViewDirectoryIcon-yP1oY",
	"TreeViewVisuallyHidden": "prc-TreeView-TreeViewVisuallyHidden-1N8xK",
	"TreeViewSkeletonItemContainerStyle": "prc-TreeView-TreeViewSkeletonItemContainerStyle-lKqwd",
	"TreeItemSkeletonTextStyles": "prc-TreeView-TreeItemSkeletonTextStyles-8VJ-g"
};
/**
* Returns the accessible name of an element
*/
function getAccessibleName(element) {
	var _document$getElementB, _document$getElementB2;
	const label = element.getAttribute("aria-label");
	const labelledby = element.getAttribute("aria-labelledby");
	if (label) return label;
	if (labelledby) return (_document$getElementB = (_document$getElementB2 = document.getElementById(labelledby)) === null || _document$getElementB2 === void 0 ? void 0 : _document$getElementB2.textContent) !== null && _document$getElementB !== void 0 ? _document$getElementB : "";
	return element.textContent;
}
/**
* Returns the nearest scrollable parent of the element or `null` if the element
* is not contained in a scrollable element.
*/
function getScrollContainer(element) {
	if (!element || element === document.body) return null;
	return isScrollable(element) ? element : getScrollContainer(element.parentElement);
}
/** Returns `true` if the element is scrollable */
function isScrollable(element) {
	return element.scrollHeight > element.clientHeight && !(window.getComputedStyle(element).overflowY.indexOf("hidden") !== -1);
}
function useRovingTabIndex(t0) {
	const $ = c(6);
	const { containerRef, mouseDownRef } = t0;
	let t1;
	if ($[0] !== containerRef || $[1] !== mouseDownRef) {
		t1 = () => {
			var _containerRef$current, _containerRef$current2, _containerRef$current3;
			if (mouseDownRef.current) return;
			const currentItem = (_containerRef$current = containerRef.current) === null || _containerRef$current === void 0 ? void 0 : _containerRef$current.querySelector("[aria-current]");
			const firstItem = (_containerRef$current2 = containerRef.current) === null || _containerRef$current2 === void 0 ? void 0 : _containerRef$current2.querySelector("[role=\"treeitem\"]");
			if (currentItem instanceof HTMLElement) return currentItem;
			if (document.activeElement instanceof HTMLElement && (_containerRef$current3 = containerRef.current) !== null && _containerRef$current3 !== void 0 && _containerRef$current3.contains(document.activeElement) && document.activeElement.getAttribute("role") === "treeitem") return document.activeElement;
			return firstItem instanceof HTMLElement ? firstItem : void 0;
		};
		$[0] = containerRef;
		$[1] = mouseDownRef;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== containerRef || $[4] !== t1) {
		t2 = {
			containerRef,
			bindKeys: FocusKeys.ArrowVertical | FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd | FocusKeys.Backspace | FocusKeys.PageUpDown,
			preventScroll: true,
			getNextFocusable: _temp$3,
			focusInStrategy: t1
		};
		$[3] = containerRef;
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	useFocusZone(t2);
}
function _temp$3(direction, from, event) {
	var _getNextFocusableElem;
	if (!(from instanceof HTMLElement)) return;
	try {
		if (from.closest("dialog:modal")) return;
	} catch {}
	return (_getNextFocusableElem = getNextFocusableElement(from, event)) !== null && _getNextFocusableElem !== void 0 ? _getNextFocusableElem : from;
}
function getNextFocusableElement(activeElement, event) {
	switch (`${getElementState(activeElement)} ${event.key}`) {
		case "open ArrowRight": return getFirstChildElement(activeElement);
		case "open ArrowLeft": return;
		case "closed ArrowRight": return;
		case "closed ArrowLeft": return getParentElement(activeElement);
		case "end ArrowRight": return;
		case "end ArrowLeft": return getParentElement(activeElement);
	}
	switch (event.key) {
		case "ArrowUp": return getVisibleElement(activeElement, "previous");
		case "ArrowDown": return getVisibleElement(activeElement, "next");
		case "Backspace": return getParentElement(activeElement);
		case "Home": return getFirstElement(activeElement);
		case "End": return getLastElement(activeElement);
		case "PageUp": return getPreviousPageElement(activeElement);
		case "PageDown": return getNextPageElement(activeElement);
	}
}
function getElementState(element) {
	if (element.getAttribute("role") !== "treeitem") throw new Error("Element is not a treeitem");
	switch (element.getAttribute("aria-expanded")) {
		case "true": return "open";
		case "false": return "closed";
		default: return "end";
	}
}
function getVisibleElement(element, direction) {
	const root = element.closest("[role=tree]");
	if (!root) return;
	const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, (node) => {
		if (!(node instanceof HTMLElement)) return NodeFilter.FILTER_SKIP;
		return node.getAttribute("role") === "treeitem" ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	});
	let current = walker.firstChild();
	while (current !== element) current = walker.nextNode();
	let next = direction === "next" ? walker.nextNode() : walker.previousNode();
	while (next instanceof HTMLElement && (_next$parentElement = next.parentElement) !== null && _next$parentElement !== void 0 && _next$parentElement.closest("[role=treeitem][aria-expanded=false]")) {
		var _next$parentElement;
		next = direction === "next" ? walker.nextNode() : walker.previousNode();
	}
	return next instanceof HTMLElement ? next : void 0;
}
function getFirstChildElement(element) {
	const firstChild = element.querySelector("[role=treeitem]");
	return firstChild instanceof HTMLElement ? firstChild : void 0;
}
function getParentElement(element) {
	const group = element.closest("[role=group]");
	const parent = group === null || group === void 0 ? void 0 : group.closest("[role=treeitem]");
	return parent instanceof HTMLElement ? parent : void 0;
}
function getFirstElement(element) {
	const root = element.closest("[role=tree]");
	const first = root === null || root === void 0 ? void 0 : root.querySelector("[role=treeitem]");
	return first instanceof HTMLElement ? first : void 0;
}
function getLastElement(element) {
	const root = element.closest("[role=tree]");
	if (!root) return;
	const items = Array.from(root.querySelectorAll("[role=treeitem]"));
	if (items.length === 0) return;
	let index = items.length - 1;
	let last = items[index];
	while (index > 0 && last instanceof HTMLElement && (_last$parentElement = last.parentElement) !== null && _last$parentElement !== void 0 && _last$parentElement.closest("[role=treeitem][aria-expanded=false]")) {
		var _last$parentElement;
		index -= 1;
		last = items[index];
	}
	return last instanceof HTMLElement ? last : void 0;
}
var defaultSize = { height: 32 };
/**
* Determine the page size for the given tree based on an item in the tree. We
* estimate this size by trying to see how many items will fit in the given
* tree. If the tree is within a scroll container, we will use the height of
* that container. Otherwise, we'll use the current window height
*/
function getPageSize(root, item) {
	var _item$getBoundingClie, _scrollContainer$clie;
	const scrollContainer = getScrollContainer(root);
	const { height: itemHeight } = (_item$getBoundingClie = item === null || item === void 0 ? void 0 : item.getBoundingClientRect()) !== null && _item$getBoundingClie !== void 0 ? _item$getBoundingClie : defaultSize;
	const availableHeight = (_scrollContainer$clie = scrollContainer === null || scrollContainer === void 0 ? void 0 : scrollContainer.clientHeight) !== null && _scrollContainer$clie !== void 0 ? _scrollContainer$clie : window.innerHeight;
	return Math.floor(availableHeight / itemHeight);
}
function getNextPageElement(element) {
	const root = element.closest("[role=\"tree\"]");
	if (!root) return;
	const items = Array.from(root.querySelectorAll("[role=\"treeitem\"]"));
	if (items.length === 0) return;
	const itemLabel = items[0].firstElementChild;
	const pageSize = getPageSize(root, itemLabel);
	const page = Math.floor(items.indexOf(element) / pageSize);
	const offset = items.indexOf(element) - pageSize * page;
	return items[Math.min(items.length - 1, (page + 1) * pageSize + offset)];
}
function getPreviousPageElement(element) {
	const root = element.closest("[role=\"tree\"]");
	if (!root) return;
	const items = Array.from(root.querySelectorAll("[role=\"treeitem\"]"));
	if (items.length === 0) return;
	const itemLabel = items[0].firstElementChild;
	const pageSize = getPageSize(root, itemLabel);
	const page = Math.floor(items.indexOf(element) / pageSize);
	const offset = items.indexOf(element) - pageSize * page;
	return items[Math.max(0, (page - 1) * pageSize + offset)];
}
/**
* A hook that caches tree items to avoid expensive querySelectorAll calls on every keypress.
* The cache is invalidated when the tree structure changes (via MutationObserver).
*
* PERFORMANCE: This is critical for INP because querySelectorAll('[role="treeitem"]')
* on large trees can take 10-50ms, which directly blocks user input response.
*
* Note: useRovingTabIndex also uses querySelectorAll for Home/End/PageUp/PageDown navigation,
* but those are infrequent single keypresses. Typeahead fires on every character typed,
* making it the priority optimization target.
*/
function useTreeItemCache(containerRef) {
	const $ = c(7);
	const cacheRef = React.useRef(null);
	let t0;
	let t1;
	if ($[0] !== containerRef) {
		t0 = () => {
			const container = containerRef.current;
			if (!container) return;
			const observer = new MutationObserver((mutations) => {
				if (mutations.some(_temp$2)) cacheRef.current = null;
			});
			observer.observe(container, {
				childList: true,
				subtree: true,
				attributes: true,
				attributeFilter: ["role"]
			});
			cacheRef.current = null;
			return () => observer.disconnect();
		};
		t1 = [containerRef];
		$[0] = containerRef;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	React.useEffect(t0, t1);
	let t2;
	if ($[3] !== containerRef) {
		t2 = () => {
			const container_0 = containerRef.current;
			if (!container_0) return [];
			if (cacheRef.current !== null) return cacheRef.current;
			cacheRef.current = Array.from(container_0.querySelectorAll("[role=\"treeitem\"]"));
			return cacheRef.current;
		};
		$[3] = containerRef;
		$[4] = t2;
	} else t2 = $[4];
	const getTreeItems = t2;
	let t3;
	if ($[5] !== getTreeItems) {
		t3 = { getTreeItems };
		$[5] = getTreeItems;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
function _temp$2(mutation) {
	return mutation.type === "childList" || mutation.type === "attributes" && mutation.attributeName === "role";
}
function useTypeahead(t0) {
	const $ = c(12);
	const { containerRef, onFocusChange } = t0;
	const searchValue = React.useRef("");
	const timeoutRef = React.useRef(0);
	const onFocusChangeRef = React.useRef(onFocusChange);
	const { safeSetTimeout, safeClearTimeout } = useSafeTimeout();
	const { getTreeItems } = useTreeItemCache(containerRef);
	let t1;
	let t2;
	if ($[0] !== onFocusChange) {
		t1 = () => {
			onFocusChangeRef.current = onFocusChange;
		};
		t2 = [onFocusChange];
		$[0] = onFocusChange;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	React.useEffect(t1, t2);
	let t3;
	if ($[3] !== containerRef || $[4] !== getTreeItems) {
		t3 = (searchValue_0) => {
			if (!searchValue_0) return;
			if (!containerRef.current) return;
			const elements = getTreeItems();
			let sortedElements = wrapArray(elements, elements.findIndex(_temp$1));
			if (searchValue_0.length === 1) sortedElements = sortedElements.slice(1);
			const nextElement = sortedElements.find((element_0) => {
				return getAccessibleName(element_0).toLowerCase().startsWith(searchValue_0.toLowerCase());
			});
			if (nextElement) onFocusChangeRef.current(nextElement);
		};
		$[3] = containerRef;
		$[4] = getTreeItems;
		$[5] = t3;
	} else t3 = $[5];
	const focusSearchValue = t3;
	let t4;
	let t5;
	if ($[6] !== containerRef || $[7] !== focusSearchValue || $[8] !== safeClearTimeout || $[9] !== safeSetTimeout) {
		t4 = () => {
			if (!containerRef.current) return;
			const container = containerRef.current;
			const onKeyDown = function onKeyDown(event) {
				if (!event.key || event.key.length > 1 || event.key === " ") return;
				if (event.ctrlKey || event.altKey || event.metaKey) return;
				searchValue.current = searchValue.current + event.key;
				focusSearchValue(searchValue.current);
				safeClearTimeout(timeoutRef.current);
				timeoutRef.current = safeSetTimeout(() => searchValue.current = "", 300);
				event.preventDefault();
				event.stopPropagation();
			};
			container.addEventListener("keydown", onKeyDown);
			return () => container.removeEventListener("keydown", onKeyDown);
		};
		t5 = [
			containerRef,
			focusSearchValue,
			safeClearTimeout,
			safeSetTimeout
		];
		$[6] = containerRef;
		$[7] = focusSearchValue;
		$[8] = safeClearTimeout;
		$[9] = safeSetTimeout;
		$[10] = t4;
		$[11] = t5;
	} else {
		t4 = $[10];
		t5 = $[11];
	}
	React.useEffect(t4, t5);
}
/**
* Wraps an array around itself at a given start index
*
* @example
* wrapArray(['a', 'b', 'c', 'd'], 2) // ['c', 'd', 'a', 'b']
*/
function _temp$1(element) {
	return element === document.activeElement;
}
function wrapArray(array, startIndex) {
	return array.map((_, index) => array[(startIndex + index) % array.length]);
}
var classes = { "SkeletonAvatar": "prc-SkeletonAvatar-SkeletonAvatar-IS5NT" };
function SkeletonAvatar(t0) {
	const $ = c(26);
	let className;
	let rest;
	let square;
	let style;
	let t1;
	if ($[0] !== t0) {
		({size: t1, square, className, style, ...rest} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = rest;
		$[3] = square;
		$[4] = style;
		$[5] = t1;
	} else {
		className = $[1];
		rest = $[2];
		square = $[3];
		style = $[4];
		t1 = $[5];
	}
	const size = t1 === void 0 ? 20 : t1;
	let t2;
	if ($[6] !== size) {
		t2 = isResponsiveValue(size);
		$[6] = size;
		$[7] = t2;
	} else t2 = $[7];
	const responsive = t2;
	let cssSizeVars;
	if ($[8] !== responsive || $[9] !== size) {
		cssSizeVars = {};
		if (responsive) {
			let t3;
			if ($[11] !== size) {
				t3 = Object.entries(size);
				$[11] = size;
				$[12] = t3;
			} else t3 = $[12];
			for (const [key, value] of t3) cssSizeVars[`--avatarSize-${key}`] = `${value}px`;
		} else cssSizeVars["--avatarSize-regular"] = `${size}px`;
		$[8] = responsive;
		$[9] = size;
		$[10] = cssSizeVars;
	} else cssSizeVars = $[10];
	let t3;
	if ($[13] !== className) {
		t3 = clsx(className, classes.SkeletonAvatar);
		$[13] = className;
		$[14] = t3;
	} else t3 = $[14];
	const t4 = responsive ? "" : void 0;
	const t5 = square ? "" : void 0;
	let t6;
	if ($[15] !== style) {
		t6 = style || {};
		$[15] = style;
		$[16] = t6;
	} else t6 = $[16];
	let t7;
	if ($[17] !== cssSizeVars || $[18] !== t6) {
		t7 = {
			...t6,
			...cssSizeVars
		};
		$[17] = cssSizeVars;
		$[18] = t6;
		$[19] = t7;
	} else t7 = $[19];
	let t8;
	if ($[20] !== rest || $[21] !== t3 || $[22] !== t4 || $[23] !== t5 || $[24] !== t7) {
		t8 = /* @__PURE__ */ jsx(SkeletonBox, {
			className: t3,
			...rest,
			"data-component": "SkeletonAvatar",
			"data-responsive": t4,
			"data-square": t5,
			style: t7
		});
		$[20] = rest;
		$[21] = t3;
		$[22] = t4;
		$[23] = t5;
		$[24] = t7;
		$[25] = t8;
	} else t8 = $[25];
	return t8;
}
var RootContext = /* @__PURE__ */ React.createContext({
	announceUpdate: () => {},
	expandedStateCache: { current: /* @__PURE__ */ new Map() },
	scrollElementIntoView: () => {}
});
var ItemContext = /* @__PURE__ */ React.createContext({
	itemId: "",
	level: 1,
	isSubTreeEmpty: false,
	setIsSubTreeEmpty: () => {},
	isExpanded: false,
	setIsExpanded: () => {},
	leadingVisualId: "",
	trailingVisualId: "",
	trailingActionId: ""
});
var TOGGLE_ICON_SIZE = 12;
var Root = (t0) => {
	const $ = c(26);
	const { "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, children, flat, truncate: t1, className, style } = t0;
	const truncate = t1 === void 0 ? true : t1;
	const containerRef = React.useRef(null);
	const mouseDownRef = React.useRef(false);
	const [ariaLiveMessage, setAriaLiveMessage] = React.useState("");
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (message) => {
			setAriaLiveMessage(message);
		};
		$[0] = t2;
	} else t2 = $[0];
	const announceUpdate = t2;
	let t3;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			mouseDownRef.current = true;
		};
		$[1] = t3;
	} else t3 = $[1];
	const onMouseDown = t3;
	let t4;
	let t5;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => {
			const onMouseUp = function onMouseUp() {
				mouseDownRef.current = false;
			};
			document.addEventListener("mouseup", onMouseUp);
			return () => {
				document.removeEventListener("mouseup", onMouseUp);
			};
		};
		t5 = [];
		$[2] = t4;
		$[3] = t5;
	} else {
		t4 = $[2];
		t5 = $[3];
	}
	useEffect(t4, t5);
	let t6;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = {
			containerRef,
			mouseDownRef
		};
		$[4] = t6;
	} else t6 = $[4];
	useRovingTabIndex(t6);
	let t7;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = {
			containerRef,
			onFocusChange: _temp
		};
		$[5] = t7;
	} else t7 = $[5];
	useTypeahead(t7);
	const pendingScrollRef = React.useRef(null);
	let t8;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = (element_0) => {
			if (!element_0) return;
			if (pendingScrollRef.current !== null) cancelAnimationFrame(pendingScrollRef.current);
			pendingScrollRef.current = requestAnimationFrame(() => {
				pendingScrollRef.current = null;
				if (!element_0.isConnected) return;
				element_0.scrollIntoView({
					block: "nearest",
					inline: "nearest"
				});
			});
		};
		$[6] = t8;
	} else t8 = $[6];
	const scrollElementIntoView = t8;
	let t10;
	let t9;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = () => () => {
			if (pendingScrollRef.current !== null) cancelAnimationFrame(pendingScrollRef.current);
		};
		t10 = [];
		$[7] = t10;
		$[8] = t9;
	} else {
		t10 = $[7];
		t9 = $[8];
	}
	useEffect(t9, t10);
	const expandedStateCache = React.useRef(null);
	if (expandedStateCache.current === null) {
		let t11;
		if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
			t11 = /* @__PURE__ */ new Map();
			$[9] = t11;
		} else t11 = $[9];
		expandedStateCache.current = t11;
	}
	let t11;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t11 = {
			announceUpdate,
			expandedStateCache,
			scrollElementIntoView
		};
		$[10] = t11;
	} else t11 = $[10];
	let t12;
	if ($[11] !== ariaLiveMessage) {
		t12 = /* @__PURE__ */ jsx(VisuallyHidden, { children: /* @__PURE__ */ jsx(AriaStatus, {
			announceOnShow: true,
			children: ariaLiveMessage
		}) });
		$[11] = ariaLiveMessage;
		$[12] = t12;
	} else t12 = $[12];
	const t13 = truncate || false;
	let t14;
	if ($[13] !== className) {
		t14 = clsx(className, classes$1.TreeViewRootUlStyles);
		$[13] = className;
		$[14] = t14;
	} else t14 = $[14];
	let t15;
	if ($[15] !== ariaLabel || $[16] !== ariaLabelledby || $[17] !== children || $[18] !== flat || $[19] !== style || $[20] !== t13 || $[21] !== t14) {
		t15 = /* @__PURE__ */ jsx("ul", {
			ref: containerRef,
			role: "tree",
			"aria-label": ariaLabel,
			"aria-labelledby": ariaLabelledby,
			"data-omit-spacer": flat,
			"data-truncate-text": t13,
			onMouseDown,
			className: t14,
			style,
			children
		});
		$[15] = ariaLabel;
		$[16] = ariaLabelledby;
		$[17] = children;
		$[18] = flat;
		$[19] = style;
		$[20] = t13;
		$[21] = t14;
		$[22] = t15;
	} else t15 = $[22];
	let t16;
	if ($[23] !== t12 || $[24] !== t15) {
		t16 = /* @__PURE__ */ jsx(RootContext.Provider, {
			value: t11,
			children: /* @__PURE__ */ jsxs(Fragment$1, { children: [t12, t15] })
		});
		$[23] = t12;
		$[24] = t15;
		$[25] = t16;
	} else t16 = $[25];
	return t16;
};
Root.displayName = "TreeView";
var Item = /* @__PURE__ */ React.forwardRef(({ id: itemId, containIntrinsicSize, current: isCurrentItem = false, defaultExpanded, expanded, onExpandedChange, onSelect, children, className, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, secondaryActions }, ref) => {
	const [slots, rest] = useSlots(children, {
		leadingAction: LeadingAction,
		leadingVisual: LeadingVisual,
		trailingVisual: TrailingVisual
	});
	const { expandedStateCache, scrollElementIntoView } = React.useContext(RootContext);
	const labelId = useId$1();
	const leadingVisualId = useId$1();
	const trailingVisualId = useId$1();
	const trailingActionId = useId$1();
	const [isExpanded, setIsExpanded] = useControllableState({
		name: itemId,
		defaultValue: () => {
			var _ref, _expandedStateCache$c, _expandedStateCache$c2;
			return (_ref = (_expandedStateCache$c = (_expandedStateCache$c2 = expandedStateCache.current) === null || _expandedStateCache$c2 === void 0 ? void 0 : _expandedStateCache$c2.get(itemId)) !== null && _expandedStateCache$c !== void 0 ? _expandedStateCache$c : defaultExpanded) !== null && _ref !== void 0 ? _ref : isCurrentItem;
		},
		value: expanded === null ? false : expanded,
		onChange: onExpandedChange
	});
	const { level } = React.useContext(ItemContext);
	const { hasSubTree, subTree, childrenWithoutSubTree } = useSubTree(rest);
	const [isSubTreeEmpty, setIsSubTreeEmpty] = React.useState(!hasSubTree);
	const [actionCommandPressed, setActionCommandPressed] = React.useState(false);
	const [isFocused, setIsFocused] = React.useState(false);
	const isMacOS = useIsMacOS();
	const setIsExpandedWithCache = React.useCallback((newIsExpanded) => {
		var _expandedStateCache$c3;
		setIsExpanded(newIsExpanded);
		(_expandedStateCache$c3 = expandedStateCache.current) === null || _expandedStateCache$c3 === void 0 || _expandedStateCache$c3.set(itemId, newIsExpanded);
	}, [
		itemId,
		setIsExpanded,
		expandedStateCache
	]);
	const toggle = React.useCallback((event) => {
		setIsExpandedWithCache(!isExpanded);
		event === null || event === void 0 || event.stopPropagation();
	}, [isExpanded, setIsExpandedWithCache]);
	const activateActionsDialog = React.useCallback(() => {
		if (!secondaryActions) return;
		if (secondaryActions.length > 1) setActionCommandPressed(true);
		else {
			const action = secondaryActions[0].onClick;
			action();
		}
	}, [secondaryActions]);
	const handleKeyDown = React.useCallback((event_0) => {
		switch (event_0.key) {
			case "Enter":
			case " ":
				if (onSelect) onSelect(event_0);
				else toggle(event_0);
				event_0.stopPropagation();
				break;
			case "ArrowRight":
				if (event_0.altKey || event_0.metaKey) return;
				event_0.preventDefault();
				event_0.stopPropagation();
				setIsExpandedWithCache(true);
				break;
			case "ArrowLeft":
				if (event_0.altKey || event_0.metaKey) return;
				event_0.preventDefault();
				event_0.stopPropagation();
				setIsExpandedWithCache(false);
				break;
			case "U":
			case "u":
				if (!(event_0.shiftKey && (event_0.metaKey || event_0.ctrlKey))) return;
				activateActionsDialog();
				break;
		}
	}, [
		onSelect,
		setIsExpandedWithCache,
		toggle,
		activateActionsDialog
	]);
	const ariaDescribedByIds = [slots.leadingVisual ? leadingVisualId : null, slots.trailingVisual ? trailingVisualId : null].filter(Boolean);
	const trailingActionShortcutText = `Press (${getAccessibleKeybindingHintString(`Shift+${isMacOS ? "Meta" : "Control"}+U`, isMacOS)}) for more actions.`;
	return /* @__PURE__ */ jsx(ItemContext.Provider, {
		value: {
			itemId,
			level: level + 1,
			isSubTreeEmpty,
			setIsSubTreeEmpty,
			isExpanded,
			setIsExpanded: setIsExpandedWithCache,
			leadingVisualId,
			trailingVisualId,
			trailingActionId
		},
		children: /* @__PURE__ */ jsxs("li", {
			className: clsx("PRIVATE_TreeView-item", className, classes$1.TreeViewItem),
			ref,
			tabIndex: 0,
			id: itemId,
			role: "treeitem",
			"aria-label": secondaryActions ? ariaLabel ? `${ariaLabel}. ${trailingActionShortcutText}` : void 0 : ariaLabel,
			"aria-labelledby": ariaLabel ? void 0 : `${ariaLabelledby || labelId} ${secondaryActions ? trailingActionId : ""}`.trim(),
			"aria-describedby": ariaDescribedByIds.length ? ariaDescribedByIds.join(" ") : void 0,
			"aria-level": level,
			"aria-expanded": isSubTreeEmpty && (!isExpanded || !hasSubTree) || expanded === null ? void 0 : isExpanded,
			"aria-current": isCurrentItem ? "true" : void 0,
			"aria-selected": isFocused ? "true" : "false",
			"data-has-leading-action": slots.leadingAction ? true : void 0,
			onKeyDown: handleKeyDown,
			onFocus: (event_1) => {
				scrollElementIntoView(event_1.currentTarget.firstElementChild);
				setIsFocused(true);
				event_1.stopPropagation();
			},
			onBlur: () => setIsFocused(false),
			onClick: (event_2) => {
				if (onSelect) onSelect(event_2);
				else toggle(event_2);
				event_2.stopPropagation();
			},
			onAuxClick: (event_3) => {
				if (onSelect && event_3.button === 1) onSelect(event_3);
				event_3.stopPropagation();
			},
			children: [/* @__PURE__ */ jsxs("div", {
				className: clsx("PRIVATE_TreeView-item-container", classes$1.TreeViewItemContainer),
				style: {
					"--level": level,
					contentVisibility: containIntrinsicSize ? "auto" : void 0,
					containIntrinsicSize
				},
				children: [
					/* @__PURE__ */ jsx("div", {
						style: {
							gridArea: "spacer",
							display: "flex"
						},
						children: /* @__PURE__ */ jsx(LevelIndicatorLines, { level })
					}),
					slots.leadingAction,
					hasSubTree ? /* @__PURE__ */ jsx("div", {
						className: clsx("PRIVATE_TreeView-item-toggle", onSelect && "PRIVATE_TreeView-item-toggle--hover", level === 1 && "PRIVATE_TreeView-item-toggle--end", classes$1.TreeViewItemToggle, classes$1.TreeViewItemToggleHover, classes$1.TreeViewItemToggleEnd),
						onClick: (event_4) => {
							if (onSelect) toggle(event_4);
						},
						children: isExpanded ? /* @__PURE__ */ jsx(ChevronDownIcon, { size: TOGGLE_ICON_SIZE }) : /* @__PURE__ */ jsx(ChevronRightIcon, { size: TOGGLE_ICON_SIZE })
					}) : null,
					/* @__PURE__ */ jsxs("div", {
						id: labelId,
						className: clsx("PRIVATE_TreeView-item-content", classes$1.TreeViewItemContent),
						children: [
							slots.leadingVisual,
							/* @__PURE__ */ jsx("span", {
								className: clsx("PRIVATE_TreeView-item-content-text", classes$1.TreeViewItemContentText),
								children: childrenWithoutSubTree
							}),
							slots.trailingVisual
						]
					}),
					secondaryActions ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(TrailingAction, {
						items: secondaryActions,
						shortcutText: trailingActionShortcutText
					}), actionCommandPressed ? /* @__PURE__ */ jsx(ActionDialog, {
						items: secondaryActions,
						onClose: () => setActionCommandPressed(false)
					}) : null] }) : null
				]
			}), subTree]
		})
	});
});
/** Lines to indicate the depth of an item in a TreeView */
var LevelIndicatorLines = (t0) => {
	const $ = c(3);
	const { level } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			width: "100%",
			display: "flex"
		};
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== level) {
		t2 = /* @__PURE__ */ jsx("div", {
			style: t1,
			children: Array.from({ length: level - 1 }).map(_temp2)
		});
		$[1] = level;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
};
Item.displayName = "TreeView.Item";
var SubTree = (t0) => {
	const $ = c(29);
	const { count, state, children, "aria-label": ariaLabel } = t0;
	const { announceUpdate } = React.useContext(RootContext);
	const { itemId, isExpanded, isSubTreeEmpty, setIsSubTreeEmpty } = React.useContext(ItemContext);
	const loadingItemRef = React.useRef(null);
	const ref = React.useRef(null);
	const [loadingFocused, setLoadingFocused] = React.useState(false);
	const [subTreeLabel, setSubTreeLabel] = React.useState("");
	const previousState = usePreviousValue(state);
	const { safeSetTimeout } = useSafeTimeout();
	let t1;
	let t2;
	if ($[0] !== children || $[1] !== isSubTreeEmpty || $[2] !== setIsSubTreeEmpty || $[3] !== state) {
		t1 = () => {
			if (state === void 0 || state === "done") {
				if (!isSubTreeEmpty && !children) setIsSubTreeEmpty(true);
				else if (isSubTreeEmpty && children) setIsSubTreeEmpty(false);
			}
		};
		t2 = [
			state,
			isSubTreeEmpty,
			setIsSubTreeEmpty,
			children
		];
		$[0] = children;
		$[1] = isSubTreeEmpty;
		$[2] = setIsSubTreeEmpty;
		$[3] = state;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	React.useEffect(t1, t2);
	let t3;
	let t4;
	if ($[6] !== announceUpdate || $[7] !== itemId || $[8] !== loadingFocused || $[9] !== previousState || $[10] !== safeSetTimeout || $[11] !== state) {
		t3 = () => {
			const parentElement = document.getElementById(itemId);
			if (!parentElement) return;
			setSubTreeLabel(getAccessibleName(parentElement));
			if (previousState === "loading" && state === "done") {
				var _ref$current;
				const parentName = getAccessibleName(parentElement);
				if ((_ref$current = ref.current) !== null && _ref$current !== void 0 && _ref$current.childElementCount) announceUpdate(`${parentName} content loaded`);
				else announceUpdate(`${parentName} is empty`);
				if (loadingFocused) {
					const firstChild = getFirstChildElement(parentElement);
					if (firstChild) safeSetTimeout(() => {
						firstChild.focus();
					});
					else safeSetTimeout(() => {
						parentElement.focus();
					});
					setLoadingFocused(false);
				}
			} else if (state === "loading") announceUpdate(`${getAccessibleName(parentElement)} content loading`);
		};
		t4 = [
			loadingFocused,
			previousState,
			state,
			itemId,
			announceUpdate,
			ref,
			safeSetTimeout
		];
		$[6] = announceUpdate;
		$[7] = itemId;
		$[8] = loadingFocused;
		$[9] = previousState;
		$[10] = safeSetTimeout;
		$[11] = state;
		$[12] = t3;
		$[13] = t4;
	} else {
		t3 = $[12];
		t4 = $[13];
	}
	React.useEffect(t3, t4);
	let t5;
	if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = () => {
			const handleFocus = function handleFocus() {
				setLoadingFocused(true);
			};
			const handleBlur = function handleBlur(event) {
				if (!event.relatedTarget) return;
				setLoadingFocused(false);
			};
			const loadingElement = loadingItemRef.current;
			if (!loadingElement) return;
			loadingElement.addEventListener("focus", handleFocus);
			loadingElement.addEventListener("blur", handleBlur);
			return () => {
				loadingElement.removeEventListener("focus", handleFocus);
				loadingElement.removeEventListener("blur", handleBlur);
			};
		};
		$[14] = t5;
	} else t5 = $[14];
	let t6;
	if ($[15] !== state) {
		t6 = [loadingItemRef, state];
		$[15] = state;
		$[16] = t6;
	} else t6 = $[16];
	React.useEffect(t5, t6);
	if (!isExpanded) return null;
	let t7;
	if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = {
			listStyle: "none",
			padding: 0,
			margin: 0
		};
		$[17] = t7;
	} else t7 = $[17];
	const t8 = ariaLabel || subTreeLabel;
	let t9;
	if ($[18] !== children || $[19] !== count || $[20] !== state) {
		t9 = state === "loading" ? /* @__PURE__ */ jsx(LoadingItem, {
			ref: loadingItemRef,
			count
		}) : children;
		$[18] = children;
		$[19] = count;
		$[20] = state;
		$[21] = t9;
	} else t9 = $[21];
	let t10;
	if ($[22] !== isSubTreeEmpty || $[23] !== state) {
		t10 = isSubTreeEmpty && state !== "loading" ? /* @__PURE__ */ jsx(EmptyItem, {}) : null;
		$[22] = isSubTreeEmpty;
		$[23] = state;
		$[24] = t10;
	} else t10 = $[24];
	let t11;
	if ($[25] !== t10 || $[26] !== t8 || $[27] !== t9) {
		t11 = /* @__PURE__ */ jsxs("ul", {
			role: "group",
			style: t7,
			ref,
			"aria-label": t8,
			children: [t9, t10]
		});
		$[25] = t10;
		$[26] = t8;
		$[27] = t9;
		$[28] = t11;
	} else t11 = $[28];
	return t11;
};
SubTree.displayName = "TreeView.SubTree";
SubTree.__SLOT__ = Symbol("TreeView.SubTree");
function usePreviousValue(value) {
	const ref = React.useRef(value);
	React.useEffect(() => {
		ref.current = value;
	}, [value]);
	return ref.current;
}
var SkeletonItem = () => {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ jsxs("span", {
			className: clsx(classes$1.TreeViewSkeletonItemContainerStyle, classes$1.TreeViewItemSkeleton, "PRIVATE_TreeView-item-skeleton"),
			children: [/* @__PURE__ */ jsx(SkeletonAvatar, {
				size: 16,
				square: true
			}), /* @__PURE__ */ jsx(SkeletonText, { className: classes$1.TreeItemSkeletonTextStyles })]
		});
		$[0] = t0;
	} else t0 = $[0];
	return t0;
};
var LoadingItem = /* @__PURE__ */ React.forwardRef((t0, ref) => {
	const $ = c(15);
	const { count } = t0;
	const itemId = useId$1();
	if (count) {
		let t1;
		if ($[0] !== count) {
			t1 = Array.from({ length: count }).map(_temp3);
			$[0] = count;
			$[1] = t1;
		} else t1 = $[1];
		let t2;
		if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = clsx("PRIVATE_VisuallyHidden", classes$1.TreeViewVisuallyHidden);
			$[2] = t2;
		} else t2 = $[2];
		let t3;
		if ($[3] !== count) {
			t3 = /* @__PURE__ */ jsxs("div", {
				className: t2,
				children: [
					"Loading ",
					count,
					" items"
				]
			});
			$[3] = count;
			$[4] = t3;
		} else t3 = $[4];
		let t4;
		if ($[5] !== itemId || $[6] !== ref || $[7] !== t1 || $[8] !== t3) {
			t4 = /* @__PURE__ */ jsxs(Item, {
				id: itemId,
				ref,
				children: [t1, t3]
			});
			$[5] = itemId;
			$[6] = ref;
			$[7] = t1;
			$[8] = t3;
			$[9] = t4;
		} else t4 = $[9];
		return t4;
	}
	let t1;
	let t2;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ jsx(LeadingVisual, { children: /* @__PURE__ */ jsx(Spinner, { size: "small" }) });
		t2 = /* @__PURE__ */ jsx(Text$1, {
			className: "fgColor-muted",
			children: "Loading..."
		});
		$[10] = t1;
		$[11] = t2;
	} else {
		t1 = $[10];
		t2 = $[11];
	}
	let t3;
	if ($[12] !== itemId || $[13] !== ref) {
		t3 = /* @__PURE__ */ jsxs(Item, {
			id: itemId,
			ref,
			children: [t1, t2]
		});
		$[12] = itemId;
		$[13] = ref;
		$[14] = t3;
	} else t3 = $[14];
	return t3;
});
var EmptyItem = /* @__PURE__ */ React.forwardRef((props, ref) => {
	const $ = c(4);
	const t0 = useId$1();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ jsx(Text$1, {
			className: "fgColor-muted",
			children: "No items found"
		});
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== ref || $[2] !== t0) {
		t2 = /* @__PURE__ */ jsx(Item, {
			expanded: null,
			id: t0,
			ref,
			children: t1
		});
		$[1] = ref;
		$[2] = t0;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
});
function useSubTree(children) {
	const $ = c(8);
	let t0;
	if ($[0] !== children) {
		t0 = React.Children.toArray(children).find(_temp4);
		$[0] = children;
		$[1] = t0;
	} else t0 = $[1];
	const subTree = t0;
	let t1;
	if ($[2] !== children) {
		t1 = React.Children.toArray(children).filter(_temp5);
		$[2] = children;
		$[3] = t1;
	} else t1 = $[3];
	const childrenWithoutSubTree = t1;
	const t2 = Boolean(subTree);
	let t3;
	if ($[4] !== childrenWithoutSubTree || $[5] !== subTree || $[6] !== t2) {
		t3 = {
			subTree,
			childrenWithoutSubTree,
			hasSubTree: t2
		};
		$[4] = childrenWithoutSubTree;
		$[5] = subTree;
		$[6] = t2;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
function _temp5(child_0) {
	return !(/* @__PURE__ */ React.isValidElement(child_0) && (child_0.type === SubTree || isSlot(child_0, SubTree)));
}
function _temp4(child) {
	return /* @__PURE__ */ React.isValidElement(child) && (child.type === SubTree || isSlot(child, SubTree));
}
var LeadingVisual = (props) => {
	const $ = c(13);
	const { isExpanded, leadingVisualId } = React.useContext(ItemContext);
	let t0;
	if ($[0] !== isExpanded || $[1] !== props.children) {
		t0 = typeof props.children === "function" ? props.children({ isExpanded }) : props.children;
		$[0] = isExpanded;
		$[1] = props.children;
		$[2] = t0;
	} else t0 = $[2];
	const children = t0;
	let t1;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("PRIVATE_VisuallyHidden", classes$1.TreeViewVisuallyHidden);
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== leadingVisualId || $[5] !== props.label) {
		t2 = /* @__PURE__ */ jsx("div", {
			className: t1,
			"aria-hidden": true,
			id: leadingVisualId,
			children: props.label
		});
		$[4] = leadingVisualId;
		$[5] = props.label;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = clsx("PRIVATE_TreeView-item-visual", classes$1.TreeViewItemVisual);
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== children) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t3,
			"aria-hidden": true,
			children
		});
		$[8] = children;
		$[9] = t4;
	} else t4 = $[9];
	let t5;
	if ($[10] !== t2 || $[11] !== t4) {
		t5 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t2, t4] });
		$[10] = t2;
		$[11] = t4;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
};
LeadingVisual.displayName = "TreeView.LeadingVisual";
var TrailingVisual = (props) => {
	const $ = c(13);
	const { isExpanded, trailingVisualId } = React.useContext(ItemContext);
	let t0;
	if ($[0] !== isExpanded || $[1] !== props.children) {
		t0 = typeof props.children === "function" ? props.children({ isExpanded }) : props.children;
		$[0] = isExpanded;
		$[1] = props.children;
		$[2] = t0;
	} else t0 = $[2];
	const children = t0;
	let t1;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("PRIVATE_VisuallyHidden", classes$1.TreeViewVisuallyHidden);
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== props.label || $[5] !== trailingVisualId) {
		t2 = /* @__PURE__ */ jsx("div", {
			className: t1,
			"aria-hidden": true,
			id: trailingVisualId,
			children: props.label
		});
		$[4] = props.label;
		$[5] = trailingVisualId;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = clsx("PRIVATE_TreeView-item-visual", classes$1.TreeViewItemVisual);
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== children) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t3,
			"aria-hidden": true,
			children
		});
		$[8] = children;
		$[9] = t4;
	} else t4 = $[9];
	let t5;
	if ($[10] !== t2 || $[11] !== t4) {
		t5 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t2, t4] });
		$[10] = t2;
		$[11] = t4;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
};
TrailingVisual.displayName = "TreeView.TrailingVisual";
var LeadingAction = (props) => {
	const $ = c(12);
	const { isExpanded } = React.useContext(ItemContext);
	let t0;
	if ($[0] !== isExpanded || $[1] !== props.children) {
		t0 = typeof props.children === "function" ? props.children({ isExpanded }) : props.children;
		$[0] = isExpanded;
		$[1] = props.children;
		$[2] = t0;
	} else t0 = $[2];
	const children = t0;
	let t1;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("PRIVATE_VisuallyHidden", classes$1.TreeViewVisuallyHidden);
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== props.label) {
		t2 = /* @__PURE__ */ jsx("div", {
			className: t1,
			"aria-hidden": true,
			children: props.label
		});
		$[4] = props.label;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = clsx("PRIVATE_TreeView-item-leading-action", classes$1.TreeViewItemLeadingAction);
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== children) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t3,
			"aria-hidden": true,
			children
		});
		$[7] = children;
		$[8] = t4;
	} else t4 = $[8];
	let t5;
	if ($[9] !== t2 || $[10] !== t4) {
		t5 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t2, t4] });
		$[9] = t2;
		$[10] = t4;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
};
LeadingAction.displayName = "TreeView.LeadingAction";
var TrailingAction = (props) => {
	const $ = c(14);
	const { trailingActionId, itemId } = React.useContext(ItemContext);
	const { items, shortcutText } = props;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = clsx("PRIVATE_VisuallyHidden", classes$1.TreeViewVisuallyHidden);
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== shortcutText || $[2] !== trailingActionId) {
		t1 = /* @__PURE__ */ jsxs("div", {
			id: trailingActionId,
			className: t0,
			children: ["- ", shortcutText]
		});
		$[1] = shortcutText;
		$[2] = trailingActionId;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== itemId || $[5] !== items) {
		let t3;
		if ($[7] !== itemId) {
			t3 = (t4, index) => {
				const { label, onClick, icon, count, className } = t4;
				if (count) return /* @__PURE__ */ jsx(Tooltip$1, {
					text: label,
					children: /* @__PURE__ */ jsx(ButtonComponent, {
						"aria-label": label,
						leadingVisual: icon,
						variant: "invisible",
						className: clsx(className, classes$1.TreeViewItemTrailingActionButton),
						onClick,
						onKeyDown: () => {
							const parentElement = document.getElementById(itemId);
							parentElement === null || parentElement === void 0 || parentElement.focus();
						},
						tabIndex: -1,
						"aria-hidden": true,
						count
					})
				}, index);
				return /* @__PURE__ */ jsx(IconButton, {
					icon,
					variant: "invisible",
					"aria-label": label,
					className: clsx(className, classes$1.TreeViewItemTrailingActionButton),
					onClick,
					tabIndex: -1,
					"aria-hidden": true,
					onKeyDown: () => {
						const parentElement_0 = document.getElementById(itemId);
						parentElement_0 === null || parentElement_0 === void 0 || parentElement_0.focus();
					}
				}, index);
			};
			$[7] = itemId;
			$[8] = t3;
		} else t3 = $[8];
		t2 = items.map(t3);
		$[4] = itemId;
		$[5] = items;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[9] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			className: classes$1.TreeViewItemTrailingAction,
			"aria-hidden": true,
			onClick: _temp6,
			onKeyDown: _temp7,
			children: t2
		});
		$[9] = t2;
		$[10] = t3;
	} else t3 = $[10];
	let t4;
	if ($[11] !== t1 || $[12] !== t3) {
		t4 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t1, t3] });
		$[11] = t1;
		$[12] = t3;
		$[13] = t4;
	} else t4 = $[13];
	return t4;
};
TrailingAction.displayName = "TreeView.TrailingAction";
var ActionDialog = (t0) => {
	const $ = c(10);
	const { items, onClose } = t0;
	const { itemId } = React.useContext(ItemContext);
	let t1;
	if ($[0] !== itemId || $[1] !== onClose) {
		t1 = () => {
			if (onClose) onClose();
			setTimeout(() => {
				const parentElement = document.getElementById(itemId);
				parentElement === null || parentElement === void 0 || parentElement.focus();
			});
		};
		$[0] = itemId;
		$[1] = onClose;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== items) {
		t2 = items.map(_temp0);
		$[3] = items;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== t2) {
		t3 = /* @__PURE__ */ jsx(ActionList, { children: t2 });
		$[5] = t2;
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== t1 || $[8] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			onClick: _temp8,
			onKeyDown: _temp9,
			children: /* @__PURE__ */ jsx(Dialog, {
				title: "Supplemental actions",
				onClose: t1,
				children: t3
			})
		});
		$[7] = t1;
		$[8] = t3;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
};
ActionDialog.displayName = "TreeView.ActionDialog";
var DirectoryIcon = () => {
	const $ = c(3);
	const { isExpanded } = React.useContext(ItemContext);
	const Icon = isExpanded ? FileDirectoryOpenFillIcon : FileDirectoryFillIcon;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = clsx("PRIVATE_TreeView-directory-icon", classes$1.TreeViewDirectoryIcon);
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== Icon) {
		t1 = /* @__PURE__ */ jsx("div", {
			className: t0,
			children: /* @__PURE__ */ jsx(Icon, {})
		});
		$[1] = Icon;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
var ErrorDialog = (t0) => {
	const $ = c(9);
	const { title: t1, children, onRetry, onDismiss } = t0;
	const title = t1 === void 0 ? "Error" : t1;
	const { itemId, setIsExpanded } = React.useContext(ItemContext);
	let t2;
	if ($[0] !== itemId || $[1] !== onDismiss || $[2] !== onRetry || $[3] !== setIsExpanded) {
		t2 = (gesture) => {
			setTimeout(() => {
				const parentElement = document.getElementById(itemId);
				parentElement === null || parentElement === void 0 || parentElement.focus();
			});
			if (gesture === "confirm") onRetry === null || onRetry === void 0 || onRetry();
			else {
				setIsExpanded(false);
				onDismiss === null || onDismiss === void 0 || onDismiss();
			}
		};
		$[0] = itemId;
		$[1] = onDismiss;
		$[2] = onRetry;
		$[3] = setIsExpanded;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== children || $[6] !== t2 || $[7] !== title) {
		t3 = /* @__PURE__ */ jsx("div", {
			onKeyDown: _temp1,
			children: /* @__PURE__ */ jsx(ConfirmationDialog, {
				title,
				onClose: t2,
				confirmButtonContent: "Retry",
				cancelButtonContent: "Dismiss",
				children
			})
		});
		$[5] = children;
		$[6] = t2;
		$[7] = title;
		$[8] = t3;
	} else t3 = $[8];
	return t3;
};
ErrorDialog.displayName = "TreeView.ErrorDialog";
var TreeView = Object.assign(Root, {
	Item,
	SubTree,
	LeadingAction,
	LeadingVisual,
	TrailingVisual,
	DirectoryIcon,
	ErrorDialog
});
function _temp(element) {
	if (element instanceof HTMLElement) element.focus();
}
function _temp2(_, index) {
	return /* @__PURE__ */ jsx("div", { className: clsx("PRIVATE_TreeView-item-level-line", classes$1.TreeViewItemLevelLine) }, index);
}
_temp2.displayName = "_temp2";
function _temp3(_, i) {
	return /* @__PURE__ */ jsx(SkeletonItem, { "aria-hidden": true }, i);
}
_temp3.displayName = "_temp3";
function _temp6(event) {
	return event.stopPropagation();
}
function _temp7(event_0) {
	return event_0.stopPropagation();
}
function _temp8(event) {
	event.stopPropagation();
}
function _temp9(event_0) {
	if ([
		"Backspace",
		"ArrowLeft",
		"ArrowRight",
		"ArrowUp",
		"ArrowDown",
		"Enter"
	].includes(event_0.key)) event_0.stopPropagation();
}
function _temp0(t0, index) {
	const { label, onClick, icon: Icon, count } = t0;
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		onSelect: onClick,
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon, {}) }),
			label,
			count ? /* @__PURE__ */ jsxs(ActionList.TrailingVisual, { children: [count, /* @__PURE__ */ jsx(VisuallyHidden, { children: "items" })] }) : null
		]
	}, index);
}
_temp0.displayName = "_temp0";
function _temp1(event) {
	if ([
		"Backspace",
		"ArrowLeft",
		"ArrowRight",
		"ArrowUp",
		"ArrowDown",
		"Enter"
	].includes(event.key)) event.stopPropagation();
}
export { TreeView as n, SkeletonAvatar as t };
