var LABELS = {
	issueBodyHeader: "Description",
	issueBodyPlaceholder: "Type your description here…",
	issueBodyHeaderActions: "Issue body actions",
	staleBodyErrorPrefix: "GraphQL error: STALE_DATA",
	convertButton: (taskName) => `Create an issue with the title "${taskName}"`,
	authorLabel: (isBot) => `${isBot ? "bot" : "mannequin"}`,
	copilotCTAButton: "Write with Copilot"
};
export { LABELS as t };
