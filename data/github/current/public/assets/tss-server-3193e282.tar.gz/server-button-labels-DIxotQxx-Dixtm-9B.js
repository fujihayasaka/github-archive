var BUTTON_LABELS = {
	comment: "Comment",
	updateComment: "Update comment"
};
export { BUTTON_LABELS as t };
