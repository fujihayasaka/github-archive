import { b as useParams$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as getQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { n as codeViewLayoutRoute } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { useEffect, useState } from "react";
import { c } from "react/compiler-runtime";
/**
* Given an object, deep compares it to the previous object passed to this hook to see if they
* are the same. If so, return the previous object.
* This is useful for objects that come from the server and are likely to match objects we
* previously received. Using this, we can avoid unnecessary rerenders.
* This function has the potential to be slow and memory-hungry if it is passed very large objects.
*/
function useCanonicalObject(obj) {
	const [lastObj, setLastObj] = useState(obj);
	const [canonical, setCanonical] = useState(obj);
	if (obj === lastObj || obj === canonical) return canonical;
	setLastObj(obj);
	if (deepCompare(obj, canonical)) return canonical;
	setCanonical(obj);
	return obj;
}
/** exported for testing */
function deepCompare(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof a !== typeof b || !a || !b) return false;
	if (Array.isArray(a)) {
		if (!Array.isArray(b)) return false;
		if (a.length !== b.length) return false;
		for (let i = 0; i < a.length; i++) if (!deepCompare(a[i], b[i])) return false;
		return true;
	}
	const aKeys = Object.keys(a);
	const bKeys = Object.keys(b);
	if (aKeys.length !== bKeys.length) return false;
	for (const key of aKeys) if (!deepCompare(a[key], b[key])) return false;
	return true;
}
function useUpdateRefInfoAndPath(refInfo, path) {
	const $ = c(6);
	const { owner, repo } = useParams$1();
	let t0;
	let t1;
	if ($[0] !== owner || $[1] !== path || $[2] !== refInfo || $[3] !== repo) {
		t0 = () => {
			const queryClient = getQueryClient();
			const layoutQueryKey = codeViewLayoutRoute.queries.mainQuery.makeQueryKey({ pathname: `/${owner}/${repo}/_layout` });
			if (!queryClient.getQueryData(layoutQueryKey)) return;
			queryClient.setQueryData(layoutQueryKey, (oldData) => {
				if (!oldData) return oldData;
				return {
					...oldData,
					payload: {
						...oldData.payload,
						refInfo: {
							...oldData.payload.refInfo,
							...refInfo
						},
						path
					}
				};
			});
		};
		t1 = [
			refInfo,
			path,
			owner,
			repo
		];
		$[0] = owner;
		$[1] = path;
		$[2] = refInfo;
		$[3] = repo;
		$[4] = t0;
		$[5] = t1;
	} else {
		t0 = $[4];
		t1 = $[5];
	}
	useEffect(t0, t1);
}
export { useUpdateRefInfoAndPath as n, useCanonicalObject as t };
