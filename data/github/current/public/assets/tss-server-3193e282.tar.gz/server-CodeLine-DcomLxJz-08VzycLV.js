import { a as ssrSafeWindow, n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { F as ChevronDownIcon, L as ChevronRightIcon, O as CheckIcon, _n as KebabHorizontalIcon, an as IconButton, bn as Link, et as CopilotIcon, fi as Tooltip, gt as EllipsisIcon, hi as TriangleDownIcon, n as ActionList, o as AlertIcon, tt as CopyIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { S as useSearchParams, g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { et as modelPromptPath, j as deferredASTPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { A as getExplainSnippetPrompt, N as getSuggestImprovementsPrompt, Z as referenceID, b as copilotFeatureFlags, i as CopilotChatIntents } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { r as VerifiedHTMLDiv } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { a as useObservableMap, c as useObservedState, i as useDerivedObservable, l as useObservedStateMap, n as ObservableSet, o as useObservableValue, r as ObservableValue, t as ObservableMap, u as useSubscription } from "./server-react-observable-0DQDiDnT-BDNMoELa.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { c as useUrlCreator, n as AllShortcutsEnabled, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { n as useCopilotSettings } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { t as useIsPlatform } from "./server-use-is-platform-BI7nkjWR-DIY2sQH4.js";
import { t as NewAgentTaskButton } from "./server-NewAgentTaskButton-gbUWCBSY-Cu9_75w7.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { a as useShortcut, i as useCodeViewOptions } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { a as hiddenUnicodeCharacterHTMLString, c as splitAroundHiddenUnicodeCharacters$1, i as hasHiddenUnicodeCharacters$1, l as useIsSafari, o as showHiddenUnicodeCharactersHTML, r as getHiddenUnicodeReplacement, t as CodeownersErrorLineIndicator } from "./server-HiddenUnicodeCharacter-CZpsU1rI-DzV8Hc4a.js";
import { s as updateUrlHash } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { i as publishOpenCopilotChat, r as publishAddCopilotChatReference } from "./server-copilot-chat-events-CAR-de8z-CxKg4yWR.js";
import { t as qualifyRef } from "./server-ref-utils-DurADI35-f0lQqMVw.js";
import React, { createContext, use, useCallback, useEffect, useEffectEvent, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { createPortal } from "react-dom";
import { c } from "react/compiler-runtime";
import { defaultRangeExtractor, useWindowVirtualizer } from "@tanstack/react-virtual";
var CurrentBlobContext = React.createContext({});
CurrentBlobContext.displayName = "CurrentBlobContext";
function CurrentBlobProvider({ blob, children }) {
	return /* @__PURE__ */ jsxs(CurrentBlobContext, {
		value: blob,
		children: [
			" ",
			children,
			" "
		]
	});
}
CurrentBlobProvider.displayName = "CurrentBlobProvider";
function useCurrentBlob() {
	return React.use(CurrentBlobContext);
}
var CurrentBlameContext = React.createContext(void 0);
CurrentBlameContext.displayName = "CurrentBlameContext";
function CurrentBlameProvider({ blame, children }) {
	return /* @__PURE__ */ jsxs(CurrentBlameContext, {
		value: blame,
		children: [
			" ",
			children,
			" "
		]
	});
}
CurrentBlameProvider.displayName = "CurrentBlameProvider";
function useCurrentBlame() {
	return React.use(CurrentBlameContext);
}
var CurrentLineRefMapContext = React.createContext(null);
CurrentLineRefMapContext.displayName = "CurrentLineRefMapContext";
var useBlobAndBlameSpecificMap = () => {
	const $ = c(2);
	const blob = useCurrentBlob();
	const blame = useCurrentBlame();
	const [map, setMap] = React.useState(_temp$1);
	const [prevBlob, setPrevBlob] = React.useState(blob);
	const [prevBlame, setPrevBlame] = React.useState(blame);
	if (blob !== prevBlob || blame !== prevBlame) {
		let t0;
		if ($[0] !== blame) {
			t0 = blame ? null : /* @__PURE__ */ new Map();
			$[0] = blame;
			$[1] = t0;
		} else t0 = $[1];
		const nextMap = t0;
		setMap(nextMap);
		setPrevBlob(blob);
		setPrevBlame(blame);
		return nextMap;
	}
	return map;
};
function CurrentLineRefMapProvider(t0) {
	const $ = c(3);
	const { children } = t0;
	const map = useBlobAndBlameSpecificMap();
	let t1;
	if ($[0] !== children || $[1] !== map) {
		t1 = jsxs(CurrentLineRefMapContext, {
			value: map,
			children: [
				" ",
				children,
				" "
			]
		});
		$[0] = children;
		$[1] = map;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
CurrentLineRefMapProvider.displayName = "CurrentLineRefMapProvider";
function useLineElementMap() {
	return React.use(CurrentLineRefMapContext);
}
function useGetValueFromLineElementMap() {
	const $ = c(2);
	const map = React.use(CurrentLineRefMapContext);
	let t0;
	if ($[0] !== map) {
		t0 = (num) => map?.get(num);
		$[0] = map;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function useAddValueToLineElementMap() {
	const $ = c(2);
	const map = React.use(CurrentLineRefMapContext);
	let t0;
	if ($[0] !== map) {
		t0 = (num, elem) => {
			if (!map) return;
			if (map.has(num)) map.get(num)?.push(elem);
			else map.set(num, [elem]);
		};
		$[0] = map;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function _temp$1() {
	return /* @__PURE__ */ new Map();
}
function endObserverLogic(previousY, previousRatio, target, intersectionRatio, lineNumber, getStartLines, isIntersecting, onLineStickOrUnstick) {
	const rect = target.getBoundingClientRect();
	const currentY = rect.y;
	const currentRatio = intersectionRatio;
	const startLineArray = lineNumber ? getStartLines() : void 0;
	const lineIsAboveBottomOfScreen = window.innerHeight - rect.bottom > 0;
	const lineIsBelowTopOfScreen = rect.bottom > 0;
	const lineIsCloseToTopOfScreen = rect.top < 150;
	const lineIsOnScreen = lineIsAboveBottomOfScreen && lineIsBelowTopOfScreen;
	const isNotNearBottomOfScreen = window.innerHeight - rect.bottom > 150 && window.innerHeight > 300;
	for (const startLine of startLineArray || []) if (startLine && lineIsOnScreen) {
		if (currentY < previousY && lineIsOnScreen) if (currentRatio > previousRatio && isIntersecting) {} else onLineStickOrUnstick(startLine, true);
		else if (currentY > previousY && isIntersecting) {
			if (currentRatio < previousRatio) {} else if (isNotNearBottomOfScreen && lineIsCloseToTopOfScreen) onLineStickOrUnstick(startLine, false);
		}
	}
	return {
		currentY,
		currentRatio
	};
}
function startObserverLogic(codeLineData, previousY, previousRatio, target, intersectionRatio, isIntersecting, onLineStickOrUnstick) {
	const rect = target.getBoundingClientRect();
	const currentY = rect.y;
	const currentRatio = intersectionRatio;
	const lineIsAboveBottomOfScreen = window.innerHeight - rect.bottom > 0;
	const lineIsBelowTopOfScreen = rect.bottom > 0;
	const lineIsCloseToTopOfScreen = rect.top < 150 && rect.top > -300;
	const lineIsOnScreen = lineIsAboveBottomOfScreen && lineIsBelowTopOfScreen;
	const lineIsNotDisplayed = rect.bottom === 0 && rect.top === 0 && rect.height === 0 && rect.width === 0 && rect.x === 0 && rect.y === 0;
	if (!codeLineData.ownedSection || codeLineData.ownedSection?.collapsed) return {
		currentY,
		currentRatio
	};
	if (currentY <= previousY && (lineIsOnScreen || lineIsCloseToTopOfScreen) && !lineIsNotDisplayed) {
		if (currentRatio > previousRatio && isIntersecting) {} else if (lineIsCloseToTopOfScreen) onLineStickOrUnstick(codeLineData, false);
	} else if (currentY > previousY && isIntersecting) if (currentRatio < previousRatio) {} else onLineStickOrUnstick(codeLineData, true);
	return {
		currentY,
		currentRatio
	};
}
var START_THRESHOLDS = [
	0,
	.1,
	.2,
	.3,
	.4,
	.5,
	.6,
	.7,
	.8,
	.9,
	1
];
function createStartObserver(stickyHeaderHeight, numParents, elementMetadata, onLineStickOrUnstickRef) {
	return new IntersectionObserver((entries) => {
		for (const entry of entries) {
			const meta = elementMetadata.get(entry.target);
			if (!meta || meta.type !== "start") continue;
			const { currentY, currentRatio } = startObserverLogic(meta.codeLineData, meta.previousY, meta.previousRatio, entry.target, entry.intersectionRatio, entry.isIntersecting, onLineStickOrUnstickRef.current);
			meta.previousY = currentY;
			meta.previousRatio = currentRatio;
		}
	}, {
		root: null,
		rootMargin: `-${stickyHeaderHeight + numParents * 20}px 0px 0px 0px`,
		threshold: START_THRESHOLDS
	});
}
function createEndObserver(stickyHeaderHeight, elementMetadata, getValueFromMapRef, onLineStickOrUnstickRef) {
	return new IntersectionObserver((entries) => {
		for (const entry of entries) {
			const meta = elementMetadata.get(entry.target);
			if (!meta || meta.type !== "end") continue;
			const { currentY, currentRatio } = endObserverLogic(meta.previousY, meta.previousRatio, entry.target, entry.intersectionRatio, meta.lineNumber, () => getValueFromMapRef.current(meta.lineNumber), entry.isIntersecting, onLineStickOrUnstickRef.current);
			meta.previousY = currentY;
			meta.previousRatio = currentRatio;
		}
	}, {
		root: null,
		rootMargin: `-${stickyHeaderHeight}px 0px 0px 0px`,
		threshold: 0
	});
}
/**
* Creates a shared set of IntersectionObservers for sticky line tracking.
* Instead of N observers (one per line), this creates ~7 total:
* - 1 end observer (shared rootMargin for all end lines)
* - ~5-6 start observers (one per unique numParents nesting depth)
*
* Call this once at the CodeBlob level and pass the handle down.
*/
function useSharedLineObserver(canDoStickyLines, stickyHeaderHeight, onLineStickOrUnstick) {
	const $ = c(14);
	const isSSR = useRuntimeEnvironment().isServer;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ new Map();
		$[0] = t0;
	} else t0 = $[0];
	const elementMetadataRef = useRef(t0);
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ new Map();
		$[1] = t1;
	} else t1 = $[1];
	const startObserversRef = useRef(t1);
	const endObserverRef = useRef(null);
	const onLineStickOrUnstickRef = useRef(onLineStickOrUnstick);
	const addValueToMap = useAddValueToLineElementMap();
	const addValueToMapRef = useRef(addValueToMap);
	const getValueFromMap = useGetValueFromLineElementMap();
	const getValueFromMapRef = useRef(getValueFromMap);
	const registeredStartLinesRef = useRef(null);
	if (registeredStartLinesRef.current == null) {
		let t2;
		if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = /* @__PURE__ */ new Set();
			$[2] = t2;
		} else t2 = $[2];
		registeredStartLinesRef.current = t2;
	}
	const stickyHeaderHeightRef = useRef(stickyHeaderHeight);
	const isInitializedRef = useRef(false);
	let t2;
	if ($[3] !== addValueToMap || $[4] !== getValueFromMap || $[5] !== onLineStickOrUnstick || $[6] !== stickyHeaderHeight) {
		t2 = () => {
			onLineStickOrUnstickRef.current = onLineStickOrUnstick;
			getValueFromMapRef.current = getValueFromMap;
			stickyHeaderHeightRef.current = stickyHeaderHeight;
			if (addValueToMap !== addValueToMapRef.current) {
				registeredStartLinesRef.current = /* @__PURE__ */ new Set();
				addValueToMapRef.current = addValueToMap;
			}
		};
		$[3] = addValueToMap;
		$[4] = getValueFromMap;
		$[5] = onLineStickOrUnstick;
		$[6] = stickyHeaderHeight;
		$[7] = t2;
	} else t2 = $[7];
	useLayoutEffect(t2);
	let t3;
	let t4;
	if ($[8] !== canDoStickyLines || $[9] !== isSSR || $[10] !== stickyHeaderHeight) {
		t3 = () => {
			if (!canDoStickyLines || isSSR) return;
			endObserverRef.current?.disconnect();
			for (const obs of startObserversRef.current.values()) obs.disconnect();
			const metadata = elementMetadataRef.current;
			for (const meta of metadata.values()) {
				meta.previousY = 0;
				meta.previousRatio = 1;
			}
			const newEndObserver = createEndObserver(stickyHeaderHeight, metadata, getValueFromMapRef, onLineStickOrUnstickRef);
			endObserverRef.current = newEndObserver;
			const newStartObservers = /* @__PURE__ */ new Map();
			for (const meta_0 of metadata.values()) if (meta_0.type === "start" && !newStartObservers.has(meta_0.numParents)) newStartObservers.set(meta_0.numParents, createStartObserver(stickyHeaderHeight, meta_0.numParents, metadata, onLineStickOrUnstickRef));
			startObserversRef.current = newStartObservers;
			for (const [element, meta_1] of metadata) if (meta_1.type === "start") newStartObservers.get(meta_1.numParents)?.observe(element);
			else newEndObserver.observe(element);
			isInitializedRef.current = true;
			return () => {
				newEndObserver.disconnect();
				for (const obs_0 of newStartObservers.values()) obs_0.disconnect();
			};
		};
		t4 = [
			canDoStickyLines,
			isSSR,
			stickyHeaderHeight
		];
		$[8] = canDoStickyLines;
		$[9] = isSSR;
		$[10] = stickyHeaderHeight;
		$[11] = t3;
		$[12] = t4;
	} else {
		t3 = $[11];
		t4 = $[12];
	}
	useLayoutEffect(t3, t4);
	let t5;
	bb0: {
		if (isSSR) {
			t5 = void 0;
			break bb0;
		}
		let t6;
		if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
			t6 = {
				observe(element_0, codeLineData, numParents) {
					const { isStartLine, isEndLine, lineNumber, ownedSection } = codeLineData;
					if (isStartLine) {
						const meta_2 = {
							type: "start",
							codeLineData,
							numParents,
							previousY: 0,
							previousRatio: 1
						};
						elementMetadataRef.current.set(element_0, meta_2);
						if (ownedSection && lineNumber && !registeredStartLinesRef.current?.has(lineNumber)) {
							addValueToMapRef.current(ownedSection.endLine, { lineNumber });
							registeredStartLinesRef.current?.add(lineNumber);
						}
						if (isInitializedRef.current) {
							let obs_1 = startObserversRef.current.get(numParents);
							if (!obs_1) {
								obs_1 = createStartObserver(stickyHeaderHeightRef.current, numParents, elementMetadataRef.current, onLineStickOrUnstickRef);
								startObserversRef.current.set(numParents, obs_1);
							}
							obs_1.observe(element_0);
						}
					} else if (isEndLine && lineNumber) {
						const meta_3 = {
							type: "end",
							lineNumber,
							previousY: 0,
							previousRatio: 1
						};
						elementMetadataRef.current.set(element_0, meta_3);
						if (isInitializedRef.current) {
							if (!endObserverRef.current) endObserverRef.current = createEndObserver(stickyHeaderHeightRef.current, elementMetadataRef.current, getValueFromMapRef, onLineStickOrUnstickRef);
							endObserverRef.current.observe(element_0);
						}
					}
				},
				unobserve(element_1) {
					const meta_4 = elementMetadataRef.current.get(element_1);
					if (!meta_4) return;
					if (meta_4.type === "start") startObserversRef.current.get(meta_4.numParents)?.unobserve(element_1);
					else endObserverRef.current?.unobserve(element_1);
					elementMetadataRef.current.delete(element_1);
				}
			};
			$[13] = t6;
		} else t6 = $[13];
		t5 = t6;
	}
	const handle = t5;
	if (!canDoStickyLines || isSSR) return;
	return handle;
}
/**
* Registers a code line element with the shared observer.
* Returns a ref callback to attach to the line element.
*
* Replaces the per-line `useCodeLineIntersectionObservers` hook,
* avoiding the creation of per-line IntersectionObserver instances.
*/
function useRegisterLineObserver(sharedObserver, codeLineData, numParents) {
	const $ = c(6);
	const elementRef = useRef(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (element) => {
			elementRef.current = element;
		};
		$[0] = t0;
	} else t0 = $[0];
	const refCallback = t0;
	let t1;
	let t2;
	if ($[1] !== codeLineData || $[2] !== numParents || $[3] !== sharedObserver) {
		t1 = () => {
			const element_0 = elementRef.current;
			if (!element_0 || !sharedObserver) return;
			const { isStartLine, isEndLine } = codeLineData;
			if (!isStartLine && !isEndLine) return;
			sharedObserver.observe(element_0, codeLineData, numParents);
			return () => {
				sharedObserver.unobserve(element_0);
			};
		};
		t2 = [
			codeLineData,
			numParents,
			sharedObserver
		];
		$[1] = codeLineData;
		$[2] = numParents;
		$[3] = sharedObserver;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useLayoutEffect(t1, t2);
	return refCallback;
}
function parseBlobRange(str) {
	const lines = str.match(/#?(?:L)(\d+)((?:C)(\d+))?/g);
	if (!lines) return;
	else if (lines.length === 1) {
		const offset = parseBlobOffset(lines[0]);
		if (!offset) return;
		return Object.freeze({
			start: offset,
			end: offset
		});
	} else if (lines.length === 2) {
		const startOffset = parseBlobOffset(lines[0]);
		const endOffset = parseBlobOffset(lines[1]);
		if (!startOffset || !endOffset) return;
		return ascendingBlobRange(Object.freeze({
			start: startOffset,
			end: endOffset
		}));
	} else return;
}
function formatBlobRange(blobRange) {
	const { start, end } = ascendingBlobRange(blobRange);
	if (start.column != null && end.column != null) return `L${start.line}C${start.column}-L${end.line}C${end.column}`;
	else if (start.column != null) return `L${start.line}C${start.column}-L${end.line}`;
	else if (end.column != null) return `L${start.line}-L${end.line}C${end.column}`;
	else if (start.line === end.line) return `L${start.line}`;
	else return `L${start.line}-L${end.line}`;
}
function parseAnchorPrefix(str) {
	const match = str.length < 5e3 && str.match(/(file-.+?-)L\d+?/i);
	return match && match[1] ? match[1] : "";
}
function parseFileAnchor(str) {
	return {
		blobRange: parseBlobRange(str),
		anchorPrefix: parseAnchorPrefix(str)
	};
}
function formatBlobRangeAnchor({ anchorPrefix, blobRange }) {
	if (!blobRange) return "#";
	return `#${anchorPrefix}${formatBlobRange(blobRange)}`;
}
function parseBlobOffset(str) {
	if (!str) return null;
	const lineMatch = str.match(/L(\d+)/);
	const columnMatch = str.match(/C(\d+)/);
	if (lineMatch && lineMatch[1]) return Object.freeze({
		line: parseInt(lineMatch[1]),
		column: columnMatch && columnMatch[1] ? parseInt(columnMatch[1]) : null
	});
	else return null;
}
function DOMRangeFromBlob(blobRange, getLineElement) {
	const [startContainer, _startOffset] = findRangeOffset(blobRange.start, true, getLineElement);
	const [endContainer, _endOffset] = findRangeOffset(blobRange.end, false, getLineElement);
	if (!startContainer || !endContainer) return;
	let startOffset = _startOffset;
	let endOffset = _endOffset;
	if (startOffset === -1) startOffset = 0;
	if (endOffset === -1) endOffset = endContainer.childNodes.length;
	if (!startContainer.ownerDocument) throw new Error(`DOMRange needs to be inside document`);
	const range = startContainer.ownerDocument.createRange();
	range.setStart(startContainer, startOffset);
	range.setEnd(endContainer, endOffset);
	return range;
}
function findRangeOffset(offset, lookAhead, getLineElement) {
	const error = [null, 0];
	const lineElement = getLineElement(offset.line);
	if (!lineElement) return error;
	if (offset.column == null) return [lineElement, -1];
	let column = offset.column - 1;
	const textNodes = getAllTextNodes(lineElement);
	for (let i = 0; i < textNodes.length; i++) {
		const textNode = textNodes[i] || null;
		const nextC = column - (textNode?.textContent || "").length;
		if (nextC === 0) {
			const nextTextNode = textNodes[i + 1];
			if (lookAhead && nextTextNode) return [nextTextNode, 0];
			else return [textNode, column];
		} else if (nextC < 0) return [textNode, column];
		column = nextC;
	}
	return error;
}
function getAllTextNodes(el) {
	if (el.nodeType === Node.TEXT_NODE) return [el];
	if (!el.childNodes || !el.childNodes.length) return [];
	let list = [];
	for (const node of el.childNodes) list = list.concat(getAllTextNodes(node));
	return list;
}
function ascendingBlobRange(range) {
	const offsets = [range.start, range.end];
	offsets.sort(compareBlobOffsets);
	if (offsets[0] === range.start && offsets[1] === range.end) return range;
	else return Object.freeze({
		start: offsets[0],
		end: offsets[1]
	});
}
function compareBlobOffsets(a, b) {
	if (a.line === b.line && a.column === b.column) return 0;
	else if (a.line === b.line && typeof a.column === "number" && typeof b.column === "number") return a.column - b.column;
	else return a.line - b.line;
}
var HighlightedOverlay_module_default = {
	focusedHighlight: "HighlightedOverlay-module_o2X7-a_focusedHighlight",
	hiddenText: "HighlightedOverlay-module_o2X7-a_hiddenText",
	highlightBackground: "HighlightedOverlay-module_o2X7-a_highlightBackground",
	overlayWrapper: "HighlightedOverlay-module_o2X7-a_overlayWrapper",
	overlayWrapperNoWrap: "HighlightedOverlay-module_o2X7-a_overlayWrapperNoWrap",
	overlayWrapperWrap: "HighlightedOverlay-module_o2X7-a_overlayWrapperWrap",
	unfocusedHighlight: "HighlightedOverlay-module_o2X7-a_unfocusedHighlight"
};
function HighlightedOverlay({ symbols, focusedSymbol, lineNumber, style, isNotUsingWhitespace, className }) {
	let startIndex = 0;
	const text = symbols.length > 0 ? symbols[0].bodyText : "";
	const key = `overlay-${lineNumber}-${style ? "blob" : "panel"}-${text}`;
	const wrapOption = useCodeViewOptions().codeWrappingOption;
	const leadingWhitespace = symbols.length > 0 && !isNotUsingWhitespace ? symbols[0].leadingWhitespace ?? 0 : 0;
	return /* @__PURE__ */ jsxs("span", {
		className: clsx(HighlightedOverlay_module_default.overlayWrapper, wrapOption.enabled ? HighlightedOverlay_module_default.overlayWrapperWrap : HighlightedOverlay_module_default.overlayWrapperNoWrap, className),
		style,
		children: [symbols.map((symbol) => {
			const isFocused = symbol === focusedSymbol;
			const line = /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
				className: HighlightedOverlay_module_default.hiddenText,
				children: text.substring(startIndex, symbol.ident.start.column + leadingWhitespace)
			}), /* @__PURE__ */ jsx("span", {
				className: clsx(HighlightedOverlay_module_default.highlightBackground, isFocused ? HighlightedOverlay_module_default.focusedHighlight : HighlightedOverlay_module_default.unfocusedHighlight),
				children: /* @__PURE__ */ jsx("span", {
					className: !isFocused ? HighlightedOverlay_module_default.hiddenText : void 0,
					id: matchElementId(symbol.lineNumber, symbol.ident.start.column + leadingWhitespace),
					children: text.substring(symbol.ident.start.column + leadingWhitespace, symbol.ident.end.column + leadingWhitespace)
				})
			})] }, `symbol-${symbol.ident.start.line}-${symbol.ident.start.column + leadingWhitespace}`);
			startIndex = symbol.ident.end.column + leadingWhitespace;
			return line;
		}), /* @__PURE__ */ jsx("span", {
			className: HighlightedOverlay_module_default.hiddenText,
			children: text.substring(startIndex)
		})]
	}, key);
}
HighlightedOverlay.displayName = "HighlightedOverlay";
function matchElementId(line, column) {
	return `match-${line}-${column}`;
}
var nodePart = (node, indexName) => {
	return node[{
		start: 0,
		end: 1,
		cssClass: 2
	}[indexName]];
};
/**
* Parses either styled directive format into the common styling directive.
* @param node - The node to parse.
* @returns The parsed styling directive.
*/
var parseDirective = (node) => {
	if (Array.isArray(node)) return {
		s: nodePart(node, "start"),
		e: nodePart(node, "end"),
		c: nodePart(node, "cssClass")
	};
	return node;
};
/**
* Parses either styled directive format into the common styling directive.
* It will short-circuit and smartly avoid checking each directive if the first one is already parsed.
* @param directives - The directives to parse.
* @returns The parsed styling directives.
*/
var parseDirectives = (directives) => {
	if (directives.length === 0) return [];
	if (Array.isArray(directives[0])) return directives.map(parseDirective);
	return directives;
};
var tooLargeOfALineHeight = 100;
function useCurrentLineHeight(lineContainerID, t0) {
	const $ = c(9);
	const defaultLineHeight = t0 === void 0 ? 20 : t0;
	const [lineHeight, setLineHeight] = useState(defaultLineHeight);
	const previousLineHeight = useRef(defaultLineHeight);
	const wrapOption = useCodeViewOptions().codeWrappingOption;
	const location = useLocation$1();
	let t1;
	if ($[0] !== defaultLineHeight || $[1] !== lineContainerID || $[2] !== wrapOption.enabled) {
		t1 = () => {
			const fileNameText = document.getElementById("file-name-id-wide");
			if (!fileNameText) return;
			const resizeObserver = new ResizeObserver(debounce(() => {
				let detectedLineHeight = document.getElementsByClassName(lineContainerID)[0]?.firstChild?.getBoundingClientRect().height ?? defaultLineHeight;
				if (detectedLineHeight > tooLargeOfALineHeight) detectedLineHeight = document.getElementsByClassName(lineContainerID)[0]?.firstChild?.firstChild?.getBoundingClientRect().height;
				if (detectedLineHeight !== 0 && detectedLineHeight !== previousLineHeight.current && !wrapOption.enabled) {
					setLineHeight(detectedLineHeight);
					previousLineHeight.current = detectedLineHeight;
				}
			}));
			resizeObserver.observe(fileNameText);
			return () => resizeObserver.disconnect();
		};
		$[0] = defaultLineHeight;
		$[1] = lineContainerID;
		$[2] = wrapOption.enabled;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== defaultLineHeight || $[5] !== lineContainerID || $[6] !== location.key || $[7] !== wrapOption.enabled) {
		t2 = [
			location.key,
			wrapOption.enabled,
			lineContainerID,
			defaultLineHeight
		];
		$[4] = defaultLineHeight;
		$[5] = lineContainerID;
		$[6] = location.key;
		$[7] = wrapOption.enabled;
		$[8] = t2;
	} else t2 = $[8];
	useLayoutEffect(t1, t2);
	return lineHeight;
}
function createNode(text) {
	const node = document.createElement("pre");
	node.style.width = "1px";
	node.style.height = "1px";
	node.style.position = "fixed";
	node.style.top = "5px";
	node.textContent = text;
	return node;
}
function copyNode(node) {
	if ("clipboard" in navigator) return navigator.clipboard.writeText(node.textContent || "");
	const selection = getSelection();
	if (selection == null) return Promise.reject(/* @__PURE__ */ new Error());
	selection.removeAllRanges();
	const range = document.createRange();
	range.selectNodeContents(node);
	selection.addRange(range);
	document.execCommand("copy");
	selection.removeAllRanges();
	return Promise.resolve();
}
function copyText(text) {
	if ("clipboard" in navigator) return navigator.clipboard.writeText(text);
	const body = document.body;
	if (!body) return Promise.reject(/* @__PURE__ */ new Error());
	const node = createNode(text);
	body.appendChild(node);
	copyNode(node);
	body.removeChild(node);
	return Promise.resolve();
}
var CopyState = {
	Idle: "Idle",
	Fetching: "Fetching",
	Success: "Success",
	Error: "Error"
};
function isClipboardSupported() {
	return "clipboard" in navigator && typeof ClipboardItem !== "undefined";
}
async function fetchContent(url) {
	const res = await fetch(url, { method: "get" });
	if (!res.ok) throw new Error(`Failed to fetch ${url}: ${res.status} ${res.statusText}`);
	const text = (await res.text()).replace(/\r?\n$/, "");
	return new Blob([text], { type: "text/plain" });
}
/**
* Get common UI for the button and action item based on the current state.
*/
function getCopyStateUI(state) {
	let ariaLabel;
	let content;
	switch (state) {
		case CopyState.Success:
			ariaLabel = "Copied!";
			content = /* @__PURE__ */ jsx(Octicon, { icon: CheckIcon });
			break;
		case CopyState.Fetching:
			ariaLabel = "Copying";
			content = /* @__PURE__ */ jsx(Spinner, { size: "small" });
			break;
		case CopyState.Error:
			ariaLabel = "Something went wrong. Try again.";
			content = /* @__PURE__ */ jsx(Octicon, { icon: AlertIcon });
			break;
		default:
			ariaLabel = "Copy";
			content = /* @__PURE__ */ jsx(Octicon, { icon: CopyIcon });
	}
	return {
		ariaLabel,
		content
	};
}
function useCopyRawBlobContents() {
	const { sendRepoClickEvent } = useReposAnalytics();
	const { rawBlobUrl } = useCurrentBlob();
	const isFirefox = useRef(false);
	useEffect(() => {
		isFirefox.current = navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
	}, []);
	return useCallback(async () => {
		sendRepoClickEvent("BLOB_RAW_DROPDOWN.COPY");
		try {
			const blobPromise = fetchContent(rawBlobUrl);
			if (isClipboardSupported() && navigator && navigator.clipboard && "write" in navigator.clipboard && !isFirefox.current) await navigator.clipboard.write([new ClipboardItem({ "text/plain": blobPromise })]);
			else {
				const blob = await blobPromise;
				if (!blob) return CopyState.Error;
				await copyText(await blob.text());
			}
		} catch {
			return CopyState.Error;
		}
		return CopyState.Success;
	}, [
		isFirefox,
		sendRepoClickEvent,
		rawBlobUrl
	]);
}
/**
* This component intercepts the select-all shortcut and selects the contents
* of the given container instead of the contents of the entire document.
*
* In addition, it also intercepts the copy shortcut. If the current selection
* was created through select-all, it will copy the raw blob contents instead
* of the current selection. This is because when the code blob is virtualized,
* the current selection will only contain the visible lines.
*/
function SelectAllShortcutButton({ containerRef, shouldNotOverrideCopy }) {
	const { selectAllShortcut } = useShortcut();
	const allSelected = useRef(false);
	const copyRawBlobContents = useCopyRawBlobContents();
	const onSelectionChange = useCallback(() => {
		allSelected.current = false;
		document.removeEventListener("selectionchange", onSelectionChange);
	}, []);
	useEffect(() => () => document.removeEventListener("selectionchange", onSelectionChange), [onSelectionChange]);
	const selectAll = useCallback((event) => {
		if (containerRef) {
			if (!containerRef.current) return;
			selectAllContentInElement(containerRef.current);
			event.preventDefault();
			allSelected.current = true;
			setTimeout(() => document.addEventListener("selectionchange", onSelectionChange), 0);
		}
	}, [containerRef, onSelectionChange]);
	const copyFullFileContents = useCallback((event_0) => {
		if (!allSelected.current) return;
		event_0.preventDefault();
		copyRawBlobContents();
	}, [copyRawBlobContents]);
	useEffect(() => {
		if (shouldNotOverrideCopy) return;
		window.addEventListener("copy", copyFullFileContents);
		return () => window.removeEventListener("copy", copyFullFileContents);
	}, [copyFullFileContents, shouldNotOverrideCopy]);
	return /* @__PURE__ */ jsx("button", {
		hidden: true,
		"data-hotkey": selectAllShortcut.hotkey,
		onClick: selectAll
	});
}
SelectAllShortcutButton.displayName = "SelectAllShortcutButton";
function selectAllContentInElement(element) {
	const range = document.createRange();
	range.selectNode(element);
	const sel = window.getSelection();
	sel?.removeAllRanges();
	sel?.addRange(range);
}
var CodeFoldingEllipsisOverlay_module_default = { ellipsisRow: "CodeFoldingEllipsisOverlay-module_BXOntW_ellipsisRow" };
function CodeFoldingEllipsisOverlay(t0) {
	const { linesData, onLineStickOrUnstick, setIsCollapsed, tabSize, extraLeftPadding, contentWidth } = t0;
	const collapsedRowsArray = [...useCollapsedLinesSubscription().keys()];
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	return jsx(Fragment$1, { children: collapsedRowsArray.map((lineNumber) => {
		const actualLineNumber = getActualLineNumberBinarySearch(lineNumber, linesData);
		if (actualLineNumber === void 0 || linesData[actualLineNumber]?.ownedSection === void 0) return null;
		const lineData = linesData[actualLineNumber];
		const leftOffset = determineProperOffsetWithDummyDiv(lineData?.rawText?.length ?? 0, lineData?.rawText ?? "", tabSize);
		return jsxs("div", {
			className: CodeFoldingEllipsisOverlay_module_default.ellipsisRow,
			style: {
				top: lineHeight * actualLineNumber,
				height: lineHeight
			},
			children: [contentWidth ? jsx(HighlighterElement, {
				subtle: true,
				lineNumber,
				highlightPosition: {
					offset: -82,
					width: contentWidth
				}
			}) : null, jsx(ExpandRowEllipsis, {
				codeLineData: lineData,
				setIsCollapsed,
				onLineStickOrUnstick,
				leftOffset: leftOffset + (extraLeftPadding ?? 0)
			})]
		}, `expand-row-ellipsis-${lineNumber}`);
	}) });
}
CodeFoldingEllipsisOverlay.displayName = "CodeFoldingEllipsisOverlay";
function ExpandRowEllipsis({ codeLineData, leftOffset, setIsCollapsed, onLineStickOrUnstick }) {
	const { lineNumber, ownedSection } = codeLineData;
	if (!useIsLineCollapsed(lineNumber)) return null;
	return /* @__PURE__ */ jsx("button", {
		"aria-label": "Expand row",
		className: "Button Button--iconOnly Button--invisible Button--small px-2 py-0 ml-1 border-0 expand-row-ellipsis",
		style: { left: leftOffset },
		onMouseDown: (ev) => {
			expandRow(lineNumber);
			setIsCollapsed?.(false);
			if (ownedSection) {
				ownedSection.collapsed = false;
				onLineStickOrUnstick?.(codeLineData, true);
			}
			ev.preventDefault();
		},
		children: /* @__PURE__ */ jsx(EllipsisIcon, {})
	});
}
ExpandRowEllipsis.displayName = "ExpandRowEllipsis";
var CodeLines_module_default = {
	codeFileContents: "CodeLines-module_m1s5ta_codeFileContents",
	scrollBarContainer: "CodeLines-module_m1s5ta_scrollBarContainer",
	scrollBarSpacer: "CodeLines-module_m1s5ta_scrollBarSpacer",
	scrollContainerAuto: "CodeLines-module_m1s5ta_scrollContainerAuto",
	scrollContainerHidden: "CodeLines-module_m1s5ta_scrollContainerHidden"
};
var defaultOverscanAmount = 100;
var defaultHeadAndTailLength = 75;
function defaultMeasureElement(element) {
	return element.getBoundingClientRect().height;
}
function useVirtualCodeBlob(t0) {
	const $ = c(12);
	const { lineCount, materializeAllLines } = t0;
	const currentLineHeight = useCurrentLineHeight("react-line-numbers");
	let t1;
	if ($[0] !== currentLineHeight) {
		t1 = () => currentLineHeight;
		$[0] = currentLineHeight;
		$[1] = t1;
	} else t1 = $[1];
	const estimateSize = t1;
	let t2;
	if ($[2] !== lineCount) {
		t2 = getRangeExtractor(lineCount);
		$[2] = lineCount;
		$[3] = t2;
	} else t2 = $[3];
	const rangeExtractor = t2;
	const t3 = materializeAllLines ? Number.MAX_SAFE_INTEGER : defaultOverscanAmount;
	let t4;
	if ($[4] !== estimateSize || $[5] !== lineCount || $[6] !== rangeExtractor || $[7] !== t3) {
		t4 = {
			count: lineCount,
			overscan: t3,
			estimateSize,
			rangeExtractor,
			measureElement: defaultMeasureElement,
			scrollToFn
		};
		$[4] = estimateSize;
		$[5] = lineCount;
		$[6] = rangeExtractor;
		$[7] = t3;
		$[8] = t4;
	} else t4 = $[8];
	const virtualizer = useWindowVirtualizer(t4);
	let t5;
	if ($[9] !== currentLineHeight || $[10] !== virtualizer) {
		t5 = {
			virtualizer,
			currentLineHeight
		};
		$[9] = currentLineHeight;
		$[10] = virtualizer;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
}
function scrollToFn(offset) {
	window.scrollTo({
		top: offset,
		left: 0,
		behavior: "instant"
	});
}
function getRangeExtractor(lineCount) {
	return function customRangeExtractor(range) {
		if (lineCount < 2 * defaultHeadAndTailLength) {
			const all = new Array(lineCount);
			for (let i = 0; i < lineCount; i++) all[i] = i;
			return all;
		}
		const indicesInWindow = defaultRangeExtractor(range);
		if (indicesInWindow.length === 0) return indicesInWindow;
		const minIndexInWindow = indicesInWindow[0];
		const maxIndexInWindow = indicesInWindow[indicesInWindow.length - 1];
		const headLength = Math.min(defaultHeadAndTailLength, minIndexInWindow);
		const tailLength = Math.min(defaultHeadAndTailLength, lineCount - maxIndexInWindow);
		const tailStart = lineCount + 1 - tailLength;
		const result = new Array(headLength + indicesInWindow.length + (lineCount - tailStart));
		let idx = 0;
		for (let i = 0; i < headLength; i++) result[idx++] = i;
		for (let i = 0; i < indicesInWindow.length; i++) result[idx++] = indicesInWindow[i];
		for (let i = tailStart; i < lineCount; i++) result[idx++] = i;
		return result;
	};
}
var HiddenUnicode_module_default = {
	Button: "HiddenUnicode-module__VmUDW_Button",
	Flash: "HiddenUnicode-module__VmUDW_Flash",
	Octicon: "HiddenUnicode-module__VmUDW_Octicon"
};
var hiddenUnicodeRegex = /[\u202A-\u202E]|[\u2066-\u2069]|\u{E0001}|\u{E007F}/u;
var hiddenUnicodeRegexG = /[\u202A-\u202E]|[\u2066-\u2069]|\u{E0001}|\u{E007F}/gu;
var hiddenUnicodeBoundaryRegex = /([\u202A-\u202E]|[\u2066-\u2069]|\u{E0001}|\u{E007F})/gu;
var hiddenUnicodeReplacementMap = new Map(Object.entries({
	"‪": "U+202A",
	"‫": "U+202B",
	"‬": "U+202C",
	"‭": "U+202D",
	"‮": "U+202E",
	"⁦": "U+2066",
	"⁧": "U+2067",
	"⁨": "U+2068",
	"⁩": "U+2069",
	"󠀁": "U+E0001",
	"󠁿": "U+E007F"
}));
function HiddenUnicodeAlert() {
	const { isBrowser } = useRuntimeEnvironment();
	const usableWindow = isBrowser ? ssrSafeWindow : void 0;
	if (!usableWindow) return null;
	const revealButtonUrl = new URL(usableWindow.location.href, usableWindow.location.origin);
	const shown = revealButtonUrl.searchParams.get("h") === "1";
	if (shown) revealButtonUrl.searchParams.delete("h");
	else revealButtonUrl.searchParams.set("h", "1");
	return /* @__PURE__ */ jsxs(Flash, {
		full: true,
		variant: "warning",
		className: HiddenUnicode_module_default.Flash,
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			/* @__PURE__ */ jsxs("span", { children: [
				"This file contains bidirectional or hidden Unicode text that may be interpreted or compiled differently than what appears below. To review, open the file in an editor that reveals hidden Unicode characters.",
				" ",
				/* @__PURE__ */ jsx(Link, {
					inline: true,
					href: "https://github.co/hiddenchars",
					target: "_blank",
					rel: "noreferrer",
					children: "Learn more about bidirectional Unicode characters"
				})
			] }),
			/* @__PURE__ */ jsx(ButtonComponent, {
				as: "a",
				onClick: () => {
					window.location.href = revealButtonUrl.href;
				},
				size: "small",
				className: HiddenUnicode_module_default.Button,
				children: shown ? "Hide revealed characters" : "Show hidden characters"
			})
		]
	});
}
HiddenUnicodeAlert.displayName = "HiddenUnicodeAlert";
function HiddenUnicodeTooltip() {
	return /* @__PURE__ */ jsx(Tooltip, {
		direction: "e",
		text: "This line has hidden Unicode characters",
		children: /* @__PURE__ */ jsx(Octicon, {
			icon: AlertIcon,
			className: HiddenUnicode_module_default.Octicon
		})
	});
}
HiddenUnicodeTooltip.displayName = "HiddenUnicodeTooltip";
function HiddenUnicodeCharacter({ char }) {
	return /* @__PURE__ */ jsx("span", {
		className: "hidden-unicode-replacement padded",
		children: char
	});
}
HiddenUnicodeCharacter.displayName = "HiddenUnicodeCharacter";
/**
* Split the given text into an array of strings and hidden Unicode control characters.
*/
function splitAroundHiddenUnicodeCharacters(text) {
	return text.split(hiddenUnicodeBoundaryRegex);
}
function showHiddenUnicodeCharactersRaw(text) {
	if (!hasHiddenUnicodeCharacters(text)) return text;
	return text.replaceAll(hiddenUnicodeRegexG, (char) => hiddenUnicodeReplacementMap.get(char) ?? "");
}
function showHiddenUnicodeCharacters(text) {
	if (!hasHiddenUnicodeCharacters(text)) return null;
	return splitAroundHiddenUnicodeCharacters(text).map((segment, index) => {
		const replacement = hiddenUnicodeReplacementMap.get(segment);
		return replacement ? /* @__PURE__ */ jsx(HiddenUnicodeCharacter, { char: replacement }, index) : segment;
	});
}
function hasHiddenUnicodeCharacters(text) {
	return hiddenUnicodeRegex.test(text);
}
function isHiddenUnicodeShown() {
	if (!ssrSafeWindow) return false;
	return new URL(ssrSafeWindow.location.href, ssrSafeWindow.location.origin).searchParams.get("h") === "1";
}
function AskCopilotButton({ children, referenceType, ...props }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(IconButton, {
		ref: useRef(null),
		icon: CopilotIcon,
		size: "small",
		"aria-label": `Ask Copilot about this ${referenceType}`,
		tooltipDirection: "n",
		"data-testid": "copilot-ask-menu",
		...props
	}) });
}
AskCopilotButton.displayName = "AskCopilotButton";
var CopilotCodeLinesMenu_module_default = { "menu-button": "CopilotCodeLinesMenu-module_h3_Eka_menu-button" };
var DROPDOWN_BUTTON_ID = "code-line-dropdown-copilot-button";
function CopilotCodeLinesMenu({ copilotAccessAllowed, messageReference, hideDropdown, id, showAgentTaskButton, currentRepo, currentReference, decoupledModeEnabled }) {
	const [open, setOpen] = useState(false);
	const [view, setView] = useState("actionMenu");
	const openingThreadSwitchEnable = isFeatureEnabled("copilot_chat_opening_thread_switch");
	const handleExplain = () => {
		sendChatEvent(messageReference.type, getChatMode(messageReference.type));
		if (copilotFeatureFlags.copilotRedirectSnippetToImmersive && messageReference.type === "snippet") {
			copilotLocalStorage.setEntrypointMessage({
				message: getExplainSnippetPrompt(),
				references: [messageReference]
			});
			window.location.href = "/copilot";
		} else publishOpenCopilotChat({
			content: "Explain",
			intent: CopilotChatIntents.explain,
			references: [messageReference],
			id: DROPDOWN_BUTTON_ID
		});
		setOpen(false);
	};
	const handleSuggest = () => {
		const suggestMessage = getSuggestImprovementsPrompt();
		if (copilotFeatureFlags.copilotRedirectSnippetToImmersive && messageReference.type === "snippet") {
			sendChatEvent(messageReference.type, getChatMode(messageReference.type));
			copilotLocalStorage.setEntrypointMessage({
				message: suggestMessage,
				references: [messageReference]
			});
			window.location.href = "/copilot";
		} else publishOpenCopilotChat({
			content: suggestMessage,
			intent: CopilotChatIntents.suggest,
			references: [messageReference],
			id: DROPDOWN_BUTTON_ID
		});
		setOpen(false);
	};
	const handleNewTask = () => {
		setView("newTask");
	};
	const handleAskAbout = useCallback(() => {
		sendChatEvent(messageReference.type, getChatMode(messageReference.type));
		publishOpenCopilotChat({
			intent: CopilotChatIntents.conversation,
			references: [messageReference],
			id
		});
		setOpen(false);
	}, [id, messageReference]);
	const handleAddReferenceCallback = () => {
		if (openingThreadSwitchEnable) handleAttachReference(messageReference, DROPDOWN_BUTTON_ID);
		else handleAddReference(messageReference, true, DROPDOWN_BUTTON_ID);
		setOpen(false);
	};
	const handleAskCopilotClick = () => {
		sendChatEvent(messageReference.type, getChatMode(messageReference.type));
		if (messageReference.type === "file" && copilotFeatureFlags.copilotRedirectFileViewToImmersive) window.location.href = `/copilot?reference_id=${referenceID(messageReference)}`;
		else if (messageReference.type === "snippet" && copilotFeatureFlags.copilotRedirectSnippetToImmersive) {
			copilotLocalStorage.setCurrentReferences(null, [messageReference]);
			window.location.href = "/copilot";
		} else if (hideDropdown) handleAddReference(messageReference, true, id);
		else handleAskAbout();
	};
	const copilotButtonGroupProps = {
		referenceType: messageReference.type,
		onClick: handleAskCopilotClick,
		id
	};
	return copilotAccessAllowed ? hideDropdown ? /* @__PURE__ */ jsx(AskCopilotButton, {
		referenceType: messageReference.type,
		onClick: handleAskCopilotClick,
		id
	}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [view === "actionMenu" && /* @__PURE__ */ jsxs(ButtonGroup, { children: [/* @__PURE__ */ jsx(AskCopilotButton, { ...copilotButtonGroupProps }), /* @__PURE__ */ jsxs(ActionMenu, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsx(ActionMenu.Button, {
			id: DROPDOWN_BUTTON_ID,
			trailingAction: TriangleDownIcon,
			size: "small",
			"aria-label": "Copilot menu",
			className: CopilotCodeLinesMenu_module_default["menu-button"],
			children: /* @__PURE__ */ jsx(Fragment$1, {})
		}), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			align: "end",
			onKeyDown: (e) => {
				if (e.key === "Escape") {
					e?.stopPropagation();
					setOpen(false);
				}
			},
			children: /* @__PURE__ */ jsxs(ActionList, { children: [
				/* @__PURE__ */ jsx(ActionList.Item, {
					onSelect: handleExplain,
					children: "Explain"
				}),
				/* @__PURE__ */ jsx(ActionList.Item, {
					onSelect: handleSuggest,
					children: "Suggest improvements"
				}),
				showAgentTaskButton && /* @__PURE__ */ jsx(ActionList.Item, {
					onSelect: handleNewTask,
					children: "New agent session"
				}),
				!copilotFeatureFlags.copilotRedirectSnippetToImmersive && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsx(ActionList.Item, {
					onSelect: handleAddReferenceCallback,
					children: "Attach to current thread"
				})] })
			] })
		})]
	})] }), view === "newTask" && /* @__PURE__ */ jsxs(ButtonGroup, { children: [/* @__PURE__ */ jsx(AskCopilotButton, { ...copilotButtonGroupProps }), /* @__PURE__ */ jsx(NewAgentTaskButton, {
		isIconButton: true,
		icon: TriangleDownIcon,
		size: "small",
		label: "Copilot menu",
		eventType: "new_agent_task_button_codeview_line_selection",
		currentReference,
		currentRepo,
		hideRepoSelector: true,
		open: true,
		onClose: () => setView("actionMenu"),
		setContentOpen: (newOpen) => {
			if (!newOpen) setView("actionMenu");
		},
		decoupledModeEnabled
	})] })] }) : null;
}
CopilotCodeLinesMenu.displayName = "CopilotCodeLinesMenu";
var handleAttachReference = (messageReference, id) => {
	publishAddCopilotChatReference(messageReference, false, id);
	publishOpenCopilotChat({
		intent: CopilotChatIntents.conversation,
		id,
		attachThread: true
	});
};
var handleAddReference = (messageReference, shouldAppend, id) => {
	if (shouldAppend) {
		publishAddCopilotChatReference(messageReference, true, id);
		publishOpenCopilotChat({
			intent: CopilotChatIntents.conversation,
			id
		});
	} else publishOpenCopilotChat({
		intent: CopilotChatIntents.conversation,
		references: [messageReference],
		id
	});
};
function getChatMode(referenceType) {
	if (referenceType === "file" && copilotFeatureFlags.copilotRedirectFileViewToImmersive) return "immersive";
	if (referenceType === "snippet" && copilotFeatureFlags.copilotRedirectSnippetToImmersive) return "immersive";
	return "assistive";
}
function sendChatEvent(referenceType, mode) {
	sendEvent("dotcom_chat.activate", {
		target: referenceType,
		mode
	});
}
var positionerID$1 = "highlighted-line-menu-positioner";
function useHighlightedLineMenuOptions({ lineData, onLineStickOrUnstick, onMenuClose, onCollapseToggle, setOpen }) {
	function setShouldBeOpen(openValue, wasExpandCollapse = false) {
		setOpen(openValue);
		if (onMenuClose && !openValue) onMenuClose(openValue, wasExpandCollapse);
	}
	function openUpRefSelector() {
		const refSelector = document.getElementsByClassName("ref-selector-class");
		if (refSelector && refSelector.length === 1) {
			refSelector[0]?.click();
			announce$1("ref selector opened");
		} else if (refSelector && refSelector.length === 2) {
			refSelector[1]?.click();
			announce$1("ref selector opened");
		}
		setShouldBeOpen(false);
	}
	function expandOrCollapseSection() {
		if (!lineData) return;
		const { ownedSection } = lineData;
		if (ownedSection) if (ownedSection.collapsed) {
			expand();
			forceAnnouncementToScreenReaders("Code section expanded");
		} else {
			collapse();
			forceAnnouncementToScreenReaders("Code section collapsed");
		}
		setShouldBeOpen(false, true);
	}
	const expand = useCallback(() => {
		if (!lineData) return;
		const { lineNumber, ownedSection: ownedSection_0 } = lineData;
		if (ownedSection_0) ownedSection_0.collapsed = false;
		onCollapseToggle?.();
		expandRow(lineNumber);
		onLineStickOrUnstick?.(lineData, true);
	}, [
		lineData,
		onCollapseToggle,
		onLineStickOrUnstick
	]);
	const collapse = useCallback(() => {
		if (!lineData) return;
		const { lineNumber: lineNumber_0, ownedSection: ownedSection_1 } = lineData;
		if (ownedSection_1) ownedSection_1.collapsed = true;
		onCollapseToggle?.();
		collapseRow(lineNumber_0);
	}, [lineData, onCollapseToggle]);
	return {
		setShouldBeOpen,
		expandOrCollapseSection,
		openUpRefSelector
	};
}
function calculatePosition(anchor, offset = {
	x: 0,
	y: 0
}) {
	const container = document.getElementById(positionerID$1);
	if (!anchor || !container) return { display: "none" };
	const { top: anchorTop, left: anchorLeft, height: anchorHeight } = anchor.getBoundingClientRect();
	const { top: tableTop, left: tableLeft } = container.getBoundingClientRect();
	const topOffset = (25 - anchorHeight) / 2;
	return {
		top: `${anchorTop - tableTop - topOffset + offset.y}px`,
		left: `${Math.max(anchorLeft - tableLeft + offset.x, 0) - 13}px`
	};
}
function calculateTextContentFromElement(element) {
	let textContent = element?.textContent ?? "";
	if (textContent !== "") return textContent;
	if (element) {
		const children = element.childNodes;
		for (let i = 0; i < children.length; i++) {
			const child = children[i];
			if (child) {
				let childTextContent = child.getAttribute("data-code-text");
				if (childTextContent === null) childTextContent = calculateTextContentFromElement(child);
				textContent += childTextContent;
			}
		}
		return textContent;
	}
	return textContent;
}
var HighlightedLineContext = React.createContext(new ObservableValue(void 0));
HighlightedLineContext.displayName = "HighlightedLineContext";
function HighlightedLinesProvider({ highlightedLines, children }) {
	const highlight = useObservableValue(highlightedLines);
	useEffect(() => {
		highlight.value = highlightedLines;
	}, [highlight, highlightedLines]);
	return /* @__PURE__ */ jsx(HighlightedLineContext, {
		value: highlight,
		children
	});
}
HighlightedLinesProvider.displayName = "HighlightedLinesProvider";
function useHighlightedLinesRange() {
	return useObservedState(React.use(HighlightedLineContext));
}
function useHighlightedLinesInfo(lineNumber) {
	const $ = c(2);
	const highlight = React.use(HighlightedLineContext);
	let t0;
	if ($[0] !== lineNumber) {
		t0 = (h) => h && lineNumber >= h.start.line && lineNumber <= h.end.line ? h : void 0;
		$[0] = lineNumber;
		$[1] = t0;
	} else t0 = $[1];
	return useObservedState(useDerivedObservable(highlight, t0));
}
var positionerID = "copilot-button-positioner";
var portalRootID$1 = "copilot-button-container";
function CopilotButtonContainer({ children }) {
	return /* @__PURE__ */ jsxs("div", {
		id: positionerID,
		className: "position-relative",
		children: [children, /* @__PURE__ */ jsx("div", { id: portalRootID$1 })]
	});
}
CopilotButtonContainer.displayName = "CopilotButtonContainer";
var CopilotButton = React.memo(function CopilotButton(t0) {
	const $ = c(31);
	const { rowBeginNumber, rowEndNumber, id, recalcPosition, ref } = t0;
	const [anchor, setAnchor] = useState(null);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => ({ setAnchor });
		$[0] = t1;
	} else t1 = $[0];
	useImperativeHandle(ref, t1);
	const [position, setPosition] = useState(void 0);
	let t2;
	if ($[1] !== anchor) {
		t2 = () => {
			const changePosition = () => requestAnimationFrame(() => setPosition(calculateCopilotButtonPosition(anchor)));
			changePosition();
			window.addEventListener("resize", changePosition);
			return () => {
				window.removeEventListener("resize", changePosition);
			};
		};
		$[1] = anchor;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== anchor || $[4] !== recalcPosition) {
		t3 = [anchor, recalcPosition];
		$[3] = anchor;
		$[4] = recalcPosition;
		$[5] = t3;
	} else t3 = $[5];
	useLayoutEffect(t2, t3);
	const path = usePath();
	const { copilotAccessAllowed } = useCopilotSettings();
	const refInfo = useRefInfo();
	const selectedBlobRange = useHighlightedLinesRange();
	const repo = useCurrentRepository();
	const { language, languageID, copilotSWEAgentEnabled } = useCurrentBlob();
	let t4;
	if ($[6] !== rowBeginNumber || $[7] !== rowEndNumber) {
		t4 = {
			start: rowBeginNumber,
			end: rowEndNumber
		};
		$[6] = rowBeginNumber;
		$[7] = rowEndNumber;
		$[8] = t4;
	} else t4 = $[8];
	let t5;
	if ($[9] !== refInfo.name || $[10] !== refInfo.refType) {
		t5 = qualifyRef(refInfo.name, refInfo.refType);
		$[9] = refInfo.name;
		$[10] = refInfo.refType;
		$[11] = t5;
	} else t5 = $[11];
	let t6;
	if ($[12] !== language || $[13] !== languageID || $[14] !== path || $[15] !== refInfo.currentOid || $[16] !== repo.id || $[17] !== repo.name || $[18] !== repo.ownerLogin || $[19] !== t4 || $[20] !== t5) {
		t6 = {
			type: "snippet",
			languageID,
			languageName: language,
			path,
			range: t4,
			ref: t5,
			commitOID: refInfo.currentOid,
			repoID: repo.id,
			repoName: repo.name,
			repoOwner: repo.ownerLogin,
			url: window.location.href
		};
		$[12] = language;
		$[13] = languageID;
		$[14] = path;
		$[15] = refInfo.currentOid;
		$[16] = repo.id;
		$[17] = repo.name;
		$[18] = repo.ownerLogin;
		$[19] = t4;
		$[20] = t5;
		$[21] = t6;
	} else t6 = $[21];
	const messageReference = t6;
	const showAgentTaskButton = copilotSWEAgentEnabled;
	let t7;
	if ($[22] !== copilotAccessAllowed || $[23] !== id || $[24] !== messageReference || $[25] !== path || $[26] !== position || $[27] !== repo || $[28] !== selectedBlobRange || $[29] !== showAgentTaskButton) {
		const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
		const element = position === void 0 ? null : jsx("div", {
			style: {
				alignSelf: "center",
				position: "absolute",
				lineHeight: "16px",
				height: "24px",
				width: "24px",
				zIndex: 2,
				...position
			},
			children: jsx(CopilotCodeLinesMenu, {
				copilotAccessAllowed,
				messageReference,
				id,
				showAgentTaskButton,
				currentRepo: repo,
				currentReference: {
					path,
					range: selectedBlobRange ? {
						start: selectedBlobRange.start.line,
						end: selectedBlobRange.end.line
					} : void 0
				},
				decoupledModeEnabled
			})
		});
		const portalRoot = document.getElementById(portalRootID$1);
		t7 = portalRoot ? createPortal(element, portalRoot) : null;
		$[22] = copilotAccessAllowed;
		$[23] = id;
		$[24] = messageReference;
		$[25] = path;
		$[26] = position;
		$[27] = repo;
		$[28] = selectedBlobRange;
		$[29] = showAgentTaskButton;
		$[30] = t7;
	} else t7 = $[30];
	return t7;
});
CopilotButton.displayName = "CopilotButton";
function calculateCopilotButtonPosition(anchor, offset = {
	x: 0,
	y: 0
}) {
	const container = document.getElementById(positionerID);
	if (!anchor || !container) return { display: "none" };
	const { top: anchorTop, height: anchorHeight } = anchor.getBoundingClientRect();
	const { top: tableTop } = container.getBoundingClientRect();
	const topOffset = (25 - anchorHeight) / 2;
	return {
		top: `${anchorTop - tableTop - topOffset + offset.y + 1}px`,
		right: "37px"
	};
}
var MarketplaceEnabledContext = React.createContext(false);
MarketplaceEnabledContext.displayName = "MarketplaceEnabledContext";
function MarketplaceEnabledProvider({ children, isMarketplaceEnabled = false }) {
	return /* @__PURE__ */ jsx(MarketplaceEnabledContext, {
		value: isMarketplaceEnabled,
		children
	});
}
MarketplaceEnabledProvider.displayName = "MarketplaceEnabledProvider";
function useMarketplaceEnabled() {
	return React.use(MarketplaceEnabledContext);
}
var EmptyDeferredMetadata = {
	showLicenseMeta: false,
	license: null,
	codeownerInfo: {
		codeownerPath: null,
		ownedByCurrentUser: null,
		ownersForFile: null,
		ruleForPathLine: null
	},
	newDiscussionPath: null,
	newIssuePath: null
};
var DeferredMetadataContext = React.createContext(EmptyDeferredMetadata);
DeferredMetadataContext.displayName = "DeferredMetadataContext";
function DeferredMetadataProvider({ children, ...props }) {
	return /* @__PURE__ */ jsx(DeferredMetadataContext, {
		value: props,
		children
	});
}
DeferredMetadataProvider.displayName = "DeferredMetadataProvider";
function useDeferredMetadata() {
	return React.use(DeferredMetadataContext);
}
var HighlightedLineMenu_module_default = {
	aiDisclaimer: "HighlightedLineMenu-module_MxKkSW_aiDisclaimer",
	highlightedLineMenuButton: "HighlightedLineMenu-module_MxKkSW_highlightedLineMenuButton"
};
var portalRootID = "highlighted-line-menu-container";
function HighlightedLineMenuContainer({ children }) {
	return /* @__PURE__ */ jsxs("div", {
		id: positionerID$1,
		className: "position-relative",
		children: [children, /* @__PURE__ */ jsx("div", { id: portalRootID })]
	});
}
HighlightedLineMenuContainer.displayName = "HighlightedLineMenuContainer";
var HighlightedLineMenu = React.memo(function HighlightedLineMenuWithRef({ codeLineClassName, offset, lineData, onLineStickOrUnstick, onMenuClose, onCollapseToggle, openOnLoad = false, cursorRef, rowBeginId, rowBeginNumber, rowEndId, rowEndNumber, ref }) {
	const [anchor, setAnchor] = useState(null);
	useImperativeHandle(ref, () => ({ setAnchor }));
	const actionMenuRef = React.useRef(null);
	const { githubDevUrl } = useReposAppPayload();
	const path = usePath();
	const isMarketplaceEnabled = useMarketplaceEnabled();
	const { modelsAccessAllowed } = useCopilotSettings();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	const [visibility, setVisibility] = useState(openOnLoad ? "hidden" : "visible");
	const [position, setPosition] = useState(void 0);
	useLayoutEffect(() => {
		const changePosition = () => {
			setVisibility("hidden");
			requestAnimationFrame(() => {
				setPosition(calculatePosition(anchor, offset));
				setVisibility("visible");
			});
		};
		changePosition();
		ssrSafeWindow?.addEventListener("resize", changePosition);
		return () => {
			ssrSafeWindow?.removeEventListener("resize", changePosition);
		};
	}, [anchor, offset]);
	const [open, setOpen] = React.useState(false);
	const handleOpenOnLoad = useEffectEvent(() => {
		if (openOnLoad) {
			if (cursorRef) setAnchor(cursorRef.current);
			const timeout = window.setTimeout(() => {
				setOpen(true);
			}, 50);
			return () => {
				window.clearTimeout(timeout);
			};
		}
	});
	useLayoutEffect(() => {
		return handleOpenOnLoad();
	}, []);
	const useEndLineNumber = rowBeginId !== rowEndId;
	const { newDiscussionPath, newIssuePath } = useDeferredMetadata();
	const { refSelectorShortcut } = useShortcut();
	const { createPermalink, getUrl } = useUrlCreator();
	const { setShouldBeOpen, expandOrCollapseSection, openUpRefSelector } = useHighlightedLineMenuOptions({
		lineData,
		onLineStickOrUnstick,
		onMenuClose,
		onCollapseToggle,
		setOpen
	});
	const [urlParams] = useSearchParams();
	const isPlain = urlParams.get("plain") === "1";
	const linkHash = `L${rowBeginNumber}${useEndLineNumber ? `-L${rowEndNumber}` : ""}`;
	const permalinkUrl = createPermalink({
		absolute: true,
		params: isPlain ? "plain=1" : void 0,
		hash: linkHash
	});
	const encodedPermalinkUrl = encodeURIComponent(permalinkUrl);
	const element = position === void 0 ? null : /* @__PURE__ */ jsxs(ActionMenu, {
		open,
		onOpenChange: setShouldBeOpen,
		children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			className: clsx(codeLineClassName, HighlightedLineMenu_module_default.highlightedLineMenuButton),
			size: "small",
			icon: KebabHorizontalIcon,
			"aria-label": `Line ${rowBeginNumber} options`,
			"data-testid": "highlighted-line-menu-button",
			style: {
				visibility,
				...position
			}
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			width: "small",
			children: /* @__PURE__ */ jsxs(ActionList, {
				"data-testid": "highlighted-line-menu",
				children: [
					rowBeginNumber === rowEndNumber && /* @__PURE__ */ jsx(ActionList.Item, {
						onClick: () => {
							forceAnnouncementToScreenReaders(`Copied line ${rowBeginNumber}.`);
							const text = calculateTextContentFromElement(ssrSafeDocument?.getElementById(`LC${rowBeginNumber}`) ?? null);
							if (text) copyText(text);
							setShouldBeOpen(false);
						},
						onSelect: () => {
							forceAnnouncementToScreenReaders(`Copied line ${rowBeginNumber}.`);
							const text_0 = calculateTextContentFromElement(ssrSafeDocument?.getElementById(`LC${rowBeginNumber}`) ?? null);
							if (text_0) copyText(text_0);
							setShouldBeOpen(false);
						},
						ref: actionMenuRef,
						className: "highlighted-line-menu-first-option",
						children: "Copy line"
					}),
					rowBeginNumber !== rowEndNumber && /* @__PURE__ */ jsx(ActionList.Item, {
						onClick: () => {
							forceAnnouncementToScreenReaders(`Copied lines ${rowBeginNumber}-${rowEndNumber}.`);
							let text_1 = "";
							for (let i = rowBeginNumber; i <= rowEndNumber; i++) text_1 += `${calculateTextContentFromElement(ssrSafeDocument?.getElementById(`LC${i}`) ?? null)}${i !== rowEndNumber ? "\n" : ""}`;
							if (text_1) copyText(text_1);
							setShouldBeOpen(false);
						},
						onSelect: () => {
							forceAnnouncementToScreenReaders(`Copied lines ${rowBeginNumber}-${rowEndNumber}.`);
							let text_2 = "";
							for (let i_0 = rowBeginNumber; i_0 <= rowEndNumber; i_0++) text_2 += `${calculateTextContentFromElement(ssrSafeDocument?.getElementById(`LC${i_0}`) ?? null)}${i_0 !== rowEndNumber ? "\n" : ""}`;
							if (text_2) copyText(text_2);
							setShouldBeOpen(false);
						},
						className: "highlighted-line-menu-first-option",
						children: "Copy lines"
					}),
					permalinkUrl && /* @__PURE__ */ jsx(ActionList.Item, {
						onClick: () => {
							forceAnnouncementToScreenReaders(`Copied permalink.`);
							copyText(permalinkUrl);
							setShouldBeOpen(false);
						},
						onSelect: () => {
							forceAnnouncementToScreenReaders(`Copied permalink.`);
							copyText(permalinkUrl);
							setShouldBeOpen(false);
						},
						children: "Copy permalink"
					}),
					/* @__PURE__ */ jsx(ActionList.LinkItem, {
						href: getUrl({
							action: "blame",
							hash: linkHash
						}),
						children: "View git blame"
					}),
					newIssuePath && permalinkUrl && /* @__PURE__ */ jsx(ActionList.LinkItem, {
						href: `${newIssuePath}?permalink=${encodedPermalinkUrl}`,
						children: "Reference in new issue"
					}),
					newDiscussionPath && permalinkUrl && /* @__PURE__ */ jsx(ActionList.LinkItem, {
						href: `${newDiscussionPath}?permalink=${encodedPermalinkUrl}`,
						children: "Reference in new discussion"
					}),
					githubDevUrl && /* @__PURE__ */ jsx(ActionList.LinkItem, {
						href: githubDevUrl + ssrSafeWindow?.location.pathname.substring(1),
						children: "View file in GitHub.dev"
					}),
					rowBeginNumber === rowEndNumber && lineData && /* @__PURE__ */ jsxs(ActionList.Item, {
						onClick: expandOrCollapseSection,
						onSelect: expandOrCollapseSection,
						children: [lineData.ownedSection && lineData.ownedSection.collapsed ? "Expand" : "Collapse", " current section"]
					}),
					/* @__PURE__ */ jsxs(ActionList.Item, {
						onClick: openUpRefSelector,
						onSelect: openUpRefSelector,
						children: ["View file in different branch/tag", /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(AllShortcutsEnabled, { children: refSelectorShortcut.text }) })]
					}),
					isMarketplaceEnabled && modelsAccessAllowed && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionMenu.Divider, {}), /* @__PURE__ */ jsxs(ActionList.LinkItem, {
						href: modelPromptPath({
							registry: "azure-openai",
							name: "gpt-4o",
							commit: refInfo.currentOid,
							filePath: path,
							repoOwner: repo.ownerLogin,
							repoName: repo.name,
							beginLine: rowBeginNumber,
							endLine: rowEndNumber
						}),
						target: "_blank",
						children: [/* @__PURE__ */ jsx("p", {
							className: "mb-1",
							children: "Open as prompt in GitHub Models"
						}), /* @__PURE__ */ jsx("span", {
							className: HighlightedLineMenu_module_default.aiDisclaimer,
							children: "This tool uses AI to process your code"
						})]
					})] })
				]
			})
		})]
	});
	const portalRoot = ssrSafeDocument?.getElementById(portalRootID);
	return portalRoot ? createPortal(element, portalRoot) : null;
});
HighlightedLineMenu.displayName = "HighlightedLineMenu";
var LineNumber_module_default = {
	codeAlert: "LineNumber-module_eHRVoa_codeAlert",
	codeAlertRight: "LineNumber-module_eHRVoa_codeAlertRight",
	codeFoldingChevron: "LineNumber-module_eHRVoa_codeFoldingChevron"
};
var LineNumber = React.memo(LineNumberUnmemoized);
LineNumber.displayName = "LineNumber";
function LineNumberUnmemoized({ codeLineData, onClick, ownedCodeSections, onCollapseToggle, preventClick, onLineStickOrUnstick, virtualOffset, copilotAccessAllowed }) {
	const { lineNumber, ownedSection, codeLineClassName, isStartLine, codeownersLineError, hiddenUnicode } = codeLineData;
	const { sendRepoClickEvent } = useReposAnalytics();
	const selectionRef = useCursorSelectionRef();
	const [shouldShowCopilotButton, setShouldShowCopilotButton] = useState(false);
	const codeCellClickFunc = useCallback((event) => {
		if (event.defaultPrevented) return;
		const targetedLineNumber = parseInt(event.currentTarget.getAttribute("data-line-number") || "", 10);
		let anchorInfo = parseFileAnchor(`L${targetedLineNumber}`);
		let highlightStart = void 0;
		let highlightEnd = void 0;
		const cursorSelection = selectionRef.current;
		if (cursorSelection && !(cursorSelection.start.line === cursorSelection.end.line && cursorSelection.start.column === cursorSelection.end.column)) {
			highlightStart = cursorSelection.start;
			highlightEnd = cursorSelection.end;
		} else {
			const selectionRange = window.getSelection()?.rangeCount ? window.getSelection()?.getRangeAt(0) : null;
			if (selectionRange) {
				highlightStart = calculateLineAndColumn(selectionRange.startContainer, selectionRange.startOffset);
				highlightEnd = calculateLineAndColumn(selectionRange.endContainer, selectionRange.endOffset);
			}
		}
		let selection = false;
		if (highlightStart && highlightEnd && highlightStart.line <= targetedLineNumber && highlightEnd.line >= targetedLineNumber) {
			selection = true;
			anchorInfo = {
				anchorPrefix: "",
				blobRange: {
					start: highlightStart,
					end: highlightEnd
				}
			};
		}
		const { blobRange } = anchorInfo;
		const currentLines = parseBlobRange(window.location.hash);
		if (currentLines && event.shiftKey && !selection) {
			sendRepoClickEvent("BLOB.MULTILINE");
			anchorInfo.blobRange = {
				start: currentLines.start,
				end: blobRange.end
			};
		} else sendRepoClickEvent("BLOB.LINE");
		updateUrlHash(formatBlobRangeAnchor(anchorInfo));
		onClick?.(event);
	}, [
		onClick,
		selectionRef,
		sendRepoClickEvent
	]);
	const highlightedInfo = useHighlightedLinesInfo(lineNumber);
	const isFirstHighlightedLine = highlightedInfo?.start.line === lineNumber;
	const isFullyHighlighted = highlightedInfo && highlightedInfo.start.line < lineNumber && highlightedInfo.end.line >= lineNumber || isFirstHighlightedLine && highlightedInfo?.start.column === null;
	const menuAnchorRef = useRef(null);
	const menuRef = useRef(null);
	const copilotMenuRef = useRef(null);
	useLayoutEffect(() => {
		if (isFirstHighlightedLine) menuRef.current?.setAnchor(menuAnchorRef.current);
	}, [isFirstHighlightedLine]);
	const { codeFoldingOption } = useCodeViewOptions();
	const showCodeFoldingIcon = codeFoldingOption.enabled;
	useEffect(() => {
		if (!codeFoldingOption.enabled) {
			expandAllRows();
			onCollapseToggle?.(false);
			if (ownedSection) ownedSection.collapsed = false;
		}
	}, [
		codeFoldingOption.enabled,
		ownedSection,
		onCollapseToggle
	]);
	const mouseCallback = (isEnter) => {
		if (copilotAccessAllowed) {
			setShouldShowCopilotButton(isEnter);
			setTimeout(() => copilotMenuRef.current?.setAnchor(isEnter ? menuAnchorRef.current : null), 0);
		}
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs("div", {
			ref: menuAnchorRef,
			"data-line-number": lineNumber,
			className: clsx(codeLineClassName, "react-line-number react-code-text", virtualOffset && "virtual", preventClick && "prevent-click", isFullyHighlighted && "highlighted-line"),
			style: virtualOffset ? {
				paddingRight: "16px",
				transform: `translateY(${virtualOffset}px)`
			} : { paddingRight: "16px" },
			onMouseDown: preventClick ? void 0 : codeCellClickFunc,
			onMouseEnter: copilotAccessAllowed ? () => mouseCallback(true) : void 0,
			onMouseLeave: copilotAccessAllowed ? () => mouseCallback(false) : void 0,
			children: [
				lineNumber,
				codeownersLineError && /* @__PURE__ */ jsx(CodeAlert, { children: /* @__PURE__ */ jsx(CodeownersErrorLineIndicator, {}) }),
				hiddenUnicode && /* @__PURE__ */ jsx(CodeAlert, { children: /* @__PURE__ */ jsx(HiddenUnicodeTooltip, {}) }),
				showCodeFoldingIcon && isStartLine && ownedSection && ownedCodeSections && /* @__PURE__ */ jsx(CodeAlert, {
					displayRight: true,
					children: /* @__PURE__ */ jsx(CodeFoldingChevron, {
						codeLineData,
						onCollapseToggle,
						onLineStickOrUnstick
					})
				})
			]
		}),
		isFirstHighlightedLine && /* @__PURE__ */ jsx(HighlightedLineMenu, {
			codeLineClassName,
			ref: menuRef,
			rowBeginId: `LG${highlightedInfo.start.line}`,
			rowBeginNumber: highlightedInfo.start.line,
			rowEndNumber: highlightedInfo.end.line,
			rowEndId: `LG${highlightedInfo.end.line}`
		}),
		copilotAccessAllowed && shouldShowCopilotButton && /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(CopilotButton, {
			ref: copilotMenuRef,
			rowBeginNumber: lineNumber,
			rowEndNumber: lineNumber,
			id: "code-line-copilot-button"
		}) })
	] });
}
LineNumberUnmemoized.displayName = "LineNumberUnmemoized";
function CodeAlert({ children, displayRight }) {
	return /* @__PURE__ */ jsx("span", {
		className: clsx(LineNumber_module_default.codeAlert, displayRight && LineNumber_module_default.codeAlertRight),
		children
	});
}
CodeAlert.displayName = "CodeAlert";
function CodeFoldingChevron({ codeLineData, onCollapseToggle, onLineStickOrUnstick }) {
	const collapsed = useIsLineCollapsed(codeLineData.lineNumber);
	const expand = useCallback((event) => {
		const { lineNumber, ownedSection } = codeLineData;
		if (ownedSection) ownedSection.collapsed = false;
		onCollapseToggle?.(false);
		expandRow(lineNumber);
		onLineStickOrUnstick?.(codeLineData, true);
		event.preventDefault();
	}, [
		codeLineData,
		onCollapseToggle,
		onLineStickOrUnstick
	]);
	const collapse = useCallback((event_0) => {
		const { lineNumber: lineNumber_0, ownedSection: ownedSection_0 } = codeLineData;
		if (ownedSection_0) ownedSection_0.collapsed = true;
		onCollapseToggle?.(true);
		collapseRow(lineNumber_0);
		event_0.preventDefault();
	}, [codeLineData, onCollapseToggle]);
	return collapsed ? /* @__PURE__ */ jsx("div", {
		"aria-label": "Expand code section",
		onMouseDown: expand,
		role: "button",
		tabIndex: 0,
		className: LineNumber_module_default.codeFoldingChevron,
		children: /* @__PURE__ */ jsx(Octicon, { icon: ChevronRightIcon })
	}) : /* @__PURE__ */ jsx("div", {
		"aria-label": "Collapse code section",
		onMouseDown: collapse,
		role: "button",
		tabIndex: 0,
		className: LineNumber_module_default.codeFoldingChevron,
		children: /* @__PURE__ */ jsx(Octicon, { icon: ChevronDownIcon })
	});
}
CodeFoldingChevron.displayName = "CodeFoldingChevron";
var CodeLines = React.memo(CodeLinesUnmemoized);
CodeLines.displayName = "CodeLines";
function CodeLinesUnmemoized({ linesData, onLineNumberClick, codeSections, codeLineToSectionMap, onLineStickOrUnstick, sharedLineObserver, tabSize, contentWidth, onCollapseToggle, cursorContainerRef, textAreaRef, materializeAllLines, copilotAccessAllowed, ref }) {
	const parentRef = useRef(null);
	const scrollContainerRef = useRef(null);
	const horizontalScrollBarRef = useRef(null);
	const shouldUseCursor = useIsCursorEnabled();
	const setNextTextAreaScroll = useRef(true);
	const setNextScrollBarScroll = useRef(true);
	const setNextScrollContainerScroll = useRef(true);
	const { stylingDirectives } = useDeferredAST();
	useEffect(() => {
		if (textAreaRef && textAreaRef.current) {
			textAreaRef.current.onscroll = () => {
				if (scrollContainerRef.current && textAreaRef?.current) {
					if (!setNextScrollContainerScroll.current) {
						setNextScrollContainerScroll.current = true;
						return;
					}
					if (textAreaRef.current.scrollLeft === scrollContainerRef.current.scrollLeft) return;
					setNextTextAreaScroll.current = !(setNextScrollBarScroll.current && setNextScrollContainerScroll.current);
					scrollContainerRef.current.scrollLeft = textAreaRef.current.scrollLeft;
				}
				if (cursorContainerRef && cursorContainerRef.current && textAreaRef?.current) cursorContainerRef.current.scrollLeft = textAreaRef.current.scrollLeft;
			};
			const textRef = textAreaRef.current;
			return () => {
				if (textRef) textRef.onscroll = null;
			};
		}
	}, [
		textAreaRef,
		parentRef,
		shouldUseCursor,
		cursorContainerRef
	]);
	const wrapOptionEnabled = useCodeViewOptions().codeWrappingOption.enabled;
	const shouldUseInert = useShouldUseInert();
	const { virtualizer, currentLineHeight } = useVirtualCodeBlob({
		parentRef,
		lineCount: linesData.length,
		materializeAllLines: !!materializeAllLines
	});
	useEffect(() => {
		virtualizer.measure();
	}, [wrapOptionEnabled, virtualizer]);
	useImperativeHandle(ref, () => ({
		scrollToTop: () => {
			if (isLineInViewport(0)) return;
			virtualizer.scrollToIndex(0, { align: "start" });
		},
		scrollToLine: (lineNumber, column) => {
			virtualizer.scrollToIndex(lineNumber, { align: "start" });
			const container = parentRef.current;
			if (!container) return;
			container.scroll({ left: getHorizontalScrollOffset(container, lineNumber, column) });
		}
	}));
	return /* @__PURE__ */ jsxs("div", {
		ref: parentRef,
		style: { pointerEvents: shouldUseCursor ? "none" : "auto" },
		onScroll: (event) => handleBlobScrollSync(event, textAreaRef),
		children: [/* @__PURE__ */ jsx("div", {
			className: clsx("react-code-line-container", shouldUseCursor ? CodeLines_module_default.scrollContainerHidden : CodeLines_module_default.scrollContainerAuto),
			ref: scrollContainerRef,
			tabIndex: 0,
			onScroll: () => {
				if (shouldUseCursor && scrollContainerRef.current && horizontalScrollBarRef.current) {
					if (!setNextScrollBarScroll.current) {
						setNextScrollBarScroll.current = true;
						return;
					}
					if (horizontalScrollBarRef.current.scrollLeft === scrollContainerRef.current.scrollLeft) return;
					setNextScrollContainerScroll.current = !(setNextScrollBarScroll.current && setNextTextAreaScroll.current);
					horizontalScrollBarRef.current.scrollLeft = scrollContainerRef.current.scrollLeft;
				}
			},
			children: /* @__PURE__ */ jsxs("div", {
				className: clsx("react-code-file-contents", CodeLines_module_default.codeFileContents),
				role: "presentation",
				"aria-hidden": true,
				"data-tab-size": tabSize,
				"data-testid": "code-lines-container",
				"data-paste-markdown-skip": true,
				style: {
					tabSize,
					width: contentWidth,
					maxWidth: wrapOptionEnabled ? "100%" : "unset",
					height: virtualizer.getTotalSize()
				},
				"data-hpc": true,
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "react-line-numbers",
						style: {
							pointerEvents: "auto",
							height: virtualizer.getTotalSize(),
							position: "relative",
							zIndex: 2
						},
						children: virtualizer.getVirtualItems().map((virtualItem) => {
							const lineData = linesData[virtualItem.index];
							return /* @__PURE__ */ jsx(LineNumber, {
								codeLineData: lineData,
								onClick: onLineNumberClick,
								ownedCodeSections: codeSections,
								onLineStickOrUnstick,
								onCollapseToggle,
								virtualOffset: virtualItem.start,
								copilotAccessAllowed
							}, lineData.lineNumber);
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "react-code-lines",
						style: { height: virtualizer.getTotalSize() },
						children: virtualizer.getVirtualItems().map((virtualItem_0) => {
							const lineData_0 = linesData[virtualItem_0.index];
							return /* @__PURE__ */ jsx(CodeLine, {
								codeLineData: lineData_0,
								stylingDirectivesLine: lineData_0.stylingDirectivesLine ?? (stylingDirectives ? stylingDirectives[lineData_0.lineNumber - 1] : void 0),
								shouldUseInert,
								codeLineClassName: lineData_0.codeLineClassName,
								id: `LC${lineData_0.lineNumber}`,
								onLineStickOrUnstick,
								sharedLineObserver,
								setIsCollapsed: onCollapseToggle,
								codeLineToSectionMap,
								virtualOffset: virtualItem_0.start,
								virtualKey: String(virtualItem_0.key),
								copilotAccessAllowed,
								currentLineHeight,
								measureRef: wrapOptionEnabled ? virtualizer.measureElement : void 0,
								virtualIndex: wrapOptionEnabled ? virtualItem_0.index : void 0
							}, lineData_0.lineNumber);
						})
					}),
					/* @__PURE__ */ jsx(SelectAllShortcutButton, {
						shouldNotOverrideCopy: shouldUseCursor,
						containerRef: shouldUseCursor ? textAreaRef : parentRef
					}),
					!wrapOptionEnabled && /* @__PURE__ */ jsx(CodeFoldingEllipsisOverlay, {
						linesData,
						onLineStickOrUnstick,
						setIsCollapsed: onCollapseToggle,
						tabSize,
						extraLeftPadding: 82
					})
				]
			})
		}), shouldUseCursor && contentWidth && scrollContainerRef.current && scrollContainerRef.current.clientWidth < contentWidth ? /* @__PURE__ */ jsx("div", {
			className: CodeLines_module_default.scrollBarContainer,
			onScroll: () => {
				if (horizontalScrollBarRef.current && textAreaRef?.current) {
					if (!setNextTextAreaScroll.current) {
						setNextTextAreaScroll.current = true;
						return;
					}
					if (horizontalScrollBarRef.current.scrollLeft === textAreaRef.current.scrollLeft) return;
					setNextScrollBarScroll.current = !(setNextScrollContainerScroll.current && setNextTextAreaScroll.current);
					textAreaRef.current.scrollLeft = horizontalScrollBarRef.current.scrollLeft;
				}
			},
			ref: horizontalScrollBarRef,
			onClick: (ev) => ev.preventDefault(),
			onMouseDown: (ev_0) => ev_0.preventDefault(),
			onMouseUp: (ev_1) => ev_1.preventDefault(),
			children: /* @__PURE__ */ jsx("div", {
				className: CodeLines_module_default.scrollBarSpacer,
				style: { width: contentWidth }
			})
		}) : null]
	});
}
CodeLinesUnmemoized.displayName = "CodeLinesUnmemoized";
function handleBlobScrollSync(event, textAreaRef) {
	const scrolledElement = event.target;
	textAreaRef?.current?.scrollTo(scrolledElement.scrollLeft, scrolledElement.scrollTop);
}
function getHorizontalScrollOffset(container, lineNumber, column) {
	if (!column) return 0;
	const element = queryMatchElement(lineNumber, column);
	if (!element) return 0;
	const containerRect = container.getBoundingClientRect();
	const elementRect = element.getBoundingClientRect();
	return containerRect.left + containerRect.width - container.scrollLeft - (elementRect.left + elementRect.width) > 0 ? 0 : element.offsetLeft;
}
var HighlightedLinesOverlay_module_default = {
	lineHighlight: "HighlightedLinesOverlay-module_RI3e_W_lineHighlight",
	lineHighlightActive: "HighlightedLinesOverlay-module_RI3e_W_lineHighlightActive",
	lineHighlightSubtle: "HighlightedLinesOverlay-module_RI3e_W_lineHighlightSubtle"
};
function HighlightedLinesOverlay({ linesData, copilotAccessAllowed }) {
	const range = useHighlightedLinesRange();
	const { tabSize } = useCurrentBlob();
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	const isSafari = useIsSafari();
	const anchorRef = useRef(null);
	const menuRef = useRef(null);
	const startLine = range ? getActualLineNumberBinarySearch(range.start.line, linesData) : 0;
	const endLine = range?.end.line ? getActualLineNumberBinarySearch(range.end.line, linesData) : startLine;
	const [copilotButtonOffsetTop, setCopilotButtonOffsetTop] = useState(isSafari ? startLine * lineHeight - 3 : startLine * lineHeight);
	useLayoutEffect(() => {
		if (!range) return;
		menuRef.current?.setAnchor(anchorRef.current);
		setCopilotButtonOffsetTop(isSafari ? startLine * lineHeight - 3 : startLine * lineHeight);
	}, [
		range,
		isSafari,
		lineHeight,
		startLine
	]);
	if (!range) return null;
	const highlightPositions = [];
	for (let lineNumber = startLine; lineNumber <= endLine; lineNumber++) {
		const element = queryLineElement("", lineNumber + 1);
		if (!element) continue;
		const position = calculateHighlightOffsetAndWidth(range, element, lineNumber + 1, tabSize, linesData[lineNumber + 1]?.rawText ?? "") ?? {};
		highlightPositions.push({
			position,
			lineNumber
		});
	}
	return /* @__PURE__ */ jsxs("div", {
		ref: anchorRef,
		style: {
			position: "relative",
			top: copilotButtonOffsetTop + 10
		},
		children: [highlightPositions.map(({ position: position_0, lineNumber: lineNumber_0 }) => /* @__PURE__ */ jsx(LineHighlight, {
			highlightPosition: position_0,
			lineNumber: lineNumber_0,
			startingLineNumber: startLine
		}, `line-${lineNumber_0}-highlight-${position_0.offset}`)), copilotAccessAllowed && /* @__PURE__ */ jsx(CopilotButton, {
			ref: menuRef,
			rowBeginNumber: range.start.line,
			rowEndNumber: range.end.line,
			recalcPosition: copilotButtonOffsetTop,
			id: "code-line-copilot-button"
		})]
	});
}
HighlightedLinesOverlay.displayName = "HighlightedLinesOverlay";
function LineHighlight(t0) {
	const $ = c(6);
	const { startingLineNumber, lineNumber, highlightPosition, subtle } = t0;
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	const topOffset = (lineNumber - startingLineNumber) * lineHeight;
	let t1;
	if ($[0] !== highlightPosition || $[1] !== lineHeight || $[2] !== lineNumber || $[3] !== subtle || $[4] !== topOffset) {
		t1 = jsx("div", {
			className: clsx("line-highlight", subtle ? HighlightedLinesOverlay_module_default.lineHighlightSubtle : HighlightedLinesOverlay_module_default.lineHighlightActive, HighlightedLinesOverlay_module_default.lineHighlight),
			style: {
				height: lineHeight,
				left: highlightPosition && highlightPosition.offset ? `${highlightPosition.offset - 10}px` : "-82px",
				top: `${topOffset - 10}px`,
				width: highlightPosition && highlightPosition.width ? `${highlightPosition.width + 82}px` : "calc(100% + 82px)"
			}
		}, `highlighted-line-${lineNumber}`);
		$[0] = highlightPosition;
		$[1] = lineHeight;
		$[2] = lineNumber;
		$[3] = subtle;
		$[4] = topOffset;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
LineHighlight.displayName = "LineHighlight";
var SearchResultsContext = createContext({
	resultsByLineNumber: new ObservableMap(),
	focusedResult: new ObservableValue(void 0)
});
SearchResultsContext.displayName = "SearchResultsContext";
function SearchResultsProvider({ searchResults, focusedSearchResult, children }) {
	const resultsByLineNumber = useObservableMap();
	const focusedResult = useObservableValue(focusedSearchResult !== void 0 ? searchResults[focusedSearchResult] : void 0);
	useEffect(() => {
		const newMap = /* @__PURE__ */ new Map();
		for (const searchResult of searchResults) {
			const lineNumber = searchResult.lineNumber;
			if (newMap.has(lineNumber)) newMap.get(lineNumber).push(searchResult);
			else newMap.set(lineNumber, [searchResult]);
		}
		resultsByLineNumber.clear();
		for (const [lineNumber_0, resultsForLine] of newMap) resultsByLineNumber.set(lineNumber_0, resultsForLine);
	}, [resultsByLineNumber, searchResults]);
	useEffect(() => {
		focusedResult.value = focusedSearchResult !== void 0 ? searchResults[focusedSearchResult] : void 0;
	}, [
		searchResults,
		focusedResult,
		focusedSearchResult
	]);
	return /* @__PURE__ */ jsx(SearchResultsContext, {
		value: useMemo(() => ({
			resultsByLineNumber,
			focusedResult
		}), [resultsByLineNumber, focusedResult]),
		children
	});
}
SearchResultsProvider.displayName = "SearchResultsProvider";
function useAllSearchResults() {
	const { resultsByLineNumber } = use(SearchResultsContext);
	return useObservedStateMap(resultsByLineNumber);
}
function useSearchResults(lineNumber) {
	const $ = c(3);
	const { resultsByLineNumber } = use(SearchResultsContext);
	let t0;
	if ($[0] !== lineNumber || $[1] !== resultsByLineNumber) {
		t0 = resultsByLineNumber.get(lineNumber);
		$[0] = lineNumber;
		$[1] = resultsByLineNumber;
		$[2] = t0;
	} else t0 = $[2];
	return useObservedState(t0);
}
function useFocusedSearchResult(lineNumber) {
	const $ = c(2);
	const { focusedResult } = use(SearchResultsContext);
	let t0;
	if ($[0] !== lineNumber) {
		t0 = (result) => result?.lineNumber === lineNumber ? result : void 0;
		$[0] = lineNumber;
		$[1] = t0;
	} else t0 = $[1];
	return useObservedState(useDerivedObservable(focusedResult, t0));
}
function useFocusedSearchResultWithoutLineCheck() {
	const { focusedResult } = use(SearchResultsContext);
	return useObservedState(focusedResult);
}
function HighlightedSymbolsOverlay(t0) {
	const $ = c(5);
	const { linesData } = t0;
	const results = useAllSearchResults();
	const focusedResult = useFocusedSearchResultWithoutLineCheck();
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	let t1;
	if ($[0] !== focusedResult || $[1] !== lineHeight || $[2] !== linesData || $[3] !== results) {
		t1 = jsx(Fragment$1, { children: [...results.values()].map((definitionsOrReferences) => {
			const lineNumber = definitionsOrReferences[0]?.lineNumber;
			if (lineNumber === void 0) return null;
			const actualLineNumber = getActualLineNumberBinarySearch(lineNumber, linesData) + 1;
			return jsx(HighlightedOverlay, {
				className: "symbol-highlight react-code-text",
				lineNumber: actualLineNumber,
				symbols: definitionsOrReferences,
				focusedSymbol: focusedResult,
				style: {
					position: "absolute",
					top: lineHeight * (actualLineNumber - 1),
					paddingLeft: "10px",
					height: lineHeight,
					whiteSpace: "pre"
				}
			}, `overlay-${actualLineNumber}-lineNumber-no-virtualization`);
		}) });
		$[0] = focusedResult;
		$[1] = lineHeight;
		$[2] = linesData;
		$[3] = results;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
HighlightedSymbolsOverlay.displayName = "HighlightedSymbolsOverlay";
var LineNumberNoVirtualziation = React.memo(LineNumberNoVirtualizationUnmemoized);
LineNumberNoVirtualziation.displayName = "LineNumberNoVirtualziation";
function LineNumberNoVirtualizationUnmemoized({ codeLineData, onClick, ownedCodeSections, onCollapseToggle, preventClick, onLineStickOrUnstick, virtualOffset, copilotAccessAllowed }) {
	const { lineNumber, ownedSection, codeLineClassName, isStartLine, codeownersLineError, hiddenUnicode } = codeLineData;
	const { sendRepoClickEvent } = useReposAnalytics();
	const selectionRef = useCursorSelectionRef();
	const codeCellClickFunc = useCallback((event) => {
		if (event.defaultPrevented) return;
		const targetedLineNumber = parseInt(event.currentTarget.getAttribute("data-line-number") || "", 10);
		let anchorInfo = parseFileAnchor(`L${targetedLineNumber}`);
		let highlightStart = void 0;
		let highlightEnd = void 0;
		const cursorSelection = selectionRef.current;
		if (cursorSelection && !(cursorSelection.start.line === cursorSelection.end.line && cursorSelection.start.column === cursorSelection.end.column)) {
			highlightStart = cursorSelection.start;
			highlightEnd = cursorSelection.end;
		} else {
			const selectionRange = window.getSelection()?.rangeCount ? window.getSelection()?.getRangeAt(0) : null;
			if (selectionRange) {
				highlightStart = calculateLineAndColumn(selectionRange.startContainer, selectionRange.startOffset);
				highlightEnd = calculateLineAndColumn(selectionRange.endContainer, selectionRange.endOffset);
			}
		}
		let selection = false;
		if (highlightStart && highlightEnd && highlightStart.line <= targetedLineNumber && highlightEnd.line >= targetedLineNumber) {
			selection = true;
			anchorInfo = {
				anchorPrefix: "",
				blobRange: {
					start: highlightStart,
					end: highlightEnd
				}
			};
		}
		const { blobRange } = anchorInfo;
		const currentLines = parseBlobRange(window.location.hash);
		if (currentLines && event.shiftKey && !selection) {
			sendRepoClickEvent("BLOB.MULTILINE");
			anchorInfo.blobRange = {
				start: currentLines.start,
				end: blobRange.end
			};
		} else sendRepoClickEvent("BLOB.LINE");
		updateUrlHash(formatBlobRangeAnchor(anchorInfo));
		onClick?.(event);
	}, [
		onClick,
		selectionRef,
		sendRepoClickEvent
	]);
	const highlightedInfo = useHighlightedLinesInfo(lineNumber);
	const isFirstHighlightedLine = highlightedInfo?.start.line === lineNumber;
	const isFullyHighlighted = highlightedInfo && highlightedInfo.start.line < lineNumber && highlightedInfo.end.line >= lineNumber || isFirstHighlightedLine && highlightedInfo?.start.column === null;
	const menuAnchorRef = useRef(null);
	const menuRef = useRef(null);
	const copilotMenuRef = useRef(null);
	const [shouldShowCopilotButton, setShouldShowCopilotButton] = useState(false);
	useLayoutEffect(() => {
		if (isFirstHighlightedLine) menuRef.current?.setAnchor(menuAnchorRef.current);
	}, [isFirstHighlightedLine]);
	const { codeFoldingOption } = useCodeViewOptions();
	const showCodeFoldingIcon = codeFoldingOption.enabled;
	const mouseCallback = (isEnter) => {
		if (copilotAccessAllowed) {
			setShouldShowCopilotButton(isEnter);
			setTimeout(() => copilotMenuRef.current?.setAnchor(isEnter ? menuAnchorRef.current : null), 0);
		}
	};
	useEffect(() => {
		if (!codeFoldingOption.enabled) {
			expandAllRows();
			onCollapseToggle?.(false);
			if (ownedSection) ownedSection.collapsed = false;
		}
	}, [
		codeFoldingOption.enabled,
		ownedSection,
		onCollapseToggle
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs("div", {
			ref: (ref) => {
				menuAnchorRef.current = ref;
			},
			"data-line-number": lineNumber,
			className: clsx(codeLineClassName, "react-line-number react-code-text", virtualOffset && "virtual", preventClick && "prevent-click", isFullyHighlighted && "highlighted-line"),
			style: virtualOffset ? {
				paddingRight: "16px",
				transform: `translateY(${virtualOffset}px)`
			} : { paddingRight: "16px" },
			onMouseDown: preventClick ? void 0 : codeCellClickFunc,
			onMouseEnter: copilotAccessAllowed ? () => mouseCallback(true) : void 0,
			onMouseLeave: copilotAccessAllowed ? () => mouseCallback(false) : void 0,
			children: [
				lineNumber,
				codeownersLineError && /* @__PURE__ */ jsx(CodeAlert, { children: /* @__PURE__ */ jsx(CodeownersErrorLineIndicator, {}) }),
				hiddenUnicode && /* @__PURE__ */ jsx(CodeAlert, { children: /* @__PURE__ */ jsx(HiddenUnicodeTooltip, {}) }),
				showCodeFoldingIcon && isStartLine && ownedSection && ownedCodeSections && /* @__PURE__ */ jsx(CodeAlert, {
					displayRight: true,
					children: /* @__PURE__ */ jsx(CodeFoldingChevron, {
						codeLineData,
						onCollapseToggle,
						onLineStickOrUnstick
					})
				})
			]
		}),
		isFirstHighlightedLine && /* @__PURE__ */ jsx(HighlightedLineMenu, {
			codeLineClassName,
			ref: menuRef,
			rowBeginId: `LG${highlightedInfo.start.line}`,
			rowBeginNumber: highlightedInfo.start.line,
			rowEndNumber: highlightedInfo.end.line,
			rowEndId: `LG${highlightedInfo.end.line}`
		}),
		copilotAccessAllowed && shouldShowCopilotButton && /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(CopilotButton, {
			ref: copilotMenuRef,
			rowBeginNumber: lineNumber,
			rowEndNumber: lineNumber,
			id: "code-line-copilot-button"
		}) })
	] });
}
LineNumberNoVirtualizationUnmemoized.displayName = "LineNumberNoVirtualizationUnmemoized";
var StickyLineObserverOverlay_module_default = { stickyLineObserver: "StickyLineObserverOverlay-module_H76pSa_stickyLineObserver" };
function StickyLineObserverOverlay(t0) {
	const $ = c(5);
	const { linesData, sharedLineObserver, codeLineToSectionMap } = t0;
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	if (codeLineToSectionMap === void 0) return null;
	let t1;
	if ($[0] !== codeLineToSectionMap || $[1] !== lineHeight || $[2] !== linesData || $[3] !== sharedLineObserver) {
		t1 = jsx(Fragment$1, { children: linesData.map((lineData) => {
			const lineNumber = lineData.lineNumber;
			const numParents = codeLineToSectionMap?.get(lineNumber)?.length ?? 0;
			if (lineNumber === void 0 || lineData.ownedSection === void 0) return null;
			const actualLineNumber = getActualLineNumberBinarySearch(lineNumber, linesData);
			return jsx(StickyLineObserverLine, {
				className: "symbol-highlight react-code-text",
				lineData: linesData[actualLineNumber],
				sharedLineObserver,
				numParents,
				style: {
					top: lineHeight * (actualLineNumber - 1),
					height: lineHeight
				}
			}, `observer-overlay-${actualLineNumber}-lineNumber-no-virtualization`);
		}) });
		$[0] = codeLineToSectionMap;
		$[1] = lineHeight;
		$[2] = linesData;
		$[3] = sharedLineObserver;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
StickyLineObserverOverlay.displayName = "StickyLineObserverOverlay";
function StickyLineObserverLine(t0) {
	const $ = c(6);
	const { lineData, sharedLineObserver, numParents, className, style } = t0;
	const refCallback = useRegisterLineObserver(sharedLineObserver, lineData, numParents);
	let t1;
	if ($[0] !== refCallback) {
		t1 = (ref) => {
			refCallback(ref);
		};
		$[0] = refCallback;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== className || $[3] !== style || $[4] !== t1) {
		t2 = jsx("div", {
			ref: t1,
			className: clsx(className, StickyLineObserverOverlay_module_default.stickyLineObserver),
			style,
			"data-testid": "sticky-line-observer"
		});
		$[2] = className;
		$[3] = style;
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
StickyLineObserverLine.displayName = "StickyLineObserverLine";
function buildCodeHTML(rawText, directives, strategy, tabSize, exposeHiddenUnicodeCharacters) {
	rawText ||= "\n";
	const normalizedDirectives = parseDirectives(directives ?? []);
	const tree = makeSyntaxTree(rawText, normalizedDirectives, strategy, tabSize);
	const out = [];
	appendHTMLNodesForSubtree(tree, strategy, exposeHiddenUnicodeCharacters, out);
	return out.join("");
}
function appendHTMLNodesForSubtree(node, strategy, exposeHiddenUnicodeCharacters, out) {
	if (node.c) out.push(`<span class="${escapeHTML(node.c)}">`);
	for (const child of node.nodes) if (isTree(child)) appendHTMLNodesForSubtree(child, strategy, exposeHiddenUnicodeCharacters, out);
	else out.push(makeHTMLToken(child, strategy, exposeHiddenUnicodeCharacters));
	if (node.c) out.push(`</span>`);
}
function makeHTMLToken(node, strategy, exposeHiddenUnicodeCharacters) {
	switch (strategy) {
		case "data-attribute": {
			const text = escapeHTML(node.text);
			if (exposeHiddenUnicodeCharacters && hasHiddenUnicodeCharacters$1(text)) {
				const children = splitAroundHiddenUnicodeCharacters$1(text).map((segment) => {
					const hiddenUnicodeReplacement = getHiddenUnicodeReplacement(segment);
					return hiddenUnicodeReplacement ? hiddenUnicodeCharacterHTMLString(hiddenUnicodeReplacement) : makeHTMLToken({
						...node,
						text: segment,
						c: ""
					}, strategy, false);
				});
				return node.c ? `<span class="${escapeHTML(node.c)}">${children.join("")}</span>` : children.join("");
			}
			return node.c ? `<span class="${escapeHTML(node.c)}" data-code-text="${text}"></span>` : `<span data-code-text="${text}"></span>`;
		}
		case "separated-characters-chunked":
		case "separated-characters": {
			if (node.text && !node.text.trim()) return makeHTMLToken({ ...node }, "data-attribute", exposeHiddenUnicodeCharacters);
			let nodeText = [...node.text];
			if (strategy === "separated-characters-chunked" && !exposeHiddenUnicodeCharacters) nodeText = node.text.match(/.{1,2}/g) ?? nodeText;
			const separatedText = [...nodeText].map((char) => {
				const hiddenUnicodeReplacement = exposeHiddenUnicodeCharacters ? getHiddenUnicodeReplacement(char) : void 0;
				return hiddenUnicodeReplacement ? hiddenUnicodeCharacterHTMLString(hiddenUnicodeReplacement) : `<span data-code-text="${escapeHTML(char)}"></span>`;
			}).join("");
			return node.c ? `<span class="${escapeHTML(node.c)}">${separatedText}</span>` : separatedText;
		}
		default: {
			const text = escapeHTML(node.text);
			const contents = exposeHiddenUnicodeCharacters ? showHiddenUnicodeCharactersHTML(text) ?? text : text;
			return node.c ? `<span class="${escapeHTML(node.c)}">${contents}</span>` : contents;
		}
	}
}
function makeSyntaxTree(rawText, stylingDirectivesLine, strategy, tabSize) {
	const offset = { value: 0 };
	const tree = {
		nodes: [],
		s: 0,
		e: rawText.length,
		c: ""
	};
	const directives = stylingDirectivesLine?.filter((dir) => dir.e > dir.s);
	if (!directives || directives.length === 0) {
		tree.nodes.push(makeNode("", rawText, 0, rawText.length, offset, tabSize, strategy));
		return tree;
	}
	const currentParentStack = [tree];
	for (let i = 0; i < directives.length; i++) {
		const current = directives[i];
		const next = directives[i + 1];
		let parent = currentParentStack[currentParentStack.length - 1] ?? tree;
		const previous = parent.nodes[parent.nodes.length - 1];
		if (parent.nodes.length === 0 && current.s > parent.s) {
			const beginningOfParent = makeNode("", rawText, parent.s, current.s, offset, tabSize, strategy);
			parent.nodes.push(beginningOfParent);
		} else if (previous && current.s > previous.e) {
			const inBetween = makeNode("", rawText, previous.e, current.s, offset, tabSize, strategy);
			parent.nodes.push(inBetween);
		}
		if (next && next.s < current.e) {
			const newContainer = {
				...current,
				nodes: []
			};
			parent.nodes.push(newContainer);
			currentParentStack.push(newContainer);
		} else {
			const newNode = makeNode(current.c, rawText, current.s, current.e, offset, tabSize, strategy);
			parent.nodes.push(newNode);
		}
		if (next && next.s >= parent.e) {
			let previousParentEnd = current.e;
			if (parent.e > previousParentEnd) {
				const restOfCurrentParent = makeNode("", rawText, previousParentEnd, parent.e, offset, tabSize, strategy);
				parent.nodes.push(restOfCurrentParent);
				previousParentEnd = parent.e;
			}
			while (currentParentStack.length > 1 && next.s >= parent.e) {
				currentParentStack.pop();
				parent = currentParentStack[currentParentStack.length - 1] ?? tree;
				if (currentParentStack.length > 1 && next.s >= parent.e && parent.e > previousParentEnd) {
					const restOfCurrentParent = makeNode("", rawText, previousParentEnd, parent.e, offset, tabSize, strategy);
					previousParentEnd = parent.e;
					parent.nodes.push(restOfCurrentParent);
				}
			}
		}
	}
	while (currentParentStack.length > 0) {
		const parent = currentParentStack.pop();
		const lastNode = parent.nodes[parent.nodes.length - 1];
		if (lastNode && lastNode.e < parent.e) {
			const restOfParent = makeNode("", rawText, lastNode.e, parent.e, offset, tabSize, strategy);
			parent.nodes.push(restOfParent);
		}
	}
	return tree;
}
function makeNode(cssClass, rawText, start, end, offset, tabSize, strategy) {
	const substring = rawText.substring(start, end);
	return {
		c: cssClass,
		s: start,
		e: end,
		text: strategy !== "plain" ? convertTabsToSpaces(substring, tabSize, offset) : substring
	};
}
function isTree(node) {
	return "nodes" in node;
}
/**
* Converts a string containing tabs to a string where all tabs have been
* replaced with the appropriate number of spaces.
*
* @param text The string to convert
* @param tabSize The number of character widths between tab stops
* @param offset The position on a line at which the string begins
*
* @remarks
* This is necessary because our html format with no text nodes uses css to
* put the code text on the page. Unfortunately, the browser does not interpret
* the css-inserted text of adjacent nodes as being part of the same contiguous
* block of text. That means that each node is treated as if it were at the
* start of a line, so tabs do not necessarily get the correct width.
* Converting them to the right number of spaces here fixes the problem. This
* does not affect copying/pasting code correctly because the
* syntax-highlighted overlay is not selectable.
*/
function convertTabsToSpaces(text, tabSize, offset) {
	const out = [];
	for (const char of text) if (char === "	") {
		const numSpaces = tabSize - offset.value % tabSize;
		out.push(spaces(numSpaces));
		offset.value += numSpaces;
	} else {
		out.push(char);
		offset.value += numberOfCodePoints(char);
	}
	return out.join("");
}
function spaces(count) {
	return new Array(count).fill(" ").join("");
}
function numberOfCodePoints(str) {
	return Array.from(str).length;
}
/**
* 1. No, there is no standard library solution for this
* 2. Yes, this is actually the fastest way; the switch statement is slightly
*    faster than a object lookup or map, and in aggregate, that adds up.
*/
function escapeHTML(unsafe) {
	return unsafe.replace(/[&<>"']/g, escapeHTMLChar);
}
function escapeHTMLChar(char) {
	switch (char) {
		case "&": return "&amp;";
		case "<": return "&lt;";
		case ">": return "&gt;";
		case "\"": return "&quot;";
		case "'": return "&#039;";
		default: return char;
	}
}
/**
* Given the possible sources of syntax highlighting from the server, returns the appropriate syntax-highlighted HTML
*/
function useCodeHTML(lineHtml, directives, rawText, t0, tabSize, hiddenUnicodeShown) {
	const $ = c(7);
	const strategy = t0 === void 0 ? "plain" : t0;
	let t1;
	if ($[0] !== directives || $[1] !== hiddenUnicodeShown || $[2] !== lineHtml || $[3] !== rawText || $[4] !== strategy || $[5] !== tabSize) {
		t1 = lineHtml ?? buildCodeHTML(rawText, directives, strategy, tabSize, hiddenUnicodeShown);
		$[0] = directives;
		$[1] = hiddenUnicodeShown;
		$[2] = lineHtml;
		$[3] = rawText;
		$[4] = strategy;
		$[5] = tabSize;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
var SyntaxHighlightedLine = React.memo(SyntaxHighlightedLineWithRef);
SyntaxHighlightedLine.displayName = "SyntaxHighlightedLine";
function SyntaxHighlightedLineWithRef({ id, stylingDirectivesLine, rawText, lineNumber, current, forceVisible, shouldUseInert, colorizedLine, ref }) {
	const strategy = useSyntaxHighlightingStrategy();
	const { tabSize } = useCurrentBlob();
	const hiddenUnicodeShown = isHiddenUnicodeShown();
	const codeLineHTML = useCodeHTML(colorizedLine, stylingDirectivesLine, rawText, forceVisible ? "plain" : strategy, tabSize, hiddenUnicodeShown);
	return /* @__PURE__ */ jsx(VerifiedHTMLDiv, {
		id,
		className: "react-file-line html-div",
		"data-testid": "code-cell",
		"data-line-number": lineNumber,
		html: codeLineHTML,
		ref,
		style: { position: "relative" },
		"aria-current": current ? "location" : void 0,
		inert: shouldUseInert
	});
}
SyntaxHighlightedLineWithRef.displayName = "SyntaxHighlightedLineWithRef";
var SyntaxHighlightedOverlay = React.memo(SyntaxHighlightedOverlayUnmemoed);
SyntaxHighlightedOverlay.displayName = "SyntaxHighlightedOverlay";
function SyntaxHighlightedOverlayUnmemoed(t0) {
	const $ = c(4);
	const { linesData, colorizedLines } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isHiddenUnicodeShown();
		$[0] = t1;
	} else t1 = $[0];
	const documentHTML = useCodeHTMLDocument(linesData, colorizedLines ?? null, t1);
	const shouldUseInert = useShouldUseInert();
	let t2;
	if ($[1] !== documentHTML || $[2] !== shouldUseInert) {
		t2 = jsx(VerifiedHTMLDiv, {
			inert: shouldUseInert,
			html: documentHTML
		});
		$[1] = documentHTML;
		$[2] = shouldUseInert;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
SyntaxHighlightedOverlayUnmemoed.displayName = "SyntaxHighlightedOverlayUnmemoed";
function useSyntaxHighlightingStrategy() {
	const hiddenFromFind = useIsCursorEnabled();
	const isFirefox = useIsFirefox();
	const shouldUseInert = useShouldUseInert();
	if (!hiddenFromFind || shouldUseInert) return "plain";
	if (isFirefox && !shouldUseInert) return "separated-characters-chunked";
	return "data-attribute";
}
function useCodeHTMLDocument(linesData, colorizedLines, hiddenUnicodeShown) {
	const $ = c(5);
	const { isServer: isSSR } = useRuntimeEnvironment();
	let t0;
	if ($[0] !== colorizedLines || $[1] !== hiddenUnicodeShown || $[2] !== isSSR || $[3] !== linesData) {
		t0 = colorizedLines ? colorizedLines.map((colorizedLine, i) => {
			if (i >= linesData.length) return null;
			let divWrapStart = "";
			let divWrapEnd = "";
			if (i % 60 === 0 && !isSSR) divWrapStart = isSSR ? "<div>" : "<div class=\"react-no-virtualization-wrapper\">";
			if (((i + 1) % 60 === 0 || i === colorizedLines.length) && !isSSR) divWrapEnd = "</div>";
			const lineContent = colorizedLine.length !== 0 ? colorizedLine : "\n";
			const processedLineContent = hiddenUnicodeShown ? showHiddenUnicodeCharactersHTML(lineContent) ?? lineContent : lineContent;
			return `${divWrapStart}<div id="LC${i + 1}" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ${linesData[i]?.codeLineClassName}">${processedLineContent}</div>${divWrapEnd}`;
		}).join("\n") : "<div></div>";
		$[0] = colorizedLines;
		$[1] = hiddenUnicodeShown;
		$[2] = isSSR;
		$[3] = linesData;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
var CodeLinesNoVirtualization = React.memo(CodeLinesNoVirtualizationUnmemoized);
CodeLinesNoVirtualization.displayName = "CodeLinesNoVirtualization";
function CodeLinesNoVirtualizationUnmemoized({ linesData, onLineNumberClick, codeSections, nonTruncatedLinesData, codeLineToSectionMap, onLineStickOrUnstick, sharedLineObserver, colorizedLines, tabSize, contentWidth, cursorContainerRef, onCollapseToggle, textAreaRef, copilotAccessAllowed, ref }) {
	const parentRef = useRef(null);
	const scrollContainerRef = useRef(null);
	const horizontalScrollBarRef = useRef(null);
	const shouldUseCursor = useIsCursorEnabled();
	const setNextTextAreaScrollRef = useRef(true);
	const setNextScrollBarScrollRef = useRef(true);
	const setNextScrollContainerScrollRef = useRef(true);
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	const lineArrayMap = useMemo(() => [...Array(Math.floor(linesData.length / 60) + 1).keys()], [linesData.length]);
	useImperativeHandle(ref, () => ({
		scrollToTop: () => {
			if (isLineInViewport(0)) return;
			window.scrollTo({
				left: 0,
				top: 0
			});
		},
		scrollToLine: (lineNumber, column) => {
			const container = parentRef.current;
			if (!container) return;
			setTimeout(() => window.scrollTo({
				left: getHorizontalScrollOffset(container, lineNumber, column),
				top: lineHeight * lineNumber
			}), 0);
		}
	}));
	useEffect(() => {
		if (textAreaRef && textAreaRef.current) {
			textAreaRef.current.onscroll = () => {
				if (scrollContainerRef.current && textAreaRef?.current) {
					if (!setNextScrollContainerScrollRef.current) {
						setNextScrollContainerScrollRef.current = true;
						return;
					}
					if (textAreaRef.current.scrollLeft === scrollContainerRef.current.scrollLeft) return;
					setNextTextAreaScrollRef.current = !(setNextScrollBarScrollRef.current && setNextScrollContainerScrollRef.current);
					scrollContainerRef.current.scrollLeft = textAreaRef.current.scrollLeft;
				}
				if (cursorContainerRef && cursorContainerRef.current && textAreaRef?.current) cursorContainerRef.current.scrollLeft = textAreaRef.current.scrollLeft;
			};
			const textRef = textAreaRef.current;
			return () => {
				if (textRef) textRef.onscroll = null;
			};
		}
	}, [
		textAreaRef,
		parentRef,
		shouldUseCursor,
		cursorContainerRef
	]);
	return /* @__PURE__ */ jsxs("div", {
		ref: parentRef,
		style: { pointerEvents: shouldUseCursor ? "none" : "auto" },
		onScroll: (event) => handleBlobScrollSync(event, textAreaRef),
		children: [/* @__PURE__ */ jsx("div", {
			ref: scrollContainerRef,
			className: clsx(shouldUseCursor ? CodeLines_module_default.scrollContainerHidden : CodeLines_module_default.scrollContainerAuto),
			tabIndex: 0,
			onScroll: () => {
				if (shouldUseCursor && scrollContainerRef.current && horizontalScrollBarRef.current) {
					if (!setNextScrollBarScrollRef.current) {
						setNextScrollBarScrollRef.current = true;
						return;
					}
					if (horizontalScrollBarRef.current.scrollLeft === scrollContainerRef.current.scrollLeft) return;
					setNextScrollContainerScrollRef.current = !(setNextScrollBarScrollRef.current && setNextTextAreaScrollRef.current);
					horizontalScrollBarRef.current.scrollLeft = scrollContainerRef.current.scrollLeft;
				}
			},
			children: /* @__PURE__ */ jsxs("div", {
				className: clsx("react-code-file-contents", CodeLines_module_default.codeFileContents),
				role: "presentation",
				"aria-hidden": true,
				"data-tab-size": tabSize,
				"data-paste-markdown-skip": true,
				style: {
					tabSize,
					width: contentWidth,
					maxWidth: "unset"
				},
				"data-hpc": true,
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "react-line-numbers-no-virtualization",
						style: {
							pointerEvents: "auto",
							position: "relative",
							zIndex: 2
						},
						children: lineArrayMap.map((segmentCount) => {
							const tempLines = linesData.slice(segmentCount * 60, Math.min(segmentCount * 60 + 60, linesData.length));
							return /* @__PURE__ */ jsx("div", {
								className: "react-no-virtualization-wrapper-lines",
								children: tempLines.map((lineData) => {
									return /* @__PURE__ */ jsx(LineNumberNoVirtualziation, {
										codeLineData: lineData,
										onClick: onLineNumberClick,
										ownedCodeSections: codeSections,
										onLineStickOrUnstick,
										onCollapseToggle,
										codeLineToSectionMap,
										copilotAccessAllowed
									}, `line-number-${lineData.lineNumber}-content:${lineData.rawText?.substring(0, 100)}`);
								})
							}, `line-number-wrapper-${segmentCount}-content:${tempLines[0]?.rawText?.substring(0, 100)}`);
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "react-code-lines",
						children: [
							/* @__PURE__ */ jsx(HighlightedSymbolsOverlay, { linesData }),
							/* @__PURE__ */ jsx(HighlightedLinesOverlay, {
								linesData,
								copilotAccessAllowed
							}),
							/* @__PURE__ */ jsx(SyntaxHighlightedOverlay, {
								colorizedLines,
								linesData: nonTruncatedLinesData
							}),
							/* @__PURE__ */ jsx(StickyLineObserverOverlay, {
								linesData,
								sharedLineObserver,
								codeLineToSectionMap
							}),
							/* @__PURE__ */ jsx(CodeFoldingEllipsisOverlay, {
								linesData,
								onLineStickOrUnstick,
								setIsCollapsed: onCollapseToggle,
								tabSize,
								contentWidth
							})
						]
					}),
					/* @__PURE__ */ jsx(SelectAllShortcutButton, {
						shouldNotOverrideCopy: shouldUseCursor,
						containerRef: shouldUseCursor ? textAreaRef : parentRef
					})
				]
			})
		}), shouldUseCursor && contentWidth && scrollContainerRef.current && scrollContainerRef.current.clientWidth < contentWidth ? /* @__PURE__ */ jsx("div", {
			className: CodeLines_module_default.scrollBarContainer,
			onScroll: () => {
				if (horizontalScrollBarRef.current && textAreaRef?.current) {
					if (!setNextTextAreaScrollRef.current) {
						setNextTextAreaScrollRef.current = true;
						return;
					}
					if (horizontalScrollBarRef.current.scrollLeft === textAreaRef.current.scrollLeft) return;
					setNextScrollBarScrollRef.current = !(setNextScrollContainerScrollRef.current && setNextTextAreaScrollRef.current);
					textAreaRef.current.scrollLeft = horizontalScrollBarRef.current.scrollLeft;
				}
			},
			ref: horizontalScrollBarRef,
			onClick: (ev) => ev.preventDefault(),
			onMouseDown: (ev_0) => ev_0.preventDefault(),
			onMouseUp: (ev_1) => ev_1.preventDefault(),
			children: /* @__PURE__ */ jsx("div", {
				className: CodeLines_module_default.scrollBarSpacer,
				style: { width: contentWidth }
			})
		}) : null]
	});
}
CodeLinesNoVirtualizationUnmemoized.displayName = "CodeLinesNoVirtualizationUnmemoized";
function useShouldDoNoVirtualization(fileLength) {
	const $ = c(1);
	const wordWrapEnabled = useCodeViewOptions().codeWrappingOption.enabled;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("react_blob_overlay");
		$[0] = t0;
	} else t0 = $[0];
	const isNonVirtualized = t0;
	const shouldUseInert = useShouldUseInert();
	const isOldFirefox = useIsFirefox() && !shouldUseInert;
	return isNonVirtualized && !wordWrapEnabled && !isOldFirefox && fileLength < 3500;
}
var EmptyDeferredAST = { stylingDirectives: null };
var DeferredASTContext = React.createContext(EmptyDeferredAST);
DeferredASTContext.displayName = "DeferredASTContext";
function DeferredASTProvider({ children, ...props }) {
	return /* @__PURE__ */ jsx(DeferredASTContext, {
		value: props,
		children
	});
}
DeferredASTProvider.displayName = "DeferredASTProvider";
function useDeferredAST() {
	return React.use(DeferredASTContext);
}
function isValidResponse(obj) {
	return Array.isArray(obj.stylingDirectives);
}
async function fetchDeferredAST(url) {
	if (!url) return EmptyDeferredAST;
	const response = await verifiedFetchJSON(url);
	if (response.ok) {
		const data = await response.json();
		if (data && isValidResponse(data)) return data;
	}
	return EmptyDeferredAST;
}
function useDeferredASTQuery(refInfo, path, has404Error, fileLength) {
	const $ = c(18);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("react_blob_overlay");
		$[0] = t0;
	} else t0 = $[0];
	const isNonVirtualized = t0;
	const repo = useCurrentRepository();
	let t1;
	if ($[1] !== has404Error || $[2] !== path || $[3] !== refInfo || $[4] !== repo) {
		t1 = refInfo && path && !has404Error ? deferredASTPath({
			repo,
			commitish: refInfo.name,
			path
		}) : null;
		$[1] = has404Error;
		$[2] = path;
		$[3] = refInfo;
		$[4] = repo;
		$[5] = t1;
	} else t1 = $[5];
	const url = t1;
	const enabled = Boolean(url) && fileLength <= 3500 && isNonVirtualized;
	const t2 = refInfo?.name;
	let t3;
	if ($[6] !== path || $[7] !== repo.name || $[8] !== repo.ownerLogin || $[9] !== t2 || $[10] !== url) {
		t3 = [
			"deferredAST",
			repo.ownerLogin,
			repo.name,
			t2,
			path,
			url
		];
		$[6] = path;
		$[7] = repo.name;
		$[8] = repo.ownerLogin;
		$[9] = t2;
		$[10] = url;
		$[11] = t3;
	} else t3 = $[11];
	let t4;
	if ($[12] !== url) {
		t4 = () => fetchDeferredAST(url);
		$[12] = url;
		$[13] = t4;
	} else t4 = $[13];
	let t5;
	if ($[14] !== enabled || $[15] !== t3 || $[16] !== t4) {
		t5 = {
			queryKey: t3,
			queryFn: t4,
			enabled,
			placeholderData: EmptyDeferredAST
		};
		$[14] = enabled;
		$[15] = t3;
		$[16] = t4;
		$[17] = t5;
	} else t5 = $[17];
	const { data } = useQuery(t5);
	return enabled ? data ?? EmptyDeferredAST : EmptyDeferredAST;
}
var focusSymbolPaneEvent = "react_blob_view_focus_symbol_pane";
function useFocusSymbolPane(callback) {
	const $ = c(3);
	const eventHandler = useEffectEvent(callback);
	let t0;
	if ($[0] !== eventHandler) {
		t0 = () => {
			const handleScrollEvent = (e) => {
				eventHandler(e.detail?.focusSymbolSearch || false);
			};
			window.addEventListener(focusSymbolPaneEvent, handleScrollEvent);
			return () => {
				window.removeEventListener(focusSymbolPaneEvent, handleScrollEvent);
			};
		};
		$[0] = eventHandler;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[2] = t1;
	} else t1 = $[2];
	useEffect(t0, t1);
}
function focusSymbolPane() {
	window.dispatchEvent(new CustomEvent(focusSymbolPaneEvent, { detail: { focusSymbolSearch: false } }));
}
function focusSymbolSearch() {
	window.dispatchEvent(new CustomEvent(focusSymbolPaneEvent, { detail: { focusSymbolSearch: true } }));
}
var charWidthMac = 7.2293;
var charWidthWindows = 6.6;
var defaultNumLinesToHopOnPageUpDown = 15;
function determineLineAndOffsetFromCharOffsetBinarySearch(charOffset, characterCountByLine) {
	let line = 0;
	let offset = 0;
	let charCount = 0;
	let prevCharCount = 0;
	let nextCharCount = 0;
	let i = 0;
	let j = characterCountByLine.length - 1;
	while (i <= j) {
		const mid = Math.floor((i + j) / 2);
		charCount = characterCountByLine[mid] + 1;
		prevCharCount = mid > 0 ? characterCountByLine[mid - 1] + 1 : 0;
		nextCharCount = mid < characterCountByLine.length - 1 ? characterCountByLine[mid + 1] + 1 : Infinity;
		if (charOffset >= prevCharCount && charOffset < charCount) {
			line = mid;
			offset = charOffset - prevCharCount;
			break;
		} else if (charOffset < prevCharCount) j = mid - 1;
		else if (charOffset >= charCount && charOffset < nextCharCount) {
			line = mid + 1;
			offset = charOffset - charCount;
			break;
		} else if (charOffset >= nextCharCount) i = mid + 1;
	}
	return {
		line,
		offset
	};
}
var startLineNumber = new ObservableValue(1);
var startCharacterNumber = new ObservableValue(0);
var endLineNumber = new ObservableValue(1);
var endCharacterNumber = new ObservableValue(0);
var keyboardNavUsed = new ObservableValue(false);
function useCursorStartLineNumber() {
	return useObservedState(startLineNumber);
}
function useCursorEndLineNumber() {
	return useObservedState(endLineNumber);
}
function useKeyboardNavUsed() {
	return useObservedState(keyboardNavUsed);
}
/**
* @returns a RefObject that contains the start and end indices of the current selection
*/
function useCursorSelectionRef() {
	const $ = c(1);
	const ref = useRef(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = function updateRef() {
			ref.current = {
				start: {
					line: startLineNumber.value,
					column: startCharacterNumber.value + 1
				},
				end: {
					line: endLineNumber.value,
					column: endCharacterNumber.value + 1
				}
			};
		};
		$[0] = t0;
	} else t0 = $[0];
	const updateRef = t0;
	useSubscription(startLineNumber, updateRef);
	useSubscription(startCharacterNumber, updateRef);
	useSubscription(endLineNumber, updateRef);
	useSubscription(endCharacterNumber, updateRef);
	return ref;
}
function setKeyboardNavUsed(value) {
	keyboardNavUsed.value = value;
}
function useIsCursorEnabled(isBlame) {
	const wordWrapEnabled = useCodeViewOptions().codeWrappingOption.enabled;
	const hasBlame = !!useCurrentBlame();
	const { isServer: isSSR } = useRuntimeEnvironment();
	return !wordWrapEnabled && !hasBlame && !isBlame && !isSSR;
}
function useCursorNavigation(cursorRef, onCodeNavTokenSelected, setLeftOffset, setTopOffset, linesData, isVirtualized, isBlame, onLineNumberClick, textAreaRef, tabSize, additionalTextAreaInstructions, textSelection) {
	const $ = c(105);
	const currentStartLineRef = useRef(0);
	const currentStartCharRef = useRef(0);
	const currentEndLineRef = useRef(0);
	const currentEndCharRef = useRef(0);
	const currentDisplayLineRef = useRef(0);
	const currentDisplayCharRef = useRef(0);
	const parentElementRef = useRef(null);
	const currentMaxRightCharRef = useRef(0);
	const currentTextAreaSelectionStartRef = useRef(0);
	const numLinesToHopOnPageUpDownRef = useRef(defaultNumLinesToHopOnPageUpDown);
	const currentTextAreaSelectionEndRef = useRef(0);
	const pendingScrollRAFRef = useRef(0);
	const minLeftOffset = isBlame ? 92 : 92;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["windows"];
		$[0] = t0;
	} else t0 = $[0];
	const charWidth = useIsPlatform(t0) ? charWidthWindows : charWidthMac;
	const lineRowHeight = useCurrentLineHeight("react-line-numbers");
	const { stylingDirectives } = useDeferredAST();
	let charCountByLine;
	if ($[1] !== linesData) {
		charCountByLine = [];
		for (let i = 0; i < linesData.length; i++) if (i === 0) charCountByLine.push(linesData[i].rawText?.length ?? 0);
		else charCountByLine.push((linesData[i].rawText?.length ?? 0) + charCountByLine[i - 1] + 1);
		$[1] = linesData;
		$[2] = charCountByLine;
	} else charCountByLine = $[2];
	const characterCountByLine = charCountByLine;
	let t1;
	if ($[3] !== setLeftOffset) {
		t1 = function setLeftOffsetWithCursorLocationUpdate(offset, offsetCharacter) {
			setLeftOffset(offset);
			currentDisplayCharRef.current = offsetCharacter;
		};
		$[3] = setLeftOffset;
		$[4] = t1;
	} else t1 = $[4];
	const setLeftOffsetWithCursorLocationUpdate = t1;
	let t2;
	if ($[5] !== setTopOffset) {
		t2 = function setTopOffsetWithCursorLocationUpdate(offset_0, offsetLine) {
			setTopOffset(offset_0);
			currentDisplayLineRef.current = offsetLine;
		};
		$[5] = setTopOffset;
		$[6] = t2;
	} else t2 = $[6];
	const setTopOffsetWithCursorLocationUpdate = t2;
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = function removeRangeFromSelection() {
			currentEndLineRef.current = currentStartLineRef.current;
			currentEndCharRef.current = currentStartCharRef.current;
		};
		$[7] = t3;
	} else t3 = $[7];
	const removeRangeFromSelection = t3;
	let t4;
	if ($[8] !== linesData) {
		t4 = function getCorrectLineNumberWithCollapsedSections(visibleLineNumber) {
			return linesData[visibleLineNumber] ? linesData[visibleLineNumber].lineNumber : visibleLineNumber;
		};
		$[8] = linesData;
		$[9] = t4;
	} else t4 = $[9];
	const getCorrectLineNumberWithCollapsedSections = t4;
	let t5;
	if ($[10] !== cursorRef || $[11] !== isVirtualized) {
		t5 = function updateParentRefIfNecessary() {
			if (!parentElementRef.current) if (isVirtualized) parentElementRef.current = cursorRef.current?.parentElement?.parentElement;
			else parentElementRef.current = cursorRef.current?.parentElement;
		};
		$[10] = cursorRef;
		$[11] = isVirtualized;
		$[12] = t5;
	} else t5 = $[12];
	const updateParentRefIfNecessary = t5;
	let t6;
	if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = function determineWhetherStartOrEndIsCurrentDisplayPosition() {
			if (currentStartLineRef.current === currentDisplayLineRef.current && currentStartCharRef.current === currentDisplayCharRef.current && (currentStartLineRef.current !== currentEndLineRef.current || currentStartCharRef.current !== currentEndCharRef.current)) return "start";
			else if (currentEndLineRef.current === currentDisplayLineRef.current && currentEndCharRef.current === currentDisplayCharRef.current && (currentStartLineRef.current !== currentEndLineRef.current || currentStartCharRef.current !== currentEndCharRef.current)) return "end";
			return "same";
		};
		$[13] = t6;
	} else t6 = $[13];
	const determineWhetherStartOrEndIsCurrentDisplayPosition = t6;
	let t7;
	if ($[14] !== characterCountByLine || $[15] !== textAreaRef) {
		t7 = function determineAndSetTextAreaCursorPosition() {
			if (textAreaRef && textAreaRef.current) {
				const textArea = textAreaRef.current;
				const zeroIndexedStartLineNum = currentStartLineRef.current - 1;
				const zeroIndexedEndLineNum = currentEndLineRef.current - 1;
				const offsetStart = (zeroIndexedStartLineNum !== -1 ? characterCountByLine[zeroIndexedStartLineNum] + 1 : 0) + currentStartCharRef.current;
				const offsetEnd = (zeroIndexedEndLineNum !== -1 ? characterCountByLine[zeroIndexedEndLineNum] + 1 : 0) + currentEndCharRef.current;
				textArea.selectionStart = offsetStart;
				textArea.selectionEnd = offsetEnd;
				currentTextAreaSelectionStartRef.current = offsetStart;
				currentTextAreaSelectionEndRef.current = offsetEnd;
			}
		};
		$[14] = characterCountByLine;
		$[15] = textAreaRef;
		$[16] = t7;
	} else t7 = $[16];
	const determineAndSetTextAreaCursorPosition = t7;
	let t8;
	if ($[17] !== linesData || $[18] !== setLeftOffsetWithCursorLocationUpdate || $[19] !== tabSize) {
		t8 = function handleDifferingLineLengthsWhenGoingUpOrDownWithParams(currentLine, currentChar) {
			let returnChar = currentChar;
			if (currentLine > linesData.length || !linesData[currentLine]) return returnChar;
			const rawText = linesData[currentLine].rawText;
			if (!rawText) return returnChar;
			if (currentChar > rawText.length) {
				returnChar = rawText.length;
				setLeftOffsetWithCursorLocationUpdate(determineProperOffsetWithDummyDiv(returnChar, rawText, tabSize), returnChar);
			} else if (returnChar < currentMaxRightCharRef.current && currentMaxRightCharRef.current < rawText.length) {
				returnChar = currentMaxRightCharRef.current;
				setLeftOffsetWithCursorLocationUpdate(determineProperOffsetWithDummyDiv(returnChar, rawText, tabSize), returnChar);
			} else if (returnChar < currentMaxRightCharRef.current && currentMaxRightCharRef.current >= rawText.length) {
				returnChar = rawText.length;
				setLeftOffsetWithCursorLocationUpdate(determineProperOffsetWithDummyDiv(returnChar, rawText, tabSize), returnChar);
			}
			return returnChar;
		};
		$[17] = linesData;
		$[18] = setLeftOffsetWithCursorLocationUpdate;
		$[19] = tabSize;
		$[20] = t8;
	} else t8 = $[20];
	const handleDifferingLineLengthsWhenGoingUpOrDownWithParams = t8;
	let t9;
	if ($[21] !== getCorrectLineNumberWithCollapsedSections || $[22] !== linesData || $[23] !== onCodeNavTokenSelected || $[24] !== stylingDirectives) {
		t9 = function selectSymbolAtCursor() {
			const lineData = linesData[currentDisplayLineRef.current];
			if (!lineData) return;
			const { rawText: rawText_0 } = lineData;
			const stylingDirectivesLine = stylingDirectives ? stylingDirectives[lineData.lineNumber - 1] : lineData.stylingDirectivesLine;
			if (!rawText_0 || !stylingDirectivesLine) return;
			const normalizedDirectives = parseDirectives(stylingDirectivesLine);
			let matchingDirective = null;
			for (const directive of normalizedDirectives) {
				if (directive.s > currentDisplayCharRef.current) continue;
				if (directive.e < currentDisplayCharRef.current) continue;
				if (!directive.c) continue;
				matchingDirective = directive;
				if (!isSymbol(rawText_0.substring(directive.s, directive.e), directive.c)) return;
			}
			if (!matchingDirective) return;
			onCodeNavTokenSelected?.({
				selectedText: rawText_0.substring(matchingDirective.s, matchingDirective.e),
				lineNumber: getCorrectLineNumberWithCollapsedSections(currentDisplayLineRef.current),
				offset: matchingDirective.s
			});
		};
		$[21] = getCorrectLineNumberWithCollapsedSections;
		$[22] = linesData;
		$[23] = onCodeNavTokenSelected;
		$[24] = stylingDirectives;
		$[25] = t9;
	} else t9 = $[25];
	const selectSymbolAtCursor = t9;
	let t10;
	if ($[26] !== getCorrectLineNumberWithCollapsedSections) {
		t10 = function syncVisibleCursorToTextAreaCursor(startLine, endLine, startChar, endChar, startIsVisible) {
			currentStartLineRef.current = startLine;
			currentStartCharRef.current = startChar;
			currentEndLineRef.current = endLine;
			currentEndCharRef.current = endChar;
			currentDisplayLineRef.current = startIsVisible ? startLine : endLine;
			currentDisplayCharRef.current = startIsVisible ? startChar : endChar;
			startLineNumber.value = getCorrectLineNumberWithCollapsedSections(startLine);
			startCharacterNumber.value = startChar;
			endLineNumber.value = getCorrectLineNumberWithCollapsedSections(endLine);
			endCharacterNumber.value = endChar;
		};
		$[26] = getCorrectLineNumberWithCollapsedSections;
		$[27] = t10;
	} else t10 = $[27];
	const syncVisibleCursorToTextAreaCursor = t10;
	let t11;
	if ($[28] !== charWidth || $[29] !== minLeftOffset) {
		t11 = function handleScrollRight(offset_1) {
			const forwardsOrBackwards = determineWhetherStartOrEndIsCurrentDisplayPosition();
			let currentCharNumber = currentStartCharRef.current;
			if (forwardsOrBackwards === "end") currentCharNumber = currentEndCharRef.current;
			if (parentElementRef.current && parentElementRef.current.scrollBy) {
				const scrollLeft = parentElementRef.current.scrollLeft;
				const clientWidth = parentElementRef.current.clientWidth;
				const cursorX = currentCharNumber * charWidth + minLeftOffset;
				if (cursorX + 50 >= scrollLeft + clientWidth) parentElementRef.current.scrollBy(cursorX - scrollLeft - clientWidth + offset_1, 0);
				else if (cursorX <= scrollLeft) parentElementRef.current.scrollBy(cursorX - scrollLeft - clientWidth, 0);
			}
		};
		$[28] = charWidth;
		$[29] = minLeftOffset;
		$[30] = t11;
	} else t11 = $[30];
	const handleScrollRight = t11;
	let t12;
	if ($[31] !== charWidth || $[32] !== getCorrectLineNumberWithCollapsedSections || $[33] !== lineRowHeight || $[34] !== linesData.length || $[35] !== minLeftOffset) {
		t12 = function handleVerticalScroll() {
			const forwardsOrBackwards_0 = determineWhetherStartOrEndIsCurrentDisplayPosition();
			let currentCharNumber_0 = currentStartCharRef.current;
			let currentLineNumber = currentStartLineRef.current;
			if (forwardsOrBackwards_0 === "end") {
				currentCharNumber_0 = currentEndCharRef.current;
				currentLineNumber = currentEndLineRef.current;
			}
			const lowerLineNumberToEnsure = Math.min(getCorrectLineNumberWithCollapsedSections(currentLineNumber + 5), linesData.length);
			const upperLineNumberToEnsure = Math.max(getCorrectLineNumberWithCollapsedSections(currentLineNumber - 5), 1);
			const viewportHeight = document.documentElement.clientHeight;
			const browserWidth = document.documentElement.clientWidth;
			const lowerLine = getElementForLine(lowerLineNumberToEnsure);
			const upperLine = getElementForLine(upperLineNumberToEnsure);
			const lowerRect = lowerLine?.getBoundingClientRect();
			const upperRect = upperLine?.getBoundingClientRect();
			const lowerLineInViewport = lowerRect ? lowerRect.top >= 0 && lowerRect.left >= 0 && lowerRect.bottom <= viewportHeight : false;
			const upperLineInViewport = upperRect ? upperRect.top >= 0 && upperRect.left >= 0 && upperRect.bottom <= viewportHeight : false;
			cancelAnimationFrame(pendingScrollRAFRef.current);
			pendingScrollRAFRef.current = requestAnimationFrame(() => {
				if (!lowerLineInViewport) {
					if (lowerLine === null) window.scrollTo(0, currentLineNumber * lineRowHeight);
					else if (lowerRect.y < 0 || lowerRect.y > viewportHeight) {
						lowerLine.scrollIntoView({ block: "center" });
						window.scrollBy(-300, 0);
					} else window.scrollBy(0, 100);
					if (browserWidth < currentCharNumber_0 * charWidth + minLeftOffset) window.scrollTo(0, 0);
				}
				if (!upperLineInViewport) if (upperLine === null) window.scrollTo(0, currentLineNumber * lineRowHeight);
				else if (upperRect.y < 0 || upperRect.y > viewportHeight) {
					upperLine.scrollIntoView({ block: "center" });
					window.scrollBy(-300, 0);
				} else window.scrollBy(0, -200);
				else if (currentLineNumber <= 7) window.scrollTo(0, 0);
			});
		};
		$[31] = charWidth;
		$[32] = getCorrectLineNumberWithCollapsedSections;
		$[33] = lineRowHeight;
		$[34] = linesData.length;
		$[35] = minLeftOffset;
		$[36] = t12;
	} else t12 = $[36];
	const handleVerticalScroll = t12;
	let t13;
	if ($[37] !== determineAndSetTextAreaCursorPosition || $[38] !== handleScrollRight || $[39] !== handleVerticalScroll) {
		t13 = function syncAndScrollCleanup(scrollOffset) {
			if (parentElementRef.current) {
				handleVerticalScroll();
				handleScrollRight(scrollOffset);
			}
			determineAndSetTextAreaCursorPosition();
		};
		$[37] = determineAndSetTextAreaCursorPosition;
		$[38] = handleScrollRight;
		$[39] = handleVerticalScroll;
		$[40] = t13;
	} else t13 = $[40];
	const syncAndScrollCleanup = t13;
	let t14;
	if ($[41] !== handleDifferingLineLengthsWhenGoingUpOrDownWithParams || $[42] !== lineRowHeight || $[43] !== linesData.length || $[44] !== setTopOffsetWithCursorLocationUpdate || $[45] !== syncAndScrollCleanup || $[46] !== updateParentRefIfNecessary) {
		t14 = function onPageDown() {
			updateParentRefIfNecessary();
			let currentLineNumber_0 = currentStartLineRef.current;
			let currentCharNumber_1 = currentStartCharRef.current;
			if (currentLineNumber_0 + numLinesToHopOnPageUpDownRef.current > linesData.length) currentLineNumber_0 = linesData.length - 1;
			else currentLineNumber_0 = currentLineNumber_0 + numLinesToHopOnPageUpDownRef.current;
			currentCharNumber_1 = handleDifferingLineLengthsWhenGoingUpOrDownWithParams(currentLineNumber_0, currentCharNumber_1);
			currentStartLineRef.current = currentLineNumber_0;
			currentStartCharRef.current = currentCharNumber_1;
			removeRangeFromSelection();
			setTopOffsetWithCursorLocationUpdate(currentLineNumber_0 * lineRowHeight, currentLineNumber_0);
			syncAndScrollCleanup(70);
		};
		$[41] = handleDifferingLineLengthsWhenGoingUpOrDownWithParams;
		$[42] = lineRowHeight;
		$[43] = linesData.length;
		$[44] = setTopOffsetWithCursorLocationUpdate;
		$[45] = syncAndScrollCleanup;
		$[46] = updateParentRefIfNecessary;
		$[47] = t14;
	} else t14 = $[47];
	const onPageDown = t14;
	let t15;
	if ($[48] !== handleDifferingLineLengthsWhenGoingUpOrDownWithParams || $[49] !== lineRowHeight || $[50] !== setTopOffsetWithCursorLocationUpdate || $[51] !== syncAndScrollCleanup || $[52] !== updateParentRefIfNecessary) {
		t15 = function onPageUp() {
			updateParentRefIfNecessary();
			let currentLineNumber_1 = currentStartLineRef.current;
			let currentCharNumber_2 = currentStartCharRef.current;
			if (currentLineNumber_1 < numLinesToHopOnPageUpDownRef.current) currentLineNumber_1 = 0;
			else currentLineNumber_1 = currentLineNumber_1 - numLinesToHopOnPageUpDownRef.current;
			currentCharNumber_2 = handleDifferingLineLengthsWhenGoingUpOrDownWithParams(currentLineNumber_1, currentCharNumber_2);
			currentStartLineRef.current = currentLineNumber_1;
			currentStartCharRef.current = currentCharNumber_2;
			removeRangeFromSelection();
			setTopOffsetWithCursorLocationUpdate(currentLineNumber_1 * lineRowHeight, currentLineNumber_1);
			syncAndScrollCleanup(70);
		};
		$[48] = handleDifferingLineLengthsWhenGoingUpOrDownWithParams;
		$[49] = lineRowHeight;
		$[50] = setTopOffsetWithCursorLocationUpdate;
		$[51] = syncAndScrollCleanup;
		$[52] = updateParentRefIfNecessary;
		$[53] = t15;
	} else t15 = $[53];
	const onPageUp = t15;
	let t16;
	if ($[54] !== selectSymbolAtCursor) {
		t16 = function onEnter() {
			keyboardNavUsed.value = true;
			focusSymbolPane();
			selectSymbolAtCursor();
		};
		$[54] = selectSymbolAtCursor;
		$[55] = t16;
	} else t16 = $[55];
	const onEnter = t16;
	let t17;
	if ($[56] !== onLineNumberClick) {
		t17 = (e) => {
			const shouldUseColumn = startLineNumber.value !== endLineNumber.value;
			const highlightInfo = {
				start: {
					line: startLineNumber.value,
					column: shouldUseColumn ? startCharacterNumber.value + 1 : null
				},
				end: {
					line: endLineNumber.value,
					column: shouldUseColumn ? endCharacterNumber.value + 1 : null
				}
			};
			const hash = formatBlobRangeAnchor({
				anchorPrefix: "L",
				blobRange: {
					start: highlightInfo.start,
					end: highlightInfo.end
				}
			});
			window.location.hash = hash;
			onLineNumberClick?.(e);
		};
		$[56] = onLineNumberClick;
		$[57] = t17;
	} else t17 = $[57];
	const updateUrlForLineNumber = t17;
	const { hash: hash_0 } = useLocation$1();
	let t18;
	let t19;
	if ($[58] !== lineRowHeight) {
		t18 = () => {
			const viewportHeight_0 = document.documentElement.clientHeight;
			const heightToMoveBy = viewportHeight_0 - 200 > 300 ? viewportHeight_0 - 200 : 300;
			const numLinesToMoveBy = Math.round(heightToMoveBy / lineRowHeight);
			numLinesToHopOnPageUpDownRef.current = Math.min(Math.max(numLinesToMoveBy, 1), 100);
		};
		t19 = [lineRowHeight];
		$[58] = lineRowHeight;
		$[59] = t18;
		$[60] = t19;
	} else {
		t18 = $[59];
		t19 = $[60];
	}
	useEffect(t18, t19);
	let t20;
	if ($[61] !== additionalTextAreaInstructions || $[62] !== onPageDown || $[63] !== onPageUp) {
		t20 = () => {
			if (!additionalTextAreaInstructions || additionalTextAreaInstructions === "") return;
			if (additionalTextAreaInstructions.includes("PageUp")) onPageUp();
			else if (additionalTextAreaInstructions.includes("PageDown")) onPageDown();
		};
		$[61] = additionalTextAreaInstructions;
		$[62] = onPageDown;
		$[63] = onPageUp;
		$[64] = t20;
	} else t20 = $[64];
	const onAdditionalTextAreaInstructionsChange = useEffectEvent(t20);
	let t21;
	if ($[65] !== onAdditionalTextAreaInstructionsChange) {
		t21 = () => {
			onAdditionalTextAreaInstructionsChange();
		};
		$[65] = onAdditionalTextAreaInstructionsChange;
		$[66] = t21;
	} else t21 = $[66];
	let t22;
	if ($[67] !== additionalTextAreaInstructions) {
		t22 = [additionalTextAreaInstructions];
		$[67] = additionalTextAreaInstructions;
		$[68] = t22;
	} else t22 = $[68];
	useEffect(t21, t22);
	let t23;
	if ($[69] !== characterCountByLine || $[70] !== handleVerticalScroll || $[71] !== lineRowHeight || $[72] !== linesData || $[73] !== selectSymbolAtCursor || $[74] !== setLeftOffsetWithCursorLocationUpdate || $[75] !== setTopOffsetWithCursorLocationUpdate || $[76] !== syncVisibleCursorToTextAreaCursor || $[77] !== tabSize || $[78] !== textSelection) {
		t23 = () => {
			if (!textSelection) return;
			if (textSelection.start < 0 && textSelection.end < 0) return;
			if (currentTextAreaSelectionStartRef.current === textSelection.start && currentTextAreaSelectionEndRef.current === textSelection.end) return;
			const startValues = determineLineAndOffsetFromCharOffsetBinarySearch(textSelection.start, characterCountByLine);
			const endValues = determineLineAndOffsetFromCharOffsetBinarySearch(textSelection.end, characterCountByLine);
			if (currentTextAreaSelectionStartRef.current === textSelection.start && currentTextAreaSelectionEndRef.current !== textSelection.end || !textSelection.keyboard && !textSelection.displayStart) {
				setLeftOffsetWithCursorLocationUpdate(determineProperOffsetWithDummyDiv(endValues.offset, linesData[endValues.line]?.rawText ?? "", tabSize), endValues.offset);
				currentMaxRightCharRef.current = endValues.offset;
				setTopOffsetWithCursorLocationUpdate(endValues.line * lineRowHeight, endValues.line);
				syncVisibleCursorToTextAreaCursor(startValues.line, endValues.line, startValues.offset, endValues.offset, false);
			} else {
				setLeftOffsetWithCursorLocationUpdate(determineProperOffsetWithDummyDiv(startValues.offset, linesData[startValues.line]?.rawText ?? "", tabSize), startValues.offset);
				currentMaxRightCharRef.current = startValues.offset;
				setTopOffsetWithCursorLocationUpdate(startValues.line * lineRowHeight, startValues.line);
				syncVisibleCursorToTextAreaCursor(startValues.line, endValues.line, startValues.offset, endValues.offset, true);
			}
			currentTextAreaSelectionEndRef.current = textSelection.end;
			currentTextAreaSelectionStartRef.current = textSelection.start;
			if (textSelection.end === textSelection.start && !textSelection.keyboard) {
				keyboardNavUsed.value = false;
				selectSymbolAtCursor();
			}
			if (currentDisplayLineRef.current <= 5 && textSelection.keyboard) handleVerticalScroll();
		};
		$[69] = characterCountByLine;
		$[70] = handleVerticalScroll;
		$[71] = lineRowHeight;
		$[72] = linesData;
		$[73] = selectSymbolAtCursor;
		$[74] = setLeftOffsetWithCursorLocationUpdate;
		$[75] = setTopOffsetWithCursorLocationUpdate;
		$[76] = syncVisibleCursorToTextAreaCursor;
		$[77] = tabSize;
		$[78] = textSelection;
		$[79] = t23;
	} else t23 = $[79];
	const handleLinesDataTabSizeOrTextSelectionChange = useEffectEvent(t23);
	let t24;
	if ($[80] !== handleLinesDataTabSizeOrTextSelectionChange) {
		t24 = () => {
			handleLinesDataTabSizeOrTextSelectionChange();
		};
		$[80] = handleLinesDataTabSizeOrTextSelectionChange;
		$[81] = t24;
	} else t24 = $[81];
	let t25;
	if ($[82] !== linesData || $[83] !== tabSize || $[84] !== textSelection) {
		t25 = [
			linesData,
			tabSize,
			textSelection
		];
		$[82] = linesData;
		$[83] = tabSize;
		$[84] = textSelection;
		$[85] = t25;
	} else t25 = $[85];
	useEffect(t24, t25);
	let t26;
	if ($[86] !== hash_0 || $[87] !== lineRowHeight || $[88] !== linesData.length || $[89] !== setLeftOffsetWithCursorLocationUpdate || $[90] !== setTopOffsetWithCursorLocationUpdate || $[91] !== syncAndScrollCleanup) {
		t26 = () => {
			const anchInfo = parseFileAnchor(hash_0);
			if (!anchInfo.blobRange?.start?.line) return;
			if (anchInfo.blobRange.start.line > linesData.length) return;
			const initialLineNumber = anchInfo.blobRange.start.line - 1;
			currentStartLineRef.current = initialLineNumber;
			startLineNumber.value = initialLineNumber;
			startCharacterNumber.value = 0;
			endLineNumber.value = initialLineNumber;
			endCharacterNumber.value = 0;
			currentStartCharRef.current = 0;
			currentEndLineRef.current = initialLineNumber;
			currentEndCharRef.current = 0;
			currentMaxRightCharRef.current = 0;
			setLeftOffsetWithCursorLocationUpdate(currentStartCharRef.current, currentStartCharRef.current);
			setTopOffsetWithCursorLocationUpdate(currentStartLineRef.current * lineRowHeight, currentStartLineRef.current);
			syncAndScrollCleanup(70);
		};
		$[86] = hash_0;
		$[87] = lineRowHeight;
		$[88] = linesData.length;
		$[89] = setLeftOffsetWithCursorLocationUpdate;
		$[90] = setTopOffsetWithCursorLocationUpdate;
		$[91] = syncAndScrollCleanup;
		$[92] = t26;
	} else t26 = $[92];
	const onHashOrLinesDataChange = useEffectEvent(t26);
	let t27;
	if ($[93] !== onHashOrLinesDataChange) {
		t27 = () => {
			onHashOrLinesDataChange();
		};
		$[93] = onHashOrLinesDataChange;
		$[94] = t27;
	} else t27 = $[94];
	let t28;
	if ($[95] !== hash_0 || $[96] !== linesData) {
		t28 = [hash_0, linesData];
		$[95] = hash_0;
		$[96] = linesData;
		$[97] = t28;
	} else t28 = $[97];
	useEffect(t27, t28);
	let t29;
	if ($[98] !== determineAndSetTextAreaCursorPosition || $[99] !== getCorrectLineNumberWithCollapsedSections || $[100] !== onEnter || $[101] !== onPageDown || $[102] !== onPageUp || $[103] !== updateUrlForLineNumber) {
		t29 = {
			onEnter,
			updateUrlForLineNumber,
			onPageDown,
			onPageUp,
			currentStartLine: currentStartLineRef,
			currentStartChar: currentStartCharRef,
			currentEndLine: currentEndLineRef,
			currentEndChar: currentEndCharRef,
			determineAndSetTextAreaCursorPosition,
			getCorrectLineNumberWithCollapsedSections
		};
		$[98] = determineAndSetTextAreaCursorPosition;
		$[99] = getCorrectLineNumberWithCollapsedSections;
		$[100] = onEnter;
		$[101] = onPageDown;
		$[102] = onPageUp;
		$[103] = updateUrlForLineNumber;
		$[104] = t29;
	} else t29 = $[104];
	return t29;
}
var FALLBACK_MONOSPACE_FONT = "ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace";
var FALLBACK_FONT_SIZE = "12px";
var FALLBACK_FONT_STRING = `normal normal ${FALLBACK_FONT_SIZE} ${FALLBACK_MONOSPACE_FONT}`;
var measureContext = null;
var cachedFontString = null;
var cachedLetterSpacing = 0;
var usingFallbackFont = false;
var canvasSupportsLetterSpacing = null;
var themeObserver = null;
function getContext() {
	if (measureContext) {
		if (usingFallbackFont) {
			resolveFontProperties();
			if (!usingFallbackFont) applyFontToContext();
		}
		return measureContext;
	}
	if (typeof OffscreenCanvas !== "undefined") measureContext = new OffscreenCanvas(0, 0).getContext("2d");
	else if (typeof document !== "undefined") measureContext = document.createElement("canvas").getContext("2d");
	if (measureContext) {
		canvasSupportsLetterSpacing = "letterSpacing" in measureContext;
		resolveFontProperties();
		applyFontToContext();
		observeThemeChanges();
	}
	return measureContext;
}
/**
* Apply the cached font string and letter-spacing to the canvas context.
*/
function applyFontToContext() {
	if (!measureContext || !cachedFontString) return;
	measureContext.font = cachedFontString;
	if (cachedLetterSpacing !== 0 && canvasSupportsLetterSpacing) measureContext.letterSpacing = `${cachedLetterSpacing}px`;
}
/**
* Watch for GitHub theme attribute changes on <html> and invalidate the
* cached font properties so the next measurement picks up the new styles.
*/
function observeThemeChanges() {
	if (themeObserver || typeof document === "undefined") return;
	themeObserver = new MutationObserver(() => {
		cachedFontString = null;
		cachedLetterSpacing = 0;
		usingFallbackFont = false;
		if (measureContext) {
			resolveFontProperties();
			applyFontToContext();
		}
	});
	themeObserver.observe(document.documentElement, {
		attributes: true,
		attributeFilter: [
			"data-color-mode",
			"data-dark-theme",
			"data-light-theme"
		]
	});
}
/**
* Resolve font properties by reading computed style from an actual code text element.
* Looks for both the blob renderer's `.react-code-text` and the code-nav's
* `.react-code-lines code` / `.react-blob-print-hide code` selectors.
*/
function resolveFontProperties() {
	if (cachedFontString && !usingFallbackFont) return;
	const style = getCodeElementStyle();
	if (style) {
		const fontStyle = style.fontStyle || "normal";
		const fontWeight = style.fontWeight || "normal";
		const fontSize = style.fontSize || FALLBACK_FONT_SIZE;
		const fontFamily = style.fontFamily || FALLBACK_MONOSPACE_FONT;
		const letterSpacingStr = style.letterSpacing;
		cachedLetterSpacing = 0;
		if (letterSpacingStr && letterSpacingStr !== "normal") cachedLetterSpacing = parseFloat(letterSpacingStr) || 0;
		cachedFontString = `${fontStyle} ${fontWeight} ${fontSize} ${fontFamily}`;
		usingFallbackFont = false;
	} else {
		cachedFontString = FALLBACK_FONT_STRING;
		usingFallbackFont = true;
	}
}
function getCodeElementStyle() {
	if (typeof document !== "undefined") {
		const codeElement = document.querySelector(".react-code-text, .react-code-lines code, .react-blob-print-hide code");
		if (codeElement) return getComputedStyle(codeElement);
	}
	return null;
}
/**
* Measure the pixel width of a string using the Canvas `measureText` API.
* Uses the same monospace font as code lines. Returns 0 if no canvas
* context is available (e.g. in tests or SSR).
*
* @param text - The string to measure.
* @param tabSize - Optional tab stop width in spaces. When provided, tab characters
*   are expanded to spaces before measuring (Canvas `measureText` does not
*   handle tab stops natively). Callers dealing with raw source lines should
*   pass this value.
*
* Accounts for letter-spacing: on browsers that support canvas `letterSpacing`,
* it is set on the context directly; on older browsers, letter-spacing is added
* manually.
*/
function measureMonospaceTextWidth(text, tabSize) {
	const ctx = getContext();
	if (!ctx) return 0;
	const measuredText = tabSize != null ? text.replace(/\t/g, " ".repeat(tabSize)) : text;
	let width = ctx.measureText(measuredText).width;
	if (cachedLetterSpacing !== 0 && !canvasSupportsLetterSpacing && measuredText.length > 1) width += cachedLetterSpacing * (measuredText.length - 1);
	return width;
}
var FIREFOX_VERSION_REGEX = /firefox\/(\d+(\.\d+)?)/;
var CHROMIUM_VERSION_REGEX = /Chrom(e|ium)\/([0-9]+)\./;
var SYMBOL_MATCH_REGEX_ENT = /\n|\s|[();&.=,]/;
var SYMBOL_MATCH_REGEX_DEFAULT = /\n|\s|[();&.=",]/;
var rowCollapseStyleId = "collapse-show-rows-styles";
var CODE_CELL_PADDING = 10;
var textAreaId = "read-only-cursor-text-area";
function queryLineElement(anchorPrefix, line) {
	return document.querySelector(`#${anchorPrefix}LC${line}`);
}
function queryMatchElement(line, column) {
	return document.querySelector(`main #${matchElementId(line, column)}`);
}
var collapsedRows = new ObservableSet();
function useIsLineCollapsed(lineNumber) {
	const $ = c(2);
	let t0;
	if ($[0] !== lineNumber) {
		t0 = collapsedRows.has(lineNumber);
		$[0] = lineNumber;
		$[1] = t0;
	} else t0 = $[1];
	return useObservedState(t0);
}
function useLinesSubscription(callbackFunc) {
	return useSubscription(collapsedRows, callbackFunc);
}
function useCollapsedLinesSubscription() {
	return useObservedStateMap(collapsedRows);
}
function useShouldUseInert() {
	const isFirefox = useIsFirefox();
	const firefoxVersion = useFirefoxVersion() ?? 0;
	const isChromiumOrEdge = useIsChromeOrEdge();
	const chromiumVersion = useChromiumVersion() ?? 0;
	const isSupportedVersion = firefoxVersion >= 124 || chromiumVersion >= 124;
	return useIsCursorEnabled() && (isFirefox || isChromiumOrEdge) && isSupportedVersion;
}
function useIsFirefox() {
	return useSyncExternalStore(_temp2, _temp3, _temp4);
}
function _temp4() {
	return false;
}
function _temp3() {
	return navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
}
function _temp2() {
	return _temp;
}
function _temp() {}
function useIsChromeOrEdge() {
	return useSyncExternalStore(_temp6, _temp7, _temp8);
}
/**
* Extracts the Firefox major version number from the user agent string
* @param userAgent - User agent string
* @returns Firefox major version number or null if not found
*/
function _temp8() {
	return false;
}
function _temp7() {
	return navigator.userAgent.toLowerCase().indexOf("chrome") > -1 || navigator.userAgent.toLowerCase().indexOf("chromium") > -1 || navigator.userAgent.toLowerCase().indexOf("edge") > -1;
}
function _temp6() {
	return _temp5;
}
function _temp5() {}
function getFirefoxVersion(userAgent) {
	const match = userAgent.toLowerCase().match(FIREFOX_VERSION_REGEX);
	return match && match.length >= 2 && match[1] ? parseFloat(match[1]) : null;
}
/**
* Extracts the edge or chrome major version number from the user agent string
* @param userAgent - User agent string
* @returns edge or chrome major version number or null if not found
*/
function getChromiumVersion(userAgent) {
	const match = userAgent.match(CHROMIUM_VERSION_REGEX);
	return match && match.length >= 3 && match[2] ? parseFloat(match[2]) : null;
}
function useChromiumVersion() {
	return useSyncExternalStore(_temp0, _temp1, _temp10);
}
function _temp10() {
	return null;
}
function _temp1() {
	return getChromiumVersion(navigator.userAgent);
}
function _temp0() {
	return _temp9;
}
function _temp9() {}
function useFirefoxVersion() {
	return useSyncExternalStore(_temp12, _temp13, _temp14);
}
function _temp14() {
	return null;
}
function _temp13() {
	return getFirefoxVersion(navigator.userAgent);
}
function _temp12() {
	return _temp11;
}
function _temp11() {}
function buildRowClass(codeSectionArray, lineNumber, isEndLine, ownedCodeSections) {
	if (!ownedCodeSections) return "";
	let rowHideClassName = "";
	for (let i = 0; i < codeSectionArray.length; i++) rowHideClassName += `${getLineChildClassName(codeSectionArray[i].startLine - 1)} `;
	if (isEndLine && ownedCodeSections.has(lineNumber)) {
		const sections = ownedCodeSections.get(lineNumber);
		if (sections) for (let j = 0; j < sections.length; j++) rowHideClassName += `${getLineChildClassName(sections[j].startLine - 1)} `;
	}
	return rowHideClassName;
}
function getLineChildClassName(lineNumber) {
	return `child-of-line-${lineNumber}`;
}
function applyStickyToParentStartLines(map, line, codeLineToSectionMap, onLineStickOrUnstick) {
	if (!codeLineToSectionMap) return;
	const sections = codeLineToSectionMap.get(line);
	if (sections) for (const section of sections) {
		const startLines = map.get(section.endLine);
		if (startLines) {
			for (const startLine of startLines) if (line > startLine.lineNumber) onLineStickOrUnstick(startLine, false);
		}
	}
}
function expandRow(lineNumber) {
	setStylesForRow(lineNumber, false);
	collapsedRows.delete(lineNumber);
}
function collapseRow(lineNumber) {
	setStylesForRow(lineNumber, true);
	collapsedRows.add(lineNumber);
}
function expandAllRows() {
	const styleSheet = document.getElementById(rowCollapseStyleId);
	if (styleSheet) styleSheet.textContent = "";
	collapsedRows.clear();
}
function setStylesForRow(lineNumber, isCollapsed) {
	const styles = `.${getLineChildClassName(lineNumber - 1)} { display: none; } `;
	if (document.getElementById(rowCollapseStyleId)) {
		const styleSheet = document.getElementById(rowCollapseStyleId);
		if (isCollapsed) styleSheet.textContent += styles;
		else {
			let sheetTextContent = styleSheet?.textContent || "";
			sheetTextContent = sheetTextContent.replace(styles, "");
			styleSheet.textContent = sheetTextContent;
		}
	} else {
		const styleSheet = document.createElement("style");
		styleSheet.id = rowCollapseStyleId;
		styleSheet.textContent = styles;
		document.head.appendChild(styleSheet);
	}
}
function isSymbol(text, className) {
	if (text.length < 3) return false;
	const classesArray = className.split(" ");
	const matchRegEx = classesArray.includes("pl-ent") ? SYMBOL_MATCH_REGEX_ENT : SYMBOL_MATCH_REGEX_DEFAULT;
	if (text.match(matchRegEx)) return false;
	if (classesArray.includes("pl-c") || classesArray.includes("pl-k")) return false;
	return true;
}
/**
* From a text node and offset, find the line number that line is on and the offset within that line
* @param textNode The node to find the line number for
* @param offset The offset within the text node
* @returns The line number and character column of the line
*/
function calculateLineAndColumn(textNode, offset) {
	let lineNumber = null;
	let lineElement = null;
	let childNode = null;
	let column = offset;
	if (textNode.parentElement?.classList.contains("react-file-line")) {
		lineNumber = textNode.parentElement.getAttribute("data-line-number");
		lineElement = textNode.parentElement;
		childNode = textNode;
	} else if (textNode.parentElement?.parentElement?.classList.contains("react-file-line")) {
		lineNumber = textNode.parentElement.parentElement.getAttribute("data-line-number");
		lineElement = textNode.parentElement.parentElement;
		childNode = textNode.parentNode;
	} else if (textNode.parentElement?.firstElementChild?.classList.contains("react-file-line")) {
		lineNumber = textNode.parentElement.firstElementChild.getAttribute("data-line-number");
		if (!lineNumber || !parseInt(lineNumber, 10)) return;
		return {
			line: parseInt(lineNumber, 10) - 1,
			column: null
		};
	} else return;
	if (!lineNumber || !parseInt(lineNumber, 10)) return;
	for (const child of lineElement.childNodes) {
		if (child === childNode) break;
		column += child.textContent?.length || 0;
	}
	return {
		line: parseInt(lineNumber, 10),
		column: column !== 0 ? column + 1 : null
	};
}
/**
* Measures text width using Canvas API instead of DOM manipulation.
* This avoids layout thrashing by not creating/appending/measuring/removing DOM elements.
* Returns an integer to match DOM's clientWidth behavior.
*/
function measureTextWithCanvas(charOffset, lineRawText, tabSize) {
	const width = measureMonospaceTextWidth(lineRawText.slice(0, charOffset), tabSize);
	if (width > 0 || charOffset === 0) return Math.round(width);
	return charOffset !== 0 ? charOffset * charWidthMac : 0;
}
/**
* Determines the pixel offset for a character position in a line of code.
* Uses an offscreen Canvas to measure the rendered width of the substring,
* falling back to a character-width approximation when Canvas is unavailable.
*/
function determineProperOffsetWithDummyDiv(charOffset, lineRawText, tabSize) {
	return measureTextWithCanvas(charOffset, lineRawText, tabSize);
}
function calculateHighlightOffsetAndWidth(highlightedInfo, lineElement, lineNumber, tabSize, rawText) {
	if (highlightedInfo?.start.line === lineNumber && highlightedInfo?.start.column !== null) {
		const range = DOMRangeFromBlob({
			start: highlightedInfo.start,
			end: {
				line: highlightedInfo.start.line,
				column: highlightedInfo.end.line === lineNumber ? highlightedInfo.end.column : null
			}
		}, () => lineElement);
		if (range && range.startContainer.parentElement) {
			const rangeRect = range.getBoundingClientRect();
			const lineRect = lineElement.getBoundingClientRect();
			return {
				offset: rangeRect.x - lineRect.x + CODE_CELL_PADDING,
				width: highlightedInfo.end.line === lineNumber ? rangeRect.width : void 0
			};
		} else if (rawText) {
			const offset = determineProperOffsetWithDummyDiv(highlightedInfo.start.column - 1, rawText, tabSize);
			const endColumn = highlightedInfo.end.line === lineNumber ? highlightedInfo.end.column : null;
			return {
				offset: offset + CODE_CELL_PADDING * 2,
				width: highlightedInfo.end.line === lineNumber ? determineProperOffsetWithDummyDiv(endColumn ? endColumn - 1 : rawText.length - 1, rawText, tabSize) - offset : void 0
			};
		}
	} else if (highlightedInfo?.end.line === lineNumber && highlightedInfo?.end.column !== null) {
		const range = DOMRangeFromBlob({
			start: {
				line: highlightedInfo.end.line,
				column: 0
			},
			end: highlightedInfo.end
		}, () => lineElement);
		if (range) return { width: range.getBoundingClientRect().width + CODE_CELL_PADDING };
		else return { width: determineProperOffsetWithDummyDiv(highlightedInfo.end.column - 1, rawText, tabSize) + CODE_CELL_PADDING };
	}
}
function isLineInViewport(lineNumber) {
	return isInViewport(queryLineElement("", lineNumber));
}
function getElementForLine(lineNumber) {
	return queryLineElement("", lineNumber);
}
function isInViewport(element) {
	if (!element) return false;
	const rect = element.getBoundingClientRect();
	return rect.top >= 0 && rect.left >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight);
}
function calculateLineNumberFromOffset(pageYOffset, topPageSpace, lineHeight) {
	return Math.floor((pageYOffset - topPageSpace) / lineHeight) + 1;
}
function getActualLineNumberBinarySearch(wrongLineNumber, linesData) {
	let low = 0;
	let high = linesData.length - 1;
	while (low <= high) {
		const mid = Math.floor((low + high) / 2);
		const midElement = linesData[mid];
		if (!midElement) return -1;
		if (midElement.lineNumber === wrongLineNumber) return mid;
		else if (midElement.lineNumber < wrongLineNumber) low = mid + 1;
		else high = mid - 1;
	}
	return -1;
}
function createScreenReaderAnnouncementDiv() {
	if (typeof ssrSafeDocument === "undefined") return;
	const dummyDiv = ssrSafeDocument.createElement("div");
	dummyDiv.classList.add("sr-only", "mt-n1");
	dummyDiv.id = "screenReaderAnnouncementDiv";
	dummyDiv.setAttribute("role", "alert");
	dummyDiv.setAttribute("data-testid", "screenReaderAnnouncement");
	dummyDiv.setAttribute("aria-live", "assertive");
	ssrSafeDocument.body.appendChild(dummyDiv);
}
function forceAnnouncementToScreenReaders(textToAnnounce, timeoutBeforeAnnouncing = 0) {
	if (typeof ssrSafeDocument === "undefined") return;
	let screenReaderDiv = ssrSafeDocument.getElementById("screenReaderAnnouncementDiv");
	if (!screenReaderDiv) createScreenReaderAnnouncementDiv();
	screenReaderDiv = ssrSafeDocument.getElementById("screenReaderAnnouncementDiv");
	if (!screenReaderDiv) return;
	const textToAnnounceDeDuped = screenReaderDiv.textContent === textToAnnounce ? `${textToAnnounce}\u00A0` : textToAnnounce;
	setTimeout(() => {
		if (screenReaderDiv) screenReaderDiv.textContent = textToAnnounceDeDuped;
	}, timeoutBeforeAnnouncing);
}
var CodeLine_module_default = {
	highlightedOverlayInCodeLine: "CodeLine-module_u7u6vW_highlightedOverlayInCodeLine",
	highlighterElement: "CodeLine-module_u7u6vW_highlighterElement"
};
var CodeLine = React.memo(CodeLineUnmemoized);
CodeLine.displayName = "CodeLine";
function CodeLineUnmemoized({ codeLineData, codeLineClassName, colorizedLine, id, onClick, setIsCollapsed, onLineStickOrUnstick, sharedLineObserver, virtualOffset, codeLineToSectionMap, stylingDirectivesLine, virtualKey, forceVisible, measureRef, virtualIndex, copilotAccessAllowed, currentLineHeight = 20, shouldUseInert }) {
	const { lineNumber, rawText } = codeLineData;
	const collapsed = useIsLineCollapsed(lineNumber);
	const { tabSize } = useCurrentBlob();
	const highlightedInfo = useHighlightedLinesInfo(lineNumber);
	const fileLineRef = useRef(null);
	const [highlightPosition, setHighlightPosition] = useState(void 0);
	useLayoutEffect(() => {
		if (!highlightedInfo || !fileLineRef.current) {
			setHighlightPosition(void 0);
			return;
		}
		setHighlightPosition(calculateHighlightOffsetAndWidth(highlightedInfo, fileLineRef.current, lineNumber, tabSize, rawText ?? ""));
	}, [
		highlightedInfo,
		lineNumber,
		tabSize,
		rawText
	]);
	const sharedRefCallback = useRegisterLineObserver(sharedLineObserver, codeLineData, codeLineToSectionMap?.get(lineNumber)?.length ?? 0);
	const wrapOption = useCodeViewOptions().codeWrappingOption;
	const overlaySymbols = useSearchResults(lineNumber);
	const focusedSymbol = useFocusedSearchResult(lineNumber);
	const isFirstHighlightedLine = highlightedInfo?.start.line === lineNumber;
	const menuAnchorRef = useRef(null);
	const menuRef = useRef(null);
	useLayoutEffect(() => {
		if (isFirstHighlightedLine) menuRef.current?.setAnchor(menuAnchorRef.current);
	}, [isFirstHighlightedLine]);
	return /* @__PURE__ */ jsx("div", {
		ref: (element) => {
			measureRef?.(element);
			sharedRefCallback(element);
		},
		"data-key": virtualKey,
		"data-index": virtualIndex,
		className: clsx(codeLineClassName, "react-code-text react-code-line-contents", virtualOffset && "virtual", wrapOption.enabled && measureRef && "react-code-text-cell"),
		style: {
			transform: virtualOffset ? `translateY(${virtualOffset}px)` : void 0,
			minHeight: wrapOption.enabled ? currentLineHeight : "auto"
		},
		onClick,
		children: /* @__PURE__ */ jsxs("div", {
			ref: menuAnchorRef,
			children: [
				highlightedInfo && /* @__PURE__ */ jsx(HighlighterElement, {
					lineNumber,
					highlightPosition
				}),
				collapsed && !highlightedInfo && /* @__PURE__ */ jsx(HighlighterElement, {
					subtle: true,
					lineNumber,
					highlightPosition
				}),
				overlaySymbols && overlaySymbols.length > 0 && /* @__PURE__ */ jsx(HighlightedOverlay, {
					symbols: overlaySymbols,
					focusedSymbol,
					className: CodeLine_module_default.highlightedOverlayInCodeLine,
					lineNumber
				}),
				/* @__PURE__ */ jsx(SyntaxHighlightedLine, {
					id,
					lineNumber,
					stylingDirectivesLine,
					current: !!highlightedInfo,
					rawText,
					forceVisible,
					ref: fileLineRef,
					shouldUseInert,
					colorizedLine
				}),
				wrapOption.enabled && /* @__PURE__ */ jsx(ExpandRowEllipsis, {
					codeLineData,
					setIsCollapsed,
					onLineStickOrUnstick,
					leftOffset: 0
				}),
				isFirstHighlightedLine && copilotAccessAllowed && /* @__PURE__ */ jsx(CopilotButton, {
					ref: menuRef,
					rowBeginNumber: highlightedInfo.start.line,
					rowEndNumber: highlightedInfo.end.line,
					id: "code-line-copilot-button"
				})
			]
		})
	});
}
CodeLineUnmemoized.displayName = "CodeLineUnmemoized";
function HighlighterElement(t0) {
	const $ = c(7);
	const { lineNumber, highlightPosition, subtle } = t0;
	const isSafari = useIsSafari();
	const hasOffset = highlightPosition?.offset !== void 0;
	const hasWidth = highlightPosition?.width !== void 0;
	const offset = highlightPosition?.offset ?? -72;
	const width = highlightPosition?.width ?? 0;
	const widthWithOffset = hasOffset && hasWidth ? width : width + 82;
	const t1 = subtle ? "var(--bgColor-neutral-muted, var(--color-neutral-subtle))" : "var(--bgColor-attention-muted, var(--color-attention-subtle))";
	const t2 = subtle ? "inset 2px 0 0 var(--fgColor-muted, var(--color-fg-subtle))" : "inset 2px 0 0 var(--fgColor-attention, var(--color-attention-fg))";
	const t3 = isSafari ? "-3px" : 0;
	const t4 = `${offset}px`;
	const t5 = hasWidth ? `${widthWithOffset}px` : "calc(100% + 72px)";
	let t6;
	if ($[0] !== lineNumber || $[1] !== t1 || $[2] !== t2 || $[3] !== t3 || $[4] !== t4 || $[5] !== t5) {
		t6 = jsx("div", {
			className: CodeLine_module_default.highlighterElement,
			style: {
				backgroundColor: t1,
				boxShadow: t2,
				top: t3,
				left: t4,
				width: t5
			}
		}, `highlighted-line-${lineNumber}`);
		$[0] = lineNumber;
		$[1] = t1;
		$[2] = t2;
		$[3] = t3;
		$[4] = t4;
		$[5] = t5;
		$[6] = t6;
	} else t6 = $[6];
	return t6;
}
HighlighterElement.displayName = "HighlighterElement";
export { useCursorEndLineNumber as $, expandRow as A, isSymbol as B, SelectAllShortcutButton as C, calculateLineNumberFromOffset as D, buildRowClass as E, getCopyStateUI as F, showHiddenUnicodeCharacters as G, parseDirectives as H, handleAddReference as I, useCodeHTML as J, showHiddenUnicodeCharactersRaw as K, hasHiddenUnicodeCharacters as L, forceAnnouncementToScreenReaders as M, formatBlobRange as N, copyText as O, getActualLineNumberBinarySearch as P, useCurrentLineHeight as Q, isHiddenUnicodeShown as R, SearchResultsProvider as S, applyStickyToParentStartLines as T, parseFileAnchor as U, measureMonospaceTextWidth as V, setKeyboardNavUsed as W, useCurrentBlame as X, useCopyRawBlobContents as Y, useCurrentBlob as Z, HighlightedOverlay as _, CopilotCodeLinesMenu as a, useHighlightedLinesInfo as at, LineNumberNoVirtualziation as b, CurrentLineRefMapProvider as c, useLineElementMap as ct, EmptyDeferredMetadata as d, useShouldDoNoVirtualization as dt, useCursorNavigation as et, HiddenUnicodeAlert as f, HighlightedLinesProvider as g, HighlightedLinesOverlay as h, CopilotButtonContainer as i, useFocusSymbolPane as it, focusSymbolSearch as j, expandAllRows as k, DeferredASTProvider as l, useLinesSubscription as lt, HighlightedLineMenuContainer as m, CodeLines as n, useDeferredASTQuery as nt, CurrentBlameProvider as o, useIsCursorEnabled as ot, HighlightedLineMenu as p, textAreaId as q, CodeLinesNoVirtualization as r, useDeferredMetadata as rt, CurrentBlobProvider as s, useKeyboardNavUsed as st, CodeLine as t, useCursorStartLineNumber as tt, DeferredMetadataProvider as u, useSharedLineObserver as ut, HighlightedSymbolsOverlay as v, SyntaxHighlightedOverlay as w, MarketplaceEnabledProvider as x, LineNumber as y, isLineInViewport as z };
