import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Mi as XIcon, Qt as Heading$2, an as IconButton, bn as Link, hi as TriangleDownIcon, i as AgentIcon, m as ArrowUpRightIcon, n as ActionList, o as AlertIcon, pt as DotFillIcon, qr as Stack } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { t as SkeletonAvatar } from "./server-TreeView-BeVCvZ0v-BAEuIsb-.js";
import { n as useCurrentRepository, t as CurrentRepositoryProvider } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { a as updateSearchParams } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { t as ConsecutiveCAPI401sProvider } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { t as CopilotChatProvider } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { C as useLocalStorageCache } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { t as WithShimmerEffect } from "./server-WithShimmerEffect-C6EPOEv6-DHTqBfIK.js";
import { t as useExternalAnchor } from "./server-react-partial-anchor-DSxm7g5E-DAe-R2_8.js";
import { n as TaskLeadingVisual, o as getTaskTitle } from "./server-TaskLeadingVisual-DlKGcMc6-CLgHXns0.js";
import { O as useAgentInfo } from "./server-CopilotCodingAgentQuotaBanner-W2Ye6Fax-B_w68npu.js";
import { E as useTasks, T as useSSOChangeDetection, b as useCreateAPITask, f as generateTaskPathForRepo, g as getSortedResourceIds, h as getFlatTaskList, i as NewAgentTaskForm, l as fetchPullRequests, m as getAgentTasksQueryKeyForMutation, o as PR_MAP_STORAGE_KEY, p as getAgentTasksQueryKey, s as copilotChatPayloadQueryOptions, u as fetchTasks, v as setFlatTaskList, y as useCopilotChatPayloadQuery } from "./server-use-sso-change-detection-DGHiXtJk-Cl1y9joK.js";
import { n as getAPITaskParamsFromAttempt, t as TaskCreationFailedBannerList } from "./server-TaskCreationFailedBanner-DV1JXc78-BD_1xX9A.js";
import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var CCAPopover_module_default = {
	popover: "CCAPopover-module_2BWRAa_popover",
	popover_content: "CCAPopover-module_2BWRAa_popover_content",
	popover_wrapper: "CCAPopover-module_2BWRAa_popover_wrapper"
};
function CCAPopover({ showPopover, dismissPopover, anchorRef }) {
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const popoverRef = useRef(null);
	useLayoutEffect(() => {
		if (!showPopover || !anchorRef.current || !popoverRef.current) return;
		const anchorRect = anchorRef.current.getBoundingClientRect();
		const popover = popoverRef.current;
		const popoverRect = popover.getBoundingClientRect();
		const popoverLeft = anchorRect.left + anchorRect.width / 2 - popoverRect.width / 2;
		popover.style.position = "fixed";
		popover.style.top = `${anchorRect.bottom + 8}px`;
		popover.style.left = `${popoverLeft}px`;
	}, [showPopover, anchorRef]);
	if (!showPopover) return null;
	const handleLearnMoreClick = () => {
		sendClickAnalyticsEvent({
			category: "copilot-coding-agent-popover",
			action: "learn-more",
			tag: "link",
			group: "expand",
			location: "global-copilot-menu"
		});
	};
	const handleDismissClick = () => {
		sendClickAnalyticsEvent({
			category: "copilot-coding-agent-popover",
			action: "dismiss",
			tag: "button",
			group: "expand",
			location: "global-copilot-menu"
		});
		dismissPopover();
	};
	return /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
		ref: popoverRef,
		className: CCAPopover_module_default.popover_wrapper,
		children: /* @__PURE__ */ jsx(Popover_default, {
			open: showPopover,
			caret: "top",
			className: CCAPopover_module_default.popover,
			children: /* @__PURE__ */ jsxs(Popover_default.Content, {
				overflow: "visible",
				className: CCAPopover_module_default.popover_content,
				"data-analytics-visible": JSON.stringify({
					category: "copilot-coding-agent-popover",
					action: "visible",
					group: "expand",
					location: "global-copilot-menu"
				}),
				children: [
					/* @__PURE__ */ jsx(Heading$2, {
						as: "h3",
						variant: "small",
						className: "h5 mb-1",
						children: "Start a task with Copilot coding agent"
					}),
					/* @__PURE__ */ jsx("p", { children: "Describe your task in natural language. Copilot will work in the background and open a pull request for your review." }),
					/* @__PURE__ */ jsxs(Stack, {
						className: "mt-2",
						direction: "horizontal",
						gap: "condensed",
						children: [/* @__PURE__ */ jsx(ButtonComponent, {
							as: "a",
							href: "https://docs.github.com/copilot/concepts/coding-agent/coding-agent",
							"aria-label": "Learn more about Copilot coding agent",
							onClick: handleLearnMoreClick,
							children: "Learn more"
						}), /* @__PURE__ */ jsx(ButtonComponent, {
							variant: "invisible",
							onClick: handleDismissClick,
							children: "Dismiss"
						})]
					})
				]
			})
		})
	}) });
}
CCAPopover.displayName = "CCAPopover";
function FreeUserPopover({ showPopover, dismissPopover, anchorRef }) {
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const popoverRef = useRef(null);
	useLayoutEffect(() => {
		if (!showPopover || !anchorRef.current || !popoverRef.current) return;
		const anchorRect = anchorRef.current.getBoundingClientRect();
		const popover = popoverRef.current;
		const popoverRect = popover.getBoundingClientRect();
		const popoverLeft = anchorRect.left + anchorRect.width / 2 - popoverRect.width / 2;
		popover.style.position = "fixed";
		popover.style.top = `${anchorRect.bottom + 8}px`;
		popover.style.left = `${popoverLeft}px`;
	}, [showPopover, anchorRef]);
	if (!showPopover) return null;
	const handleDismissClick = () => {
		sendClickAnalyticsEvent({
			category: "copilot-coding-agent-free-popover",
			action: "dismiss",
			tag: "button",
			group: "expand",
			location: "global-copilot-menu"
		});
		dismissPopover();
	};
	return /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
		ref: popoverRef,
		className: CCAPopover_module_default.popover_wrapper,
		children: /* @__PURE__ */ jsx(Popover_default, {
			open: showPopover,
			caret: "top",
			className: CCAPopover_module_default.popover,
			children: /* @__PURE__ */ jsxs(Popover_default.Content, {
				className: CCAPopover_module_default.popover_content,
				"data-analytics-visible": JSON.stringify({
					category: "copilot-coding-agent-free-popover",
					action: "visible",
					group: "expand",
					location: "global-copilot-menu"
				}),
				children: [
					/* @__PURE__ */ jsx(Heading$2, {
						as: "h3",
						variant: "small",
						className: "h5 mb-1",
						children: "Start a task with Copilot coding agent"
					}),
					/* @__PURE__ */ jsx("p", { children: "Copilot works in the cloud and opens a pull request for your review. Enjoy up to 5 free uses this month with your Copilot Free plan." }),
					/* @__PURE__ */ jsx(Stack, {
						className: "mt-2",
						direction: "horizontal",
						gap: "condensed",
						children: /* @__PURE__ */ jsx(ButtonComponent, {
							onClick: handleDismissClick,
							children: "Dismiss"
						})
					})
				]
			})
		})
	}) });
}
FreeUserPopover.displayName = "FreeUserPopover";
var GlobalCopilotOverlay_module_default = {
	agentAvatarTrailingVisual: "GlobalCopilotOverlay-module_AkCIIW_agentAvatarTrailingVisual",
	animatedText: "GlobalCopilotOverlay-module_AkCIIW_animatedText",
	content: "GlobalCopilotOverlay-module_AkCIIW_content",
	copilotDisclosure: "GlobalCopilotOverlay-module_AkCIIW_copilotDisclosure",
	copilotDisclosureText: "GlobalCopilotOverlay-module_AkCIIW_copilotDisclosureText",
	dots: "GlobalCopilotOverlay-module_AkCIIW_dots",
	failedTaskBanners: "GlobalCopilotOverlay-module_AkCIIW_failedTaskBanners",
	header: "GlobalCopilotOverlay-module_AkCIIW_header",
	headerActions: "GlobalCopilotOverlay-module_AkCIIW_headerActions",
	messageState: "GlobalCopilotOverlay-module_AkCIIW_messageState",
	messageStateDescription: "GlobalCopilotOverlay-module_AkCIIW_messageStateDescription",
	messageStateHeading: "GlobalCopilotOverlay-module_AkCIIW_messageStateHeading",
	optimisticTaskIcon: "GlobalCopilotOverlay-module_AkCIIW_optimisticTaskIcon",
	overlay: "GlobalCopilotOverlay-module_AkCIIW_overlay",
	retryButton: "GlobalCopilotOverlay-module_AkCIIW_retryButton",
	shimmeringTaskTitle: "GlobalCopilotOverlay-module_AkCIIW_shimmeringTaskTitle",
	task: "GlobalCopilotOverlay-module_AkCIIW_task",
	tasksList: "GlobalCopilotOverlay-module_AkCIIW_tasksList",
	tasksListHeading: "GlobalCopilotOverlay-module_AkCIIW_tasksListHeading",
	taskStartDate: "GlobalCopilotOverlay-module_AkCIIW_taskStartDate",
	viewAllLink: "GlobalCopilotOverlay-module_AkCIIW_viewAllLink"
};
function GlobalCopilotOverlay(t0) {
	const $ = c(24);
	const { onClose, decoupledModeEnabled } = t0;
	useSSOChangeDetection();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { taskFilter: "active" };
		$[0] = t1;
	} else t1 = $[0];
	const { tasks, isLoading, isError } = useTasks(t1);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[1] = t2;
	} else t2 = $[1];
	const [failedTasks, setFailedTasks] = useState(t2);
	const [t3] = useState(_temp);
	const { initialText, initialBranch } = t3;
	let t4;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = getAgentTasksQueryKeyForMutation();
		$[2] = t4;
	} else t4 = $[2];
	let t5;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = (error, variables) => {
			setFailedTasks((prev) => [{
				...variables,
				errorMessage: error.message,
				timestamp: (/* @__PURE__ */ new Date()).toISOString()
			}, ...prev]);
		};
		$[3] = t5;
	} else t5 = $[3];
	let t6;
	if ($[4] !== decoupledModeEnabled) {
		t6 = {
			queryKey: t4,
			pageSize: 10,
			getFlatTaskList,
			setFlatTaskList,
			onError: t5,
			decoupledModeEnabled
		};
		$[4] = decoupledModeEnabled;
		$[5] = t6;
	} else t6 = $[5];
	const { createTask } = useCreateAPITask(t6);
	let t7;
	if ($[6] !== createTask || $[7] !== failedTasks) {
		t7 = (attemptIndex) => {
			const attempt = failedTasks[attemptIndex];
			if (attempt) {
				setFailedTasks((prev_0) => prev_0.filter((_, index) => index !== attemptIndex));
				createTask(getAPITaskParamsFromAttempt(attempt));
			}
		};
		$[6] = createTask;
		$[7] = failedTasks;
		$[8] = t7;
	} else t7 = $[8];
	const handleRetry = t7;
	let t8;
	if ($[9] !== onClose) {
		t8 = (event) => {
			if (!(event.metaKey || event.ctrlKey) && onClose) onClose();
		};
		$[9] = onClose;
		$[10] = t8;
	} else t8 = $[10];
	const handleLinkClick = t8;
	let t9;
	if ($[11] !== createTask || $[12] !== decoupledModeEnabled || $[13] !== failedTasks || $[14] !== handleLinkClick || $[15] !== handleRetry || $[16] !== initialBranch || $[17] !== initialText || $[18] !== isError || $[19] !== isLoading || $[20] !== onClose || $[21] !== tasks) {
		const defaultToTaskInput = isFeatureEnabled("copilot_default_to_task_input");
		let t10;
		if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
			t10 = (index_0) => setFailedTasks((prev_1) => prev_1.filter((__0, i) => i !== index_0));
			$[23] = t10;
		} else t10 = $[23];
		t9 = jsxs("div", {
			className: GlobalCopilotOverlay_module_default.overlay,
			children: [jsxs("div", {
				className: GlobalCopilotOverlay_module_default.header,
				children: [jsx("h2", {
					className: "f5",
					children: "Agents"
				}), defaultToTaskInput && jsxs("div", {
					className: "d-flex gap-2",
					children: [jsx(IconButton, {
						icon: ArrowUpRightIcon,
						"aria-label": "Navigate to Copilot",
						variant: "invisible",
						size: "small",
						as: "a",
						href: "/copilot/agents",
						onClick: (e) => {
							sendEvent("agent_sessions.global_agents_menu", {
								target: "NAVIGATE_TO_AGENTS_FULLSCREEN",
								defaultToTaskInput,
								defaultToTaskControl: isFeatureEnabled("copilot_default_to_task_input_control_group")
							});
							handleLinkClick(e);
						}
					}), jsx(IconButton, {
						icon: XIcon,
						"aria-label": "Close",
						variant: "invisible",
						size: "small",
						onClick: onClose
					})]
				})]
			}), jsxs("div", {
				className: GlobalCopilotOverlay_module_default.content,
				children: [
					jsx(NewAgentTaskForm, {
						createTask,
						eventType: "agents_panel",
						showHeader: false,
						initialText,
						initialBranch,
						decoupledModeEnabled
					}),
					jsx(TaskCreationFailedBannerList, {
						attempts: failedTasks,
						onRetry: handleRetry,
						onDismiss: t10,
						className: GlobalCopilotOverlay_module_default.failedTaskBanners
					}),
					isLoading && tasks.length === 0 ? jsx(TasksLoadingState, {}) : jsxs(Fragment$1, { children: [isError ? jsx(TasksErrorState, {}) : tasks.length === 0 ? jsx(TasksEmptyState, {}) : jsx(TasksList, {
						tasks,
						onLinkClick: handleLinkClick
					}), jsx(CopilotDisclosure, {})] })
				]
			})]
		});
		$[11] = createTask;
		$[12] = decoupledModeEnabled;
		$[13] = failedTasks;
		$[14] = handleLinkClick;
		$[15] = handleRetry;
		$[16] = initialBranch;
		$[17] = initialText;
		$[18] = isError;
		$[19] = isLoading;
		$[20] = onClose;
		$[21] = tasks;
		$[22] = t9;
	} else t9 = $[22];
	return t9;
}
GlobalCopilotOverlay.displayName = "GlobalCopilotOverlay";
function _temp() {
	const entrypointMessage = copilotLocalStorage.getTaskEntrypointMessage();
	if (entrypointMessage?.message) {
		copilotLocalStorage.setTaskEntrypointMessage(null);
		return {
			initialText: entrypointMessage.message,
			initialBranch: entrypointMessage.branch
		};
	}
	return {};
}
var TaskItem = memo(function TaskItem(t0) {
	const $ = c(18);
	const { taskId, isArchived, state, updatedAt, title, prState, prNumber, nwo, prGlobalId, prInMergeQueue, latestSessionId, onLinkClick, agentId } = t0;
	const { data: agentInfo } = useAgentInfo(agentId ?? null);
	const agentAvatarUrl = agentInfo?.avatar_url;
	let t1;
	if ($[0] !== agentAvatarUrl || $[1] !== agentInfo?.display_name || $[2] !== isArchived || $[3] !== latestSessionId || $[4] !== nwo || $[5] !== onLinkClick || $[6] !== prGlobalId || $[7] !== prInMergeQueue || $[8] !== prNumber || $[9] !== prState || $[10] !== state || $[11] !== taskId || $[12] !== title || $[13] !== updatedAt) {
		const taskUrl = generateTaskPathForRepo({
			repositoryNwo: nwo,
			pullRequestNumber: prNumber,
			sessionId: latestSessionId,
			taskId
		});
		let t2;
		if ($[15] !== onLinkClick || $[16] !== prGlobalId) {
			t2 = (e) => {
				onLinkClick(e);
				sendEvent("agent_sessions.global_agents_menu", {
					target: "VIEW_TASK_FROM_AGENTS_MENU",
					task_id: prGlobalId
				});
			};
			$[15] = onLinkClick;
			$[16] = prGlobalId;
			$[17] = t2;
		} else t2 = $[17];
		t1 = jsxs(ActionList.LinkItem, {
			className: GlobalCopilotOverlay_module_default.task,
			href: taskUrl,
			onClick: t2,
			children: [
				jsx(ActionList.LeadingVisual, { children: jsx(TaskLeadingVisual, {
					prState,
					prInMergeQueue,
					sessionState: state,
					isArchived
				}) }),
				title,
				jsxs(ActionList.Description, {
					variant: "block",
					className: "no-wrap",
					children: [nwo, updatedAt && jsxs(Fragment$1, { children: [
						" ",
						"· ",
						jsx(RelativeTime, {
							datetime: updatedAt,
							format: "micro",
							className: GlobalCopilotOverlay_module_default.taskStartDate
						})
					] })]
				}),
				agentAvatarUrl && jsx(ActionList.TrailingVisual, {
					className: GlobalCopilotOverlay_module_default.agentAvatarTrailingVisual,
					children: jsx(GitHubAvatar, {
						src: agentAvatarUrl,
						size: 16,
						square: true,
						alt: agentInfo?.display_name || "Agent"
					})
				})
			]
		});
		$[0] = agentAvatarUrl;
		$[1] = agentInfo?.display_name;
		$[2] = isArchived;
		$[3] = latestSessionId;
		$[4] = nwo;
		$[5] = onLinkClick;
		$[6] = prGlobalId;
		$[7] = prInMergeQueue;
		$[8] = prNumber;
		$[9] = prState;
		$[10] = state;
		$[11] = taskId;
		$[12] = title;
		$[13] = updatedAt;
		$[14] = t1;
	} else t1 = $[14];
	return t1;
});
TaskItem.displayName = "TaskItem";
function TasksList(t0) {
	const $ = c(13);
	const { tasks, onLinkClick } = t0;
	let t1;
	if ($[0] !== tasks) {
		t1 = tasks.filter(_temp2);
		$[0] = tasks;
		$[1] = t1;
	} else t1 = $[1];
	const optimisticTasks = t1;
	let t2;
	if ($[2] !== tasks) {
		t2 = tasks.filter(_temp3);
		$[2] = tasks;
		$[3] = t2;
	} else t2 = $[3];
	const hydratedTasks = t2;
	const currentRepo = useCurrentRepository();
	let t3;
	bb0: {
		let t4;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t4 = new URL("/copilot/agents", window.location.origin);
			$[4] = t4;
		} else t4 = $[4];
		const url = t4;
		if (currentRepo?.ownerLogin && currentRepo?.name) {
			const repoParam = `${encodeURIComponent(currentRepo.ownerLogin)}/${encodeURIComponent(currentRepo.name)}`;
			t3 = `${url.pathname}?repo=${repoParam}`;
			break bb0;
		}
		t3 = url.pathname;
	}
	const viewAllTasksUrl = t3;
	let t4;
	if ($[5] !== hydratedTasks || $[6] !== onLinkClick || $[7] !== optimisticTasks || $[8] !== tasks || $[9] !== viewAllTasksUrl) {
		let t5;
		if ($[11] !== onLinkClick) {
			t5 = (task_2) => {
				if (!task_2.nwo) return null;
				return jsx(TaskItem, {
					taskId: task_2.id,
					isArchived: !!task_2.archived_at,
					state: task_2.latest_session_state,
					updatedAt: task_2.latest_session_updated_at,
					title: getTaskTitle(task_2, task_2.pull?.title),
					prState: task_2.pull?.state,
					prNumber: task_2.pull?.number,
					nwo: task_2.nwo,
					prGlobalId: task_2.pull?.global_relay_id,
					prInMergeQueue: task_2.pull?.inMergeQueue ?? false,
					latestSessionId: task_2.latest_session_id,
					onLinkClick,
					agentId: task_2.agentId ? Number(task_2.agentId) : void 0
				}, task_2.clientGeneratedId ?? task_2.id ?? task_2.resource_id);
			};
			$[11] = onLinkClick;
			$[12] = t5;
		} else t5 = $[12];
		t4 = jsx(ActionList, {
			showDividers: true,
			className: GlobalCopilotOverlay_module_default.tasksList,
			children: jsxs(ActionList.Group, { children: [
				jsxs(ActionList.GroupHeading, {
					as: "h3",
					className: GlobalCopilotOverlay_module_default.tasksListHeading,
					children: [
						"Recent sessions",
						" ",
						tasks && tasks.length !== 0 && jsx(Link, {
							href: viewAllTasksUrl,
							className: GlobalCopilotOverlay_module_default.viewAllLink,
							onClick: (e) => {
								sendEvent("agent_sessions.global_agents_menu", { target: "VIEW_ALL_TASKS_LINK" });
								onLinkClick(e);
							},
							children: "View all"
						})
					]
				}),
				optimisticTasks.map(_temp4),
				hydratedTasks.map(t5)
			] })
		});
		$[5] = hydratedTasks;
		$[6] = onLinkClick;
		$[7] = optimisticTasks;
		$[8] = tasks;
		$[9] = viewAllTasksUrl;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
TasksList.displayName = "TasksList";
function _temp4(task_1) {
	return jsx(OptimisticTaskItem, { task: task_1 }, task_1.clientGeneratedId);
}
function _temp3(task_0) {
	if (task_0.isOptimistic) return false;
	return task_0.pull || task_0.nwo;
}
function _temp2(task) {
	return task.isOptimistic;
}
function OptimisticTaskItem({ task }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		className: GlobalCopilotOverlay_module_default.task,
		disabled: true,
		"aria-label": `Creating task in ${task.nwo}`,
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, {
				className: GlobalCopilotOverlay_module_default.optimisticTaskIcon,
				children: /* @__PURE__ */ jsx(DotFillIcon, {})
			}),
			/* @__PURE__ */ jsx(WithShimmerEffect, {
				className: GlobalCopilotOverlay_module_default.shimmeringTaskTitle,
				children: task.problemStatement
			}),
			/* @__PURE__ */ jsx(ActionList.Description, {
				variant: "block",
				className: "no-wrap",
				children: task.nwo
			})
		]
	});
}
OptimisticTaskItem.displayName = "OptimisticTaskItem";
function TasksLoadingState() {
	return /* @__PURE__ */ jsx(ActionList, {
		showDividers: true,
		className: GlobalCopilotOverlay_module_default.tasksList,
		children: /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
			as: "h3",
			className: GlobalCopilotOverlay_module_default.tasksListHeading,
			children: /* @__PURE__ */ jsx(SkeletonText, {
				size: "bodySmall",
				width: "4.75rem"
			})
		}), Array.from({ length: 3 }, (_, index) => /* @__PURE__ */ jsxs(ActionList.Item, {
			disabled: true,
			children: [
				/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(SkeletonAvatar, { size: 16 }) }),
				/* @__PURE__ */ jsx(SkeletonText, { maxWidth: "75%" }),
				/* @__PURE__ */ jsx(ActionList.Description, {
					variant: "block",
					children: /* @__PURE__ */ jsx(SkeletonText, {
						size: "bodySmall",
						maxWidth: "50%"
					})
				})
			]
		}, index))] })
	});
}
TasksLoadingState.displayName = "TasksLoadingState";
function TasksEmptyState() {
	return /* @__PURE__ */ jsx(MessageState, {
		heading: "Start a new task with Copilot",
		description: "Describe your task in natural language. Copilot will work in the background and open a pull request for your review.",
		linkHref: "https://docs.github.com/copilot/concepts/coding-agent/coding-agent",
		linkText: "Learn more about Copilot coding agent"
	});
}
TasksEmptyState.displayName = "TasksEmptyState";
function TasksErrorState() {
	return /* @__PURE__ */ jsx(MessageState, {
		showAlertIcon: true,
		heading: "Tasks couldn’t be loaded",
		description: "Try again or, if the problem persists, contact support.",
		linkHref: "https://githubstatus.com/",
		linkText: "GitHub status"
	});
}
TasksErrorState.displayName = "TasksErrorState";
function MessageState({ showAlertIcon = false, heading, description, linkHref, linkText }) {
	return /* @__PURE__ */ jsxs("div", {
		className: GlobalCopilotOverlay_module_default.messageState,
		children: [
			/* @__PURE__ */ jsxs("h3", {
				className: GlobalCopilotOverlay_module_default.messageStateHeading,
				children: [showAlertIcon && /* @__PURE__ */ jsx(AlertIcon, { className: "var(--fgColor-attention)" }), heading]
			}),
			/* @__PURE__ */ jsx("p", {
				className: GlobalCopilotOverlay_module_default.messageStateDescription,
				children: description
			}),
			linkHref && linkText && /* @__PURE__ */ jsx(Link, {
				href: linkHref,
				inline: true,
				className: "d-inline-block",
				children: linkText
			})
		]
	});
}
MessageState.displayName = "MessageState";
function CopilotDisclosure() {
	return /* @__PURE__ */ jsx("div", {
		className: GlobalCopilotOverlay_module_default.copilotDisclosure,
		children: /* @__PURE__ */ jsxs("p", {
			className: GlobalCopilotOverlay_module_default.copilotDisclosureText,
			children: [
				/* @__PURE__ */ jsx(Link, {
					href: "https://docs.github.com/copilot/responsible-use/copilot-coding-agent",
					target: "_blank",
					rel: "noopener noreferrer",
					muted: true,
					inline: true,
					children: "Copilot"
				}),
				" ",
				"uses AI. Check for mistakes."
			]
		})
	});
}
CopilotDisclosure.displayName = "CopilotDisclosure";
var TOGGLE_COPILOT_OVERLAY = "toggle-copilot-overlay";
function GlobalAgentsMenuWithAnchor({ open, setOpen, anchorRef, anchorProps, copilotApiUrl, ...props }) {
	return /* @__PURE__ */ jsx(GlobalAgentsMenuOverlay, {
		...props,
		anchorRef,
		open,
		setOpen,
		copilotApiUrl,
		renderAnchor: (renderAnchorProps) => /* @__PURE__ */ jsx(ButtonComponent, {
			...renderAnchorProps,
			...anchorProps,
			onClick: (e) => {
				renderAnchorProps.onClick?.(e);
				anchorProps?.onClick?.(e);
			},
			leadingVisual: AgentIcon,
			trailingVisual: TriangleDownIcon,
			id: props.agentsButtonId ?? "global-copilot-agent-button",
			ref: anchorRef,
			className: clsx(renderAnchorProps.className, anchorProps?.className),
			"aria-label": "Open agents panel",
			children: ""
		})
	});
}
GlobalAgentsMenuWithAnchor.displayName = "GlobalAgentsMenuWithAnchor";
function GlobalAgentsMenu(props) {
	const { reactPartialAnchor, ...rest } = props;
	const { ref: anchorRef, open, setOpen } = useExternalAnchor(reactPartialAnchor);
	return jsx(GlobalAgentsMenuOverlay, {
		...rest,
		anchorRef,
		open,
		setOpen,
		renderAnchor: null
	});
}
GlobalAgentsMenu.displayName = "GlobalAgentsMenu";
function GlobalAgentsMenuOverlay(props) {
	const { setValue: setCachedPRMap } = useLocalStorageCache(PR_MAP_STORAGE_KEY);
	const queryClient = useQueryClient();
	const [hasPrefetched, setHasPrefetched] = useState(false);
	const { anchorRef, open, setOpen } = props;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const { repository, popoverAvailable, agentsButtonId, copilotApiUrl, decoupledModeEnabled = false, freeUserPopoverAvailable } = props;
	const handleClose = () => {
		setOpen(false);
	};
	const [showPopover, setShowPopover] = useState(popoverAvailable || freeUserPopoverAvailable || false);
	const dismissCCAPopover = useCallback(async () => {
		setShowPopover(false);
		await verifiedFetch(`/settings/dismiss-notice/copilot_coding_agent_entry_point${freeUserPopoverAvailable ? "_free" : ""}_popover`, { method: "POST" });
	}, [setShowPopover, freeUserPopoverAvailable]);
	useEffect(() => {
		if (open && showPopover) dismissCCAPopover();
	}, [
		open,
		dismissCCAPopover,
		showPopover
	]);
	useEffect(() => {
		if (open) sendClickAnalyticsEvent({
			category: "copilot-coding-agent-global-dropdown",
			action: "open"
		});
	}, [open, sendClickAnalyticsEvent]);
	useEffect(() => {
		const handleToggleCopilotOverlay = () => {
			const tooltip = anchorRef.current?.nextElementSibling;
			if (!open && tooltip && tooltip instanceof HTMLElement && tooltip.matches("tool-tip[popover=\"manual\"]")) tooltip.setAttribute("style", "display: none");
			setOpen(!open);
		};
		document.addEventListener(TOGGLE_COPILOT_OVERLAY, handleToggleCopilotOverlay);
		return () => {
			document.removeEventListener(TOGGLE_COPILOT_OVERLAY, handleToggleCopilotOverlay);
		};
	}, [
		setOpen,
		open,
		anchorRef
	]);
	useEffect(() => {
		const urlParams = new URLSearchParams(window.location.search);
		if (urlParams.get("open_agents_panel") === "1" && !open) {
			setOpen(true);
			urlParams.delete("open_agents_panel");
			updateSearchParams(urlParams);
		}
	}, [open, setOpen]);
	useEffect(() => {
		if (hasPrefetched) return;
		const prefetchTasksAndPullRequests = async () => {
			try {
				const tasksQueryKey = getAgentTasksQueryKey(1, "active");
				await queryClient.prefetchQuery({
					queryKey: tasksQueryKey,
					queryFn: async () => await fetchTasks({
						queryClient,
						copilotApiUrl,
						queryKey: tasksQueryKey,
						queryParams: { archived: false }
					})
				});
				const cachedTasks = queryClient.getQueryData(tasksQueryKey)?.[0] ?? [];
				if (cachedTasks.length > 0) {
					const tasksWithResourceIds = cachedTasks.filter((task) => task.resource_id !== void 0);
					if (tasksWithResourceIds.length > 0) {
						const pullRequestIds = getSortedResourceIds(tasksWithResourceIds);
						await queryClient.prefetchQuery({
							queryKey: ["agent-sessions-pull-requests", pullRequestIds],
							queryFn: async () => await fetchPullRequests(tasksWithResourceIds, setCachedPRMap)
						});
					}
				}
				setHasPrefetched(true);
			} catch {}
		};
		const buttonElement = document.getElementById(agentsButtonId ?? "global-copilot-agent-button");
		if (!buttonElement) return;
		buttonElement.addEventListener("mouseenter", prefetchTasksAndPullRequests);
		buttonElement.addEventListener("focus", prefetchTasksAndPullRequests);
		return () => {
			buttonElement.removeEventListener("mouseenter", prefetchTasksAndPullRequests);
			buttonElement.removeEventListener("focus", prefetchTasksAndPullRequests);
		};
	}, [
		hasPrefetched,
		queryClient,
		setCachedPRMap,
		agentsButtonId,
		copilotApiUrl
	]);
	useEffect(() => {
		const buttonElement_0 = document.getElementById(agentsButtonId ?? "global-copilot-agent-button");
		if (!buttonElement_0) return;
		const handlePrefetch = () => {
			queryClient.prefetchQuery(copilotChatPayloadQueryOptions);
		};
		buttonElement_0.addEventListener("mouseenter", handlePrefetch, { once: true });
		buttonElement_0.addEventListener("focus", handlePrefetch, { once: true });
		return () => {
			buttonElement_0.removeEventListener("mouseenter", handlePrefetch);
			buttonElement_0.removeEventListener("focus", handlePrefetch);
		};
	}, [queryClient, agentsButtonId]);
	useEffect(() => {
		if (!open) {
			const tooltip_0 = anchorRef.current?.nextElementSibling;
			if (tooltip_0 && tooltip_0 instanceof HTMLElement && tooltip_0.matches("tool-tip[popover=\"manual\"]")) tooltip_0.removeAttribute("style");
		}
	}, [open, anchorRef]);
	const chatPayload = useCopilotChatPayloadQuery();
	return /* @__PURE__ */ jsxs(ConsecutiveCAPI401sProvider, { children: [/* @__PURE__ */ jsx(AnchoredOverlay, {
		width: "xlarge",
		variant: {
			regular: "anchored",
			narrow: "fullscreen"
		},
		align: "end",
		open,
		onOpen: () => setOpen(true),
		onClose: handleClose,
		anchorRef,
		renderAnchor: props.renderAnchor,
		preventOverflow: false,
		focusZoneSettings: { disabled: true },
		children: chatPayload ? /* @__PURE__ */ jsx(CopilotChatProvider, {
			threadId: null,
			workerPath: chatPayload.findFileWorkerPath,
			refs: chatPayload.refs ?? [],
			mode: "assistive",
			ssoOrganizations: chatPayload.ssoOrganizations ?? [],
			copilotChatPayload: chatPayload,
			children: repository ? /* @__PURE__ */ jsx(CurrentRepositoryProvider, {
				repository,
				children: /* @__PURE__ */ jsx(GlobalCopilotOverlay, {
					onClose: handleClose,
					decoupledModeEnabled
				})
			}) : /* @__PURE__ */ jsx(GlobalCopilotOverlay, {
				onClose: handleClose,
				decoupledModeEnabled
			})
		}) : null
	}), freeUserPopoverAvailable ? /* @__PURE__ */ jsx(FreeUserPopover, {
		showPopover,
		dismissPopover: dismissCCAPopover,
		anchorRef
	}) : /* @__PURE__ */ jsx(CCAPopover, {
		showPopover,
		dismissPopover: dismissCCAPopover,
		anchorRef
	})] });
}
GlobalAgentsMenuOverlay.displayName = "GlobalAgentsMenuOverlay";
export { TOGGLE_COPILOT_OVERLAY as n, GlobalAgentsMenuWithAnchor as t };
