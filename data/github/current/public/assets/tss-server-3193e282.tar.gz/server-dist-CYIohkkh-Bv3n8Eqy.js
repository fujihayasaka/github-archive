import { n as __exportAll } from "./server-rolldown-runtime-BO2ueIC9.js";
import { o as useId$1, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as __require } from "./server-chunk-DPETvcc5-SoS15Jre.js";
import { c as Text$1, i as ButtonComponent$1 } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Fi as getResponsiveAttributes, Hi as useProvidedRefOrCreate, Qt as Heading$2, _i as Truncate, an as IconButton$1, bn as Link$1, n as ActionList, pi as Tooltip$1, u as ArrowLeftIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as Overlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog$1 } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as isResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as Label$1 } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { r as UnderlineNav, t as Breadcrumbs_default } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { a as Token$1, i as Textarea, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import React, { createElement, forwardRef, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isElement, isValidElementType, typeOf } from "react-is";
import ReactDOM from "react-dom";
import deepmerge, { default as merge } from "deepmerge";
import l from "shallowequal";
import p from "@emotion/is-prop-valid";
import f from "hoist-non-react-statics";
import assign from "object-assign";
function stylis_min(W) {
	function M(d, c, e, h, a) {
		for (var m = 0, b = 0, v = 0, n = 0, q, g, x = 0, K = 0, k, u = k = q = 0, l = 0, r = 0, I = 0, t = 0, B = e.length, J = B - 1, y, f = "", p = "", F = "", G = "", C; l < B;) {
			g = e.charCodeAt(l);
			l === J && 0 !== b + n + v + m && (0 !== b && (g = 47 === b ? 10 : 47), n = v = m = 0, B++, J++);
			if (0 === b + n + v + m) {
				if (l === J && (0 < r && (f = f.replace(N, "")), 0 < f.trim().length)) {
					switch (g) {
						case 32:
						case 9:
						case 59:
						case 13:
						case 10: break;
						default: f += e.charAt(l);
					}
					g = 59;
				}
				switch (g) {
					case 123:
						f = f.trim();
						q = f.charCodeAt(0);
						k = 1;
						for (t = ++l; l < B;) {
							switch (g = e.charCodeAt(l)) {
								case 123:
									k++;
									break;
								case 125:
									k--;
									break;
								case 47:
									switch (g = e.charCodeAt(l + 1)) {
										case 42:
										case 47: a: {
											for (u = l + 1; u < J; ++u) switch (e.charCodeAt(u)) {
												case 47:
													if (42 === g && 42 === e.charCodeAt(u - 1) && l + 2 !== u) {
														l = u + 1;
														break a;
													}
													break;
												case 10: if (47 === g) {
													l = u + 1;
													break a;
												}
											}
											l = u;
										}
									}
									break;
								case 91: g++;
								case 40: g++;
								case 34:
								case 39: for (; l++ < J && e.charCodeAt(l) !== g;);
							}
							if (0 === k) break;
							l++;
						}
						k = e.substring(t, l);
						0 === q && (q = (f = f.replace(ca, "").trim()).charCodeAt(0));
						switch (q) {
							case 64:
								0 < r && (f = f.replace(N, ""));
								g = f.charCodeAt(1);
								switch (g) {
									case 100:
									case 109:
									case 115:
									case 45:
										r = c;
										break;
									default: r = O;
								}
								k = M(c, r, k, g, a + 1);
								t = k.length;
								0 < A && (r = X(O, f, I), C = H(3, k, r, c, D, z, t, g, a, h), f = r.join(""), void 0 !== C && 0 === (t = (k = C.trim()).length) && (g = 0, k = ""));
								if (0 < t) switch (g) {
									case 115: f = f.replace(da, ea);
									case 100:
									case 109:
									case 45:
										k = f + "{" + k + "}";
										break;
									case 107:
										f = f.replace(fa, "$1 $2");
										k = f + "{" + k + "}";
										k = 1 === w || 2 === w && L("@" + k, 3) ? "@-webkit-" + k + "@" + k : "@" + k;
										break;
									default: k = f + k, 112 === h && (k = (p += k, ""));
								}
								else k = "";
								break;
							default: k = M(c, X(c, f, I), k, h, a + 1);
						}
						F += k;
						k = I = r = u = q = 0;
						f = "";
						g = e.charCodeAt(++l);
						break;
					case 125:
					case 59:
						f = (0 < r ? f.replace(N, "") : f).trim();
						if (1 < (t = f.length)) switch (0 === u && (q = f.charCodeAt(0), 45 === q || 96 < q && 123 > q) && (t = (f = f.replace(" ", ":")).length), 0 < A && void 0 !== (C = H(1, f, c, d, D, z, p.length, h, a, h)) && 0 === (t = (f = C.trim()).length) && (f = "\0\0"), q = f.charCodeAt(0), g = f.charCodeAt(1), q) {
							case 0: break;
							case 64: if (105 === g || 99 === g) {
								G += f + e.charAt(l);
								break;
							}
							default: 58 !== f.charCodeAt(t - 1) && (p += P(f, q, g, f.charCodeAt(2)));
						}
						I = r = u = q = 0;
						f = "";
						g = e.charCodeAt(++l);
				}
			}
			switch (g) {
				case 13:
				case 10:
					47 === b ? b = 0 : 0 === 1 + q && 107 !== h && 0 < f.length && (r = 1, f += "\0");
					0 < A * Y && H(0, f, c, d, D, z, p.length, h, a, h);
					z = 1;
					D++;
					break;
				case 59:
				case 125: if (0 === b + n + v + m) {
					z++;
					break;
				}
				default:
					z++;
					y = e.charAt(l);
					switch (g) {
						case 9:
						case 32:
							if (0 === n + m + b) switch (x) {
								case 44:
								case 58:
								case 9:
								case 32:
									y = "";
									break;
								default: 32 !== g && (y = " ");
							}
							break;
						case 0:
							y = "\\0";
							break;
						case 12:
							y = "\\f";
							break;
						case 11:
							y = "\\v";
							break;
						case 38:
							0 === n + b + m && (r = I = 1, y = "\f" + y);
							break;
						case 108:
							if (0 === n + b + m + E && 0 < u) switch (l - u) {
								case 2: 112 === x && 58 === e.charCodeAt(l - 3) && (E = x);
								case 8: 111 === K && (E = K);
							}
							break;
						case 58:
							0 === n + b + m && (u = l);
							break;
						case 44:
							0 === b + v + n + m && (r = 1, y += "\r");
							break;
						case 34:
						case 39:
							0 === b && (n = n === g ? 0 : 0 === n ? g : n);
							break;
						case 91:
							0 === n + b + v && m++;
							break;
						case 93:
							0 === n + b + v && m--;
							break;
						case 41:
							0 === n + b + m && v--;
							break;
						case 40:
							if (0 === n + b + m) {
								if (0 === q) switch (2 * x + 3 * K) {
									case 533: break;
									default: q = 1;
								}
								v++;
							}
							break;
						case 64:
							0 === b + v + n + m + u + k && (k = 1);
							break;
						case 42:
						case 47: if (!(0 < n + m + v)) switch (b) {
							case 0:
								switch (2 * g + 3 * e.charCodeAt(l + 1)) {
									case 235:
										b = 47;
										break;
									case 220: t = l, b = 42;
								}
								break;
							case 42: 47 === g && 42 === x && t + 2 !== l && (33 === e.charCodeAt(t + 2) && (p += e.substring(t, l + 1)), y = "", b = 0);
						}
					}
					0 === b && (f += y);
			}
			K = x;
			x = g;
			l++;
		}
		t = p.length;
		if (0 < t) {
			r = c;
			if (0 < A && (C = H(2, p, r, d, D, z, t, h, a, h), void 0 !== C && 0 === (p = C).length)) return G + p + F;
			p = r.join(",") + "{" + p + "}";
			if (0 !== w * E) {
				2 !== w || L(p, 2) || (E = 0);
				switch (E) {
					case 111:
						p = p.replace(ha, ":-moz-$1") + p;
						break;
					case 112: p = p.replace(Q, "::-webkit-input-$1") + p.replace(Q, "::-moz-$1") + p.replace(Q, ":-ms-input-$1") + p;
				}
				E = 0;
			}
		}
		return G + p + F;
	}
	function X(d, c, e) {
		var h = c.trim().split(ia);
		c = h;
		var a = h.length, m = d.length;
		switch (m) {
			case 0:
			case 1:
				var b = 0;
				for (d = 0 === m ? "" : d[0] + " "; b < a; ++b) c[b] = Z(d, c[b], e).trim();
				break;
			default:
				var v = b = 0;
				for (c = []; b < a; ++b) for (var n = 0; n < m; ++n) c[v++] = Z(d[n] + " ", h[b], e).trim();
		}
		return c;
	}
	function Z(d, c, e) {
		var h = c.charCodeAt(0);
		33 > h && (h = (c = c.trim()).charCodeAt(0));
		switch (h) {
			case 38: return c.replace(F, "$1" + d.trim());
			case 58: return d.trim() + c.replace(F, "$1" + d.trim());
			default: if (0 < 1 * e && 0 < c.indexOf("\f")) return c.replace(F, (58 === d.charCodeAt(0) ? "" : "$1") + d.trim());
		}
		return d + c;
	}
	function P(d, c, e, h) {
		var a = d + ";", m = 2 * c + 3 * e + 4 * h;
		if (944 === m) {
			d = a.indexOf(":", 9) + 1;
			var b = a.substring(d, a.length - 1).trim();
			b = a.substring(0, d).trim() + b + ";";
			return 1 === w || 2 === w && L(b, 1) ? "-webkit-" + b + b : b;
		}
		if (0 === w || 2 === w && !L(a, 1)) return a;
		switch (m) {
			case 1015: return 97 === a.charCodeAt(10) ? "-webkit-" + a + a : a;
			case 951: return 116 === a.charCodeAt(3) ? "-webkit-" + a + a : a;
			case 963: return 110 === a.charCodeAt(5) ? "-webkit-" + a + a : a;
			case 1009: if (100 !== a.charCodeAt(4)) break;
			case 969:
			case 942: return "-webkit-" + a + a;
			case 978: return "-webkit-" + a + "-moz-" + a + a;
			case 1019:
			case 983: return "-webkit-" + a + "-moz-" + a + "-ms-" + a + a;
			case 883:
				if (45 === a.charCodeAt(8)) return "-webkit-" + a + a;
				if (0 < a.indexOf("image-set(", 11)) return a.replace(ja, "$1-webkit-$2") + a;
				break;
			case 932:
				if (45 === a.charCodeAt(4)) switch (a.charCodeAt(5)) {
					case 103: return "-webkit-box-" + a.replace("-grow", "") + "-webkit-" + a + "-ms-" + a.replace("grow", "positive") + a;
					case 115: return "-webkit-" + a + "-ms-" + a.replace("shrink", "negative") + a;
					case 98: return "-webkit-" + a + "-ms-" + a.replace("basis", "preferred-size") + a;
				}
				return "-webkit-" + a + "-ms-" + a + a;
			case 964: return "-webkit-" + a + "-ms-flex-" + a + a;
			case 1023:
				if (99 !== a.charCodeAt(8)) break;
				b = a.substring(a.indexOf(":", 15)).replace("flex-", "").replace("space-between", "justify");
				return "-webkit-box-pack" + b + "-webkit-" + a + "-ms-flex-pack" + b + a;
			case 1005: return ka.test(a) ? a.replace(aa, ":-webkit-") + a.replace(aa, ":-moz-") + a : a;
			case 1e3:
				b = a.substring(13).trim();
				c = b.indexOf("-") + 1;
				switch (b.charCodeAt(0) + b.charCodeAt(c)) {
					case 226:
						b = a.replace(G, "tb");
						break;
					case 232:
						b = a.replace(G, "tb-rl");
						break;
					case 220:
						b = a.replace(G, "lr");
						break;
					default: return a;
				}
				return "-webkit-" + a + "-ms-" + b + a;
			case 1017: if (-1 === a.indexOf("sticky", 9)) break;
			case 975:
				c = (a = d).length - 10;
				b = (33 === a.charCodeAt(c) ? a.substring(0, c) : a).substring(d.indexOf(":", 7) + 1).trim();
				switch (m = b.charCodeAt(0) + (b.charCodeAt(7) | 0)) {
					case 203: if (111 > b.charCodeAt(8)) break;
					case 115:
						a = a.replace(b, "-webkit-" + b) + ";" + a;
						break;
					case 207:
					case 102: a = a.replace(b, "-webkit-" + (102 < m ? "inline-" : "") + "box") + ";" + a.replace(b, "-webkit-" + b) + ";" + a.replace(b, "-ms-" + b + "box") + ";" + a;
				}
				return a + ";";
			case 938:
				if (45 === a.charCodeAt(5)) switch (a.charCodeAt(6)) {
					case 105: return b = a.replace("-items", ""), "-webkit-" + a + "-webkit-box-" + b + "-ms-flex-" + b + a;
					case 115: return "-webkit-" + a + "-ms-flex-item-" + a.replace(ba, "") + a;
					default: return "-webkit-" + a + "-ms-flex-line-pack" + a.replace("align-content", "").replace(ba, "") + a;
				}
				break;
			case 973:
			case 989: if (45 !== a.charCodeAt(3) || 122 === a.charCodeAt(4)) break;
			case 931:
			case 953:
				if (!0 === la.test(d)) return 115 === (b = d.substring(d.indexOf(":") + 1)).charCodeAt(0) ? P(d.replace("stretch", "fill-available"), c, e, h).replace(":fill-available", ":stretch") : a.replace(b, "-webkit-" + b) + a.replace(b, "-moz-" + b.replace("fill-", "")) + a;
				break;
			case 962: if (a = "-webkit-" + a + (102 === a.charCodeAt(5) ? "-ms-" + a : "") + a, 211 === e + h && 105 === a.charCodeAt(13) && 0 < a.indexOf("transform", 10)) return a.substring(0, a.indexOf(";", 27) + 1).replace(ma, "$1-webkit-$2") + a;
		}
		return a;
	}
	function L(d, c) {
		var e = d.indexOf(1 === c ? ":" : "{"), h = d.substring(0, 3 !== c ? e : 10);
		e = d.substring(e + 1, d.length - 1);
		return R(2 !== c ? h : h.replace(na, "$1"), e, c);
	}
	function ea(d, c) {
		var e = P(c, c.charCodeAt(0), c.charCodeAt(1), c.charCodeAt(2));
		return e !== c + ";" ? e.replace(oa, " or ($1)").substring(4) : "(" + c + ")";
	}
	function H(d, c, e, h, a, m, b, v, n, q) {
		for (var g = 0, x = c, w; g < A; ++g) switch (w = S[g].call(B, d, x, e, h, a, m, b, v, n, q)) {
			case void 0:
			case !1:
			case !0:
			case null: break;
			default: x = w;
		}
		if (x !== c) return x;
	}
	function T(d) {
		switch (d) {
			case void 0:
			case null:
				A = S.length = 0;
				break;
			default: if ("function" === typeof d) S[A++] = d;
			else if ("object" === typeof d) for (var c = 0, e = d.length; c < e; ++c) T(d[c]);
			else Y = !!d | 0;
		}
		return T;
	}
	function U(d) {
		d = d.prefix;
		void 0 !== d && (R = null, d ? "function" !== typeof d ? w = 1 : (w = 2, R = d) : w = 0);
		return U;
	}
	function B(d, c) {
		var e = d;
		33 > e.charCodeAt(0) && (e = e.trim());
		V = e;
		e = [V];
		if (0 < A) {
			var h = H(-1, c, e, e, D, z, 0, 0, 0, 0);
			void 0 !== h && "string" === typeof h && (c = h);
		}
		var a = M(O, e, c, 0, 0);
		0 < A && (h = H(-2, a, e, e, D, z, a.length, 0, 0, 0), void 0 !== h && (a = h));
		V = "";
		E = 0;
		z = D = 1;
		return a;
	}
	var ca = /^\0+/g, N = /[\0\r\f]/g, aa = /: */g, ka = /zoo|gra/, ma = /([,: ])(transform)/g, ia = /,\r+?/g, F = /([\t\r\n ])*\f?&/g, fa = /@(k\w+)\s*(\S*)\s*/, Q = /::(place)/g, ha = /:(read-only)/g, G = /[svh]\w+-[tblr]{2}/, da = /\(\s*(.*)\s*\)/g, oa = /([\s\S]*?);/g, ba = /-self|flex-/g, na = /[^]*?(:[rp][el]a[\w-]+)[^]*/, la = /stretch|:\s*\w+\-(?:conte|avail)/, ja = /([^-])(image-set\()/, z = 1, D = 1, E = 0, w = 1, O = [], S = [], A = 0, R = null, Y = 0, V = "";
	B.use = T;
	B.set = U;
	void 0 !== W && U(W);
	return B;
}
var unitlessKeys = {
	animationIterationCount: 1,
	borderImageOutset: 1,
	borderImageSlice: 1,
	borderImageWidth: 1,
	boxFlex: 1,
	boxFlexGroup: 1,
	boxOrdinalGroup: 1,
	columnCount: 1,
	columns: 1,
	flex: 1,
	flexGrow: 1,
	flexPositive: 1,
	flexShrink: 1,
	flexNegative: 1,
	flexOrder: 1,
	gridRow: 1,
	gridRowEnd: 1,
	gridRowSpan: 1,
	gridRowStart: 1,
	gridColumn: 1,
	gridColumnEnd: 1,
	gridColumnSpan: 1,
	gridColumnStart: 1,
	msGridRow: 1,
	msGridRowSpan: 1,
	msGridColumn: 1,
	msGridColumnSpan: 1,
	fontWeight: 1,
	lineHeight: 1,
	opacity: 1,
	order: 1,
	orphans: 1,
	tabSize: 1,
	widows: 1,
	zIndex: 1,
	zoom: 1,
	WebkitLineClamp: 1,
	fillOpacity: 1,
	floodOpacity: 1,
	stopOpacity: 1,
	strokeDasharray: 1,
	strokeDashoffset: 1,
	strokeMiterlimit: 1,
	strokeOpacity: 1,
	strokeWidth: 1
};
var merge$1 = function merge(a, b) {
	var result = assign({}, a, b);
	for (var key in a) {
		var _assign;
		if (!a[key] || typeof b[key] !== "object") continue;
		assign(result, (_assign = {}, _assign[key] = assign(a[key], b[key]), _assign));
	}
	return result;
};
var sort = function sort(obj) {
	var next = {};
	Object.keys(obj).sort(function(a, b) {
		return a.localeCompare(b, void 0, {
			numeric: true,
			sensitivity: "base"
		});
	}).forEach(function(key) {
		next[key] = obj[key];
	});
	return next;
};
var defaults$3 = { breakpoints: [
	40,
	52,
	64
].map(function(n) {
	return n + "em";
}) };
var createMediaQuery = function createMediaQuery(n) {
	return "@media screen and (min-width: " + n + ")";
};
var getValue = function getValue(n, scale) {
	return get$3(scale, n, n);
};
var get$3 = function get(obj, key, def, p, undef) {
	key = key && key.split ? key.split(".") : [key];
	for (p = 0; p < key.length; p++) obj = obj ? obj[key[p]] : undef;
	return obj === undef ? def : obj;
};
var createParser = function createParser(config) {
	var cache = {};
	var parse = function parse(props) {
		var styles = {};
		var shouldSort = false;
		var isCacheDisabled = props.theme && props.theme.disableStyledSystemCache;
		for (var key in props) {
			if (!config[key]) continue;
			var sx = config[key];
			var raw = props[key];
			var scale = get$3(props.theme, sx.scale, sx.defaults);
			if (typeof raw === "object") {
				cache.breakpoints = !isCacheDisabled && cache.breakpoints || get$3(props.theme, "breakpoints", defaults$3.breakpoints);
				if (Array.isArray(raw)) {
					cache.media = !isCacheDisabled && cache.media || [null].concat(cache.breakpoints.map(createMediaQuery));
					styles = merge$1(styles, parseResponsiveStyle(cache.media, sx, scale, raw, props));
					continue;
				}
				if (raw !== null) {
					styles = merge$1(styles, parseResponsiveObject(cache.breakpoints, sx, scale, raw, props));
					shouldSort = true;
				}
				continue;
			}
			assign(styles, sx(raw, scale, props));
		}
		if (shouldSort) styles = sort(styles);
		return styles;
	};
	parse.config = config;
	parse.propNames = Object.keys(config);
	parse.cache = cache;
	var keys = Object.keys(config).filter(function(k) {
		return k !== "config";
	});
	if (keys.length > 1) keys.forEach(function(key) {
		var _createParser;
		parse[key] = createParser((_createParser = {}, _createParser[key] = config[key], _createParser));
	});
	return parse;
};
var parseResponsiveStyle = function parseResponsiveStyle(mediaQueries, sx, scale, raw, _props) {
	var styles = {};
	raw.slice(0, mediaQueries.length).forEach(function(value, i) {
		var media = mediaQueries[i];
		var style = sx(value, scale, _props);
		if (!media) assign(styles, style);
		else {
			var _assign2;
			assign(styles, (_assign2 = {}, _assign2[media] = assign({}, styles[media], style), _assign2));
		}
	});
	return styles;
};
var parseResponsiveObject = function parseResponsiveObject(breakpoints, sx, scale, raw, _props) {
	var styles = {};
	for (var key in raw) {
		var breakpoint = breakpoints[key];
		var value = raw[key];
		var style = sx(value, scale, _props);
		if (!breakpoint) assign(styles, style);
		else {
			var _assign3;
			var media = createMediaQuery(breakpoint);
			assign(styles, (_assign3 = {}, _assign3[media] = assign({}, styles[media], style), _assign3));
		}
	}
	return styles;
};
var createStyleFunction = function createStyleFunction(_ref) {
	var properties = _ref.properties, property = _ref.property, scale = _ref.scale, _ref$transform = _ref.transform, transform = _ref$transform === void 0 ? getValue : _ref$transform, defaultScale = _ref.defaultScale;
	properties = properties || [property];
	var sx = function sx(value, scale, _props) {
		var result = {};
		var n = transform(value, scale, _props);
		if (n === null) return;
		properties.forEach(function(prop) {
			result[prop] = n;
		});
		return result;
	};
	sx.scale = scale;
	sx.defaults = defaultScale;
	return sx;
};
var system = function system(args) {
	if (args === void 0) args = {};
	var config = {};
	Object.keys(args).forEach(function(key) {
		var conf = args[key];
		if (conf === true) {
			config[key] = createStyleFunction({
				property: key,
				scale: key
			});
			return;
		}
		if (typeof conf === "function") {
			config[key] = conf;
			return;
		}
		config[key] = createStyleFunction(conf);
	});
	return createParser(config);
};
var compose = function compose() {
	var config = {};
	for (var _len = arguments.length, parsers = new Array(_len), _key = 0; _key < _len; _key++) parsers[_key] = arguments[_key];
	parsers.forEach(function(parser) {
		if (!parser || !parser.config) return;
		assign(config, parser.config);
	});
	return createParser(config);
};
var isNumber$1 = function isNumber(n) {
	return typeof n === "number" && !isNaN(n);
};
var layout = system({
	width: {
		property: "width",
		scale: "sizes",
		transform: function getWidth(n, scale) {
			return get$3(scale, n, !isNumber$1(n) || n > 1 ? n : n * 100 + "%");
		}
	},
	height: {
		property: "height",
		scale: "sizes"
	},
	minWidth: {
		property: "minWidth",
		scale: "sizes"
	},
	minHeight: {
		property: "minHeight",
		scale: "sizes"
	},
	maxWidth: {
		property: "maxWidth",
		scale: "sizes"
	},
	maxHeight: {
		property: "maxHeight",
		scale: "sizes"
	},
	size: {
		properties: ["width", "height"],
		scale: "sizes"
	},
	overflow: true,
	overflowX: true,
	overflowY: true,
	display: true,
	verticalAlign: true
});
var config$6 = {
	color: {
		property: "color",
		scale: "colors"
	},
	backgroundColor: {
		property: "backgroundColor",
		scale: "colors"
	},
	opacity: true
};
config$6.bg = config$6.backgroundColor;
var color = system(config$6);
var typography = system({
	fontFamily: {
		property: "fontFamily",
		scale: "fonts"
	},
	fontSize: {
		property: "fontSize",
		scale: "fontSizes",
		defaultScale: { fontSizes: [
			12,
			14,
			16,
			20,
			24,
			32,
			48,
			64,
			72
		] }.fontSizes
	},
	fontWeight: {
		property: "fontWeight",
		scale: "fontWeights"
	},
	lineHeight: {
		property: "lineHeight",
		scale: "lineHeights"
	},
	letterSpacing: {
		property: "letterSpacing",
		scale: "letterSpacings"
	},
	textAlign: true,
	fontStyle: true
});
var flexbox = system({
	alignItems: true,
	alignContent: true,
	justifyItems: true,
	justifyContent: true,
	flexWrap: true,
	flexDirection: true,
	flex: true,
	flexGrow: true,
	flexShrink: true,
	flexBasis: true,
	justifySelf: true,
	alignSelf: true,
	order: true
});
var defaults$2 = { space: [
	0,
	4,
	8,
	16,
	32,
	64,
	128,
	256,
	512
] };
var grid = system({
	gridGap: {
		property: "gridGap",
		scale: "space",
		defaultScale: defaults$2.space
	},
	gridColumnGap: {
		property: "gridColumnGap",
		scale: "space",
		defaultScale: defaults$2.space
	},
	gridRowGap: {
		property: "gridRowGap",
		scale: "space",
		defaultScale: defaults$2.space
	},
	gridColumn: true,
	gridRow: true,
	gridAutoFlow: true,
	gridAutoColumns: true,
	gridAutoRows: true,
	gridTemplateColumns: true,
	gridTemplateRows: true,
	gridTemplateAreas: true,
	gridArea: true
});
var config$2 = {
	border: {
		property: "border",
		scale: "borders"
	},
	borderWidth: {
		property: "borderWidth",
		scale: "borderWidths"
	},
	borderStyle: {
		property: "borderStyle",
		scale: "borderStyles"
	},
	borderColor: {
		property: "borderColor",
		scale: "colors"
	},
	borderRadius: {
		property: "borderRadius",
		scale: "radii"
	},
	borderTop: {
		property: "borderTop",
		scale: "borders"
	},
	borderTopLeftRadius: {
		property: "borderTopLeftRadius",
		scale: "radii"
	},
	borderTopRightRadius: {
		property: "borderTopRightRadius",
		scale: "radii"
	},
	borderRight: {
		property: "borderRight",
		scale: "borders"
	},
	borderBottom: {
		property: "borderBottom",
		scale: "borders"
	},
	borderBottomLeftRadius: {
		property: "borderBottomLeftRadius",
		scale: "radii"
	},
	borderBottomRightRadius: {
		property: "borderBottomRightRadius",
		scale: "radii"
	},
	borderLeft: {
		property: "borderLeft",
		scale: "borders"
	},
	borderX: {
		properties: ["borderLeft", "borderRight"],
		scale: "borders"
	},
	borderY: {
		properties: ["borderTop", "borderBottom"],
		scale: "borders"
	}
};
config$2.borderTopWidth = {
	property: "borderTopWidth",
	scale: "borderWidths"
};
config$2.borderTopColor = {
	property: "borderTopColor",
	scale: "colors"
};
config$2.borderTopStyle = {
	property: "borderTopStyle",
	scale: "borderStyles"
};
config$2.borderTopLeftRadius = {
	property: "borderTopLeftRadius",
	scale: "radii"
};
config$2.borderTopRightRadius = {
	property: "borderTopRightRadius",
	scale: "radii"
};
config$2.borderBottomWidth = {
	property: "borderBottomWidth",
	scale: "borderWidths"
};
config$2.borderBottomColor = {
	property: "borderBottomColor",
	scale: "colors"
};
config$2.borderBottomStyle = {
	property: "borderBottomStyle",
	scale: "borderStyles"
};
config$2.borderBottomLeftRadius = {
	property: "borderBottomLeftRadius",
	scale: "radii"
};
config$2.borderBottomRightRadius = {
	property: "borderBottomRightRadius",
	scale: "radii"
};
config$2.borderLeftWidth = {
	property: "borderLeftWidth",
	scale: "borderWidths"
};
config$2.borderLeftColor = {
	property: "borderLeftColor",
	scale: "colors"
};
config$2.borderLeftStyle = {
	property: "borderLeftStyle",
	scale: "borderStyles"
};
config$2.borderRightWidth = {
	property: "borderRightWidth",
	scale: "borderWidths"
};
config$2.borderRightColor = {
	property: "borderRightColor",
	scale: "colors"
};
config$2.borderRightStyle = {
	property: "borderRightStyle",
	scale: "borderStyles"
};
var border = system(config$2);
var config$1 = {
	background: true,
	backgroundImage: true,
	backgroundSize: true,
	backgroundPosition: true,
	backgroundRepeat: true
};
config$1.bgImage = config$1.backgroundImage;
config$1.bgSize = config$1.backgroundSize;
config$1.bgPosition = config$1.backgroundPosition;
config$1.bgRepeat = config$1.backgroundRepeat;
var background = system(config$1);
var defaults$1 = { space: [
	0,
	4,
	8,
	16,
	32,
	64,
	128,
	256,
	512
] };
var position = system({
	position: true,
	zIndex: {
		property: "zIndex",
		scale: "zIndices"
	},
	top: {
		property: "top",
		scale: "space",
		defaultScale: defaults$1.space
	},
	right: {
		property: "right",
		scale: "space",
		defaultScale: defaults$1.space
	},
	bottom: {
		property: "bottom",
		scale: "space",
		defaultScale: defaults$1.space
	},
	left: {
		property: "left",
		scale: "space",
		defaultScale: defaults$1.space
	}
});
var defaults = { space: [
	0,
	4,
	8,
	16,
	32,
	64,
	128,
	256,
	512
] };
var isNumber = function isNumber(n) {
	return typeof n === "number" && !isNaN(n);
};
var getMargin = function getMargin(n, scale) {
	if (!isNumber(n)) return get$3(scale, n, n);
	var isNegative = n < 0;
	var absolute = Math.abs(n);
	var value = get$3(scale, absolute, absolute);
	if (!isNumber(value)) return isNegative ? "-" + value : value;
	return value * (isNegative ? -1 : 1);
};
var configs = {};
configs.margin = {
	margin: {
		property: "margin",
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	},
	marginTop: {
		property: "marginTop",
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	},
	marginRight: {
		property: "marginRight",
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	},
	marginBottom: {
		property: "marginBottom",
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	},
	marginLeft: {
		property: "marginLeft",
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	},
	marginX: {
		properties: ["marginLeft", "marginRight"],
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	},
	marginY: {
		properties: ["marginTop", "marginBottom"],
		scale: "space",
		transform: getMargin,
		defaultScale: defaults.space
	}
};
configs.margin.m = configs.margin.margin;
configs.margin.mt = configs.margin.marginTop;
configs.margin.mr = configs.margin.marginRight;
configs.margin.mb = configs.margin.marginBottom;
configs.margin.ml = configs.margin.marginLeft;
configs.margin.mx = configs.margin.marginX;
configs.margin.my = configs.margin.marginY;
configs.padding = {
	padding: {
		property: "padding",
		scale: "space",
		defaultScale: defaults.space
	},
	paddingTop: {
		property: "paddingTop",
		scale: "space",
		defaultScale: defaults.space
	},
	paddingRight: {
		property: "paddingRight",
		scale: "space",
		defaultScale: defaults.space
	},
	paddingBottom: {
		property: "paddingBottom",
		scale: "space",
		defaultScale: defaults.space
	},
	paddingLeft: {
		property: "paddingLeft",
		scale: "space",
		defaultScale: defaults.space
	},
	paddingX: {
		properties: ["paddingLeft", "paddingRight"],
		scale: "space",
		defaultScale: defaults.space
	},
	paddingY: {
		properties: ["paddingTop", "paddingBottom"],
		scale: "space",
		defaultScale: defaults.space
	}
};
configs.padding.p = configs.padding.padding;
configs.padding.pt = configs.padding.paddingTop;
configs.padding.pr = configs.padding.paddingRight;
configs.padding.pb = configs.padding.paddingBottom;
configs.padding.pl = configs.padding.paddingLeft;
configs.padding.px = configs.padding.paddingX;
configs.padding.py = configs.padding.paddingY;
var margin = system(configs.margin);
var padding = system(configs.padding);
var space = compose(margin, padding);
var shadow = system({
	boxShadow: {
		property: "boxShadow",
		scale: "shadows"
	},
	textShadow: {
		property: "textShadow",
		scale: "shadows"
	}
});
function _extends$1() {
	_extends$1 = Object.assign || function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$1.apply(this, arguments);
}
var get$2 = function get(obj, key, def, p, undef) {
	key = key && key.split ? key.split(".") : [key];
	for (p = 0; p < key.length; p++) obj = obj ? obj[key[p]] : undef;
	return obj === undef ? def : obj;
};
var defaultBreakpoints$1 = [
	40,
	52,
	64
].map(function(n) {
	return n + "em";
});
var defaultTheme$1 = {
	space: [
		0,
		4,
		8,
		16,
		32,
		64,
		128,
		256,
		512
	],
	fontSizes: [
		12,
		14,
		16,
		20,
		24,
		32,
		48,
		64,
		72
	]
};
var aliases$1 = {
	bg: "backgroundColor",
	m: "margin",
	mt: "marginTop",
	mr: "marginRight",
	mb: "marginBottom",
	ml: "marginLeft",
	mx: "marginX",
	my: "marginY",
	p: "padding",
	pt: "paddingTop",
	pr: "paddingRight",
	pb: "paddingBottom",
	pl: "paddingLeft",
	px: "paddingX",
	py: "paddingY"
};
var multiples$1 = {
	marginX: ["marginLeft", "marginRight"],
	marginY: ["marginTop", "marginBottom"],
	paddingX: ["paddingLeft", "paddingRight"],
	paddingY: ["paddingTop", "paddingBottom"],
	size: ["width", "height"]
};
var scales$1 = {
	color: "colors",
	backgroundColor: "colors",
	borderColor: "colors",
	margin: "space",
	marginTop: "space",
	marginRight: "space",
	marginBottom: "space",
	marginLeft: "space",
	marginX: "space",
	marginY: "space",
	padding: "space",
	paddingTop: "space",
	paddingRight: "space",
	paddingBottom: "space",
	paddingLeft: "space",
	paddingX: "space",
	paddingY: "space",
	top: "space",
	right: "space",
	bottom: "space",
	left: "space",
	gridGap: "space",
	gridColumnGap: "space",
	gridRowGap: "space",
	gap: "space",
	columnGap: "space",
	rowGap: "space",
	fontFamily: "fonts",
	fontSize: "fontSizes",
	fontWeight: "fontWeights",
	lineHeight: "lineHeights",
	letterSpacing: "letterSpacings",
	border: "borders",
	borderTop: "borders",
	borderRight: "borders",
	borderBottom: "borders",
	borderLeft: "borders",
	borderWidth: "borderWidths",
	borderStyle: "borderStyles",
	borderRadius: "radii",
	borderTopRightRadius: "radii",
	borderTopLeftRadius: "radii",
	borderBottomRightRadius: "radii",
	borderBottomLeftRadius: "radii",
	borderTopWidth: "borderWidths",
	borderTopColor: "colors",
	borderTopStyle: "borderStyles",
	borderBottomWidth: "borderWidths",
	borderBottomColor: "colors",
	borderBottomStyle: "borderStyles",
	borderLeftWidth: "borderWidths",
	borderLeftColor: "colors",
	borderLeftStyle: "borderStyles",
	borderRightWidth: "borderWidths",
	borderRightColor: "colors",
	borderRightStyle: "borderStyles",
	outlineColor: "colors",
	boxShadow: "shadows",
	textShadow: "shadows",
	zIndex: "zIndices",
	width: "sizes",
	minWidth: "sizes",
	maxWidth: "sizes",
	height: "sizes",
	minHeight: "sizes",
	maxHeight: "sizes",
	flexBasis: "sizes",
	size: "sizes",
	fill: "colors",
	stroke: "colors"
};
var positiveOrNegative$1 = function positiveOrNegative(scale, value) {
	if (typeof value !== "number" || value >= 0) return get$2(scale, value, value);
	var absolute = Math.abs(value);
	var n = get$2(scale, absolute, absolute);
	if (typeof n === "string") return "-" + n;
	return n * -1;
};
var transforms$1 = [
	"margin",
	"marginTop",
	"marginRight",
	"marginBottom",
	"marginLeft",
	"marginX",
	"marginY",
	"top",
	"bottom",
	"left",
	"right"
].reduce(function(acc, curr) {
	var _extends2;
	return _extends$1({}, acc, (_extends2 = {}, _extends2[curr] = positiveOrNegative$1, _extends2));
}, {});
var responsive$1 = function responsive(styles) {
	return function(theme) {
		var next = {};
		var breakpoints = get$2(theme, "breakpoints", defaultBreakpoints$1);
		var mediaQueries = [null].concat(breakpoints.map(function(n) {
			return "@media screen and (min-width: " + n + ")";
		}));
		for (var key in styles) {
			var value = typeof styles[key] === "function" ? styles[key](theme) : styles[key];
			if (value == null) continue;
			if (!Array.isArray(value)) {
				next[key] = value;
				continue;
			}
			for (var i = 0; i < value.slice(0, mediaQueries.length).length; i++) {
				var media = mediaQueries[i];
				if (!media) {
					next[key] = value[i];
					continue;
				}
				next[media] = next[media] || {};
				if (value[i] == null) continue;
				next[media][key] = value[i];
			}
		}
		return next;
	};
};
var css$1 = function css(args) {
	return function(props) {
		if (props === void 0) props = {};
		var theme = _extends$1({}, defaultTheme$1, {}, props.theme || props);
		var result = {};
		var styles = responsive$1(typeof args === "function" ? args(theme) : args)(theme);
		for (var key in styles) {
			var x = styles[key];
			var val = typeof x === "function" ? x(theme) : x;
			if (key === "variant") {
				var variant = css(get$2(theme, val))(theme);
				result = _extends$1({}, result, {}, variant);
				continue;
			}
			if (val && typeof val === "object") {
				result[key] = css(val)(theme);
				continue;
			}
			var prop = get$2(aliases$1, key, key);
			var scale = get$2(theme, get$2(scales$1, prop), get$2(theme, prop, {}));
			var value = get$2(transforms$1, prop, get$2)(scale, val, val);
			if (multiples$1[prop]) {
				var dirs = multiples$1[prop];
				for (var i = 0; i < dirs.length; i++) result[dirs[i]] = value;
			} else result[prop] = value;
		}
		return result;
	};
};
var variant = function variant(_ref) {
	var _config;
	var scale = _ref.scale, _ref$prop = _ref.prop, prop = _ref$prop === void 0 ? "variant" : _ref$prop, _ref$variants = _ref.variants, variants = _ref$variants === void 0 ? {} : _ref$variants, key = _ref.key;
	var sx;
	if (Object.keys(variants).length) sx = function sx(value, scale, props) {
		return css$1(get$3(scale, value, null))(props.theme);
	};
	else sx = function sx(value, scale) {
		return get$3(scale, value, null);
	};
	sx.scale = scale || key;
	sx.defaults = variants;
	return createParser((_config = {}, _config[prop] = sx, _config));
};
var buttonStyle = variant({ key: "buttons" });
var textStyle = variant({
	key: "textStyles",
	prop: "textStyle"
});
var colorStyle = variant({
	key: "colorStyles",
	prop: "colors"
});
var index_esm_exports = /* @__PURE__ */ __exportAll({
	alignContent: () => alignContent,
	alignItems: () => alignItems,
	alignSelf: () => alignSelf,
	background: () => background,
	backgroundImage: () => backgroundImage,
	backgroundPosition: () => backgroundPosition,
	backgroundRepeat: () => backgroundRepeat,
	backgroundSize: () => backgroundSize,
	border: () => border,
	borderBottom: () => borderBottom,
	borderColor: () => borderColor,
	borderLeft: () => borderLeft,
	borderRadius: () => borderRadius,
	borderRight: () => borderRight,
	borderStyle: () => borderStyle,
	borderTop: () => borderTop,
	borderWidth: () => borderWidth,
	borders: () => border,
	bottom: () => bottom,
	boxShadow: () => shadow,
	buttonStyle: () => buttonStyle,
	color: () => color,
	colorStyle: () => colorStyle,
	compose: () => compose,
	createParser: () => createParser,
	createStyleFunction: () => createStyleFunction,
	display: () => display,
	flex: () => flex,
	flexBasis: () => flexBasis,
	flexDirection: () => flexDirection,
	flexGrow: () => flexGrow,
	flexShrink: () => flexShrink,
	flexWrap: () => flexWrap,
	flexbox: () => flexbox,
	fontFamily: () => fontFamily,
	fontSize: () => fontSize,
	fontStyle: () => fontStyle,
	fontWeight: () => fontWeight,
	get: () => get$3,
	grid: () => grid,
	gridArea: () => gridArea,
	gridAutoColumns: () => gridAutoColumns,
	gridAutoFlow: () => gridAutoFlow,
	gridAutoRows: () => gridAutoRows,
	gridColumn: () => gridColumn,
	gridColumnGap: () => gridColumnGap,
	gridGap: () => gridGap,
	gridRow: () => gridRow,
	gridRowGap: () => gridRowGap,
	gridTemplateAreas: () => gridTemplateAreas,
	gridTemplateColumns: () => gridTemplateColumns,
	gridTemplateRows: () => gridTemplateRows,
	height: () => height,
	justifyContent: () => justifyContent,
	justifyItems: () => justifyItems,
	justifySelf: () => justifySelf,
	layout: () => layout,
	left: () => left,
	letterSpacing: () => letterSpacing,
	lineHeight: () => lineHeight,
	margin: () => margin,
	maxHeight: () => maxHeight,
	maxWidth: () => maxWidth,
	minHeight: () => minHeight,
	minWidth: () => minWidth,
	opacity: () => opacity,
	order: () => order,
	overflow: () => overflow,
	overflowX: () => overflowX,
	overflowY: () => overflowY,
	padding: () => padding,
	position: () => position,
	right: () => right,
	shadow: () => shadow,
	size: () => size,
	space: () => space,
	style: () => style,
	system: () => system,
	textAlign: () => textAlign,
	textShadow: () => shadow,
	textStyle: () => textStyle,
	top: () => top,
	typography: () => typography,
	variant: () => variant,
	verticalAlign: () => verticalAlign,
	width: () => width,
	zIndex: () => zIndex
});
var width = layout.width, height = layout.height, minWidth = layout.minWidth, minHeight = layout.minHeight, maxWidth = layout.maxWidth, maxHeight = layout.maxHeight, size = layout.size, verticalAlign = layout.verticalAlign, display = layout.display, overflow = layout.overflow, overflowX = layout.overflowX, overflowY = layout.overflowY;
var opacity = color.opacity;
var fontSize = typography.fontSize, fontFamily = typography.fontFamily, fontWeight = typography.fontWeight, lineHeight = typography.lineHeight, textAlign = typography.textAlign, fontStyle = typography.fontStyle, letterSpacing = typography.letterSpacing;
var alignItems = flexbox.alignItems, alignContent = flexbox.alignContent, justifyItems = flexbox.justifyItems, justifyContent = flexbox.justifyContent, flexWrap = flexbox.flexWrap, flexDirection = flexbox.flexDirection, flex = flexbox.flex, flexGrow = flexbox.flexGrow, flexShrink = flexbox.flexShrink, flexBasis = flexbox.flexBasis, justifySelf = flexbox.justifySelf, alignSelf = flexbox.alignSelf, order = flexbox.order;
var gridGap = grid.gridGap, gridColumnGap = grid.gridColumnGap, gridRowGap = grid.gridRowGap, gridColumn = grid.gridColumn, gridRow = grid.gridRow, gridAutoFlow = grid.gridAutoFlow, gridAutoColumns = grid.gridAutoColumns, gridAutoRows = grid.gridAutoRows, gridTemplateColumns = grid.gridTemplateColumns, gridTemplateRows = grid.gridTemplateRows, gridTemplateAreas = grid.gridTemplateAreas, gridArea = grid.gridArea;
var borderWidth = border.borderWidth, borderStyle = border.borderStyle, borderColor = border.borderColor, borderTop = border.borderTop, borderRight = border.borderRight, borderBottom = border.borderBottom, borderLeft = border.borderLeft, borderRadius = border.borderRadius;
var backgroundImage = background.backgroundImage, backgroundSize = background.backgroundSize, backgroundPosition = background.backgroundPosition, backgroundRepeat = background.backgroundRepeat;
var zIndex = position.zIndex, top = position.top, right = position.right, bottom = position.bottom, left = position.left;
var style = function style(_ref) {
	var prop = _ref.prop, cssProperty = _ref.cssProperty, alias = _ref.alias, key = _ref.key, transformValue = _ref.transformValue, scale = _ref.scale, properties = _ref.properties;
	var config = {};
	config[prop] = createStyleFunction({
		properties,
		property: cssProperty || prop,
		scale: key,
		defaultScale: scale,
		transform: transformValue
	});
	if (alias) config[alias] = config[prop];
	return createParser(config);
};
var themeGet = function themeGet(path, fallback) {
	if (fallback === void 0) fallback = null;
	return function(props) {
		return get$3(props.theme, path, fallback);
	};
};
function fontStack(fonts) {
	return fonts.map((font) => font.includes(" ") ? `"${font}"` : font).join(", ");
}
var theme = {
	animation: { easeOutCubic: "cubic-bezier(0.33, 1, 0.68, 1)" },
	borderWidths: [0, "1px"],
	breakpoints: [
		"544px",
		"768px",
		"1012px",
		"1280px"
	],
	fonts: {
		normal: fontStack([
			"-apple-system",
			"BlinkMacSystemFont",
			"Segoe UI",
			"Noto Sans",
			"Helvetica",
			"Arial",
			"sans-serif",
			"Apple Color Emoji",
			"Segoe UI Emoji"
		]),
		mono: `var(--fontStack-monospace, ${fontStack([
			"SFMono-Regular",
			"Consolas",
			"Liberation Mono",
			"Menlo",
			"Courier",
			"monospace"
		])})`
	},
	fontSizes: [
		"12px",
		"14px",
		"16px",
		"20px",
		"24px",
		"32px",
		"40px",
		"48px",
		"56px"
	],
	fontWeights: {
		light: 300,
		normal: 400,
		semibold: 500,
		bold: 600
	},
	lineHeights: {
		condensedUltra: 1,
		condensed: 1.25,
		default: 1.5
	},
	radii: [
		"0",
		"3px",
		"6px",
		"100px"
	],
	sizes: {
		small: "544px",
		medium: "768px",
		large: "1012px",
		xlarge: "1280px"
	},
	space: [
		"0",
		"4px",
		"8px",
		"16px",
		"24px",
		"32px",
		"40px",
		"48px",
		"64px",
		"80px",
		"96px",
		"112px",
		"128px"
	],
	colorSchemes: {
		"light": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(255,255,255,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #f6f8fa))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #218bff)",
					"secondary": "var(--color-marketing-icon-secondary, #54aeff)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #1F2328))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #1F2328))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, #ccffd8))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, #e6ffec))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, #abf2bc))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #1F2328))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #1F2328))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, #ffd7d5))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, #ffebe9))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(255,129,130,0.4)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(84,174,255,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #656d76))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, multiply)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(31,35,40,0.15))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(31,35,40,0.15))",
					"additionBg": "var(undefined, var(--color-diffstat-addition-bg, #1f883d))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, #fff8c5))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #57606a)",
					"constant": "var(--color-prettylights-syntax-constant, #0550ae)",
					"entity": "var(--color-prettylights-syntax-entity, #6639ba)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #24292f)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #116329)",
					"keyword": "var(--color-prettylights-syntax-keyword, #cf222e)",
					"string": "var(--color-prettylights-syntax-string, #0a3069)",
					"variable": "var(--color-prettylights-syntax-variable, #953800)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #82071e)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #f6f8fa)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #82071e)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #f6f8fa)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #cf222e)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #116329)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #3b2300)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #0550ae)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #24292f)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #24292f)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #82071e)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #ffebe9)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #116329)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #dafbe1)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #953800)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #ffd8b5)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #eaeef2)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #0550ae)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #8250df)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #57606a)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #8c959f)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #0a3069)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #1F2328))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #ffffff))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #ffffff))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #ffffff))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #6e7781))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #656d76))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #1F2328))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(84,174,255,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(234,238,242,0.5)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #1F2328))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #ffffff))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #24292f))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #0550ae))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #8250df))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #cf222e))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #cf222e))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #0a3069))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #0550ae))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #953800))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #24292f)",
					"runBorderWidth": "var(--color-checks-run-border-width, 0px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 0px)",
					"textPrimary": "var(--color-checks-text-primary, #f6f8fa)",
					"textSecondary": "var(--color-checks-text-secondary, #8c959f)",
					"textLink": "var(--color-checks-text-link, #54aeff)",
					"btnIcon": "var(--color-checks-btn-icon, #afb8c1)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #f6f8fa)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(255,255,255,0.125))",
					"inputText": "var(--color-checks-input-text, #eaeef2)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #8c959f)",
					"inputFocusText": "var(--color-checks-input-focus-text, #8c959f)",
					"inputBg": "var(--color-checks-input-bg, #32383f)",
					"inputShadow": "var(--color-checks-input-shadow, none)",
					"donutError": "var(--color-checks-donut-error, #fa4549)",
					"donutPending": "var(--color-checks-donut-pending, #bf8700)",
					"donutSuccess": "var(--color-checks-donut-success, #1f883d)",
					"donutNeutral": "var(--color-checks-donut-neutral, #afb8c1)",
					"dropdownText": "var(--color-checks-dropdown-text, #afb8c1)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #32383f)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #424a53)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(31,35,40,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #f6f8fa)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, #424a53)",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #f6f8fa)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, #32383f)",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, #57606a)",
					"headerLabelText": "var(--color-checks-header-label-text, #d0d7de)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #f6f8fa)",
					"headerBorder": "var(--color-checks-header-border, #32383f)",
					"headerIcon": "var(--color-checks-header-icon, #8c959f)",
					"lineText": "var(--color-checks-line-text, #d0d7de)",
					"lineNumText": "var(--color-checks-line-num-text, rgba(140,149,159,0.75))",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #8c959f)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, #32383f)",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(33,139,255,0.15))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #54aeff)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #24292f)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #9a6700)",
					"gateBg": "var(--color-checks-gate-bg, rgba(125,78,0,0.15))",
					"gateText": "var(--color-checks-gate-text, #d0d7de)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #d4a72c)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #32383f)",
					"stepErrorText": "var(--color-checks-step-error-text, #ff8182)",
					"stepWarningText": "var(--color-checks-step-warning-text, #d4a72c)",
					"loglineText": "var(--color-checks-logline-text, #8c959f)",
					"loglineNumText": "var(--color-checks-logline-num-text, rgba(140,149,159,0.75))",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #c297ff)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #d0d7de)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #ff8182)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(164,14,38,0.15))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #d0d7de)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #d4a72c)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(125,78,0,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #54aeff)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #4ac26b)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #24292f)",
						"blackBright": "var(--color-checks-ansi-black-bright, #32383f)",
						"white": "var(--color-checks-ansi-white, #d0d7de)",
						"whiteBright": "var(--color-checks-ansi-white-bright, #d0d7de)",
						"gray": "var(--color-checks-ansi-gray, #8c959f)",
						"red": "var(--color-checks-ansi-red, #ff8182)",
						"redBright": "var(--color-checks-ansi-red-bright, #ffaba8)",
						"green": "var(--color-checks-ansi-green, #4ac26b)",
						"greenBright": "var(--color-checks-ansi-green-bright, #6fdd8b)",
						"yellow": "var(--color-checks-ansi-yellow, #d4a72c)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #eac54f)",
						"blue": "var(--color-checks-ansi-blue, #54aeff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #80ccff)",
						"magenta": "var(--color-checks-ansi-magenta, #c297ff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #d8b9ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #24292f)",
					"sidebarBg": "var(--color-project-sidebar-bg, #ffffff)",
					"gradientIn": "var(--color-project-gradient-in, #ffffff)",
					"gradientOut": "var(--color-project-gradient-out, rgba(255,255,255,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #1b1f23))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #858F99))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, #ffffff))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(31,35,40,0.15)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #afb8c1))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #d0d7de))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, transparent))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(175,184,193,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #b6e3ff))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(140,149,159,0.2)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #24292f))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #57606a))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #ffffff))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #24292f))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #57606a))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #ffffff))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, transparent))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(175,184,193,0.2)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #eaeef2))" },
				"ansi": {
					"black": "var(--color-ansi-black, #24292f)",
					"blackBright": "var(--color-ansi-black-bright, #57606a)",
					"white": "var(--color-ansi-white, #6e7781)",
					"whiteBright": "var(--color-ansi-white-bright, #8c959f)",
					"gray": "var(--color-ansi-gray, #6e7781)",
					"red": "var(--color-ansi-red, #cf222e)",
					"redBright": "var(--color-ansi-red-bright, #a40e26)",
					"green": "var(--color-ansi-green, #116329)",
					"greenBright": "var(--color-ansi-green-bright, #1a7f37)",
					"yellow": "var(--color-ansi-yellow, #4d2d00)",
					"yellowBright": "var(--color-ansi-yellow-bright, #633c01)",
					"blue": "var(--color-ansi-blue, #0969da)",
					"blueBright": "var(--color-ansi-blue-bright, #218bff)",
					"magenta": "var(--color-ansi-magenta, #8250df)",
					"magentaBright": "var(--color-ansi-magenta-bright, #a475f9)",
					"cyan": "var(--color-ansi-cyan, #1b7c83)",
					"cyanBright": "var(--color-ansi-cyan-bright, #3192aa)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #24292f))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #f6f8fa))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(31,35,40,0.15)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #f3f4f6))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, rgba(31,35,40,0.15)))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(220,14%,93%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, rgba(31,35,40,0.15)))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, hsla(220,14%,94%,1)))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, rgba(31,35,40,0.08)))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #1f883d))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(31,35,40,0.15)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #1a7f37))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(31,35,40,0.15)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, hsla(137,66%,28%,1)))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.8)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, #94d3a2))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(31,35,40,0.15)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, rgba(255,255,255,0.8)))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(0,45,17,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #0969da))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #ffffff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #0969da))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(31,35,40,0.15)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, hsla(212,92%,42%,1)))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(31,35,40,0.15)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(9,105,218,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #f6f8fa))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(9,105,218,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, #0969da1a))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #0550ae))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(9,105,218,0.5)))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #cf222e))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #a40e26))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, rgba(31,35,40,0.15)))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, hsla(356,72%,44%,1)))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, rgba(31,35,40,0.15)))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(207,34,46,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #f6f8fa))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(207,34,46,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(207,34,46,0.1)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #cf222e))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #a40e26))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(207,34,46,0.5)))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #eaeef2))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #57606a))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #6e7781))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(175,184,193,0.2)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(208,215,222,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(208,215,222,0.32)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(208,215,222,0.48)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(208,215,222,0.24)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-default-danger-hover-bg, rgba(255,235,233,0.64)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-default-danger-active-bg, #ffebe9))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-default-danger-hover-text, #d1242f))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, #eaeef2))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(210,24%,90%,1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, hsla(210,24%,88%,1)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #8c959f))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #656d76))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #ffffff))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, #0969da))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, #0860CA))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, #0757BA))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #ffffff))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #ffffff))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #f6f8fa))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #858F99))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #ffffff))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #f6f8fa))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, #0969da))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, #eaeef2))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #ffffff))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, rgba(175,184,193,0.2)))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-hover-active-bg, rgba(175,184,193,0.4)))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-hover-active-selected-border, #8c959f))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(208,215,222,0.32)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-chevron-directory-fill, #54aeff))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #1F2328))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #656d76))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #6e7781))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #ffffff))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #ffffff))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #f6f8fa))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #f6f8fa))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #d0d7de))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, hsla(210,18%,87%,1)))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(31,35,40,0.15)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #24292f))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #6e7781))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(175,184,193,0.2)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(234,238,242,0.5)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #0969da))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #0969da))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(84,174,255,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, #ddf4ff))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #1a7f37))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #1f883d))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(74,194,107,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, #dafbe1))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #9a6700))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #9a6700))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(212,167,44,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, #fff8c5))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #bc4c00))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #bc4c00))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(251,143,68,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, #fff1e5))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #d1242f))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #cf222e))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(255,129,130,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, #ffebe9))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #1a7f37))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #1f883d))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(74,194,107,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, #dafbe1))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #d1242f))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #cf222e))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(255,129,130,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, #ffebe9))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #8250df))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8250df))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(194,151,255,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, #fbefff))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #bf3989))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #bf3989))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(255,128,200,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, #ffeff7))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #8c959f))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-fg-canvas-backdrop, rgba(31,35,40,0.5)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(255,255,255,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #fd8c73))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(31,35,40,0.1)))"
					}
				}
			},
			"shadows": {
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(0 0 0 / 15%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(0 0 0 / 15%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(0 0 0 / 70%) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px rgba(255,255,255,0.8)))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 1px 3px rgba(31,35,40,0.12), 0 8px 24px rgba(66,74,83,0.12)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 1px 0 rgba(31,35,40,0.04)))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 1px 0 rgba(31,35,40,0.1)))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, inset 0 1px 0 rgba(0,45,17,0.2)))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(31,35,40,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, inset 0 1px 0 rgba(0,33,85,0.2)))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 1px 0 rgba(31,35,40,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, inset 0 1px 0 rgba(76,0,20,0.2)))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 1px 0 rgba(31,35,40,0.04)))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px rgba(140,149,159,0.15)))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px rgba(140,149,159,0.2)))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 28px rgba(140,149,159,0.3)))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, inset 0 1px 0 rgba(208,215,222,0.2)))"
				} }
			}
		},
		"light_high_contrast": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(255,255,255,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #ffffff))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #1168e3)",
					"secondary": "var(--color-marketing-icon-secondary, #368cf9)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #0e1116))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #ffffff))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, #ccffd8))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, #e6ffec))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, #055d20))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #0e1116))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #ffffff))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, #ffd7d5))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, #fff0ee))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, #a0111f))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, #9cd7ff))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #0e1116))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, multiply)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(1,4,9,0.8))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(1,4,9,0.8))",
					"additionBg": "var(undefined, var(--color-diffstat-addition-bg, #055d20))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, #fcf7be))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #4b535d)",
					"constant": "var(--color-prettylights-syntax-constant, #023b95)",
					"entity": "var(--color-prettylights-syntax-entity, #512598)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #0e1116)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #024c1a)",
					"keyword": "var(--color-prettylights-syntax-keyword, #a0111f)",
					"string": "var(--color-prettylights-syntax-string, #032563)",
					"variable": "var(--color-prettylights-syntax-variable, #702c00)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #6e011a)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #ffffff)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #6e011a)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #ffffff)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #a0111f)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #024c1a)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #2e1800)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #023b95)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #0e1116)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #0e1116)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #6e011a)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #fff0ee)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #024c1a)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #d2fedb)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #702c00)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #ffc67b)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #e7ecf0)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #023b95)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #622cbc)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #4b535d)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #88929d)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #032563)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #0e1116))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #ffffff))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #ffffff))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #ffffff))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #66707b))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #0e1116))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #0e1116))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, #368cf9))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, #e7ecf0))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #0e1116))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #ffffff))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #0e1116))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #023b95))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #622cbc))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #a0111f))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #a0111f))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #032563))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #023b95))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #702c00))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #0e1116)",
					"runBorderWidth": "var(--color-checks-run-border-width, 0px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 0px)",
					"textPrimary": "var(--color-checks-text-primary, #ffffff)",
					"textSecondary": "var(--color-checks-text-secondary, #88929d)",
					"textLink": "var(--color-checks-text-link, #368cf9)",
					"btnIcon": "var(--color-checks-btn-icon, #acb6c0)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #ffffff)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(255,255,255,0.125))",
					"inputText": "var(--color-checks-input-text, #e7ecf0)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #88929d)",
					"inputFocusText": "var(--color-checks-input-focus-text, #88929d)",
					"inputBg": "var(--color-checks-input-bg, #20252c)",
					"inputShadow": "var(--color-checks-input-shadow, none)",
					"donutError": "var(--color-checks-donut-error, #d5232c)",
					"donutPending": "var(--color-checks-donut-pending, #956400)",
					"donutSuccess": "var(--color-checks-donut-success, #055d20)",
					"donutNeutral": "var(--color-checks-donut-neutral, #acb6c0)",
					"dropdownText": "var(--color-checks-dropdown-text, #acb6c0)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #20252c)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #343b43)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(1,4,9,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #ffffff)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, #343b43)",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #ffffff)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, #20252c)",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, #4b535d)",
					"headerLabelText": "var(--color-checks-header-label-text, #ced5dc)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #ffffff)",
					"headerBorder": "var(--color-checks-header-border, #20252c)",
					"headerIcon": "var(--color-checks-header-icon, #88929d)",
					"lineText": "var(--color-checks-line-text, #ced5dc)",
					"lineNumText": "var(--color-checks-line-num-text, rgba(136,146,157,0.75))",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #88929d)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, #20252c)",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(17,104,227,0.15))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #368cf9)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #0e1116)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #744500)",
					"gateBg": "var(--color-checks-gate-bg, rgba(96,55,0,0.15))",
					"gateText": "var(--color-checks-gate-text, #ced5dc)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #b58407)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #20252c)",
					"stepErrorText": "var(--color-checks-step-error-text, #ee5a5d)",
					"stepWarningText": "var(--color-checks-step-warning-text, #b58407)",
					"loglineText": "var(--color-checks-logline-text, #88929d)",
					"loglineNumText": "var(--color-checks-logline-num-text, rgba(136,146,157,0.75))",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #a371f7)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #ced5dc)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #ee5a5d)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(134,6,29,0.15))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #ced5dc)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #b58407)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(96,55,0,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #368cf9)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #26a148)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #0e1116)",
						"blackBright": "var(--color-checks-ansi-black-bright, #20252c)",
						"white": "var(--color-checks-ansi-white, #ced5dc)",
						"whiteBright": "var(--color-checks-ansi-white-bright, #ced5dc)",
						"gray": "var(--color-checks-ansi-gray, #88929d)",
						"red": "var(--color-checks-ansi-red, #ee5a5d)",
						"redBright": "var(--color-checks-ansi-red-bright, #ff8e8a)",
						"green": "var(--color-checks-ansi-green, #26a148)",
						"greenBright": "var(--color-checks-ansi-green-bright, #43c663)",
						"yellow": "var(--color-checks-ansi-yellow, #b58407)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #d5a824)",
						"blue": "var(--color-checks-ansi-blue, #368cf9)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #67b3fd)",
						"magenta": "var(--color-checks-ansi-magenta, #a371f7)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #c49bff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #0e1116)",
					"sidebarBg": "var(--color-project-sidebar-bg, #ffffff)",
					"gradientIn": "var(--color-project-gradient-in, #ffffff)",
					"gradientOut": "var(--color-project-gradient-out, rgba(255,255,255,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #1b1f23))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #20252c))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, #ffffff))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(1,4,9,0.8)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #acb6c0))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #ced5dc))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, #0349b4))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, #20252c))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, transparent))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(172,182,192,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #9cd7ff))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(136,146,157,0.2)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #0e1116))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #acb6c0))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #ffffff))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #0e1116))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #4b535d))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #ffffff))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, transparent))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(172,182,192,0.2)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #e7ecf0))" },
				"ansi": {
					"black": "var(--color-ansi-black, #0e1116)",
					"blackBright": "var(--color-ansi-black-bright, #4b535d)",
					"white": "var(--color-ansi-white, #66707b)",
					"whiteBright": "var(--color-ansi-white-bright, #88929d)",
					"gray": "var(--color-ansi-gray, #66707b)",
					"red": "var(--color-ansi-red, #a0111f)",
					"redBright": "var(--color-ansi-red-bright, #86061d)",
					"green": "var(--color-ansi-green, #024c1a)",
					"greenBright": "var(--color-ansi-green-bright, #055d20)",
					"yellow": "var(--color-ansi-yellow, #3f2200)",
					"yellowBright": "var(--color-ansi-yellow-bright, #4e2c00)",
					"blue": "var(--color-ansi-blue, #0349b4)",
					"blueBright": "var(--color-ansi-blue-bright, #1168e3)",
					"magenta": "var(--color-ansi-magenta, #622cbc)",
					"magentaBright": "var(--color-ansi-magenta-bright, #844ae7)",
					"cyan": "var(--color-ansi-cyan, #1b7c83)",
					"cyanBright": "var(--color-ansi-cyan-bright, #3192aa)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #0e1116))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #e7ecf0))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(1,4,9,0.8)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #ced5dc))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, rgba(1,4,9,0.8)))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, #acb6c0))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, rgba(1,4,9,0.8)))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, #acb6c0))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, rgba(1,4,9,0.08)))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #055d20))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, #013d14))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #024c1a))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, #013d14))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, hsla(139,95%,13%,1)))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.8)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, #94d3a2))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(1,4,9,0.8)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, rgba(255,255,255,0.8)))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(0,35,11,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #023b95))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #ffffff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #0349b4))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, #022f7a))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, #022f7a))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, #022f7a))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(3,73,180,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #e7ecf0))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(3,73,180,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, #0969da1a))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #023b95))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(3,73,180,0.5)))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #86061d))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #a0111f))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, #6e011a))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, #6e011a))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, #6e011a))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(160,17,31,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #e7ecf0))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(160,17,31,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(160,17,31,0.1)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #86061d))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #86061d))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(160,17,31,0.5)))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #e7ecf0))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #4b535d))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #66707b))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(172,182,192,0.2)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, #88929d))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, #e7ecf0))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, #88929d))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, #ced5dc))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, #20252c))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, #ced5dc))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-danger-hover-bg, #a0111f))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-danger-active-bg, #6e011a))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-danger-hover-text, #ffffff))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, #66707b))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(211,9%,47%,1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, hsla(211,9%,49%,1)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #88929d))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #ffffff))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #ffffff))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, #0349b4))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, #0860CA))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, #0757BA))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #ffffff))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #ffffff))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #e7ecf0))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #20252c))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #ffffff))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #e7ecf0))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, #0349b4))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, #e7ecf0))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #ffffff))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, rgba(172,182,192,0.2)))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-hover-active-bg, rgba(172,182,192,0.4)))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-hover-active-selected-border, #88929d))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, #ced5dc))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-chevron-directory-fill, #368cf9))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #0e1116))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #0e1116))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #66707b))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #ffffff))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #ffffff))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #ffffff))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #e7ecf0))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #20252c))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, #88929d))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(1,4,9,0.8)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #0e1116))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #66707b))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(172,182,192,0.2)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, #e7ecf0))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #0349b4))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #0349b4))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, #368cf9))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, #dff7ff))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #055d20))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #055d20))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, #26a148))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, #d2fedb))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #744500))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #744500))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, #b58407))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, #fcf7be))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #873800))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #873800))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, #dc6d1a))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, #fff2d5))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #d1242f))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #a0111f))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, #ee5a5d))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, #fff0ee))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #055d20))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #055d20))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(38,161,72,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, #d2fedb))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #d1242f))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #a0111f))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(238,90,93,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, #fff0ee))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #622cbc))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #622cbc))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, #a371f7))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, #faf0fe))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #971368))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #971368))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, #ed4baf))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, #feeff7))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #88929d))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-fg-canvas-backdrop, rgba(1,4,9,0.5)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(255,255,255,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #ef5b48))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(1,4,9,0.1)))"
					}
				}
			},
			"shadows": {
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(0 0 0 / 15%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(0 0 0 / 15%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(0 0 0 / 70%) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px rgba(255,255,255,0.8)))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 1px 3px rgba(1,4,9,0.12), 0 8px 24px rgba(52,59,67,0.12)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 1px 0 rgba(1,4,9,0.04)))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 1px 0 rgba(1,4,9,0.1)))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, inset 0 1px 0 rgba(0,35,11,0.2)))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(1,4,9,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, inset 0 1px 0 rgba(2,26,74,0.2)))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 1px 0 rgba(1,4,9,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, inset 0 1px 0 rgba(67,0,17,0.2)))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 1px 0 rgba(1,4,9,0.04)))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px rgba(136,146,157,0.15)))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px rgba(136,146,157,0.2)))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 28px rgba(136,146,157,0.3)))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, inset 0 1px 0 rgba(206,213,220,0.2)))"
				} }
			}
		},
		"light_colorblind": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(255,255,255,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #f6f8fa))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #218bff)",
					"secondary": "var(--color-marketing-icon-secondary, #54aeff)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #24292f))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #24292f))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(84,174,255,0.4)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(221,244,255,0.5)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, rgba(84,174,255,0.4)))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #24292f))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #24292f))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(247,153,57,0.4)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(255,245,232,0.5)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(255,188,109,0.5)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(84,174,255,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #57606a))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, multiply)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(27,31,36,0.15))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(27,31,36,0.15))",
					"additionBg": "var(undefined, var(--color-diffstat-addition-bg, #0969da))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, #fff8c5))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #57606a)",
					"constant": "var(--color-prettylights-syntax-constant, #0550ae)",
					"entity": "var(--color-prettylights-syntax-entity, #6639ba)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #24292f)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #0550ae)",
					"keyword": "var(--color-prettylights-syntax-keyword, #b35900)",
					"string": "var(--color-prettylights-syntax-string, #0a3069)",
					"variable": "var(--color-prettylights-syntax-variable, #8a4600)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #6f3800)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #f6f8fa)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #6f3800)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #f6f8fa)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #b35900)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #0550ae)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #3b2300)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #0550ae)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #24292f)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #24292f)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #6f3800)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #fff5e8)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #0550ae)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #ddf4ff)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #8a4600)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #ffddb0)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #eaeef2)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #0550ae)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #8250df)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #57606a)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #8c959f)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #0a3069)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #24292f))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #ffffff))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #ffffff))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #ffffff))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #6e7781))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #57606a))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #24292f))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(84,174,255,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(234,238,242,0.5)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #24292f))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #ffffff))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #24292f))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #0550ae))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #8250df))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #b35900))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #b35900))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #0a3069))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #0550ae))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #8a4600))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #24292f)",
					"runBorderWidth": "var(--color-checks-run-border-width, 0px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 0px)",
					"textPrimary": "var(--color-checks-text-primary, #f6f8fa)",
					"textSecondary": "var(--color-checks-text-secondary, #8c959f)",
					"textLink": "var(--color-checks-text-link, #54aeff)",
					"btnIcon": "var(--color-checks-btn-icon, #afb8c1)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #f6f8fa)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(255,255,255,0.125))",
					"inputText": "var(--color-checks-input-text, #eaeef2)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #8c959f)",
					"inputFocusText": "var(--color-checks-input-focus-text, #8c959f)",
					"inputBg": "var(--color-checks-input-bg, #32383f)",
					"inputShadow": "var(--color-checks-input-shadow, none)",
					"donutError": "var(--color-checks-donut-error, #dd7815)",
					"donutPending": "var(--color-checks-donut-pending, #bf8700)",
					"donutSuccess": "var(--color-checks-donut-success, #0969da)",
					"donutNeutral": "var(--color-checks-donut-neutral, #afb8c1)",
					"dropdownText": "var(--color-checks-dropdown-text, #afb8c1)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #32383f)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #424a53)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(27,31,36,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #f6f8fa)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, #424a53)",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #f6f8fa)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, #32383f)",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, #57606a)",
					"headerLabelText": "var(--color-checks-header-label-text, #d0d7de)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #f6f8fa)",
					"headerBorder": "var(--color-checks-header-border, #32383f)",
					"headerIcon": "var(--color-checks-header-icon, #8c959f)",
					"lineText": "var(--color-checks-line-text, #d0d7de)",
					"lineNumText": "var(--color-checks-line-num-text, rgba(140,149,159,0.75))",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #8c959f)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, #32383f)",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(33,139,255,0.15))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #54aeff)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #24292f)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #9a6700)",
					"gateBg": "var(--color-checks-gate-bg, rgba(125,78,0,0.15))",
					"gateText": "var(--color-checks-gate-text, #d0d7de)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #d4a72c)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #32383f)",
					"stepErrorText": "var(--color-checks-step-error-text, #f79939)",
					"stepWarningText": "var(--color-checks-step-warning-text, #d4a72c)",
					"loglineText": "var(--color-checks-logline-text, #8c959f)",
					"loglineNumText": "var(--color-checks-logline-num-text, rgba(140,149,159,0.75))",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #c297ff)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #d0d7de)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #f79939)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(138,70,0,0.15))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #d0d7de)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #d4a72c)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(125,78,0,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #54aeff)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #54aeff)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #24292f)",
						"blackBright": "var(--color-checks-ansi-black-bright, #32383f)",
						"white": "var(--color-checks-ansi-white, #d0d7de)",
						"whiteBright": "var(--color-checks-ansi-white-bright, #d0d7de)",
						"gray": "var(--color-checks-ansi-gray, #8c959f)",
						"red": "var(--color-checks-ansi-red, #f79939)",
						"redBright": "var(--color-checks-ansi-red-bright, #ffbc6d)",
						"green": "var(--color-checks-ansi-green, #54aeff)",
						"greenBright": "var(--color-checks-ansi-green-bright, #80ccff)",
						"yellow": "var(--color-checks-ansi-yellow, #d4a72c)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #eac54f)",
						"blue": "var(--color-checks-ansi-blue, #54aeff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #80ccff)",
						"magenta": "var(--color-checks-ansi-magenta, #c297ff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #d8b9ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #24292f)",
					"sidebarBg": "var(--color-project-sidebar-bg, #ffffff)",
					"gradientIn": "var(--color-project-gradient-in, #ffffff)",
					"gradientOut": "var(--color-project-gradient-out, rgba(255,255,255,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #1b1f23))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #858F99))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, #ffffff))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(27,31,36,0.15)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #afb8c1))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #d0d7de))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, transparent))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(175,184,193,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #b6e3ff))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(140,149,159,0.2)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #24292f))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #57606a))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #ffffff))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #24292f))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #57606a))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #ffffff))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, transparent))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(175,184,193,0.2)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #eaeef2))" },
				"ansi": {
					"black": "var(--color-ansi-black, #24292f)",
					"blackBright": "var(--color-ansi-black-bright, #57606a)",
					"white": "var(--color-ansi-white, #6e7781)",
					"whiteBright": "var(--color-ansi-white-bright, #8c959f)",
					"gray": "var(--color-ansi-gray, #6e7781)",
					"red": "var(--color-ansi-red, #b35900)",
					"redBright": "var(--color-ansi-red-bright, #8a4600)",
					"green": "var(--color-ansi-green, #0550ae)",
					"greenBright": "var(--color-ansi-green-bright, #0969da)",
					"yellow": "var(--color-ansi-yellow, #4d2d00)",
					"yellowBright": "var(--color-ansi-yellow-bright, #633c01)",
					"blue": "var(--color-ansi-blue, #0969da)",
					"blueBright": "var(--color-ansi-blue-bright, #218bff)",
					"magenta": "var(--color-ansi-magenta, #8250df)",
					"magentaBright": "var(--color-ansi-magenta-bright, #a475f9)",
					"cyan": "var(--color-ansi-cyan, #1b7c83)",
					"cyanBright": "var(--color-ansi-cyan-bright, #3192aa)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #24292f))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #f6f8fa))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(27,31,36,0.15)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #f3f4f6))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, rgba(27,31,36,0.15)))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(220,14%,93%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, rgba(27,31,36,0.15)))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, hsla(220,14%,94%,1)))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, rgba(27,31,36,0.08)))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #0969da))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(27,31,36,0.15)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #0969da))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(27,31,36,0.15)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, hsla(212,92%,43%,1)))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.8)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, #80ccff))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(27,31,36,0.15)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, rgba(255,255,255,0.8)))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(0,33,85,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #0969da))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #ffffff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #0969da))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(27,31,36,0.15)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, hsla(212,92%,42%,1)))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(27,31,36,0.15)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(9,105,218,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #f6f8fa))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(9,105,218,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, #0969da1a))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #0550ae))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(9,105,218,0.5)))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #b35900))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #8a4600))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, rgba(27,31,36,0.15)))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, hsla(30,100%,32%,1)))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, rgba(27,31,36,0.15)))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(179,89,0,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #f6f8fa))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(179,89,0,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(179,89,0,0.1)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #b35900))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #8a4600))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(179,89,0,0.5)))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #eaeef2))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #57606a))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #6e7781))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(175,184,193,0.2)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(208,215,222,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(208,215,222,0.32)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(208,215,222,0.48)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(208,215,222,0.24)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-default-danger-hover-bg, rgba(255,245,232,0.64)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-default-danger-active-bg, #fff5e8))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-default-danger-hover-text, #b35900))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, #eaeef2))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(210,24%,90%,1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, hsla(210,24%,88%,1)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #8c959f))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #57606a))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #ffffff))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, #0969da))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, #0860CA))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, #0757BA))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #ffffff))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #ffffff))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #f6f8fa))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #858F99))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #ffffff))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #f6f8fa))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, #0969da))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, #eaeef2))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #ffffff))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, rgba(175,184,193,0.2)))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-hover-active-bg, rgba(175,184,193,0.4)))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-hover-active-selected-border, #8c959f))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(208,215,222,0.32)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-chevron-directory-fill, #54aeff))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #24292f))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #57606a))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #6e7781))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #ffffff))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #ffffff))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #f6f8fa))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #f6f8fa))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #d0d7de))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, hsla(210,18%,87%,1)))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(27,31,36,0.15)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #24292f))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #6e7781))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(175,184,193,0.2)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(234,238,242,0.5)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #0969da))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #0969da))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(84,174,255,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, #ddf4ff))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #0969da))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #0969da))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(84,174,255,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, #ddf4ff))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #9a6700))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #9a6700))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(212,167,44,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, #fff8c5))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #b35900))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #b35900))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(247,153,57,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, #fff5e8))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #b35900))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #b35900))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(247,153,57,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, #fff5e8))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #b35900))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #dd7815))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(247,153,57,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, #fff5e8))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #6e7781))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #6e7781))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(175,184,193,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, #f6f8fa))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #8250df))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8250df))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(194,151,255,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, #fbefff))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #bf3989))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #bf3989))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(255,128,200,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, #ffeff7))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #8c959f))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-fg-canvas-backdrop, rgba(27,31,36,0.5)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(255,255,255,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #fd8c73))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(27,31,36,0.1)))"
					}
				}
			},
			"shadows": {
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(0 0 0 / 15%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(0 0 0 / 15%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(0 0 0 / 70%) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px rgba(255,255,255,0.8)))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 1px 3px rgba(27,31,36,0.12), 0 8px 24px rgba(66,74,83,0.12)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 1px 0 rgba(27,31,36,0.04)))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 1px 0 rgba(27,31,36,0.1)))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, inset 0 1px 0 rgba(0,33,85,0.2)))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(27,31,36,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, inset 0 1px 0 rgba(0,33,85,0.2)))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 1px 0 rgba(27,31,36,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, inset 0 1px 0 rgba(65,32,0,0.2)))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 1px 0 rgba(27,31,36,0.04)))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px rgba(140,149,159,0.15)))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px rgba(140,149,159,0.2)))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 28px rgba(140,149,159,0.3)))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, inset 0 1px 0 rgba(208,215,222,0.2)))"
				} }
			}
		},
		"light_tritanopia": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(255,255,255,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #f6f8fa))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #218bff)",
					"secondary": "var(--color-marketing-icon-secondary, #54aeff)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #24292f))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #24292f))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(84,174,255,0.4)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(221,244,255,0.5)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, rgba(84,174,255,0.4)))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #24292f))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #24292f))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(255,129,130,0.4)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(255,235,233,0.5)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(255,171,168,0.5)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(84,174,255,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #57606a))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, multiply)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(27,31,36,0.15))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(27,31,36,0.15))",
					"additionBg": "var(undefined, var(--color-diffstat-addition-bg, #0969da))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, #fff8c5))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #57606a)",
					"constant": "var(--color-prettylights-syntax-constant, #0550ae)",
					"entity": "var(--color-prettylights-syntax-entity, #6639ba)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #24292f)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #0550ae)",
					"keyword": "var(--color-prettylights-syntax-keyword, #cf222e)",
					"string": "var(--color-prettylights-syntax-string, #0a3069)",
					"variable": "var(--color-prettylights-syntax-variable, #a40e26)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #82071e)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #f6f8fa)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #82071e)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #f6f8fa)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #cf222e)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #0550ae)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #3b2300)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #0550ae)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #24292f)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #24292f)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #82071e)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #ffebe9)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #0550ae)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #ddf4ff)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #a40e26)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #ffcecb)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #eaeef2)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #0550ae)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #8250df)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #57606a)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #8c959f)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #0a3069)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #24292f))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #ffffff))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #ffffff))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #ffffff))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #6e7781))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #57606a))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #24292f))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(84,174,255,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(234,238,242,0.5)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #24292f))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #ffffff))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #24292f))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #0550ae))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #8250df))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #cf222e))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #cf222e))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #0a3069))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #0550ae))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #a40e26))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #24292f)",
					"runBorderWidth": "var(--color-checks-run-border-width, 0px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 0px)",
					"textPrimary": "var(--color-checks-text-primary, #f6f8fa)",
					"textSecondary": "var(--color-checks-text-secondary, #8c959f)",
					"textLink": "var(--color-checks-text-link, #54aeff)",
					"btnIcon": "var(--color-checks-btn-icon, #afb8c1)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #f6f8fa)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(255,255,255,0.125))",
					"inputText": "var(--color-checks-input-text, #eaeef2)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #8c959f)",
					"inputFocusText": "var(--color-checks-input-focus-text, #8c959f)",
					"inputBg": "var(--color-checks-input-bg, #32383f)",
					"inputShadow": "var(--color-checks-input-shadow, none)",
					"donutError": "var(--color-checks-donut-error, #fa4549)",
					"donutPending": "var(--color-checks-donut-pending, #bf8700)",
					"donutSuccess": "var(--color-checks-donut-success, #0969da)",
					"donutNeutral": "var(--color-checks-donut-neutral, #afb8c1)",
					"dropdownText": "var(--color-checks-dropdown-text, #afb8c1)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #32383f)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #424a53)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(27,31,36,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #f6f8fa)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, #424a53)",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #f6f8fa)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, #32383f)",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, #57606a)",
					"headerLabelText": "var(--color-checks-header-label-text, #d0d7de)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #f6f8fa)",
					"headerBorder": "var(--color-checks-header-border, #32383f)",
					"headerIcon": "var(--color-checks-header-icon, #8c959f)",
					"lineText": "var(--color-checks-line-text, #d0d7de)",
					"lineNumText": "var(--color-checks-line-num-text, rgba(140,149,159,0.75))",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #8c959f)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, #32383f)",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(33,139,255,0.15))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #54aeff)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #24292f)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #9a6700)",
					"gateBg": "var(--color-checks-gate-bg, rgba(125,78,0,0.15))",
					"gateText": "var(--color-checks-gate-text, #d0d7de)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #d4a72c)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #32383f)",
					"stepErrorText": "var(--color-checks-step-error-text, #ff8182)",
					"stepWarningText": "var(--color-checks-step-warning-text, #d4a72c)",
					"loglineText": "var(--color-checks-logline-text, #8c959f)",
					"loglineNumText": "var(--color-checks-logline-num-text, rgba(140,149,159,0.75))",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #c297ff)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #d0d7de)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #ff8182)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(164,14,38,0.15))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #d0d7de)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #d4a72c)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(125,78,0,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #54aeff)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #54aeff)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #24292f)",
						"blackBright": "var(--color-checks-ansi-black-bright, #32383f)",
						"white": "var(--color-checks-ansi-white, #d0d7de)",
						"whiteBright": "var(--color-checks-ansi-white-bright, #d0d7de)",
						"gray": "var(--color-checks-ansi-gray, #8c959f)",
						"red": "var(--color-checks-ansi-red, #ff8182)",
						"redBright": "var(--color-checks-ansi-red-bright, #ffaba8)",
						"green": "var(--color-checks-ansi-green, #54aeff)",
						"greenBright": "var(--color-checks-ansi-green-bright, #80ccff)",
						"yellow": "var(--color-checks-ansi-yellow, #d4a72c)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #eac54f)",
						"blue": "var(--color-checks-ansi-blue, #54aeff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #80ccff)",
						"magenta": "var(--color-checks-ansi-magenta, #c297ff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #d8b9ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #24292f)",
					"sidebarBg": "var(--color-project-sidebar-bg, #ffffff)",
					"gradientIn": "var(--color-project-gradient-in, #ffffff)",
					"gradientOut": "var(--color-project-gradient-out, rgba(255,255,255,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #1b1f23))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #858F99))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, #ffffff))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(27,31,36,0.15)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #afb8c1))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #d0d7de))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, transparent))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(175,184,193,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #b6e3ff))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(140,149,159,0.2)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #24292f))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #57606a))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #ffffff))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #24292f))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #57606a))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #ffffff))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, transparent))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(175,184,193,0.2)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #eaeef2))" },
				"ansi": {
					"black": "var(--color-ansi-black, #24292f)",
					"blackBright": "var(--color-ansi-black-bright, #57606a)",
					"white": "var(--color-ansi-white, #6e7781)",
					"whiteBright": "var(--color-ansi-white-bright, #8c959f)",
					"gray": "var(--color-ansi-gray, #6e7781)",
					"red": "var(--color-ansi-red, #cf222e)",
					"redBright": "var(--color-ansi-red-bright, #a40e26)",
					"green": "var(--color-ansi-green, #0550ae)",
					"greenBright": "var(--color-ansi-green-bright, #0969da)",
					"yellow": "var(--color-ansi-yellow, #4d2d00)",
					"yellowBright": "var(--color-ansi-yellow-bright, #633c01)",
					"blue": "var(--color-ansi-blue, #0969da)",
					"blueBright": "var(--color-ansi-blue-bright, #218bff)",
					"magenta": "var(--color-ansi-magenta, #8250df)",
					"magentaBright": "var(--color-ansi-magenta-bright, #a475f9)",
					"cyan": "var(--color-ansi-cyan, #1b7c83)",
					"cyanBright": "var(--color-ansi-cyan-bright, #3192aa)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #24292f))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #f6f8fa))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(27,31,36,0.15)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #f3f4f6))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, rgba(27,31,36,0.15)))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(220,14%,93%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, rgba(27,31,36,0.15)))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, hsla(220,14%,94%,1)))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, rgba(27,31,36,0.08)))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #0969da))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(27,31,36,0.15)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #0969da))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(27,31,36,0.15)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, hsla(212,92%,43%,1)))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.8)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, #80ccff))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(27,31,36,0.15)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, rgba(255,255,255,0.8)))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(0,33,85,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #0969da))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #ffffff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #0969da))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(27,31,36,0.15)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, hsla(212,92%,42%,1)))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(27,31,36,0.15)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(9,105,218,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #f6f8fa))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(9,105,218,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, #0969da1a))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #0550ae))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(9,105,218,0.5)))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #cf222e))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #a40e26))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, rgba(27,31,36,0.15)))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, hsla(356,72%,44%,1)))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, rgba(27,31,36,0.15)))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(207,34,46,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #f6f8fa))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(207,34,46,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(207,34,46,0.1)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #cf222e))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #a40e26))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(207,34,46,0.5)))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #eaeef2))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #57606a))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #6e7781))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(175,184,193,0.2)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(208,215,222,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(208,215,222,0.32)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(208,215,222,0.48)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(208,215,222,0.24)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-default-danger-hover-bg, rgba(255,235,233,0.64)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-default-danger-active-bg, #ffebe9))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-default-danger-hover-text, #cf222e))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, #eaeef2))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(210,24%,90%,1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, hsla(210,24%,88%,1)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #8c959f))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #57606a))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #ffffff))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, #0969da))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, #0860CA))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, #0757BA))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #ffffff))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #ffffff))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #f6f8fa))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #858F99))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #ffffff))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #f6f8fa))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, #0969da))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, #eaeef2))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #ffffff))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, rgba(175,184,193,0.2)))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-hover-active-bg, rgba(175,184,193,0.4)))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-hover-active-selected-border, #8c959f))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(208,215,222,0.32)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-chevron-directory-fill, #54aeff))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #24292f))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #57606a))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #6e7781))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #ffffff))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #ffffff))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #f6f8fa))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #f6f8fa))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #d0d7de))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, hsla(210,18%,87%,1)))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(27,31,36,0.15)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #24292f))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #6e7781))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(175,184,193,0.2)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(234,238,242,0.5)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #0969da))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #0969da))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(84,174,255,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, #ddf4ff))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #0969da))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #0969da))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(84,174,255,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, #ddf4ff))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #9a6700))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #9a6700))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(212,167,44,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, #fff8c5))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #cf222e))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #cf222e))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(255,129,130,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, #ffebe9))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #cf222e))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #cf222e))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(255,129,130,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, #ffebe9))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #cf222e))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #fa4549))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(255,129,130,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, #ffebe9))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #6e7781))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #6e7781))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(175,184,193,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, #f6f8fa))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #8250df))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8250df))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(194,151,255,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, #fbefff))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #bf3989))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #bf3989))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(255,128,200,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, #ffeff7))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #8c959f))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-fg-canvas-backdrop, rgba(27,31,36,0.5)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(255,255,255,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #fd8c73))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(27,31,36,0.1)))"
					}
				}
			},
			"shadows": {
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(0 0 0 / 15%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(0 0 0 / 15%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(0 0 0 / 70%) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px rgba(255,255,255,0.8)))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 1px 3px rgba(27,31,36,0.12), 0 8px 24px rgba(66,74,83,0.12)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 1px 0 rgba(27,31,36,0.04)))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 1px 0 rgba(27,31,36,0.1)))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, inset 0 1px 0 rgba(0,33,85,0.2)))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(27,31,36,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, inset 0 1px 0 rgba(0,33,85,0.2)))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 1px 0 rgba(27,31,36,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, inset 0 1px 0 rgba(76,0,20,0.2)))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 1px 0 rgba(27,31,36,0.04)))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px rgba(140,149,159,0.15)))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px rgba(140,149,159,0.2)))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 28px rgba(140,149,159,0.3)))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, inset 0 1px 0 rgba(255,255,255,0.25)))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, inset 0 1px 0 rgba(208,215,222,0.2)))"
				} }
			}
		},
		"dark": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(13,17,23,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #0d1117))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #79c0ff)",
					"secondary": "var(--color-marketing-icon-secondary, #1f6feb)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #e6edf3))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #e6edf3))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(63,185,80,0.3)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(46,160,67,0.15)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, rgba(46,160,67,0.4)))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #e6edf3))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #e6edf3))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(248,81,73,0.3)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(248,81,73,0.1)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(248,81,73,0.4)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(56,139,253,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #848d97))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, screen)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(240,246,252,0.1))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(240,246,252,0.1))",
					"additionBg": "var(--diffStat-addition-bgColor, var(--color-diffstat-addition-bg, #3fb950))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, rgba(210,153,34,0.4)))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #8b949e)",
					"constant": "var(--color-prettylights-syntax-constant, #79c0ff)",
					"entity": "var(--color-prettylights-syntax-entity, #d2a8ff)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #c9d1d9)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #7ee787)",
					"keyword": "var(--color-prettylights-syntax-keyword, #ff7b72)",
					"string": "var(--color-prettylights-syntax-string, #a5d6ff)",
					"variable": "var(--color-prettylights-syntax-variable, #ffa657)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #f85149)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #f0f6fc)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #8e1519)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #f0f6fc)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #b62324)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #7ee787)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #f2cc60)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #1f6feb)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #c9d1d9)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #c9d1d9)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #ffdcd7)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #67060c)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #aff5b4)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #033a16)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #ffdfb6)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #5a1e02)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #c9d1d9)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #1158c7)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #d2a8ff)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #8b949e)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #484f58)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #a5d6ff)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #e6edf3))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #0d1117))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #0d1117))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #0d1117))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #6e7681))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #848d97))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #e6edf3))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(56,139,253,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(110,118,129,0.1)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #e6edf3))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #0d1117))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #8b949e))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #79c0ff))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #d2a8ff))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #ff7b72))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #ff7b72))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #a5d6ff))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #79c0ff))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #ffa657))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #010409)",
					"runBorderWidth": "var(--color-checks-run-border-width, 1px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 1px)",
					"textPrimary": "var(--color-checks-text-primary, #e6edf3)",
					"textSecondary": "var(--color-checks-text-secondary, #848d97)",
					"textLink": "var(--color-checks-text-link, #2f81f7)",
					"btnIcon": "var(--color-checks-btn-icon, #848d97)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #e6edf3)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(110,118,129,0.1))",
					"inputText": "var(--color-checks-input-text, #848d97)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #6e7681)",
					"inputFocusText": "var(--color-checks-input-focus-text, #e6edf3)",
					"inputBg": "var(--color-checks-input-bg, #161b22)",
					"donutError": "var(--color-checks-donut-error, #f85149)",
					"donutPending": "var(--color-checks-donut-pending, #d29922)",
					"donutSuccess": "var(--color-checks-donut-success, #2ea043)",
					"donutNeutral": "var(--color-checks-donut-neutral, #8b949e)",
					"dropdownText": "var(--color-checks-dropdown-text, #e6edf3)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #161b22)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #30363d)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(1,4,9,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #e6edf3)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, rgba(110,118,129,0.1))",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #e6edf3)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, rgba(110,118,129,0.1))",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, rgba(110,118,129,0.4))",
					"headerLabelText": "var(--color-checks-header-label-text, #848d97)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #e6edf3)",
					"headerBorder": "var(--color-checks-header-border, #21262d)",
					"headerIcon": "var(--color-checks-header-icon, #848d97)",
					"lineText": "var(--color-checks-line-text, #848d97)",
					"lineNumText": "var(--color-checks-line-num-text, #6e7681)",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #6e7681)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, rgba(110,118,129,0.1))",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(56,139,253,0.1))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #2f81f7)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #ffffff)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #9e6a03)",
					"gateBg": "var(--color-checks-gate-bg, rgba(187,128,9,0.15))",
					"gateText": "var(--color-checks-gate-text, #848d97)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #d29922)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #161b22)",
					"stepErrorText": "var(--color-checks-step-error-text, #f85149)",
					"stepWarningText": "var(--color-checks-step-warning-text, #d29922)",
					"loglineText": "var(--color-checks-logline-text, #848d97)",
					"loglineNumText": "var(--color-checks-logline-num-text, #6e7681)",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #a371f7)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #848d97)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #6e7681)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(248,81,73,0.1))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #848d97)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #d29922)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(187,128,9,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #2f81f7)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #3fb950)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #0d1117)",
						"blackBright": "var(--color-checks-ansi-black-bright, #161b22)",
						"white": "var(--color-checks-ansi-white, #b1bac4))",
						"whiteBright": "var(--color-checks-ansi-white-bright, #b1bac4)",
						"gray": "var(--color-checks-ansi-gray, #6e7681)",
						"red": "var(--color-checks-ansi-red, #ff7b72)",
						"redBright": "var(--color-checks-ansi-red-bright, #ffa198)",
						"green": "var(--color-checks-ansi-green, #3fb950)",
						"greenBright": "var(--color-checks-ansi-green-bright, #56d364)",
						"yellow": "var(--color-checks-ansi-yellow, #d29922)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #e3b341)",
						"blue": "var(--color-checks-ansi-blue, #58a6ff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #79c0ff)",
						"magenta": "var(--color-checks-ansi-magenta, #bc8cff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #d2a8ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #0d1117)",
					"sidebarBg": "var(--color-project-sidebar-bg, #161b22)",
					"gradientIn": "var(--color-project-gradient-in, #161b22)",
					"gradientOut": "var(--color-project-gradient-out, rgba(22,27,34,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #f6f8fa))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #606771))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, rgba(255,255,255,0.1)))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(240,246,252,0.1)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #30363d))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #21262d))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, #484f58))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(48,54,61,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #0c2d6b))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(22,27,34,0.4)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #161b22))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #8b949e))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #f0f6fc))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #0d1117))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #30363d))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #21262d))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, #161b22))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(110,118,129,0)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #21262d))" },
				"ansi": {
					"black": "var(--color-ansi-black, #484f58)",
					"blackBright": "var(--color-ansi-black-bright, #6e7681)",
					"white": "var(--color-ansi-white, #b1bac4)",
					"whiteBright": "var(--color-ansi-white-bright, #ffffff)",
					"gray": "var(--color-ansi-gray, #6e7681)",
					"red": "var(--color-ansi-red, #ff7b72)",
					"redBright": "var(--color-ansi-red-bright, #ffa198)",
					"green": "var(--color-ansi-green, #3fb950)",
					"greenBright": "var(--color-ansi-green-bright, #56d364)",
					"yellow": "var(--color-ansi-yellow, #d29922)",
					"yellowBright": "var(--color-ansi-yellow-bright, #e3b341)",
					"blue": "var(--color-ansi-blue, #58a6ff)",
					"blueBright": "var(--color-ansi-blue-bright, #79c0ff)",
					"magenta": "var(--color-ansi-magenta, #bc8cff)",
					"magentaBright": "var(--color-ansi-magenta-bright, #d2a8ff)",
					"cyan": "var(--color-ansi-cyan, #39c5cf)",
					"cyanBright": "var(--color-ansi-cyan-bright, #56d4dd)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #c9d1d9))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #21262d))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(240,246,252,0.1)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #30363d))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, #8b949e))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(212,12%,18%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, #6e7681))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, #161b22))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, #30363d))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #238636))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(240,246,252,0.1)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #2ea043))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(240,246,252,0.1)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, #238636))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.5)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, rgba(35,134,54,0.6)))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(240,246,252,0.1)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, #ffffff))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(4,38,15,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #388bfd))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #58a6ff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #30363d))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(240,246,252,0.1)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(5,29,77,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, #0d419d))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(240,246,252,0.1)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(88,166,255,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #0d1117))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(31,111,235,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, rgba(5,29,77,0.2)))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #58a6ff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(47,129,247,0.5)))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #388bfd))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #f85149))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #da3633))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, #f85149))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, #b62324))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, #ff7b72))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(248,81,73,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #0d1117))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(218,54,51,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(73,2,2,0.2)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #f85149))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #f85149))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(248,81,73,0.5)))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #21262d))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #8b949e))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #6e7681))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(110,118,129,0.4)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(48,54,61,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(177,186,196,0.12)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(177,186,196,0.2)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(177,186,196,0.08)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-danger-hover-bg, rgba(248,81,73,0.16)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-danger-active-bg, rgba(248,81,73,0.24)))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-danger-hover-text, #ff7b72))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, rgba(110,118,129,0.1)))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(215,8%,72%,0.1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, rgba(110,118,129,0.4)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #21262d))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #848d97))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #010409))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, rgba(31,111,235,0.35)))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, rgba(31,111,235,0.5)))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, rgba(31,111,235,0.65)))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #010409))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #0d1117))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #606771))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #161b22))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #0d1117))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #161b22))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, rgba(31,111,235,0.35)))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, rgba(110,118,129,0.1)))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #0d1117))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, #30363d))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-active-bg, #21262d))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-selected-border, #6e7681))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(177,186,196,0.12)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-directory-fill, #848d97))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #e6edf3))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #848d97))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #6e7681))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #0d1117))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #161b22))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #010409))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #161b22))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #30363d))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, #21262d))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(240,246,252,0.1)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #6e7681))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #6e7681))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(110,118,129,0.4)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(110,118,129,0.1)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #2f81f7))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #1f6feb))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(56,139,253,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, rgba(56,139,253,0.1)))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #3fb950))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #238636))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(46,160,67,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, rgba(46,160,67,0.15)))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #d29922))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #9e6a03))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(187,128,9,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, rgba(187,128,9,0.15)))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #db6d28))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #bd561d))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(219,109,40,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, rgba(219,109,40,0.1)))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #f85149))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #da3633))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(248,81,73,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, rgba(248,81,73,0.1)))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #3fb950))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #238636))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(46,160,67,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, rgba(46,160,67,0.15)))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #f85149))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #da3633))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(248,81,73,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, rgba(248,81,73,0.15)))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #a371f7))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8957e5))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(163,113,247,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, rgba(163,113,247,0.1)))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #db61a2))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #bf4b8a))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(219,97,162,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, rgba(219,97,162,0.1)))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #484f58))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-canvas-backdrop, rgba(1,4,9,0.8)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(13,17,23,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #f78166))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(255,255,255,0.2)))"
					}
				}
			},
			"shadows": {
				"checks": { "inputShadow": "var(--color-checks-input-shadow, 0 0 0 1px #30363d)" },
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(255 255 255 / 25%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(255 255 255 / 25%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(255 255 255) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px #0d1117))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 0 0 1px #30363d, 0 16px 32px rgba(1,4,9,0.85)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 0 transparent))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, 0 0 transparent))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 0 transparent))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, 0 0 transparent))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(1,4,9,0.1)))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, 0 0 transparent))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 0 transparent))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, 0 0 transparent))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 0 transparent))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px #010409))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px #010409))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 48px #010409))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, 0 0 transparent))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, 0 0 transparent))"
				} }
			}
		},
		"dark_dimmed": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(34,39,46,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #22272e))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #6cb6ff)",
					"secondary": "var(--color-marketing-icon-secondary, #316dca)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #adbac7))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #adbac7))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(87,171,90,0.3)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(70,149,74,0.15)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, rgba(70,149,74,0.4)))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #adbac7))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #adbac7))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(229,83,75,0.3)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(229,83,75,0.1)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(229,83,75,0.4)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(65,132,228,0.4)))" },
					"expander": { "icon": "#adbac7" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, screen)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(205,217,229,0.1))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(205,217,229,0.1))",
					"additionBg": "var(--diffStat-addition-bgColor, var(--color-diffstat-addition-bg, #57ab5a))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, rgba(198,144,38,0.4)))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #768390)",
					"constant": "var(--color-prettylights-syntax-constant, #6cb6ff)",
					"entity": "var(--color-prettylights-syntax-entity, #dcbdfb)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #adbac7)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #8ddb8c)",
					"keyword": "var(--color-prettylights-syntax-keyword, #f47067)",
					"string": "var(--color-prettylights-syntax-string, #96d0ff)",
					"variable": "var(--color-prettylights-syntax-variable, #f69d50)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #e5534b)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #cdd9e5)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #922323)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #cdd9e5)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #ad2e2c)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #8ddb8c)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #eac55f)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #316dca)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #adbac7)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #adbac7)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #ffd8d3)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #78191b)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #b4f1b4)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #1b4721)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #ffddb0)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #682d0f)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #adbac7)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #255ab2)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #dcbdfb)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #768390)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #545d68)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #96d0ff)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #adbac7))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #22272e))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #22272e))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #22272e))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #636e7b))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #768390))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #adbac7))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(65,132,228,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(99,110,123,0.1)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #adbac7))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #22272e))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #768390))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #6cb6ff))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #dcbdfb))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #f47067))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #f47067))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #96d0ff))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #6cb6ff))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #f69d50))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #1c2128)",
					"runBorderWidth": "var(--color-checks-run-border-width, 1px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 1px)",
					"textPrimary": "var(--color-checks-text-primary, #adbac7)",
					"textSecondary": "var(--color-checks-text-secondary, #768390)",
					"textLink": "var(--color-checks-text-link, #539bf5)",
					"btnIcon": "var(--color-checks-btn-icon, #768390)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #adbac7)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(99,110,123,0.1))",
					"inputText": "var(--color-checks-input-text, #768390)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #636e7b)",
					"inputFocusText": "var(--color-checks-input-focus-text, #adbac7)",
					"inputBg": "var(--color-checks-input-bg, #2d333b)",
					"donutError": "var(--color-checks-donut-error, #e5534b)",
					"donutPending": "var(--color-checks-donut-pending, #c69026)",
					"donutSuccess": "var(--color-checks-donut-success, #46954a)",
					"donutNeutral": "var(--color-checks-donut-neutral, #768390)",
					"dropdownText": "var(--color-checks-dropdown-text, #adbac7)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #2d333b)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #444c56)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(28,33,40,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #adbac7)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, rgba(99,110,123,0.1))",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #adbac7)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, rgba(99,110,123,0.1))",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, rgba(99,110,123,0.4))",
					"headerLabelText": "var(--color-checks-header-label-text, #768390)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #adbac7)",
					"headerBorder": "var(--color-checks-header-border, #373e47)",
					"headerIcon": "var(--color-checks-header-icon, #768390)",
					"lineText": "var(--color-checks-line-text, #768390)",
					"lineNumText": "var(--color-checks-line-num-text, #636e7b)",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #636e7b)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, rgba(99,110,123,0.1))",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(65,132,228,0.1))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #539bf5)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #cdd9e5)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #966600)",
					"gateBg": "var(--color-checks-gate-bg, rgba(174,124,20,0.15))",
					"gateText": "var(--color-checks-gate-text, #768390)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #c69026)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #2d333b)",
					"stepErrorText": "var(--color-checks-step-error-text, #e5534b)",
					"stepWarningText": "var(--color-checks-step-warning-text, #c69026)",
					"loglineText": "var(--color-checks-logline-text, #768390)",
					"loglineNumText": "var(--color-checks-logline-num-text, #636e7b)",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #986ee2)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #768390)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #636e7b)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(229,83,75,0.1))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #768390)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #c69026)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(174,124,20,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #539bf5)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #57ab5a)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #22272e)",
						"blackBright": "var(--color-checks-ansi-black-bright, #2d333b)",
						"white": "var(--color-checks-ansi-white, #909dab))",
						"whiteBright": "var(--color-checks-ansi-white-bright, #909dab)",
						"gray": "var(--color-checks-ansi-gray, #636e7b)",
						"red": "var(--color-checks-ansi-red, #f47067)",
						"redBright": "var(--color-checks-ansi-red-bright, #ff938a)",
						"green": "var(--color-checks-ansi-green, #57ab5a)",
						"greenBright": "var(--color-checks-ansi-green-bright, #6bc46d)",
						"yellow": "var(--color-checks-ansi-yellow, #c69026)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #daaa3f)",
						"blue": "var(--color-checks-ansi-blue, #539bf5)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #6cb6ff)",
						"magenta": "var(--color-checks-ansi-magenta, #b083f0)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #dcbdfb)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #22272e)",
					"sidebarBg": "var(--color-project-sidebar-bg, #2d333b)",
					"gradientIn": "var(--color-project-gradient-in, #2d333b)",
					"gradientOut": "var(--color-project-gradient-out, rgba(45,51,59,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #f6f8fa))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #606771))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, rgba(205,217,229,0.1)))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(205,217,229,0.1)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #444c56))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #373e47))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, #545d68))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(68,76,86,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #143d79))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(45,51,59,0.4)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(205,217,229,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #2d333b))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #768390))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #cdd9e5))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #22272e))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #444c56))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #373e47))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, #2d333b))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(99,110,123,0)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #373e47))" },
				"ansi": {
					"black": "var(--color-ansi-black, #545d68)",
					"blackBright": "var(--color-ansi-black-bright, #636e7b)",
					"white": "var(--color-ansi-white, #909dab)",
					"whiteBright": "var(--color-ansi-white-bright, #cdd9e5)",
					"gray": "var(--color-ansi-gray, #636e7b)",
					"red": "var(--color-ansi-red, #f47067)",
					"redBright": "var(--color-ansi-red-bright, #ff938a)",
					"green": "var(--color-ansi-green, #57ab5a)",
					"greenBright": "var(--color-ansi-green-bright, #6bc46d)",
					"yellow": "var(--color-ansi-yellow, #c69026)",
					"yellowBright": "var(--color-ansi-yellow-bright, #daaa3f)",
					"blue": "var(--color-ansi-blue, #539bf5)",
					"blueBright": "var(--color-ansi-blue-bright, #6cb6ff)",
					"magenta": "var(--color-ansi-magenta, #b083f0)",
					"magentaBright": "var(--color-ansi-magenta-bright, #dcbdfb)",
					"cyan": "var(--color-ansi-cyan, #39c5cf)",
					"cyanBright": "var(--color-ansi-cyan-bright, #56d4dd)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #adbac7))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #373e47))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(205,217,229,0.1)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #444c56))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, #768390))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(213,12%,27%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, #636e7b))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, #2d333b))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, #444c56))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #347d39))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(205,217,229,0.1)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #46954a))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(205,217,229,0.1)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, #347d39))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(205,217,229,0.5)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, rgba(52,125,57,0.6)))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(205,217,229,0.1)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, #cdd9e5))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(17,52,23,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #4184e4))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #539bf5))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #444c56))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(205,217,229,0.1)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(15,45,92,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #cdd9e5))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, #1b4b91))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(205,217,229,0.1)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(83,155,245,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #22272e))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(49,109,202,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, rgba(15,45,92,0.2)))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #539bf5))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(83,155,245,0.5)))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #4184e4))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #e5534b))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #cdd9e5))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #c93c37))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, #e5534b))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #cdd9e5))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, #ad2e2c))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, #f47067))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(229,83,75,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #22272e))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(201,60,55,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(93,15,18,0.2)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #e5534b))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #e5534b))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(229,83,75,0.5)))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #cdd9e5))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #373e47))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #768390))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #636e7b))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(99,110,123,0.4)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(68,76,86,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(144,157,171,0.12)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(144,157,171,0.2)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(144,157,171,0.08)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-danger-hover-bg, rgba(229,83,75,0.16)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-danger-active-bg, rgba(229,83,75,0.24)))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-danger-hover-text, #f47067))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, rgba(99,110,123,0.1)))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(213,11%,69%,0.1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, rgba(99,110,123,0.4)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #373e47))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #768390))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #1c2128))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, rgba(49,109,202,0.35)))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, rgba(49,109,202,0.5)))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, rgba(49,109,202,0.65)))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #cdd9e5))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #1c2128))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #22272e))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #606771))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #2d333b))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #22272e))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #2d333b))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, rgba(49,109,202,0.35)))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, rgba(99,110,123,0.1)))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #22272e))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, #444c56))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-active-bg, #373e47))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-selected-border, #636e7b))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(144,157,171,0.12)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-directory-fill, #768390))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #adbac7))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #768390))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #636e7b))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #cdd9e5))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #22272e))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #2d333b))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #1c2128))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #2d333b))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #444c56))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, #373e47))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(205,217,229,0.1)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #636e7b))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #636e7b))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(99,110,123,0.4)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(99,110,123,0.1)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #539bf5))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #316dca))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(65,132,228,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, rgba(65,132,228,0.1)))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #57ab5a))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #347d39))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(70,149,74,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, rgba(70,149,74,0.15)))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #c69026))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #966600))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(174,124,20,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, rgba(174,124,20,0.15)))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #cc6b2c))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #ae5622))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(204,107,44,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, rgba(204,107,44,0.1)))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #e5534b))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #c93c37))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(229,83,75,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, rgba(229,83,75,0.1)))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #57ab5a))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #347d39))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(70,149,74,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, rgba(70,149,74,0.15)))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #e5534b))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #c93c37))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(229,83,75,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, rgba(229,83,75,0.15)))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #986ee2))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8256d0))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(152,110,226,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, rgba(152,110,226,0.1)))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #c96198))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #ae4c82))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(201,97,152,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, rgba(201,97,152,0.1)))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #545d68))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-canvas-backdrop, rgba(28,33,40,0.8)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(34,39,46,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #ec775c))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(205,217,229,0.2)))"
					}
				}
			},
			"shadows": {
				"checks": { "inputShadow": "var(--color-checks-input-shadow, 0 0 0 1px #444c56)" },
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(255 255 255 / 25%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(255 255 255 / 25%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(255 255 255) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px #22272e))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 0 0 1px #444c56, 0 16px 32px rgba(28,33,40,0.85)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 0 transparent))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, 0 0 transparent))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 0 transparent))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, 0 0 transparent))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(28,33,40,0.1)))// HI_KATIE: no matches",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(205,217,229,0.03)))// HI_KATIE: no matches",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, 0 0 transparent))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 0 transparent))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, 0 0 transparent))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 0 transparent))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px #1c2128))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px #1c2128))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 48px #1c2128))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, 0 0 transparent))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, 0 0 transparent))"
				} }
			}
		},
		"dark_high_contrast": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(10,12,16,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #0a0c10))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #91cbff)",
					"secondary": "var(--color-marketing-icon-secondary, #409eff)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #f0f3f6))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #0a0c10))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(38,205,77,0.3)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(9,180,58,0.15)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, #09b43a))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #f0f3f6))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #0a0c10))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(255,106,105,0.3)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(255,106,105,0.1)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, #ff6a69))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(64,158,255,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #f0f3f6))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, screen)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, #ffb1af)",
					"additionBorder": "var(--color-diffstat-addition-border, #4ae168)",
					"additionBg": "var(--diffStat-addition-bgColor, var(--color-diffstat-addition-bg, #26cd4d))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, rgba(240,183,47,0.4)))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #bdc4cc)",
					"constant": "var(--color-prettylights-syntax-constant, #91cbff)",
					"entity": "var(--color-prettylights-syntax-entity, #dbb7ff)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #f0f3f6)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #72f088)",
					"keyword": "var(--color-prettylights-syntax-keyword, #ff9492)",
					"string": "var(--color-prettylights-syntax-string, #addcff)",
					"variable": "var(--color-prettylights-syntax-variable, #ffb757)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #ff6a69)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #ffffff)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #e82a2f)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #ffffff)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #ff4445)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #72f088)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #fbd669)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #409eff)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #f0f3f6)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #f0f3f6)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #ffdedb)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #cc1421)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #acf7b6)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #007728)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #ffe1b4)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #a74c00)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #f0f3f6)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #318bf8)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #dbb7ff)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #bdc4cc)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #7a828e)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #addcff)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #f0f3f6))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #0a0c10))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #0a0c10))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #0a0c10))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #9ea7b3))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #f0f3f6))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #f0f3f6))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(64,158,255,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(158,167,179,0.1)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #f0f3f6))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #0a0c10))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #bdc4cc))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #91cbff))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #dbb7ff))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #ff9492))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #ff9492))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #addcff))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #91cbff))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #ffb757))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #010409)",
					"runBorderWidth": "var(--color-checks-run-border-width, 1px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 1px)",
					"textPrimary": "var(--color-checks-text-primary, #f0f3f6)",
					"textSecondary": "var(--color-checks-text-secondary, #f0f3f6)",
					"textLink": "var(--color-checks-text-link, #71b7ff)",
					"btnIcon": "var(--color-checks-btn-icon, #f0f3f6)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #f0f3f6)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(158,167,179,0.1))",
					"inputText": "var(--color-checks-input-text, #f0f3f6)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #9ea7b3)",
					"inputFocusText": "var(--color-checks-input-focus-text, #f0f3f6)",
					"inputBg": "var(--color-checks-input-bg, #272b33)",
					"donutError": "var(--color-checks-donut-error, #ff6a69)",
					"donutPending": "var(--color-checks-donut-pending, #f0b72f)",
					"donutSuccess": "var(--color-checks-donut-success, #09b43a)",
					"donutNeutral": "var(--color-checks-donut-neutral, #bdc4cc)",
					"dropdownText": "var(--color-checks-dropdown-text, #f0f3f6)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #272b33)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #7a828e)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(1,4,9,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #f0f3f6)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, rgba(158,167,179,0.1))",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #f0f3f6)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, rgba(158,167,179,0.1))",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, rgba(158,167,179,0.4))",
					"headerLabelText": "var(--color-checks-header-label-text, #f0f3f6)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #f0f3f6)",
					"headerBorder": "var(--color-checks-header-border, #7a828e)",
					"headerIcon": "var(--color-checks-header-icon, #f0f3f6)",
					"lineText": "var(--color-checks-line-text, #f0f3f6)",
					"lineNumText": "var(--color-checks-line-num-text, #9ea7b3)",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #9ea7b3)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, rgba(158,167,179,0.1))",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(64,158,255,0.1))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #71b7ff)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #0a0c10)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #e09b13)",
					"gateBg": "var(--color-checks-gate-bg, rgba(224,155,19,0.15))",
					"gateText": "var(--color-checks-gate-text, #f0f3f6)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #f0b72f)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #272b33)",
					"stepErrorText": "var(--color-checks-step-error-text, #ff6a69)",
					"stepWarningText": "var(--color-checks-step-warning-text, #f0b72f)",
					"loglineText": "var(--color-checks-logline-text, #f0f3f6)",
					"loglineNumText": "var(--color-checks-logline-num-text, #9ea7b3)",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #b780ff)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #f0f3f6)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #9ea7b3)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(255,106,105,0.1))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #f0f3f6)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #f0b72f)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(224,155,19,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #71b7ff)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #26cd4d)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #0a0c10)",
						"blackBright": "var(--color-checks-ansi-black-bright, #272b33)",
						"white": "var(--color-checks-ansi-white, #d9dee3))",
						"whiteBright": "var(--color-checks-ansi-white-bright, #d9dee3)",
						"gray": "var(--color-checks-ansi-gray, #9ea7b3)",
						"red": "var(--color-checks-ansi-red, #ff9492)",
						"redBright": "var(--color-checks-ansi-red-bright, #ffb1af)",
						"green": "var(--color-checks-ansi-green, #26cd4d)",
						"greenBright": "var(--color-checks-ansi-green-bright, #4ae168)",
						"yellow": "var(--color-checks-ansi-yellow, #f0b72f)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #f7c843)",
						"blue": "var(--color-checks-ansi-blue, #71b7ff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #91cbff)",
						"magenta": "var(--color-checks-ansi-magenta, #cb9eff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #dbb7ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #0a0c10)",
					"sidebarBg": "var(--color-project-sidebar-bg, #272b33)",
					"gradientIn": "var(--color-project-gradient-in, #272b33)",
					"gradientOut": "var(--color-project-gradient-out, rgba(39,43,51,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #f6f8fa))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #9ea7b3))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, rgba(255,255,255,0.1)))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(255,255,255,0.9)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #525964))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #272b33))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, #409eff))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, #7a828e))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(82,89,100,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #1e60d5))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(39,43,51,0.4)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #272b33))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #bdc4cc))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #ffffff))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #0a0c10))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #525964))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #272b33))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, #272b33))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(158,167,179,0)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #272b33))" },
				"ansi": {
					"black": "var(--color-ansi-black, #7a828e)",
					"blackBright": "var(--color-ansi-black-bright, #9ea7b3)",
					"white": "var(--color-ansi-white, #d9dee3)",
					"whiteBright": "var(--color-ansi-white-bright, #ffffff)",
					"gray": "var(--color-ansi-gray, #9ea7b3)",
					"red": "var(--color-ansi-red, #ff9492)",
					"redBright": "var(--color-ansi-red-bright, #ffb1af)",
					"green": "var(--color-ansi-green, #26cd4d)",
					"greenBright": "var(--color-ansi-green-bright, #4ae168)",
					"yellow": "var(--color-ansi-yellow, #f0b72f)",
					"yellowBright": "var(--color-ansi-yellow-bright, #f7c843)",
					"blue": "var(--color-ansi-blue, #71b7ff)",
					"blueBright": "var(--color-ansi-blue-bright, #91cbff)",
					"magenta": "var(--color-ansi-magenta, #cb9eff)",
					"magentaBright": "var(--color-ansi-magenta-bright, #dbb7ff)",
					"cyan": "var(--color-ansi-cyan, #39c5cf)",
					"cyanBright": "var(--color-ansi-cyan-bright, #56d4dd)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #f0f3f6))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #272b33))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, #7a828e))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #525964))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, #bdc4cc))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(217,10%,33%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, #9ea7b3))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, rgba(82,89,100,0.9)))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, #525964))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #0a0c10))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #09b43a))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, #4ae168))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #26cd4d))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, #4ae168))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, #09b43a))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(10,12,16,0.5)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, rgba(9,180,58,0.6)))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(74,225,104,0.4)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, #0a0c10))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(1,4,9,0.15)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #409eff))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #71b7ff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #525964))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, #7a828e))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(25,79,177,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, #2672f3))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, #7a828e))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(113,183,255,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #0a0c10))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(64,158,255,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, rgba(25,79,177,0.2)))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #71b7ff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(113,183,255,0.5)))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #409eff))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #ff6a69))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #0a0c10))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #ff6a69))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, #ff6a69))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #0a0c10))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(1,4,9,0.15)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, #ff4445))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, #ff9492))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(255,106,105,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #0a0c10))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(255,106,105,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(1,4,9,0.15)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #ff6a69))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #ff6a69))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(255,106,105,0.5)))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #272b33))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #bdc4cc))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #f0f3f6))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, #bdc4cc))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, #7a828e))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, #272b33))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, #7a828e))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, #525964))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, #9ea7b3))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, #525964))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-danger-hover-bg, #ff6a69))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-danger-active-bg, #ff4445))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-danger-hover-text, #0a0c10))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, #9ea7b3))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(214,12%,61%,1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, hsla(214,12%,58%,1)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #272b33))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #0a0c10))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #010409))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, #409eff))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, rgba(64,158,255,0.5)))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, rgba(64,158,255,0.65)))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #0a0c10))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #010409))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #0a0c10))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #9ea7b3))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #272b33))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #0a0c10))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #272b33))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, #409eff))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, rgba(158,167,179,0.1)))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #0a0c10))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, #525964))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-active-bg, #272b33))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-selected-border, #9ea7b3))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, #525964))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-directory-fill, #f0f3f6))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #f0f3f6))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #f0f3f6))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #9ea7b3))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #0a0c10))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #0a0c10))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #272b33))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #010409))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #272b33))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #7a828e))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, #7a828e))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, #7a828e))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #ffffff))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #9ea7b3))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(158,167,179,0.4)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(158,167,179,0.1)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #71b7ff))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #409eff))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, #409eff))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, rgba(64,158,255,0.1)))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #26cd4d))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #09b43a))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, #09b43a))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, rgba(9,180,58,0.15)))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #f0b72f))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #e09b13))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, #e09b13))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, rgba(224,155,19,0.15)))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #e7811d))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #e7811d))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, #e7811d))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, rgba(231,129,29,0.1)))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #ff6a69))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #ff6a69))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, #ff6a69))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, rgba(255,106,105,0.1)))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #26cd4d))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #09b43a))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(9,180,58,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, rgba(9,180,58,0.15)))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #ff6a69))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #ff6a69))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(255,106,105,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, rgba(255,106,105,0.15)))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #b780ff))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #b87fff))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, #b780ff))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, rgba(183,128,255,0.1)))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #ef6eb1))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #ef6eb1))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, #ef6eb1))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, rgba(239,110,177,0.1)))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #7a828e))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-canvas-backdrop, rgba(1,4,9,0.8)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(10,12,16,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #ff967d))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(255,255,255,0.2)))"
					}
				}
			},
			"shadows": {
				"checks": { "inputShadow": "var(--color-checks-input-shadow, 0 0 0 1px #7a828e)" },
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(255 255 255 / 25%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(255 255 255 / 25%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(255 255 255) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px #0a0c10))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 0 0 1px #525964, 0 16px 32px rgba(1,4,9,0.85)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 0 transparent))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, 0 0 transparent))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 0 transparent))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, 0 0 transparent))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(1,4,9,0.1)))// HI_KATIE: no matches",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))// HI_KATIE: no matches",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, 0 0 transparent))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 0 transparent))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, 0 0 transparent))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 0 transparent))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px #010409))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px #010409))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 48px #010409))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, 0 0 transparent))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, 0 0 transparent))"
				} }
			}
		},
		"dark_colorblind": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(13,17,23,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #0d1117))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #79c0ff)",
					"secondary": "var(--color-marketing-icon-secondary, #1f6feb)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #c9d1d9))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #c9d1d9))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(88,166,255,0.3)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(56,139,253,0.15)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, rgba(56,139,253,0.4)))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #c9d1d9))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #c9d1d9))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(212,118,22,0.3)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(212,118,22,0.1)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(212,118,22,0.4)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(56,139,253,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #8b949e))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, screen)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(240,246,252,0.1))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(240,246,252,0.1))",
					"additionBg": "var(--diffStat-addition-bgColor, var(--color-diffstat-addition-bg, #58a6ff))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, rgba(210,153,34,0.4)))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #8b949e)",
					"constant": "var(--color-prettylights-syntax-constant, #79c0ff)",
					"entity": "var(--color-prettylights-syntax-entity, #d2a8ff)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #c9d1d9)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #a5d6ff)",
					"keyword": "var(--color-prettylights-syntax-keyword, #ec8e2c)",
					"string": "var(--color-prettylights-syntax-string, #a5d6ff)",
					"variable": "var(--color-prettylights-syntax-variable, #fdac54)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #d47616)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #f0f6fc)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #6c3906)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #f0f6fc)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #914d04)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #a5d6ff)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #f2cc60)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #1f6feb)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #c9d1d9)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #c9d1d9)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #ffe2bb)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #4e2906)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #cae8ff)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #0c2d6b)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #ffe2bb)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #4e2906)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #c9d1d9)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #1158c7)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #d2a8ff)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #8b949e)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #484f58)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #a5d6ff)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #c9d1d9))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #0d1117))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #0d1117))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #0d1117))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #6e7681))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #8b949e))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #c9d1d9))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(56,139,253,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(110,118,129,0.1)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #c9d1d9))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #0d1117))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #8b949e))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #79c0ff))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #d2a8ff))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #ec8e2c))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #ec8e2c))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #a5d6ff))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #79c0ff))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #fdac54))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #010409)",
					"runBorderWidth": "var(--color-checks-run-border-width, 1px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 1px)",
					"textPrimary": "var(--color-checks-text-primary, #c9d1d9)",
					"textSecondary": "var(--color-checks-text-secondary, #8b949e)",
					"textLink": "var(--color-checks-text-link, #58a6ff)",
					"btnIcon": "var(--color-checks-btn-icon, #8b949e)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #c9d1d9)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(110,118,129,0.1))",
					"inputText": "var(--color-checks-input-text, #8b949e)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #6e7681)",
					"inputFocusText": "var(--color-checks-input-focus-text, #c9d1d9)",
					"inputBg": "var(--color-checks-input-bg, #161b22)",
					"donutError": "var(--color-checks-donut-error, #d47616)",
					"donutPending": "var(--color-checks-donut-pending, #d29922)",
					"donutSuccess": "var(--color-checks-donut-success, #388bfd)",
					"donutNeutral": "var(--color-checks-donut-neutral, #8b949e)",
					"dropdownText": "var(--color-checks-dropdown-text, #c9d1d9)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #161b22)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #30363d)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(1,4,9,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #c9d1d9)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, rgba(110,118,129,0.1))",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #c9d1d9)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, rgba(110,118,129,0.1))",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, rgba(110,118,129,0.4))",
					"headerLabelText": "var(--color-checks-header-label-text, #8b949e)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #c9d1d9)",
					"headerBorder": "var(--color-checks-header-border, #21262d)",
					"headerIcon": "var(--color-checks-header-icon, #8b949e)",
					"lineText": "var(--color-checks-line-text, #8b949e)",
					"lineNumText": "var(--color-checks-line-num-text, #6e7681)",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #6e7681)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, rgba(110,118,129,0.1))",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(56,139,253,0.1))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #58a6ff)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #ffffff)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #9e6a03)",
					"gateBg": "var(--color-checks-gate-bg, rgba(187,128,9,0.15))",
					"gateText": "var(--color-checks-gate-text, #8b949e)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #d29922)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #161b22)",
					"stepErrorText": "var(--color-checks-step-error-text, #d47616)",
					"stepWarningText": "var(--color-checks-step-warning-text, #d29922)",
					"loglineText": "var(--color-checks-logline-text, #8b949e)",
					"loglineNumText": "var(--color-checks-logline-num-text, #6e7681)",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #a371f7)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #8b949e)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #6e7681)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(212,118,22,0.1))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #8b949e)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #d29922)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(187,128,9,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #58a6ff)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #58a6ff)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #0d1117)",
						"blackBright": "var(--color-checks-ansi-black-bright, #161b22)",
						"white": "var(--color-checks-ansi-white, #b1bac4))",
						"whiteBright": "var(--color-checks-ansi-white-bright, #b1bac4)",
						"gray": "var(--color-checks-ansi-gray, #6e7681)",
						"red": "var(--color-checks-ansi-red, #ec8e2c)",
						"redBright": "var(--color-checks-ansi-red-bright, #fdac54)",
						"green": "var(--color-checks-ansi-green, #58a6ff)",
						"greenBright": "var(--color-checks-ansi-green-bright, #79c0ff)",
						"yellow": "var(--color-checks-ansi-yellow, #d29922)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #e3b341)",
						"blue": "var(--color-checks-ansi-blue, #58a6ff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #79c0ff)",
						"magenta": "var(--color-checks-ansi-magenta, #bc8cff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #d2a8ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #0d1117)",
					"sidebarBg": "var(--color-project-sidebar-bg, #161b22)",
					"gradientIn": "var(--color-project-gradient-in, #161b22)",
					"gradientOut": "var(--color-project-gradient-out, rgba(22,27,34,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #f6f8fa))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #606771))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, rgba(255,255,255,0.1)))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(240,246,252,0.1)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #30363d))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #21262d))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, #484f58))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(48,54,61,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #0c2d6b))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(22,27,34,0.4)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #161b22))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #8b949e))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #f0f6fc))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #0d1117))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #30363d))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #21262d))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, #161b22))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(110,118,129,0)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #21262d))" },
				"ansi": {
					"black": "var(--color-ansi-black, #484f58)",
					"blackBright": "var(--color-ansi-black-bright, #6e7681)",
					"white": "var(--color-ansi-white, #b1bac4)",
					"whiteBright": "var(--color-ansi-white-bright, #ffffff)",
					"gray": "var(--color-ansi-gray, #6e7681)",
					"red": "var(--color-ansi-red, #ec8e2c)",
					"redBright": "var(--color-ansi-red-bright, #fdac54)",
					"green": "var(--color-ansi-green, #58a6ff)",
					"greenBright": "var(--color-ansi-green-bright, #79c0ff)",
					"yellow": "var(--color-ansi-yellow, #d29922)",
					"yellowBright": "var(--color-ansi-yellow-bright, #e3b341)",
					"blue": "var(--color-ansi-blue, #58a6ff)",
					"blueBright": "var(--color-ansi-blue-bright, #79c0ff)",
					"magenta": "var(--color-ansi-magenta, #bc8cff)",
					"magentaBright": "var(--color-ansi-magenta-bright, #d2a8ff)",
					"cyan": "var(--color-ansi-cyan, #39c5cf)",
					"cyanBright": "var(--color-ansi-cyan-bright, #56d4dd)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #c9d1d9))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #21262d))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(240,246,252,0.1)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #30363d))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, #8b949e))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(212,12%,18%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, #6e7681))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, #161b22))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, #30363d))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #1f6feb))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(240,246,252,0.1)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #388bfd))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(240,246,252,0.1)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, #1f6feb))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.5)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, rgba(31,111,235,0.6)))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(240,246,252,0.1)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, #ffffff))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(5,29,77,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #388bfd))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #58a6ff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #30363d))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(240,246,252,0.1)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(5,29,77,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, #0d419d))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(240,246,252,0.1)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(88,166,255,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #0d1117))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(31,111,235,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, rgba(5,29,77,0.2)))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #58a6ff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(88,166,255,0.5)))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #388bfd))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #d47616))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #b76100))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, #d47616))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, #914d04))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, #ec8e2c))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(212,118,22,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #0d1117))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(183,97,0,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(51,28,4,0.2)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #d47616))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #d47616))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(212,118,22,0.5)))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #21262d))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #8b949e))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #6e7681))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(110,118,129,0.4)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(48,54,61,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(177,186,196,0.12)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(177,186,196,0.2)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(177,186,196,0.08)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-danger-hover-bg, rgba(212,118,22,0.16)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-danger-active-bg, rgba(212,118,22,0.24)))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-danger-hover-text, #ec8e2c))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, rgba(110,118,129,0.1)))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(215,8%,72%,0.1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, rgba(110,118,129,0.4)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #21262d))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #8b949e))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #010409))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, rgba(31,111,235,0.35)))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, rgba(31,111,235,0.5)))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, rgba(31,111,235,0.65)))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #010409))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #0d1117))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #606771))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #161b22))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #0d1117))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #161b22))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, rgba(31,111,235,0.35)))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, rgba(110,118,129,0.1)))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #0d1117))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, #30363d))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-active-bg, #21262d))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-selected-border, #6e7681))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(177,186,196,0.12)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-directory-fill, #8b949e))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #c9d1d9))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #8b949e))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #6e7681))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #0d1117))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #161b22))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #010409))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #161b22))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #30363d))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, #21262d))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(240,246,252,0.1)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #6e7681))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #6e7681))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(110,118,129,0.4)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(110,118,129,0.1)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #58a6ff))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #1f6feb))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(56,139,253,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, rgba(56,139,253,0.1)))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #58a6ff))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #1f6feb))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(56,139,253,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, rgba(56,139,253,0.15)))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #d29922))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #9e6a03))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(187,128,9,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, rgba(187,128,9,0.15)))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #d47616))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #b76100))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(212,118,22,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, rgba(212,118,22,0.1)))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #d47616))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #b76100))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(212,118,22,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, rgba(212,118,22,0.1)))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #ec8e2c))",
					"emphasis": "var(--borderColor-open-emphasis, var(--color-open-emphasis, #b76100))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(212,118,22,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, rgba(212,118,22,0.15)))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-open-fg, #8b949e))",
					"emphasis": "var(--borderColor-closed-emphasis, var(--color-closed-emphasis, #6e7681))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(110,118,129,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, rgba(110,118,129,0.1)))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #a371f7))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8957e5))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(163,113,247,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, rgba(163,113,247,0.1)))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #db61a2))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #bf4b8a))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(219,97,162,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, rgba(219,97,162,0.1)))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #484f58))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-canvas-backdrop, rgba(1,4,9,0.8)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(13,17,23,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #f78166))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(255,255,255,0.2)))"
					}
				}
			},
			"shadows": {
				"checks": { "inputShadow": "var(--color-checks-input-shadow, 0 0 0 1px #30363d)" },
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(255 255 255 / 25%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(255 255 255 / 25%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(255 255 255) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px #0d1117))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 0 0 1px #30363d, 0 16px 32px rgba(1,4,9,0.85)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 0 transparent))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, 0 0 transparent))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 0 transparent))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, 0 0 transparent))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(1,4,9,0.1)))// HI_KATIE: no matches",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))// HI_KATIE: no matches",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, 0 0 transparent))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 0 transparent))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, 0 0 transparent))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 0 transparent))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px #010409))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px #010409))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 48px #010409))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, 0 0 transparent))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, 0 0 transparent))"
				} }
			}
		},
		"dark_tritanopia": {
			"colors": {
				"canvasDefaultTransparent": "var(--bgColor-transparent, var(--color-canvas-default-transparent, rgba(13,17,23,0)))",
				"pageHeaderBg": "var(--page-header-bgColor, var(--color-page-header-bg, #0d1117))",
				"marketingIcon": {
					"primary": "var(--color-marketing-icon-primary, #79c0ff)",
					"secondary": "var(--color-marketing-icon-secondary, #1f6feb)"
				},
				"diffBlob": {
					"addition": {
						"numText": "var(--diffBlob-addition-fgColor-num, var(--color-diff-blob-addition-num-text, #c9d1d9))",
						"fg": "var(--diffBlob-addition-fgColor-text, var(--color-diff-blob-addition-fg, #c9d1d9))",
						"numBg": "var(--diffBlob-addition-bgColor-num, var(--color-diff-blob-addition-num-bg, rgba(88,166,255,0.3)))",
						"lineBg": "var(--diffBlob-addition-bgColor-line, var(--color-diff-blob-addition-line-bg, rgba(56,139,253,0.15)))",
						"wordBg": "var(--diffBlob-addition-bgColor-word, var(--color-diff-blob-addition-word-bg, rgba(56,139,253,0.4)))"
					},
					"deletion": {
						"numText": "var(--diffBlob-deletion-fgColor-num, var(--color-diff-blob-deletion-num-text, #c9d1d9))",
						"fg": "var(--diffBlob-deletion-fgColor-text, var(--color-diff-blob-deletion-fg, #c9d1d9))",
						"numBg": "var(--diffBlob-deletion-bgColor-num, var(--color-diff-blob-deletion-num-bg, rgba(248,81,73,0.3)))",
						"lineBg": "var(--diffBlob-deletion-bgColor-line, var(--color-diff-blob-deletion-line-bg, rgba(248,81,73,0.1)))",
						"wordBg": "var(--diffBlob-deletion-bgColor-word, var(--color-diff-blob-deletion-word-bg, rgba(248,81,73,0.4)))"
					},
					"hunk": { "numBg": "var(--diffBlob-hunk-bgColor-num, var(--color-diff-blob-hunk-num-bg, rgba(56,139,253,0.4)))" },
					"expander": { "icon": "var(--diffBlob-expander-iconColor, var(--color-diff-blob-expander-icon, #8b949e))" },
					"selectedLineHighlightMixBlendMode": "var(--color-diff-blob-selected-line-highlight-mix-blend-mode, screen)"
				},
				"diffstat": {
					"deletionBorder": "var(--color-diffstat-deletion-border, rgba(240,246,252,0.1))",
					"additionBorder": "var(--color-diffstat-addition-border, rgba(240,246,252,0.1))",
					"additionBg": "var(--diffStat-addition-bgColor, var(--color-diffstat-addition-bg, #58a6ff))"
				},
				"searchKeyword": { "hl": "var(--highlight-neutral-bgColor, var(--color-search-keyword-hl, rgba(210,153,34,0.4)))" },
				"prettylights": { "syntax": {
					"comment": "var(--color-prettylights-syntax-comment, #8b949e)",
					"constant": "var(--color-prettylights-syntax-constant, #79c0ff)",
					"entity": "var(--color-prettylights-syntax-entity, #d2a8ff)",
					"storageModifierImport": "var(--color-prettylights-syntax-storage-modifier-import, #c9d1d9)",
					"entityTag": "var(--color-prettylights-syntax-entity-tag, #a5d6ff)",
					"keyword": "var(--color-prettylights-syntax-keyword, #ff7b72)",
					"string": "var(--color-prettylights-syntax-string, #a5d6ff)",
					"variable": "var(--color-prettylights-syntax-variable, #ffa198)",
					"brackethighlighterUnmatched": "var(--color-prettylights-syntax-brackethighlighter-unmatched, #f85149)",
					"invalidIllegalText": "var(--color-prettylights-syntax-invalid-illegal-text, #f0f6fc)",
					"invalidIllegalBg": "var(--color-prettylights-syntax-invalid-illegal-bg, #8e1519)",
					"carriageReturnText": "var(--color-prettylights-syntax-carriage-return-text, #f0f6fc)",
					"carriageReturnBg": "var(--color-prettylights-syntax-carriage-return-bg, #b62324)",
					"stringRegexp": "var(--color-prettylights-syntax-string-regexp, #a5d6ff)",
					"markupList": "var(--color-prettylights-syntax-markup-list, #f2cc60)",
					"markupHeading": "var(--color-prettylights-syntax-markup-heading, #1f6feb)",
					"markupItalic": "var(--color-prettylights-syntax-markup-italic, #c9d1d9)",
					"markupBold": "var(--color-prettylights-syntax-markup-bold, #c9d1d9)",
					"markupDeletedText": "var(--color-prettylights-syntax-markup-deleted-text, #ffdcd7)",
					"markupDeletedBg": "var(--color-prettylights-syntax-markup-deleted-bg, #67060c)",
					"markupInsertedText": "var(--color-prettylights-syntax-markup-inserted-text, #cae8ff)",
					"markupInsertedBg": "var(--color-prettylights-syntax-markup-inserted-bg, #0c2d6b)",
					"markupChangedText": "var(--color-prettylights-syntax-markup-changed-text, #ffdcd7)",
					"markupChangedBg": "var(--color-prettylights-syntax-markup-changed-bg, #67060c)",
					"markupIgnoredText": "var(--color-prettylights-syntax-markup-ignored-text, #c9d1d9)",
					"markupIgnoredBg": "var(--color-prettylights-syntax-markup-ignored-bg, #1158c7)",
					"metaDiffRange": "var(--color-prettylights-syntax-meta-diff-range, #d2a8ff)",
					"brackethighlighterAngle": "var(--color-prettylights-syntax-brackethighlighter-angle, #8b949e)",
					"sublimelinterGutterMark": "var(--color-prettylights-syntax-sublimelinter-gutter-mark, #484f58)",
					"constantOtherReferenceLink": "var(--color-prettylights-syntax-constant-other-reference-link, #a5d6ff)"
				} },
				"codemirror": {
					"text": "var(--codeMirror-fgColor, var(--color-codemirror-text, #c9d1d9))",
					"bg": "var(--codeMirror-bgColor, var(--color-codemirror-bg, #0d1117))",
					"guttersBg": "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg, #0d1117))",
					"guttermarkerText": "var(--codeMirror-gutterMarker-fgColor-default, var(--color-codemirror-guttermarker-text, #0d1117))",
					"guttermarkerSubtleText": "var(--codeMirror-gutterMarker-fgColor-muted, var(--color-codemirror-guttermarker-subtle-text, #6e7681))",
					"linenumberText": "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text, #8b949e))",
					"cursor": "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor, #c9d1d9))",
					"selectionBg": "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, rgba(56,139,253,0.4)))",
					"activelineBg": "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg, rgba(110,118,129,0.1)))",
					"matchingbracketText": "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text, #c9d1d9))",
					"linesBg": "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg, #0d1117))",
					"syntax": {
						"comment": "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment, #8b949e))",
						"constant": "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant, #79c0ff))",
						"entity": "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity, #d2a8ff))",
						"keyword": "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword, #ff7b72))",
						"storage": "var(--codeMirror-syntax-fgColor-storage, var(--color-codemirror-syntax-storage, #ff7b72))",
						"string": "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string, #a5d6ff))",
						"support": "var(--codeMirror-syntax-fgColor-support, var(--color-codemirror-syntax-support, #79c0ff))",
						"variable": "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable, #ffa198))"
					}
				},
				"checks": {
					"bg": "var(--color-checks-bg, #010409)",
					"runBorderWidth": "var(--color-checks-run-border-width, 1px)",
					"containerBorderWidth": "var(--color-checks-container-border-width, 1px)",
					"textPrimary": "var(--color-checks-text-primary, #c9d1d9)",
					"textSecondary": "var(--color-checks-text-secondary, #8b949e)",
					"textLink": "var(--color-checks-text-link, #58a6ff)",
					"btnIcon": "var(--color-checks-btn-icon, #8b949e)",
					"btnHoverIcon": "var(--color-checks-btn-hover-icon, #c9d1d9)",
					"btnHoverBg": "var(--color-checks-btn-hover-bg, rgba(110,118,129,0.1))",
					"inputText": "var(--color-checks-input-text, #8b949e)",
					"inputPlaceholderText": "var(--color-checks-input-placeholder-text, #6e7681)",
					"inputFocusText": "var(--color-checks-input-focus-text, #c9d1d9)",
					"inputBg": "var(--color-checks-input-bg, #161b22)",
					"donutError": "var(--color-checks-donut-error, #f85149)",
					"donutPending": "var(--color-checks-donut-pending, #d29922)",
					"donutSuccess": "var(--color-checks-donut-success, #388bfd)",
					"donutNeutral": "var(--color-checks-donut-neutral, #8b949e)",
					"dropdownText": "var(--color-checks-dropdown-text, #c9d1d9)",
					"dropdownBg": "var(--color-checks-dropdown-bg, #161b22)",
					"dropdownBorder": "var(--color-checks-dropdown-border, #30363d)",
					"dropdownShadow": "var(--color-checks-dropdown-shadow, rgba(1,4,9,0.3))",
					"dropdownHoverText": "var(--color-checks-dropdown-hover-text, #c9d1d9)",
					"dropdownHoverBg": "var(--color-checks-dropdown-hover-bg, rgba(110,118,129,0.1))",
					"dropdownBtnHoverText": "var(--color-checks-dropdown-btn-hover-text, #c9d1d9)",
					"dropdownBtnHoverBg": "var(--color-checks-dropdown-btn-hover-bg, rgba(110,118,129,0.1))",
					"scrollbarThumbBg": "var(--color-checks-scrollbar-thumb-bg, rgba(110,118,129,0.4))",
					"headerLabelText": "var(--color-checks-header-label-text, #8b949e)",
					"headerLabelOpenText": "var(--color-checks-header-label-open-text, #c9d1d9)",
					"headerBorder": "var(--color-checks-header-border, #21262d)",
					"headerIcon": "var(--color-checks-header-icon, #8b949e)",
					"lineText": "var(--color-checks-line-text, #8b949e)",
					"lineNumText": "var(--color-checks-line-num-text, #6e7681)",
					"lineTimestampText": "var(--color-checks-line-timestamp-text, #6e7681)",
					"lineHoverBg": "var(--color-checks-line-hover-bg, rgba(110,118,129,0.1))",
					"lineSelectedBg": "var(--color-checks-line-selected-bg, rgba(56,139,253,0.1))",
					"lineSelectedNumText": "var(--color-checks-line-selected-num-text, #58a6ff)",
					"lineDtFmText": "var(--color-checks-line-dt-fm-text, #ffffff)",
					"lineDtFmBg": "var(--color-checks-line-dt-fm-bg, #9e6a03)",
					"gateBg": "var(--color-checks-gate-bg, rgba(187,128,9,0.15))",
					"gateText": "var(--color-checks-gate-text, #8b949e)",
					"gateWaitingText": "var(--color-checks-gate-waiting-text, #d29922)",
					"stepHeaderOpenBg": "var(--color-checks-step-header-open-bg, #161b22)",
					"stepErrorText": "var(--color-checks-step-error-text, #f85149)",
					"stepWarningText": "var(--color-checks-step-warning-text, #d29922)",
					"loglineText": "var(--color-checks-logline-text, #8b949e)",
					"loglineNumText": "var(--color-checks-logline-num-text, #6e7681)",
					"loglineDebugText": "var(--color-checks-logline-debug-text, #a371f7)",
					"loglineErrorText": "var(--color-checks-logline-error-text, #8b949e)",
					"loglineErrorNumText": "var(--color-checks-logline-error-num-text, #6e7681)",
					"loglineErrorBg": "var(--color-checks-logline-error-bg, rgba(248,81,73,0.1))",
					"loglineWarningText": "var(--color-checks-logline-warning-text, #8b949e)",
					"loglineWarningNumText": "var(--color-checks-logline-warning-num-text, #d29922)",
					"loglineWarningBg": "var(--color-checks-logline-warning-bg, rgba(187,128,9,0.15))",
					"loglineCommandText": "var(--color-checks-logline-command-text, #58a6ff)",
					"loglineSectionText": "var(--color-checks-logline-section-text, #58a6ff)",
					"ansi": {
						"black": "var(--color-checks-ansi-black, #0d1117)",
						"blackBright": "var(--color-checks-ansi-black-bright, #161b22)",
						"white": "var(--color-checks-ansi-white, #b1bac4))",
						"whiteBright": "var(--color-checks-ansi-white-bright, #b1bac4)",
						"gray": "var(--color-checks-ansi-gray, #6e7681)",
						"red": "var(--color-checks-ansi-red, #ff7b72)",
						"redBright": "var(--color-checks-ansi-red-bright, #ffa198)",
						"green": "var(--color-checks-ansi-green, #58a6ff)",
						"greenBright": "var(--color-checks-ansi-green-bright, #79c0ff)",
						"yellow": "var(--color-checks-ansi-yellow, #d29922)",
						"yellowBright": "var(--color-checks-ansi-yellow-bright, #e3b341)",
						"blue": "var(--color-checks-ansi-blue, #58a6ff)",
						"blueBright": "var(--color-checks-ansi-blue-bright, #79c0ff)",
						"magenta": "var(--color-checks-ansi-magenta, #bc8cff)",
						"magentaBright": "var(--color-checks-ansi-magenta-bright, #d2a8ff)",
						"cyan": "var(--color-checks-ansi-cyan, #76e3ea)",
						"cyanBright": "var(--color-checks-ansi-cyan-bright, #b3f0ff)"
					}
				},
				"project": {
					"headerBg": "var(--color-project-header-bg, #0d1117)",
					"sidebarBg": "var(--color-project-sidebar-bg, #161b22)",
					"gradientIn": "var(--color-project-gradient-in, #161b22)",
					"gradientOut": "var(--color-project-gradient-out, rgba(22,27,34,0))"
				},
				"mktg": { "btn": { "bg": "var(--color-mktg-btn-bg, #f6f8fa))" } },
				"control": { "borderColor": { "emphasis": "var(--control-borderColor-emphasis, var(--color-control-border-color-emphasis, #606771))" } },
				"avatar": {
					"bg": "var(--avatar-bgColor, var(--color-avatar-bg, rgba(255,255,255,0.1)))",
					"border": "var(--avatar-borderColor, var(--color-avatar-border, rgba(240,246,252,0.1)))",
					"stackFade": "var(--avatarStack-fade-bgColor-default, var(--color-avatar-stack-fade, #30363d))",
					"stackFadeMore": "var(--avatarStack-fade-bgColor-muted, var(--color-avatar-stack-fade-more, #21262d))"
				},
				"topicTag": { "border": "var(--topicTag-borderColor, var(--color-topic-tag-border, transparent))" },
				"counter": { "border": "var(--counter-borderColor, var(--color-counter-border, transparent))" },
				"selectMenu": {
					"backdropBorder": "var(--selectMenu-borderColor, var(--color-select-menu-backdrop-border, #484f58))",
					"tapHighlight": "var(--control-bgColor-active, var(--color-select-menu-tap-highlight, rgba(48,54,61,0.5)))",
					"tapFocusBg": "var(--selectMenu-bgColor-active, var(--color-select-menu-tap-focus-bg, #0c2d6b))"
				},
				"overlay": { "backdrop": "var(--overlay-backdrop-bgColor, var(--color-overlay-backdrop, rgba(22,27,34,0.4)))" },
				"header": {
					"text": "var(--header-fgColor-default, var(--color-header-text, rgba(255,255,255,0.7)))",
					"bg": "var(--header-bgColor, var(--color-header-bg, #161b22))",
					"divider": "var(--header-borderColor-divider, var(--color-header-divider, #8b949e))",
					"logo": "var(--header-fgColor-logo, var(--color-header-logo, #f0f6fc))"
				},
				"headerSearch": {
					"bg": "var(--headerSearch-bgColor, var(--color-header-search-bg, #0d1117))",
					"border": "var(--headerSearch-borderColor, var(--color-header-search-border, #30363d))"
				},
				"sidenav": { "selectedBg": "var(--sideNav-bgColor-selected, var(--color-sidenav-selected-bg, #21262d))" },
				"menu": { "bgActive": "var(--menu-bgColor-active, var(--color-menu-bg-active, #161b22))" },
				"input": { "disabledBg": "var(--control-bgColor-disabled, var(--color-input-disabled-bg, rgba(110,118,129,0)))" },
				"timeline": { "badgeBg": "var(--timelineBadge-bgColor, var(--color-timeline-badge-bg, #21262d))" },
				"ansi": {
					"black": "var(--color-ansi-black, #484f58)",
					"blackBright": "var(--color-ansi-black-bright, #6e7681)",
					"white": "var(--color-ansi-white, #b1bac4)",
					"whiteBright": "var(--color-ansi-white-bright, #ffffff)",
					"gray": "var(--color-ansi-gray, #6e7681)",
					"red": "var(--color-ansi-red, #ff7b72)",
					"redBright": "var(--color-ansi-red-bright, #ffa198)",
					"green": "var(--color-ansi-green, #58a6ff)",
					"greenBright": "var(--color-ansi-green-bright, #79c0ff)",
					"yellow": "var(--color-ansi-yellow, #d29922)",
					"yellowBright": "var(--color-ansi-yellow-bright, #e3b341)",
					"blue": "var(--color-ansi-blue, #58a6ff)",
					"blueBright": "var(--color-ansi-blue-bright, #79c0ff)",
					"magenta": "var(--color-ansi-magenta, #bc8cff)",
					"magentaBright": "var(--color-ansi-magenta-bright, #d2a8ff)",
					"cyan": "var(--color-ansi-cyan, #39c5cf)",
					"cyanBright": "var(--color-ansi-cyan-bright, #56d4dd)"
				},
				"btn": {
					"text": "var(--button-default-fgColor-rest, var(--color-btn-text, #c9d1d9))",
					"bg": "var(--button-default-bgColor-rest, var(--color-btn-bg, #21262d))",
					"border": "var(--button-default-borderColor-rest, var(--color-btn-border, rgba(240,246,252,0.1)))",
					"hoverBg": "var(--button-default-bgColor-hover, var(--color-btn-hover-bg, #30363d))",
					"hoverBorder": "var(--button-default-borderColor-hover, var(--color-btn-hover-border, #8b949e))",
					"activeBg": "var(--button-default-bgColor-active, var(--color-btn-active-bg, hsla(212,12%,18%,1)))",
					"activeBorder": "var(--button-default-borderColor-active, var(--color-btn-active-border, #6e7681))",
					"selectedBg": "var(--button-default-bgColor-selected, var(--color-btn-selected-bg, #161b22))",
					"counterBg": "var(--buttonCounter-default-bgColor-rest, var(--color-btn-counter-bg, #30363d))",
					"primary": {
						"text": "var(--button-primary-fgColor-rest, var(--color-btn-primary-text, #ffffff))",
						"bg": "var(--button-primary-bgColor-rest, var(--color-btn-primary-bg, #1f6feb))",
						"border": "var(--button-primary-borderColor-rest, var(--color-btn-primary-border, rgba(240,246,252,0.1)))",
						"hoverBg": "var(--button-primary-bgColor-hover, var(--color-btn-primary-hover-bg, #388bfd))",
						"hoverBorder": "var(--button-primary-borderColor-hover, var(--color-btn-primary-hover-border, rgba(240,246,252,0.1)))",
						"selectedBg": "var(--button-primary-bgColor-active, var(--color-btn-primary-selected-bg, #1f6feb))",
						"disabledText": "var(--button-primary-fgColor-disabled, var(--color-btn-primary-disabled-text, rgba(255,255,255,0.5)))",
						"disabledBg": "var(--button-primary-bgColor-disabled, var(--color-btn-primary-disabled-bg, rgba(31,111,235,0.6)))",
						"disabledBorder": "var(--button-primary-borderColor-disabled, var(--color-btn-primary-disabled-border, rgba(240,246,252,0.1)))",
						"icon": "var(--button-primary-iconColor-rest, var(--color-btn-primary-icon, #ffffff))",
						"counterBg": "var(--buttonCounter-primary-bgColor-rest, var(--color-btn-primary-counter-bg, rgba(5,29,77,0.2)))"
					},
					"outline": {
						"text": "var(--button-outline-fgColor-rest, var(--color-btn-outline-text, #388bfd))",
						"hoverText": "var(--button-outline-fgColor-hover, var(--color-btn-outline-hover-text, #58a6ff))",
						"hoverBg": "var(--button-outline-bgColor-hover, var(--color-btn-outline-hover-bg, #30363d))",
						"hoverBorder": "var(--button-outline-borderColor-hover, var(--color-btn-outline-hover-border, rgba(240,246,252,0.1)))",
						"hoverCounterBg": "var(--buttonCounter-outline-bgColor-hover, var(--color-btn-outline-hover-counter-bg, rgba(5,29,77,0.2)))",
						"selectedText": "var(--button-outline-fgColor-active, var(--color-btn-outline-selected-text, #ffffff))",
						"selectedBg": "var(--button-outline-bgColor-active, var(--color-btn-outline-selected-bg, #0d419d))",
						"selectedBorder": "var(--button-outline-borderColor-active, var(--color-btn-outline-selected-border, rgba(240,246,252,0.1)))",
						"disabledText": "var(--button-outline-fgColor-disabled, var(--color-btn-outline-disabled-text, rgba(88,166,255,0.5)))",
						"disabledBg": "var(--button-outline-bgColor-disabled, var(--color-btn-outline-disabled-bg, #0d1117))",
						"disabledCounterBg": "var(--buttonCounter-outline-bgColor-disabled, var(--color-btn-outline-disabled-counter-bg, rgba(31,111,235,0.05)))",
						"counterBg": "var(--buttonCounter-outline-bgColor-rest, var(--color-btn-outline-counter-bg, rgba(5,29,77,0.2)))",
						"hoverCounterFg": "var(--buttonCounter-outline-fgColor-hover, var(--color-btn-outline-hover-counter-fg, #58a6ff))",
						"disabledCounterFg": "var(--buttonCounter-outline-fgColor-disabled, var(--color-btn-outline-disabled-counter-fg, rgba(88,166,255,0.5)))",
						"counterFg": "var(--buttonCounter-outline-fgColor-rest, var(--color-btn-outline-counter-fg, #388bfd))"
					},
					"danger": {
						"text": "var(--button-danger-fgColor-rest, var(--color-btn-danger-text, #f85149))",
						"hoverText": "var(--button-danger-fgColor-hover, var(--color-btn-danger-hover-text, #ffffff))",
						"hoverBg": "var(--button-danger-bgColor-hover, var(--color-btn-danger-hover-bg, #da3633))",
						"hoverBorder": "var(--button-danger-borderColor-hover, var(--color-btn-danger-hover-border, #f85149))",
						"hoverIcon": "var(--button-danger-iconColor-hover, var(--color-btn-danger-hover-icon, #ffffff))",
						"hoverCounterBg": "var(--buttonCounter-danger-bgColor-hover, var(--color-btn-danger-hover-counter-bg, rgba(255,255,255,0.2)))",
						"selectedText": "var(--button-danger-fgColor-active, var(--color-btn-danger-selected-text, #ffffff))",
						"selectedBg": "var(--button-danger-bgColor-active, var(--color-btn-danger-selected-bg, #b62324))",
						"selectedBorder": "var(--button-danger-borderColor-active, var(--color-btn-danger-selected-border, #ff7b72))",
						"disabledText": "var(--button-danger-fgColor-disabled, var(--color-btn-danger-disabled-text, rgba(248,81,73,0.5)))",
						"disabledBg": "var(--button-danger-bgColor-disabled, var(--color-btn-danger-disabled-bg, #0d1117))",
						"disabledCounterBg": "var(--buttonCounter-danger-bgColor-disabled, var(--color-btn-danger-disabled-counter-bg, rgba(218,54,51,0.05)))",
						"counterBg": "var(--buttonCounter-danger-bgColor-rest, var(--color-btn-danger-counter-bg, rgba(73,2,2,0.2)))",
						"icon": "var(--button-danger-iconColor-rest, var(--color-btn-danger-icon, #f85149))",
						"counterFg": "var(--buttonCounter-danger-fgColor-rest, var(--color-btn-danger-counter-fg, #f85149))",
						"disabledCounterFg": "var(--buttonCounter-danger-fgColor-disabled, var(--color-btn-danger-disabled-counter-fg, rgba(248,81,73,0.5)))",
						"hoverCounterFg": "var(--buttonCounter-danger-fgColor-hover, var(--color-btn-danger-hover-counter-fg, #ffffff))"
					},
					"inactive": {
						"bg": "var(--button-inactive-bgColor-rest, var(--color-btn-inactive-bg, #21262d))",
						"text": "var(--button-inactive-fgColor-rest, var(--color-btn-inactive-text, #8b949e))"
					}
				},
				"underlinenav": {
					"icon": "var(--underlineNav-iconColor-rest, var(--color-underlinenav-icon, #6e7681))",
					"borderHover": "var(--underlineNav-borderColor-hover, var(--color-underlinenav-border-hover, rgba(110,118,129,0.4)))"
				},
				"actionListItem": {
					"inlineDivider": "var(--borderColor-muted, var(--color-action-list-item-inline-divider, rgba(48,54,61,0.48)))",
					"default": {
						"hoverBg": "var(--control-transparent-bgColor-hover, var(--color-action-list-item-default-hover-bg, rgba(177,186,196,0.12)))",
						"hoverBorder": "var(--control-transparent-borderColor-hover, var(--color-action-list-item-default-hover-border, transparent))",
						"activeBg": "var(--control-transparent-bgColor-active, var(--color-action-list-item-default-active-bg, rgba(177,186,196,0.2)))",
						"activeBorder": "var(--control-transparent-borderColor-active, var(--color-action-list-item-default-active-border, transparent))",
						"selectedBg": "var(--control-transparent-bgColor-selected, var(--color-action-list-item-default-selected-bg, rgba(177,186,196,0.08)))"
					},
					"danger": {
						"hoverBg": "var(--control-danger-bgColor-hover, var(--color-action-list-item-danger-hover-bg, rgba(248,81,73,0.16)))",
						"activeBg": "var(--control-danger-bgColor-active, var(--color-action-list-item-danger-active-bg, rgba(248,81,73,0.24)))",
						"hoverText": "var(--control-danger-fgColor-hover, var(--color-action-list-item-danger-hover-text, #ff7b72))"
					}
				},
				"switchTrack": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-switch-track-bg, rgba(110,118,129,0.1)))",
					"hoverBg": "var(--controlTrack-bgColor-hover, var(--color-switch-track-hover-bg, hsla(215,8%,72%,0.1)))",
					"activeBg": "var(--controlTrack-bgColor-active, var(--color-switch-track-active-bg, rgba(110,118,129,0.4)))",
					"disabledBg": "var(--controlTrack-bgColor-disabled, var(--color-switch-track-disabled-bg, #21262d))",
					"fg": "var(--controlTrack-fgColor-rest, var(--color-switch-track-fg, #8b949e))",
					"disabledFg": "var(--controlTrack-fgColor-disabled, var(--color-switch-track-disabled-fg, #010409))",
					"border": "var(--controlTrack-borderColor-rest, var(--color-switch-track-border, transparent))",
					"checked": {
						"bg": "var(--control-checked-bgColor-rest, var(--color-switch-track-checked-bg, rgba(31,111,235,0.35)))",
						"hoverBg": "var(--control-checked-bgColor-hover, var(--color-switch-track-checked-hover-bg, rgba(31,111,235,0.5)))",
						"activeBg": "var(--control-checked-bgColor-active, var(--color-switch-track-checked-active-bg, rgba(31,111,235,0.65)))",
						"fg": "var(--control-checked-fgColor-rest, var(--color-switch-track-checked-fg, #ffffff))",
						"disabledFg": "var(--control-checked-fgColor-disabled, var(--color-switch-track-checked-disabled-fg, #010409))",
						"border": "var(--borderColor-transparent, var(--color-switch-track-checked-border, transparent))"
					}
				},
				"switchKnob": {
					"bg": "var(--controlKnob-bgColor-rest, var(--color-switch-knob-bg, #0d1117))",
					"border": "var(--controlKnob-borderColor-rest, var(--color-switch-knob-border, #606771))",
					"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-disabled-bg, #161b22))",
					"checked": {
						"bg": "var(--controlKnob-bgColor-checked, var(--color-switch-knob-checked-bg, #0d1117))",
						"disabledBg": "var(--controlKnob-bgColor-disabled, var(--color-switch-knob-checked-disabled-bg, #161b22))",
						"border": "var(--controlKnob-borderColor-checked, var(--color-switch-knob-checked-border, rgba(31,111,235,0.35)))"
					}
				},
				"segmentedControl": {
					"bg": "var(--controlTrack-bgColor-rest, var(--color-segmented-control-bg, rgba(110,118,129,0.1)))",
					"button": {
						"bg": "var(--controlKnob-bgColor-rest, var(--color-segmented-control-button-bg, #0d1117))",
						"hover": { "bg": "var(--controlTrack-bgColor-hover, var(--color-segmented-control-button-hover-bg, #30363d))" },
						"active": { "bg": "var(--controlTrack-bgColor-active, var(--color-segmented-control-button-active-bg, #21262d))" },
						"selected": { "border": "var(--controlKnob-borderColor-rest, var(--color-segmented-control-button-selected-border, #6e7681))" }
					}
				},
				"treeViewItem": {
					"chevron": { "hoverBg": "var(--control-transparent-bgColor-hover, var(--color-tree-view-item-chevron-hover-bg, rgba(177,186,196,0.12)))" },
					"directory": { "fill": "var(--treeViewItem-leadingVisual-iconColor-rest, var(--color-tree-view-item-directory-fill, #8b949e))" }
				},
				"fg": {
					"default": "var(--fgColor-default, var(--color-fg-default, #c9d1d9))",
					"muted": "var(--fgColor-muted, var(--color-fg-muted, #8b949e))",
					"subtle": "var(--fgColor-muted, var(--color-fg-subtle, #6e7681))",
					"onEmphasis": "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis, #ffffff))"
				},
				"canvas": {
					"default": "var(--bgColor-default, var(--color-canvas-default, #0d1117))",
					"overlay": "var(--overlay-bgColor, var(--color-canvas-overlay, #161b22))",
					"inset": "var(--bgColor-inset, var(--color-canvas-inset, #010409))",
					"subtle": "var(--bgColor-muted, var(--color-canvas-subtle, #161b22))"
				},
				"border": {
					"default": "var(--borderColor-default, var(--color-border-default, #30363d))",
					"muted": "var(--borderColor-muted, var(--color-border-muted, #21262d))",
					"subtle": "var(--borderColor-muted, var(--color-border-subtle, rgba(240,246,252,0.1)))"
				},
				"neutral": {
					"emphasisPlus": "var(--bgColor-emphasis, var(--color-neutral-emphasis-plus, #6e7681))",
					"emphasis": "var(--bgColor-neutral-emphasis, var(--color-neutral-emphasis, #6e7681))",
					"muted": "var(--bgColor-neutral-muted, var(--color-neutral-muted, rgba(110,118,129,0.4)))",
					"subtle": "var(--bgColor-neutral-muted, var(--color-neutral-subtle, rgba(110,118,129,0.1)))"
				},
				"accent": {
					"fg": "var(--fgColor-accent, var(--color-accent-fg, #58a6ff))",
					"emphasis": "var(--bgColor-accent-emphasis, var(--color-accent-emphasis, #1f6feb))",
					"muted": "var(--borderColor-accent-muted, var(--color-accent-muted, rgba(56,139,253,0.4)))",
					"subtle": "var(--bgColor-accent-muted, var(--color-accent-subtle, rgba(56,139,253,0.1)))"
				},
				"success": {
					"fg": "var(--fgColor-success, var(--color-success-fg, #58a6ff))",
					"emphasis": "var(--bgColor-success-emphasis, var(--color-success-emphasis, #1f6feb))",
					"muted": "var(--borderColor-success-muted, var(--color-success-muted, rgba(56,139,253,0.4)))",
					"subtle": "var(--bgColor-success-muted, var(--color-success-subtle, rgba(56,139,253,0.15)))"
				},
				"attention": {
					"fg": "var(--fgColor-attention, var(--color-attention-fg, #d29922))",
					"emphasis": "var(--bgColor-attention-emphasis, var(--color-attention-emphasis, #9e6a03))",
					"muted": "var(--borderColor-attention-muted, var(--color-attention-muted, rgba(187,128,9,0.4)))",
					"subtle": "var(--bgColor-attention-muted, var(--color-attention-subtle, rgba(187,128,9,0.15)))"
				},
				"severe": {
					"fg": "var(--fgColor-severe, var(--color-severe-fg, #f85149))",
					"emphasis": "var(--bgColor-severe-emphasis, var(--color-severe-emphasis, #da3633))",
					"muted": "var(--borderColor-severe-muted, var(--color-severe-muted, rgba(248,81,73,0.4)))",
					"subtle": "var(--bgColor-severe-muted, var(--color-severe-subtle, rgba(248,81,73,0.1)))"
				},
				"danger": {
					"fg": "var(--fgColor-danger, var(--color-danger-fg, #f85149))",
					"emphasis": "var(--borderColor-danger-emphasis, var(--color-danger-emphasis, #da3633))",
					"muted": "var(--borderColor-danger-muted, var(--color-danger-muted, rgba(248,81,73,0.4)))",
					"subtle": "var(--bgColor-danger-muted, var(--color-danger-subtle, rgba(248,81,73,0.1)))"
				},
				"open": {
					"fg": "var(--fgColor-open, var(--color-open-fg, #ff7b72))",
					"emphasis": "var(--bgColor-open-emphasis, var(--color-open-emphasis, #da3633))",
					"muted": "var(--borderColor-open-muted, var(--color-open-muted, rgba(248,81,73,0.4)))",
					"subtle": "var(--bgColor-open-muted, var(--color-open-subtle, rgba(248,81,73,0.15)))"
				},
				"closed": {
					"fg": "var(--fgColor-closed, var(--color-closed-fg, #8b949e))",
					"emphasis": "var(--bgColor-closed-emphasis, var(--color-closed-emphasis, #6e7681))",
					"muted": "var(--borderColor-closed-muted, var(--color-closed-muted, rgba(110,118,129,0.4)))",
					"subtle": "var(--bgColor-closed-muted, var(--color-closed-subtle, rgba(110,118,129,0.1)))"
				},
				"done": {
					"fg": "var(--fgColor-done, var(--color-done-fg, #a371f7))",
					"emphasis": "var(--bgColor-done-emphasis, var(--color-done-emphasis, #8957e5))",
					"muted": "var(--borderColor-done-muted, var(--color-done-muted, rgba(163,113,247,0.4)))",
					"subtle": "var(--bgColor-done-muted, var(--color-done-subtle, rgba(163,113,247,0.1)))"
				},
				"sponsors": {
					"fg": "var(--fgColor-sponsors, var(--color-sponsors-fg, #db61a2))",
					"emphasis": "var(--bgColor-sponsors-emphasis, var(--color-sponsors-emphasis, #bf4b8a))",
					"muted": "var(--borderColor-sponsors-muted, var(--color-sponsors-muted, rgba(219,97,162,0.4)))",
					"subtle": "var(--bgColor-sponsors-muted, var(--color-sponsors-subtle, rgba(219,97,162,0.1)))"
				},
				"primer": {
					"fg": { "disabled": "var(--fgColor-disabled, var(--color-primer-fg-disabled, #484f58))" },
					"canvas": {
						"backdrop": "var(--overlay-backdrop-bgColor, var(--color-primer-canvas-backdrop, rgba(1,4,9,0.8)))",
						"sticky": "var(--color-primer-canvas-sticky, rgba(13,17,23,0.95))"
					},
					"border": {
						"active": "var(--underlineNav-borderColor-active, var(--color-primer-border-active, #f78166))",
						"contrast": "var(--borderColor-muted, var(--color-primer-border-contrast, rgba(255,255,255,0.2)))"
					}
				}
			},
			"shadows": {
				"checks": { "inputShadow": "var(--color-checks-input-shadow, 0 0 0 1px #30363d)" },
				"mktg": { "btn": { "shadow": {
					"outline": "var(--color-mktg-btn-shadow-outline, rgb(255 255 255 / 25%) 0 0 0 1px inset))",
					"focus": "var(--color-mktg-btn-shadow-focus, rgb(255 255 255 / 25%) 0 0 0 4px))",
					"hover": "var(--color-mktg-btn-shadow-hover, 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07)))",
					"hoverMuted": "var(--color-mktg-btn-shadow-hover-muted, rgb(255 255 255) 0 0 0 2px inset))"
				} } },
				"avatar": { "childShadow": "var(--avatar-shadow, var(--color-avatar-child-shadow, 0 0 0 2px #0d1117))" },
				"overlay": { "shadow": "var(--shadow-floating-small, var(--color-overlay-shadow, 0 0 0 1px #30363d, 0 16px 32px rgba(1,4,9,0.85)))" },
				"btn": {
					"shadow": "var(--button-default-shadow-resting, var(--color-btn-shadow, 0 0 transparent))",
					"insetShadow": "var(--button-default-shadow-inset, var(--color-btn-inset-shadow, 0 0 transparent))",
					"primary": {
						"shadow": "var(--shadow-resting-small, var(--color-btn-primary-shadow, 0 0 transparent))",
						"insetShadow": "var(--shadow-highlight, var(--color-btn-primary-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-primary-shadow-selected, var(--color-btn-primary-selected-shadow, 0 0 transparent))"
					},
					"outline": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-outline-hover-shadow, 0 1px 0 rgba(1,4,9,0.1)))// HI_KATIE: no matches",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-outline-hover-inset-shadow, inset 0 1px 0 rgba(255,255,255,0.03)))// HI_KATIE: no matches",
						"selectedShadow": "var(--button-outline-shadow-selected, var(--color-btn-outline-selected-shadow, 0 0 transparent))"
					},
					"danger": {
						"hoverShadow": "var(--shadow-resting-small, var(--color-btn-danger-hover-shadow, 0 0 transparent))",
						"hoverInsetShadow": "var(--shadow-highlight, var(--color-btn-danger-hover-inset-shadow, 0 0 transparent))",
						"selectedShadow": "var(--button-danger-shadow-selected, var(--color-btn-danger-selected-shadow, 0 0 transparent))"
					}
				},
				"shadow": {
					"small": "var(--shadow-resting-small, var(--color-shadow-small, 0 0 transparent))",
					"medium": "var(--shadow-resting-medium, var(--color-shadow-medium, 0 3px 6px #010409))",
					"large": "var(--shadow-floating-large, var(--color-shadow-large, 0 8px 24px #010409))",
					"extraLarge": "var(--shadow-floating-xlarge, var(--color-shadow-extra-large, 0 12px 48px #010409))"
				},
				"primer": { "shadow": {
					"highlight": "var(--shadow-highlight, var(--color-primer-shadow-highlight, 0 0 transparent))",
					"inset": "var(--shadow-inset, var(--color-primer-shadow-inset, 0 0 transparent))"
				} }
			}
		}
	}
};
/**
* When the value that initialized the state changes
* this hook will update the state to the new value, immediately.
*
* This uses an Object.is comparison to determine if the value has changed by default
*
* If you use a non-primitive value as the initial value, you should provide a custom isEqual function
*
* This is adapted almost directly from https://beta.reactjs.org/learn/you-might-not-need-an-effect#adjusting-some-state-when-a-prop-changes
*/
var useSyncedState = (initialValue, t0) => {
	const $ = c(2);
	const { isPropUpdateDisabled: t1, isEqual: t2 } = t0 === void 0 ? {} : t0;
	const isPropUpdateDisabled = t1 === void 0 ? false : t1;
	const isEqual = t2 === void 0 ? Object.is : t2;
	const [state, setState] = useState(initialValue);
	const [previous, setPrevious] = useState(initialValue);
	const nextInitialValue = initialValue instanceof Function ? initialValue() : initialValue;
	if (!isPropUpdateDisabled && !isEqual(previous, nextInitialValue)) {
		setPrevious(nextInitialValue);
		setState(nextInitialValue);
	}
	let t3;
	if ($[0] !== state) {
		t3 = [state, setState];
		$[0] = state;
		$[1] = t3;
	} else t3 = $[1];
	return t3;
};
var classes$2 = {
	"Header": "prc-Header-Header-zcBYI",
	"HeaderItem": "prc-Header-HeaderItem-BPQgk",
	"HeaderLink": "prc-Header-HeaderLink-NpVNI"
};
var Header$1 = /* @__PURE__ */ React.forwardRef(function Header(t0, forwardRef) {
	const $ = c(13);
	let children;
	let className;
	let rest;
	let t1;
	if ($[0] !== t0) {
		({as: t1, children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
		$[4] = t1;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
		t1 = $[4];
	}
	const BaseComponent = t1 === void 0 ? "header" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = clsx(className, classes$2.Header);
		$[5] = className;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== BaseComponent || $[8] !== children || $[9] !== forwardRef || $[10] !== rest || $[11] !== t2) {
		t3 = /* @__PURE__ */ jsx(BaseComponent, {
			ref: forwardRef,
			className: t2,
			...rest,
			children
		});
		$[7] = BaseComponent;
		$[8] = children;
		$[9] = forwardRef;
		$[10] = rest;
		$[11] = t2;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
});
Header$1.displayName = "Header";
var HeaderItem$1 = /* @__PURE__ */ React.forwardRef(function HeaderItem(t0, forwardRef) {
	const $ = c(13);
	let children;
	let className;
	let full;
	let rest;
	if ($[0] !== t0) {
		({children, className, full, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = full;
		$[4] = rest;
	} else {
		children = $[1];
		className = $[2];
		full = $[3];
		rest = $[4];
	}
	let t1;
	if ($[5] !== className) {
		t1 = clsx(className, classes$2.HeaderItem);
		$[5] = className;
		$[6] = t1;
	} else t1 = $[6];
	let t2;
	if ($[7] !== children || $[8] !== forwardRef || $[9] !== full || $[10] !== rest || $[11] !== t1) {
		t2 = /* @__PURE__ */ jsx("div", {
			ref: forwardRef,
			className: t1,
			"data-full": full,
			...rest,
			children
		});
		$[7] = children;
		$[8] = forwardRef;
		$[9] = full;
		$[10] = rest;
		$[11] = t1;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
});
HeaderItem$1.displayName = "Header.Item";
var HeaderLink$1 = /* @__PURE__ */ React.forwardRef(function HeaderLink(t0, forwardRef) {
	const $ = c(13);
	let children;
	let className;
	let rest;
	let t1;
	if ($[0] !== t0) {
		({children, className, as: t1, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
		$[4] = t1;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
		t1 = $[4];
	}
	const BaseComponent = t1 === void 0 ? "a" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = clsx(className, classes$2.HeaderLink);
		$[5] = className;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== BaseComponent || $[8] !== children || $[9] !== forwardRef || $[10] !== rest || $[11] !== t2) {
		t3 = /* @__PURE__ */ jsx(BaseComponent, {
			ref: forwardRef,
			className: t2,
			...rest,
			children
		});
		$[7] = BaseComponent;
		$[8] = children;
		$[9] = forwardRef;
		$[10] = rest;
		$[11] = t2;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
});
HeaderLink$1.displayName = "Header.Link";
var Header_default = Object.assign(Header$1, {
	Link: HeaderLink$1,
	Item: HeaderItem$1
});
function areAllValuesTheSame(responsiveValue) {
	if ("narrow" in responsiveValue && "regular" in responsiveValue && "wide" in responsiveValue) {
		const values = Object.values(responsiveValue);
		return values.every((value) => value === values[0]);
	}
	return false;
}
function haveRegularAndWideSameValue(responsiveValue) {
	if ("regular" in responsiveValue && "wide" in responsiveValue) return responsiveValue.regular === responsiveValue.wide;
	return false;
}
var classes$1 = {
	"PageHeader": "prc-PageHeader-PageHeader-YLwBQ",
	"ContextArea": "prc-PageHeader-ContextArea-ueeWv",
	"ParentLink": "prc-PageHeader-ParentLink-AJ9VB",
	"ContextBar": "prc-PageHeader-ContextBar-8AoJ5",
	"ContextAreaActions": "prc-PageHeader-ContextAreaActions-DLQP5",
	"TitleArea": "prc-PageHeader-TitleArea-2n2J0",
	"LeadingAction": "prc-PageHeader-LeadingAction-4NMe9",
	"Breadcrumbs": "prc-PageHeader-Breadcrumbs-FGVQU",
	"LeadingVisual": "prc-PageHeader-LeadingVisual-njece",
	"Title": "prc-PageHeader-Title-p0Mgh",
	"TrailingVisual": "prc-PageHeader-TrailingVisual-Zb96K",
	"TrailingAction": "prc-PageHeader-TrailingAction-xqlZJ",
	"Actions": "prc-PageHeader-Actions-wawWm",
	"Description": "prc-PageHeader-Description-w-ejP",
	"Navigation": "prc-PageHeader-Navigation--uLav"
};
var hiddenOnRegularAndWide = {
	narrow: false,
	regular: true,
	wide: true
};
var hiddenOnNarrow = {
	narrow: true,
	regular: false,
	wide: false
};
var Root = /* @__PURE__ */ React.forwardRef((t0, forwardedRef) => {
	const $ = c(14);
	const { children, className, as: t1, "aria-label": ariaLabel, role, hasBorder } = t0;
	const BaseComponent = t1 === void 0 ? "div" : t1;
	const rootRef = useProvidedRefOrCreate(forwardedRef);
	let t2;
	let t3;
	if ($[0] !== children || $[1] !== rootRef) {
		t2 = function validateInteractiveElementsInTitle() {};
		t3 = [children, rootRef];
		$[0] = children;
		$[1] = rootRef;
		$[2] = t2;
		$[3] = t3;
	} else {
		t2 = $[2];
		t3 = $[3];
	}
	useEffect(t2, t3);
	let t4;
	if ($[4] !== className) {
		t4 = clsx(classes$1.PageHeader, className);
		$[4] = className;
		$[5] = t4;
	} else t4 = $[5];
	const t5 = hasBorder ? "true" : void 0;
	let t6;
	if ($[6] !== BaseComponent || $[7] !== ariaLabel || $[8] !== children || $[9] !== role || $[10] !== rootRef || $[11] !== t4 || $[12] !== t5) {
		t6 = /* @__PURE__ */ jsx(BaseComponent, {
			ref: rootRef,
			className: t4,
			"data-has-border": t5,
			"aria-label": ariaLabel,
			role,
			children
		});
		$[6] = BaseComponent;
		$[7] = ariaLabel;
		$[8] = children;
		$[9] = role;
		$[10] = rootRef;
		$[11] = t4;
		$[12] = t5;
		$[13] = t6;
	} else t6 = $[13];
	return t6;
});
var ContextArea = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? hiddenOnRegularAndWide : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.ContextArea, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
ContextArea.__SLOT__ = Symbol("PageHeader.ContextArea");
var ParentLink = /* @__PURE__ */ React.forwardRef((t0, ref) => {
	const $ = c(15);
	const { children, className, href, "aria-label": ariaLabel, as: t1, hidden: t2 } = t0;
	const as = t1 === void 0 ? "a" : t1;
	const hidden = t2 === void 0 ? hiddenOnRegularAndWide : t2;
	let t3;
	if ($[0] !== className) {
		t3 = clsx(classes$1.ParentLink, className);
		$[0] = className;
		$[1] = t3;
	} else t3 = $[1];
	let t4;
	if ($[2] !== hidden) {
		t4 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t4;
	} else t4 = $[3];
	let t5;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = /* @__PURE__ */ jsx(ArrowLeftIcon, {});
		$[4] = t5;
	} else t5 = $[4];
	let t6;
	if ($[5] !== children) {
		t6 = /* @__PURE__ */ jsx("div", { children });
		$[5] = children;
		$[6] = t6;
	} else t6 = $[6];
	let t7;
	if ($[7] !== ariaLabel || $[8] !== as || $[9] !== href || $[10] !== ref || $[11] !== t3 || $[12] !== t4 || $[13] !== t6) {
		t7 = /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs(Link$1, {
			ref,
			as,
			"aria-label": ariaLabel,
			muted: true,
			className: t3,
			...t4,
			href,
			children: [t5, t6]
		}) });
		$[7] = ariaLabel;
		$[8] = as;
		$[9] = href;
		$[10] = ref;
		$[11] = t3;
		$[12] = t4;
		$[13] = t6;
		$[14] = t7;
	} else t7 = $[14];
	return t7;
});
ParentLink.displayName = "ParentLink";
var ContextBar = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? hiddenOnRegularAndWide : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.ContextBar, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var ContextAreaActions = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? hiddenOnRegularAndWide : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.ContextAreaActions, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var TitleArea = /* @__PURE__ */ React.forwardRef((t0, forwardedRef) => {
	const $ = c(12);
	const { children, className, hidden: t1, variant: t2 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	const variant = t2 === void 0 ? "medium" : t2;
	const titleAreaRef = useProvidedRefOrCreate(forwardedRef);
	let t3;
	if ($[0] !== className) {
		t3 = clsx(classes$1.TitleArea, className);
		$[0] = className;
		$[1] = t3;
	} else t3 = $[1];
	let t4;
	if ($[2] !== variant) {
		t4 = getResponsiveAttributes("size-variant", variant);
		$[2] = variant;
		$[3] = t4;
	} else t4 = $[3];
	let t5;
	if ($[4] !== hidden) {
		t5 = getHiddenDataAttributes(hidden);
		$[4] = hidden;
		$[5] = t5;
	} else t5 = $[5];
	let t6;
	if ($[6] !== children || $[7] !== t3 || $[8] !== t4 || $[9] !== t5 || $[10] !== titleAreaRef) {
		t6 = /* @__PURE__ */ jsx("div", {
			className: t3,
			ref: titleAreaRef,
			"data-component": "TitleArea",
			...t4,
			...t5,
			children
		});
		$[6] = children;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
		$[10] = titleAreaRef;
		$[11] = t6;
	} else t6 = $[11];
	return t6;
});
TitleArea.displayName = "TitleArea";
var LeadingAction = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? hiddenOnNarrow : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.LeadingAction, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			"data-component": "PH_LeadingAction",
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
LeadingAction.__SLOT__ = Symbol("PageHeader.LeadingAction");
var Breadcrumbs$1 = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.Breadcrumbs, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			"data-component": "PH_Breadcrumbs",
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var LeadingVisual = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.LeadingVisual, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			"data-component": "PH_LeadingVisual",
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var Title = (t0) => {
	const $ = c(10);
	const { children, className, hidden: t1, as: t2 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	const as = t2 === void 0 ? "h2" : t2;
	let t3;
	if ($[0] !== className) {
		t3 = clsx(classes$1.Title, className);
		$[0] = className;
		$[1] = t3;
	} else t3 = $[1];
	let t4;
	if ($[2] !== hidden) {
		t4 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t4;
	} else t4 = $[3];
	let t5;
	if ($[4] !== as || $[5] !== children || $[6] !== hidden || $[7] !== t3 || $[8] !== t4) {
		t5 = /* @__PURE__ */ jsx(Heading$2, {
			className: t3,
			"data-component": "PH_Title",
			"data-hidden": hidden,
			as,
			...t4,
			children
		});
		$[4] = as;
		$[5] = children;
		$[6] = hidden;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
	} else t5 = $[9];
	return t5;
};
var TrailingVisual = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.TrailingVisual, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			"data-component": "PH_TrailingVisual",
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var TrailingAction = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? hiddenOnNarrow : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.TrailingAction, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			"data-component": "PH_TrailingAction",
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var Actions = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.Actions, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			"data-component": "PH_Actions",
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var Description = (t0) => {
	const $ = c(8);
	const { children, className, hidden: t1 } = t0;
	const hidden = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(classes$1.Description, className);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hidden) {
		t3 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== children || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t2,
			...t3,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
var Navigation = (t0) => {
	const $ = c(11);
	const { children, className, hidden: t1, as: t2, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy } = t0;
	const hidden = t1 === void 0 ? false : t1;
	const BaseComponent = t2 === void 0 ? "div" : t2;
	const t3 = BaseComponent === "nav" ? ariaLabel : void 0;
	const t4 = BaseComponent === "nav" ? ariaLabelledBy : void 0;
	let t5;
	if ($[0] !== className) {
		t5 = clsx(classes$1.Navigation, className);
		$[0] = className;
		$[1] = t5;
	} else t5 = $[1];
	let t6;
	if ($[2] !== hidden) {
		t6 = getHiddenDataAttributes(hidden);
		$[2] = hidden;
		$[3] = t6;
	} else t6 = $[3];
	let t7;
	if ($[4] !== BaseComponent || $[5] !== children || $[6] !== t3 || $[7] !== t4 || $[8] !== t5 || $[9] !== t6) {
		t7 = /* @__PURE__ */ jsx(BaseComponent, {
			"aria-label": t3,
			"aria-labelledby": t4,
			className: t5,
			"data-component": "PH_Navigation",
			...t6,
			children
		});
		$[4] = BaseComponent;
		$[5] = children;
		$[6] = t3;
		$[7] = t4;
		$[8] = t5;
		$[9] = t6;
		$[10] = t7;
	} else t7 = $[10];
	return t7;
};
function getHiddenDataAttributes(isHidden) {
	if (isResponsiveValue(isHidden)) {
		const responsiveValue = isHidden;
		const narrowMediaQuery = "narrow" in responsiveValue ? { "data-hidden-narrow": responsiveValue.narrow || void 0 } : {};
		const regularMediaQuery = "regular" in responsiveValue ? { "data-hidden-regular": responsiveValue.regular || void 0 } : {};
		const wideMediaQuery = "wide" in responsiveValue ? { "data-hidden-wide": responsiveValue.wide || void 0 } : {};
		if (areAllValuesTheSame(responsiveValue)) return { "data-hidden-all": responsiveValue.narrow || void 0 };
		else if (haveRegularAndWideSameValue(responsiveValue)) return {
			...narrowMediaQuery,
			...regularMediaQuery
		};
		else return {
			...narrowMediaQuery,
			...regularMediaQuery,
			...wideMediaQuery
		};
	} else return { "data-hidden-all": isHidden || void 0 };
}
var PageHeader$1 = Object.assign(Root, {
	ContextArea,
	ParentLink,
	ContextBar,
	TitleArea,
	ContextAreaActions,
	LeadingAction,
	Breadcrumbs: Breadcrumbs$1,
	LeadingVisual,
	Title,
	TrailingVisual,
	TrailingAction,
	Actions,
	Description,
	Navigation
});
PageHeader$1.displayName = "PageHeader";
var classes = {
	"Timeline": "prc-Timeline-Timeline-awSoC",
	"TimelineItem": "prc-Timeline-TimelineItem-QwDVH",
	"TimelineBadge": "prc-Timeline-TimelineBadge-u0qSm",
	"TimelineBadgeWrapper": "prc-Timeline-TimelineBadgeWrapper-SZw4k",
	"TimelineBody": "prc-Timeline-TimelineBody-tjOtb",
	"TimelineBreak": "prc-Timeline-TimelineBreak-X8eti"
};
var Timeline$1 = /* @__PURE__ */ React.forwardRef((t0, forwardRef) => {
	const $ = c(11);
	let className;
	let clipSidebar;
	let props;
	if ($[0] !== t0) {
		({clipSidebar, className, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = clipSidebar;
		$[3] = props;
	} else {
		className = $[1];
		clipSidebar = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx(className, classes.Timeline);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	const t2 = clipSidebar ? "" : void 0;
	let t3;
	if ($[6] !== forwardRef || $[7] !== props || $[8] !== t1 || $[9] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			...props,
			className: t1,
			ref: forwardRef,
			"data-clip-sidebar": t2
		});
		$[6] = forwardRef;
		$[7] = props;
		$[8] = t1;
		$[9] = t2;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
});
Timeline$1.displayName = "Timeline";
/**
* @deprecated Use the `TimelineItemProps` type instead
*/
var TimelineItem$1 = /* @__PURE__ */ React.forwardRef((t0, forwardRef) => {
	const $ = c(11);
	let className;
	let condensed;
	let props;
	if ($[0] !== t0) {
		({condensed, className, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = condensed;
		$[3] = props;
	} else {
		className = $[1];
		condensed = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx(className, "Timeline-Item", classes.TimelineItem);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	const t2 = condensed ? "" : void 0;
	let t3;
	if ($[6] !== forwardRef || $[7] !== props || $[8] !== t1 || $[9] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			...props,
			className: t1,
			ref: forwardRef,
			"data-condensed": t2
		});
		$[6] = forwardRef;
		$[7] = props;
		$[8] = t1;
		$[9] = t2;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
});
TimelineItem$1.displayName = "TimelineItem";
var TimelineBadge$1 = (t0) => {
	const $ = c(8);
	let className;
	let props;
	if ($[0] !== t0) {
		({className, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = props;
	} else {
		className = $[1];
		props = $[2];
	}
	let t1;
	if ($[3] !== className) {
		t1 = clsx(className, classes.TimelineBadge);
		$[3] = className;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== props || $[6] !== t1) {
		t2 = /* @__PURE__ */ jsx("div", {
			className: classes.TimelineBadgeWrapper,
			children: /* @__PURE__ */ jsx("div", {
				...props,
				className: t1
			})
		});
		$[5] = props;
		$[6] = t1;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
};
TimelineBadge$1.displayName = "Timeline.Badge";
var TimelineBody$1 = /* @__PURE__ */ React.forwardRef((t0, forwardRef) => {
	const $ = c(9);
	let className;
	let props;
	if ($[0] !== t0) {
		({className, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = props;
	} else {
		className = $[1];
		props = $[2];
	}
	let t1;
	if ($[3] !== className) {
		t1 = clsx(className, classes.TimelineBody);
		$[3] = className;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== forwardRef || $[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ jsx("div", {
			...props,
			className: t1,
			ref: forwardRef
		});
		$[5] = forwardRef;
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
});
TimelineBody$1.displayName = "TimelineBody";
var TimelineBreak$1 = /* @__PURE__ */ React.forwardRef((t0, forwardRef) => {
	const $ = c(9);
	let className;
	let props;
	if ($[0] !== t0) {
		({className, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = props;
	} else {
		className = $[1];
		props = $[2];
	}
	let t1;
	if ($[3] !== className) {
		t1 = clsx(className, classes.TimelineBreak);
		$[3] = className;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== forwardRef || $[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ jsx("div", {
			...props,
			className: t1,
			ref: forwardRef
		});
		$[5] = forwardRef;
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
});
TimelineBreak$1.displayName = "TimelineBreak";
var Timeline_default = Object.assign(Timeline$1, {
	Item: TimelineItem$1,
	Badge: TimelineBadge$1,
	Body: TimelineBody$1,
	Break: TimelineBreak$1
});
function m() {
	return (m = Object.assign || function(e) {
		for (var t = 1; t < arguments.length; t++) {
			var n = arguments[t];
			for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
		}
		return e;
	}).apply(this, arguments);
}
var y = function(e, t) {
	for (var n = [e[0]], r = 0, o = t.length; r < o; r += 1) n.push(t[r], e[r + 1]);
	return n;
}, v = function(t) {
	return null !== t && "object" == typeof t && "[object Object]" === (t.toString ? t.toString() : Object.prototype.toString.call(t)) && !typeOf(t);
}, g = Object.freeze([]), S = Object.freeze({});
function w(e) {
	return "function" == typeof e;
}
function E(e) {
	return e.displayName || e.name || "Component";
}
function b(e) {
	return e && "string" == typeof e.styledComponentId;
}
var _ = "undefined" != typeof process && void 0 !== process.env && (process.env.REACT_APP_SC_ATTR || process.env.SC_ATTR) || "data-styled", A = "undefined" != typeof window && "HTMLElement" in window, C = Boolean(false), I = {};
function R(e) {
	for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
	throw /* @__PURE__ */ new Error("An error occurred. See https://git.io/JUIaE#" + e + " for more information." + (n.length > 0 ? " Args: " + n.join(", ") : ""));
}
var D = function() {
	function e(e) {
		this.groupSizes = new Uint32Array(512), this.length = 512, this.tag = e;
	}
	var t = e.prototype;
	return t.indexOfGroup = function(e) {
		for (var t = 0, n = 0; n < e; n++) t += this.groupSizes[n];
		return t;
	}, t.insertRules = function(e, t) {
		if (e >= this.groupSizes.length) {
			for (var n = this.groupSizes, r = n.length, o = r; e >= o;) (o <<= 1) < 0 && R(16, "" + e);
			this.groupSizes = new Uint32Array(o), this.groupSizes.set(n), this.length = o;
			for (var s = r; s < o; s++) this.groupSizes[s] = 0;
		}
		for (var i = this.indexOfGroup(e + 1), a = 0, c = t.length; a < c; a++) this.tag.insertRule(i, t[a]) && (this.groupSizes[e]++, i++);
	}, t.clearGroup = function(e) {
		if (e < this.length) {
			var t = this.groupSizes[e], n = this.indexOfGroup(e), r = n + t;
			this.groupSizes[e] = 0;
			for (var o = n; o < r; o++) this.tag.deleteRule(n);
		}
	}, t.getGroup = function(e) {
		var t = "";
		if (e >= this.length || 0 === this.groupSizes[e]) return t;
		for (var n = this.groupSizes[e], r = this.indexOfGroup(e), o = r + n, s = r; s < o; s++) t += this.tag.getRule(s) + "/*!sc*/\n";
		return t;
	}, e;
}(), j = /* @__PURE__ */ new Map(), T = /* @__PURE__ */ new Map(), x = 1, k = function(e) {
	if (j.has(e)) return j.get(e);
	for (; T.has(x);) x++;
	var t = x++;
	return j.set(e, t), T.set(t, e), t;
}, V = function(e) {
	return T.get(e);
}, z = function(e, t) {
	t >= x && (x = t + 1), j.set(e, t), T.set(t, e);
}, B = "style[" + _ + "][data-styled-version=\"5.3.11\"]", M = new RegExp("^" + _ + "\\.g(\\d+)\\[id=\"([\\w\\d-]+)\"\\].*?\"([^\"]*)"), G = function(e, t, n) {
	for (var r, o = n.split(","), s = 0, i = o.length; s < i; s++) (r = o[s]) && e.registerName(t, r);
}, L = function(e, t) {
	for (var n = (t.textContent || "").split("/*!sc*/\n"), r = [], o = 0, s = n.length; o < s; o++) {
		var i = n[o].trim();
		if (i) {
			var a = i.match(M);
			if (a) {
				var c = 0 | parseInt(a[1], 10), u = a[2];
				0 !== c && (z(u, c), G(e, u, a[3]), e.getTag().insertRules(c, r)), r.length = 0;
			} else r.push(i);
		}
	}
}, F = function() {
	return "undefined" != typeof __webpack_nonce__ ? __webpack_nonce__ : null;
}, Y = function(e) {
	var t = document.head, n = e || t, r = document.createElement("style"), o = function(e) {
		for (var t = e.childNodes, n = t.length; n >= 0; n--) {
			var r = t[n];
			if (r && 1 === r.nodeType && r.hasAttribute(_)) return r;
		}
	}(n), s = void 0 !== o ? o.nextSibling : null;
	r.setAttribute(_, "active"), r.setAttribute("data-styled-version", "5.3.11");
	var i = F();
	return i && r.setAttribute("nonce", i), n.insertBefore(r, s), r;
}, q = function() {
	function e(e) {
		var t = this.element = Y(e);
		t.appendChild(document.createTextNode("")), this.sheet = function(e) {
			if (e.sheet) return e.sheet;
			for (var t = document.styleSheets, n = 0, r = t.length; n < r; n++) {
				var o = t[n];
				if (o.ownerNode === e) return o;
			}
			R(17);
		}(t), this.length = 0;
	}
	var t = e.prototype;
	return t.insertRule = function(e, t) {
		try {
			return this.sheet.insertRule(t, e), this.length++, !0;
		} catch (e) {
			return !1;
		}
	}, t.deleteRule = function(e) {
		this.sheet.deleteRule(e), this.length--;
	}, t.getRule = function(e) {
		var t = this.sheet.cssRules[e];
		return void 0 !== t && "string" == typeof t.cssText ? t.cssText : "";
	}, e;
}(), H = function() {
	function e(e) {
		this.nodes = (this.element = Y(e)).childNodes, this.length = 0;
	}
	var t = e.prototype;
	return t.insertRule = function(e, t) {
		if (e <= this.length && e >= 0) {
			var n = document.createTextNode(t), r = this.nodes[e];
			return this.element.insertBefore(n, r || null), this.length++, !0;
		}
		return !1;
	}, t.deleteRule = function(e) {
		this.element.removeChild(this.nodes[e]), this.length--;
	}, t.getRule = function(e) {
		return e < this.length ? this.nodes[e].textContent : "";
	}, e;
}(), $ = function() {
	function e(e) {
		this.rules = [], this.length = 0;
	}
	var t = e.prototype;
	return t.insertRule = function(e, t) {
		return e <= this.length && (this.rules.splice(e, 0, t), this.length++, !0);
	}, t.deleteRule = function(e) {
		this.rules.splice(e, 1), this.length--;
	}, t.getRule = function(e) {
		return e < this.length ? this.rules[e] : "";
	}, e;
}(), W = A, U = {
	isServer: !A,
	useCSSOMInjection: !C
}, J = function() {
	function e(e, t, n) {
		void 0 === e && (e = S), void 0 === t && (t = {}), this.options = m({}, U, {}, e), this.gs = t, this.names = new Map(n), this.server = !!e.isServer, !this.server && A && W && (W = !1, function(e) {
			for (var t = document.querySelectorAll(B), n = 0, r = t.length; n < r; n++) {
				var o = t[n];
				o && "active" !== o.getAttribute(_) && (L(e, o), o.parentNode && o.parentNode.removeChild(o));
			}
		}(this));
	}
	e.registerId = function(e) {
		return k(e);
	};
	var t = e.prototype;
	return t.reconstructWithOptions = function(t, n) {
		return void 0 === n && (n = !0), new e(m({}, this.options, {}, t), this.gs, n && this.names || void 0);
	}, t.allocateGSInstance = function(e) {
		return this.gs[e] = (this.gs[e] || 0) + 1;
	}, t.getTag = function() {
		return this.tag || (this.tag = (n = (t = this.options).isServer, r = t.useCSSOMInjection, o = t.target, e = n ? new $(o) : r ? new q(o) : new H(o), new D(e)));
		var e, t, n, r, o;
	}, t.hasNameForId = function(e, t) {
		return this.names.has(e) && this.names.get(e).has(t);
	}, t.registerName = function(e, t) {
		if (k(e), this.names.has(e)) this.names.get(e).add(t);
		else {
			var n = /* @__PURE__ */ new Set();
			n.add(t), this.names.set(e, n);
		}
	}, t.insertRules = function(e, t, n) {
		this.registerName(e, t), this.getTag().insertRules(k(e), n);
	}, t.clearNames = function(e) {
		this.names.has(e) && this.names.get(e).clear();
	}, t.clearRules = function(e) {
		this.getTag().clearGroup(k(e)), this.clearNames(e);
	}, t.clearTag = function() {
		this.tag = void 0;
	}, t.toString = function() {
		return function(e) {
			for (var t = e.getTag(), n = t.length, r = "", o = 0; o < n; o++) {
				var s = V(o);
				if (void 0 !== s) {
					var i = e.names.get(s), a = t.getGroup(o);
					if (i && a && i.size) {
						var c = _ + ".g" + o + "[id=\"" + s + "\"]", u = "";
						void 0 !== i && i.forEach((function(e) {
							e.length > 0 && (u += e + ",");
						})), r += "" + a + c + "{content:\"" + u + "\"}/*!sc*/\n";
					}
				}
			}
			return r;
		}(this);
	}, e;
}(), X = /(a)(d)/gi, Z = function(e) {
	return String.fromCharCode(e + (e > 25 ? 39 : 97));
};
function K(e) {
	var t, n = "";
	for (t = Math.abs(e); t > 52; t = t / 52 | 0) n = Z(t % 52) + n;
	return (Z(t % 52) + n).replace(X, "$1-$2");
}
var Q = function(e, t) {
	for (var n = t.length; n;) e = 33 * e ^ t.charCodeAt(--n);
	return e;
}, ee = function(e) {
	return Q(5381, e);
};
function te(e) {
	for (var t = 0; t < e.length; t += 1) {
		var n = e[t];
		if (w(n) && !b(n)) return !1;
	}
	return !0;
}
var ne = ee("5.3.11"), re = function() {
	function e(e, t, n) {
		this.rules = e, this.staticRulesId = "", this.isStatic = (void 0 === n || n.isStatic) && te(e), this.componentId = t, this.baseHash = Q(ne, t), this.baseStyle = n, J.registerId(t);
	}
	return e.prototype.generateAndInjectStyles = function(e, t, n) {
		var r = this.componentId, o = [];
		if (this.baseStyle && o.push(this.baseStyle.generateAndInjectStyles(e, t, n)), this.isStatic && !n.hash) if (this.staticRulesId && t.hasNameForId(r, this.staticRulesId)) o.push(this.staticRulesId);
		else {
			var s = be(this.rules, e, t, n).join(""), i = K(Q(this.baseHash, s) >>> 0);
			if (!t.hasNameForId(r, i)) {
				var a = n(s, "." + i, void 0, r);
				t.insertRules(r, i, a);
			}
			o.push(i), this.staticRulesId = i;
		}
		else {
			for (var c = this.rules.length, u = Q(this.baseHash, n.hash), l = "", d = 0; d < c; d++) {
				var h = this.rules[d];
				if ("string" == typeof h) l += h;
				else if (h) {
					var p = be(h, e, t, n), f = Array.isArray(p) ? p.join("") : p;
					u = Q(u, f + d), l += f;
				}
			}
			if (l) {
				var m = K(u >>> 0);
				if (!t.hasNameForId(r, m)) {
					var y = n(l, "." + m, void 0, r);
					t.insertRules(r, m, y);
				}
				o.push(m);
			}
		}
		return o.join(" ");
	}, e;
}(), oe = /^\s*\/\/.*$/gm, se = [
	":",
	"[",
	".",
	"#"
];
function ie(e) {
	var t, n, r, o, s = void 0 === e ? S : e, i = s.options, a = void 0 === i ? S : i, c = s.plugins, u = void 0 === c ? g : c, l = new stylis_min(a), h = [], p = function(e) {
		function t(t) {
			if (t) try {
				e(t + "}");
			} catch (e) {}
		}
		return function(n, r, o, s, i, a, c, u, l, d) {
			switch (n) {
				case 1:
					if (0 === l && 64 === r.charCodeAt(0)) return e(r + ";"), "";
					break;
				case 2:
					if (0 === u) return r + "/*|*/";
					break;
				case 3: switch (u) {
					case 102:
					case 112: return e(o[0] + r), "";
					default: return r + (0 === d ? "/*|*/" : "");
				}
				case -2: r.split("/*|*/}").forEach(t);
			}
		};
	}((function(e) {
		h.push(e);
	})), f = function(e, r, s) {
		return 0 === r && -1 !== se.indexOf(s[n.length]) || s.match(o) ? e : "." + t;
	};
	function m(e, s, i, a) {
		void 0 === a && (a = "&");
		var c = e.replace(oe, ""), u = s && i ? i + " " + s + " { " + c + " }" : c;
		return t = a, n = s, r = new RegExp("\\" + n + "\\b", "g"), o = new RegExp("(\\" + n + "\\b){2,}"), l(i || !s ? "" : s, u);
	}
	return l.use([].concat(u, [
		function(e, t, o) {
			2 === e && o.length && o[0].lastIndexOf(n) > 0 && (o[0] = o[0].replace(r, f));
		},
		p,
		function(e) {
			if (-2 === e) {
				var t = h;
				return h = [], t;
			}
		}
	])), m.hash = u.length ? u.reduce((function(e, t) {
		return t.name || R(15), Q(e, t.name);
	}), 5381).toString() : "", m;
}
var ae = React.createContext();
ae.Consumer;
var ue = React.createContext(), le = (ue.Consumer, new J()), de = ie();
function he() {
	return useContext(ae) || le;
}
function pe() {
	return useContext(ue) || de;
}
function fe(e) {
	var t = useState(e.stylisPlugins), n = t[0], s = t[1], c = he(), u = useMemo((function() {
		var t = c;
		return e.sheet ? t = e.sheet : e.target && (t = t.reconstructWithOptions({ target: e.target }, !1)), e.disableCSSOMInjection && (t = t.reconstructWithOptions({ useCSSOMInjection: !1 })), t;
	}), [
		e.disableCSSOMInjection,
		e.sheet,
		e.target
	]), d = useMemo((function() {
		return ie({
			options: { prefix: !e.disableVendorPrefixes },
			plugins: n
		});
	}), [e.disableVendorPrefixes, n]);
	return useEffect((function() {
		l(n, e.stylisPlugins) || s(e.stylisPlugins);
	}), [e.stylisPlugins]), React.createElement(ae.Provider, { value: u }, React.createElement(ue.Provider, { value: d }, e.children));
}
var me = function() {
	function e(e, t) {
		var n = this;
		this.inject = function(e, t) {
			void 0 === t && (t = de);
			var r = n.name + t.hash;
			e.hasNameForId(n.id, r) || e.insertRules(n.id, r, t(n.rules, r, "@keyframes"));
		}, this.toString = function() {
			return R(12, String(n.name));
		}, this.name = e, this.id = "sc-keyframes-" + e, this.rules = t;
	}
	return e.prototype.getName = function(e) {
		return void 0 === e && (e = de), this.name + e.hash;
	}, e;
}(), ye = /([A-Z])/, ve = /([A-Z])/g, ge = /^ms-/, Se = function(e) {
	return "-" + e.toLowerCase();
};
function we(e) {
	return ye.test(e) ? e.replace(ve, Se).replace(ge, "-ms-") : e;
}
var Ee = function(e) {
	return null == e || !1 === e || "" === e;
};
function be(e, n, r, o) {
	if (Array.isArray(e)) {
		for (var s, i = [], a = 0, c = e.length; a < c; a += 1) "" !== (s = be(e[a], n, r, o)) && (Array.isArray(s) ? i.push.apply(i, s) : i.push(s));
		return i;
	}
	if (Ee(e)) return "";
	if (b(e)) return "." + e.styledComponentId;
	if (w(e)) {
		if ("function" != typeof (l = e) || l.prototype && l.prototype.isReactComponent || !n) return e;
		return be(e(n), n, r, o);
	}
	var l;
	return e instanceof me ? r ? (e.inject(r, o), e.getName(o)) : e : v(e) ? function e(t, n) {
		var r, o, s = [];
		for (var i in t) t.hasOwnProperty(i) && !Ee(t[i]) && (Array.isArray(t[i]) && t[i].isCss || w(t[i]) ? s.push(we(i) + ":", t[i], ";") : v(t[i]) ? s.push.apply(s, e(t[i], i)) : s.push(we(i) + ": " + (r = i, null == (o = t[i]) || "boolean" == typeof o || "" === o ? "" : "number" != typeof o || 0 === o || r in unitlessKeys || r.startsWith("--") ? String(o).trim() : o + "px") + ";"));
		return n ? [n + " {"].concat(s, ["}"]) : s;
	}(e) : e.toString();
}
var _e = function(e) {
	return Array.isArray(e) && (e.isCss = !0), e;
};
function Ne(e) {
	for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
	return w(e) || v(e) ? _e(be(y(g, [e].concat(n)))) : 0 === n.length && 1 === e.length && "string" == typeof e[0] ? e : _e(be(y(e, n)));
}
var Pe = function(e, t, n) {
	return void 0 === n && (n = S), e.theme !== n.theme && e.theme || t || n.theme;
}, Oe = /[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g, Re = /(^-|-$)/g;
function De(e) {
	return e.replace(Oe, "-").replace(Re, "");
}
var je = function(e) {
	return K(ee(e) >>> 0);
};
function Te(e) {
	return "string" == typeof e && true;
}
var xe = function(e) {
	return "function" == typeof e || "object" == typeof e && null !== e && !Array.isArray(e);
}, ke = function(e) {
	return "__proto__" !== e && "constructor" !== e && "prototype" !== e;
};
function Ve(e, t, n) {
	var r = e[n];
	xe(t) && xe(r) ? ze(r, t) : e[n] = t;
}
function ze(e) {
	for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
	for (var o = 0, s = n; o < s.length; o++) {
		var i = s[o];
		if (xe(i)) for (var a in i) ke(a) && Ve(e, i[a], a);
	}
	return e;
}
var Be = React.createContext();
Be.Consumer;
function Ge(e) {
	var t = useContext(Be), n = useMemo((function() {
		return function(e, t) {
			if (!e) return R(14);
			if (w(e)) return e(t);
			return Array.isArray(e) || "object" != typeof e ? R(8) : t ? m({}, t, {}, e) : e;
		}(e.theme, t);
	}), [e.theme, t]);
	return e.children ? React.createElement(Be.Provider, { value: n }, e.children) : null;
}
var Le = {};
function Fe(e, t, n) {
	var o = b(e), i = !Te(e), a = t.attrs, c = void 0 === a ? g : a, l = t.componentId, d = void 0 === l ? function(e, t) {
		var n = "string" != typeof e ? "sc" : De(e);
		Le[n] = (Le[n] || 0) + 1;
		var r = n + "-" + je("5.3.11" + n + Le[n]);
		return t ? t + "-" + r : r;
	}(t.displayName, t.parentComponentId) : l, h = t.displayName, y = void 0 === h ? function(e) {
		return Te(e) ? "styled." + e : "Styled(" + E(e) + ")";
	}(e) : h, v = t.displayName && t.componentId ? De(t.displayName) + "-" + t.componentId : t.componentId || d, _ = o && e.attrs ? Array.prototype.concat(e.attrs, c).filter(Boolean) : c, N = t.shouldForwardProp;
	o && e.shouldForwardProp && (N = t.shouldForwardProp ? function(n, r, o) {
		return e.shouldForwardProp(n, r, o) && t.shouldForwardProp(n, r, o);
	} : e.shouldForwardProp);
	var A, C = new re(n, v, o ? e.componentStyle : void 0), I = C.isStatic && 0 === c.length, P = function(e, t) {
		return function(e, t, n, r) {
			var o = e.attrs, i = e.componentStyle, a = e.defaultProps, c = e.foldedComponentIds, l = e.shouldForwardProp, d = e.styledComponentId, h = e.target, f = function(e, t, n) {
				void 0 === e && (e = S);
				var r = m({}, t, { theme: e }), o = {};
				return n.forEach((function(e) {
					var t, n, s, i = e;
					for (t in w(i) && (i = i(r)), i) r[t] = o[t] = "className" === t ? (n = o[t], s = i[t], n && s ? n + " " + s : n || s) : i[t];
				})), [r, o];
			}(Pe(t, useContext(Be), a) || S, t, o), y = f[0], v = f[1], g = function(e, t, n, r) {
				var o = he(), s = pe();
				return t ? e.generateAndInjectStyles(S, o, s) : e.generateAndInjectStyles(n, o, s);
			}(i, r, y, void 0), E = n, b = v.$as || t.$as || v.as || t.as || h, _ = Te(b), N = v !== t ? m({}, t, {}, v) : t, A = {};
			for (var C in N) "$" !== C[0] && "as" !== C && ("forwardedAs" === C ? A.as = N[C] : (l ? l(C, p, b) : !_ || p(C)) && (A[C] = N[C]));
			return t.style && v.style !== t.style && (A.style = m({}, t.style, {}, v.style)), A.className = Array.prototype.concat(c, d, g !== d ? g : null, t.className, v.className).filter(Boolean).join(" "), A.ref = E, createElement(b, A);
		}(A, e, t, I);
	};
	return P.displayName = y, (A = React.forwardRef(P)).attrs = _, A.componentStyle = C, A.displayName = y, A.shouldForwardProp = N, A.foldedComponentIds = o ? Array.prototype.concat(e.foldedComponentIds, e.styledComponentId) : g, A.styledComponentId = v, A.target = o ? e.target : e, A.withComponent = function(e) {
		var r = t.componentId, o = function(e, t) {
			if (null == e) return {};
			var n, r, o = {}, s = Object.keys(e);
			for (r = 0; r < s.length; r++) n = s[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
			return o;
		}(t, ["componentId"]), s = r && r + "-" + (Te(e) ? e : De(E(e)));
		return Fe(e, m({}, o, {
			attrs: _,
			componentId: s
		}), n);
	}, Object.defineProperty(A, "defaultProps", {
		get: function() {
			return this._foldedDefaultProps;
		},
		set: function(t) {
			this._foldedDefaultProps = o ? ze({}, e.defaultProps, t) : t;
		}
	}), Object.defineProperty(A, "toString", { value: function() {
		return "." + A.styledComponentId;
	} }), i && f(A, e, {
		attrs: !0,
		componentStyle: !0,
		displayName: !0,
		foldedComponentIds: !0,
		shouldForwardProp: !0,
		styledComponentId: !0,
		target: !0,
		withComponent: !0
	}), A;
}
var Ye = function(e) {
	return function e(t, r, o) {
		if (void 0 === o && (o = S), !isValidElementType(r)) return R(1, String(r));
		var s = function() {
			return t(r, o, Ne.apply(void 0, arguments));
		};
		return s.withConfig = function(n) {
			return e(t, r, m({}, o, {}, n));
		}, s.attrs = function(n) {
			return e(t, r, m({}, o, { attrs: Array.prototype.concat(o.attrs, n).filter(Boolean) }));
		}, s;
	}(Fe, e);
};
[
	"a",
	"abbr",
	"address",
	"area",
	"article",
	"aside",
	"audio",
	"b",
	"base",
	"bdi",
	"bdo",
	"big",
	"blockquote",
	"body",
	"br",
	"button",
	"canvas",
	"caption",
	"cite",
	"code",
	"col",
	"colgroup",
	"data",
	"datalist",
	"dd",
	"del",
	"details",
	"dfn",
	"dialog",
	"div",
	"dl",
	"dt",
	"em",
	"embed",
	"fieldset",
	"figcaption",
	"figure",
	"footer",
	"form",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"head",
	"header",
	"hgroup",
	"hr",
	"html",
	"i",
	"iframe",
	"img",
	"input",
	"ins",
	"kbd",
	"keygen",
	"label",
	"legend",
	"li",
	"link",
	"main",
	"map",
	"mark",
	"marquee",
	"menu",
	"menuitem",
	"meta",
	"meter",
	"nav",
	"noscript",
	"object",
	"ol",
	"optgroup",
	"option",
	"output",
	"p",
	"param",
	"picture",
	"pre",
	"progress",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"script",
	"section",
	"select",
	"small",
	"source",
	"span",
	"strong",
	"style",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"time",
	"title",
	"tr",
	"track",
	"u",
	"ul",
	"var",
	"video",
	"wbr",
	"circle",
	"clipPath",
	"defs",
	"ellipse",
	"foreignObject",
	"g",
	"image",
	"line",
	"linearGradient",
	"marker",
	"mask",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"stop",
	"svg",
	"text",
	"textPath",
	"tspan"
].forEach((function(e) {
	Ye[e] = Ye(e);
}));
var qe = function() {
	function e(e, t) {
		this.rules = e, this.componentId = t, this.isStatic = te(e), J.registerId(this.componentId + 1);
	}
	var t = e.prototype;
	return t.createStyles = function(e, t, n, r) {
		var o = r(be(this.rules, t, n, r).join(""), ""), s = this.componentId + e;
		n.insertRules(s, s, o);
	}, t.removeStyles = function(e, t) {
		t.clearRules(this.componentId + e);
	}, t.renderStyles = function(e, t, n, r) {
		e > 2 && J.registerId(this.componentId + e), this.removeStyles(e, n), this.createStyles(e, t, n, r);
	}, e;
}();
function He(e) {
	for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), o = 1; o < t; o++) n[o - 1] = arguments[o];
	var i = Ne.apply(void 0, [e].concat(n)), a = "sc-global-" + je(JSON.stringify(i)), u = new qe(i, a);
	function l(e) {
		var t = he(), n = pe(), o = useContext(Be), u = useRef(t.allocateGSInstance(a)).current;
		return t.server && d(u, e, t, o, n), null;
	}
	function d(e, t, n, r, o) {
		if (u.isStatic) u.renderStyles(e, I, n, o);
		else {
			var s = m({}, t, { theme: Pe(t, r, l.defaultProps) });
			u.renderStyles(e, s, n, o);
		}
	}
	return React.memo(l);
}
var We = /^\s*<\/[a-z]/i;
(function() {
	function e() {
		var e = this;
		this._emitSheetCSS = function() {
			var t = e.instance.toString();
			if (!t) return "";
			var n = F();
			return "<style " + [
				n && "nonce=\"" + n + "\"",
				_ + "=\"true\"",
				"data-styled-version=\"5.3.11\""
			].filter(Boolean).join(" ") + ">" + t + "</style>";
		}, this.getStyleTags = function() {
			return e.sealed ? R(2) : e._emitSheetCSS();
		}, this.getStyleElement = function() {
			var t;
			if (e.sealed) return R(2);
			var n = ((t = {})[_] = "", t["data-styled-version"] = "5.3.11", t.dangerouslySetInnerHTML = { __html: e.instance.toString() }, t), o = F();
			return o && (n.nonce = o), [React.createElement("style", m({}, n, { key: "sc-0-0" }))];
		}, this.seal = function() {
			e.sealed = !0;
		}, this.instance = new J({ isServer: !0 }), this.sealed = !1;
	}
	var t = e.prototype;
	return t.collectStyles = function(e) {
		return this.sealed ? R(2) : React.createElement(fe, { sheet: this.instance }, e);
	}, t.interleaveWithNodeStream = function(e) {
		if (A) return R(3);
		if (this.sealed) return R(2);
		this.seal();
		var t = __require("stream"), n = (t.Readable, t.Transform), r = e, o = this.instance, s = this._emitSheetCSS, i = new n({ transform: function(e, t, n) {
			var r = e.toString(), i = s();
			if (o.clearTag(), We.test(r)) {
				var a = r.indexOf(">") + 1, c = r.slice(0, a), u = r.slice(a);
				this.push(c + i + u);
			} else this.push(i + r);
			n();
		} });
		return r.on("error", (function(e) {
			i.emit("error", e);
		})), r.pipe(i);
	}, e;
})();
function _extends() {
	_extends = Object.assign || function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends.apply(this, arguments);
}
var get$1 = function get(obj, key, def, p, undef) {
	key = key && key.split ? key.split(".") : [key];
	for (p = 0; p < key.length; p++) obj = obj ? obj[key[p]] : undef;
	return obj === undef ? def : obj;
};
var defaultBreakpoints = [
	40,
	52,
	64
].map(function(n) {
	return n + "em";
});
var defaultTheme = {
	space: [
		0,
		4,
		8,
		16,
		32,
		64,
		128,
		256,
		512
	],
	fontSizes: [
		12,
		14,
		16,
		20,
		24,
		32,
		48,
		64,
		72
	]
};
var aliases = {
	bg: "backgroundColor",
	m: "margin",
	mt: "marginTop",
	mr: "marginRight",
	mb: "marginBottom",
	ml: "marginLeft",
	mx: "marginX",
	my: "marginY",
	p: "padding",
	pt: "paddingTop",
	pr: "paddingRight",
	pb: "paddingBottom",
	pl: "paddingLeft",
	px: "paddingX",
	py: "paddingY"
};
var multiples = {
	marginX: ["marginLeft", "marginRight"],
	marginY: ["marginTop", "marginBottom"],
	paddingX: ["paddingLeft", "paddingRight"],
	paddingY: ["paddingTop", "paddingBottom"],
	size: ["width", "height"]
};
var scales = {
	color: "colors",
	backgroundColor: "colors",
	borderColor: "colors",
	margin: "space",
	marginTop: "space",
	marginRight: "space",
	marginBottom: "space",
	marginLeft: "space",
	marginX: "space",
	marginY: "space",
	padding: "space",
	paddingTop: "space",
	paddingRight: "space",
	paddingBottom: "space",
	paddingLeft: "space",
	paddingX: "space",
	paddingY: "space",
	top: "space",
	right: "space",
	bottom: "space",
	left: "space",
	gridGap: "space",
	gridColumnGap: "space",
	gridRowGap: "space",
	gap: "space",
	columnGap: "space",
	rowGap: "space",
	fontFamily: "fonts",
	fontSize: "fontSizes",
	fontWeight: "fontWeights",
	lineHeight: "lineHeights",
	letterSpacing: "letterSpacings",
	border: "borders",
	borderTop: "borders",
	borderRight: "borders",
	borderBottom: "borders",
	borderLeft: "borders",
	borderWidth: "borderWidths",
	borderStyle: "borderStyles",
	borderRadius: "radii",
	borderTopRightRadius: "radii",
	borderTopLeftRadius: "radii",
	borderBottomRightRadius: "radii",
	borderBottomLeftRadius: "radii",
	borderTopWidth: "borderWidths",
	borderTopColor: "colors",
	borderTopStyle: "borderStyles",
	borderBottomWidth: "borderWidths",
	borderBottomColor: "colors",
	borderBottomStyle: "borderStyles",
	borderLeftWidth: "borderWidths",
	borderLeftColor: "colors",
	borderLeftStyle: "borderStyles",
	borderRightWidth: "borderWidths",
	borderRightColor: "colors",
	borderRightStyle: "borderStyles",
	outlineColor: "colors",
	boxShadow: "shadows",
	textShadow: "shadows",
	zIndex: "zIndices",
	width: "sizes",
	minWidth: "sizes",
	maxWidth: "sizes",
	height: "sizes",
	minHeight: "sizes",
	maxHeight: "sizes",
	flexBasis: "sizes",
	size: "sizes",
	fill: "colors",
	stroke: "colors"
};
var positiveOrNegative = function positiveOrNegative(scale, value) {
	if (typeof value !== "number" || value >= 0) return get$1(scale, value, value);
	var absolute = Math.abs(value);
	var n = get$1(scale, absolute, absolute);
	if (typeof n === "string") return "-" + n;
	return n * -1;
};
var transforms = [
	"margin",
	"marginTop",
	"marginRight",
	"marginBottom",
	"marginLeft",
	"marginX",
	"marginY",
	"top",
	"bottom",
	"left",
	"right"
].reduce(function(acc, curr) {
	var _extends2;
	return _extends({}, acc, (_extends2 = {}, _extends2[curr] = positiveOrNegative, _extends2));
}, {});
var responsive = function responsive(styles) {
	return function(theme) {
		var next = {};
		var breakpoints = get$1(theme, "breakpoints", defaultBreakpoints);
		var mediaQueries = [null].concat(breakpoints.map(function(n) {
			return "@media screen and (min-width: " + n + ")";
		}));
		for (var key in styles) {
			var value = typeof styles[key] === "function" ? styles[key](theme) : styles[key];
			if (value == null) continue;
			if (!Array.isArray(value)) {
				next[key] = value;
				continue;
			}
			for (var i = 0; i < value.slice(0, mediaQueries.length).length; i++) {
				var media = mediaQueries[i];
				if (!media) {
					next[key] = value[i];
					continue;
				}
				next[media] = next[media] || {};
				if (value[i] == null) continue;
				next[media][key] = value[i];
			}
		}
		return next;
	};
};
var css = function css(args) {
	return function(props) {
		if (props === void 0) props = {};
		var theme = _extends({}, defaultTheme, {}, props.theme || props);
		var result = {};
		var styles = responsive(typeof args === "function" ? args(theme) : args)(theme);
		for (var key in styles) {
			var x = styles[key];
			var val = typeof x === "function" ? x(theme) : x;
			if (key === "variant") {
				var variant = css(get$1(theme, val))(theme);
				result = _extends({}, result, {}, variant);
				continue;
			}
			if (val && typeof val === "object") {
				result[key] = css(val)(theme);
				continue;
			}
			var prop = get$1(aliases, key, key);
			var scale = get$1(theme, get$1(scales, prop), get$1(theme, prop, {}));
			var value = get$1(transforms, prop, get$1)(scale, val, val);
			if (multiples[prop]) {
				var dirs = multiples[prop];
				for (var i = 0; i < dirs.length; i++) result[dirs[i]] = value;
			} else result[prop] = value;
		}
		return result;
	};
};
var sx = (props) => css(props.sx);
/**
* @deprecated The Box component is deprecated. Replace with a `div` or
* appropriate HTML element instead, with CSS modules for styling.
* @see https://github.com/primer/react/blob/main/contributor-docs/migration-from-box.md
*/
var Box = Ye.div.withConfig({
	displayName: "Box",
	componentId: "sc-62in7e-0"
})(space, color, typography, layout, flexbox, grid, background, border, position, shadow, sx);
var defaultDayScheme = "light";
var defaultNightScheme = "dark";
var ThemeContext = /* @__PURE__ */ React.createContext({
	setColorMode: () => null,
	setDayScheme: () => null,
	setNightScheme: () => null
});
var getServerHandoff = (id) => {
	try {
		const serverData = document.getElementById(`__PRIMER_DATA_${id}__`)?.textContent;
		if (serverData) return JSON.parse(serverData);
	} catch (_error) {}
	return {};
};
var ThemeProvider = ({ children, ...props }) => {
	const { theme: fallbackTheme, colorMode: fallbackColorMode, dayScheme: fallbackDayScheme, nightScheme: fallbackNightScheme } = useTheme();
	const theme$1 = props.theme ?? fallbackTheme ?? theme;
	const uniqueDataId = useId$1();
	const { resolvedServerColorMode } = getServerHandoff(uniqueDataId);
	const resolvedColorModePassthrough = React.useRef(resolvedServerColorMode);
	const [colorMode, setColorMode] = useSyncedState(props.colorMode ?? fallbackColorMode ?? "day");
	const [dayScheme, setDayScheme] = useSyncedState(props.dayScheme ?? fallbackDayScheme ?? defaultDayScheme);
	const [nightScheme, setNightScheme] = useSyncedState(props.nightScheme ?? fallbackNightScheme ?? defaultNightScheme);
	const systemColorMode = useSystemColorMode();
	const resolvedColorMode = resolvedColorModePassthrough.current || resolveColorMode(colorMode, systemColorMode);
	const colorScheme = chooseColorScheme(resolvedColorMode, dayScheme, nightScheme);
	const { resolvedTheme, resolvedColorScheme } = React.useMemo(() => applyColorScheme(theme$1, colorScheme), [theme$1, colorScheme]);
	React.useEffect(function updateColorModeAfterServerPassthrough() {
		const resolvedColorModeOnClient = resolveColorMode(colorMode, systemColorMode);
		if (resolvedColorModePassthrough.current) {
			if (resolvedColorModePassthrough.current !== resolvedColorModeOnClient) window.setTimeout(() => {
				ReactDOM.flushSync(() => {
					setColorMode(resolvedColorModeOnClient);
				});
				setColorMode(colorMode);
			});
			resolvedColorModePassthrough.current = null;
		}
	}, [
		colorMode,
		systemColorMode,
		setColorMode
	]);
	return /* @__PURE__ */ jsx(ThemeContext.Provider, {
		value: {
			theme: resolvedTheme,
			colorScheme,
			colorMode,
			resolvedColorMode,
			resolvedColorScheme,
			dayScheme,
			nightScheme,
			setColorMode,
			setDayScheme,
			setNightScheme
		},
		children: /* @__PURE__ */ jsxs(Ge, {
			theme: resolvedTheme,
			children: [children, props.preventSSRMismatch ? /* @__PURE__ */ jsx("script", {
				type: "application/json",
				id: `__PRIMER_DATA_${uniqueDataId}__`,
				dangerouslySetInnerHTML: { __html: JSON.stringify({ resolvedServerColorMode: resolvedColorMode }) }
			}) : null]
		})
	});
};
function useTheme() {
	return React.useContext(ThemeContext);
}
function useSystemColorMode() {
	const [systemColorMode, setSystemColorMode] = React.useState(getSystemColorMode);
	React.useEffect(() => {
		const media = window?.matchMedia?.("(prefers-color-scheme: dark)");
		function matchesMediaToColorMode(matches) {
			return matches ? "night" : "day";
		}
		function handleChange(event) {
			const isNight = event.matches;
			setSystemColorMode(matchesMediaToColorMode(isNight));
		}
		if (media) {
			const isNight = media.matches;
			setSystemColorMode(matchesMediaToColorMode(isNight));
			if (media.addEventListener !== void 0) {
				media.addEventListener("change", handleChange);
				return function cleanup() {
					media.removeEventListener("change", handleChange);
				};
			} else if (media.addListener !== void 0) {
				media.addListener(handleChange);
				return function cleanup() {
					media.removeListener(handleChange);
				};
			}
		}
	}, []);
	return systemColorMode;
}
function getSystemColorMode() {
	if (typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)")?.matches) return "night";
	return "day";
}
function resolveColorMode(colorMode, systemColorMode) {
	switch (colorMode) {
		case "auto": return systemColorMode;
		default: return colorMode;
	}
}
function chooseColorScheme(colorMode, dayScheme, nightScheme) {
	switch (colorMode) {
		case "day":
		case "light": return dayScheme;
		case "dark":
		case "night": return nightScheme;
	}
}
function applyColorScheme(theme, colorScheme) {
	if (!theme.colorSchemes) return {
		resolvedTheme: theme,
		resolvedColorScheme: void 0
	};
	if (!theme.colorSchemes[colorScheme]) {
		console.error(`\`${colorScheme}\` scheme not defined in \`theme.colorSchemes\``);
		const defaultColorScheme = Object.keys(theme.colorSchemes)[0];
		return {
			resolvedTheme: deepmerge(theme, theme.colorSchemes[defaultColorScheme]),
			resolvedColorScheme: defaultColorScheme
		};
	}
	return {
		resolvedTheme: deepmerge(theme, theme.colorSchemes[colorScheme]),
		resolvedColorScheme: colorScheme
	};
}
He(["*{box-sizing:border-box;}body{margin:0;}table{border-collapse:collapse;}[data-color-mode='light'] input{color-scheme:light;}[data-color-mode='dark'] input{color-scheme:dark;}@media (prefers-color-scheme:light){[data-color-mode='auto'][data-light-theme*='light']{color-scheme:light;}}@media (prefers-color-scheme:dark){[data-color-mode='auto'][data-dark-theme*='dark']{color-scheme:dark;}}[role='button']:focus:not(:focus-visible):not(:global(.focus-visible)),[role='tabpanel'][tabindex='0']:focus:not(:focus-visible):not(:global(.focus-visible)),button:focus:not(:focus-visible):not(:global(.focus-visible)),summary:focus:not(:focus-visible):not(:global(.focus-visible)),a:focus:not(:focus-visible):not(:global(.focus-visible)){outline:none;box-shadow:none;}[tabindex='0']:focus:not(:focus-visible):not(:global(.focus-visible)),details-dialog:focus:not(:focus-visible):not(:global(.focus-visible)){outline:none;}.BaseStyles{font-family:var(--BaseStyles-fontFamily,var(--fontStack-system));line-height:var(--BaseStyles-lineHeight,1.5);color:var(--BaseStyles-fgColor,var(--fgColor-default));&:has([data-color-mode='light']){input &{color-scheme:light;}}&:has([data-color-mode='dark']){input &{color-scheme:dark;}}:where(a:not([class*='prc-']):not([class*='PRC-']):not([class*='Primer_Brand__'])){color:var(--fgColor-accent,var(--color-accent-fg));text-decoration:none;&:hover{text-decoration:underline;}}}"]);
var { get: getKey } = index_esm_exports;
var get = (key) => themeGet(key, getKey(theme, key));
var StyledActionList = Ye(ActionList).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionList",
	componentId: "sc-hw2362-0"
})(["", ""], sx);
var ActionListImpl = /* @__PURE__ */ React.forwardRef(function ActionListImpl({ as, ...rest }, ref) {
	return /* @__PURE__ */ jsx(StyledActionList, {
		ref,
		...rest,
		...as ? { forwardedAs: as } : {}
	});
});
var StyledActionListLinkItem = Ye(ActionList.LinkItem).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListLinkItem",
	componentId: "sc-hw2362-1"
})(["", ""], sx);
var ActionListLinkItem = /* @__PURE__ */ React.forwardRef(({ children, as, ...props }, ref) => /* @__PURE__ */ jsx(StyledActionListLinkItem, {
	ref,
	...props,
	...as ? { forwardedAs: as } : {},
	children
}));
ActionListLinkItem.displayName = "ActionList.LinkItem";
var StyledActionListTrailingAction = Ye(ActionList.TrailingAction).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListTrailingAction",
	componentId: "sc-hw2362-2"
})(["", ""], sx);
var ActionListTrailingAction = /* @__PURE__ */ React.forwardRef((props, ref) => {
	const { as, ...rest } = props;
	return /* @__PURE__ */ jsx(StyledActionListTrailingAction, {
		...rest,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
var StyledActionListItem = Ye(ActionList.Item).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListItem",
	componentId: "sc-hw2362-3"
})(["", ""], sx);
var ActionListItem = /* @__PURE__ */ React.forwardRef(({ children, as, ...props }, ref) => /* @__PURE__ */ jsx(StyledActionListItem, {
	ref,
	...props,
	...as ? { forwardedAs: as } : {},
	children
}));
var StyledActionListGroup = Ye(ActionList.Group).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListGroup",
	componentId: "sc-hw2362-4"
})(["", ""], sx);
var ActionListGroup = ({ children, as, ...props }) => /* @__PURE__ */ jsx(StyledActionListGroup, {
	...props,
	...as ? { forwardedAs: as } : {},
	children
});
ActionListGroup.displayName = "ActionList.Group";
var ActionListDivider = Ye(ActionList.Divider).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__ActionListDivider",
	componentId: "sc-hw2362-5"
})(["", ""], sx);
var StyledActionListLeadingVisual = Ye(ActionList.LeadingVisual).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListLeadingVisual",
	componentId: "sc-hw2362-6"
})(["", ""], sx);
var ActionListLeadingVisual = ({ children, as, ...props }) => /* @__PURE__ */ jsx(StyledActionListLeadingVisual, {
	...props,
	...as ? { forwardedAs: as } : {},
	children
});
ActionListLeadingVisual.displayName = "ActionList.LeadingVisual";
var StyledActionListTrailingVisual = Ye(ActionList.TrailingVisual).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListTrailingVisual",
	componentId: "sc-hw2362-7"
})(["", ""], sx);
var ActionListTrailingVisual = ({ children, as, ...props }) => /* @__PURE__ */ jsx(StyledActionListTrailingVisual, {
	...props,
	...as ? { forwardedAs: as } : {},
	children
});
ActionListTrailingVisual.displayName = "ActionList.TrailingVisual";
Object.assign(ActionListImpl, {
	Item: ActionListItem,
	LinkItem: ActionListLinkItem,
	Group: ActionListGroup,
	GroupHeading: ActionList.GroupHeading,
	Divider: ActionListDivider,
	Description: ActionList.Description,
	LeadingVisual: ActionListLeadingVisual,
	TrailingVisual: ActionListTrailingVisual,
	Heading: ActionList.Heading,
	TrailingAction: ActionListTrailingAction
});
ActionListItem.__SLOT__ = ActionList.Item.__SLOT__;
ActionListLinkItem.__SLOT__ = ActionList.LinkItem.__SLOT__;
ActionListGroup.__SLOT__ = ActionList.Group.__SLOT__;
ActionListDivider.__SLOT__ = ActionList.Divider.__SLOT__;
ActionListLeadingVisual.__SLOT__ = ActionList.LeadingVisual.__SLOT__;
ActionListTrailingVisual.__SLOT__ = ActionList.TrailingVisual.__SLOT__;
ActionListTrailingAction.__SLOT__ = ActionList.TrailingAction.__SLOT__;
var ActionMenuOverlay = Ye(ActionMenu.Overlay).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionMenu__ActionMenuOverlay",
	componentId: "sc-w5s60e-0"
})(["", ""], sx);
Object.assign(ActionMenu, {
	Button: ActionMenu.Button,
	Anchor: ActionMenu.Anchor,
	Overlay: ActionMenuOverlay,
	Divider: ActionMenu.Divider
});
ActionMenuOverlay.__SLOT__ = ActionMenu.Overlay.__SLOT__;
var BreadcrumbsImpl = Ye(Breadcrumbs_default).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Breadcrumbs__BreadcrumbsImpl",
	componentId: "sc-1qj8pw-0"
})(["", ""], sx);
var StyledBreadcrumbsItem = Ye(Breadcrumbs_default.Item).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Breadcrumbs__StyledBreadcrumbsItem",
	componentId: "sc-1qj8pw-1"
})(["", ""], sx);
function BreadcrumbsItem({ as, ...props }) {
	return /* @__PURE__ */ jsx(StyledBreadcrumbsItem, {
		...props,
		...as ? { forwardedAs: as } : {}
	});
}
Object.assign(BreadcrumbsImpl, { Item: BreadcrumbsItem });
var StyledButtonComponent = Ye(ButtonComponent$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Button__StyledButtonComponent",
	componentId: "sc-vqy3e4-0"
})(["", ""], sx);
var ButtonComponent = /* @__PURE__ */ forwardRef(({ as, sx, style: propStyle, ...props }, ref) => {
	const { block, size = "medium", leadingVisual, trailingVisual, trailingAction } = props;
	let sxStyles = {};
	const style = { ...propStyle || {} };
	if (sx !== null && Object.keys(sx || {}).length > 0) {
		sxStyles = generateCustomSxProp({
			block,
			size,
			leadingVisual,
			trailingVisual,
			trailingAction
		}, sx);
		const { color } = sx;
		if (color) style["--button-color"] = color;
	}
	return /* @__PURE__ */ jsx(StyledButtonComponent, {
		style,
		sx: sxStyles,
		ref,
		...props,
		...as ? { forwardedAs: as } : {}
	});
});
function generateCustomSxProp(props, providedSx) {
	const cssSelector = `&${`[data-size="${props.size}"]`}${props.block ? `[data-block="block"]` : ""}${props.leadingVisual || props.trailingVisual || props.trailingAction ? "" : "[data-no-visuals]"}`;
	const customSxProp = {};
	if (!providedSx) return customSxProp;
	else {
		customSxProp[cssSelector] = providedSx;
		return customSxProp;
	}
}
ButtonComponent.displayName = "Button";
ButtonComponent.__SLOT__ = ButtonComponent$1.__SLOT__;
var StyledDialog = Ye(Dialog$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Dialog__StyledDialog",
	componentId: "sc-19zph8h-0"
})(["", ""], sx);
var DialogImpl = /* @__PURE__ */ forwardRef(function Dialog({ as, ...props }, ref) {
	return /* @__PURE__ */ jsx(StyledDialog, {
		ref,
		...as ? { forwardedAs: as } : {},
		...props
	});
});
var StyledDialogHeader = Ye(Dialog$1.Header).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Dialog__StyledDialogHeader",
	componentId: "sc-19zph8h-1"
})(["", ""], sx);
var DialogHeader = /* @__PURE__ */ forwardRef(function DialogHeader({ as, ...props }, ref) {
	return /* @__PURE__ */ jsx(StyledDialogHeader, {
		ref,
		...as ? { forwardedAs: as } : {},
		...props
	});
});
var StyledDialogBody = Ye(Dialog$1.Body).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Dialog__StyledDialogBody",
	componentId: "sc-19zph8h-2"
})(["", ""], sx);
var DialogBody = /* @__PURE__ */ forwardRef(function DialogBody({ as, ...props }, ref) {
	return /* @__PURE__ */ jsx(StyledDialogBody, {
		ref,
		...as ? { forwardedAs: as } : {},
		...props
	});
});
var StyledDialogFooter = Ye(Dialog$1.Footer).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Dialog__StyledDialogFooter",
	componentId: "sc-19zph8h-3"
})(["", ""], sx);
var DialogFooter = /* @__PURE__ */ forwardRef(function DialogFooter({ as, ...props }, ref) {
	return /* @__PURE__ */ jsx(StyledDialogFooter, {
		ref,
		...as ? { forwardedAs: as } : {},
		...props
	});
});
DialogHeader.__SLOT__ = Dialog$1.Header.__SLOT__;
DialogBody.__SLOT__ = Dialog$1.Body.__SLOT__;
DialogFooter.__SLOT__ = Dialog$1.Footer.__SLOT__;
var Dialog = Object.assign(DialogImpl, {
	__SLOT__: Dialog$1["__SLOT__"],
	Buttons: Dialog$1.Buttons,
	Header: DialogHeader,
	Body: DialogBody,
	Footer: DialogFooter
});
Ye(Flash).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Flash",
	componentId: "sc-413izo-0"
})(["", ""], sx);
var FormControlImpl = Ye(FormControl$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "FormControl__FormControlImpl",
	componentId: "sc-1642wfe-0"
})(["", ""], sx);
Object.assign(FormControlImpl, {
	__SLOT__: FormControl$1.__SLOT__,
	Caption: FormControl$1.Caption,
	LeadingVisual: FormControl$1.LeadingVisual,
	Validation: FormControl$1.Validation,
	Label: FormControl$1.Label
});
var StyledHeader = /* @__PURE__ */ forwardRef(function Header(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Header_default,
		ref,
		...props
	});
});
var HeaderImpl = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledHeader, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
var HeaderItem = /* @__PURE__ */ forwardRef(function HeaderItem(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Header_default.Item,
		ref,
		...props
	});
});
var StyledHeaderLink = /* @__PURE__ */ forwardRef(function HeaderLink(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Header_default.Link,
		ref,
		...props
	});
});
var HeaderLink = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledHeaderLink, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
Object.assign(HeaderImpl, {
	Item: HeaderItem,
	Link: HeaderLink
});
var Heading = Ye(Heading$2).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Heading",
	componentId: "sc-1vc165i-0"
})(["", ""], sx);
var StyledIconButton = Ye(IconButton$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "IconButton__StyledIconButton",
	componentId: "sc-i53dt6-0"
})(["", ""], sx);
var IconButton = /* @__PURE__ */ forwardRef(({ as, sx, ...props }, ref) => {
	let sxStyles = sx;
	const { size = "medium" } = props;
	if (sx !== null && sx !== void 0 && Object.keys(sx).length > 0) sxStyles = generateCustomSxProp({ size }, sx);
	return /* @__PURE__ */ jsx(StyledIconButton, {
		sx: sxStyles,
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
IconButton.__SLOT__ = IconButton$1.__SLOT__;
var StyledLabel = Ye(Label$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Label__StyledLabel",
	componentId: "sc-1cpass9-0"
})(["", ""], sx);
var Label = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => {
	return /* @__PURE__ */ jsx(StyledLabel, {
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
var StyledLink = Ye(Link$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Link__StyledLink",
	componentId: "sc-1syctfj-0"
})(["", ""], sx);
var Link = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => {
	return /* @__PURE__ */ jsx(StyledLink, {
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
Ye(LinkButton).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "LinkButton",
	componentId: "sc-1v6zkmg-0"
})(["", ""], sx);
Ye(Overlay).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Overlay",
	componentId: "sc-tjbd74-0"
})(["", ""], sx);
var StyledPageHeader = Ye(PageHeader$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "PageHeader__StyledPageHeader",
	componentId: "sc-1g9symn-0"
})(["", ""], sx);
var PageHeaderImpl = /* @__PURE__ */ React.forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledPageHeader, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
function PageHeaderActions({ sx, ...rest }) {
	const style = {};
	if (sx) {
		const { height } = sx;
		if (height) style["--custom-height"] = height;
	}
	return /* @__PURE__ */ jsx(Box, {
		...rest,
		as: PageHeader$1.Actions,
		style,
		sx
	});
}
function StyledPageHeaderTitle({ sx, ...rest }) {
	const style = {};
	if (sx) {
		const { fontSize, lineHeight, fontWeight } = sx;
		if (fontSize) style["--custom-font-size"] = fontSize;
		if (lineHeight) style["--custom-line-height"] = lineHeight;
		if (fontWeight) style["--custom-font-weight"] = fontWeight;
	}
	return /* @__PURE__ */ jsx(Box, {
		...rest,
		as: PageHeader$1.Title,
		style,
		sx
	});
}
var PageHeaderTitle = ({ as, ...props }) => /* @__PURE__ */ jsx(StyledPageHeaderTitle, {
	...props,
	...as ? { forwardedAs: as } : {}
});
var PageHeaderTitleArea = Ye(PageHeader$1.TitleArea).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "PageHeader__PageHeaderTitleArea",
	componentId: "sc-1g9symn-1"
})(["", ""], sx);
Object.assign(PageHeaderImpl, {
	Actions: PageHeaderActions,
	ContextArea: PageHeader$1.ContextArea,
	ParentLink: PageHeader$1.ParentLink,
	ContextBar: PageHeader$1.ContextBar,
	TitleArea: PageHeaderTitleArea,
	ContextAreaActions: PageHeader$1.ContextAreaActions,
	LeadingAction: PageHeader$1.LeadingAction,
	Breadcrumbs: PageHeader$1.Breadcrumbs,
	LeadingVisual: PageHeader$1.LeadingVisual,
	Title: PageHeaderTitle,
	TrailingVisual: PageHeader$1.TrailingVisual,
	Description: PageHeader$1.Description,
	TrailingAction: PageHeader$1.TrailingAction
});
var SegmentedControlButton = (props) => {
	return /* @__PURE__ */ jsx(Box, {
		as: SegmentedControl.Button,
		...props
	});
};
var SegmentedControlIconButton = (props) => {
	return /* @__PURE__ */ jsx(Box, {
		as: SegmentedControl.IconButton,
		...props
	});
};
var SegmentedControlImpl = (props) => {
	return /* @__PURE__ */ jsx(Box, {
		as: SegmentedControl,
		...props
	});
};
Object.assign(SegmentedControlImpl, {
	__SLOT__: SegmentedControl.__SLOT__,
	Button: SegmentedControlButton,
	IconButton: SegmentedControlIconButton
});
SegmentedControlButton.__SLOT__ = SegmentedControl.Button.__SLOT__;
SegmentedControlIconButton.__SLOT__ = SegmentedControl.IconButton.__SLOT__;
Ye(Spinner).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Spinner",
	componentId: "sc-jbw2a0-0"
})(["", ""], sx);
var StyledText = Ye(Text$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Text__StyledText",
	componentId: "sc-1klmep6-0"
})(["", ""], sx);
var Text = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => {
	return /* @__PURE__ */ jsx(StyledText, {
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
Ye(Textarea).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Textarea__StyledTextarea",
	componentId: "sc-40d1gp-0"
})(["", ""], sx);
var StyledTextInput = Ye(TextInput$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "TextInput__StyledTextInput",
	componentId: "sc-ttxlvl-0"
})(["", ""], sx);
var TextInputImpl = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => {
	return /* @__PURE__ */ jsx(StyledTextInput, {
		ref,
		...props,
		...as ? { forwardedAs: as } : {}
	});
});
var TextInputAction = Ye(TextInput$1.Action).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "TextInput__TextInputAction",
	componentId: "sc-ttxlvl-1"
})(["", ""], sx);
Object.assign(TextInputImpl, {
	__SLOT__: TextInput$1.__SLOT__,
	Action: TextInputAction
});
TextInputAction.displayName = "TextInputAction";
TextInputImpl.displayName = "TextInput";
var TimelineImpl = /* @__PURE__ */ forwardRef(function Timeline(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Timeline_default,
		ref,
		...props
	});
});
var TimelineItem = /* @__PURE__ */ forwardRef(function TimelineItem(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Timeline_default.Item,
		ref,
		...props
	});
});
function TimelineBadge(props) {
	return /* @__PURE__ */ jsx(Box, {
		as: Timeline_default.Badge,
		...props
	});
}
var TimelineBody = /* @__PURE__ */ forwardRef(function TimelineBody(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Timeline_default.Body,
		ref,
		...props
	});
});
var TimelineBreak = /* @__PURE__ */ forwardRef(function TimelineBreak(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Timeline_default.Break,
		ref,
		...props
	});
});
var Timeline = Object.assign(TimelineImpl, {
	Item: TimelineItem,
	Badge: TimelineBadge,
	Body: TimelineBody,
	Break: TimelineBreak
});
var Tooltip = /* @__PURE__ */ forwardRef(function Tooltip(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Tooltip$1,
		ref,
		...props
	});
});
Tooltip.__SLOT__ = Tooltip$1.__SLOT__;
var StyledToken = Ye(Token$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Token__StyledToken",
	componentId: "sc-ldn0r8-0"
})(["", ""], sx);
var Token = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => {
	return /* @__PURE__ */ jsx(StyledToken, {
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
Ye(Truncate).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Truncate",
	componentId: "sc-x3i4it-0"
})(["", ""], sx);
var StyledUnderlineNav = /* @__PURE__ */ forwardRef(function UnderlineNav$1(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: UnderlineNav,
		ref,
		...props
	});
});
var UnderlineNavImpl = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledUnderlineNav, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
var StyledUnderlineNavItem = Ye(UnderlineNav.Item).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "UnderlineNav__StyledUnderlineNavItem",
	componentId: "sc-dx6br2-0"
})(["", ""], sx);
var UnderlineNavItem = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledUnderlineNavItem, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
Object.assign(UnderlineNavImpl, { Item: UnderlineNavItem });
export { get as _, Heading as a, useTheme as b, Link as c, ThemeProvider as d, Timeline as f, Ye as g, Tooltip as h, Header_default as i, PageHeader$1 as l, Token as m, ButtonComponent as n, IconButton as o, Timeline_default as p, Dialog as r, Label as s, Box as t, Text as u, merge as v, sx as y };
