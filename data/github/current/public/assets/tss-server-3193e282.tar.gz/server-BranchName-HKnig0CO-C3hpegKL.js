import { d as fixedForwardRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var classes = { "BranchName": "prc-BranchName-BranchName-CMTaU" };
function BranchName(props, ref) {
	const $ = c(13);
	let children;
	let className;
	let rest;
	let t0;
	if ($[0] !== props) {
		({as: t0, className, children, ...rest} = props);
		$[0] = props;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
		$[4] = t0;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
		t0 = $[4];
	}
	const Component = t0 === void 0 ? "a" : t0;
	let t1;
	if ($[5] !== className) {
		t1 = clsx(className, classes.BranchName);
		$[5] = className;
		$[6] = t1;
	} else t1 = $[6];
	let t2;
	if ($[7] !== Component || $[8] !== children || $[9] !== ref || $[10] !== rest || $[11] !== t1) {
		t2 = /* @__PURE__ */ jsx(Component, {
			...rest,
			ref,
			className: t1,
			children
		});
		$[7] = Component;
		$[8] = children;
		$[9] = ref;
		$[10] = rest;
		$[11] = t1;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
}
BranchName.displayName = "BranchName";
var BranchName_default = fixedForwardRef(BranchName);
export { BranchName_default as t };
