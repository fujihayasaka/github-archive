import { t as AnalyticsContext } from "./server-context-CRkr38GV-DyKv_rx3.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { use, useCallback } from "react";
import { c } from "react/compiler-runtime";
/**
* Use this hook with the AnalyticsContext to send user analytics events to the data warehouse.
* This hook will read values from the nearest AnalyticsContext.Provider, though you can override properties directly when sending an event.
* It uses the `sendEvent` helper from `github/hydro-analytics`,
* which enriches event context with additional information about the user, repository, and current page.
* See: https://thehub.github.com/epd/engineering/products-and-services/internal/hydro/installation/browser-events/
*
* You can find a list of all included context properties in `app/helpers/octolytics_helper.rb`.
*
*
* @example
* ```tsx
* function Component() {
*   const { sendAnalyticsEvent } = useAnalytics()
*   return <Button onClick={() => sendAnalyticsEvent('file_tree.close', 'FILE_TREE_TOGGLE')}>CLOSE TREE</Button>
* }
* ```
*
*/
function useAnalytics() {
	const $ = c(6);
	const contextData = use(AnalyticsContext);
	if (!contextData) throw new Error("useAnalytics must be used within an AnalyticsContext");
	const { appName, category, metadata } = contextData;
	let t0;
	if ($[0] !== appName || $[1] !== category || $[2] !== metadata) {
		t0 = (eventType, target, t1) => {
			const payload = t1 === void 0 ? {} : t1;
			sendEvent(eventType, {
				react: true,
				"app_name": appName,
				category,
				...metadata,
				...payload,
				target
			});
		};
		$[0] = appName;
		$[1] = category;
		$[2] = metadata;
		$[3] = t0;
	} else t0 = $[3];
	const t1 = t0;
	let t2;
	if ($[4] !== t1) {
		t2 = { sendAnalyticsEvent: t1 };
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
/**
* Use this hook with the AnalyticsContext to send user analytics events to the data warehouse.
* This hook will read values from the nearest AnalyticsContext.Provider, though you can override properties directly when sending an event.
* It uses the `sendEvent` helper from `github/hydro-analytics`,
* which enriches event context with additional information about the user, repository, and current page.
* See: https://thehub.github.com/epd/engineering/products-and-services/internal/hydro/installation/browser-events/
*
* You can find a list of all included context properties in `app/helpers/octolytics_helper.rb`.
*
*
* @example
* ```tsx
* function Component() {
*   const { sendClickAnalyticsEvent } = useClickAnalytics()
*   return <Button onClick={() => sendClickAnalyticsEvent({category: '...', action: '...', label: '...'})}>Submit</Button>
* }
* ```
*
*/
function useClickAnalytics() {
	const $ = c(4);
	const { sendAnalyticsEvent } = useAnalytics();
	let t0;
	if ($[0] !== sendAnalyticsEvent) {
		t0 = (t1) => {
			sendAnalyticsEvent("analytics.click", void 0, t1 === void 0 ? {} : t1);
		};
		$[0] = sendAnalyticsEvent;
		$[1] = t0;
	} else t0 = $[1];
	const t1 = t0;
	let t2;
	if ($[2] !== t1) {
		t2 = { sendClickAnalyticsEvent: t1 };
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
export { useClickAnalytics as n, useAnalytics as t };
