performance.mark("js-parse-end:server-global-nav-layout-orAiLaIT-lOlwRzul.js");
import { a as ssrSafeWindow, i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { n as __exportAll } from "./server-chunk-DPETvcc5-SoS15Jre.js";
import { i as ButtonComponent, m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { $n as PersonAddIcon, Dn as MarkGithubIcon, Gi as useSlots, H as CodeIcon, Hr as SparkleIcon, Ii as index_esm_exports, J as CodespacesIcon, Jt as GitPullRequestIcon, Qn as PeopleIcon, Tn as LockIcon, Wn as OrganizationIcon, Y as CommandPaletteIcon, Yt as GlobeIcon, Z as CommentIcon, _i as Truncate, _r as RepoLockedIcon, an as IconButton, ar as PlusIcon, bn as Link$1, ci as ThreeBarsIcon, et as CopilotIcon, fn as IssueOpenedIcon, gr as RepoIcon, hi as TriangleDownIcon, hr as RepoForkedIcon, i as AgentIcon, mt as DownloadIcon, n as ActionList, o as AlertIcon, or as ProjectIcon, pi as Tooltip$1, qr as Stack, si as TerminalIcon, sn as InboxIcon, vr as RepoPushIcon, wr as SearchIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { n as isExternalToApp } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { s as isUIService } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as Link$1$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { i as reactFetchJSON, r as reactFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { r as UnderlineNav, t as Breadcrumbs_default } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { l as useQuery, t as hashKey, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { a as CopilotLicenseType, b as copilotFeatureFlags, i as CopilotChatIntents, o as CopilotPlan, r as COPILOT_SPACES_PATH } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { t as isMacOS } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { n as useClickAnalytics, t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as getCookie, r as setCookie } from "./server-cookies-DndQO37X-vNR87gG9.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { i as publishOpenCopilotChat, o as subscribeOpenCopilotChat, t as OpenCopilotChatEvent } from "./server-copilot-chat-events-CAR-de8z-CxKg4yWR.js";
import { t as IncludeFragment } from "./server-IncludeFragment-DnVGLtXS-CQrYLuE4.js";
import { t as useAlive } from "./server-use-alive-Bs0u94wF-BuNgouIr.js";
import { t as createPersister } from "./server-react-query-persister-D24LKcxB-BQe2u09x.js";
import { n as Type, t as Compile } from "./server-typebox-DK1Y6Tz8-C4QyQJfa.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { a as getKeybindings, s as getPrimaryKeybinding } from "./server-commands-registry-PhKKp09d-CINoICbD.js";
import { a as GlobalCommands, r as CommandIconButton } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { t as FeatureFlags } from "./server-FeatureFlags-C1NipJFp-82e1Xac8.js";
import { r as ItemPicker } from "./server-ItemPicker-ILw4RsMA-BLDIejLk.js";
import { n as SpacesIcon } from "./server-CustomIcon-CTl7CX1Z-5XxrNXUA.js";
import { t as useExternalAnchor } from "./server-react-partial-anchor-DSxm7g5E-DAe-R2_8.js";
import { t as LazyGlobalSsoBanner } from "./server-LazyGlobalSsoBanner-BCV_e8ma-ZuaPMhBt.js";
import { n as useNavigableRef, t as NavigableRefProvider } from "./server-NavigableRef-V_CJ6v-4-DI5O_E6T.js";
import { a as registerLocalNavigationHandler, i as registerContextRegionHandler, n as clearRegisteredLocalNavigation, r as getContextRegion, t as clearRegisteredContextRegion } from "./server-global-navigation-CMV1pRiF-CAlzMUki.js";
import { t as TransactionalMessageBanner } from "./server-in-product-targeting-CynopFUF-BI4HZUnA.js";
import { n as analyticsCategory, r as useGlobalNavAnalytics, t as GlobalNavAnalyticsProvider } from "./server-constants-BeftNbDC-CL1QQX4_.js";
import { t as lazyWithPreload } from "./server-lazy-with-preload-CGaVyU2--DP3_troP.js";
import { t as analyticsCategory$1 } from "./server-constants-CqVh5mOx-CvujeEpf.js";
import { n as strings_default, t as getQueryOptions } from "./server-strings-BVSa86KS-9Xe7e3BY.js";
import { t as getRouterInstance } from "./server-getRouterInstance-CbN1klIM-Cx3RyjAK.js";
import { t as staffbar_module_default } from "./server-staffbar.module-D7igjJkz-CX7Ru-fg.js";
import React, { Suspense, createContext, lazy, startTransition, use, useCallback, useEffect, useId, useImperativeHandle, useLayoutEffect, useMemo, useReducer, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { Outlet, getRouteApi, useMatches } from "@tanstack/react-router";
import { c } from "react/compiler-runtime";
import { produce } from "immer";
performance.mark("js-parse-end:global-nav-layout-orAiLaIT.js");
function performFullPageNavigation(targetUrl, replace) {
	if (replace) {
		ssrSafeWindow?.location.replace(targetUrl.href);
		return;
	}
	ssrSafeWindow?.location.assign(targetUrl.href);
}
var softNavigate = async (url, options) => {
	if (!ssrSafeWindow) return;
	const targetUrl = new URL(String(url), ssrSafeWindow.location.href);
	const shouldReplace = options?.action === "replace";
	const router = await getRouterInstance();
	if (targetUrl.origin !== ssrSafeWindow.location.origin || isExternalToApp(router, targetUrl.pathname)) {
		performFullPageNavigation(targetUrl, shouldReplace);
		return;
	}
	router.navigate({
		to: `${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`,
		replace: shouldReplace
	});
};
var styles_module_default$1 = {
	appHeader: "styles-module_gNfHta_appHeader",
	appHeaderButton: "styles-module_gNfHta_appHeaderButton",
	center: "styles-module_gNfHta_center",
	hideTopNav: "styles-module_gNfHta_hideTopNav",
	itemDivider: "styles-module_gNfHta_itemDivider",
	left: "styles-module_gNfHta_left",
	right: "styles-module_gNfHta_right",
	withLocalNavigation: "styles-module_gNfHta_withLocalNavigation"
};
function ItemDivider() {
	return /* @__PURE__ */ jsx("div", { className: styles_module_default$1.itemDivider });
}
ItemDivider.displayName = "ItemDivider";
/**
* The NavLinkItem is used to display individual navigation icons in the TopNav
*/
var NavLinkItem = ({ ref: forwardedRef, href, "aria-label": ariaLabel, icon: Icon, hotkey, commandId, analyticsKey, analyticsSubCategory, linkText, onClick, onMouseEnter, onFocus, className }) => {
	const { sendItemClick } = useGlobalNavAnalytics(analyticsSubCategory);
	const linkRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef ?? null, linkRef);
	const uiCommandsEnabled = isFeatureEnabled("global_nav_ui_commands");
	if (!href) return /* @__PURE__ */ jsx(NavButtonItem, {
		"aria-label": ariaLabel,
		icon: Icon,
		hotkey: uiCommandsEnabled ? void 0 : hotkey,
		analyticsKey,
		linkText,
		onClick,
		onMouseEnter,
		onFocus,
		className,
		commandId: uiCommandsEnabled ? commandId : void 0
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [linkText ? /* @__PURE__ */ jsx(ButtonComponent, {
		ref: linkRef,
		as: Link$1$1,
		to: href,
		variant: "invisible",
		"aria-label": ariaLabel,
		"data-hotkey": uiCommandsEnabled ? void 0 : hotkey,
		className: clsx(styles_module_default$1.appHeaderButton, className),
		onClick: (e) => {
			sendItemClick(analyticsKey);
			onClick?.(e);
		},
		onMouseEnter,
		onFocus,
		leadingVisual: Icon,
		children: linkText
	}) : /* @__PURE__ */ jsx(IconButton, {
		ref: linkRef,
		as: Link$1$1,
		variant: "invisible",
		icon: Icon,
		"aria-label": ariaLabel,
		to: href,
		"data-hotkey": uiCommandsEnabled ? void 0 : hotkey,
		className: clsx(styles_module_default$1.appHeaderButton, className),
		keybindingHint: uiCommandsEnabled ? commandId && getPrimaryKeybinding(commandId) : hotkey,
		onClick: (e_0) => {
			sendItemClick(analyticsKey, ariaLabel);
			onClick?.(e_0);
		},
		onMouseEnter,
		onFocus
	}), uiCommandsEnabled && commandId && /* @__PURE__ */ jsx(GlobalCommands, { commands: { [commandId]: () => linkRef.current?.click() } })] });
};
NavLinkItem.displayName = "NavLinkItem";
NavLinkItem.displayName = "NavLinkItem";
/**
* The NavButtonItem is used to display individual navigation buttons in the TopNav
*/
var NavButtonItem = ({ "aria-label": ariaLabel, icon: Icon, hotkey, commandId, analyticsKey, linkText, onClick, onFocus, onMouseEnter, className, ref: forwardedRef }) => {
	const { sendItemClick } = useGlobalNavAnalytics();
	const uiCommandsEnabled = isFeatureEnabled("global_nav_ui_commands");
	const ref = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef ?? null, ref);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [linkText ? /* @__PURE__ */ jsx(ButtonComponent, {
		ref,
		variant: "invisible",
		"aria-label": ariaLabel,
		"data-hotkey": uiCommandsEnabled ? void 0 : hotkey,
		className: clsx(styles_module_default$1.appHeaderButton, className),
		onClick: (e) => {
			sendItemClick(analyticsKey);
			onClick?.(e);
		},
		onMouseEnter,
		onFocus,
		leadingVisual: Icon,
		children: linkText
	}) : /* @__PURE__ */ jsx(IconButton, {
		ref,
		variant: "invisible",
		icon: Icon,
		"aria-label": ariaLabel,
		"data-hotkey": uiCommandsEnabled ? void 0 : hotkey,
		className: clsx(styles_module_default$1.appHeaderButton, className),
		keybindingHint: uiCommandsEnabled ? commandId && getPrimaryKeybinding(commandId) : hotkey,
		onClick: (e_0) => {
			sendItemClick(analyticsKey, ariaLabel);
			onClick?.(e_0);
		},
		onMouseEnter,
		onFocus
	}), uiCommandsEnabled && commandId && /* @__PURE__ */ jsx(GlobalCommands, { commands: { [commandId]: () => ref.current?.click() } })] });
};
NavButtonItem.displayName = "NavButtonItem";
/**
* Context values exposed via `useTopNavContext`:
* - `hasLocalNavigation`: whether the navigation has local navigation tabs below the main bar.
* - `searchOpen`: whether the search input is currently open.
* - `isSearchPage`: whether the current page is the search page.
* - `setSearchOpen(open)`: toggles the search input open state.
* - `getFragmentsPath(type)`: builds the path used to fetch HTML fragments for the given type.
* - `topNavHidden`: whether the top navigation is currently hidden.
* - `setTopNavHidden(hidden)`: sets the hidden state of the top navigation.
* - `shouldLoadCopilotChat`: whether Copilot Chat assets should be loaded.
* - `loadCopilotChat()`: triggers loading of Copilot Chat assets.
*/
var TopNavContext = createContext({
	hasLocalNavigation: false,
	searchOpen: false,
	isSearchPage: false,
	setSearchOpen: () => {},
	getFragmentsPath: (type) => `/_global-navigation/fragments?type=${type}`,
	setTopNavHidden: () => {},
	topNavHidden: false,
	shouldLoadCopilotChat: false,
	loadCopilotChat: () => {},
	getPayloadsUrl: (type) => `/_global-navigation/payloads.json?type=${type}`
});
TopNavContext.displayName = "TopNavContext";
function shouldHideTopNav(urlParams, isSearchPage, isJumpToSearch) {
	return isSearchPage && !isJumpToSearch && !urlParams.get("q")?.trim();
}
function TopNavProvider(t0) {
	const $ = c(20);
	const { children, hasLocalNavigation, searchFragmentsPath, searchFragmentsParams, isSearchPage, isJumpToSearch, payloadsUrl: t1 } = t0;
	const payloadsUrl = t1 === void 0 ? "/_global-navigation/payloads.json" : t1;
	let t2;
	if ($[0] !== searchFragmentsParams || $[1] !== searchFragmentsPath) {
		t2 = (type) => searchFragmentsPath ? `${searchFragmentsPath}?type=${type}${searchFragmentsParams ? `&${searchFragmentsParams}` : ""}` : `/_global-navigation/fragments?type=${type}${searchFragmentsParams ? `&${searchFragmentsParams}` : ""}`;
		$[0] = searchFragmentsParams;
		$[1] = searchFragmentsPath;
		$[2] = t2;
	} else t2 = $[2];
	const getFragmentsPath = t2;
	const [shouldLoadCopilotChat, setShouldLoadCopilotChat] = useState(false);
	const [searchOpen, setSearchOpen] = useState(false);
	let t3;
	if ($[3] !== isJumpToSearch || $[4] !== isSearchPage) {
		t3 = () => {
			return shouldHideTopNav(new URLSearchParams(ssrSafeLocation.search), isSearchPage, isJumpToSearch);
		};
		$[3] = isJumpToSearch;
		$[4] = isSearchPage;
		$[5] = t3;
	} else t3 = $[5];
	const [topNavHidden, setTopNavHidden] = useState(t3);
	let t4;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => {
			setShouldLoadCopilotChat(true);
		};
		$[6] = t4;
	} else t4 = $[6];
	const loadCopilotChat = t4;
	let t5;
	if ($[7] !== payloadsUrl) {
		t5 = (type_0) => {
			const url = new URL(payloadsUrl, ssrSafeLocation.origin);
			url.searchParams.set("type", type_0);
			return url.toString();
		};
		$[7] = payloadsUrl;
		$[8] = t5;
	} else t5 = $[8];
	const getPayloadsUrl = t5;
	let t6;
	if ($[9] !== getFragmentsPath || $[10] !== getPayloadsUrl || $[11] !== hasLocalNavigation || $[12] !== isSearchPage || $[13] !== searchOpen || $[14] !== shouldLoadCopilotChat || $[15] !== topNavHidden) {
		t6 = {
			hasLocalNavigation,
			searchOpen,
			isSearchPage,
			setSearchOpen,
			getFragmentsPath,
			setTopNavHidden,
			topNavHidden,
			shouldLoadCopilotChat,
			loadCopilotChat,
			getPayloadsUrl
		};
		$[9] = getFragmentsPath;
		$[10] = getPayloadsUrl;
		$[11] = hasLocalNavigation;
		$[12] = isSearchPage;
		$[13] = searchOpen;
		$[14] = shouldLoadCopilotChat;
		$[15] = topNavHidden;
		$[16] = t6;
	} else t6 = $[16];
	const context = t6;
	let t7;
	if ($[17] !== children || $[18] !== context) {
		t7 = jsx(TopNavContext, {
			value: context,
			children
		});
		$[17] = children;
		$[18] = context;
		$[19] = t7;
	} else t7 = $[19];
	return t7;
}
/**
* React hook to access the TopNav context.
*
* Returns an object with the following values:
* - `hasLocalNavigation` (boolean): Whether local navigation tabs are present below the main bar.
* - `searchOpen` (boolean): Whether the search input is currently open.
* - `isSearchPage` (boolean): Whether the search input is on the search page.
* - `setSearchOpen` (function): Function to set the `searchOpen` state.
* - `getFragmentsPath` (function): Function to get the path for fetching HTML fragments based on type.
*
* Should be used within components that are descendants of `TopNavProvider` or `TopNav`.
*/
TopNavProvider.displayName = "TopNavProvider";
function useTopNavContext() {
	return use(TopNavContext);
}
function TopNavComponent(t0) {
	const $ = c(9);
	const { children, className } = t0;
	const { topNavHidden } = useTopNavContext();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			left: Left,
			center: Center,
			right: Right,
			above: Above
		};
		$[0] = t1;
	} else t1 = $[0];
	const [t2, rest] = useSlots(children, t1);
	const { left, center, right, above } = t2;
	let t3;
	if ($[1] !== above || $[2] !== center || $[3] !== className || $[4] !== left || $[5] !== rest || $[6] !== right || $[7] !== topNavHidden) {
		t3 = jsxs(Stack, {
			as: "header",
			className: clsx("GlobalNav", { "d-none": topNavHidden }, styles_module_default$1.appHeader, className),
			role: "banner",
			"aria-label": "Global Navigation Menu",
			gap: "none",
			children: [
				above,
				jsxs(Stack, {
					direction: "horizontal",
					align: "center",
					justify: "center",
					children: [
						left,
						center,
						right
					]
				}),
				rest
			]
		});
		$[1] = above;
		$[2] = center;
		$[3] = className;
		$[4] = left;
		$[5] = rest;
		$[6] = right;
		$[7] = topNavHidden;
		$[8] = t3;
	} else t3 = $[8];
	return t3;
}
TopNavComponent.displayName = "TopNavComponent";
function Left({ children }) {
	const { hasLocalNavigation } = use(TopNavContext);
	return /* @__PURE__ */ jsx(Stack, {
		"data-testid": "top-nav-left",
		direction: "horizontal",
		className: clsx(styles_module_default$1.left, hasLocalNavigation && styles_module_default$1.withLocalNavigation),
		gap: "condensed",
		padding: "normal",
		children
	});
}
Left.displayName = "Left";
function Center({ children, className }) {
	const { hasLocalNavigation } = use(TopNavContext);
	return /* @__PURE__ */ jsx(Stack, {
		"data-testid": "top-nav-center",
		direction: "horizontal",
		gap: "condensed",
		padding: "normal",
		className: clsx(styles_module_default$1.center, hasLocalNavigation && styles_module_default$1.withLocalNavigation, className),
		children
	});
}
Center.displayName = "Center";
function Right({ children }) {
	const { hasLocalNavigation } = use(TopNavContext);
	return /* @__PURE__ */ jsx(Stack, {
		"data-testid": "top-nav-right",
		direction: "horizontal",
		align: "center",
		gap: "condensed",
		padding: "normal",
		className: clsx(styles_module_default$1.right, hasLocalNavigation && styles_module_default$1.withLocalNavigation),
		children
	});
}
Right.displayName = "Right";
function Above({ children }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children });
}
/**
* The TopNav component lays the structure for the top navigation bar within product.
* Use the `TopNav.Above`, `TopNav.Left`, `TopNav.Center`, and `TopNav.Right` slots to define the content above, left, center, and right sides of the navigation bar.
* - `TopNav.Above`: Content rendered above the main navigation bar (e.g., banners, alerts).
* - `TopNav.Left`, `TopNav.Center`, `TopNav.Right`: Content rendered on the left, center, and right of the navigation bar, respectively.
* Any additional children will be shown below the initial bar (such as Local Navigation).
*/
Above.displayName = "Above";
var TopNav = Object.assign(TopNavComponent, {
	Above,
	Left,
	Center,
	Right
});
function HideOnError({ children }) {
	return /* @__PURE__ */ jsx(ErrorBoundary, {
		fallback: null,
		children
	});
}
HideOnError.displayName = "HideOnError";
var GlobalNavBar_module_default = { noBreadcrumbs: "GlobalNavBar-module_o4ROGG_noBreadcrumbs" };
/**
* Valid octicon names for navigation items (breadcrumbs and tabs)
*/
function octiconNameToComponentName(iconName) {
	return `${iconName.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join("")}Icon`;
}
/**
* Get the octicon component for a navigation item.
* @param iconName - The name of the icon to retrieve
* @returns The octicon React component, or undefined if not found
*/
function getOcticon(iconName) {
	const IconName = iconName ? octiconNameToComponentName(iconName) : void 0;
	const icon = IconName ? index_esm_exports[IconName] : void 0;
	if (iconName && !icon) {
		let errorMessage = `Octicon not found: ${iconName}`;
		setTimeout(() => {
			throw new Error(errorMessage);
		}, 0);
	}
	return icon;
}
var styles_module_default = {
	appHeaderHome: "styles-module_iipd_W_appHeaderHome",
	contextCrumb: "styles-module_iipd_W_contextCrumb",
	contextCrumbLast: "styles-module_iipd_W_contextCrumbLast",
	contextCrumbStatic: "styles-module_iipd_W_contextCrumbStatic",
	contextRegion: "styles-module_iipd_W_contextRegion",
	crumbIcon: "styles-module_iipd_W_crumbIcon",
	notificationIndicator: "styles-module_iipd_W_notificationIndicator",
	repoPickerCrumb: "styles-module_iipd_W_repoPickerCrumb",
	repoPickerDropdownButton: "styles-module_iipd_W_repoPickerDropdownButton",
	trailingIcon: "styles-module_iipd_W_trailingIcon"
};
var RepositoriesResponseValidator = Compile(Type.Object({ repositories: Type.Array(Type.Object({
	id: Type.Number(),
	name: Type.String(),
	owner: Type.String(),
	nameWithOwner: Type.String(),
	iconType: Type.String()
})) }));
var ONE_DAY_MS = 1440 * 60 * 1e3;
function useRepositorySuggestions(t0) {
	const $ = c(26);
	const { owner, enabled, currentRepositoryName, currentRepositoryIconType } = t0;
	const [searchQuery, setSearchQuery] = useState("");
	const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== sendAnalyticsEvent) {
		t1 = createPersister({
			validator: RepositoriesResponseValidator,
			sendAnalyticsEvent,
			prefix: "global-nav-repo-picker",
			maxAgeMs: ONE_DAY_MS
		});
		$[0] = sendAnalyticsEvent;
		$[1] = t1;
	} else t1 = $[1];
	const persister = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (value) => setDebouncedSearchQuery(value);
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = {
			leading: false,
			trailing: true
		};
		$[3] = t3;
	} else t3 = $[3];
	const debouncedSetQuery = useDebounce(t2, 300, t3);
	let t4;
	if ($[4] !== debouncedSetQuery) {
		t4 = (value_0) => {
			setSearchQuery(value_0);
			debouncedSetQuery(value_0);
		};
		$[4] = debouncedSetQuery;
		$[5] = t4;
	} else t4 = $[5];
	const handleFilterChange = t4;
	let t5;
	let t6;
	if ($[6] !== debouncedSearchQuery || $[7] !== owner) {
		t5 = [
			"global-nav-repo-picker",
			owner,
			debouncedSearchQuery
		];
		t6 = async (t7) => {
			const { signal } = t7;
			if (!owner) return { repositories: [] };
			const url = new URL(`/_global-navigation/repositories/${encodeURIComponent(owner)}`, window.location.origin);
			if (debouncedSearchQuery) url.searchParams.set("query", debouncedSearchQuery);
			const response = await reactFetchJSON(url.toString(), { signal });
			if (!response.ok) return { repositories: [] };
			return response.json();
		};
		$[6] = debouncedSearchQuery;
		$[7] = owner;
		$[8] = t5;
		$[9] = t6;
	} else {
		t5 = $[8];
		t6 = $[9];
	}
	const t7 = !!owner && enabled;
	let t8;
	if ($[10] !== persister || $[11] !== t5 || $[12] !== t6 || $[13] !== t7) {
		t8 = {
			queryKey: t5,
			queryFn: t6,
			persister,
			placeholderData: _temp$8,
			enabled: t7,
			staleTime: 3e5,
			refetchOnMount: false,
			refetchOnWindowFocus: false
		};
		$[10] = persister;
		$[11] = t5;
		$[12] = t6;
		$[13] = t7;
		$[14] = t8;
	} else t8 = $[14];
	const { data, isFetching } = useQuery(t8);
	let repositories;
	if ($[15] !== currentRepositoryIconType || $[16] !== currentRepositoryName || $[17] !== data?.repositories || $[18] !== owner || $[19] !== searchQuery) {
		let currentRepositoryObject = null;
		repositories = [];
		for (const repo of data?.repositories ?? []) if (repo.name === currentRepositoryName) currentRepositoryObject = repo;
		else repositories.push(repo);
		if (currentRepositoryObject) repositories.unshift(currentRepositoryObject);
		else if (currentRepositoryName.toLowerCase().includes(searchQuery.toLowerCase())) repositories.unshift({
			id: -1,
			name: currentRepositoryName,
			owner,
			nameWithOwner: `${owner}/${currentRepositoryName}`,
			iconType: currentRepositoryIconType
		});
		$[15] = currentRepositoryIconType;
		$[16] = currentRepositoryName;
		$[17] = data?.repositories;
		$[18] = owner;
		$[19] = searchQuery;
		$[20] = repositories;
	} else repositories = $[20];
	const t9 = isFetching || searchQuery !== debouncedSearchQuery;
	let t10;
	if ($[21] !== handleFilterChange || $[22] !== repositories || $[23] !== searchQuery || $[24] !== t9) {
		t10 = {
			repositories,
			isLoading: t9,
			searchQuery,
			handleFilterChange
		};
		$[21] = handleFilterChange;
		$[22] = repositories;
		$[23] = searchQuery;
		$[24] = t9;
		$[25] = t10;
	} else t10 = $[25];
	return t10;
}
function _temp$8(previousData) {
	return previousData;
}
function shouldOpenInNewTab(event) {
	const isPlatformModifierClick = isMacOS() ? event.metaKey : event.ctrlKey;
	const isMiddleClick = event.button === 1;
	return isPlatformModifierClick || isMiddleClick;
}
function RepoPicker({ repositoryCrumb, ownerCrumb, onCrumbClick }) {
	const [isOpen, setIsOpen] = useState(false);
	const [isHovering, setIsHovering] = useState(false);
	const [isFocused, setIsFocused] = useState(false);
	const { sendItemClick } = useGlobalNavAnalytics("REPO_PICKER");
	const isCurrentRepoPrivate = repositoryCrumb.octicon === "lock";
	const isCurrentRepoForked = repositoryCrumb.octicon === "repo-forked";
	const lastActionEventRef = useRef(null);
	const navigableRef = useNavigableRef();
	const { repositories, isLoading, searchQuery, handleFilterChange } = useRepositorySuggestions({
		owner: ownerCrumb.label,
		enabled: isOpen || isHovering || isFocused,
		currentRepositoryName: repositoryCrumb.label,
		currentRepositoryIconType: repositoryCrumb.octicon || "repo"
	});
	const convertToItemProps = useCallback((repo) => {
		const Icon = repo.iconType === "lock" ? RepoLockedIcon : getOcticon(repo.iconType) || RepoIcon;
		return {
			id: repo.nameWithOwner,
			text: repo.name,
			source: repo,
			leadingVisual: () => /* @__PURE__ */ jsx(Icon, { size: 16 }),
			onAction: (_itemProps, event) => {
				lastActionEventRef.current = event;
				if (shouldOpenInNewTab(event)) {
					event.preventDefault();
					sendItemClick("REPO_SELECTED");
					window.open(`/${repo.nameWithOwner}`, "_blank");
				}
			}
		};
	}, [sendItemClick]);
	const getItemKey = (repo_0) => repo_0.nameWithOwner;
	const handleSelectionChange = useCallback((items) => {
		const selectedRepo = items[0];
		if (selectedRepo) {
			if (lastActionEventRef.current && shouldOpenInNewTab(lastActionEventRef.current)) {
				lastActionEventRef.current = null;
				return;
			}
			sendItemClick("REPO_SELECTED");
			softNavigate(`/${selectedRepo.nameWithOwner}`);
			lastActionEventRef.current = null;
		}
	}, [sendItemClick]);
	const currentRepoHref = repositoryCrumb.href || repositoryCrumb.path || `/${repositoryCrumb.label}`;
	const currentRepoName = repositoryCrumb.label.split("/").pop() || repositoryCrumb.label;
	const initialSelectedItems = useMemo(() => {
		const currentRepo = repositories.find((repo_1) => repo_1.name === repositoryCrumb.label);
		return currentRepo ? [currentRepo] : [];
	}, [repositories, repositoryCrumb.label]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(Breadcrumbs_default.Item, {
		as: "a",
		href: currentRepoHref,
		className: clsx(styles_module_default.contextCrumb, styles_module_default.contextCrumbLast, styles_module_default.repoPickerCrumb),
		onClick: onCrumbClick,
		children: [isCurrentRepoForked ? /* @__PURE__ */ jsx(RepoForkedIcon, { className: styles_module_default.crumbIcon }) : isCurrentRepoPrivate ? /* @__PURE__ */ jsx(LockIcon, { className: styles_module_default.crumbIcon }) : null, currentRepoName]
	}), /* @__PURE__ */ jsx(ItemPicker, {
		renderAnchor: ({ "aria-labelledby": ariaLabelledBy, "aria-label": ariaLabel, ...anchorProps }) => /* @__PURE__ */ jsx(CommandIconButton, {
			...anchorProps,
			icon: TriangleDownIcon,
			variant: "invisible",
			size: "small",
			"aria-label": "Switch repository",
			commandId: "global-navigation:open-repo-picker",
			className: clsx(styles_module_default.contextCrumb, styles_module_default.repoPickerDropdownButton),
			onMouseEnter: () => setIsHovering(true),
			onFocus: () => setIsFocused(true)
		}),
		items: repositories,
		initialSelectedItems,
		placeholderText: "Search repositories",
		selectionVariant: "single",
		loading: isLoading,
		filterItems: handleFilterChange,
		getItemKey,
		convertToItemProps,
		onSelectionChange: handleSelectionChange,
		onOpen: () => {
			sendItemClick("REPO_PICKER_TOGGLE");
			setIsOpen(true);
		},
		onClose: () => setIsOpen(false),
		title: "Switch repository",
		width: "medium",
		improvedNoMatchAccessibility: true,
		noMatchMessage: isLoading ? {
			variant: "empty",
			title: "Loading repositories...",
			body: ""
		} : repositories.length === 0 && searchQuery ? {
			variant: "empty",
			title: "No repositories found",
			body: ""
		} : void 0,
		keybindingCommandId: "global-navigation:open-repo-picker",
		selectPanelRef: navigableRef
	})] });
}
RepoPicker.displayName = "RepoPicker";
function toContextCrumb(crumb) {
	return {
		crumb_type: "unknown",
		label: crumb.label,
		is_root: false,
		href: crumb.href
	};
}
function useRegisterContextRegion() {
	const $ = c(3);
	const ref = useRef(null);
	let t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			const { current } = ref;
			if (current && getContextRegion({
				source: "react",
				silent: true
			}) !== current) registerContextRegionHandler(current);
			return () => {
				if (getContextRegion({
					source: "react",
					silent: true
				}) === current) clearRegisteredContextRegion();
			};
		};
		t1 = [];
		$[0] = t0;
		$[1] = t1;
	} else {
		t0 = $[0];
		t1 = $[1];
	}
	useEffect(t0, t1);
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = { ref };
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
function ContextRegion(t0) {
	const $ = c(19);
	let props;
	let ref;
	if ($[0] !== t0) {
		({ref, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = ref;
	} else {
		props = $[1];
		ref = $[2];
	}
	const { sendItemClick } = useGlobalNavAnalytics("CONTEXT_REGION");
	const { searchOpen, isSearchPage } = useTopNavContext();
	const { onUpdateCrumbs } = props;
	let t1;
	if ($[3] !== props.crumbs) {
		t1 = props.crumbs || [];
		$[3] = props.crumbs;
		$[4] = t1;
	} else t1 = $[4];
	const [crumbs, setCrumbs] = React.useState(t1);
	let t2;
	let t3;
	if ($[5] !== props.crumbs) {
		t2 = () => {
			if (props.crumbs) setCrumbs(props.crumbs);
		};
		t3 = [props.crumbs];
		$[5] = props.crumbs;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	useEffect(t2, t3);
	let t4;
	if ($[8] !== onUpdateCrumbs) {
		t4 = (updateFn) => {
			setCrumbs((prevCrumbs) => {
				const newCrumbs = typeof updateFn === "function" ? updateFn(prevCrumbs) : updateFn;
				onUpdateCrumbs?.(newCrumbs);
				return newCrumbs;
			});
		};
		$[8] = onUpdateCrumbs;
		$[9] = t4;
	} else t4 = $[9];
	const updateCrumbs = t4;
	let t5;
	let t6;
	if ($[10] !== updateCrumbs) {
		t5 = () => ({
			pushCrumb: (crumb) => {
				updateCrumbs((prevCrumbs_0) => [...prevCrumbs_0, toContextCrumb(crumb)]);
			},
			popCrumb: () => {
				updateCrumbs(_temp$7);
			},
			replaceCrumbs: (newCrumbs_0) => {
				updateCrumbs(newCrumbs_0.map(toContextCrumb));
			},
			renameCurrentCrumb: (label) => {
				updateCrumbs((prevCrumbs_2) => {
					const lastCrumb = prevCrumbs_2[prevCrumbs_2.length - 1];
					if (!lastCrumb) return prevCrumbs_2;
					return [...prevCrumbs_2.slice(0, -1), {
						...lastCrumb,
						label
					}];
				});
			},
			replaceCurrentCrumb: (crumb_0) => {
				updateCrumbs((prevCrumbs_3) => {
					if (prevCrumbs_3.length === 0) return prevCrumbs_3;
					const updatedCrumbs = [...prevCrumbs_3];
					const lastIndex = updatedCrumbs.length - 1;
					updatedCrumbs[lastIndex] = toContextCrumb(crumb_0);
					return updatedCrumbs;
				});
			}
		});
		t6 = [updateCrumbs];
		$[10] = updateCrumbs;
		$[11] = t5;
		$[12] = t6;
	} else {
		t5 = $[11];
		t6 = $[12];
	}
	useImperativeHandle(ref, t5, t6);
	if (!crumbs || crumbs.length === 0 || isSearchPage || searchOpen) return null;
	const lastCrumbIsRepo = crumbs[crumbs.length - 1]?.crumb_type === "repository";
	let t7;
	if ($[13] !== lastCrumbIsRepo) {
		t7 = lastCrumbIsRepo && isFeatureEnabled("global_nav_repo_picker_experiment");
		$[13] = lastCrumbIsRepo;
		$[14] = t7;
	} else t7 = $[14];
	const showRepoPicker = t7;
	let t8;
	if ($[15] !== crumbs || $[16] !== sendItemClick || $[17] !== showRepoPicker) {
		const repositoryPickerRepoCrumb = showRepoPicker ? crumbs.find(_temp2$3) : void 0;
		const ownerCrumb = showRepoPicker && repositoryPickerRepoCrumb ? crumbs[crumbs.indexOf(repositoryPickerRepoCrumb) - 1] : void 0;
		t8 = jsx(FeatureFlags, {
			flags: { primer_react_breadcrumbs_overflow_menu: true },
			children: jsx(Breadcrumbs_default, {
				className: styles_module_default.contextRegion,
				overflow: "menu",
				children: crumbs.map((crumb_2, index) => {
					if (ownerCrumb && repositoryPickerRepoCrumb && crumb_2.crumb_type === "repository") return jsx(RepoPicker, {
						repositoryCrumb: repositoryPickerRepoCrumb,
						ownerCrumb,
						onCrumbClick: () => {
							sendItemClick("CONTEXT_REGION_CRUMB", `position:${index + 1}`);
						}
					}, repositoryPickerRepoCrumb.label);
					const href = crumb_2.href || crumb_2.path;
					const isLast = index === crumbs.length - 1;
					const Octicon = getOcticon(crumb_2.octicon);
					return jsxs(Breadcrumbs_default.Item, {
						as: href ? "a" : "span",
						href,
						className: clsx({
							[styles_module_default.contextCrumb]: true,
							[styles_module_default.contextCrumbStatic]: !href
						}),
						onClick: () => {
							sendItemClick("CONTEXT_REGION_CRUMB", `position:${index + 1}`);
						},
						children: [jsx("span", {
							className: isLast ? styles_module_default.contextCrumbLast : "",
							children: crumb_2.label
						}), Octicon && jsx(Octicon, {
							size: 12,
							className: styles_module_default.trailingIcon
						})]
					}, `${href || crumb_2.label}`);
				})
			})
		});
		$[15] = crumbs;
		$[16] = sendItemClick;
		$[17] = showRepoPicker;
		$[18] = t8;
	} else t8 = $[18];
	return t8;
}
ContextRegion.displayName = "ContextRegion";
function _temp2$3(crumb_1) {
	return crumb_1.crumb_type === "repository";
}
function _temp$7(prevCrumbs_1) {
	return prevCrumbs_1.slice(0, -1);
}
var editors_default = {
	vscode: {
		url: "https://marketplace.visualstudio.com/items?itemName=GitHub.copilot-chat",
		icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAADU0lEQVR4Ae3UQ5hkVxjG8Te2VtkEbcTOKl7Hy9hqu4u3PfasxvYU2rZRU4xzt3Ep1pfv3gqmcGqeaYy63uf5738X5yCxxBJL7MS7UBpced06x9cZzT9sy2r9OQlnzNaNXQ199yFoOgglTZTR+EOoJoYeDWTgtK6u63roumwcobKdUGRlXDCsTEvAnHnYdx9O+aTeJOh6voCWcdpOQgUDCy2UYQnGLMsarDq1OE2XDA3D/q2ijVBgUjGicEpW3nk7tB3fKf9cWOWthHwTpZuDwjDrbfzkLn4rl54Y1/0wKju8yueMqqyFkHeU0k1BYZjV1n5oxBo3YY1HxjJnKkTTdL6M8va/YuHUz1uqAI98l340SKJwsmNYHVYz7v9+wmpPQfSb68hHOSOEtSrAPhSYktKOBEkUTnYM8mOVi6Jzb1XvN2UlzUb17ZS1xqltNQ4evAC8tMMBEjQL4Er3i4z5AysZFRFDZRRa1yLPRChqJIYSQyPzMvApHLe0QwEShVltuftBLHd9ixVOimqZnfi/I+QcJhRYCMVNIWgI60BFaxJ4CwpUV8OHYwW/seWMipW2h/D+QQq9TSvXtB6FBy9DjKUeCJAozGkNtiQsY+RSBsWqbpqQc8SL3MOvI2ynCviuKQkfHJFRM8kghygvltrfiAvcHyBRmPUKjmYj3yKr/9p7BwjSKKHBESd7PSQ6PyZwX4BEzRLXfBfjvBwhz0wq8t39BE0fod4ep2NO9beIWMpePwmaBTDf+vx/uH/LNRE+YOTbu79AzdRm1NlJFENl1NqfDwPu8ZOgWQBzLX8oby2qHPNWFJiuhbIam4S6YxQ/u7QwwJyjy9U39n+/IceUj/CFkDUMEWYjVE2O8b+blLzLT6IwmzFI4hScjBxrFkSrcXyAahsJkyYJFf3y7IFxkZb7/v2kcWeYeQJVNi9H4c0QjBOE8l5K3uEXhlOyGnsmJJsMaYbCMjCwrOcMAPIYmATjjMxRqGmCfpxQ2kNJ2/zCwDu1SP30JzBMk5qOgSXdDPHF7OZt3y/DKZ924kbopu3QTxE0Y4RiBm71hcW43qRt3kdx2lY2dBW0062oVIA9dPMWX6itvu7TC4tcxdiaa5d+8lXS5u/3JW/x3onEEktsEe1vJvBZCyBp9isAAAAASUVORK5CYII=",
		name: "Visual Studio Code",
		eventName: "VSCODE"
	},
	visualstudio: {
		url: "https://visualstudio.microsoft.com/github-copilot/",
		icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAEdElEQVR42u2YW0wcZRTH/2dmdrcgbWkxbaIiW43lEox98tJEk+qLsfWC2gdrYvpgiBcUajWtEMlCGlMTtQ9WKy2JbVrbilqsGvWpGCyGRLAUEKjVsmVpmkIKyK24O3OOcYcOm90ZFlgaeNjfzMme2Uwyvz3f950vs0iSJMkioPiZ40XbCo7uPPOZpGOxsb2gpryk4Ji89sRhOVnZ3X22Wn8cs0DBDeSNZ7/cLCQVEIBFhwh7FSjftlYbH51+r3/pggqWbK5ZJ8LVCCNg4XBABCQoWpaxsrVln75p3gRrfIGVJ3yBp2t93emIw86nar2KgVoSWoYoZDIg8CoafddSpVe1HZDVCQkeL+u+X2VuZuavDUP59aSv5xZHuS3frwgqoToA3hg5kZggQiELN7bsl7VzEvyq3F+mqUqDWA+U3JDO9Z+XdWQhisLCKldwYvyIKeeA2IV4hUKlsEGDAyfe7c3ga/pBAm0SWONifhDudCGl7mjphQcAXMEkTV3NFYA8BkckfNhigGZcwa2P7vGeavzxzJWhy5acQGDlEs7WqESN5KZwtZo7m8oBeRvTIHFixoISQtnw2GhmQ1s9Bob7TbUpUTM1bb0UlLrzvV07hFCBeJg/zjYAmbkgQXEBgKa60dBej9GJERs5S9ubtcq7W1MVxINUGrMvXwJtRgQ4ffYUJkLXouUsaY/bg/w1+TAlBXaopL7lXXX7TwL7g3nObYYQ1HV0XGw/JEJGtBwmc03VkJuVC4/bZUlat0F5BcD7nNgcdIZIQe/Vnp9Z9Bej5SQid2se5GTmYYnbbd5EElJZfQHAPiCeHc9C0PnWg2xIaaQconJVVZGdmYubUlLHYOA5AEemqsmOi4Tnay9u7Gh0B/r9lpDYzEtFUXHXbdl0T/a6cUTCgDgckIQryGg693uxprl8vX2XMDQ2YAnFzEszSSWhH/LX5j8fvxeaJCAo8Cip9zJjj9l+luB84E+Mjo/EylkVNa+JcfjuO/JfBQAWZ0PhBIc4LXX5y0QgTEKk4VygE0E96NAjBeGTQCDszfHm7gAkkUbtzIqlq6GQFtN+BCo6ezoQMkK2PdK6EgEz7x4YHnpkXoZYSNh8oIHlaTdDVVywg0AIhXT/yNjgO9FyYslZ6xyG6OlOY8wyC0HSpVJRVf/S1Ay4VA+mwa9PGA8C2EUQnzlSU1WTSTnre8eY/SLxp6fduj7Fk3YIzrQzGxsA9MKkAiKfRFfNsjNxmoNzatSXAWwVyJs20+QvI4SNAPyIICXN2CbCv1hy5glr2QgcMRjGXBfJB0R63nUZIulg/PsQgB7EElRcVADw3xIpZ15Ms5NwH9i1K5E20zUuE/cRyRZNofVmdR25KuzeAMJFq60gQjYqDNE/FjfnALiQ6FbXB+AYgH8Qn4Bu8EYIDSMCEYpcGZeI8DCAIgCDC/Hi/ocBKbzedogUEAgCgFn/wqWG8gDUYaE5UNy2vaqkVfYW/SbfVAb89R8OPonFxv7X2176tLil4v+X/uRfaUmSzDP/Ab1LFlwLY+97AAAAAElFTkSuQmCC",
		name: "Visual Studio",
		eventName: "VS"
	},
	xcode: {
		url: "https://github.com/github/CopilotForXcode",
		icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAIE0lEQVR4Xu2Xa4xdZbnHf8+67cval5k9s2emM6VDO5Taljb0QiK2B4whQTGKRvmgMSZ+ICqfxBgh5KAmAjEEpYgGY8CIogQvMRT0cEiM5xChtrVAoaVMgaadTqczncue695r7/W+72OdTAIfAKWDwZj+knX5st781n/9n5W8/IdznvMI/27ccsu3Nt/6ze/cfvsdux6+664f/vbOO3/wo3vuuf/r9913/xZA3us3lG2X7bi5mbRuUKEahpnMxRdfTG9PN1GUIY7j1/ww/N7YyGsP3Hvvvc13TbDvwb0drmvdp0TdWvWIkcBHnQCCIioqAKQpbvxUZMaHQ2ZrQW7q9KWZZ58cGGgv0LtiBWEYEUUh5VJlqK2cu+6mm766b7mCsmL35FfwuE08Lz8Qe/TnPTKe8GY4k5LO1kimxmjNTtNcmMPUJhjb/TOK+SyVSgfFYol8HNPT0z1Uray88sYbv3CctyF4W7lHx29EvO/urAQUQnhu2vL/sxaLAqBAMRRKvmBRRMG1cky6Kk2/gPqzWIFsoZuxwX0UikU6O6qI5/HyYVl19Yc/fmTXrgdmZmZq+3p7e264/vrPDf/Tgj3f/0MnTm7b2elzbM4ykjgUEMBDKEdCIMpUS5l1DgRQQCPycUSp2AZpO2OeT667j2g4Zma6RtKos37DVg4efRX7P49lV69ek924YfM169ZtaL6zBCsbrsN5uViEkXmHAgAZX8j5MFV3+AJWob/gkxhFBBKr1FpKIoK6LNW2DtYVAsymLYyMnKR961XM5UvEF2xndN8TvPT7R+lbserXV1yxdYI3weMtUOetvSj2eH7SoE7BKp2BEDil1nDkgPZA2NkZUBRlbexxbW/IJ3vDxWtJQB2YU0OUSCkUCgT9m9nvVSlXOpiOq6zcsuOJqz762TPlcucdgL6TBAVLsT/r8X/TKShEHtRbSt0o5UhILUy0HPMZYXjOsaHP569nDFkfjINaQ+mKlIvGDpCalKSZcrJnG0HlAjpXdxMwy4up+YX3yK2f+d0vp2ff8ZCo0SACnFEEiBDmW47FoRA4nSo4ZWjG0ZkR5pvK6JxlXbvPn0dTBKX+ymH60knq2YgXTRv+WTm/uoZCTxfB/CyBgzPT09PnNsWp9XEKRskHwnziiDwhcJwVcRinAEwZy/s7IgYnDdVIqC0oYhSc5bLJfRhjmE8so9VLiEq95OIKXphFIkXjDv4R3lsLAgbUvH4fqWJTJW0tioOBzsBjfN4x11BCBx2RoKnSeeIAqzMpuWzEobRC1LYCG7XhSQgWcB6QBeDcErSAU0KnNIyCQiHyGK07XkfZ2OYzOGVYWfAYm7OcqFkuz03TePlx6isrTEzXGWvfRjbXiXh5PCvggBSAZSRoFCyEVnCpEjlImg6MsnTQlxVm6456ooiFjsgjbVqOP/YTpoYGOfziC+w7o1DoIsiWQX1MyyF2af0Wy0zQKjZdlMILoG4AqwCowsZKwLOnUzZUAvYMt+iJPeLTh2i98jSZYp7Z+XmmOgfwsh04smDAWMVb6jbWLUMwdWBBDGAUVaH1hgUv6414fjglFKE25xCjjNVSup96gEwUEPjCcKsClTVIWEScD05BQC2QKqTLStChVsE4PAvdsbCmEuEA62BzT0g1K3TGPidqhmpfxPE9j5NOnySKsywsNKiuv5KNA11kO0pkshkOnEppGcUtDRh2OYItFAfNpuKJ0Bt7vDCcYpySDTyOjqbkI8G6lNCHhZkZ3P5HyIUBvu8xZgqs7F6PDcoM1YRUUwZKHofPGLCgix20yxA0KFbRVAkDIfaFS7pCnFMSo4AsihkL4Jh+/jdE6RxRnKNeb5Bb9UGGGmV25GMiDfB8oZkqvgWWOohbzhQ7FAssDcYfjzT405EEnHLgeIupOcvBoRZ7X0vYe/A4OvjEYvd8XxhPsvjdm4jjCntPgK/wzNEmL51KaTTe0G27HEGzJGiVesNRDDwG2n1GJiw5EcqhsFB3iHXkD/2cbKCEYUCjkTDXdiljrXb6q2XSlpA0lbwPWVnsH6IKy/7EltbsgiVQoWUczaZj5YqQPa822dofMTia4lmF0efI154jygX4njBeD9C+zcT5duaSgLUdASNThkv//uyxJgCy1EFNkuRcE1RSOzN4ynBRxQcDrUR5dSTlyrUZTk9ZZuYcBc8Sv/IQUSCEYbiYXtq+mVK5C/wCx8YcAcJAJeAvR5tgAQvzDYdYsDMnh89VEFefePbMtGFddwBWUaNnxQxPHUlYqFvyvrIw+CSZ5ghRGCACk3WhXtxM3ZVpphHlyOPsGmflkqVflhIBzgDWNqZeuPulZWyaqoXuL+4/fEFnuGp9X8j/HmwgIiCAQo45cvu/RlbmyeeyNJMGI94lxOs/gV9cjZfJU6uDc8oSZALh2u15frVnAZuM/3jiwW1fBty5dZDxhebR3Z8fMh/Znaa50tWbcuQiIfDAOmXP4w/hzCxRPoMnUE9Stn/oA5R7u8mVS3h+AAigiAhzDYcCjzw9Dy4dbDx1wzcAt9xtp1/auWt75sL/usvLVneoqqAgZpbygS+RzwhxPkuzmXAyXU3a/2n80gBeWAARAHTphICoS8zC8MONZ27+7/rJp0ferY27ALnMmmtW5i782EYv11WV5mSmeOzuW5NGvVoulzHGNWuFy2/Sti2GfBeeF7AETlAxzcTOHBtOj/70UH1icAJo8S9EAG/gfZu2rd2wfXd1xapaX/+6bwMBIG95vAcIkAXKQMh7w3nOc56/AWSl7okwRobRAAAAAElFTkSuQmCC",
		name: "Xcode",
		eventName: "XCODE"
	},
	jetbrains: {
		url: "https://plugins.jetbrains.com/plugin/17718-github-copilot",
		icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAADsUlEQVR4Ae2WA4x0VxhAz3fvG71/f9u2GdRhHdQ2wtq226i23Qa1bdu2tXi6t/PuZCdrzaKYk5wxzvNHlSpV/uV4VMD0I/8a+6uxt9R5+bUj5SlLj6gHTuNEOanXAyX4a1tfZddFFHVAMZIeRBaAA4HuBdrjpw0z2B2L1tAMg8ivn3vH1d5YEzfsr3Q5qZLIYd3exIb4UYssk2bVAkYXHcHdh2903El/RtNAACqP7G5gGtc8TEGSKu7+ydrN5/o2gDZSaoG4lyI9OsK6mLLHPvkLL38bENgc7yUXEouQiMIUTSiaPlcaKwooKrRm/CrY4KReCIx1s7iixbiQ+z+rBVKfpT9QtEfgNVNCDxIhZeONN+aMM84oO3PmTFKGDRvGmWeeydixY/shMMw4JfKcpIFWSPF9n9WrV3PooYe6mCFDhpQDDznkEMaMGdP3gRJ6ToJMWYyQctttt3HOOeeQstdee/Hqq68OxCbWv5AGOnVJo6iAXg6MMr8TNAZmnNZoKkUsSG8E2sB70cUFJYOGQfwaDSdl1KhRjBs3jpS5c+eSzWbdPrnDDjuQ8v3339Me2iZkTIz0wj74sQssyQ+1E9EYAHdwXHbZZaS8+eabrLvuurzwwgsceOCBHHnkkfzwww+0h8LiJ2EpspLzoIqyX5kISBQmzhLX+2hTDnQ2RUToCtoY/DhoflnsSWBcp15XViOJEAU++ThGY6gUbQ1+4gKbR3Y30KvXX1vlQaLQdR6+CtC2FwJJ8OOw1YARdjeQfMNX/DWsjlD7mdj0WqCypX2Q5mPSB90OlMcei82SLT8mVosBsiZGm97cxLaUJvJGHLFTj6YZCfWHFhaXn1Nit912Y+utt6YtrrrqKm6++Wbaw7OGQXGAImFF5rmbLzhnp+1AbI8CDXwgtMSd59zphXbe6whlDfP1W+w76hSm5z549QJ2tj2eBxXyvsXSknvuucfZExYUXuW08buhxPTCwIr9hiasLAxvPc+KKonCiBAr7e5Lr2kSEYwohhS+Z2juR1ZNiFDSWxN1FL5GJksjJ41aTEtC5VHn5ajTqVlqGx97WXffkFXMnfoQSye81fsjv3x85w9m3rYR2AztkDUxxJSxQpmhQ7608xfeKTWFH2kTyxOVBDosfCwwD0fHkZaSWDGJ2BNWrrnmWmzDVliEpigMCS/KcTxbeaDIC2KtC+xKpMDziUS7zX32snd5lpQze3sebIZWch7Ch3SCFX7LmOSE4SOmrD3tlWKco0qVKlX+Bkezo4mAppNyAAAAAElFTkSuQmCC",
		name: "JetBrains",
		eventName: "JETBRAINS"
	},
	eclipse: {
		url: "https://marketplace.eclipse.org/content/github-copilot",
		icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAT9SURBVHgB7VhrTFxFFD5zHwvsCgWUUkWXhR802PoDKw/RKI2JjYl/TKXxb21jqgnaVDE12qb4qDGpPDQVaWyNj8ZKHyE01aA2UBVrf2AF2h8oFBCQthjYheXu6945nnshhH3Bvvi3Hxnu3DtnzvnmzJwzMwuQRBJJrAgGcWCmITPTbEp/yocsF5DddnilX/JeHRqDBCJqgkikXKaMFxjCTuqsjDhMrUd+KJz9fTzjQVJXCQiWRc0aydg5wBA9z/tU8eLA2Kl/IUpETBARmPcTay1H2E9V34jdXLfj+OZ7SEMNNWdEooLKCaZqh/v/OXcDIkREBJXGu61MlL4AxqrIytld32zu6Z+0vEZN2RAlqD8XkB3uH249EIn8qgRdH+cWAEvppGo+cqyvaCrTOAq1ECdoRjo8DueOwenvZyFWgjMNG2ypkqmLpPI1ZA0P15c6kbG3IM7gWjKOeIUpaU/03fpqPpyMEK6htRpEIndBJ4eIPY82lc4SuQOJIqeD9JVrZk/jSjrDEny6ylpL3e6nqu/Ty3n7Vc7ehDUAY7h7k237c2HbQ310HrVtEJFfp2q2CELzlg8fKqbRVsHa4XaKK6ugZ/KYEtgQ0oOI2m5YiFD1jQu2biL3OKwt1rtTp/eFaghJUAK2bbF6qWMgZyskcN2FA2PsGQjJJQB6zqPHI3qdPNcmccvXquiugzWDi0pa2FYp+Itpi05Nr3b+lT2pMuUl5DxsMMUPmYpq1DYWbG8fGD7b50cnUJwB37Q4o/xQh+0/Slan2cL7wj8mQKJmnNa637uMQFs3rEyQcyYLhr+Q56Vi75AnIHpFERIFpnLwJyOPBspIEL473PK6BIHJhhZK1gtuIw9Ki90YCLRj8ZjdqRoOU5fe3fS3KkFBRK++BBlt6znrxLIbbvxukY0BE5OASC8bRqwe1Yem+ttG4SA93l2RIC2yUf3IQUcq6eWK8flX2osOwrJFh4ZI/NPMwasfGNDPNGB7oFwQQRSlnxk3FodQXmAvuT505j3w17OGYEGGQq4f91HrHzS6EmJ5say+vJcmvGZ5+x1pOUwUUyBWcK6C03WTlvWyj8i7rw2f2RooGzK/aQhtRiODx0ry5n+j3vLyonimJYFJMRevb04idrK/XvZTKC4hCXotwkc0ODvNrHysur+S/NwV6IF59xQIAgWMIEdVPD4HFWeARRy9K3/qg4gJZu0csXOGRjQxgdU8X36zhUjO+Q2CjMzOTxjRLhLR1YpAgaV4pkBxTwcbRPZOV1eXGjFBHRZIb6G9+CpV5T2VI3vvNPsaA2V8qgIzc6Pg9tqNHUYwUlBw0Qdjd46Ayz0TZIfWd8u14dPHw/FYMckqLYVWYnGJhGwc8f2KxnKV8nXIyw6dRkAWzSBJqUaeRErAPtUNKhWOamgDCJfXmTzbugfa52IiqMNVby1EGTuJgJVz/nZlUwXTwpCMCgg/WkTTs1cGT8Z+aVoi2Wyz0QXnHN3qSvRrZ/WJB34dtVvogIn3QfRQSVdd/7CeX1dPsJFf3A+B4F1vrdU4e50MOHom0j9/sbU4l3acXdScGoEKjfbub2lzP9I7eOoqRIjof/r47N5sRRGqKbr36CeICYfpy71tG2fHZsxPkjuKyCdZuBB8une8tDf8iUzopJR0vm/w5DhEibgOdthclKeo3lJB5MWaTxxXNak7c9/fEf+skUQSSSQA/wNnnfrXHIximwAAAABJRU5ErkJggg==",
		name: "Eclipse",
		eventName: "ECLIPSE"
	},
	neovim: {
		url: "https://github.com/github/copilot.vim",
		icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAADmklEQVR4AWIYimAUjILio8nydUciaknRU7fdOZ5ujis7nHKt4WjI7e7jPg7E6gPQYg4wsmRhFI65tr0bc8L1tqtmjThr22yOFa2tZ3aPPW13P9vmGPHgntv1p2+/10qqepKTWzXqL+f85xZsvfoRpn8qDxd4Y9eXwTfmANgYsXibQ09eWjZgj37R1mv8p2JwXwRe38U0xzSbAZRSjWHZWR6gwWvrMSwy0AVbt8ZOmjw/3UrOARACYFNUTkGNseqqUv/D2qP3wkGSZpC3tp+/6dr/dvW83P/dKADZ/M1RxM0ROdnEXZQ6S0VtA2A3h1vQFPJaz2jH9Z7R1J3/+XZ95H13hhx0hV/Y3xSRU80RKQkXm8PSZ8UBlYh7ciHt3TqnKsDrPeMp6Nq1p9KPrf3tKMXsDL1wAIAEiZWiLhHxAmTt0XFIh9pmX+ceTcPB692jqeuW7d/yUt+3o18EMzMIMETMQdlx/qgJ0ECAotQXhuCwQnf9H9j5uf815iArCcEJoqjztzgXjhzUJGI4ydf1p9PmDT8ch4PcNUAy8bVI1NgHrQoUKbPl6NQDwkHoWsgzlrx22b4tHwy8sQMwfKsJA5Qg5XytpogXNI8YUFDGySzoA56Nnyuzp0imlSA/u7gkhkVqMh2rjxhwooN07jn/BHPsTSqICEeRNwYp6gygVQFDgyFNIuaRCiUhNwGIGBlIpwAFQKxKq+WV+bYZmkVAajKDEDmHYwLEz1EIAiQ3aV+EmmPVb4o3CxDFjCuLvUf3typAEYyiFgHxhXnjrkUzgCRytSEu32fNXuoITpsZvFZoL0UMSBGQoqaI0WqxPOyavZIArcJVxArIbg2uJASFY4IUASlqBSpNoKJcQ6aT5BoAAYpz9TNIzSUX8ziYjbr6MyoJJB7XBywz9t7sDHInAajJtZigCPKCGRSjZg525DSa1pA0Xes1U0F4xNo4qLgmliWvg7lRp8V4cQ5A5uKic9CE2SNIbSMmFQMUW02XQt7koIUDQvZeg+IeB/Wq3KjHO8TtpZSDYtRoM4FmAM0cEFFTSdjqVgV4DW753aOdcBFxYyZLAeZu4BAApWkGyQGzURs2O92PXqEKUIQsM2IR8jNyEYAEx0H95hw4zSDR4jIBKWovdxAlARhiDkqbnd6nBTgNIRlcp7jNlHSRvX0QASsGJ0KiOGUBkpNRqa0hZBmtOJwIeY37fFXZgIg6bHZn4ZY2csAoGAWjAABsR6I9D/NVgAAAAABJRU5ErkJggg==",
		name: "Neovim",
		eventName: "NEOVIM"
	}
};
function recordMenuClick({ eventName, menuLocation, mode, action, text }) {
	sendEvent("dotcom_chat.activate", {
		target: `${menuLocation.toUpperCase()}_${eventName.toUpperCase()}`,
		text,
		category: menuLocation,
		action,
		mode
	});
}
function EditorMenuItems({ menuLocation, mode, onItemClick }) {
	return Object.entries(editors_default).map(([key, { name, url, icon }]) => /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		href: url,
		onClick: () => {
			onItemClick?.();
			if (copilotFeatureFlags.freeToPaidTelemetry) recordMenuClick({
				eventName: key,
				menuLocation,
				mode,
				action: "menu_item_click",
				text: name
			});
		},
		children: [name, /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx("img", {
			src: icon,
			alt: "",
			height: "20",
			width: "20"
		}) })]
	}, key));
}
EditorMenuItems.displayName = "EditorMenuItems";
var useEntitlementData = () => {
	const $ = c(5);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["copilot-chat", "entitlement"];
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			queryKey: t0,
			queryFn: _temp$6,
			placeholderData: { licenseType: CopilotLicenseType.Unlicensed },
			staleTime: 3e5
		};
		$[1] = t1;
	} else t1 = $[1];
	const { data } = useQuery(t1);
	const t2 = data?.plan;
	const t3 = data?.licenseType ?? CopilotLicenseType.Unlicensed;
	let t4;
	if ($[2] !== t2 || $[3] !== t3) {
		t4 = {
			plan: t2,
			licenseType: t3
		};
		$[2] = t2;
		$[3] = t3;
		$[4] = t4;
	} else t4 = $[4];
	return t4;
};
var usePlan = () => {
	const { plan } = useEntitlementData();
	return plan;
};
async function _temp$6() {
	const response = await verifiedFetchJSON("/github-copilot/chat/entitlement");
	if (!response.ok) throw new Error(`Failed to retrieve Copilot chat entitlement (${response.status} on ${response.url})`);
	return await response.json();
}
var GlobalCopilotMenu_module_default = { proLabel: "GlobalCopilotMenu-module_IsWAJa_proLabel" };
var analyticsMenuLocation = "global_copilot_menu";
var mode = "global_nav";
var recordClick = (id) => {
	if (copilotFeatureFlags.freeToPaidTelemetry) recordMenuClick({
		eventName: id,
		menuLocation: analyticsMenuLocation,
		mode
	});
	else sendEvent("dotcom_chat.activate", {
		target: `GLOBAL_COPILOT_MENU_${id}`,
		mode: "global_nav"
	});
};
function redirectToSignup(returnTo) {
	window.location.replace(`${window.location.origin}/github-copilot/signup?return_to=${encodeURIComponent(returnTo)}`);
}
var openAssistive = () => {
	publishOpenCopilotChat({
		id: "copilot-assistive",
		intent: CopilotChatIntents.conversation,
		newThread: true
	});
	recordClick("ASSISTIVE");
};
var openImmersive = () => {
	window.location.href = "/copilot";
	sendEvent("dotcom_chat.activate", {
		target: `GLOBAL_COPILOT_MENU_FULLSCREEN`,
		mode: "global_nav"
	});
	recordClick("IMMERSIVE");
};
function ExternallyAnchoredGlobalCopilotMenu(props) {
	const $ = c(8);
	const { ref: anchorRef, open, setOpen } = useExternalAnchor(props.reactPartialAnchor);
	let t0;
	let t1;
	if ($[0] !== props.defaultOpen || $[1] !== setOpen) {
		t0 = () => {
			if (props.defaultOpen) setOpen(true);
		};
		t1 = [props.defaultOpen, setOpen];
		$[0] = props.defaultOpen;
		$[1] = setOpen;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	let t2;
	if ($[4] !== anchorRef || $[5] !== open || $[6] !== setOpen) {
		t2 = jsx(ActionMenu, {
			anchorRef,
			open,
			onOpenChange: setOpen,
			children: jsx(GlobalCopilotMenuOverlay, {})
		});
		$[4] = anchorRef;
		$[5] = open;
		$[6] = setOpen;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
}
ExternallyAnchoredGlobalCopilotMenu.displayName = "ExternallyAnchoredGlobalCopilotMenu";
function GlobalCopilotMenuWithAnchor(t0) {
	const $ = c(3);
	const { anchorProps, defaultOpen } = t0;
	const [open, setOpen] = useState(defaultOpen ?? false);
	let t1;
	if ($[0] !== anchorProps || $[1] !== open) {
		t1 = jsxs(ActionMenu, {
			open,
			onOpenChange: setOpen,
			children: [jsx(ActionMenu.Button, {
				leadingVisual: CopilotIcon,
				"aria-label": "Open Copilot…",
				...anchorProps,
				children: ""
			}), jsx(GlobalCopilotMenuOverlay, {})]
		});
		$[0] = anchorProps;
		$[1] = open;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
GlobalCopilotMenuWithAnchor.displayName = "GlobalCopilotMenuWithAnchor";
function GlobalCopilotMenu({ reactPartialAnchor, anchorProps, defaultOpen }) {
	return /* @__PURE__ */ jsxs(ErrorBoundary, {
		fallback: null,
		children: [/* @__PURE__ */ jsx(GlobalCommands, { commands: {
			"copilot-chat:open-assistive": openAssistive,
			"copilot-chat:open-immersive": openImmersive
		} }), reactPartialAnchor ? /* @__PURE__ */ jsx(ExternallyAnchoredGlobalCopilotMenu, {
			reactPartialAnchor,
			defaultOpen
		}) : /* @__PURE__ */ jsx(GlobalCopilotMenuWithAnchor, {
			anchorProps,
			defaultOpen
		})]
	});
}
GlobalCopilotMenu.displayName = "GlobalCopilotMenu";
function renderPlanType(plan) {
	switch (plan) {
		case CopilotPlan.IndividualProPlus: return /* @__PURE__ */ jsx(Label, {
			className: GlobalCopilotMenu_module_default.proLabel,
			children: "Pro+"
		});
		case CopilotPlan.IndividualPro: return /* @__PURE__ */ jsx(Label, {
			className: GlobalCopilotMenu_module_default.proLabel,
			children: "Pro"
		});
		case CopilotPlan.IndividualStudent: return /* @__PURE__ */ jsx(Label, { children: "Student" });
		case CopilotPlan.IndividualFree: return /* @__PURE__ */ jsx(Label, { children: "Free" });
		default: return null;
	}
}
function YourCopilotButton() {
	const $ = c(2);
	const plan = usePlan();
	let t0;
	if ($[0] !== plan) {
		t0 = jsxs(ActionList.LinkItem, {
			href: "/settings/copilot",
			onClick: _temp$5,
			children: [
				"Your Copilot",
				jsx(ActionList.LeadingVisual, { children: jsx(CopilotIcon, {}) }),
				plan && jsx(ActionList.TrailingVisual, { children: renderPlanType(plan) })
			]
		});
		$[0] = plan;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
YourCopilotButton.displayName = "YourCopilotButton";
function _temp$5() {
	return recordClick("SETTINGS");
}
function GlobalCopilotMenuOverlay() {
	const $ = c(7);
	const { licenseType } = useEntitlementData();
	const isUnlicensed = licenseType === CopilotLicenseType.Unlicensed;
	let t0;
	if ($[0] !== isUnlicensed) {
		t0 = () => {
			if (isUnlicensed) {
				recordClick("ASSISTIVE");
				redirectToSignup(window.location.pathname);
				return;
			}
			openAssistive();
		};
		$[0] = isUnlicensed;
		$[1] = t0;
	} else t0 = $[1];
	const handleAssistiveClick = t0;
	let t1;
	if ($[2] !== isUnlicensed) {
		t1 = (e) => {
			recordClick("SPACES");
			if (isUnlicensed) {
				e.preventDefault();
				redirectToSignup(COPILOT_SPACES_PATH);
			}
		};
		$[2] = isUnlicensed;
		$[3] = t1;
	} else t1 = $[3];
	const handleSpacesClick = t1;
	let t2;
	if ($[4] !== handleAssistiveClick || $[5] !== handleSpacesClick) {
		t2 = jsx(ActionMenu.Overlay, {
			align: "end",
			children: jsxs(ActionList, {
				style: { width: "15rem" },
				children: [
					jsxs(ActionList.Group, { children: [
						jsx(ActionList.GroupHeading, { children: "New conversation in" }),
						!copilotFeatureFlags.removeAssistiveChatButton && jsxs(ActionList.Item, {
							onSelect: handleAssistiveClick,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(CommentIcon, {}) }), "Assistive"]
						}),
						jsxs(ActionList.LinkItem, {
							href: COPILOT_SPACES_PATH,
							onClick: handleSpacesClick,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(SpacesIcon, {}) }), "Spaces"]
						})
					] }),
					jsx(ActionList.Divider, {}),
					jsxs(ActionMenu, {
						onOpenChange: _temp2$2,
						children: [jsx(ActionMenu.Anchor, { children: jsxs(ActionList.Item, {
							onSelect: _temp3,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(DownloadIcon, {}) }), "Download for"]
						}) }), jsx(ActionMenu.Overlay, { children: jsxs(ActionList, { children: [
							jsx(EditorMenuItems, {
								menuLocation: analyticsMenuLocation,
								mode
							}),
							jsx(ActionList.Divider, {}),
							jsxs(ActionList.LinkItem, {
								href: "https://docs.github.com/en/copilot/managing-copilot/configure-personal-settings/installing-github-copilot-in-the-cli",
								onClick: _temp4,
								children: ["CLI", jsx(ActionList.LeadingVisual, { children: jsx(TerminalIcon, {}) })]
							})
						] }) })]
					}),
					copilotFeatureFlags.freeToPaidYourCopilotSettings ? jsx(YourCopilotButton, {}) : jsxs(ActionList.LinkItem, {
						href: "/settings/copilot",
						onClick: _temp5,
						children: ["Settings", jsx(ActionList.LeadingVisual, { children: jsx(GearIcon, {}) })]
					})
				]
			})
		});
		$[4] = handleAssistiveClick;
		$[5] = handleSpacesClick;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
GlobalCopilotMenuOverlay.displayName = "GlobalCopilotMenuOverlay";
function _temp5() {
	return recordClick("SETTINGS");
}
function _temp4() {
	return recordClick("CLI");
}
function _temp3() {
	return recordClick("OPEN_WITH");
}
function _temp2$2(isOpen) {
	return isOpen && recordClick("IDE_MENU_OPEN");
}
function LazyGlobalNavAgentsMenu({ anchorProps, copilotApiUrl }) {
	const [shouldLoad, setShouldLoad] = useState(true);
	const [openOnLoad, setOpenOnLoad] = useState(false);
	const { getPayloadsUrl } = useTopNavContext();
	const payloadsUrl = getPayloadsUrl("agents_menu");
	const anchorRef = useRef(null);
	const { data: agentsPanelProps, isPending } = useQuery({
		queryKey: ["global-agents-menu", payloadsUrl],
		queryFn: async () => {
			const response = await verifiedFetchJSON(payloadsUrl);
			if (response.ok) try {
				return await response.json();
			} catch {
				throw new Error("Failed to parse agents menu payload.");
			}
			throw new Error("Failed to retrieve agents menu payload.");
		}
	});
	const buttonId = agentsPanelProps?.agentsButtonId ?? "global-copilot-agent-button";
	const handleIntentToOpen = useCallback(() => {
		setShouldLoad(true);
	}, []);
	const handleClick = useCallback((event) => {
		setShouldLoad(true);
		setOpenOnLoad(true);
		anchorProps?.onClick?.(event);
	}, [anchorProps]);
	if (!shouldLoad) return /* @__PURE__ */ jsx(AgentsButtonFallback, {
		anchorProps,
		loading: false,
		openOnLoad: false,
		handleIntentToOpen,
		handleClick,
		buttonId
	});
	return /* @__PURE__ */ jsx(Suspense, {
		fallback: /* @__PURE__ */ jsx(AgentsButtonFallback, {
			anchorProps,
			loading: isPending,
			openOnLoad,
			handleIntentToOpen,
			handleClick,
			buttonId
		}),
		children: /* @__PURE__ */ jsx(LazyGlobalAgentsMenuWithAnchor, {
			...agentsPanelProps,
			copilotApiUrl,
			open: openOnLoad && !isPending,
			setOpen: setOpenOnLoad,
			anchorRef,
			anchorProps: {
				...anchorProps,
				id: buttonId,
				onClick: (event_0) => {
					anchorProps?.onClick?.(event_0);
				}
			}
		})
	});
}
LazyGlobalNavAgentsMenu.displayName = "LazyGlobalNavAgentsMenu";
function AgentsButtonFallback({ loading, openOnLoad, handleIntentToOpen, handleClick, buttonId, anchorProps }) {
	const shouldShowLoading = loading && openOnLoad;
	return /* @__PURE__ */ jsx(ButtonComponent, {
		id: buttonId,
		variant: anchorProps?.variant ?? "invisible",
		className: anchorProps?.className,
		leadingVisual: AgentIcon,
		trailingVisual: shouldShowLoading ? () => /* @__PURE__ */ jsx(Spinner, { size: "small" }) : TriangleDownIcon,
		"aria-label": "Open agents panel",
		onMouseEnter: handleIntentToOpen,
		onFocus: handleIntentToOpen,
		onClick: handleClick,
		children: ""
	});
}
AgentsButtonFallback.displayName = "AgentsButtonFallback";
var LazyGlobalAgentsMenuWithAnchor = lazy(async () => {
	return { default: (await import("./server-GlobalAgentsMenu-CNs9Ls-S-BeuGctZw.js")).GlobalAgentsMenuWithAnchor };
});
LazyGlobalAgentsMenuWithAnchor.displayName = "LazyGlobalAgentsMenuWithAnchor";
var CopilotItems_module_default = {
	AgentsMenu: "CopilotItems-module_V6fXDW_AgentsMenu",
	CopilotMenu: "CopilotItems-module_V6fXDW_CopilotMenu"
};
function CopilotItems({ show, showAgentsButton, copilotApiUrl, copilotChatUrl }) {
	const { shouldLoadCopilotChat, loadCopilotChat } = useTopNavContext();
	const { sendItemClick } = useGlobalNavAnalytics("COPILOT");
	const isImmersiveEmbedded = isFeatureEnabled("copilot_immersive_embedded");
	const isImmersiveEmbeddedHeaderButton = isImmersiveEmbedded && isFeatureEnabled("copilot_immersive_embedded_header_button");
	const { data: copilotChatProps, isPending } = useQuery({
		enabled: !!copilotChatUrl,
		queryKey: [
			"copilot-chat",
			copilotChatUrl,
			isImmersiveEmbedded
		],
		queryFn: async () => {
			if (!copilotChatUrl) return null;
			const response = await verifiedFetchJSON(copilotChatUrl);
			if (response.ok) try {
				if (isImmersiveEmbedded) return await response.json();
				return await response.json();
			} catch {
				throw new Error("Failed to parse copilot chat response.");
			}
			throw new Error("Failed to retrieve copilot chat payload.");
		}
	});
	const anchorRef = useRef(null);
	const [reactPartialAnchor, setReactPartialAnchor] = useState();
	const [pendingOpenEvent, setPendingOpenEvent] = useState(null);
	useEffect(() => {
		if (anchorRef.current && !reactPartialAnchor) setReactPartialAnchor({ __wrapperElement: { anchor: anchorRef.current } });
	}, [reactPartialAnchor]);
	useEffect(() => {
		return subscribeOpenCopilotChat((e) => {
			loadCopilotChat();
			setPendingOpenEvent(e);
		});
	}, [loadCopilotChat]);
	if (!show) return null;
	const shouldUseAgentsHref = isFeatureEnabled("copilot_default_to_task_input") && isFeatureEnabled("copilot_redirect_header_button_to_agents") && showAgentsButton;
	let analyticsKey = "COPILOT_CHAT";
	if (isFeatureEnabled("copilot_default_to_task_input")) analyticsKey += "_TASK_BUTTON";
	if (isFeatureEnabled("copilot_default_to_task_input_control_group")) analyticsKey += "_TASK_EXPERIMENT_CONTROL";
	const copilotItemProps = {
		href: shouldUseAgentsHref ? "/copilot/agents" : "/copilot",
		icon: CopilotIcon,
		"aria-label": shouldUseAgentsHref ? "Navigate to Copilot" : "Chat with Copilot",
		analyticsKey,
		analyticsSubCategory: "COPILOT",
		copilotApiUrl,
		ref: anchorRef,
		onClick: isImmersiveEmbeddedHeaderButton ? (e_0) => {
			e_0.preventDefault();
			loadCopilotChat();
			const storedReferences = copilotLocalStorage.getCurrentReferences(null);
			if (storedReferences && storedReferences.length > 0) copilotLocalStorage.clearCurrentReferences(null);
			setPendingOpenEvent(new OpenCopilotChatEvent({
				intent: CopilotChatIntents.conversation,
				source: "header",
				references: storedReferences ?? void 0
			}));
		} : void 0,
		onMouseEnter: isImmersiveEmbeddedHeaderButton ? loadCopilotChat : void 0,
		onFocus: isImmersiveEmbeddedHeaderButton ? loadCopilotChat : void 0
	};
	const shouldShowCopilotChat = !isPending && copilotChatProps && reactPartialAnchor;
	return /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsxs(ButtonGroup, { children: [/* @__PURE__ */ jsx(NavLinkItem, { ...copilotItemProps }), showAgentsButton ? /* @__PURE__ */ jsx(LazyGlobalNavAgentsMenu, {
		copilotApiUrl,
		anchorProps: {
			variant: "invisible",
			className: clsx(styles_module_default$1.appHeaderButton, CopilotItems_module_default.AgentsMenu),
			onClick: () => {
				sendItemClick("AGENTS_MENU");
			}
		}
	}) : /* @__PURE__ */ jsx(GlobalCopilotMenu, { anchorProps: {
		variant: "invisible",
		className: clsx(styles_module_default$1.appHeaderButton, CopilotItems_module_default.CopilotMenu),
		onMouseEnter: loadCopilotChat,
		onFocus: loadCopilotChat,
		onClick: () => {
			loadCopilotChat();
			sendItemClick("COPILOT_MENU");
		}
	} })] }), shouldShowCopilotChat && shouldLoadCopilotChat && typeof window !== "undefined" ? /* @__PURE__ */ jsx(Suspense, {
		fallback: null,
		children: isImmersiveEmbedded ? /* @__PURE__ */ jsx(LazyCopilotImmersiveEmbedded, {
			...copilotChatProps,
			pendingOpenEvent,
			onPendingEventHandled: () => setPendingOpenEvent(null)
		}) : /* @__PURE__ */ jsx(LazyCopilotChat, {
			...copilotChatProps,
			reactPartialAnchor
		})
	}) : null] });
}
CopilotItems.displayName = "CopilotItems";
var LazyCopilotChat = lazy(async () => {
	return { default: (await import("./server-CopilotChat-Ci9P0QcB-DRBXPmgU.js")).CopilotChat };
});
LazyCopilotChat.displayName = "LazyCopilotChat";
var LazyCopilotImmersiveEmbedded = lazy(async () => {
	return { default: (await import("./server-CopilotImmersiveEmbedded-DRb7qpII-B-npoabI.js")).CopilotImmersiveEmbedded };
});
LazyCopilotImmersiveEmbedded.displayName = "LazyCopilotImmersiveEmbedded";
function EnterpriseBanner(props) {
	const { show, href, businessName, isFirstEmuOwner, viewingAsLogin, showDataResidency, dataResidencyRegion } = props;
	if (!show) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: "tmp-px-3 py-2 border-bottom color-border-muted d-flex flex-items-center lh-condensed f6 color-fg-muted no-wrap",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex-sm-1 text-bold",
			children: [/* @__PURE__ */ jsx(GlobeIcon, { size: 16 }), /* @__PURE__ */ jsx("span", {
				className: "ml-1 hide-sm",
				children: "GitHub Enterprise"
			})]
		}), /* @__PURE__ */ jsx("div", {
			className: "ml-2 overflow-x-hidden",
			children: /* @__PURE__ */ jsxs(Truncate, {
				title: `${showDataResidency ? `Data residency: ${dataResidencyRegion} - ` : ""} ${isFirstEmuOwner ? `Viewing as ${viewingAsLogin}` : `Users managed by ${businessName}`}`,
				maxWidth: "100%",
				children: [showDataResidency && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("span", {
					"data-testid": "data-residency-region",
					children: ["Data residency: ", /* @__PURE__ */ jsx("strong", { children: dataResidencyRegion })]
				}), /* @__PURE__ */ jsx("span", {
					className: "mx-1",
					children: "·"
				})] }), isFirstEmuOwner ? /* @__PURE__ */ jsxs(Fragment$1, { children: ["Viewing as ", /* @__PURE__ */ jsx("strong", {
					className: "ml-1",
					children: viewingAsLogin
				})] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [
					"Users managed by",
					" ",
					href ? /* @__PURE__ */ jsx(Link$1, {
						as: Link$1$1,
						to: href,
						muted: true,
						className: "text-bold ml-1",
						children: businessName
					}) : /* @__PURE__ */ jsx("strong", {
						className: "ml-1",
						children: businessName
					})
				] })]
			})
		})]
	});
}
EnterpriseBanner.displayName = "EnterpriseBanner";
function HeaderLogo({ href, ...props }) {
	const { sendItemClick } = useGlobalNavAnalytics();
	const uiCommandsEnabled = isFeatureEnabled("global_nav_ui_commands");
	const ref = useRef(null);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
		as: Link$1$1,
		to: href ?? "/",
		ref,
		variant: "invisible",
		className: styles_module_default.appHeaderHome,
		icon: () => /* @__PURE__ */ jsx(MarkGithubIcon, { size: "medium" }),
		"data-hotkey": uiCommandsEnabled ? void 0 : props.hotkey,
		keybindingHint: uiCommandsEnabled ? getPrimaryKeybinding("global-navigation:go-to-dashboard") : props.hotkey,
		"aria-label": "Dashboard",
		onClick: () => {
			sendItemClick("HEADER_LOGO");
		},
		...props
	}), uiCommandsEnabled && /* @__PURE__ */ jsx(GlobalCommands, { commands: { "global-navigation:go-to-dashboard": () => ref.current?.click() } })] });
}
HeaderLogo.displayName = "HeaderLogo";
var RETRY_DELAY = 500;
var MAX_RETRIES = 3;
var AriaLabelForMode = {
	none: "You have no unread notifications",
	global: "You have unread notifications",
	disabled: "Notifications are disabled",
	unavailable: "Notifications are unavailable at the moment."
};
function useAsyncNotificationIndicator(config) {
	const $ = c(19);
	const queryClient = useQueryClient();
	let t0;
	if ($[0] !== config.src) {
		t0 = ["global-nav-notifications", config.src];
		$[0] = config.src;
		$[1] = t0;
	} else t0 = $[1];
	const t1 = config.defaultIndicatorMode ?? "none";
	let t2;
	if ($[2] !== t1) {
		t2 = { mode: t1 };
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== config.src) {
		t3 = async () => {
			const response = await verifiedFetchJSON(config.src);
			if (!response.ok) throw new Error("Network response was not ok");
			return response.json();
		};
		$[4] = config.src;
		$[5] = t3;
	} else t3 = $[5];
	const t4 = config.maxRetries ?? MAX_RETRIES;
	const t5 = config.retryDelay ?? RETRY_DELAY;
	let t6;
	if ($[6] !== config.enabled || $[7] !== t0 || $[8] !== t2 || $[9] !== t3 || $[10] !== t4 || $[11] !== t5) {
		t6 = {
			enabled: config.enabled,
			queryKey: t0,
			initialData: t2,
			queryFn: t3,
			retry: t4,
			retryDelay: t5
		};
		$[6] = config.enabled;
		$[7] = t0;
		$[8] = t2;
		$[9] = t3;
		$[10] = t4;
		$[11] = t5;
		$[12] = t6;
	} else t6 = $[12];
	const queryData = useQuery(t6);
	let t7;
	if ($[13] !== config.src || $[14] !== queryClient) {
		t7 = (mode) => {
			queryClient.setQueryData(["global-nav-notifications", config.src], (oldData) => {
				if (!oldData) return oldData;
				return {
					...oldData,
					mode
				};
			});
		};
		$[13] = config.src;
		$[14] = queryClient;
		$[15] = t7;
	} else t7 = $[15];
	const updateIndicatorMode = t7;
	let t8;
	if ($[16] !== queryData || $[17] !== updateIndicatorMode) {
		t8 = {
			...queryData,
			updateIndicatorMode
		};
		$[16] = queryData;
		$[17] = updateIndicatorMode;
		$[18] = t8;
	} else t8 = $[18];
	return t8;
}
function useAsyncNotifications(t0) {
	const $ = c(10);
	const { defaultIndicatorMode: t1, fetchIndicatorSrc, websocketChannel, fetchIndicatorEnabled: t2, maxRetries, retryDelay } = t0;
	const defaultIndicatorMode = t1 === void 0 ? "none" : t1;
	const fetchIndicatorEnabled = t2 === void 0 ? false : t2;
	const t3 = fetchIndicatorSrc ?? "/notifications/indicator";
	let t4;
	if ($[0] !== defaultIndicatorMode || $[1] !== fetchIndicatorEnabled || $[2] !== maxRetries || $[3] !== retryDelay || $[4] !== t3) {
		t4 = {
			defaultIndicatorMode,
			src: t3,
			enabled: fetchIndicatorEnabled,
			maxRetries,
			retryDelay
		};
		$[0] = defaultIndicatorMode;
		$[1] = fetchIndicatorEnabled;
		$[2] = maxRetries;
		$[3] = retryDelay;
		$[4] = t3;
		$[5] = t4;
	} else t4 = $[5];
	const { data, isFetching, updateIndicatorMode } = useAsyncNotificationIndicator(t4);
	let t5;
	if ($[6] !== updateIndicatorMode) {
		t5 = (result) => {
			updateIndicatorMode(result.indicator_mode);
		};
		$[6] = updateIndicatorMode;
		$[7] = t5;
	} else t5 = $[7];
	const onNotification = t5;
	let t6;
	bb0: {
		if (data?.mode === "disabled" || !websocketChannel || isFetching) {
			t6 = void 0;
			break bb0;
		}
		t6 = websocketChannel;
	}
	useAlive(t6, onNotification);
	const { isBrowser } = useRuntimeEnvironment();
	const mode = isBrowser ? data.mode ?? "none" : defaultIndicatorMode;
	let t7;
	if ($[8] !== mode) {
		t7 = { mode };
		$[8] = mode;
		$[9] = t7;
	} else t7 = $[9];
	return t7;
}
function NotificationItem(t0) {
	const $ = c(11);
	const { hotkey, indicatorMode: t1, websocketChannel, fetchIndicatorSrc, fetchIndicatorEnabled: t2, maxRetries, retryDelay } = t0;
	const defaultIndicatorMode = t1 === void 0 ? "none" : t1;
	const fetchIndicatorEnabled = t2 === void 0 ? false : t2;
	let t3;
	if ($[0] !== defaultIndicatorMode || $[1] !== fetchIndicatorEnabled || $[2] !== fetchIndicatorSrc || $[3] !== maxRetries || $[4] !== retryDelay || $[5] !== websocketChannel) {
		t3 = {
			defaultIndicatorMode,
			websocketChannel,
			fetchIndicatorSrc,
			fetchIndicatorEnabled,
			maxRetries,
			retryDelay
		};
		$[0] = defaultIndicatorMode;
		$[1] = fetchIndicatorEnabled;
		$[2] = fetchIndicatorSrc;
		$[3] = maxRetries;
		$[4] = retryDelay;
		$[5] = websocketChannel;
		$[6] = t3;
	} else t3 = $[6];
	const { mode } = useAsyncNotifications(t3);
	if (mode === "disabled") return null;
	const t4 = AriaLabelForMode[mode];
	let t5;
	if ($[7] !== hotkey || $[8] !== mode || $[9] !== t4) {
		t5 = jsx(NavLinkItem, {
			analyticsKey: "NOTIFICATIONS_HEADER",
			href: "/notifications",
			"aria-label": t4,
			hotkey,
			commandId: "global-navigation:go-to-notifications",
			icon: InboxIcon,
			className: clsx({ [styles_module_default.notificationIndicator]: mode !== "none" })
		});
		$[7] = hotkey;
		$[8] = mode;
		$[9] = t4;
		$[10] = t5;
	} else t5 = $[10];
	return t5;
}
NotificationItem.displayName = "NotificationItem";
var Search_module_default = {
	childDialogOpen: "Search-module_mT1eDG_childDialogOpen",
	constant: "Search-module_mT1eDG_constant",
	entity: "Search-module_mT1eDG_entity",
	filter: "Search-module_mT1eDG_filter",
	hideButtons: "Search-module_mT1eDG_hideButtons",
	kbd: "Search-module_mT1eDG_kbd",
	mobilePlaceholderButton: "Search-module_mT1eDG_mobilePlaceholderButton",
	mobileSearch: "Search-module_mT1eDG_mobileSearch",
	mobileSearchContainer: "Search-module_mT1eDG_mobileSearchContainer",
	placeholder: "Search-module_mT1eDG_placeholder",
	placeholderButton: "Search-module_mT1eDG_placeholderButton",
	placeholderButtonGroup: "Search-module_mT1eDG_placeholderButtonGroup",
	searchButton: "Search-module_mT1eDG_searchButton",
	searchButtonGroup: "Search-module_mT1eDG_searchButtonGroup",
	searchPage: "Search-module_mT1eDG_searchPage",
	searchText: "Search-module_mT1eDG_searchText",
	smallSearchButton: "Search-module_mT1eDG_smallSearchButton",
	text: "Search-module_mT1eDG_text",
	value: "Search-module_mT1eDG_value",
	withLocalNav: "Search-module_mT1eDG_withLocalNav"
};
var QuickSearch = lazy(async () => {
	return { default: (await import("./server-quick-search-BbRl98iv-DwEte5Wj.js")).QuickSearch };
});
QuickSearch.displayName = "QuickSearch";
async function preloadQuickSearch() {
	(await import("./server-quick-search-BbRl98iv-DwEte5Wj.js")).preloadQuickSearch();
}
function SearchPlaceholder({ isSearchPage, isLegacySearch }) {
	const query = new URLSearchParams(ssrSafeLocation.search).get("q")?.trim();
	if (query && isSearchPage) return /* @__PURE__ */ jsx("span", {
		className: clsx(Search_module_default.placeholder, Search_module_default.text, Search_module_default.value, isLegacySearch && Search_module_default.searchText),
		children: query
	});
	return /* @__PURE__ */ jsxs("span", {
		className: clsx(Search_module_default.placeholder, Search_module_default.text, Search_module_default.value),
		children: [
			"Type",
			" ",
			/* @__PURE__ */ jsx("kbd", {
				className: Search_module_default.kbd,
				children: isFeatureEnabled("global_nav_ui_commands") ? getPrimaryKeybinding("global-navigation:search") : "/"
			}),
			" ",
			"to search"
		]
	});
}
SearchPlaceholder.displayName = "SearchPlaceholder";
function Search({ show, isJumpToSearch, searchHotkey, showCommandPalette, commandPaletteHotkey, isSearchPage, searchContext }) {
	const { searchOpen, setSearchOpen, getFragmentsPath, setTopNavHidden, topNavHidden, loadCopilotChat } = useTopNavContext();
	const showQuickSearchBar = isFeatureEnabled("app_shell_quick_search_bar");
	const [searchTextBlocks, setSearchTextBlocks] = useState([]);
	const [searchLoaded, setSearchLoaded] = useState(false);
	const [isQuickSearchOpen, setIsQuickSearchOpen] = useState(false);
	const scope = searchContext?.scope || "";
	useEffect(() => {
		if (showQuickSearchBar) preloadQuickSearch();
	}, [showQuickSearchBar]);
	const handleQuickSearchIntent = useCallback(() => {
		loadCopilotChat();
		preloadQuickSearch();
	}, [loadCopilotChat]);
	const openQuickSearch = useCallback(() => {
		preloadQuickSearch();
		startTransition(() => {
			setIsQuickSearchOpen(true);
		});
	}, []);
	const closeQuickSearch = useCallback(() => {
		startTransition(() => {
			setIsQuickSearchOpen(false);
		});
	}, []);
	const getHref = () => {
		if (isUIService) return scope ? { href: `/search?${new URLSearchParams({ q: scope }).toString()}` } : { href: "/search" };
		else return {};
	};
	useEffect(() => {
		const hideTopNav = shouldHideTopNav(new URLSearchParams(ssrSafeLocation.search), isSearchPage ?? false, isJumpToSearch ?? false) && !searchTextBlocks.length;
		if (topNavHidden !== hideTopNav) setTopNavHidden(hideTopNav);
	}, [
		setTopNavHidden,
		topNavHidden,
		isSearchPage,
		isJumpToSearch,
		searchTextBlocks
	]);
	if (!show) return null;
	if (isJumpToSearch && !showQuickSearchBar) return /* @__PURE__ */ jsx(JumpToSearch, {
		showCommandPalette,
		isSearchPage
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs(ButtonGroup, {
			className: clsx(Search_module_default.searchButtonGroup, isSearchPage && Search_module_default.searchPage, searchOpen && Search_module_default.hideButtons),
			children: [showQuickSearchBar ? /* @__PURE__ */ jsx(NavButtonItem, {
				className: Search_module_default.searchButton,
				onClick: openQuickSearch,
				onFocus: handleQuickSearchIntent,
				onMouseEnter: handleQuickSearchIntent,
				icon: SearchIcon,
				analyticsKey: "SEARCH",
				"aria-label": "Search or jump to…",
				"aria-haspopup": "dialog",
				"aria-expanded": isQuickSearchOpen,
				linkText: /* @__PURE__ */ jsx("span", { children: "Placeholder for new QuickSearch" })
			}) : /* @__PURE__ */ jsx(NavLinkItem, {
				className: Search_module_default.searchButton,
				"aria-busy": !searchLoaded,
				onClick: () => {
					if (!isUIService && searchLoaded) setSearchOpen(true);
				},
				onFocus: loadCopilotChat,
				onMouseEnter: loadCopilotChat,
				icon: SearchIcon,
				...getHref(),
				analyticsKey: "SEARCH",
				"aria-label": "Search or jump to…",
				linkText: searchTextBlocks && searchTextBlocks.length > 0 ? searchTextBlocks.map((block, index) => {
					return /* @__PURE__ */ jsx("span", {
						className: clsx(Search_module_default.text, Search_module_default[block.type]),
						children: block.value
					}, `value-${index}`);
				}) : /* @__PURE__ */ jsx(SearchPlaceholder, { isSearchPage })
			}), showCommandPalette && !showQuickSearchBar && /* @__PURE__ */ jsx(NavButtonItem, {
				className: "js-activate-command-palette",
				icon: CommandPaletteIcon,
				hotkey: commandPaletteHotkey?.split(",").join(" "),
				"aria-label": "Command palette",
				analyticsKey: "COMMAND_PALETTE"
			})]
		}),
		/* @__PURE__ */ jsx(NavLinkItem, {
			icon: SearchIcon,
			"aria-label": "Search or jump to…",
			hotkey: searchHotkey,
			commandId: "global-navigation:search",
			...isUIService ? { href: "/search" } : {},
			onClick: () => {
				if (isUIService) return;
				if (showQuickSearchBar) openQuickSearch();
				else if (searchLoaded) setSearchOpen(true);
			},
			onFocus: showQuickSearchBar ? handleQuickSearchIntent : loadCopilotChat,
			onMouseEnter: showQuickSearchBar ? handleQuickSearchIntent : loadCopilotChat,
			className: Search_module_default.smallSearchButton,
			analyticsKey: "SEARCH"
		}),
		isFeatureEnabled("global_nav_react_blackbird_fragment") ? /* @__PURE__ */ jsx(SearchFragment, {
			open: searchOpen,
			fragmentsPath: getFragmentsPath("blackbird_search"),
			onLoad: () => setSearchLoaded(true),
			onClose: (closed) => {
				setSearchOpen(!closed);
			},
			onSearchBlocksChange: setSearchTextBlocks
		}) : /* @__PURE__ */ jsx(EmbeddedRailsSearch, {
			open: searchOpen,
			onLoad: () => setSearchLoaded(true),
			onClose: (closed_0) => {
				setSearchOpen(!closed_0);
			},
			onSearchBlocksChange: setSearchTextBlocks
		}),
		showQuickSearchBar && isQuickSearchOpen && /* @__PURE__ */ jsx(Suspense, {
			fallback: null,
			children: /* @__PURE__ */ jsx(QuickSearch, {
				isOpen: isQuickSearchOpen,
				onClose: closeQuickSearch,
				searchContext
			})
		})
	] });
}
Search.displayName = "Search";
function JumpToSearch({ showCommandPalette, isSearchPage }) {
	const { getFragmentsPath } = useTopNavContext();
	const fragmentRef = useRef(null);
	const [loaded, setLoaded] = useState(false);
	useEffect(() => {
		const fragment = fragmentRef.current;
		if (fragment) {
			const replacedCallback = () => {
				setLoaded(true);
			};
			fragment.addEventListener("include-fragment-replaced", replacedCallback);
			return () => {
				fragment.removeEventListener("include-fragment-replaced", replacedCallback);
			};
		}
	}, [setLoaded]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
		className: clsx({
			"AppHeader-search": true,
			"d-none": !loaded
		}),
		children: /* @__PURE__ */ jsx(IncludeFragment, {
			ref: fragmentRef,
			src: getFragmentsPath("search"),
			accept: "text/fragment+html"
		})
	}), !loaded && /* @__PURE__ */ jsxs("span", {
		className: "AppHeader-search",
		children: [/* @__PURE__ */ jsxs(ButtonGroup, {
			className: Search_module_default.placeholderButtonGroup,
			children: [/* @__PURE__ */ jsx(NavLinkItem, {
				className: clsx(Search_module_default.searchButton, Search_module_default.placeholderButton),
				"aria-busy": true,
				icon: SearchIcon,
				...isUIService ? { href: "/search" } : {},
				analyticsKey: "SEARCH",
				"aria-label": "Search or jump to…",
				linkText: /* @__PURE__ */ jsx(SearchPlaceholder, {
					isSearchPage,
					isLegacySearch: true
				})
			}), showCommandPalette && /* @__PURE__ */ jsx(NavButtonItem, {
				className: "js-activate-command-palette",
				icon: CommandPaletteIcon,
				"aria-label": "Command palette",
				analyticsKey: "COMMAND_PALETTE"
			})]
		}), /* @__PURE__ */ jsx(IconButton, {
			icon: SearchIcon,
			"aria-label": "Search or jump to…",
			"aria-busy": true,
			className: clsx(Search_module_default.mobileSearch, Search_module_default.mobilePlaceholderButton)
		})]
	})] });
}
JumpToSearch.displayName = "JumpToSearch";
function SearchFragment(props) {
	const { onClose, open, onLoad, onSearchBlocksChange, fragmentsPath } = props;
	const searchInputWrapperRef = useRef(null);
	const fragmentRef = useRef(null);
	const [loaded, setLoaded] = useState(false);
	const [hasChildDialogOpen, setHasChildDialogOpen] = useState(false);
	useSearchElement(searchInputWrapperRef, {
		loaded,
		onClose,
		open,
		onSearchBlocksChange,
		onChildDialogChange: setHasChildDialogOpen
	});
	useEffect(() => {
		const fragment = fragmentRef.current;
		if (fragment) {
			const replacedCallback = () => {
				setLoaded(true);
				onLoad?.();
			};
			fragment.addEventListener("include-fragment-replaced", replacedCallback);
			return () => {
				fragment.removeEventListener("include-fragment-replaced", replacedCallback);
			};
		}
	}, [setLoaded, onLoad]);
	const isVisible = open || hasChildDialogOpen;
	return /* @__PURE__ */ jsx("div", {
		className: clsx({
			"d-flex width-full": open,
			"d-none": !isVisible,
			[Search_module_default.childDialogOpen]: hasChildDialogOpen && !open
		}),
		ref: searchInputWrapperRef,
		children: /* @__PURE__ */ jsx(IncludeFragment, {
			ref: fragmentRef,
			loading: "eager",
			src: fragmentsPath,
			accept: "text/fragment+html"
		})
	});
}
SearchFragment.displayName = "SearchFragment";
function EmbeddedRailsSearch(props) {
	const { onLoad, onClose, open, onSearchBlocksChange } = props;
	const searchInputWrapperRef = useRef(null);
	const [loaded, setLoaded] = useState(false);
	const [hasChildDialogOpen, setHasChildDialogOpen] = useState(false);
	useLayoutEffect(() => {
		setLoaded(true);
		onLoad?.();
	}, [onLoad]);
	useSearchElement(searchInputWrapperRef, {
		loaded,
		onClose,
		open,
		onSearchBlocksChange,
		onInitialize: useCallback(() => {
			const searchInput = document.querySelector("qbsearch-input");
			if (!searchInput || !isSearchInputElement(searchInput)) return;
			const clonedSearchInput = searchInput.cloneNode(true);
			searchInputWrapperRef.current?.appendChild(clonedSearchInput);
			const suggestionsTokenInput = document.querySelector(".js-data-jump-to-suggestions-path-csrf");
			if (suggestionsTokenInput) {
				const clonedSuggestionsTokenInput = suggestionsTokenInput.cloneNode(true);
				searchInputWrapperRef.current?.appendChild(clonedSuggestionsTokenInput);
			}
		}, []),
		onChildDialogChange: setHasChildDialogOpen
	});
	const isVisible = open || hasChildDialogOpen;
	return /* @__PURE__ */ jsx("div", {
		className: clsx({
			"d-flex width-full": open,
			"d-none": !isVisible,
			[Search_module_default.childDialogOpen]: hasChildDialogOpen && !open
		}),
		ref: searchInputWrapperRef
	});
}
EmbeddedRailsSearch.displayName = "EmbeddedRailsSearch";
function MobileSearch(t0) {
	const $ = c(5);
	const { show, isJumpToSearch } = t0;
	const { hasLocalNavigation, getFragmentsPath } = useTopNavContext();
	let t1;
	if ($[0] !== getFragmentsPath || $[1] !== hasLocalNavigation || $[2] !== isJumpToSearch || $[3] !== show) {
		t1 = show && isJumpToSearch && jsx("div", {
			className: clsx("js-global-bar-second-row", Search_module_default.mobileSearchContainer, hasLocalNavigation && Search_module_default.withLocalNav),
			hidden: true,
			children: jsx("div", {
				className: clsx("AppHeader-search", Search_module_default.mobileSearch),
				children: jsx(IncludeFragment, {
					src: getFragmentsPath("mobile_search"),
					accept: "text/fragment+html"
				})
			})
		});
		$[0] = getFragmentsPath;
		$[1] = hasLocalNavigation;
		$[2] = isJumpToSearch;
		$[3] = show;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
MobileSearch.displayName = "MobileSearch";
function QuickSearchPartial(t0) {
	const $ = c(2);
	const { show } = t0;
	const { getFragmentsPath } = useTopNavContext();
	if (!show || !isFeatureEnabled("global_nav_react_blackbird_fragment")) return null;
	let t1;
	if ($[0] !== getFragmentsPath) {
		t1 = jsx(IncludeFragment, {
			src: getFragmentsPath("quick_search"),
			accept: "text/fragment+html"
		});
		$[0] = getFragmentsPath;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
QuickSearchPartial.displayName = "QuickSearchPartial";
function CommandPalettePartial(t0) {
	const $ = c(2);
	const { show, showCommandPalette } = t0;
	const { getFragmentsPath } = useTopNavContext();
	if (!show || !showCommandPalette || !isFeatureEnabled("global_nav_react_blackbird_fragment")) return null;
	let t1;
	if ($[0] !== getFragmentsPath) {
		t1 = jsx(IncludeFragment, {
			src: getFragmentsPath("command_palette"),
			accept: "text/fragment+html"
		});
		$[0] = getFragmentsPath;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
CommandPalettePartial.displayName = "CommandPalettePartial";
function isSearchInputElement(element) {
	return element !== null && "handleExpand" in element && "closeDialog" in element && "syncRichButtonText" in element;
}
function useSearchElement(containerRef, options) {
	const $ = c(12);
	const searchInputRef = useRef(null);
	const { onInitialize, onChildDialogChange } = options;
	const container = containerRef.current;
	let t0;
	if ($[0] !== onInitialize || $[1] !== options.loaded) {
		t0 = () => {
			if (!options.loaded || !container || searchInputRef.current) return;
			onInitialize?.();
			const searchInput = container.querySelector("qbsearch-input");
			if (!searchInput || !isSearchInputElement(searchInput)) return;
			searchInputRef.current = searchInput;
			searchInputRef.current.syncRichButtonText();
		};
		$[0] = onInitialize;
		$[1] = options.loaded;
		$[2] = t0;
	} else t0 = $[2];
	const initializeSearch = t0;
	let t1;
	let t2;
	if ($[3] !== initializeSearch || $[4] !== options.open) {
		t1 = () => {
			if (options.open) {
				initializeSearch();
				searchInputRef.current?.handleExpand();
			}
		};
		t2 = [options.open, initializeSearch];
		$[3] = initializeSearch;
		$[4] = options.open;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	useEffect(t1, t2);
	let t3;
	let t4;
	if ($[7] !== initializeSearch || $[8] !== onChildDialogChange || $[9] !== options) {
		t3 = () => {
			const onCloseSearch = () => {
				options.onClose?.(true);
			};
			const onOpenSearch = () => {
				onChildDialogChange?.(false);
				options.onClose?.(false);
			};
			const onUpdateText = (event) => {
				if (!(event instanceof CustomEvent)) return;
				options.onSearchBlocksChange?.(event.detail.searchTextBlocks);
			};
			initializeSearch();
			document.addEventListener("qbsearch-input:updateText", onUpdateText);
			const searchInput_0 = searchInputRef.current;
			if (!searchInput_0) return () => {
				document.removeEventListener("qbsearch-input:updateText", onUpdateText);
			};
			document.addEventListener("qbsearch-input:close", onCloseSearch);
			document.addEventListener("qbsearch-input:expand", onOpenSearch);
			const observer = new MutationObserver(() => {
				const hasOpenDialog = Boolean(searchInput_0.querySelector("dialog[open]") || searchInput_0.querySelector("modal-dialog[open]"));
				onChildDialogChange?.(hasOpenDialog);
			});
			observer.observe(searchInput_0, {
				subtree: true,
				childList: true,
				attributes: true,
				attributeFilter: ["open"]
			});
			return () => {
				document.removeEventListener("qbsearch-input:close", onCloseSearch);
				document.removeEventListener("qbsearch-input:expand", onOpenSearch);
				document.removeEventListener("qbsearch-input:updateText", onUpdateText);
				observer.disconnect();
			};
		};
		t4 = [
			initializeSearch,
			onChildDialogChange,
			options
		];
		$[7] = initializeSearch;
		$[8] = onChildDialogChange;
		$[9] = options;
		$[10] = t3;
		$[11] = t4;
	} else {
		t3 = $[10];
		t4 = $[11];
	}
	useEffect(t3, t4);
}
function LazyAccountSwitchDialog() {
	const $ = c(6);
	const { getPayloadsUrl } = useTopNavContext();
	let t0;
	if ($[0] !== getPayloadsUrl) {
		t0 = getPayloadsUrl("account_switch_dialog");
		$[0] = getPayloadsUrl;
		$[1] = t0;
	} else t0 = $[1];
	const payloadsUrl = t0;
	let t1;
	if ($[2] !== payloadsUrl) {
		t1 = {
			queryKey: ["account-switch-dialog", payloadsUrl],
			queryFn: async () => {
				const response = await verifiedFetchJSON(payloadsUrl);
				if (response.ok) try {
					return await response.json();
				} catch {
					throw new Error("Failed to parse account switch dialog payload.");
				}
				throw new Error("Failed to retrieve account switch dialog payload.");
			}
		};
		$[2] = payloadsUrl;
		$[3] = t1;
	} else t1 = $[3];
	const { data: accountSwitchDialogProps } = useQuery(t1);
	let t2;
	if ($[4] !== accountSwitchDialogProps) {
		t2 = jsx(Suspense, {
			fallback: null,
			children: accountSwitchDialogProps && jsx(AccountSwitchDialog, { ...accountSwitchDialogProps })
		});
		$[4] = accountSwitchDialogProps;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
LazyAccountSwitchDialog.displayName = "LazyAccountSwitchDialog";
var AccountSwitchDialog = lazy(async () => {
	return { default: (await import("./server-AccountSwitchDialog-P_LjKO5G-dcHzUNE4.js")).AccountSwitchDialog };
});
AccountSwitchDialog.displayName = "AccountSwitchDialog";
var GlobalCreateMenu_module_default = {
	actionMenuButton: "GlobalCreateMenu-module_rqT3-q_actionMenuButton",
	hideOnSmall: "GlobalCreateMenu-module_rqT3-q_hideOnSmall"
};
var LazyCreateIssueDialog = lazy(() => import("./server-CreateIssueDialog-dWstGyoI-DDQ5sv64.js"));
LazyCreateIssueDialog.displayName = "LazyCreateIssueDialog";
function analyticsPayload({ analyticsKey, analyticsLabel }) {
	const globalNavBarFeatureEnabled = isFeatureEnabled("global_nav_react");
	return {
		category: globalNavBarFeatureEnabled ? "GLOBAL_NAV_BAR:CREATE_MENU" : "SiteHeaderComponent",
		action: globalNavBarFeatureEnabled ? analyticsKey : "app_dropdown",
		label: globalNavBarFeatureEnabled ? void 0 : analyticsLabel
	};
}
function CreateMenuLinkItem(t0) {
	const $ = c(10);
	const { label, href, LeadingVisual, analyticsKey, analyticsLabel, itemRef: t1 } = t0;
	const itemRef = t1 === void 0 ? null : t1;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t2;
	if ($[0] !== analyticsKey || $[1] !== analyticsLabel || $[2] !== sendClickAnalyticsEvent) {
		t2 = () => {
			sendClickAnalyticsEvent(analyticsPayload({
				analyticsKey,
				analyticsLabel
			}));
		};
		$[0] = analyticsKey;
		$[1] = analyticsLabel;
		$[2] = sendClickAnalyticsEvent;
		$[3] = t2;
	} else t2 = $[3];
	const handleClick = t2;
	let t3;
	if ($[4] !== LeadingVisual || $[5] !== handleClick || $[6] !== href || $[7] !== itemRef || $[8] !== label) {
		t3 = jsxs(ActionList.LinkItem, {
			href,
			onClick: handleClick,
			ref: itemRef,
			children: [jsx(ActionList.LeadingVisual, { children: jsx(LeadingVisual, {}) }), label]
		});
		$[4] = LeadingVisual;
		$[5] = handleClick;
		$[6] = href;
		$[7] = itemRef;
		$[8] = label;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
CreateMenuLinkItem.displayName = "CreateMenuLinkItem";
function CreateMenuItem(t0) {
	const $ = c(9);
	const { label, onClick, LeadingVisual, analyticsLabel, analyticsKey } = t0;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t1;
	if ($[0] !== analyticsKey || $[1] !== analyticsLabel || $[2] !== onClick || $[3] !== sendClickAnalyticsEvent) {
		t1 = () => {
			sendClickAnalyticsEvent(analyticsPayload({
				analyticsKey,
				analyticsLabel
			}));
			onClick();
		};
		$[0] = analyticsKey;
		$[1] = analyticsLabel;
		$[2] = onClick;
		$[3] = sendClickAnalyticsEvent;
		$[4] = t1;
	} else t1 = $[4];
	const handleClick = t1;
	let t2;
	if ($[5] !== LeadingVisual || $[6] !== handleClick || $[7] !== label) {
		t2 = jsxs(ActionList.Item, {
			onSelect: handleClick,
			children: [jsx(ActionList.LeadingVisual, { children: jsx(LeadingVisual, {}) }), label]
		});
		$[5] = LeadingVisual;
		$[6] = handleClick;
		$[7] = label;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
CreateMenuItem.displayName = "CreateMenuItem";
function MenuItemSpinner() {
	return /* @__PURE__ */ jsx(Spinner, { size: "small" });
}
MenuItemSpinner.displayName = "MenuItemSpinner";
function GlobalCreateMenuOverlay({ side = "outside-bottom", showCreateRepo, showImportRepo, showCreateOrg, showCreateProject, createProjectUrl, showCreateLegacyProject, showCreateIssue, showCodespaces, showSpark, showCodingAgent, showGist, org, owner, repo, isOpen, setIsOpen, environment, anchorRef }) {
	const [isCreateIssueVisible, setIsCreateIssueVisible] = useState(false);
	const [isCreateIssueLoaded, setIsCreateIssueLoaded] = useState(false);
	const [createIssueIntent, setCreateIssueIntent] = useState(isOpen);
	useEffect(() => {
		if (isOpen) setCreateIssueIntent(true);
	}, [isOpen]);
	const shouldShowCreateIssueFallback = isCreateIssueVisible && !isCreateIssueLoaded;
	const listRef = useRef(null);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [showCreateIssue && createIssueIntent && /* @__PURE__ */ jsx(Suspense, { children: /* @__PURE__ */ jsx(LazyCreateIssueDialog, {
		isVisible: isCreateIssueVisible,
		setIsVisible: setIsCreateIssueVisible,
		setIsLoaded: setIsCreateIssueLoaded,
		setIsParentMenuOpen: setIsOpen,
		owner,
		repo,
		environment,
		returnFocusRef: anchorRef ?? listRef
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		side,
		children: /* @__PURE__ */ jsxs(ActionList, { children: [
			showCreateIssue && /* @__PURE__ */ jsx(CreateMenuItem, {
				label: "New issue",
				analyticsLabel: "new issue",
				analyticsKey: "NEW_ISSUE",
				onClick: () => {
					setIsCreateIssueVisible(true);
					return false;
				},
				itemRef: listRef,
				LeadingVisual: shouldShowCreateIssueFallback ? MenuItemSpinner : IssueOpenedIcon
			}),
			showCreateRepo !== false && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
				label: "New repository",
				analyticsLabel: "new repository",
				analyticsKey: "NEW_REPOSITORY",
				href: "/new",
				LeadingVisual: RepoIcon
			}),
			showImportRepo && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
				label: "Import repository",
				analyticsLabel: "import repository",
				analyticsKey: "IMPORT_REPOSITORY",
				href: "/new/import",
				LeadingVisual: RepoPushIcon
			}),
			(showCodingAgent || showSpark || showCodespaces || showGist) && /* @__PURE__ */ jsx(ActionList.Divider, {}),
			showCodingAgent && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
				label: "New agent session",
				analyticsLabel: "new agent task",
				analyticsKey: "NEW_AGENT_TASK",
				href: "/copilot/agents",
				LeadingVisual: AgentIcon
			}),
			showSpark && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
				label: "New spark",
				analyticsLabel: "new spark",
				analyticsKey: "NEW_SPARK",
				href: "/spark",
				LeadingVisual: SparkleIcon
			}),
			(showCodespaces || showGist) && /* @__PURE__ */ jsxs(Fragment$1, { children: [showCodespaces && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
				label: "New codespace",
				analyticsLabel: "new codespace",
				analyticsKey: "NEW_CODESPACE",
				href: "/codespaces/new",
				LeadingVisual: CodespacesIcon
			}), showGist && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
				label: "New gist",
				analyticsLabel: "new gist",
				analyticsKey: "NEW_GIST",
				href: "/gist",
				LeadingVisual: CodeIcon
			})] }),
			(showCreateOrg || showCreateProject || showCreateLegacyProject) && /* @__PURE__ */ jsxs(Fragment$1, { children: [
				/* @__PURE__ */ jsx(ActionList.Divider, {}),
				showCreateOrg && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
					label: "New organization",
					analyticsLabel: "new organization",
					analyticsKey: "NEW_ORGANIZATION",
					href: "/account/organizations/new",
					LeadingVisual: OrganizationIcon
				}),
				showCreateProject && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
					label: "New project",
					analyticsLabel: "new project",
					analyticsKey: "NEW_PROJECT",
					href: createProjectUrl,
					LeadingVisual: ProjectIcon
				}),
				!showCreateProject && showCreateLegacyProject && /* @__PURE__ */ jsx(CreateMenuLinkItem, {
					label: "New project",
					analyticsLabel: "new legacy project",
					analyticsKey: "NEW_LEGACY_PROJECT",
					href: "/new/project",
					LeadingVisual: ProjectIcon
				})
			] }),
			org && /* @__PURE__ */ jsxs(Fragment$1, { children: [
				/* @__PURE__ */ jsx(ActionList.Divider, {}),
				/* @__PURE__ */ jsx(CreateMenuLinkItem, {
					label: `${org.addWord} someone to ${org.login}`,
					analyticsLabel: "invite someone",
					analyticsKey: "INVITE_SOMEONE",
					href: `/orgs/${org.login}/people#invite-member`,
					LeadingVisual: PersonAddIcon
				}),
				/* @__PURE__ */ jsx(CreateMenuLinkItem, {
					label: `New team in ${org.login}`,
					analyticsLabel: "new team",
					analyticsKey: "NEW_TEAM",
					href: `/orgs/${org.login}/new-team`,
					LeadingVisual: PeopleIcon
				}),
				/* @__PURE__ */ jsx(CreateMenuLinkItem, {
					label: `New repository in ${org.login}`,
					analyticsLabel: "organization - new repository",
					analyticsKey: "NEW_ORG_REPOSITORY",
					href: `/organizations/${org.login}/repositories/new`,
					LeadingVisual: RepoIcon
				})
			] })
		] })
	})] });
}
GlobalCreateMenuOverlay.displayName = "GlobalCreateMenuOverlay";
function ReactPartialGlobalCreateMenu(t0) {
	const { reactPartialAnchor, ...props } = t0;
	const { ref: anchorRef, open, setOpen } = useExternalAnchor(reactPartialAnchor);
	return jsx(ActionMenu, {
		anchorRef,
		open,
		onOpenChange: setOpen,
		children: jsx(GlobalCreateMenuOverlay, {
			...props,
			isOpen: open,
			setIsOpen: setOpen,
			anchorRef
		})
	});
}
ReactPartialGlobalCreateMenu.displayName = "ReactPartialGlobalCreateMenu";
function GlobalCreateMenu(t0) {
	const $ = c(2);
	const { isLoading, isOpen, setIsOpen, anchorRef, ...props } = t0;
	const toolTipId = `global-create-menu-tooltip-${useId()}`;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t1;
	if ($[0] !== sendClickAnalyticsEvent) {
		t1 = () => sendClickAnalyticsEvent(analyticsPayload({
			analyticsKey: "CREATE_MENU_TOGGLE",
			analyticsLabel: "create new"
		}));
		$[0] = sendClickAnalyticsEvent;
		$[1] = t1;
	} else t1 = $[1];
	return jsxs(ActionMenu, {
		open: isOpen,
		onOpenChange: setIsOpen,
		anchorRef,
		children: [jsx(Tooltip$1, {
			text: "Create new...",
			type: "label",
			id: toolTipId,
			children: jsx(ActionMenu.Button, {
				ref: anchorRef,
				variant: "invisible",
				className: GlobalCreateMenu_module_default.actionMenuButton,
				leadingVisual: isLoading ? MenuItemSpinner : PlusIcon,
				onClick: t1
			})
		}), jsx(GlobalCreateMenuOverlay, {
			...props,
			isOpen,
			setIsOpen,
			anchorRef
		})]
	});
}
GlobalCreateMenu.displayName = "GlobalCreateMenu";
function LazyGlobalCreateMenu() {
	const { getPayloadsUrl } = useTopNavContext();
	const payloadsUrl = getPayloadsUrl("create_menu");
	const [isOpen, setIsOpen] = useState(false);
	const anchorRef = useRef(null);
	const { data: createMenuProps, isPending } = useQuery({
		queryKey: ["global-create-menu", payloadsUrl],
		queryFn: async () => {
			const response = await verifiedFetchJSON(payloadsUrl);
			if (response.ok) try {
				return await response.json();
			} catch {
				throw new Error("Failed to parse create menu payload.");
			}
			throw new Error("Failed to retrieve create menu payload.");
		}
	});
	return /* @__PURE__ */ jsx(GlobalCreateMenu, {
		...createMenuProps,
		isOpen: isOpen && !isPending,
		setIsOpen,
		anchorRef,
		isLoading: isOpen && isPending
	});
}
LazyGlobalCreateMenu.displayName = "LazyGlobalCreateMenu";
function GlobalNavMenuToggle({ ref, setOpen, open, isLoading = false }) {
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	return /* @__PURE__ */ jsx(IconButton, {
		ref,
		variant: "invisible",
		className: styles_module_default$1.appHeaderButton,
		"aria-haspopup": "dialog",
		onClick: () => {
			setOpen(!open);
			sendClickAnalyticsEvent({
				category: analyticsCategory,
				action: "GLOBAL_NAV_MENU_TOGGLE"
			});
		},
		"aria-label": "Open menu",
		loading: isLoading && open,
		icon: ThreeBarsIcon
	});
}
GlobalNavMenuToggle.displayName = "GlobalNavMenuToggle";
function LazyAnchoredGlobalNavMenu() {
	const $ = c(13);
	const [open, setOpen] = useState(false);
	const [isLoading, setIsLoading] = useState(true);
	const anchorRef = useNavigableRef();
	const { getPayloadsUrl } = useTopNavContext();
	let t0;
	if ($[0] !== getPayloadsUrl) {
		t0 = getPayloadsUrl("nav_menu");
		$[0] = getPayloadsUrl;
		$[1] = t0;
	} else t0 = $[1];
	const payloadsUrl = t0;
	let t1;
	if ($[2] !== payloadsUrl) {
		t1 = {
			queryKey: ["global-nav-menu", payloadsUrl],
			queryFn: async () => {
				const response = await verifiedFetchJSON(payloadsUrl);
				if (response.ok) try {
					return await response.json();
				} catch {
					throw new Error("Failed to parse nav menu payload.");
				}
				throw new Error("Failed to retrieve nav menu payload.");
			}
		};
		$[2] = payloadsUrl;
		$[3] = t1;
	} else t1 = $[3];
	const { data: menuProps, isPending } = useQuery(t1);
	let t2;
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => {
			let cancelled = false;
			LazyGlobalNavMenu.preload().then(() => {
				if (!cancelled) setIsLoading(false);
			}).catch(() => {
				if (!cancelled) setIsLoading(false);
			});
			return () => {
				cancelled = true;
			};
		};
		t3 = [];
		$[4] = t2;
		$[5] = t3;
	} else {
		t2 = $[4];
		t3 = $[5];
	}
	useEffect(t2, t3);
	let t4;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => {
			setOpen(false);
		};
		$[6] = t4;
	} else t4 = $[6];
	const onClose = t4;
	const showLoadingState = isLoading || isPending;
	const openMenu = open && !showLoadingState;
	let t5;
	if ($[7] !== anchorRef || $[8] !== menuProps || $[9] !== open || $[10] !== openMenu || $[11] !== showLoadingState) {
		t5 = jsxs(Fragment$1, { children: [jsx(GlobalNavMenuToggle, {
			ref: anchorRef,
			setOpen,
			open,
			isLoading: open && showLoadingState
		}), jsx(Suspense, {
			fallback: null,
			children: jsx(LazyGlobalNavMenu, {
				returnFocusRef: anchorRef,
				open: openMenu,
				onClose,
				...menuProps
			})
		})] });
		$[7] = anchorRef;
		$[8] = menuProps;
		$[9] = open;
		$[10] = openMenu;
		$[11] = showLoadingState;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
}
LazyAnchoredGlobalNavMenu.displayName = "LazyAnchoredGlobalNavMenu";
var LazyGlobalNavMenu = lazyWithPreload(async () => {
	return { default: (await import("./server-GlobalNavMenu-5qc51k19-DBPM-Vm3.js")).GlobalNavMenu };
});
var GlobalNavUserMenu_module_default = {
	anchor: "GlobalNavUserMenu-module_Y1V8rq_anchor",
	container: "GlobalNavUserMenu-module_Y1V8rq_container",
	Dialog: "GlobalNavUserMenu-module_Y1V8rq_Dialog",
	overlay: "GlobalNavUserMenu-module_Y1V8rq_overlay"
};
function GlobalNavUserMenuToggle({ owner, ref, open, setOpen, isLoading }) {
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const label = `${open ? "Close" : "Open"} user navigation menu`;
	return /* @__PURE__ */ jsxs("div", {
		className: GlobalNavUserMenu_module_default.container,
		children: [/* @__PURE__ */ jsx(IconButton, {
			ref,
			className: GlobalNavUserMenu_module_default.anchor,
			variant: "invisible",
			icon: () => /* @__PURE__ */ jsx(GitHubAvatar, {
				size: 32,
				alt: owner.name ?? "User avatar",
				src: owner.avatarUrl
			}),
			"aria-label": label,
			"aria-haspopup": "menu",
			onClick: () => {
				setOpen(!open);
				sendClickAnalyticsEvent({
					category: analyticsCategory$1,
					action: "USER_NAV_MENU_TOGGLE",
					label
				});
			},
			"data-login": owner.login,
			...testIdProps("global-nav-user-menu-toggle")
		}), isLoading && open && /* @__PURE__ */ jsx("div", {
			className: GlobalNavUserMenu_module_default.overlay,
			children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
		})]
	});
}
GlobalNavUserMenuToggle.displayName = "GlobalNavUserMenuToggle";
function LazyAnchoredGlobalNavUserMenu({ owner }) {
	const [open, setOpen] = useState(false);
	const [isLoading, setIsLoading] = useState(true);
	const anchorRef = useNavigableRef();
	const { getPayloadsUrl } = useTopNavContext();
	const payloadsUrl = getPayloadsUrl("user_menu");
	const { data: globalUserMenuProps, isPending } = useQuery({
		queryKey: ["global-user-menu", payloadsUrl],
		queryFn: async () => {
			const response = await verifiedFetchJSON(payloadsUrl);
			if (response.ok) try {
				return await response.json();
			} catch {
				throw new Error("Failed to parse nav menu payload.");
			}
			throw new Error("Failed to retrieve nav menu payload.");
		}
	});
	useEffect(() => {
		let cancelled = false;
		async function preload() {
			try {
				await LazyGlobalNavUserMenu.preload();
			} finally {
				if (!cancelled) setIsLoading(false);
			}
		}
		preload();
		return () => {
			cancelled = true;
		};
	}, []);
	const onClose = useCallback(() => {
		setOpen(false);
	}, [setOpen]);
	const showLoadingState = isLoading || isPending;
	const openMenu = open && !showLoadingState;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(GlobalNavUserMenuToggle, {
		owner,
		ref: anchorRef,
		open,
		setOpen,
		isLoading: open && showLoadingState
	}), /* @__PURE__ */ jsx(Suspense, {
		fallback: null,
		children: globalUserMenuProps && /* @__PURE__ */ jsx(LazyGlobalNavUserMenu, {
			...globalUserMenuProps,
			owner,
			anchorRef,
			open: openMenu,
			onClose
		})
	})] });
}
LazyAnchoredGlobalNavUserMenu.displayName = "LazyAnchoredGlobalNavUserMenu";
var LazyGlobalNavUserMenu = lazyWithPreload(async () => {
	return { default: (await import("./server-GlobalNavUserMenu-DXcYbilN-CBf7LlUE.js")).GlobalNavUserMenu };
});
/**
* Store refs to many instances in one convenient place. Useful when rendering a list of items.
*
* @example
* ```jsx
* const itemsRef = useMultiRef<string, HTMLLIElement>()
*
* useEffect(() => {
*   itemsRef("a").current?.focus()
* }, [])
*
* return <ul>
*   {items.map(item => <li key={item.id} ref={itemsRef(item.id)}>{item.text}</li>)}
* </ul>
* ```
*/
function useMultiRef() {
	const storeRef = useRef(null);
	return useCallback((key) => {
		const store = storeRef.current ??= /* @__PURE__ */ new Map();
		const refForKey = store.get(key) ?? { current: null };
		store.set(key, refForKey);
		return refForKey;
	}, []);
}
var NavigationTabPopover = lazy(async () => {
	return { default: (await import("./server-NavigationTabPopover-kJ1QqvVY-DtSsPJCb.js")).NavigationTabPopover };
});
NavigationTabPopover.displayName = "NavigationTabPopover";
function LazyNavigationTabPopover(props) {
	return /* @__PURE__ */ jsx(Suspense, {
		fallback: null,
		children: /* @__PURE__ */ jsx(NavigationTabPopover, { ...props })
	});
}
LazyNavigationTabPopover.displayName = "LazyNavigationTabPopover";
var LocalNavigation_module_default = {
	LocalNavigation: "LocalNavigation-module_gsahca_LocalNavigation",
	PopoverLink: "LocalNavigation-module_gsahca_PopoverLink",
	PopoverTab: "LocalNavigation-module_gsahca_PopoverTab"
};
function getTabCount(count) {
	if (count !== void 0 && count > 0) {
		if (count >= 5e3) return "5k+";
		if (count >= 1e3) return `${parseFloat((count / 1e3).toFixed(1))}k`;
		return count.toString();
	}
}
/** Extracts react-specific navigation attributes from the context region payload */
function getReactNavAttrs(target) {
	if (!target) return {};
	return {
		"data-react-nav": target.appTarget,
		...target.anchor ? { "data-react-nav-anchor": target.anchor } : {}
	};
}
function getTurboNavAttrs(target) {
	if (!target) return {};
	return { "data-turbo-frame": target.frame };
}
function findActiveTabBySelectedLink(tabs, selectedLink) {
	if (!tabs || tabs.length === 0) return;
	const currentPath = ssrSafeLocation.pathname + ssrSafeLocation.search;
	if (selectedLink) {
		const selectedLinkTab = tabs.find((tab) => tab.selectedLinks?.includes(selectedLink));
		if (selectedLinkTab) return selectedLinkTab;
	}
	const currentPathLower = currentPath.toLowerCase();
	return tabs.filter((tab) => {
		const hrefLower = tab.href?.toLowerCase();
		return hrefLower && (currentPathLower === hrefLower || currentPathLower.startsWith(`${hrefLower}/`) || currentPathLower.startsWith(`${hrefLower}?`));
	}).sort((a, b) => (b.href?.length || 0) - (a.href?.length || 0))[0];
}
/**
* Hook to track which tab is currently active based on the selected link or the current URL
* Listens for turbo navigation events and updates the active tab accordingly
*/
function useActiveTab(tabs, defaultSelectedLink) {
	const $ = c(6);
	let t0;
	if ($[0] !== defaultSelectedLink || $[1] !== tabs) {
		t0 = () => findActiveTabBySelectedLink(tabs || [], defaultSelectedLink);
		$[0] = defaultSelectedLink;
		$[1] = tabs;
		$[2] = t0;
	} else t0 = $[2];
	const [activeTab, setActiveTab] = useState(t0);
	let t1;
	let t2;
	if ($[3] !== tabs) {
		t1 = () => {
			const updateActiveTabFromMetaElement = function updateActiveTabFromMetaElement(node) {
				if (node.isConnected && node.getAttribute("name") === "selected-link") {
					const selection = node.getAttribute("value");
					const selectedLinkTab = findActiveTabBySelectedLink(tabs || [], selection || void 0);
					if (selectedLinkTab) {
						setActiveTab(selectedLinkTab);
						return;
					}
				}
			};
			const observer = new MutationObserver((mutations) => {
				for (const mutation of mutations) for (const node_0 of mutation.addedNodes) if (node_0 instanceof HTMLMetaElement) updateActiveTabFromMetaElement(node_0);
			});
			if (document?.head) observer.observe(document.head, { childList: true });
			const turboEventHandler = () => {
				const selectedLinkElement = document.head?.querySelector("meta[name=\"selected-link\"]");
				if (selectedLinkElement) updateActiveTabFromMetaElement(selectedLinkElement);
			};
			if (typeof window !== "undefined") window.addEventListener("turbo:load", turboEventHandler);
			return () => {
				observer.disconnect();
				window?.removeEventListener("turbo:load", turboEventHandler);
			};
		};
		t2 = [tabs];
		$[3] = tabs;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useEffect(t1, t2);
	return activeTab;
}
var crumbToLabelMap = {
	repository: "Repository",
	business: "Enterprise",
	organization: "Organization",
	user: "User"
};
function getAriaLabel(crumbs) {
	const lastCrumb = crumbs?.[crumbs.length - 1];
	if (lastCrumb && lastCrumb.crumb_type) return crumbToLabelMap[lastCrumb.crumb_type] ?? "Local";
	return "Local";
}
/** Renders the local tabs and other nav items specific to this particular route */
function LocalNavigation({ localNavigation: defaultLocalNavigation, localNavigationUpdateChannel, selectedLink, crumbs }) {
	const [localNavigation, setLocalNavigation] = useState(defaultLocalNavigation);
	useEffect(() => {
		setLocalNavigation(defaultLocalNavigation);
	}, [defaultLocalNavigation]);
	const activeTab = useActiveTab(localNavigation, selectedLink);
	useAlive(localNavigationUpdateChannel, (event) => {
		if (event.tabs) setLocalNavigation(event.tabs);
	});
	const updateTabCount = useCallback((tabId, delta) => {
		setLocalNavigation((prev) => {
			if (!prev) return prev;
			return prev.map((tab) => {
				if (tab.id !== tabId) return tab;
				const currentCount = tab.count ?? 0;
				return {
					...tab,
					count: Math.max(currentCount + delta, 0)
				};
			});
		});
	}, [setLocalNavigation]);
	const ref = useRef(null);
	useImperativeHandle(ref, () => ({ updateTabCount }), [updateTabCount]);
	useEffect(() => {
		const { current } = ref;
		if (current) registerLocalNavigationHandler(current);
		return () => {
			clearRegisteredLocalNavigation();
		};
	}, []);
	const { isBrowser } = useRuntimeEnvironment();
	const supportsPopoverAnchorPosition = useMemo(() => {
		try {
			return isBrowser ? CSS.supports("position-anchor", "--name") ?? false : false;
		} catch {
			return false;
		}
	}, [isBrowser]);
	const [popoverDismissed, dismissPopover] = useReducer(() => true, false);
	const popoverId = useId();
	const itemsRef = useMultiRef();
	const uiCommandsEnabled = isFeatureEnabled("global_nav_ui_commands");
	const codeViewEnabled = isFeatureEnabled("ui_route_code_view");
	if (!localNavigation || localNavigation.length === 0) return null;
	const underlineNavKey = localNavigation.map((tab_0) => tab_0.id).join("-");
	const popoverTabId = supportsPopoverAnchorPosition && !popoverDismissed ? localNavigation.find((tab_1) => tab_1.popoverData !== void 0)?.id : void 0;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(UnderlineNav, {
		"aria-label": getAriaLabel(crumbs),
		className: LocalNavigation_module_default.LocalNavigation,
		children: localNavigation.map((tab_2) => {
			const Icon = getOcticon(tab_2.icon);
			const href = tab_2.href || "#";
			const isCurrentPage = activeTab?.id === tab_2.id;
			const commonAttrs = {
				leadingVisual: Icon ? /* @__PURE__ */ jsx(Icon, {}) : void 0,
				"data-hotkey": uiCommandsEnabled ? void 0 : tab_2.hotkey,
				"aria-current": isCurrentPage ? "page" : void 0,
				"data-tab-item": tab_2.id,
				counter: getTabCount(tab_2.count),
				...getReactNavAttrs(tab_2.reactNav),
				...getTurboNavAttrs(codeViewEnabled && tab_2.id === "code" ? void 0 : tab_2.turboNav)
			};
			return tab_2.id === popoverTabId ? /* @__PURE__ */ jsxs(UnderlineNav.Item, {
				as: "span",
				className: LocalNavigation_module_default.PopoverTab,
				...commonAttrs,
				children: [/* @__PURE__ */ jsx(Link$1$1, {
					to: href,
					className: LocalNavigation_module_default.PopoverLink,
					"aria-details": popoverId,
					ref: itemsRef(tab_2.id),
					children: tab_2.label
				}), /* @__PURE__ */ jsx(LazyNavigationTabPopover, {
					id: popoverId,
					popoverData: tab_2.popoverData,
					onDismiss: dismissPopover
				})]
			}, tab_2.id) : /* @__PURE__ */ jsx(UnderlineNav.Item, {
				as: Link$1$1,
				to: href,
				...commonAttrs,
				ref: itemsRef(tab_2.id),
				children: tab_2.label
			}, tab_2.id);
		})
	}, underlineNavKey), uiCommandsEnabled && /* @__PURE__ */ jsx(GlobalCommands, { commands: Object.fromEntries(localNavigation.filter((tab_3) => tab_3.commandId !== void 0).map((tab_4) => [tab_4.commandId, () => itemsRef(tab_4.id).current?.click()])) })] });
}
LocalNavigation.displayName = "LocalNavigation";
function GlobalNavBar(props) {
	const $ = c(18);
	const { userMenu, headerLogo, copilot, notifications, contextRegion, search, enterpriseBanner, issues, pulls, contributedRepos, globalTransactionalMessage, payloadsUrl } = props;
	const hasLocalNavigation = !!contextRegion?.localNavigation && contextRegion.localNavigation.length > 0;
	const contextRegionProps = useRegisterContextRegion();
	contextRegion?.localNavigation;
	let t0;
	if ($[0] !== contextRegion?.localNavigation) {
		t0 = new Set(contextRegion?.localNavigation?.flatMap(_temp$4) ?? []);
		$[0] = contextRegion?.localNavigation;
		$[1] = t0;
	} else t0 = $[1];
	const localNavigationKeybindings = t0;
	let t1;
	if ($[2] !== contextRegion || $[3] !== contextRegionProps || $[4] !== contributedRepos || $[5] !== copilot || $[6] !== enterpriseBanner || $[7] !== globalTransactionalMessage || $[8] !== hasLocalNavigation || $[9] !== headerLogo || $[10] !== issues || $[11] !== localNavigationKeybindings || $[12] !== notifications || $[13] !== payloadsUrl || $[14] !== pulls || $[15] !== search || $[16] !== userMenu) {
		t1 = jsx(NavigableRefProvider, { children: jsx(GlobalNavAnalyticsProvider, {
			category: "GLOBAL_NAV_BAR",
			children: jsxs(TopNavProvider, {
				hasLocalNavigation,
				isSearchPage: search?.isSearchPage ?? false,
				isJumpToSearch: search?.isJumpToSearch ?? false,
				searchFragmentsPath: search?.fragmentsPath,
				searchFragmentsParams: search?.fragmentsParams,
				payloadsUrl,
				children: [
					jsxs(TopNav, { children: [
						jsx(TopNav.Above, { children: jsx(EnterpriseBanner, { ...enterpriseBanner }) }),
						jsxs(TopNav.Left, { children: [jsx(HideOnError, { children: jsx(LazyAnchoredGlobalNavMenu, {}) }), jsx(HeaderLogo, { ...headerLogo })] }),
						jsxs(TopNav.Center, {
							className: clsx(!contextRegion?.crumbs?.length && GlobalNavBar_module_default.noBreadcrumbs),
							children: [jsx(HideOnError, { children: jsx(ContextRegion, {
								...contextRegionProps,
								crumbs: contextRegion?.crumbs
							}) }), jsx(HideOnError, { children: jsx(Search, { ...search }) })]
						}),
						jsxs(TopNav.Right, { children: [
							jsxs(Stack, {
								"data-testid": "top-bar-actions",
								direction: "horizontal",
								align: "center",
								gap: "condensed",
								padding: "none",
								className: "hide-sm hide-md",
								children: [
									jsx(HideOnError, { children: jsx(CopilotItems, { ...copilot }) }),
									jsx(ItemDivider, {}),
									jsx(HideOnError, { children: jsx(LazyGlobalCreateMenu, {}) }),
									jsx(GlobalNavBarLinkItems, {
										issues,
										pulls,
										contributedRepos,
										localNavKeybindings: localNavigationKeybindings
									})
								]
							}),
							jsx(NotificationItem, { ...notifications }),
							jsx(HideOnError, { children: jsx(LazyAnchoredGlobalNavUserMenu, { ...userMenu }) }),
							jsx(LazyAccountSwitchDialog, {})
						] }),
						jsx(MobileSearch, { ...search }),
						hasLocalNavigation && jsx(HideOnError, { children: jsx(LocalNavigation, { ...contextRegion }) })
					] }),
					jsx(HideOnError, { children: jsx(QuickSearchPartial, { ...search }) }),
					globalTransactionalMessage && jsx(HideOnError, { children: jsx(TransactionalMessageBanner, { banner: globalTransactionalMessage }) })
				]
			})
		}) });
		$[2] = contextRegion;
		$[3] = contextRegionProps;
		$[4] = contributedRepos;
		$[5] = copilot;
		$[6] = enterpriseBanner;
		$[7] = globalTransactionalMessage;
		$[8] = hasLocalNavigation;
		$[9] = headerLogo;
		$[10] = issues;
		$[11] = localNavigationKeybindings;
		$[12] = notifications;
		$[13] = payloadsUrl;
		$[14] = pulls;
		$[15] = search;
		$[16] = userMenu;
		$[17] = t1;
	} else t1 = $[17];
	return t1;
}
GlobalNavBar.displayName = "GlobalNavBar";
function _temp$4(item) {
	return item.commandId ? getKeybindings(item.commandId) : [];
}
function GlobalNavBarLinkItems({ localNavKeybindings, ...props }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: [
		"issues",
		"pulls",
		"contributedRepos"
	].map((key) => {
		const { label, ...navItemProps } = GlobalNavBarItems[key];
		const { show, ...mergedProps } = {
			...navItemProps,
			...props[key]
		};
		if (show === false) return null;
		const hasConflictWithLocalNav = getKeybindings(mergedProps.commandId).some((kb) => localNavKeybindings.has(kb));
		return /* @__PURE__ */ jsx(NavLinkItem, {
			...mergedProps,
			...hasConflictWithLocalNav ? { commandId: void 0 } : {},
			"aria-label": label
		}, key);
	}) });
}
/**
* The items in the global navigation bar
* Any config set here will be the default, and can be overridden by passing props to the GlobalNavBar component
*/
GlobalNavBarLinkItems.displayName = "GlobalNavBarLinkItems";
var GlobalNavBarItems = {
	issues: {
		href: "/issues",
		icon: IssueOpenedIcon,
		label: "Issues",
		analyticsKey: "ISSUES_HEADER",
		show: true,
		commandId: "global-navigation:go-to-issues"
	},
	pulls: {
		href: "/pulls",
		icon: GitPullRequestIcon,
		label: "Pull requests",
		analyticsKey: "PULL_REQUESTS_HEADER",
		show: true,
		commandId: "global-navigation:go-to-pull-requests"
	},
	contributedRepos: {
		href: "/repos",
		label: "Repositories",
		analyticsKey: "REPOS_HEADER",
		icon: RepoIcon,
		show: false,
		commandId: "global-navigation:go-to-repositories"
	}
};
var LazyStaffbarContents = lazy(() => import("./server-staffbar-contents-2lgvujyh-Bd8-EF_q.js"));
LazyStaffbarContents.displayName = "LazyStaffbarContents";
function Staffbar(props) {
	const asideRef = useRef(null);
	useEffect(() => {
		const node = asideRef.current;
		if (node && !node.matches(":popover-open")) node.showPopover();
		return () => {
			if (node && node.matches(":popover-open")) node.hidePopover();
		};
	}, []);
	return /* @__PURE__ */ jsx("aside", {
		ref: asideRef,
		"aria-label": "Staffbar",
		popover: "manual",
		className: staffbar_module_default.container,
		children: /* @__PURE__ */ jsx(Suspense, {
			fallback: null,
			children: /* @__PURE__ */ jsx(ErrorBoundary, {
				fallback: /* @__PURE__ */ jsxs(Fragment$1, { children: [
					/* @__PURE__ */ jsx(AlertIcon, {}),
					" ",
					/* @__PURE__ */ jsx("span", { children: "Failed to render the staffbar. Check the browser console for details." })
				] }),
				children: /* @__PURE__ */ jsx(LazyStaffbarContents, { ...props })
			})
		})
	});
}
Staffbar.displayName = "Staffbar";
var CookieCategoryId = {
	Required: "Required",
	Analytics: "Analytics",
	SocialMedia: "SocialMedia",
	Advertising: "Advertising"
};
var privacyPolicyUrl = "https://docs.github.com/site-policy/privacy-policies/github-privacy-statement";
var cookieInventoryUrl = "https://docs.github.com/site-policy/privacy-policies/github-subprocessors-and-cookies";
var docsURL = "https://docs.github.com/account-and-profile/setting-up-and-managing-your-personal-account-on-github/managing-personal-account-settings/managing-your-cookie-preferences-for-githubs-enterprise-marketing-pages";
CookieCategoryId.Required, CookieCategoryId.Analytics, CookieCategoryId.SocialMedia, CookieCategoryId.Advertising;
CookieCategoryId.Required, CookieCategoryId.Analytics, CookieCategoryId.SocialMedia, CookieCategoryId.Advertising;
var themes = { github: {
	"close-button-color": "#d8b9ff",
	"secondary-button-disabled-opacity": "0.5",
	"secondary-button-hover-shadow": "none",
	"primary-button-disabled-opacity": "0.5",
	"primary-button-hover-border": "1px solid transparent",
	"primary-button-disabled-border": "1px solid transparent",
	"primary-button-hover-shadow": "none",
	"banner-background-color": "#24292f",
	"dialog-background-color": "#24292f",
	"primary-button-color": "#ffffff",
	"text-color": "#ffffff",
	"secondary-button-color": "#32383f",
	"secondary-button-disabled-color": "#424a53",
	"secondary-button-border": "1px solid #eaeef2",
	"background-color-between-page-and-dialog": "rgba(23, 23, 23, 0.8)",
	"dialog-border-color": "#d8b9ff",
	"hyperlink-font-color": "#d8b9ff",
	"secondary-button-hover-color": "#24292f",
	"secondary-button-hover-border": "1px solid #ffffff",
	"secondary-button-disabled-border": "1px solid #6e7781",
	"secondary-button-focus-border-color": "#6e7781",
	"secondary-button-text-color": "#ffffff",
	"secondary-button-disabled-text-color": "#ffffff",
	"primary-button-hover-color": "#d8b9ff",
	"primary-button-disabled-color": "#ffffff",
	"primary-button-border": "1px solid #ffffff",
	"primary-button-focus-border-color": "#ffffff",
	"primary-button-text-color": "#1f2328",
	"primary-button-disabled-text-color": "#1f2328",
	"radio-button-border-color": "#d8b9ff",
	"radio-button-checked-background-color": "#d8b9ff",
	"radio-button-hover-border-color": "#ffffff",
	"radio-button-hover-background-color": "#ffffff",
	"radio-button-disabled-color": "rgba(227, 227, 227, 0.2)",
	"radio-button-disabled-border-color": "rgba(227, 227, 227, 0.2)"
} };
var configuration_en_exports = /* @__PURE__ */ __exportAll({
	consentControlOptions: () => consentControlOptions$4,
	cookieCategories: () => cookieCategories$4
});
var CookieCategoryName$4 = {
	Required: "Required",
	Analytics: "Analytics",
	SocialMedia: "Social Media",
	Advertising: "Advertising"
};
var cookieCategories$4 = [
	{
		id: CookieCategoryId.Required,
		name: CookieCategoryName$4.Required,
		descHtml: "GitHub uses required cookies to perform essential website functions and to provide the services. For example, cookies are used to log you in, save your language preferences, provide a shopping cart experience, improve performance, route traffic between web servers, detect the size of your screen, determine page load times, improve user experience, and for audience measurement. These cookies are necessary for our websites to work.",
		isUnswitchable: true
	},
	{
		id: CookieCategoryId.Analytics,
		name: CookieCategoryName$4.Analytics,
		descHtml: "We allow third parties to use analytics cookies to understand how you use our websites so we can make them better. For example, cookies are used to gather information about the pages you visit and how many clicks you need to accomplish a task. We also use some analytics cookies to provide personalized advertising."
	},
	{
		id: CookieCategoryId.SocialMedia,
		name: CookieCategoryName$4.SocialMedia,
		descHtml: "GitHub and third parties use social media cookies to show you ads and content based on your social media profiles and activity on GitHub's websites. This ensures that the ads and content you see on our websites and on social media will better reflect your interests. This also enables third parties to develop and improve their products, which they may use on websites that are not owned or operated by GitHub."
	},
	{
		id: CookieCategoryId.Advertising,
		name: CookieCategoryName$4.Advertising,
		descHtml: "In addition, GitHub and third parties use advertising cookies to show you new ads based on ads you've already seen. Cookies also track which ads you click or purchases you make after clicking an ad. This is done to show you ads that are more relevant to you and for business purposes with our advertising partners. For example, cookies are used to detect when you click an ad and to show you ads based on your social media interests and website browsing history."
	}
];
var consentControlOptions$4 = {
	textResources: {
		bannerMessageHtml: `We use optional cookies to improve your experience on our websites and to display personalized advertising based on your online activity. If you reject optional cookies, only cookies necessary to provide you the services listed above will be used. You may change your selection on which cookies to accept by clicking "Manage Cookies" at the bottom of the page to change your selection. This selection is maintained for 180 days. Please review your selections regularly. <br/> <br/> <a href="${docsURL}">How to manage cookie preferences</a> | <a href="${privacyPolicyUrl}">Privacy Statement</a> | <a href="${cookieInventoryUrl}">Third-Party Cookies</a>.`,
		acceptAllLabel: "Accept",
		rejectAllLabel: "Reject",
		moreInfoLabel: "Manage cookies",
		preferencesDialogCloseLabel: "Close",
		preferencesDialogTitle: "Manage cookie preferences",
		preferencesDialogDescHtml: `Most GitHub websites use cookies. Cookies are small text files placed on your device to store data so web servers can use it later. GitHub and our third-party partners use cookies to remember your preferences and settings, help you sign in, show you personalized ads, and analyze how well our websites are working. For more info, see the Cookies and similar technologies section of the <a href="${privacyPolicyUrl}">Privacy Statement</a>.`
	},
	themes,
	initialTheme: "github"
};
var configuration_pt_exports = /* @__PURE__ */ __exportAll({
	consentControlOptions: () => consentControlOptions$3,
	cookieCategories: () => cookieCategories$3
});
var CookieCategoryName$3 = {
	Required: "Obrigatórios",
	Analytics: "Analíticos",
	SocialMedia: "Mídia social",
	Advertising: "Publicidade"
};
var cookieCategories$3 = [
	{
		id: CookieCategoryId.Required,
		name: CookieCategoryName$3.Required,
		descHtml: "O GitHub usa cookies obrigatórios para realizar funções essenciais do site e fornecer serviços. Por exemplo, cookies são usados para permitir seu login, salvar suas preferências de idioma, fornecer uma experiência de carrinho de compras, melhorar o desempenho, rotear tráfego entre servidores web, detectar o tamanho da sua tela, determinar tempos de carregamento de páginas, melhorar a experiência de usuário e para medição de público. Esses cookies são necessários para que nossos sites funcionem.",
		isUnswitchable: true
	},
	{
		id: CookieCategoryId.Analytics,
		name: CookieCategoryName$3.Analytics,
		descHtml: "Permitimos que terceiros usem cookies analíticos para entender como você usa nossos sites para que possamos melhorá-los. Por exemplo, cookies são usados para coletar informações sobre as páginas que você visita e quantos cliques são necessários para concluir uma tarefa. Também usamos cookies analíticos para veicular anúncios personalizados."
	},
	{
		id: CookieCategoryId.SocialMedia,
		name: CookieCategoryName$3.SocialMedia,
		descHtml: "O GitHub e terceiros usam cookies de mídia social para mostrar anúncios e conteúdo com base em seus perfis de mídia social e atividade em sites do GitHub. Isso garante que os anúncios e o conteúdo que você vê em nossos sites e redes sociais vão estar mais alinhados aos seus interesses. Também permite que terceiros desenvolvam e melhorem seus produtos, que podem ser usados em sites que não são de propriedade ou operados pelo GitHub."
	},
	{
		id: CookieCategoryId.Advertising,
		name: CookieCategoryName$3.Advertising,
		descHtml: "Além disso, o GitHub e terceiros usam cookies de publicidade para mostrar novos anúncios com base em anúncios que você já viu. Os cookies também rastreiam em quais anúncios você clicou ou compras que realizou após clicar em um anúncio. Isso é feito para veicular os anúncios que são mais relevantes para você e para fins comerciais com nossos parceiros de publicidade. Por exemplo, cookies são usados para detectar quando você clica em um anúncio e para veicular anúncios com base em seus interesses de mídia social e histórico de navegação em sites."
	}
];
var consentControlOptions$3 = {
	textResources: {
		bannerMessageHtml: `Usamos cookies opcionais para melhorar sua experiência em nossos sites e para exibir publicidade personalizada com base em sua atividade on-line. Se você rejeitar os cookies opcionais, somente serão usados os cookies necessários para fornecer os serviços listados acima. Você pode alterar sua escolha de quais cookies você aceita ao clicar em “Gerenciar cookies” no parte inferior da página. Essa escolha é mantida por 180 dias. Revise suas escolhas regularmente. <br/> <br/> <a href="${docsURL}">Como gerenciar preferências de cookies</a> | <a href="${privacyPolicyUrl}">Declaração de Privacidade</a> | <a href="${cookieInventoryUrl}">Cookies de terceiros</a>.`,
		acceptAllLabel: "Aceitar",
		rejectAllLabel: "Rejeitar",
		moreInfoLabel: "Gerenciar cookies",
		preferencesDialogCloseLabel: "Fechar",
		preferencesDialogTitle: "Gerenciar preferências de cookies",
		preferencesDialogDescHtml: `A maioria dos sites do GitHub usa cookies. Cookies são pequenos arquivos de texto que são colocados em seu dispositivo para armazenar dados para que servidores web possam usá-los posteriormente. O GitHub e nossos parceiros terceiros usam cookies para lembrar de suas preferências e configurações, permitir seu login, veicular anúncios personalizados e analisar o nível de funcionamento de nossos sites. Para obter mais informações, consulte a seção Cookies e tecnologias de rastreamento da <a href="${privacyPolicyUrl}">Declaração de Privacidade</a>.`,
		acceptLabel: "Aceitar",
		rejectLabel: "Rejeitar",
		saveLabel: "Salvar alterações",
		resetLabel: "Redefinir tudo"
	},
	themes,
	initialTheme: "github"
};
var configuration_ja_exports = /* @__PURE__ */ __exportAll({
	consentControlOptions: () => consentControlOptions$2,
	cookieCategories: () => cookieCategories$2
});
var CookieCategoryName$2 = {
	Required: "必須",
	Analytics: "分析",
	SocialMedia: "ソーシャル メディア",
	Advertising: "広告"
};
var cookieCategories$2 = [
	{
		id: CookieCategoryId.Required,
		name: CookieCategoryName$2.Required,
		descHtml: "GitHub は、必要不可欠なウェブサイト機能を実行し、サービスを提供するために必須 Cookie を使用します。Cookie の使用例には、ログインの実行、言語設定の保存、ショッピング カート エクスペリエンスの提供、パフォーマンスの向上、ウェブ サーバー間のトラフィックのルーティング、画面サイズの検知、ページ読み込み時間の確定、ユーザー エクスペリエンスの改善、およびオーディエンス測定などがあります。これらの Cookie は、GitHub ウェブサイトを機能させるために必要です。.",
		isUnswitchable: true
	},
	{
		id: CookieCategoryId.Analytics,
		name: CookieCategoryName$2.Analytics,
		descHtml: "GitHub は、分析 Cookie の使用をサードパーティに許可し、GitHub ウェブサイトの使用状況を把握することで、ウェブサイトの改善を図っています。例えば、Cookie はユーザーがアクセスするページや、タスクを完了するために必要なクリック数に関する情報を収集するために使用されます。また、パーソナライズされた広告を提供するためにも分析 Cookie を使用しています。."
	},
	{
		id: CookieCategoryId.SocialMedia,
		name: CookieCategoryName$2.SocialMedia,
		descHtml: "GitHub とサードパーティは、ユーザーのソーシャル メディア プロファイルと、GitHub ウェブサイトでのアクティビティに基づいた広告とコンテンツを表示するために、ソーシャル メディア Cookie を使用しています。これらの Cookie を使用することで、GitHub ウェブサイトやソーシャル メディアで表示される広告とコンテンツにユーザーの関心がより良く反映されるようになります。これにより、サードパーティは製品の開発および改善も可能になります。これらの製品は、GitHub が所有または運営しないウェブサイトで使用される場合があります。."
	},
	{
		id: CookieCategoryId.Advertising,
		name: CookieCategoryName$2.Advertising,
		descHtml: "上記に加えて、GitHub とサードパーティは、ユーザーが既に閲覧した広告に基づいて新しい広告を表示するための広告 Cookie も使用しています。Cookie は、ユーザーがクリックする広告や、広告をクリックした後での購入も追跡します。これは、関連性の高い広告の表示、および広告パートナーとの業務上の目的のために行われます。例えば、Cookie はユーザーが広告をクリックしたことを検知し、ソーシャル メディアでの関心やウェブサイトの閲覧履歴に基づいて広告を表示するために使用されます。."
	}
];
var consentControlOptions$2 = {
	textResources: {
		bannerMessageHtml: `GitHub は、GitHub ウェブサイトでのユーザー エクスペリエンスを向上させるとともに、オンライン アクティビティに基づいてパーソナライズされた広告を表示するために、オプションの Cookie を使用しています。オプションの Cookie を拒否する場合は、上記のサービスを提供するために必要な Cookie のみが使用されます。許可する Cookie の選択は、ページの最下部にある [Manage Cookies] をクリックすることで変更できます。この選択は 180 日間保持されます。Cookie の選択は定期的に確認するようにしてください。<br/> <br/> <a href="${docsURL}">Cookie 設定の管理方法</a> | <a href="${privacyPolicyUrl}">プライバシー ステートメント</a> | <a href="${cookieInventoryUrl}">サードパーティ Cookie</a>。`,
		acceptAllLabel: "承認",
		rejectAllLabel: "拒否",
		moreInfoLabel: "Cookieの管理",
		preferencesDialogCloseLabel: "閉じる",
		preferencesDialogTitle: "Cookie 設定を管理する",
		preferencesDialogDescHtml: `ほとんどの GitHub ウェブサイトでは、Cookie が使用されています。Cookie は、データを保存してウェブ サーバーが後ほど使用できるようにするために、デバイス上に保存される小さなテキストファイルです。GitHub と GitHub のサードパーティ パートナーは、ユーザーの好みや設定の記憶、サインインの簡略化、パーソナライズされた広告の表示、ウェブサイトの機能性を分析するために Cookie を使用します。詳細については、<a href="${privacyPolicyUrl}">プライバシー ステートメント</a>の「Cookie および類似のテクノロジとは?」セクションを参照してください。`,
		acceptLabel: "同意する",
		rejectLabel: "拒否する",
		saveLabel: "変更の保存",
		resetLabel: "すべてリセット"
	},
	themes,
	initialTheme: "github"
};
var configuration_es_exports = /* @__PURE__ */ __exportAll({
	consentControlOptions: () => consentControlOptions$1,
	cookieCategories: () => cookieCategories$1
});
var CookieCategoryName$1 = {
	Required: "Requerido",
	Analytics: "Analíticas",
	SocialMedia: "Redes sociales",
	Advertising: "Publicidad"
};
var cookieCategories$1 = [
	{
		id: CookieCategoryId.Required,
		name: CookieCategoryName$1.Required,
		descHtml: "GitHub utiliza las cookies necesarias para ejecutar las funciones esenciales del sitio web y prestar los servicios. Por ejemplo, las cookies se utilizan para iniciar sesión, guardar tus preferencias de idioma, proporcionar una buena experiencia con el carrito de la compra, mejorar el rendimiento, dirigir el tráfico entre servidores web, detectar el tamaño de la pantalla, determinar los tiempos de carga de la página, mejorar la experiencia del usuario y medir la audiencia. Estas cookies son necesarias para que nuestros sitios web funcionen.",
		isUnswitchable: true
	},
	{
		id: CookieCategoryId.Analytics,
		name: CookieCategoryName$1.Analytics,
		descHtml: "Permitimos que los terceros utilicen cookies de análisis para comprender cómo utiliza nuestros sitios web y poder mejorarlos. Por ejemplo, las cookies se utilizan para recopilar información sobre las páginas que visita y cuántos clics se necesitan para realizar una tarea. También utilizamos algunas cookies de análisis para ofrecer publicidad personalizada."
	},
	{
		id: CookieCategoryId.SocialMedia,
		name: CookieCategoryName$1.SocialMedia,
		descHtml: "GitHub y otros terceros utilizan cookies de redes sociales para mostrarte anuncios y contenidos basados en tus perfiles de redes sociales y tu actividad en los sitios web de GitHub. Esto garantiza que los anuncios y contenidos que aparecen en nuestros sitios web y en las redes sociales reflejen mejor tus intereses. Esto también permite a terceros desarrollar y mejorar sus productos, que pueden utilizar en sitios web que no son propiedad ni están gestionados por GitHub."
	},
	{
		id: CookieCategoryId.Advertising,
		name: CookieCategoryName$1.Advertising,
		descHtml: "Además, GitHub y otros terceros utilizan cookies de publicidad para mostrarte nuevos anuncios basados en los que ya has visto. Las cookies también rastrean los anuncios en los que haces clic o las compras que realizas después de hacer clic en un anuncio. Lo hacemos para mostrarte anuncios que sean más relevantes para ti y con fines comerciales con nuestros socios publicitarios. Por ejemplo, las cookies se utilizan para detectar cuándo haces clic en un anuncio y mostrarte anuncios basados en tus intereses en las redes sociales y en tu historial de navegación por el sitio web."
	}
];
var consentControlOptions$1 = {
	textResources: {
		bannerMessageHtml: `Utilizamos cookies opcionales para mejorar tu experiencia en nuestros sitios web y mostrarte publicidad personalizada basada en tu actividad en línea. Si rechazas las cookies opcionales, solo se utilizarán las cookies necesarias para prestarte los servicios indicados anteriormente. Para cambiar la selección de las cookies que deseas aceptar, haz clic en “Administrar cookies” en la parte inferior de la página. Esta selección se mantiene durante 180 días. Revisa tu selección con regularidad. <br/> <br/> <a href="${docsURL}">Cómo gestionar las preferencias de cookies</a> | <a href="${privacyPolicyUrl}">Declaración de privacidad</a> | <a href="${cookieInventoryUrl}">Cookies de terceros</a>.`,
		acceptAllLabel: "Aceptar",
		rejectAllLabel: "Rechazar",
		moreInfoLabel: "Administrar cookies",
		preferencesDialogCloseLabel: "Cerrar",
		preferencesDialogTitle: "Gestionar las preferencias de cookies",
		preferencesDialogDescHtml: `La mayoría de los sitios web de GitHub utilizan cookies. Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo para que los servidores web puedan utilizarlos posteriormente. GitHub y nuestros socios terceros utilizan cookies para recordar tus preferencias y configuración, ayudarte a iniciar sesión, mostrarte anuncios personalizados y analizar el funcionamiento de nuestros sitios web. Para obtener más información, consulta la sección Cookies y tecnologías similares de la <a href="${privacyPolicyUrl}">Declaración de privacidad</a>.`,
		acceptLabel: "Aceptar",
		rejectLabel: "Rechazar",
		saveLabel: "Guardar cambios",
		resetLabel: "Restablecer todas"
	},
	themes,
	initialTheme: "github"
};
var configuration_ko_exports = /* @__PURE__ */ __exportAll({
	consentControlOptions: () => consentControlOptions,
	cookieCategories: () => cookieCategories
});
var CookieCategoryName = {
	Required: "필수",
	Analytics: "분석",
	SocialMedia: "소셜 미디어",
	Advertising: "광고"
};
var cookieCategories = [
	{
		id: CookieCategoryId.Required,
		name: CookieCategoryName.Required,
		descHtml: "GitHub는 필수 웹 사이트 기능을 수행하고 서비스를 제공하기 위해 필수 쿠키를 사용합니다. 예를 들어, 쿠키는 로그인, 언어 기본 설정 저장, 장바구니 환경 제공, 성능 개선, 웹 서버 간 트래픽 라우팅, 화면 크기 감지, 페이지 로드 시간 결정, 사용자 경험 개선, 인터넷 방문자 분석 등에 사용됩니다. 이러한 쿠키는 웹 사이트 작동에 필요합니다.",
		isUnswitchable: true
	},
	{
		id: CookieCategoryId.Analytics,
		name: CookieCategoryName.Analytics,
		descHtml: "당사는 타사가 웹 사이트 개선을 위해 사용자가 당사 웹 사이트를 어떻게 사용하는지 파악하는 데 분석 쿠키를 사용하는 것을 허용합니다. 예를 들어, 쿠키는 사용자가 방문한 페이지와 작업을 완료하는 데 필요한 클릭 수에 대한 정보를 수집하는 데 사용됩니다. 맞춤형 광고를 제공하기 위해 일부 분석 쿠키도 사용됩니다."
	},
	{
		id: CookieCategoryId.SocialMedia,
		name: CookieCategoryName.SocialMedia,
		descHtml: "GitHub와 타사는 소셜 미디어 쿠키를 사용하여 사용자의 소셜 미디어 프로필과 GitHub 웹 사이트 활동을 기반으로 광고와 콘텐츠를 표시합니다. 이를 통해 당사 웹 사이트와 소셜 미디어에서 사용자가 보는 광고와 콘텐츠가 사용자의 관심사를 더 잘 반영할 수 있습니다. 또한 이를 통해 타사는 GitHub가 소유하거나 운영하지 않는 웹 사이트에서 사용할 수 있는 제품을 개발하고 개선할 수 있습니다."
	},
	{
		id: CookieCategoryId.Advertising,
		name: CookieCategoryName.Advertising,
		descHtml: "GitHub와 타사는 광고 쿠키를 사용하여 사용자가 이미 본 광고를 기반으로 새로운 광고를 표시합니다. 또한 쿠키는 사용자가 어떤 광고를 클릭했는지 또는 광고 클릭 후 무엇을 구매했는지 추적합니다. 이는 사용자에게 더 관련성이 높은 광고를 표시하고 광고 파트너와의 비즈니스 목적을 위해 수행됩니다. 예를 들어, 쿠키는 사용자가 광고를 클릭하는 시점을 감지하고 소셜 미디어 관심사 및 웹 사이트 검색 기록을 기반으로 광고를 표시하는 데 사용됩니다."
	}
];
var consentControlOptions = {
	textResources: {
		bannerMessageHtml: `당사는 선택적 쿠키를 사용하여 웹 사이트 경험을 개선하고 사용자의 온라인 활동을 기반으로 맞춤 광고를 표시합니다. 선택적 쿠키를 거부하면 위에 나열된 서비스를 제공하는 데 필요한 쿠키만 사용됩니다. 페이지 하단의 "쿠키 관리"를 클릭하여 허용할 쿠키에 대한 선택 사항을 변경할 수 있습니다. 이 선택 사항은 180일 동안 유지됩니다. 정기적으로 선택 사항을 검토하십시오.<br/> <br/> <a href="${docsURL}">쿠키 기본 설정 관리 방법</a> | <a href="${privacyPolicyUrl}">개인 정보 보호 정책</a> | <a href="${cookieInventoryUrl}">타사 쿠키</a>`,
		acceptAllLabel: "허용",
		rejectAllLabel: "거부",
		moreInfoLabel: "쿠키 관리",
		preferencesDialogCloseLabel: "닫기",
		preferencesDialogTitle: "쿠키 기본 설정 관리",
		preferencesDialogDescHtml: `대부분의 GitHub 웹 사이트에서 쿠키를 사용합니다. 쿠키는 웹 서버가 나중에 사용할 수 있도록 데이터를 저장하기 위해 사용자 장치에 배치되는 작은 텍스트 파일입니다. GitHub와 타사 파트너는 쿠키를 사용하여 사용자의 기본 설정과 설정을 기억하고, 로그인을 돕고, 맞춤 광고를 표시하고, 웹 사이트가 얼마나 잘 작동하는지 분석합니다. 자세한 내용은 <a href="${privacyPolicyUrl}">개인 정보 보호 정책</a>의 쿠키 및 유사 기술 섹션을 참조하십시오.`,
		acceptLabel: "동의",
		rejectLabel: "거부",
		saveLabel: "변경 사항 저장",
		resetLabel: "모두 재설정"
	},
	themes,
	initialTheme: "github"
};
var languageConfigs = {
	en: configuration_en_exports,
	pt: configuration_pt_exports,
	ja: configuration_ja_exports,
	es: configuration_es_exports,
	ko: configuration_ko_exports
};
var CONSENT_COOKIE_NAME = "GHCC";
var CONSENT_COOKIE_EXPIRATION_DATE = new Date(Date.now() + 1e3 * 60 * 60 * 24 * 180);
var consentControlInstance;
var onPreferenceChange = async (preferences) => {
	setPreferencesToCookie(preferences);
	consentControlInstance?.hideBanner();
};
async function initializeConsentControl(locale = "en") {
	const { ConsentControl } = await import("consent-banner");
	const baseLocale = locale.split("-")[0] || "en";
	const config = languageConfigs[baseLocale] ? languageConfigs[baseLocale] : languageConfigs["en"];
	if (!config) throw new Error(`No language config found for locale: ${locale}`);
	const cookieCategories = config.cookieCategories;
	const consentControlOptions = config.consentControlOptions;
	consentControlInstance = new ConsentControl("ghcc", locale, onPreferenceChange, cookieCategories, consentControlOptions);
	return consentControlInstance;
}
function showPreferences() {
	consentControlInstance?.showPreferences(getPreferencesFromCookie() || {});
}
var consentPromiseWithResolvers = Promise.withResolvers();
function setPreferencesToCookie(preferences) {
	setCookie(CONSENT_COOKIE_NAME, Object.keys(preferences).map((cookieCategoryId) => `${cookieCategoryId}:${preferences[cookieCategoryId] ? "1" : "0"}`).join("-"), CONSENT_COOKIE_EXPIRATION_DATE.toUTCString());
	consentPromiseWithResolvers.resolve(preferences);
}
function getPreferencesFromCookie() {
	const preferencesCookie = getCookie(CONSENT_COOKIE_NAME);
	if (!preferencesCookie) return null;
	const preferences = preferencesCookie.value.split("-");
	const cookieCategoriesPreferences = {};
	for (const cookieParts of preferences) {
		const [cookieCategoryId, preference] = cookieParts.split(":");
		if (cookieCategoryId) cookieCategoriesPreferences[cookieCategoryId] = preference === "1";
	}
	return cookieCategoriesPreferences;
}
var initialConsent = getPreferencesFromCookie();
if (initialConsent) consentPromiseWithResolvers.resolve(initialConsent);
var Footer_module_default = {
	adminModeState: "Footer-module_H2lBzq_adminModeState",
	container: "Footer-module_H2lBzq_container",
	copyright: "Footer-module_H2lBzq_copyright",
	footer: "Footer-module_H2lBzq_footer",
	footerLink: "Footer-module_H2lBzq_footerLink",
	linkItem: "Footer-module_H2lBzq_linkItem",
	linkList: "Footer-module_H2lBzq_linkList",
	logoLink: "Footer-module_H2lBzq_logoLink",
	responsivePadding: "Footer-module_H2lBzq_responsivePadding",
	textButton: "Footer-module_H2lBzq_textButton"
};
var DOTCOM_FOOTER_LINKS = [
	{
		name: "Terms",
		href: "https://docs.github.com/site-policy/github-terms/github-terms-of-service",
		analyticsAction: "go to Terms"
	},
	{
		name: "Privacy",
		href: "https://docs.github.com/site-policy/privacy-policies/github-privacy-statement",
		analyticsAction: "go to privacy"
	},
	{
		name: "Security",
		href: "https://github.com/security",
		analyticsAction: "go to security"
	},
	{
		name: "Status",
		href: "https://www.githubstatus.com/",
		analyticsAction: "go to status",
		testId: "footer_status_link"
	},
	{
		name: "Community",
		href: "https://github.community/",
		analyticsAction: "go to community",
		testId: "footer_community_link"
	},
	{
		name: "Docs",
		href: "https://docs.github.com/",
		analyticsAction: "go to docs"
	},
	{
		name: "Contact",
		href: "https://support.github.com?tags=dotcom-footer",
		analyticsAction: "go to contact"
	}
];
function Footer(t0) {
	const $ = c(16);
	const { showAdminToggle: t1, isAdminModeOn: t2, adminTogglePath, showUiOptOut: t3, isUiOptedOut: t4, uiOptOutTogglePath, showCookieConsentLinks: t5, isEnterprise: t6, helpUrl, supportUrl, noHorizontalPadding: t7 } = t0;
	const showAdminToggle = t1 === void 0 ? false : t1;
	const isAdminModeOn = t2 === void 0 ? false : t2;
	const showUiOptOut = t3 === void 0 ? false : t3;
	const isUiOptedOut = t4 === void 0 ? false : t4;
	const showCookieConsentLinks = t5 === void 0 ? false : t5;
	const isEnterprise = t6 === void 0 ? false : t6;
	const noHorizontalPadding = t7 === void 0 ? false : t7;
	let t8;
	if ($[0] !== adminTogglePath || $[1] !== helpUrl || $[2] !== isAdminModeOn || $[3] !== isEnterprise || $[4] !== isUiOptedOut || $[5] !== noHorizontalPadding || $[6] !== showAdminToggle || $[7] !== showCookieConsentLinks || $[8] !== showUiOptOut || $[9] !== supportUrl || $[10] !== uiOptOutTogglePath) {
		const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
		let t9;
		if ($[12] !== adminTogglePath) {
			t9 = async () => {
				if (adminTogglePath) try {
					await reactFetch(adminTogglePath, { method: "PATCH" });
					window.location.reload();
				} catch {
					console.error("Failed to toggle site admin mode");
				}
			};
			$[12] = adminTogglePath;
			$[13] = t9;
		} else t9 = $[13];
		const handleAdminToggle = t9;
		let t10;
		if ($[14] !== uiOptOutTogglePath) {
			t10 = async () => {
				if (uiOptOutTogglePath) try {
					await reactFetch(uiOptOutTogglePath, { method: "PATCH" });
					window.location.reload();
				} catch {
					console.error("Failed to toggle UI service opt-out");
				}
			};
			$[14] = uiOptOutTogglePath;
			$[15] = t10;
		} else t10 = $[15];
		const handleUiOptOutToggle = t10;
		t8 = jsxs("footer", {
			className: clsx(Footer_module_default.footer, !noHorizontalPadding && Footer_module_default.responsivePadding),
			role: "contentinfo",
			"data-testid": "global_footer",
			children: [jsx("h2", {
				className: "sr-only",
				children: "Footer"
			}), jsxs("div", {
				className: Footer_module_default.container,
				children: [jsxs("div", {
					className: Footer_module_default.copyright,
					children: [jsx("a", {
						"aria-label": "GitHub Homepage",
						className: Footer_module_default.logoLink,
						href: "https://github.com",
						children: jsx(MarkGithubIcon, { size: 24 })
					}), jsxs("span", { children: [
						"©",
						currentYear,
						" GitHub,\xA0Inc."
					] })]
				}), jsxs("nav", {
					"aria-label": "Footer",
					children: [jsx("h3", {
						className: "sr-only",
						id: "sr-footer-heading",
						children: "Footer navigation"
					}), jsxs("ul", {
						className: Footer_module_default.linkList,
						"aria-labelledby": "sr-footer-heading",
						children: [
							showAdminToggle && adminTogglePath && jsx("li", {
								className: Footer_module_default.linkItem,
								children: jsxs("button", {
									type: "button",
									"data-hotkey": "`,Shift+S",
									className: Footer_module_default.textButton,
									onClick: handleAdminToggle,
									"aria-pressed": isAdminModeOn,
									"aria-label": isAdminModeOn ? "Turn off site admin mode (currently on)" : "Turn on site admin mode (currently off)",
									"data-analytics-event": JSON.stringify({
										location: "footer",
										action: "toggle_site_admin_mode",
										label: `state:${isAdminModeOn ? "on" : "off"}`
									}),
									children: ["Site admin mode ", jsx("span", {
										className: Footer_module_default.adminModeState,
										children: isAdminModeOn ? "on" : "off"
									})]
								})
							}),
							showUiOptOut && uiOptOutTogglePath && jsx("li", {
								className: Footer_module_default.linkItem,
								children: jsxs("button", {
									type: "button",
									className: Footer_module_default.textButton,
									onClick: handleUiOptOutToggle,
									"aria-pressed": isUiOptedOut,
									"aria-label": isUiOptedOut ? "Opt in to UI service (currently opted out)" : "Opt out of UI service (currently opted in)",
									"data-analytics-event": JSON.stringify({
										location: "footer",
										action: "toggle_ui_service_opt_out",
										label: `state:${isUiOptedOut ? "opted_out" : "opted_in"}`
									}),
									children: ["UI service ", jsx("span", {
										className: Footer_module_default.adminModeState,
										children: isUiOptedOut ? "off" : "on"
									})]
								})
							}),
							isEnterprise ? jsxs(Fragment$1, { children: [helpUrl && jsx("li", {
								className: Footer_module_default.linkItem,
								children: jsx(Link$1$1, {
									to: helpUrl,
									className: Footer_module_default.footerLink,
									"data-analytics-event": JSON.stringify({
										category: "Footer",
										action: "go to help",
										label: "text:help"
									}),
									children: "Help"
								})
							}), supportUrl && jsx("li", {
								className: Footer_module_default.linkItem,
								children: jsx(Link$1$1, {
									to: supportUrl,
									className: Footer_module_default.footerLink,
									"data-analytics-event": JSON.stringify({
										category: "Footer",
										action: "go to support",
										label: "text:support"
									}),
									children: "Support"
								})
							})] }) : DOTCOM_FOOTER_LINKS.map(_temp$3),
							showCookieConsentLinks && !isEnterprise && jsxs(Fragment$1, { children: [jsx("li", {
								className: Footer_module_default.linkItem,
								children: jsx("button", {
									type: "button",
									className: Footer_module_default.textButton,
									onClick: showPreferences,
									"data-analytics-event": JSON.stringify({
										location: "footer",
										action: "cookies",
										context: "subfooter",
										tag: "link",
										label: "cookies_link_subfooter_footer"
									}),
									children: "Manage cookies"
								})
							}), jsx("li", {
								className: Footer_module_default.linkItem,
								children: jsx("button", {
									type: "button",
									className: Footer_module_default.textButton,
									onClick: showPreferences,
									"data-analytics-event": JSON.stringify({
										location: "footer",
										action: "dont_share_info",
										context: "subfooter",
										tag: "link",
										label: "dont_share_info_link_subfooter_footer"
									}),
									children: "Do not share my personal information"
								})
							})] })
						]
					})]
				})]
			})]
		});
		$[0] = adminTogglePath;
		$[1] = helpUrl;
		$[2] = isAdminModeOn;
		$[3] = isEnterprise;
		$[4] = isUiOptedOut;
		$[5] = noHorizontalPadding;
		$[6] = showAdminToggle;
		$[7] = showCookieConsentLinks;
		$[8] = showUiOptOut;
		$[9] = supportUrl;
		$[10] = uiOptOutTogglePath;
		$[11] = t8;
	} else t8 = $[11];
	return t8;
}
Footer.displayName = "Footer";
function _temp$3(link) {
	return jsx("li", {
		className: Footer_module_default.linkItem,
		children: jsx(Link$1$1, {
			to: link.href,
			className: Footer_module_default.footerLink,
			"data-analytics-event": JSON.stringify({
				category: "Footer",
				action: link.analyticsAction,
				label: `text:${link.name.toLowerCase()}`
			}),
			...link.testId && { "data-testid": link.testId },
			children: link.name
		})
	}, link.name);
}
var KeyboardShortcutsDialog_module_default = {
	LoadingStateContainer: "KeyboardShortcutsDialog-module_cRuLcG_LoadingStateContainer",
	ShortcutsDialogRoot: "KeyboardShortcutsDialog-module_cRuLcG_ShortcutsDialogRoot"
};
var LazyDialogContent = lazyWithPreload(() => import("./server-ShortcutsDialogContent-DvJVRVOr-wclv4zPe.js"));
/**
* Read keyboard shortcut contexts from meta tag. Returns a comma-separated list of contexts. If an empty string, the
* only context is global so we will still fetch site-wide shortcuts. If `undefined`, the meta tag was not found and
* shortcut fetching is skipped.
*/
function getContexts() {
	return document.querySelector("meta[name=github-keyboard-shortcuts]")?.content;
}
var LoadingState = () => /* @__PURE__ */ jsxs("div", {
	role: "status",
	className: KeyboardShortcutsDialog_module_default.LoadingStateContainer,
	children: [/* @__PURE__ */ jsx(Spinner, { size: "large" }), /* @__PURE__ */ jsx("span", {
		className: "sr-only",
		children: strings_default.loading
	})]
});
LoadingState.displayName = "LoadingState";
function KeyboardShortcutsDialog(t0) {
	const $ = c(7);
	const { docsUrl } = t0;
	const [contexts, setContexts] = useState(null);
	const queryClient = useQueryClient();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	useEffect(_temp2$1, t1);
	let t2;
	if ($[1] !== queryClient) {
		t2 = () => {
			const ctx = getContexts();
			setContexts(ctx);
			queryClient.prefetchQuery(getQueryOptions(ctx));
		};
		$[1] = queryClient;
		$[2] = t2;
	} else t2 = $[2];
	const showDialog = t2;
	let t3;
	if ($[3] !== contexts || $[4] !== docsUrl || $[5] !== showDialog) {
		t3 = jsxs(Fragment$1, { children: [jsx(GlobalCommands, { commands: { "global-navigation:show-shortcuts-dialog": showDialog } }), contexts !== null && jsx(Dialog, {
			title: strings_default.keyboardShortcuts,
			"aria-modal": "true",
			width: "xlarge",
			height: "large",
			onClose: () => setContexts(null),
			className: KeyboardShortcutsDialog_module_default.ShortcutsDialogRoot,
			children: jsx(ErrorBoundary, {
				fallback: jsxs(BlankslateContainer, {
					narrow: true,
					children: [
						jsx(BlankslateContainer.Visual, { children: jsx(AlertIcon, { size: "medium" }) }),
						jsx(BlankslateContainer.Heading, { children: strings_default.errorTitle }),
						jsx(BlankslateContainer.Description, { children: strings_default.errorMessage })
					]
				}),
				children: jsx(Suspense, {
					fallback: jsx(LoadingState, {}),
					children: jsx(LazyDialogContent, {
						contexts,
						docsUrl
					})
				})
			})
		})] });
		$[3] = contexts;
		$[4] = docsUrl;
		$[5] = showDialog;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
KeyboardShortcutsDialog.displayName = "KeyboardShortcutsDialog";
function _temp2$1() {
	const id = requestIdleCallback(_temp$2);
	return () => cancelIdleCallback(id);
}
function _temp$2() {
	LazyDialogContent.preload();
}
var FlashMessagesArray = { toKey: (messages) => messages.reduce((acc, [type, message]) => `${acc}${type}:${message};`, "") };
/** Renders simple (text-only) `flash` message banners from previous actions. */
function FlashMessages({ messages }) {
	return /* @__PURE__ */ jsx(DismissableMessages, { messages }, FlashMessagesArray.toKey(messages));
}
FlashMessages.displayName = "FlashMessages";
var flashTypeProps = {
	error: {
		variant: "critical",
		title: "Error"
	},
	warn: {
		variant: "warning",
		title: "Warning"
	},
	success: {
		variant: "success",
		title: "Success"
	},
	notice: {
		variant: "info",
		title: "Notice"
	},
	message: {
		variant: "info",
		title: "Notice"
	}
};
function DismissableMessages(t0) {
	const $ = c(6);
	const { messages } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ new Set();
		$[0] = t1;
	} else t1 = $[0];
	const [dismissedFlashIndices, dismissFlash] = useReducer(_temp$1, t1);
	let t2;
	if ($[1] !== dismissedFlashIndices || $[2] !== messages) {
		let t3;
		if ($[4] !== dismissedFlashIndices) {
			t3 = (t4, i) => {
				const [type, message] = t4;
				return dismissedFlashIndices.has(i) ? null : jsx(Banner, {
					flush: true,
					hideTitle: true,
					description: message,
					style: { borderTop: "none" },
					onDismiss: () => dismissFlash(i),
					...flashTypeProps[type]
				}, i);
			};
			$[4] = dismissedFlashIndices;
			$[5] = t3;
		} else t3 = $[5];
		t2 = jsx(Fragment$1, { children: messages.map(t3) });
		$[1] = dismissedFlashIndices;
		$[2] = messages;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
DismissableMessages.displayName = "DismissableMessages";
function _temp$1(prev, index) {
	return new Set([...prev, index]);
}
function GlobalBanners(t0) {
	const $ = c(3);
	const { flashMessages } = t0;
	const ssoRouteInfo = useSsoRouteInfo();
	let t1;
	if ($[0] !== flashMessages || $[1] !== ssoRouteInfo) {
		t1 = jsxs(Fragment$1, { children: [ssoRouteInfo && jsx(ErrorBoundary, {
			fallback: null,
			children: jsx(SsoBanner, { ssoRouteInfo })
		}), flashMessages && jsx(ErrorBoundary, {
			fallback: null,
			children: jsx(FlashMessages, { messages: flashMessages })
		})] });
		$[0] = flashMessages;
		$[1] = ssoRouteInfo;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
GlobalBanners.displayName = "GlobalBanners";
function SsoBanner({ ssoRouteInfo }) {
	const { queryRoute, queryName, key } = ssoRouteInfo;
	const queryClient = useQueryClient();
	const seenQueryKeysRef = useRef(/* @__PURE__ */ new Map());
	const { data, queryKey } = useRouteQuery(queryRoute, queryName, { select: useCallback((d) => ({
		ssoOrgs: d.payload?.[key]?.["sso_organizations"] || null,
		showSsoBanner: d.payload?.[key]?.["current_sso_orgs_match_dismissed_cookie"] !== true
	}), [key]) });
	const { ssoOrgs, showSsoBanner } = data || {};
	useEffect(() => {
		if (!ssoOrgs || !showSsoBanner) return;
		const hashed = hashKey(queryKey);
		if (!seenQueryKeysRef.current.has(hashed)) seenQueryKeysRef.current.set(hashed, queryKey);
	}, [
		queryKey,
		ssoOrgs,
		showSsoBanner
	]);
	const onConfirm = useCallback(() => {
		for (const trackedKey of seenQueryKeysRef.current.values()) queryClient.setQueryData(trackedKey, (oldData) => {
			if (!oldData) return oldData;
			return produce(oldData, (draft) => {
				if (draft?.payload?.[key]) draft.payload[key].current_sso_orgs_match_dismissed_cookie = true;
			});
		});
		seenQueryKeysRef.current.clear();
	}, [key, queryClient]);
	return ssoOrgs && showSsoBanner ? /* @__PURE__ */ jsx(LazyGlobalSsoBanner, {
		ssoOrgs,
		onConfirm
	}) : null;
}
SsoBanner.displayName = "SsoBanner";
function useSsoRouteInfo() {
	const $ = c(11);
	const matches = useMatches();
	let t0;
	if ($[0] !== matches) {
		t0 = matches.findLast(_temp);
		$[0] = matches;
		$[1] = t0;
	} else t0 = $[1];
	const deepestMatch = t0;
	if (!deepestMatch?.staticData.showSsoPrompt) return null;
	let t1;
	if ($[2] !== deepestMatch || $[3] !== matches) {
		t1 = deepestMatch?.staticData.sso ? deepestMatch : matches.find(_temp2);
		$[2] = deepestMatch;
		$[3] = matches;
		$[4] = t1;
	} else t1 = $[4];
	const ssoDataMatch = t1;
	if (!ssoDataMatch) return null;
	const queryRoute = ssoDataMatch?.staticData.queryRoute;
	let t2;
	if ($[5] !== ssoDataMatch.staticData.sso) {
		t2 = ssoDataMatch.staticData.sso ?? [];
		$[5] = ssoDataMatch.staticData.sso;
		$[6] = t2;
	} else t2 = $[6];
	const [queryName, key] = t2;
	if (queryRoute && queryName) {
		const t3 = key || "sso";
		let t4;
		if ($[7] !== queryName || $[8] !== queryRoute || $[9] !== t3) {
			t4 = {
				queryRoute,
				queryName,
				key: t3
			};
			$[7] = queryName;
			$[8] = queryRoute;
			$[9] = t3;
			$[10] = t4;
		} else t4 = $[10];
		return t4;
	}
	return null;
}
function _temp2(match_0) {
	return match_0.staticData.sso !== void 0;
}
function _temp(match) {
	return match.staticData?.showSsoPrompt !== void 0;
}
function Layout() {
	const { globalNavigation, staffbar, footer, globalBanners } = getRouteApi("/_nav").useLoaderData();
	const contextRegion = useContextRegion();
	useEffect(() => {
		if (footer?.showCookieConsentLinks) initializeConsentControl();
	}, [footer?.showCookieConsentLinks]);
	return /* @__PURE__ */ jsxs("div", { children: [
		/* @__PURE__ */ jsxs("div", {
			style: { minHeight: "101vh" },
			children: [
				staffbar && /* @__PURE__ */ jsx(Staffbar, { ...staffbar }),
				/* @__PURE__ */ jsx(GlobalNavBar, {
					...globalNavigation,
					contextRegion
				}),
				/* @__PURE__ */ jsx(GlobalBanners, { flashMessages: globalBanners.flashMessages }),
				/* @__PURE__ */ jsx(Outlet, {})
			]
		}),
		footer && /* @__PURE__ */ jsx(Footer, { ...footer }),
		footer?.showCookieConsentLinks && /* @__PURE__ */ jsx("div", { id: "ghcc" }),
		/* @__PURE__ */ jsx(KeyboardShortcutsDialog, { docsUrl: "https://docs.github.com/get-started/accessibility/keyboard-shortcuts" })
	] });
}
Layout.displayName = "Layout";
function useContextRegion() {
	const matches = useMatches();
	return matches[matches.length - 1]?.context?.navigation;
}
var SplitComponent = Layout;
export { SplitComponent as component };
