function getLanguageInfo(name) {
	const key = name.toUpperCase();
	let info = languageMap[key];
	if (!info && languageAliases[key]) info = languageMap[languageAliases[key]];
	return info ?? { name };
}
var docLanguages = new Set(["Markdown", "MDX"]);
/**
* Often, the language name copilot uses is different than what we expect so we try to map them here.
*/
var languageAliases = {
	CPP: "C++",
	CSHARP: "C#",
	FSHARP: "F#",
	VBNET: "VISUAL BASIC .NET"
};
/**
* Map of programming languages to colors.
*
* Extracted from https://github.com/github-linguist/linguist/blob/main/lib/linguist/languages.yml
* Generated with this program:
*   const fs = require('fs');
*   const yaml = require('js-yaml');
*   const input = fs.readFileSync('languages.yml').toString();
*   const inLanguages = yaml.load(input);
*   const outLanguages = {};
*   for (const [k, v] of Object.entries(inLanguages)) {
*     const outKey = k.toUpperCase();
*     const obj = ({color: v.color, name: k, extensions: v.extensions});
*     if (v.wrap) obj.wrap = true
*     outLanguages[outKey] = obj;
*   }
*   fs.writeFileSync('languages_out.json', JSON.stringify(outLanguages));
*/
var languageMap = {
	"1C ENTERPRISE": {
		color: "#814CCC",
		name: "1C Enterprise",
		extensions: [".bsl", ".os"]
	},
	"2-DIMENSIONAL ARRAY": {
		color: "#38761D",
		name: "2-Dimensional Array",
		extensions: [".2da"]
	},
	"4D": {
		color: "#004289",
		name: "4D",
		extensions: [".4dm"]
	},
	ABAP: {
		color: "#E8274B",
		name: "ABAP",
		extensions: [".abap"]
	},
	"ABAP CDS": {
		color: "#555e25",
		name: "ABAP CDS",
		extensions: [".asddls"]
	},
	ABNF: {
		name: "ABNF",
		extensions: [".abnf"]
	},
	"AGS SCRIPT": {
		color: "#B9D9FF",
		name: "AGS Script",
		extensions: [".asc", ".ash"]
	},
	AIDL: {
		color: "#34EB6B",
		name: "AIDL",
		extensions: [".aidl"]
	},
	AL: {
		color: "#3AA2B5",
		name: "AL",
		extensions: [".al"]
	},
	AMPL: {
		color: "#E6EFBB",
		name: "AMPL",
		extensions: [".ampl", ".mod"]
	},
	ANTLR: {
		color: "#9DC3FF",
		name: "ANTLR",
		extensions: [".g4"]
	},
	"API BLUEPRINT": {
		color: "#2ACCA8",
		name: "API Blueprint",
		extensions: [".apib"]
	},
	APL: {
		color: "#5A8164",
		name: "APL",
		extensions: [".apl", ".dyalog"]
	},
	ASL: {
		name: "ASL",
		extensions: [".asl", ".dsl"]
	},
	"ASN.1": {
		name: "ASN.1",
		extensions: [".asn", ".asn1"]
	},
	"ASP.NET": {
		color: "#9400ff",
		name: "ASP.NET",
		extensions: [
			".asax",
			".ascx",
			".ashx",
			".asmx",
			".aspx",
			".axd"
		]
	},
	ATS: {
		color: "#1ac620",
		name: "ATS",
		extensions: [
			".dats",
			".hats",
			".sats"
		]
	},
	ACTIONSCRIPT: {
		color: "#882B0F",
		name: "ActionScript",
		extensions: [".as"]
	},
	ADA: {
		color: "#02f88c",
		name: "Ada",
		extensions: [
			".adb",
			".ada",
			".ads"
		]
	},
	"ADBLOCK FILTER LIST": {
		color: "#800000",
		name: "Adblock Filter List",
		extensions: [".txt"]
	},
	"ADOBE FONT METRICS": {
		color: "#fa0f00",
		name: "Adobe Font Metrics",
		extensions: [".afm"]
	},
	AGDA: {
		color: "#315665",
		name: "Agda",
		extensions: [".agda"]
	},
	AIKEN: {
		color: "#640ff8",
		name: "Aiken",
		extensions: [".ak"]
	},
	ALLOY: {
		color: "#64C800",
		name: "Alloy",
		extensions: [".als"]
	},
	"ALPINE ABUILD": {
		color: "#0D597F",
		name: "Alpine Abuild"
	},
	"ALTIUM DESIGNER": {
		color: "#A89663",
		name: "Altium Designer",
		extensions: [
			".OutJob",
			".PcbDoc",
			".PrjPCB",
			".SchDoc"
		]
	},
	ANGELSCRIPT: {
		color: "#C7D7DC",
		name: "AngelScript",
		extensions: [".as", ".angelscript"]
	},
	"ANSWER SET PROGRAMMING": {
		color: "#A9CC29",
		name: "Answer Set Programming",
		extensions: [".lp"]
	},
	"ANT BUILD SYSTEM": {
		color: "#A9157E",
		name: "Ant Build System"
	},
	ANTLERS: {
		color: "#ff269e",
		name: "Antlers",
		extensions: [
			".antlers.html",
			".antlers.php",
			".antlers.xml"
		]
	},
	APACHECONF: {
		color: "#d12127",
		name: "ApacheConf",
		extensions: [".apacheconf", ".vhost"]
	},
	APEX: {
		color: "#1797c0",
		name: "Apex",
		extensions: [
			".cls",
			".apex",
			".trigger"
		]
	},
	"APOLLO GUIDANCE COMPUTER": {
		color: "#0B3D91",
		name: "Apollo Guidance Computer",
		extensions: [".agc"]
	},
	APPLESCRIPT: {
		color: "#101F1F",
		name: "AppleScript",
		extensions: [".applescript", ".scpt"]
	},
	ARC: {
		color: "#aa2afe",
		name: "Arc",
		extensions: [".arc"]
	},
	ASCIIDOC: {
		color: "#73a0c5",
		name: "AsciiDoc",
		extensions: [
			".asciidoc",
			".adoc",
			".asc"
		],
		wrap: true
	},
	ASPECTJ: {
		color: "#a957b0",
		name: "AspectJ",
		extensions: [".aj"]
	},
	ASSEMBLY: {
		color: "#6E4C13",
		name: "Assembly",
		extensions: [
			".asm",
			".a51",
			".i",
			".inc",
			".nas",
			".nasm",
			".s"
		]
	},
	ASTRO: {
		color: "#ff5a03",
		name: "Astro",
		extensions: [".astro"]
	},
	ASYMPTOTE: {
		color: "#ff0000",
		name: "Asymptote",
		extensions: [".asy"]
	},
	AUGEAS: {
		color: "#9CC134",
		name: "Augeas",
		extensions: [".aug"]
	},
	AUTOHOTKEY: {
		color: "#6594b9",
		name: "AutoHotkey",
		extensions: [".ahk", ".ahkl"]
	},
	AUTOIT: {
		color: "#1C3552",
		name: "AutoIt",
		extensions: [".au3"]
	},
	"AVRO IDL": {
		color: "#0040FF",
		name: "Avro IDL",
		extensions: [".avdl"]
	},
	AWK: {
		color: "#c30e9b",
		name: "Awk",
		extensions: [
			".awk",
			".auk",
			".gawk",
			".mawk",
			".nawk"
		]
	},
	B4X: {
		color: "#00e4ff",
		name: "B4X",
		extensions: [".bas"]
	},
	BASIC: {
		color: "#ff0000",
		name: "BASIC",
		extensions: [".bas"]
	},
	BQN: {
		color: "#2b7067",
		name: "BQN",
		extensions: [".bqn"]
	},
	BALLERINA: {
		color: "#FF5000",
		name: "Ballerina",
		extensions: [".bal"]
	},
	BATCHFILE: {
		color: "#C1F12E",
		name: "Batchfile",
		extensions: [".bat", ".cmd"]
	},
	BEEF: {
		color: "#a52f4e",
		name: "Beef",
		extensions: [".bf"]
	},
	BEFUNGE: {
		name: "Befunge",
		extensions: [".befunge", ".bf"]
	},
	BERRY: {
		color: "#15A13C",
		name: "Berry",
		extensions: [".be"]
	},
	BIBTEX: {
		color: "#778899",
		name: "BibTeX",
		extensions: [".bib", ".bibtex"]
	},
	"BIBTEX STYLE": {
		name: "BibTeX Style",
		extensions: [".bst"]
	},
	BICEP: {
		color: "#519aba",
		name: "Bicep",
		extensions: [".bicep", ".bicepparam"]
	},
	BIKESHED: {
		color: "#5562ac",
		name: "Bikeshed",
		extensions: [".bs"]
	},
	BISON: {
		color: "#6A463F",
		name: "Bison",
		extensions: [".bison"]
	},
	BITBAKE: {
		color: "#00bce4",
		name: "BitBake",
		extensions: [
			".bb",
			".bbappend",
			".bbclass",
			".inc"
		]
	},
	BLADE: {
		color: "#f7523f",
		name: "Blade",
		extensions: [".blade", ".blade.php"]
	},
	BLITZBASIC: {
		color: "#00FFAE",
		name: "BlitzBasic",
		extensions: [".bb", ".decls"]
	},
	BLITZMAX: {
		color: "#cd6400",
		name: "BlitzMax",
		extensions: [".bmx"]
	},
	BLUESPEC: {
		color: "#12223c",
		name: "Bluespec",
		extensions: [".bsv"]
	},
	"BLUESPEC BH": {
		color: "#12223c",
		name: "Bluespec BH",
		extensions: [".bs"]
	},
	BOO: {
		color: "#d4bec1",
		name: "Boo",
		extensions: [".boo"]
	},
	BOOGIE: {
		color: "#c80fa0",
		name: "Boogie",
		extensions: [".bpl"]
	},
	BRAINFUCK: {
		color: "#2F2530",
		name: "Brainfuck",
		extensions: [".b", ".bf"]
	},
	BRIGHTERSCRIPT: {
		color: "#66AABB",
		name: "BrighterScript",
		extensions: [".bs"]
	},
	BRIGHTSCRIPT: {
		color: "#662D91",
		name: "Brightscript",
		extensions: [".brs"]
	},
	BROWSERSLIST: {
		color: "#ffd539",
		name: "Browserslist"
	},
	BUILDSTREAM: {
		color: "#006bff",
		name: "BuildStream",
		extensions: [".bst"]
	},
	C: {
		color: "#555555",
		name: "C",
		extensions: [
			".c",
			".cats",
			".h",
			".h.in",
			".idc"
		]
	},
	"C#": {
		color: "#178600",
		name: "C#",
		extensions: [
			".cs",
			".cake",
			".cs.pp",
			".csx",
			".linq"
		]
	},
	"C++": {
		color: "#f34b7d",
		name: "C++",
		extensions: [
			".cpp",
			".c++",
			".cc",
			".cp",
			".cppm",
			".cxx",
			".h",
			".h++",
			".hh",
			".hpp",
			".hxx",
			".inc",
			".inl",
			".ino",
			".ipp",
			".ixx",
			".re",
			".tcc",
			".tpp",
			".txx"
		]
	},
	"C-OBJDUMP": {
		name: "C-ObjDump",
		extensions: [".c-objdump"]
	},
	"C2HS HASKELL": {
		name: "C2hs Haskell",
		extensions: [".chs"]
	},
	"CAP CDS": {
		color: "#0092d1",
		name: "CAP CDS",
		extensions: [".cds"]
	},
	CIL: {
		name: "CIL",
		extensions: [".cil"]
	},
	CLIPS: {
		color: "#00A300",
		name: "CLIPS",
		extensions: [".clp"]
	},
	CMAKE: {
		color: "#DA3434",
		name: "CMake",
		extensions: [".cmake", ".cmake.in"]
	},
	COBOL: {
		name: "COBOL",
		extensions: [
			".cob",
			".cbl",
			".ccp",
			".cobol",
			".cpy"
		]
	},
	CODEOWNERS: { name: "CODEOWNERS" },
	COLLADA: {
		color: "#F1A42B",
		name: "COLLADA",
		extensions: [".dae"]
	},
	CSON: {
		color: "#244776",
		name: "CSON",
		extensions: [".cson"]
	},
	CSS: {
		color: "#663399",
		name: "CSS",
		extensions: [".css"]
	},
	CSV: {
		color: "#237346",
		name: "CSV",
		extensions: [".csv"]
	},
	CUE: {
		color: "#5886E1",
		name: "CUE",
		extensions: [".cue"]
	},
	CWEB: {
		color: "#00007a",
		name: "CWeb",
		extensions: [".w"]
	},
	"CABAL CONFIG": {
		color: "#483465",
		name: "Cabal Config",
		extensions: [".cabal"]
	},
	CADDYFILE: {
		color: "#22b638",
		name: "Caddyfile",
		extensions: [".caddyfile"]
	},
	CADENCE: {
		color: "#00ef8b",
		name: "Cadence",
		extensions: [".cdc"]
	},
	CAIRO: {
		color: "#ff4a48",
		name: "Cairo",
		extensions: [".cairo"]
	},
	"CAIRO ZERO": {
		color: "#ff4a48",
		name: "Cairo Zero",
		extensions: [".cairo"]
	},
	CAMELIGO: {
		color: "#3be133",
		name: "CameLIGO",
		extensions: [".mligo"]
	},
	"CAP'N PROTO": {
		color: "#c42727",
		name: "Cap'n Proto",
		extensions: [".capnp"]
	},
	CARBON: {
		color: "#222222",
		name: "Carbon",
		extensions: [".carbon"]
	},
	CARTOCSS: {
		name: "CartoCSS",
		extensions: [".mss"]
	},
	CEYLON: {
		color: "#dfa535",
		name: "Ceylon",
		extensions: [".ceylon"]
	},
	CHAPEL: {
		color: "#8dc63f",
		name: "Chapel",
		extensions: [".chpl"]
	},
	CHARITY: {
		name: "Charity",
		extensions: [".ch"]
	},
	CHECKSUMS: {
		name: "Checksums",
		extensions: [
			".crc32",
			".md2",
			".md4",
			".md5",
			".sha1",
			".sha2",
			".sha224",
			".sha256",
			".sha256sum",
			".sha3",
			".sha384",
			".sha512"
		]
	},
	CHUCK: {
		color: "#3f8000",
		name: "ChucK",
		extensions: [".ck"]
	},
	CIRCOM: {
		color: "#707575",
		name: "Circom",
		extensions: [".circom"]
	},
	CIRRU: {
		color: "#ccccff",
		name: "Cirru",
		extensions: [".cirru"]
	},
	CLARION: {
		color: "#db901e",
		name: "Clarion",
		extensions: [".clw"]
	},
	CLARITY: {
		color: "#5546ff",
		name: "Clarity",
		extensions: [".clar"]
	},
	"CLASSIC ASP": {
		color: "#6a40fd",
		name: "Classic ASP",
		extensions: [".asp"]
	},
	CLEAN: {
		color: "#3F85AF",
		name: "Clean",
		extensions: [".icl", ".dcl"]
	},
	CLICK: {
		color: "#E4E6F3",
		name: "Click",
		extensions: [".click"]
	},
	CLOJURE: {
		color: "#db5855",
		name: "Clojure",
		extensions: [
			".clj",
			".bb",
			".boot",
			".cl2",
			".cljc",
			".cljs",
			".cljs.hl",
			".cljscm",
			".cljx",
			".hic"
		]
	},
	"CLOSURE TEMPLATES": {
		color: "#0d948f",
		name: "Closure Templates",
		extensions: [".soy"]
	},
	"CLOUD FIRESTORE SECURITY RULES": {
		color: "#FFA000",
		name: "Cloud Firestore Security Rules"
	},
	CLUE: {
		color: "#0009b5",
		name: "Clue",
		extensions: [".clue"]
	},
	"CONLL-U": {
		name: "CoNLL-U",
		extensions: [".conllu", ".conll"]
	},
	CODEQL: {
		color: "#140f46",
		name: "CodeQL",
		extensions: [".ql", ".qll"]
	},
	COFFEESCRIPT: {
		color: "#244776",
		name: "CoffeeScript",
		extensions: [
			".coffee",
			"._coffee",
			".cake",
			".cjsx",
			".iced"
		]
	},
	COLDFUSION: {
		color: "#ed2cd6",
		name: "ColdFusion",
		extensions: [".cfm", ".cfml"]
	},
	"COLDFUSION CFC": {
		color: "#ed2cd6",
		name: "ColdFusion CFC",
		extensions: [".cfc"]
	},
	"COMMON LISP": {
		color: "#3fb68b",
		name: "Common Lisp",
		extensions: [
			".lisp",
			".asd",
			".cl",
			".l",
			".lsp",
			".ny",
			".podsl",
			".sexp"
		]
	},
	"COMMON WORKFLOW LANGUAGE": {
		color: "#B5314C",
		name: "Common Workflow Language",
		extensions: [".cwl"]
	},
	"COMPONENT PASCAL": {
		color: "#B0CE4E",
		name: "Component Pascal",
		extensions: [".cp", ".cps"]
	},
	COOL: {
		name: "Cool",
		extensions: [".cl"]
	},
	"CPP-OBJDUMP": {
		name: "Cpp-ObjDump",
		extensions: [
			".cppobjdump",
			".c++-objdump",
			".c++objdump",
			".cpp-objdump",
			".cxx-objdump"
		]
	},
	CREOLE: {
		name: "Creole",
		extensions: [".creole"],
		wrap: true
	},
	CRYSTAL: {
		color: "#000100",
		name: "Crystal",
		extensions: [".cr"]
	},
	CSOUND: {
		color: "#1a1a1a",
		name: "Csound",
		extensions: [".orc", ".udo"]
	},
	"CSOUND DOCUMENT": {
		color: "#1a1a1a",
		name: "Csound Document",
		extensions: [".csd"]
	},
	"CSOUND SCORE": {
		color: "#1a1a1a",
		name: "Csound Score",
		extensions: [".sco"]
	},
	CUDA: {
		color: "#3A4E3A",
		name: "Cuda",
		extensions: [".cu", ".cuh"]
	},
	"CUE SHEET": {
		name: "Cue Sheet",
		extensions: [".cue"]
	},
	CURRY: {
		color: "#531242",
		name: "Curry",
		extensions: [".curry"]
	},
	CYCRIPT: {
		name: "Cycript",
		extensions: [".cy"]
	},
	CYLC: {
		color: "#00b3fd",
		name: "Cylc",
		extensions: [".cylc"]
	},
	CYPHER: {
		color: "#34c0eb",
		name: "Cypher",
		extensions: [".cyp", ".cypher"]
	},
	CYTHON: {
		color: "#fedf5b",
		name: "Cython",
		extensions: [
			".pyx",
			".pxd",
			".pxi"
		]
	},
	D: {
		color: "#ba595e",
		name: "D",
		extensions: [".d", ".di"]
	},
	"D-OBJDUMP": {
		name: "D-ObjDump",
		extensions: [".d-objdump"]
	},
	D2: {
		color: "#526ee8",
		name: "D2",
		extensions: [".d2"]
	},
	"DIGITAL COMMAND LANGUAGE": {
		name: "DIGITAL Command Language",
		extensions: [".com"]
	},
	DM: {
		color: "#447265",
		name: "DM",
		extensions: [".dm"]
	},
	"DNS ZONE": {
		name: "DNS Zone",
		extensions: [".zone", ".arpa"]
	},
	DTRACE: {
		name: "DTrace",
		extensions: [".d"]
	},
	DAFNY: {
		color: "#FFEC25",
		name: "Dafny",
		extensions: [".dfy"]
	},
	"DARCS PATCH": {
		color: "#8eff23",
		name: "Darcs Patch",
		extensions: [".darcspatch", ".dpatch"]
	},
	DART: {
		color: "#00B4AB",
		name: "Dart",
		extensions: [".dart"]
	},
	DASLANG: {
		color: "#d3d3d3",
		name: "Daslang",
		extensions: [".das"]
	},
	DATAWEAVE: {
		color: "#003a52",
		name: "DataWeave",
		extensions: [".dwl"]
	},
	"DEBIAN PACKAGE CONTROL FILE": {
		color: "#D70751",
		name: "Debian Package Control File",
		extensions: [".dsc"]
	},
	DENIZENSCRIPT: {
		color: "#FBEE96",
		name: "DenizenScript",
		extensions: [".dsc"]
	},
	DHALL: {
		color: "#dfafff",
		name: "Dhall",
		extensions: [".dhall"]
	},
	DIFF: {
		name: "Diff",
		extensions: [".diff", ".patch"]
	},
	"DIRECTX 3D FILE": {
		color: "#aace60",
		name: "DirectX 3D File",
		extensions: [".x"]
	},
	DOCKERFILE: {
		color: "#384d54",
		name: "Dockerfile",
		extensions: [".dockerfile", ".containerfile"]
	},
	DOGESCRIPT: {
		color: "#cca760",
		name: "Dogescript",
		extensions: [".djs"]
	},
	DOTENV: {
		color: "#e5d559",
		name: "Dotenv",
		extensions: [".env"]
	},
	DUNE: {
		color: "#89421e",
		name: "Dune"
	},
	DYLAN: {
		color: "#6c616e",
		name: "Dylan",
		extensions: [
			".dylan",
			".dyl",
			".intr",
			".lid"
		]
	},
	E: {
		color: "#ccce35",
		name: "E",
		extensions: [".e"]
	},
	"E-MAIL": {
		name: "E-mail",
		extensions: [".eml", ".mbox"]
	},
	EBNF: {
		name: "EBNF",
		extensions: [".ebnf"]
	},
	ECL: {
		color: "#8a1267",
		name: "ECL",
		extensions: [".ecl", ".eclxml"]
	},
	ECLIPSE: {
		color: "#001d9d",
		name: "ECLiPSe",
		extensions: [".ecl"]
	},
	EJS: {
		color: "#a91e50",
		name: "EJS",
		extensions: [
			".ejs",
			".ect",
			".ejs.t",
			".jst"
		]
	},
	EQ: {
		color: "#a78649",
		name: "EQ",
		extensions: [".eq"]
	},
	EAGLE: {
		name: "Eagle",
		extensions: [".sch", ".brd"]
	},
	EARTHLY: {
		color: "#2af0ff",
		name: "Earthly"
	},
	EASYBUILD: {
		color: "#069406",
		name: "Easybuild",
		extensions: [".eb"]
	},
	"ECERE PROJECTS": {
		color: "#913960",
		name: "Ecere Projects",
		extensions: [".epj"]
	},
	ECMARKUP: {
		color: "#eb8131",
		name: "Ecmarkup",
		extensions: [".html"]
	},
	EDGE: {
		color: "#0dffe0",
		name: "Edge",
		extensions: [".edge"]
	},
	EDGEQL: {
		color: "#31A7FF",
		name: "EdgeQL",
		extensions: [".edgeql", ".esdl"]
	},
	EDITORCONFIG: {
		color: "#fff1f2",
		name: "EditorConfig",
		extensions: [".editorconfig"]
	},
	"EDJE DATA COLLECTION": {
		name: "Edje Data Collection",
		extensions: [".edc"]
	},
	EIFFEL: {
		color: "#4d6977",
		name: "Eiffel",
		extensions: [".e"]
	},
	ELIXIR: {
		color: "#6e4a7e",
		name: "Elixir",
		extensions: [".ex", ".exs"]
	},
	ELM: {
		color: "#60B5CC",
		name: "Elm",
		extensions: [".elm"]
	},
	ELVISH: {
		color: "#55BB55",
		name: "Elvish",
		extensions: [".elv"]
	},
	"ELVISH TRANSCRIPT": {
		color: "#55BB55",
		name: "Elvish Transcript"
	},
	"EMACS LISP": {
		color: "#c065db",
		name: "Emacs Lisp",
		extensions: [
			".el",
			".emacs",
			".emacs.desktop"
		]
	},
	EMBERSCRIPT: {
		color: "#FFF4F3",
		name: "EmberScript",
		extensions: [".em", ".emberscript"]
	},
	ERLANG: {
		color: "#B83998",
		name: "Erlang",
		extensions: [
			".erl",
			".app",
			".app.src",
			".es",
			".escript",
			".hrl",
			".xrl",
			".yrl"
		]
	},
	EUPHORIA: {
		color: "#FF790B",
		name: "Euphoria",
		extensions: [".e", ".ex"]
	},
	"F#": {
		color: "#b845fc",
		name: "F#",
		extensions: [
			".fs",
			".fsi",
			".fsx"
		]
	},
	"F*": {
		color: "#572e30",
		name: "F*",
		extensions: [".fst", ".fsti"]
	},
	"FIGLET FONT": {
		color: "#FFDDBB",
		name: "FIGlet Font",
		extensions: [".flf"]
	},
	FIRRTL: {
		color: "#2f632f",
		name: "FIRRTL",
		extensions: [".fir"]
	},
	FLUX: {
		color: "#88ccff",
		name: "FLUX",
		extensions: [".fx", ".flux"]
	},
	FACTOR: {
		color: "#636746",
		name: "Factor",
		extensions: [".factor"]
	},
	FANCY: {
		color: "#7b9db4",
		name: "Fancy",
		extensions: [".fy", ".fancypack"]
	},
	FANTOM: {
		color: "#14253c",
		name: "Fantom",
		extensions: [".fan"]
	},
	FAUST: {
		color: "#c37240",
		name: "Faust",
		extensions: [".dsp"]
	},
	FENNEL: {
		color: "#fff3d7",
		name: "Fennel",
		extensions: [".fnl"]
	},
	"FILEBENCH WML": {
		color: "#F6B900",
		name: "Filebench WML",
		extensions: [".f"]
	},
	FILTERSCRIPT: {
		name: "Filterscript",
		extensions: [".fs"]
	},
	FLUENT: {
		color: "#ffcc33",
		name: "Fluent",
		extensions: [".ftl"]
	},
	FORMATTED: {
		name: "Formatted",
		extensions: [".for", ".eam.fs"]
	},
	FORTH: {
		color: "#341708",
		name: "Forth",
		extensions: [
			".fth",
			".4th",
			".f",
			".for",
			".forth",
			".fr",
			".frt",
			".fs"
		]
	},
	FORTRAN: {
		color: "#4d41b1",
		name: "Fortran",
		extensions: [
			".f",
			".f77",
			".for",
			".fpp"
		]
	},
	"FORTRAN FREE FORM": {
		color: "#4d41b1",
		name: "Fortran Free Form",
		extensions: [
			".f90",
			".f03",
			".f08",
			".f95"
		]
	},
	FREEBASIC: {
		color: "#141AC9",
		name: "FreeBASIC",
		extensions: [".bi", ".bas"]
	},
	FREEMARKER: {
		color: "#0050b2",
		name: "FreeMarker",
		extensions: [".ftl"]
	},
	FREGE: {
		color: "#00cafe",
		name: "Frege",
		extensions: [".fr"]
	},
	FUTHARK: {
		color: "#5f021f",
		name: "Futhark",
		extensions: [".fut"]
	},
	"G-CODE": {
		color: "#D08CF2",
		name: "G-code",
		extensions: [
			".g",
			".cnc",
			".gco",
			".gcode"
		]
	},
	GAML: {
		color: "#FFC766",
		name: "GAML",
		extensions: [".gaml"]
	},
	GAMS: {
		color: "#f49a22",
		name: "GAMS",
		extensions: [".gms"]
	},
	GAP: {
		color: "#0000cc",
		name: "GAP",
		extensions: [
			".g",
			".gap",
			".gd",
			".gi",
			".tst"
		]
	},
	"GCC MACHINE DESCRIPTION": {
		color: "#FFCFAB",
		name: "GCC Machine Description",
		extensions: [".md"]
	},
	GDB: {
		name: "GDB",
		extensions: [".gdb", ".gdbinit"]
	},
	GDSCRIPT: {
		color: "#355570",
		name: "GDScript",
		extensions: [".gd"]
	},
	GDSHADER: {
		color: "#478CBF",
		name: "GDShader",
		extensions: [".gdshader", ".gdshaderinc"]
	},
	GEDCOM: {
		color: "#003058",
		name: "GEDCOM",
		extensions: [".ged"]
	},
	GLSL: {
		color: "#5686a5",
		name: "GLSL",
		extensions: [
			".glsl",
			".fp",
			".frag",
			".frg",
			".fs",
			".fsh",
			".fshader",
			".geo",
			".geom",
			".glslf",
			".glslv",
			".gs",
			".gshader",
			".rchit",
			".rmiss",
			".shader",
			".tesc",
			".tese",
			".vert",
			".vrx",
			".vs",
			".vsh",
			".vshader"
		]
	},
	GN: {
		name: "GN",
		extensions: [".gn", ".gni"]
	},
	GSC: {
		color: "#FF6800",
		name: "GSC",
		extensions: [
			".gsc",
			".csc",
			".gsh"
		]
	},
	"GAME MAKER LANGUAGE": {
		color: "#71b417",
		name: "Game Maker Language",
		extensions: [".gml"]
	},
	"GEMFILE.LOCK": {
		color: "#701516",
		name: "Gemfile.lock"
	},
	GEMINI: {
		color: "#ff6900",
		name: "Gemini",
		extensions: [".gmi"],
		wrap: true
	},
	"GENERO 4GL": {
		color: "#63408e",
		name: "Genero 4gl",
		extensions: [".4gl"]
	},
	"GENERO PER": {
		color: "#d8df39",
		name: "Genero per",
		extensions: [".per"]
	},
	GENIE: {
		color: "#fb855d",
		name: "Genie",
		extensions: [".gs"]
	},
	GENSHI: {
		color: "#951531",
		name: "Genshi",
		extensions: [".kid"]
	},
	"GENTOO EBUILD": {
		color: "#9400ff",
		name: "Gentoo Ebuild",
		extensions: [".ebuild"]
	},
	"GENTOO ECLASS": {
		color: "#9400ff",
		name: "Gentoo Eclass",
		extensions: [".eclass"]
	},
	"GERBER IMAGE": {
		color: "#d20b00",
		name: "Gerber Image",
		extensions: [
			".gbr",
			".cmp",
			".gbl",
			".gbo",
			".gbp",
			".gbs",
			".gko",
			".gml",
			".gpb",
			".gpt",
			".gtl",
			".gto",
			".gtp",
			".gts",
			".ncl",
			".sol"
		]
	},
	"GETTEXT CATALOG": {
		name: "Gettext Catalog",
		extensions: [".po", ".pot"]
	},
	GHERKIN: {
		color: "#5B2063",
		name: "Gherkin",
		extensions: [".feature", ".story"]
	},
	"GIT ATTRIBUTES": {
		color: "#F44D27",
		name: "Git Attributes"
	},
	"GIT CONFIG": {
		color: "#F44D27",
		name: "Git Config",
		extensions: [".gitconfig"]
	},
	"GIT REVISION LIST": {
		color: "#F44D27",
		name: "Git Revision List"
	},
	GLEAM: {
		color: "#ffaff3",
		name: "Gleam",
		extensions: [".gleam"]
	},
	"GLIMMER JS": {
		color: "#F5835F",
		name: "Glimmer JS",
		extensions: [".gjs"]
	},
	"GLIMMER TS": {
		color: "#3178c6",
		name: "Glimmer TS",
		extensions: [".gts"]
	},
	GLYPH: {
		color: "#c1ac7f",
		name: "Glyph",
		extensions: [".glf"]
	},
	"GLYPH BITMAP DISTRIBUTION FORMAT": {
		name: "Glyph Bitmap Distribution Format",
		extensions: [".bdf"]
	},
	GNUPLOT: {
		color: "#f0a9f0",
		name: "Gnuplot",
		extensions: [
			".gp",
			".gnu",
			".gnuplot",
			".p",
			".plot",
			".plt"
		]
	},
	GO: {
		color: "#00ADD8",
		name: "Go",
		extensions: [".go"]
	},
	"GO CHECKSUMS": {
		color: "#00ADD8",
		name: "Go Checksums"
	},
	"GO MODULE": {
		color: "#00ADD8",
		name: "Go Module"
	},
	"GO WORKSPACE": {
		color: "#00ADD8",
		name: "Go Workspace"
	},
	"GODOT RESOURCE": {
		color: "#355570",
		name: "Godot Resource",
		extensions: [
			".gdnlib",
			".gdns",
			".tres",
			".tscn"
		]
	},
	GOLO: {
		color: "#88562A",
		name: "Golo",
		extensions: [".golo"]
	},
	GOSU: {
		color: "#82937f",
		name: "Gosu",
		extensions: [
			".gs",
			".gst",
			".gsx",
			".vark"
		]
	},
	GRACE: {
		color: "#615f8b",
		name: "Grace",
		extensions: [".grace"]
	},
	GRADLE: {
		color: "#02303a",
		name: "Gradle",
		extensions: [".gradle"]
	},
	"GRADLE KOTLIN DSL": {
		color: "#02303a",
		name: "Gradle Kotlin DSL",
		extensions: [".gradle.kts"]
	},
	"GRAMMATICAL FRAMEWORK": {
		color: "#ff0000",
		name: "Grammatical Framework",
		extensions: [".gf"]
	},
	"GRAPH MODELING LANGUAGE": {
		name: "Graph Modeling Language",
		extensions: [".gml"]
	},
	GRAPHQL: {
		color: "#e10098",
		name: "GraphQL",
		extensions: [
			".graphql",
			".gql",
			".graphqls"
		]
	},
	"GRAPHVIZ (DOT)": {
		color: "#2596be",
		name: "Graphviz (DOT)",
		extensions: [".dot", ".gv"]
	},
	GROOVY: {
		color: "#4298b8",
		name: "Groovy",
		extensions: [
			".groovy",
			".grt",
			".gtpl",
			".gvy"
		]
	},
	"GROOVY SERVER PAGES": {
		color: "#4298b8",
		name: "Groovy Server Pages",
		extensions: [".gsp"]
	},
	HAPROXY: {
		color: "#106da9",
		name: "HAProxy",
		extensions: [".cfg"]
	},
	HCL: {
		color: "#844FBA",
		name: "HCL",
		extensions: [
			".hcl",
			".nomad",
			".tf",
			".tfvars",
			".workflow"
		]
	},
	HIP: {
		color: "#4F3A4F",
		name: "HIP",
		extensions: [".hip"]
	},
	HLSL: {
		color: "#aace60",
		name: "HLSL",
		extensions: [
			".hlsl",
			".cginc",
			".fx",
			".fxh",
			".hlsli"
		]
	},
	HOCON: {
		color: "#9ff8ee",
		name: "HOCON",
		extensions: [".hocon"]
	},
	HTML: {
		color: "#e34c26",
		name: "HTML",
		extensions: [
			".html",
			".hta",
			".htm",
			".html.hl",
			".inc",
			".xht",
			".xhtml"
		]
	},
	"HTML+ECR": {
		color: "#2e1052",
		name: "HTML+ECR",
		extensions: [".ecr"]
	},
	"HTML+EEX": {
		color: "#6e4a7e",
		name: "HTML+EEX",
		extensions: [
			".html.eex",
			".heex",
			".leex"
		]
	},
	"HTML+ERB": {
		color: "#701516",
		name: "HTML+ERB",
		extensions: [
			".erb",
			".erb.deface",
			".rhtml"
		]
	},
	"HTML+PHP": {
		color: "#4f5d95",
		name: "HTML+PHP",
		extensions: [".phtml"]
	},
	"HTML+RAZOR": {
		color: "#512be4",
		name: "HTML+Razor",
		extensions: [".cshtml", ".razor"]
	},
	HTTP: {
		color: "#005C9C",
		name: "HTTP",
		extensions: [".http"]
	},
	HXML: {
		color: "#f68712",
		name: "HXML",
		extensions: [".hxml"]
	},
	HACK: {
		color: "#878787",
		name: "Hack",
		extensions: [
			".hack",
			".hh",
			".hhi",
			".php"
		]
	},
	HAML: {
		color: "#ece2a9",
		name: "Haml",
		extensions: [".haml", ".haml.deface"]
	},
	HANDLEBARS: {
		color: "#f7931e",
		name: "Handlebars",
		extensions: [".handlebars", ".hbs"]
	},
	HARBOUR: {
		color: "#0e60e3",
		name: "Harbour",
		extensions: [".hb"]
	},
	HARE: {
		color: "#9d7424",
		name: "Hare",
		extensions: [".ha"]
	},
	HASKELL: {
		color: "#5e5086",
		name: "Haskell",
		extensions: [
			".hs",
			".hs-boot",
			".hsc"
		]
	},
	HAXE: {
		color: "#df7900",
		name: "Haxe",
		extensions: [".hx", ".hxsl"]
	},
	HIVEQL: {
		color: "#dce200",
		name: "HiveQL",
		extensions: [".q", ".hql"]
	},
	HOLYC: {
		color: "#ffefaf",
		name: "HolyC",
		extensions: [".hc"]
	},
	"HOSTS FILE": {
		color: "#308888",
		name: "Hosts File"
	},
	HY: {
		color: "#7790B2",
		name: "Hy",
		extensions: [".hy"]
	},
	HYPHY: {
		name: "HyPhy",
		extensions: [".bf"]
	},
	IDL: {
		color: "#a3522f",
		name: "IDL",
		extensions: [".pro", ".dlm"]
	},
	"IGOR PRO": {
		color: "#0000cc",
		name: "IGOR Pro",
		extensions: [".ipf"]
	},
	INI: {
		color: "#d1dbe0",
		name: "INI",
		extensions: [
			".ini",
			".cfg",
			".cnf",
			".dof",
			".frm",
			".lektorproject",
			".prefs",
			".pro",
			".properties",
			".url"
		]
	},
	"IRC LOG": {
		name: "IRC log",
		extensions: [".irclog", ".weechatlog"]
	},
	ISPC: {
		color: "#2D68B1",
		name: "ISPC",
		extensions: [".ispc"]
	},
	IDRIS: {
		color: "#b30000",
		name: "Idris",
		extensions: [".idr", ".lidr"]
	},
	"IGNORE LIST": {
		color: "#000000",
		name: "Ignore List",
		extensions: [".gitignore"]
	},
	"IMAGEJ MACRO": {
		color: "#99AAFF",
		name: "ImageJ Macro",
		extensions: [".ijm"]
	},
	IMBA: {
		color: "#16cec6",
		name: "Imba",
		extensions: [".imba"]
	},
	"INFORM 7": {
		name: "Inform 7",
		extensions: [".ni", ".i7x"],
		wrap: true
	},
	INK: {
		name: "Ink",
		extensions: [".ink"],
		wrap: true
	},
	"INNO SETUP": {
		color: "#264b99",
		name: "Inno Setup",
		extensions: [".iss", ".isl"]
	},
	IO: {
		color: "#a9188d",
		name: "Io",
		extensions: [".io"]
	},
	IOKE: {
		color: "#078193",
		name: "Ioke",
		extensions: [".ik"]
	},
	ISABELLE: {
		color: "#FEFE00",
		name: "Isabelle",
		extensions: [".thy"]
	},
	"ISABELLE ROOT": {
		color: "#FEFE00",
		name: "Isabelle ROOT"
	},
	J: {
		color: "#9EEDFF",
		name: "J",
		extensions: [".ijs"]
	},
	"JAR MANIFEST": {
		color: "#b07219",
		name: "JAR Manifest"
	},
	JCL: {
		color: "#d90e09",
		name: "JCL",
		extensions: [".jcl"]
	},
	JFLEX: {
		color: "#DBCA00",
		name: "JFlex",
		extensions: [".flex", ".jflex"]
	},
	JSON: {
		color: "#292929",
		name: "JSON",
		extensions: [
			".json",
			".4DForm",
			".4DProject",
			".avsc",
			".geojson",
			".gltf",
			".har",
			".ice",
			".JSON-tmLanguage",
			".json.example",
			".jsonl",
			".mcmeta",
			".sarif",
			".tact",
			".tfstate",
			".tfstate.backup",
			".topojson",
			".webapp",
			".webmanifest",
			".yy",
			".yyp"
		]
	},
	"JSON WITH COMMENTS": {
		color: "#292929",
		name: "JSON with Comments",
		extensions: [
			".jsonc",
			".code-snippets",
			".code-workspace",
			".sublime-build",
			".sublime-color-scheme",
			".sublime-commands",
			".sublime-completions",
			".sublime-keymap",
			".sublime-macro",
			".sublime-menu",
			".sublime-mousemap",
			".sublime-project",
			".sublime-settings",
			".sublime-theme",
			".sublime-workspace",
			".sublime_metrics",
			".sublime_session"
		]
	},
	JSON5: {
		color: "#267CB9",
		name: "JSON5",
		extensions: [".json5"]
	},
	JSONLD: {
		color: "#0c479c",
		name: "JSONLD",
		extensions: [".jsonld"]
	},
	JSONIQ: {
		color: "#40d47e",
		name: "JSONiq",
		extensions: [".jq"]
	},
	JAI: {
		color: "#ab8b4b",
		name: "Jai",
		extensions: [".jai"]
	},
	JANET: {
		color: "#0886a5",
		name: "Janet",
		extensions: [".janet"]
	},
	JASMIN: {
		color: "#d03600",
		name: "Jasmin",
		extensions: [".j"]
	},
	JAVA: {
		color: "#b07219",
		name: "Java",
		extensions: [
			".java",
			".jav",
			".jsh"
		]
	},
	"JAVA PROPERTIES": {
		color: "#2A6277",
		name: "Java Properties",
		extensions: [".properties"]
	},
	"JAVA SERVER PAGES": {
		color: "#2A6277",
		name: "Java Server Pages",
		extensions: [".jsp", ".tag"]
	},
	"JAVA TEMPLATE ENGINE": {
		color: "#2A6277",
		name: "Java Template Engine",
		extensions: [".jte"]
	},
	JAVASCRIPT: {
		color: "#f1e05a",
		name: "JavaScript",
		extensions: [
			".js",
			"._js",
			".bones",
			".cjs",
			".es",
			".es6",
			".frag",
			".gs",
			".jake",
			".javascript",
			".jsb",
			".jscad",
			".jsfl",
			".jslib",
			".jsm",
			".jspre",
			".jss",
			".jsx",
			".mjs",
			".njs",
			".pac",
			".sjs",
			".ssjs",
			".xsjs",
			".xsjslib"
		]
	},
	"JAVASCRIPT+ERB": {
		color: "#f1e05a",
		name: "JavaScript+ERB",
		extensions: [".js.erb"]
	},
	"JEST SNAPSHOT": {
		color: "#15c213",
		name: "Jest Snapshot",
		extensions: [".snap"]
	},
	"JETBRAINS MPS": {
		color: "#21D789",
		name: "JetBrains MPS",
		extensions: [
			".mps",
			".mpl",
			".msd"
		]
	},
	JINJA: {
		color: "#a52a22",
		name: "Jinja",
		extensions: [
			".jinja",
			".j2",
			".jinja2"
		]
	},
	JISON: {
		color: "#56b3cb",
		name: "Jison",
		extensions: [".jison"]
	},
	"JISON LEX": {
		color: "#56b3cb",
		name: "Jison Lex",
		extensions: [".jisonlex"]
	},
	JOLIE: {
		color: "#843179",
		name: "Jolie",
		extensions: [".ol", ".iol"]
	},
	JSONNET: {
		color: "#0064bd",
		name: "Jsonnet",
		extensions: [".jsonnet", ".libsonnet"]
	},
	JULIA: {
		color: "#a270ba",
		name: "Julia",
		extensions: [".jl"]
	},
	"JULIA REPL": {
		color: "#a270ba",
		name: "Julia REPL"
	},
	"JUPYTER NOTEBOOK": {
		color: "#DA5B0B",
		name: "Jupyter Notebook",
		extensions: [".ipynb"]
	},
	JUST: {
		color: "#384d54",
		name: "Just",
		extensions: [".just"]
	},
	KDL: {
		color: "#ffb3b3",
		name: "KDL",
		extensions: [".kdl"]
	},
	KRL: {
		color: "#28430A",
		name: "KRL",
		extensions: [".krl"]
	},
	"KAITAI STRUCT": {
		color: "#773b37",
		name: "Kaitai Struct",
		extensions: [".ksy"]
	},
	KAKOUNESCRIPT: {
		color: "#6f8042",
		name: "KakouneScript",
		extensions: [".kak"]
	},
	KERBOSCRIPT: {
		color: "#41adf0",
		name: "KerboScript",
		extensions: [".ks"]
	},
	"KICAD LAYOUT": {
		color: "#2f4aab",
		name: "KiCad Layout",
		extensions: [
			".kicad_pcb",
			".kicad_mod",
			".kicad_wks"
		]
	},
	"KICAD LEGACY LAYOUT": {
		color: "#2f4aab",
		name: "KiCad Legacy Layout",
		extensions: [".brd"]
	},
	"KICAD SCHEMATIC": {
		color: "#2f4aab",
		name: "KiCad Schematic",
		extensions: [
			".kicad_sch",
			".kicad_sym",
			".sch"
		]
	},
	KICKSTART: {
		name: "Kickstart",
		extensions: [".ks"]
	},
	KIT: {
		name: "Kit",
		extensions: [".kit"]
	},
	KOKA: {
		color: "#215166",
		name: "Koka",
		extensions: [".kk"]
	},
	KOTLIN: {
		color: "#A97BFF",
		name: "Kotlin",
		extensions: [
			".kt",
			".ktm",
			".kts"
		]
	},
	KUSTO: {
		name: "Kusto",
		extensions: [".csl", ".kql"]
	},
	LFE: {
		color: "#4C3023",
		name: "LFE",
		extensions: [".lfe"]
	},
	LLVM: {
		color: "#185619",
		name: "LLVM",
		extensions: [".ll"]
	},
	LOLCODE: {
		color: "#cc9900",
		name: "LOLCODE",
		extensions: [".lol"]
	},
	LSL: {
		color: "#3d9970",
		name: "LSL",
		extensions: [".lsl", ".lslp"]
	},
	"LTSPICE SYMBOL": {
		name: "LTspice Symbol",
		extensions: [".asy"]
	},
	LABVIEW: {
		color: "#fede06",
		name: "LabVIEW",
		extensions: [
			".lvproj",
			".lvclass",
			".lvlib"
		]
	},
	LARK: {
		color: "#2980B9",
		name: "Lark",
		extensions: [".lark"]
	},
	LASSO: {
		color: "#999999",
		name: "Lasso",
		extensions: [
			".lasso",
			".las",
			".lasso8",
			".lasso9"
		]
	},
	LATTE: {
		color: "#f2a542",
		name: "Latte",
		extensions: [".latte"]
	},
	LEAN: {
		name: "Lean",
		extensions: [".lean", ".hlean"]
	},
	"LEAN 4": {
		name: "Lean 4",
		extensions: [".lean"]
	},
	LEO: {
		color: "#C4FFC2",
		name: "Leo",
		extensions: [".leo"],
		wrap: true
	},
	LESS: {
		color: "#1d365d",
		name: "Less",
		extensions: [".less"]
	},
	LEX: {
		color: "#DBCA00",
		name: "Lex",
		extensions: [".l", ".lex"]
	},
	LIGOLANG: {
		color: "#0e74ff",
		name: "LigoLANG",
		extensions: [".ligo"]
	},
	LILYPOND: {
		color: "#9ccc7c",
		name: "LilyPond",
		extensions: [".ly", ".ily"]
	},
	LIMBO: {
		name: "Limbo",
		extensions: [".b", ".m"]
	},
	"LINEAR PROGRAMMING": {
		name: "Linear Programming",
		extensions: [".lp"]
	},
	"LINKER SCRIPT": {
		name: "Linker Script",
		extensions: [
			".ld",
			".lds",
			".x"
		]
	},
	"LINUX KERNEL MODULE": {
		name: "Linux Kernel Module",
		extensions: [".mod"]
	},
	LIQUID: {
		color: "#67b8de",
		name: "Liquid",
		extensions: [".liquid"]
	},
	"LITERATE AGDA": {
		color: "#315665",
		name: "Literate Agda",
		extensions: [".lagda"]
	},
	"LITERATE COFFEESCRIPT": {
		color: "#244776",
		name: "Literate CoffeeScript",
		extensions: [".litcoffee", ".coffee.md"],
		wrap: true
	},
	"LITERATE HASKELL": {
		color: "#5e5086",
		name: "Literate Haskell",
		extensions: [".lhs"]
	},
	"LIVECODE SCRIPT": {
		color: "#0c5ba5",
		name: "LiveCode Script",
		extensions: [".livecodescript"]
	},
	LIVESCRIPT: {
		color: "#499886",
		name: "LiveScript",
		extensions: [".ls", "._ls"]
	},
	LOGOS: {
		name: "Logos",
		extensions: [
			".xm",
			".x",
			".xi"
		]
	},
	LOGTALK: {
		color: "#295b9a",
		name: "Logtalk",
		extensions: [".lgt", ".logtalk"]
	},
	LOOKML: {
		color: "#652B81",
		name: "LookML",
		extensions: [".lkml", ".lookml"]
	},
	LOOMSCRIPT: {
		name: "LoomScript",
		extensions: [".ls"]
	},
	LUA: {
		color: "#000080",
		name: "Lua",
		extensions: [
			".lua",
			".fcgi",
			".nse",
			".p8",
			".pd_lua",
			".rbxs",
			".rockspec",
			".wlua"
		]
	},
	LUAU: {
		color: "#00A2FF",
		name: "Luau",
		extensions: [".luau"]
	},
	M: {
		name: "M",
		extensions: [".mumps", ".m"]
	},
	M3U: {
		color: "#179C7D",
		name: "M3U",
		extensions: [".m3u", ".m3u8"]
	},
	M4: {
		name: "M4",
		extensions: [".m4", ".mc"]
	},
	M4SUGAR: {
		name: "M4Sugar",
		extensions: [".m4"]
	},
	MATLAB: {
		color: "#e16737",
		name: "MATLAB",
		extensions: [".matlab", ".m"]
	},
	MAXSCRIPT: {
		color: "#00a6a6",
		name: "MAXScript",
		extensions: [".ms", ".mcr"]
	},
	MDX: {
		color: "#fcb32c",
		name: "MDX",
		extensions: [".mdx"],
		wrap: true
	},
	MLIR: {
		color: "#5EC8DB",
		name: "MLIR",
		extensions: [".mlir"]
	},
	MQL4: {
		color: "#62A8D6",
		name: "MQL4",
		extensions: [".mq4", ".mqh"]
	},
	MQL5: {
		color: "#4A76B8",
		name: "MQL5",
		extensions: [".mq5", ".mqh"]
	},
	MTML: {
		color: "#b7e1f4",
		name: "MTML",
		extensions: [".mtml"]
	},
	MUF: {
		name: "MUF",
		extensions: [".muf", ".m"]
	},
	MACAULAY2: {
		color: "#d8ffff",
		name: "Macaulay2",
		extensions: [".m2"]
	},
	MAKEFILE: {
		color: "#427819",
		name: "Makefile",
		extensions: [
			".mak",
			".d",
			".make",
			".makefile",
			".mk",
			".mkfile"
		]
	},
	MAKO: {
		color: "#7e858d",
		name: "Mako",
		extensions: [".mako", ".mao"]
	},
	MARKDOWN: {
		color: "#083fa1",
		name: "Markdown",
		extensions: [
			".md",
			".livemd",
			".markdown",
			".mdown",
			".mdwn",
			".mkd",
			".mkdn",
			".mkdown",
			".ronn",
			".scd",
			".workbook"
		],
		wrap: true
	},
	MARKO: {
		color: "#42bff2",
		name: "Marko",
		extensions: [".marko"]
	},
	MASK: {
		color: "#f97732",
		name: "Mask",
		extensions: [".mask"]
	},
	MATHEMATICA: {
		color: "#dd1100",
		name: "Mathematica",
		extensions: [
			".mathematica",
			".cdf",
			".m",
			".ma",
			".mt",
			".nb",
			".nbp",
			".wl",
			".wlt"
		]
	},
	"MAVEN POM": { name: "Maven POM" },
	MAX: {
		color: "#c4a79c",
		name: "Max",
		extensions: [
			".maxpat",
			".maxhelp",
			".maxproj",
			".mxt",
			".pat"
		]
	},
	MERCURY: {
		color: "#ff2b2b",
		name: "Mercury",
		extensions: [".m", ".moo"]
	},
	MERMAID: {
		color: "#ff3670",
		name: "Mermaid",
		extensions: [".mmd", ".mermaid"]
	},
	MESON: {
		color: "#007800",
		name: "Meson"
	},
	METAL: {
		color: "#8f14e9",
		name: "Metal",
		extensions: [".metal"]
	},
	"MICROSOFT DEVELOPER STUDIO PROJECT": {
		name: "Microsoft Developer Studio Project",
		extensions: [".dsp"]
	},
	"MICROSOFT VISUAL STUDIO SOLUTION": {
		name: "Microsoft Visual Studio Solution",
		extensions: [".sln"]
	},
	MINID: {
		name: "MiniD",
		extensions: [".minid"]
	},
	MINIYAML: {
		color: "#ff1111",
		name: "MiniYAML",
		extensions: [".yaml", ".yml"]
	},
	MINIZINC: {
		color: "#06a9e6",
		name: "MiniZinc",
		extensions: [".mzn"]
	},
	"MINIZINC DATA": {
		name: "MiniZinc Data",
		extensions: [".dzn"]
	},
	MINT: {
		color: "#02b046",
		name: "Mint",
		extensions: [".mint"]
	},
	MIRAH: {
		color: "#c7a938",
		name: "Mirah",
		extensions: [
			".druby",
			".duby",
			".mirah"
		]
	},
	MODELICA: {
		color: "#de1d31",
		name: "Modelica",
		extensions: [".mo"]
	},
	"MODULA-2": {
		color: "#10253f",
		name: "Modula-2",
		extensions: [".mod"]
	},
	"MODULA-3": {
		color: "#223388",
		name: "Modula-3",
		extensions: [
			".i3",
			".ig",
			".m3",
			".mg"
		]
	},
	"MODULE MANAGEMENT SYSTEM": {
		name: "Module Management System",
		extensions: [".mms", ".mmk"]
	},
	MOJO: {
		color: "#ff4c1f",
		name: "Mojo",
		extensions: [".mojo"]
	},
	MONKEY: {
		name: "Monkey",
		extensions: [".monkey", ".monkey2"]
	},
	"MONKEY C": {
		color: "#8D6747",
		name: "Monkey C",
		extensions: [".mc"]
	},
	MOOCODE: {
		name: "Moocode",
		extensions: [".moo"]
	},
	MOONBIT: {
		color: "#b92381",
		name: "MoonBit",
		extensions: [".mbt"]
	},
	MOONSCRIPT: {
		color: "#ff4585",
		name: "MoonScript",
		extensions: [".moon"]
	},
	MOTOKO: {
		color: "#fbb03b",
		name: "Motoko",
		extensions: [".mo"]
	},
	"MOTOROLA 68K ASSEMBLY": {
		color: "#005daa",
		name: "Motorola 68K Assembly",
		extensions: [
			".asm",
			".i",
			".inc",
			".s",
			".x68"
		]
	},
	MOVE: {
		color: "#4a137a",
		name: "Move",
		extensions: [".move"]
	},
	MUSE: {
		name: "Muse",
		extensions: [".muse"],
		wrap: true
	},
	MUSTACHE: {
		color: "#724b3b",
		name: "Mustache",
		extensions: [".mustache"]
	},
	MYGHTY: {
		name: "Myghty",
		extensions: [".myt"]
	},
	NASL: {
		name: "NASL",
		extensions: [".nasl", ".inc"]
	},
	NCL: {
		color: "#28431f",
		name: "NCL",
		extensions: [".ncl"]
	},
	NEON: {
		name: "NEON",
		extensions: [".neon"]
	},
	NL: {
		name: "NL",
		extensions: [".nl"]
	},
	NMODL: {
		color: "#00356B",
		name: "NMODL",
		extensions: [".mod"]
	},
	"NPM CONFIG": {
		color: "#cb3837",
		name: "NPM Config"
	},
	NSIS: {
		name: "NSIS",
		extensions: [".nsi", ".nsh"]
	},
	NWSCRIPT: {
		color: "#111522",
		name: "NWScript",
		extensions: [".nss"]
	},
	NASAL: {
		color: "#1d2c4e",
		name: "Nasal",
		extensions: [".nas"]
	},
	NEARLEY: {
		color: "#990000",
		name: "Nearley",
		extensions: [".ne", ".nearley"]
	},
	NEMERLE: {
		color: "#3d3c6e",
		name: "Nemerle",
		extensions: [".n"]
	},
	NETLINX: {
		color: "#0aa0ff",
		name: "NetLinx",
		extensions: [".axs", ".axi"]
	},
	"NETLINX+ERB": {
		color: "#747faa",
		name: "NetLinx+ERB",
		extensions: [".axs.erb", ".axi.erb"]
	},
	NETLOGO: {
		color: "#ff6375",
		name: "NetLogo",
		extensions: [".nlogo"]
	},
	NEWLISP: {
		color: "#87AED7",
		name: "NewLisp",
		extensions: [
			".nl",
			".lisp",
			".lsp"
		]
	},
	NEXTFLOW: {
		color: "#3ac486",
		name: "Nextflow",
		extensions: [".nf"]
	},
	NGINX: {
		color: "#009639",
		name: "Nginx",
		extensions: [
			".nginx",
			".nginxconf",
			".vhost"
		]
	},
	NICKEL: {
		color: "#E0C3FC",
		name: "Nickel",
		extensions: [".ncl"]
	},
	NIM: {
		color: "#ffc200",
		name: "Nim",
		extensions: [
			".nim",
			".nim.cfg",
			".nimble",
			".nimrod",
			".nims"
		]
	},
	NINJA: {
		name: "Ninja",
		extensions: [".ninja"]
	},
	NIT: {
		color: "#009917",
		name: "Nit",
		extensions: [".nit"]
	},
	NIX: {
		color: "#7e7eff",
		name: "Nix",
		extensions: [".nix"]
	},
	NOIR: {
		color: "#2f1f49",
		name: "Noir",
		extensions: [".nr"]
	},
	NU: {
		color: "#c9df40",
		name: "Nu",
		extensions: [".nu"]
	},
	NUMPY: {
		color: "#9C8AF9",
		name: "NumPy",
		extensions: [
			".numpy",
			".numpyw",
			".numsc"
		]
	},
	NUNJUCKS: {
		color: "#3d8137",
		name: "Nunjucks",
		extensions: [".njk"]
	},
	NUSHELL: {
		color: "#4E9906",
		name: "Nushell",
		extensions: [".nu"]
	},
	"OASV2-JSON": {
		color: "#85ea2d",
		name: "OASv2-json",
		extensions: [".json"]
	},
	"OASV2-YAML": {
		color: "#85ea2d",
		name: "OASv2-yaml",
		extensions: [".yaml", ".yml"]
	},
	"OASV3-JSON": {
		color: "#85ea2d",
		name: "OASv3-json",
		extensions: [".json"]
	},
	"OASV3-YAML": {
		color: "#85ea2d",
		name: "OASv3-yaml",
		extensions: [".yaml", ".yml"]
	},
	OCAML: {
		color: "#ef7a08",
		name: "OCaml",
		extensions: [
			".ml",
			".eliom",
			".eliomi",
			".ml4",
			".mli",
			".mll",
			".mly"
		]
	},
	"OMNET++ MSG": {
		color: "#a0e0a0",
		name: "OMNeT++ MSG",
		extensions: [".msg"]
	},
	"OMNET++ NED": {
		color: "#08607c",
		name: "OMNeT++ NED",
		extensions: [".ned"]
	},
	OBERON: {
		name: "Oberon",
		extensions: [".ob2"]
	},
	OBJDUMP: {
		name: "ObjDump",
		extensions: [".objdump"]
	},
	"OBJECT DATA INSTANCE NOTATION": {
		name: "Object Data Instance Notation",
		extensions: [".odin"]
	},
	OBJECTSCRIPT: {
		color: "#424893",
		name: "ObjectScript",
		extensions: [".cls"]
	},
	"OBJECTIVE-C": {
		color: "#438eff",
		name: "Objective-C",
		extensions: [".m", ".h"]
	},
	"OBJECTIVE-C++": {
		color: "#6866fb",
		name: "Objective-C++",
		extensions: [".mm"]
	},
	"OBJECTIVE-J": {
		color: "#ff0c5a",
		name: "Objective-J",
		extensions: [".j", ".sj"]
	},
	ODIN: {
		color: "#60AFFE",
		name: "Odin",
		extensions: [".odin"]
	},
	OMGROFL: {
		color: "#cabbff",
		name: "Omgrofl",
		extensions: [".omgrofl"]
	},
	OPA: {
		name: "Opa",
		extensions: [".opa"]
	},
	OPAL: {
		color: "#f7ede0",
		name: "Opal",
		extensions: [".opal"]
	},
	"OPEN POLICY AGENT": {
		color: "#7d9199",
		name: "Open Policy Agent",
		extensions: [".rego"]
	},
	"OPENAPI SPECIFICATION V2": {
		color: "#85ea2d",
		name: "OpenAPI Specification v2"
	},
	"OPENAPI SPECIFICATION V3": {
		color: "#85ea2d",
		name: "OpenAPI Specification v3"
	},
	OPENCL: {
		color: "#ed2e2d",
		name: "OpenCL",
		extensions: [".cl", ".opencl"]
	},
	"OPENEDGE ABL": {
		color: "#5ce600",
		name: "OpenEdge ABL",
		extensions: [
			".p",
			".cls",
			".w"
		]
	},
	OPENQASM: {
		color: "#AA70FF",
		name: "OpenQASM",
		extensions: [".qasm"]
	},
	"OPENRC RUNSCRIPT": { name: "OpenRC runscript" },
	OPENSCAD: {
		color: "#e5cd45",
		name: "OpenSCAD",
		extensions: [".scad"]
	},
	"OPENSTEP PROPERTY LIST": {
		name: "OpenStep Property List",
		extensions: [".plist", ".glyphs"]
	},
	"OPENTYPE FEATURE FILE": {
		name: "OpenType Feature File",
		extensions: [".fea"]
	},
	"OPTION LIST": {
		color: "#476732",
		name: "Option List"
	},
	ORG: {
		color: "#77aa99",
		name: "Org",
		extensions: [".org"],
		wrap: true
	},
	OVERPASSQL: {
		color: "#cce2aa",
		name: "OverpassQL",
		extensions: [".overpassql"],
		wrap: true
	},
	OX: {
		name: "Ox",
		extensions: [
			".ox",
			".oxh",
			".oxo"
		]
	},
	OXYGENE: {
		color: "#cdd0e3",
		name: "Oxygene",
		extensions: [".oxygene"]
	},
	OZ: {
		color: "#fab738",
		name: "Oz",
		extensions: [".oz"]
	},
	P4: {
		color: "#7055b5",
		name: "P4",
		extensions: [".p4"]
	},
	PDDL: {
		color: "#0d00ff",
		name: "PDDL",
		extensions: [".pddl"]
	},
	"PEG.JS": {
		color: "#234d6b",
		name: "PEG.js",
		extensions: [".pegjs", ".peggy"]
	},
	PHP: {
		color: "#4F5D95",
		name: "PHP",
		extensions: [
			".php",
			".aw",
			".ctp",
			".fcgi",
			".inc",
			".php3",
			".php4",
			".php5",
			".phps",
			".phpt"
		]
	},
	PLSQL: {
		color: "#dad8d8",
		name: "PLSQL",
		extensions: [
			".pls",
			".bdy",
			".ddl",
			".fnc",
			".pck",
			".pkb",
			".pks",
			".plb",
			".plsql",
			".prc",
			".spc",
			".sql",
			".tpb",
			".tps",
			".trg",
			".vw"
		]
	},
	PLPGSQL: {
		color: "#336790",
		name: "PLpgSQL",
		extensions: [".pgsql", ".sql"]
	},
	"POV-RAY SDL": {
		color: "#6bac65",
		name: "POV-Ray SDL",
		extensions: [".pov", ".inc"]
	},
	PACT: {
		color: "#F7A8B8",
		name: "Pact",
		extensions: [".pact"]
	},
	PAN: {
		color: "#cc0000",
		name: "Pan",
		extensions: [".pan"]
	},
	PAPYRUS: {
		color: "#6600cc",
		name: "Papyrus",
		extensions: [".psc"]
	},
	PARROT: {
		color: "#f3ca0a",
		name: "Parrot",
		extensions: [".parrot"]
	},
	"PARROT ASSEMBLY": {
		name: "Parrot Assembly",
		extensions: [".pasm"]
	},
	"PARROT INTERNAL REPRESENTATION": {
		name: "Parrot Internal Representation",
		extensions: [".pir"]
	},
	PASCAL: {
		color: "#E3F171",
		name: "Pascal",
		extensions: [
			".pas",
			".dfm",
			".dpr",
			".inc",
			".lpr",
			".pascal",
			".pp"
		]
	},
	PAWN: {
		color: "#dbb284",
		name: "Pawn",
		extensions: [
			".pwn",
			".inc",
			".sma"
		]
	},
	PEP8: {
		color: "#C76F5B",
		name: "Pep8",
		extensions: [".pep"]
	},
	PERL: {
		color: "#0298c3",
		name: "Perl",
		extensions: [
			".pl",
			".al",
			".cgi",
			".fcgi",
			".perl",
			".ph",
			".plx",
			".pm",
			".psgi",
			".t"
		]
	},
	PIC: {
		name: "Pic",
		extensions: [".pic", ".chem"]
	},
	PICKLE: {
		name: "Pickle",
		extensions: [".pkl"]
	},
	PICOLISP: {
		color: "#6067af",
		name: "PicoLisp",
		extensions: [".l"]
	},
	PIGLATIN: {
		color: "#fcd7de",
		name: "PigLatin",
		extensions: [".pig"]
	},
	PIKE: {
		color: "#005390",
		name: "Pike",
		extensions: [".pike", ".pmod"]
	},
	"PIP REQUIREMENTS": {
		color: "#FFD343",
		name: "Pip Requirements"
	},
	PKL: {
		color: "#6b9543",
		name: "Pkl",
		extensions: [".pkl"]
	},
	PLANTUML: {
		color: "#fbbd16",
		name: "PlantUML",
		extensions: [
			".puml",
			".iuml",
			".plantuml"
		]
	},
	POD: {
		name: "Pod",
		extensions: [".pod"],
		wrap: true
	},
	"POD 6": {
		name: "Pod 6",
		extensions: [".pod", ".pod6"],
		wrap: true
	},
	POGOSCRIPT: {
		color: "#d80074",
		name: "PogoScript",
		extensions: [".pogo"]
	},
	POLAR: {
		color: "#ae81ff",
		name: "Polar",
		extensions: [".polar"]
	},
	PONY: {
		name: "Pony",
		extensions: [".pony"]
	},
	PORTUGOL: {
		color: "#f8bd00",
		name: "Portugol",
		extensions: [".por"]
	},
	POSTCSS: {
		color: "#dc3a0c",
		name: "PostCSS",
		extensions: [".pcss", ".postcss"]
	},
	POSTSCRIPT: {
		color: "#da291c",
		name: "PostScript",
		extensions: [
			".ps",
			".eps",
			".epsi",
			".pfa"
		]
	},
	POWERBUILDER: {
		color: "#8f0f8d",
		name: "PowerBuilder",
		extensions: [
			".pbt",
			".sra",
			".sru",
			".srw"
		]
	},
	POWERSHELL: {
		color: "#012456",
		name: "PowerShell",
		extensions: [
			".ps1",
			".psd1",
			".psm1"
		]
	},
	PRAAT: {
		color: "#c8506d",
		name: "Praat",
		extensions: [".praat"]
	},
	PRISMA: {
		color: "#0c344b",
		name: "Prisma",
		extensions: [".prisma"]
	},
	PROCESSING: {
		color: "#0096D8",
		name: "Processing",
		extensions: [".pde"]
	},
	PROCFILE: {
		color: "#3B2F63",
		name: "Procfile"
	},
	PROGUARD: {
		name: "Proguard",
		extensions: [".pro"]
	},
	PROLOG: {
		color: "#74283c",
		name: "Prolog",
		extensions: [
			".pl",
			".plt",
			".pro",
			".prolog",
			".yap"
		]
	},
	PROMELA: {
		color: "#de0000",
		name: "Promela",
		extensions: [".pml"]
	},
	"PROPELLER SPIN": {
		color: "#7fa2a7",
		name: "Propeller Spin",
		extensions: [".spin"]
	},
	"PROTOCOL BUFFER": {
		name: "Protocol Buffer",
		extensions: [".proto"]
	},
	"PROTOCOL BUFFER TEXT FORMAT": {
		name: "Protocol Buffer Text Format",
		extensions: [
			".textproto",
			".pbt",
			".pbtxt"
		]
	},
	"PUBLIC KEY": {
		name: "Public Key",
		extensions: [".asc", ".pub"]
	},
	PUG: {
		color: "#a86454",
		name: "Pug",
		extensions: [".jade", ".pug"]
	},
	PUPPET: {
		color: "#302B6D",
		name: "Puppet",
		extensions: [".pp"]
	},
	"PURE DATA": {
		name: "Pure Data",
		extensions: [".pd"]
	},
	PUREBASIC: {
		color: "#5a6986",
		name: "PureBasic",
		extensions: [".pb", ".pbi"]
	},
	PURESCRIPT: {
		color: "#1D222D",
		name: "PureScript",
		extensions: [".purs"]
	},
	PYRET: {
		color: "#ee1e10",
		name: "Pyret",
		extensions: [".arr"]
	},
	PYTHON: {
		color: "#3572A5",
		name: "Python",
		extensions: [
			".py",
			".cgi",
			".fcgi",
			".gyp",
			".gypi",
			".lmi",
			".py3",
			".pyde",
			".pyi",
			".pyp",
			".pyt",
			".pyw",
			".rpy",
			".spec",
			".tac",
			".wsgi",
			".xpy"
		]
	},
	"PYTHON CONSOLE": {
		color: "#3572A5",
		name: "Python console"
	},
	"PYTHON TRACEBACK": {
		color: "#3572A5",
		name: "Python traceback",
		extensions: [".pytb"]
	},
	"Q#": {
		color: "#fed659",
		name: "Q#",
		extensions: [".qs"]
	},
	QML: {
		color: "#44a51c",
		name: "QML",
		extensions: [".qml", ".qbs"]
	},
	QMAKE: {
		name: "QMake",
		extensions: [".pro", ".pri"]
	},
	"QT SCRIPT": {
		color: "#00b841",
		name: "Qt Script",
		extensions: [".qs"]
	},
	QUAKE: {
		color: "#882233",
		name: "Quake"
	},
	QUICKBASIC: {
		color: "#008080",
		name: "QuickBASIC",
		extensions: [".bas"]
	},
	R: {
		color: "#198CE7",
		name: "R",
		extensions: [
			".r",
			".rd",
			".rsx"
		]
	},
	RAML: {
		color: "#77d9fb",
		name: "RAML",
		extensions: [".raml"]
	},
	RBS: {
		color: "#701516",
		name: "RBS",
		extensions: [".rbs"]
	},
	RDOC: {
		color: "#701516",
		name: "RDoc",
		extensions: [".rdoc"],
		wrap: true
	},
	REALBASIC: {
		name: "REALbasic",
		extensions: [
			".rbbas",
			".rbfrm",
			".rbmnu",
			".rbres",
			".rbtbar",
			".rbuistate"
		]
	},
	REXX: {
		color: "#d90e09",
		name: "REXX",
		extensions: [
			".rexx",
			".pprx",
			".rex"
		]
	},
	RMARKDOWN: {
		color: "#198ce7",
		name: "RMarkdown",
		extensions: [".qmd", ".rmd"],
		wrap: true
	},
	RON: {
		color: "#a62c00",
		name: "RON",
		extensions: [".ron"]
	},
	RPC: {
		name: "RPC",
		extensions: [".x"]
	},
	RPGLE: {
		color: "#2BDE21",
		name: "RPGLE",
		extensions: [".rpgle", ".sqlrpgle"]
	},
	"RPM SPEC": {
		name: "RPM Spec",
		extensions: [".spec"]
	},
	RUNOFF: {
		color: "#665a4e",
		name: "RUNOFF",
		extensions: [".rnh", ".rno"],
		wrap: true
	},
	RACKET: {
		color: "#3c5caa",
		name: "Racket",
		extensions: [
			".rkt",
			".rktd",
			".rktl",
			".scrbl"
		]
	},
	RAGEL: {
		color: "#9d5200",
		name: "Ragel",
		extensions: [".rl"]
	},
	RAKU: {
		color: "#0000fb",
		name: "Raku",
		extensions: [
			".6pl",
			".6pm",
			".nqp",
			".p6",
			".p6l",
			".p6m",
			".pl",
			".pl6",
			".pm",
			".pm6",
			".raku",
			".rakumod",
			".t"
		]
	},
	RASCAL: {
		color: "#fffaa0",
		name: "Rascal",
		extensions: [".rsc"]
	},
	"RAW TOKEN DATA": {
		name: "Raw token data",
		extensions: [".raw"]
	},
	RESCRIPT: {
		color: "#ed5051",
		name: "ReScript",
		extensions: [".res", ".resi"]
	},
	"READLINE CONFIG": { name: "Readline Config" },
	REASON: {
		color: "#ff5847",
		name: "Reason",
		extensions: [".re", ".rei"]
	},
	REASONLIGO: {
		color: "#ff5847",
		name: "ReasonLIGO",
		extensions: [".religo"]
	},
	REBOL: {
		color: "#358a5b",
		name: "Rebol",
		extensions: [
			".reb",
			".r",
			".r2",
			".r3",
			".rebol"
		]
	},
	"RECORD JAR": {
		color: "#0673ba",
		name: "Record Jar"
	},
	RED: {
		color: "#f50000",
		name: "Red",
		extensions: [".red", ".reds"]
	},
	REDCODE: {
		name: "Redcode",
		extensions: [".cw"]
	},
	"REDIRECT RULES": { name: "Redirect Rules" },
	"REGULAR EXPRESSION": {
		color: "#009a00",
		name: "Regular Expression",
		extensions: [".regexp", ".regex"]
	},
	"REN'PY": {
		color: "#ff7f7f",
		name: "Ren'Py",
		extensions: [".rpy"]
	},
	RENDERSCRIPT: {
		name: "RenderScript",
		extensions: [".rs", ".rsh"]
	},
	REZ: {
		color: "#FFDAB3",
		name: "Rez",
		extensions: [".r"]
	},
	"RICH TEXT FORMAT": {
		name: "Rich Text Format",
		extensions: [".rtf"]
	},
	RING: {
		color: "#2D54CB",
		name: "Ring",
		extensions: [".ring"]
	},
	RIOT: {
		color: "#A71E49",
		name: "Riot",
		extensions: [".riot"]
	},
	ROBOTFRAMEWORK: {
		color: "#00c0b5",
		name: "RobotFramework",
		extensions: [".robot", ".resource"]
	},
	ROC: {
		color: "#7c38f5",
		name: "Roc",
		extensions: [".roc"]
	},
	"ROCQ PROVER": {
		color: "#d0b68c",
		name: "Rocq Prover",
		extensions: [".v", ".coq"]
	},
	ROFF: {
		color: "#ecdebe",
		name: "Roff",
		extensions: [
			".roff",
			".1",
			".1in",
			".1m",
			".1x",
			".2",
			".3",
			".3in",
			".3m",
			".3p",
			".3pm",
			".3qt",
			".3x",
			".4",
			".5",
			".6",
			".7",
			".8",
			".9",
			".l",
			".man",
			".mdoc",
			".me",
			".ms",
			".n",
			".nr",
			".rno",
			".tmac"
		],
		wrap: true
	},
	"ROFF MANPAGE": {
		color: "#ecdebe",
		name: "Roff Manpage",
		extensions: [
			".1",
			".1in",
			".1m",
			".1x",
			".2",
			".3",
			".3in",
			".3m",
			".3p",
			".3pm",
			".3qt",
			".3x",
			".4",
			".5",
			".6",
			".7",
			".8",
			".9",
			".man",
			".mdoc"
		],
		wrap: true
	},
	ROUGE: {
		color: "#cc0088",
		name: "Rouge",
		extensions: [".rg"]
	},
	"ROUTEROS SCRIPT": {
		color: "#DE3941",
		name: "RouterOS Script",
		extensions: [".rsc"]
	},
	RUBY: {
		color: "#701516",
		name: "Ruby",
		extensions: [
			".rb",
			".builder",
			".eye",
			".fcgi",
			".gemspec",
			".god",
			".jbuilder",
			".mspec",
			".pluginspec",
			".podspec",
			".prawn",
			".rabl",
			".rake",
			".rbi",
			".rbuild",
			".rbw",
			".rbx",
			".ru",
			".ruby",
			".spec",
			".thor",
			".watchr"
		]
	},
	RUST: {
		color: "#dea584",
		name: "Rust",
		extensions: [".rs", ".rs.in"]
	},
	SAS: {
		color: "#B34936",
		name: "SAS",
		extensions: [".sas"]
	},
	SCSS: {
		color: "#c6538c",
		name: "SCSS",
		extensions: [".scss"]
	},
	"SELINUX POLICY": {
		name: "SELinux Policy",
		extensions: [".te"]
	},
	SMT: {
		name: "SMT",
		extensions: [
			".smt2",
			".smt",
			".z3"
		]
	},
	SPARQL: {
		color: "#0C4597",
		name: "SPARQL",
		extensions: [".sparql", ".rq"]
	},
	SQF: {
		color: "#3F3F3F",
		name: "SQF",
		extensions: [".sqf", ".hqf"]
	},
	SQL: {
		color: "#e38c00",
		name: "SQL",
		extensions: [
			".sql",
			".cql",
			".ddl",
			".inc",
			".mysql",
			".prc",
			".tab",
			".udf",
			".viw"
		]
	},
	SQLPL: {
		color: "#e38c00",
		name: "SQLPL",
		extensions: [".sql", ".db2"]
	},
	"SRECODE TEMPLATE": {
		color: "#348a34",
		name: "SRecode Template",
		extensions: [".srt"]
	},
	"SSH CONFIG": { name: "SSH Config" },
	STAR: {
		name: "STAR",
		extensions: [".star"]
	},
	STL: {
		color: "#373b5e",
		name: "STL",
		extensions: [".stl"]
	},
	STON: {
		name: "STON",
		extensions: [".ston"]
	},
	SVG: {
		color: "#ff9900",
		name: "SVG",
		extensions: [".svg"]
	},
	SWIG: {
		name: "SWIG",
		extensions: [
			".i",
			".swg",
			".swig"
		]
	},
	SAGE: {
		name: "Sage",
		extensions: [".sage", ".sagews"]
	},
	SAIL: {
		color: "#259dd5",
		name: "Sail",
		extensions: [".sail"]
	},
	SALTSTACK: {
		color: "#646464",
		name: "SaltStack",
		extensions: [".sls"]
	},
	SASS: {
		color: "#a53b70",
		name: "Sass",
		extensions: [".sass"]
	},
	SCALA: {
		color: "#c22d40",
		name: "Scala",
		extensions: [
			".scala",
			".kojo",
			".sbt",
			".sc"
		]
	},
	SCAML: {
		color: "#bd181a",
		name: "Scaml",
		extensions: [".scaml"]
	},
	SCENIC: {
		color: "#fdc700",
		name: "Scenic",
		extensions: [".scenic"]
	},
	SCHEME: {
		color: "#1e4aec",
		name: "Scheme",
		extensions: [
			".scm",
			".sch",
			".sld",
			".sls",
			".sps",
			".ss"
		]
	},
	SCILAB: {
		color: "#ca0f21",
		name: "Scilab",
		extensions: [
			".sci",
			".sce",
			".tst"
		]
	},
	SELF: {
		color: "#0579aa",
		name: "Self",
		extensions: [".self"]
	},
	SHADERLAB: {
		color: "#222c37",
		name: "ShaderLab",
		extensions: [".shader"]
	},
	SHELL: {
		color: "#89e051",
		name: "Shell",
		extensions: [
			".sh",
			".bash",
			".bats",
			".cgi",
			".command",
			".fcgi",
			".ksh",
			".sh.in",
			".tmux",
			".tool",
			".trigger",
			".zsh",
			".zsh-theme"
		]
	},
	"SHELLCHECK CONFIG": {
		color: "#cecfcb",
		name: "ShellCheck Config"
	},
	SHELLSESSION: {
		name: "ShellSession",
		extensions: [".sh-session"]
	},
	SHEN: {
		color: "#120F14",
		name: "Shen",
		extensions: [".shen"]
	},
	SIEVE: {
		name: "Sieve",
		extensions: [".sieve"]
	},
	"SIMPLE FILE VERIFICATION": {
		color: "#C9BFED",
		name: "Simple File Verification",
		extensions: [".sfv"]
	},
	SINGULARITY: {
		color: "#64E6AD",
		name: "Singularity"
	},
	SLANG: {
		color: "#1fbec9",
		name: "Slang",
		extensions: [".slang"]
	},
	SLASH: {
		color: "#007eff",
		name: "Slash",
		extensions: [".sl"]
	},
	SLICE: {
		color: "#003fa2",
		name: "Slice",
		extensions: [".ice"]
	},
	SLIM: {
		color: "#2b2b2b",
		name: "Slim",
		extensions: [".slim"]
	},
	SLINT: {
		color: "#2379F4",
		name: "Slint",
		extensions: [".slint"]
	},
	SMPL: {
		color: "#c94949",
		name: "SmPL",
		extensions: [".cocci"]
	},
	SMALI: {
		name: "Smali",
		extensions: [".smali"]
	},
	SMALLTALK: {
		color: "#596706",
		name: "Smalltalk",
		extensions: [".st", ".cs"]
	},
	SMARTY: {
		color: "#f0c040",
		name: "Smarty",
		extensions: [".tpl"]
	},
	SMITHY: {
		color: "#c44536",
		name: "Smithy",
		extensions: [".smithy"]
	},
	SNAKEMAKE: {
		color: "#419179",
		name: "Snakemake",
		extensions: [".smk", ".snakefile"]
	},
	SOLIDITY: {
		color: "#AA6746",
		name: "Solidity",
		extensions: [".sol"]
	},
	SOONG: { name: "Soong" },
	SOURCEPAWN: {
		color: "#f69e1d",
		name: "SourcePawn",
		extensions: [".sp", ".inc"]
	},
	"SPLINE FONT DATABASE": {
		name: "Spline Font Database",
		extensions: [".sfd"]
	},
	SQUIRREL: {
		color: "#800000",
		name: "Squirrel",
		extensions: [".nut"]
	},
	STAN: {
		color: "#b2011d",
		name: "Stan",
		extensions: [".stan"]
	},
	"STANDARD ML": {
		color: "#dc566d",
		name: "Standard ML",
		extensions: [
			".ml",
			".fun",
			".sig",
			".sml"
		]
	},
	STARLARK: {
		color: "#76d275",
		name: "Starlark",
		extensions: [".bzl", ".star"]
	},
	STATA: {
		color: "#1a5f91",
		name: "Stata",
		extensions: [
			".do",
			".ado",
			".doh",
			".ihlp",
			".mata",
			".matah",
			".sthlp"
		]
	},
	STRINGTEMPLATE: {
		color: "#3fb34f",
		name: "StringTemplate",
		extensions: [".st"]
	},
	STYLUS: {
		color: "#ff6347",
		name: "Stylus",
		extensions: [".styl"]
	},
	"SUBRIP TEXT": {
		color: "#9e0101",
		name: "SubRip Text",
		extensions: [".srt"]
	},
	SUGARSS: {
		color: "#2fcc9f",
		name: "SugarSS",
		extensions: [".sss"]
	},
	SUPERCOLLIDER: {
		color: "#46390b",
		name: "SuperCollider",
		extensions: [".sc", ".scd"]
	},
	"SURVEX DATA": {
		color: "#ffcc99",
		name: "Survex data",
		extensions: [".svx"]
	},
	SVELTE: {
		color: "#ff3e00",
		name: "Svelte",
		extensions: [".svelte"]
	},
	SWAY: {
		color: "#00F58C",
		name: "Sway",
		extensions: [".sw"]
	},
	SWEAVE: {
		color: "#198ce7",
		name: "Sweave",
		extensions: [".rnw"]
	},
	SWIFT: {
		color: "#F05138",
		name: "Swift",
		extensions: [".swift"]
	},
	SYSTEMVERILOG: {
		color: "#DAE1C2",
		name: "SystemVerilog",
		extensions: [
			".sv",
			".svh",
			".vh"
		]
	},
	"TI PROGRAM": {
		color: "#A0AA87",
		name: "TI Program",
		extensions: [".8xp", ".8xp.txt"]
	},
	"TL-VERILOG": {
		color: "#C40023",
		name: "TL-Verilog",
		extensions: [".tlv"]
	},
	TLA: {
		color: "#4b0079",
		name: "TLA",
		extensions: [".tla"]
	},
	TOML: {
		color: "#9c4221",
		name: "TOML",
		extensions: [".toml"]
	},
	"TSPLIB DATA": {
		name: "TSPLIB data",
		extensions: [".tsp"]
	},
	TSQL: {
		color: "#e38c00",
		name: "TSQL",
		extensions: [".sql"]
	},
	TSV: {
		color: "#237346",
		name: "TSV",
		extensions: [".tsv", ".vcf"]
	},
	TSX: {
		color: "#3178c6",
		name: "TSX",
		extensions: [".tsx"]
	},
	TXL: {
		color: "#0178b8",
		name: "TXL",
		extensions: [".txl"]
	},
	TACT: {
		color: "#48b5ff",
		name: "Tact",
		extensions: [".tact"]
	},
	TALON: {
		color: "#333333",
		name: "Talon",
		extensions: [".talon"]
	},
	TCL: {
		color: "#e4cc98",
		name: "Tcl",
		extensions: [
			".tcl",
			".adp",
			".sdc",
			".tcl.in",
			".tm",
			".xdc"
		]
	},
	TCSH: {
		name: "Tcsh",
		extensions: [".tcsh", ".csh"]
	},
	TEX: {
		color: "#3D6117",
		name: "TeX",
		extensions: [
			".tex",
			".aux",
			".bbx",
			".cbx",
			".cls",
			".dtx",
			".ins",
			".lbx",
			".ltx",
			".mkii",
			".mkiv",
			".mkvi",
			".sty",
			".toc"
		],
		wrap: true
	},
	TEA: {
		name: "Tea",
		extensions: [".tea"]
	},
	TERRA: {
		color: "#00004c",
		name: "Terra",
		extensions: [".t"]
	},
	"TERRAFORM TEMPLATE": {
		color: "#7b42bb",
		name: "Terraform Template",
		extensions: [".tftpl"]
	},
	TEXINFO: {
		name: "Texinfo",
		extensions: [
			".texinfo",
			".texi",
			".txi"
		],
		wrap: true
	},
	TEXT: {
		name: "Text",
		extensions: [
			".txt",
			".fr",
			".nb",
			".ncl",
			".no"
		],
		wrap: true
	},
	TEXTGRID: {
		color: "#c8506d",
		name: "TextGrid",
		extensions: [".TextGrid"]
	},
	"TEXTMATE PROPERTIES": {
		color: "#df66e4",
		name: "TextMate Properties"
	},
	TEXTILE: {
		color: "#ffe7ac",
		name: "Textile",
		extensions: [".textile"],
		wrap: true
	},
	THRIFT: {
		color: "#D12127",
		name: "Thrift",
		extensions: [".thrift"]
	},
	TOIT: {
		color: "#c2c9fb",
		name: "Toit",
		extensions: [".toit"]
	},
	"TOR CONFIG": {
		color: "#59316b",
		name: "Tor Config"
	},
	"TREE-SITTER QUERY": {
		color: "#8ea64c",
		name: "Tree-sitter Query",
		extensions: [".scm"]
	},
	TURING: {
		color: "#cf142b",
		name: "Turing",
		extensions: [".t", ".tu"]
	},
	TURTLE: {
		name: "Turtle",
		extensions: [".ttl"]
	},
	TWIG: {
		color: "#c1d026",
		name: "Twig",
		extensions: [".twig"]
	},
	"TYPE LANGUAGE": {
		name: "Type Language",
		extensions: [".tl"]
	},
	TYPESCRIPT: {
		color: "#3178c6",
		name: "TypeScript",
		extensions: [
			".ts",
			".cts",
			".mts"
		]
	},
	TYPESPEC: {
		color: "#4A3665",
		name: "TypeSpec",
		extensions: [".tsp"]
	},
	TYPST: {
		color: "#239dad",
		name: "Typst",
		extensions: [".typ"]
	},
	"UNIFIED PARALLEL C": {
		color: "#4e3617",
		name: "Unified Parallel C",
		extensions: [".upc"]
	},
	"UNITY3D ASSET": {
		color: "#222c37",
		name: "Unity3D Asset",
		extensions: [
			".anim",
			".asset",
			".mask",
			".mat",
			".meta",
			".prefab",
			".unity"
		]
	},
	"UNIX ASSEMBLY": {
		name: "Unix Assembly",
		extensions: [".s", ".ms"]
	},
	UNO: {
		color: "#9933cc",
		name: "Uno",
		extensions: [".uno"]
	},
	UNREALSCRIPT: {
		color: "#a54c4d",
		name: "UnrealScript",
		extensions: [".uc"]
	},
	"UNTYPED PLUTUS CORE": {
		color: "#36adbd",
		name: "Untyped Plutus Core",
		extensions: [".uplc"]
	},
	URWEB: {
		color: "#ccccee",
		name: "UrWeb",
		extensions: [".ur", ".urs"]
	},
	V: {
		color: "#4f87c4",
		name: "V",
		extensions: [".v"]
	},
	VBA: {
		color: "#867db1",
		name: "VBA",
		extensions: [
			".bas",
			".cls",
			".frm",
			".vba"
		]
	},
	VBSCRIPT: {
		color: "#15dcdc",
		name: "VBScript",
		extensions: [".vbs"]
	},
	VCL: {
		color: "#148AA8",
		name: "VCL",
		extensions: [".vcl"]
	},
	VHDL: {
		color: "#adb2cb",
		name: "VHDL",
		extensions: [
			".vhdl",
			".vhd",
			".vhf",
			".vhi",
			".vho",
			".vhs",
			".vht",
			".vhw"
		]
	},
	VALA: {
		color: "#a56de2",
		name: "Vala",
		extensions: [".vala", ".vapi"]
	},
	"VALVE DATA FORMAT": {
		color: "#f26025",
		name: "Valve Data Format",
		extensions: [".vdf"]
	},
	"VELOCITY TEMPLATE LANGUAGE": {
		color: "#507cff",
		name: "Velocity Template Language",
		extensions: [".vtl"]
	},
	VENTO: {
		color: "#ff0080",
		name: "Vento",
		extensions: [".vto"]
	},
	VERILOG: {
		color: "#b2b7f8",
		name: "Verilog",
		extensions: [".v", ".veo"]
	},
	"VIM HELP FILE": {
		color: "#199f4b",
		name: "Vim Help File",
		extensions: [".txt"]
	},
	"VIM SCRIPT": {
		color: "#199f4b",
		name: "Vim Script",
		extensions: [
			".vim",
			".vba",
			".vimrc",
			".vmb"
		]
	},
	"VIM SNIPPET": {
		color: "#199f4b",
		name: "Vim Snippet",
		extensions: [
			".snip",
			".snippet",
			".snippets"
		]
	},
	"VISUAL BASIC .NET": {
		color: "#945db7",
		name: "Visual Basic .NET",
		extensions: [".vb", ".vbhtml"]
	},
	"VISUAL BASIC 6.0": {
		color: "#2c6353",
		name: "Visual Basic 6.0",
		extensions: [
			".bas",
			".cls",
			".ctl",
			".Dsr",
			".frm"
		]
	},
	VOLT: {
		color: "#1F1F1F",
		name: "Volt",
		extensions: [".volt"]
	},
	VUE: {
		color: "#41b883",
		name: "Vue",
		extensions: [".vue"]
	},
	VYPER: {
		color: "#9F4CF2",
		name: "Vyper",
		extensions: [".vy"]
	},
	WDL: {
		color: "#42f1f4",
		name: "WDL",
		extensions: [".wdl"]
	},
	WGSL: {
		color: "#1a5e9a",
		name: "WGSL",
		extensions: [".wgsl"]
	},
	"WAVEFRONT MATERIAL": {
		name: "Wavefront Material",
		extensions: [".mtl"]
	},
	"WAVEFRONT OBJECT": {
		name: "Wavefront Object",
		extensions: [".obj"]
	},
	"WEB ONTOLOGY LANGUAGE": {
		color: "#5b70bd",
		name: "Web Ontology Language",
		extensions: [".owl"]
	},
	WEBASSEMBLY: {
		color: "#04133b",
		name: "WebAssembly",
		extensions: [".wast", ".wat"]
	},
	"WEBASSEMBLY INTERFACE TYPE": {
		color: "#6250e7",
		name: "WebAssembly Interface Type",
		extensions: [".wit"]
	},
	WEBIDL: {
		name: "WebIDL",
		extensions: [".webidl"]
	},
	WEBVTT: {
		name: "WebVTT",
		extensions: [".vtt"],
		wrap: true
	},
	"WGET CONFIG": { name: "Wget Config" },
	WHILEY: {
		color: "#d5c397",
		name: "Whiley",
		extensions: [".whiley"]
	},
	WIKITEXT: {
		color: "#fc5757",
		name: "Wikitext",
		extensions: [
			".mediawiki",
			".wiki",
			".wikitext"
		],
		wrap: true
	},
	"WIN32 MESSAGE FILE": {
		name: "Win32 Message File",
		extensions: [".mc"]
	},
	"WINDOWS REGISTRY ENTRIES": {
		color: "#52d5ff",
		name: "Windows Registry Entries",
		extensions: [".reg"]
	},
	"WITCHER SCRIPT": {
		color: "#ff0000",
		name: "Witcher Script",
		extensions: [".ws"]
	},
	WOLLOK: {
		color: "#a23738",
		name: "Wollok",
		extensions: [".wlk"]
	},
	"WORLD OF WARCRAFT ADDON DATA": {
		color: "#f7e43f",
		name: "World of Warcraft Addon Data",
		extensions: [".toc"]
	},
	WREN: {
		color: "#383838",
		name: "Wren",
		extensions: [".wren"]
	},
	"X BITMAP": {
		name: "X BitMap",
		extensions: [".xbm"]
	},
	"X FONT DIRECTORY INDEX": { name: "X Font Directory Index" },
	"X PIXMAP": {
		name: "X PixMap",
		extensions: [".xpm", ".pm"]
	},
	X10: {
		color: "#4B6BEF",
		name: "X10",
		extensions: [".x10"]
	},
	XC: {
		color: "#99DA07",
		name: "XC",
		extensions: [".xc"]
	},
	XCOMPOSE: { name: "XCompose" },
	XML: {
		color: "#0060ac",
		name: "XML",
		extensions: [
			".xml",
			".adml",
			".admx",
			".ant",
			".axaml",
			".axml",
			".builds",
			".ccproj",
			".ccxml",
			".clixml",
			".cproject",
			".cscfg",
			".csdef",
			".csl",
			".csproj",
			".ct",
			".depproj",
			".dita",
			".ditamap",
			".ditaval",
			".dll.config",
			".dotsettings",
			".filters",
			".fsproj",
			".fxml",
			".glade",
			".gml",
			".gmx",
			".gpx",
			".grxml",
			".gst",
			".hzp",
			".iml",
			".ivy",
			".jelly",
			".jsproj",
			".kml",
			".launch",
			".mdpolicy",
			".mjml",
			".mm",
			".mod",
			".mojo",
			".mxml",
			".natvis",
			".ncl",
			".ndproj",
			".nproj",
			".nuspec",
			".odd",
			".osm",
			".pkgproj",
			".pluginspec",
			".proj",
			".props",
			".ps1xml",
			".psc1",
			".pt",
			".qhelp",
			".rdf",
			".res",
			".resx",
			".rs",
			".rss",
			".sch",
			".scxml",
			".sfproj",
			".shproj",
			".slnx",
			".srdf",
			".storyboard",
			".sublime-snippet",
			".sw",
			".targets",
			".tml",
			".ts",
			".tsx",
			".typ",
			".ui",
			".urdf",
			".ux",
			".vbproj",
			".vcxproj",
			".vsixmanifest",
			".vssettings",
			".vstemplate",
			".vxml",
			".wixproj",
			".workflow",
			".wsdl",
			".wsf",
			".wxi",
			".wxl",
			".wxs",
			".x3d",
			".xacro",
			".xaml",
			".xib",
			".xlf",
			".xliff",
			".xmi",
			".xml.dist",
			".xmp",
			".xproj",
			".xsd",
			".xspec",
			".xul",
			".zcml"
		]
	},
	"XML PROPERTY LIST": {
		color: "#0060ac",
		name: "XML Property List",
		extensions: [
			".plist",
			".stTheme",
			".tmCommand",
			".tmLanguage",
			".tmPreferences",
			".tmSnippet",
			".tmTheme"
		]
	},
	XPAGES: {
		name: "XPages",
		extensions: [".xsp-config", ".xsp.metadata"]
	},
	XPROC: {
		name: "XProc",
		extensions: [".xpl", ".xproc"]
	},
	XQUERY: {
		color: "#5232e7",
		name: "XQuery",
		extensions: [
			".xquery",
			".xq",
			".xql",
			".xqm",
			".xqy"
		]
	},
	XS: {
		name: "XS",
		extensions: [".xs"]
	},
	XSLT: {
		color: "#EB8CEB",
		name: "XSLT",
		extensions: [".xslt", ".xsl"]
	},
	XMAKE: {
		color: "#22a079",
		name: "Xmake"
	},
	XOJO: {
		color: "#81bd41",
		name: "Xojo",
		extensions: [
			".xojo_code",
			".xojo_menu",
			".xojo_report",
			".xojo_script",
			".xojo_toolbar",
			".xojo_window"
		]
	},
	XONSH: {
		color: "#285EEF",
		name: "Xonsh",
		extensions: [".xsh"]
	},
	XTEND: {
		color: "#24255d",
		name: "Xtend",
		extensions: [".xtend"]
	},
	YAML: {
		color: "#cb171e",
		name: "YAML",
		extensions: [
			".yml",
			".mir",
			".reek",
			".rviz",
			".sublime-syntax",
			".syntax",
			".yaml",
			".yaml-tmlanguage",
			".yaml.sed",
			".yml.mysql"
		]
	},
	YANG: {
		name: "YANG",
		extensions: [".yang"]
	},
	YARA: {
		color: "#220000",
		name: "YARA",
		extensions: [".yar", ".yara"]
	},
	YASNIPPET: {
		color: "#32AB90",
		name: "YASnippet",
		extensions: [".yasnippet"]
	},
	YACC: {
		color: "#4B6C4B",
		name: "Yacc",
		extensions: [
			".y",
			".yacc",
			".yy"
		]
	},
	YUL: {
		color: "#794932",
		name: "Yul",
		extensions: [".yul"]
	},
	ZAP: {
		color: "#0d665e",
		name: "ZAP",
		extensions: [".zap", ".xzap"]
	},
	ZIL: {
		color: "#dc75e5",
		name: "ZIL",
		extensions: [".zil", ".mud"]
	},
	ZEEK: {
		name: "Zeek",
		extensions: [".zeek", ".bro"]
	},
	ZENSCRIPT: {
		color: "#00BCD1",
		name: "ZenScript",
		extensions: [".zs"]
	},
	ZEPHIR: {
		color: "#118f9e",
		name: "Zephir",
		extensions: [".zep"]
	},
	ZIG: {
		color: "#ec915c",
		name: "Zig",
		extensions: [".zig", ".zig.zon"]
	},
	ZIMPL: {
		color: "#d67711",
		name: "Zimpl",
		extensions: [
			".zimpl",
			".zmpl",
			".zpl"
		]
	},
	ZMODEL: {
		color: "#ff7100",
		name: "Zmodel",
		extensions: [".zmodel"]
	},
	"CURL CONFIG": { name: "cURL Config" },
	CRONTAB: {
		color: "#ead7ac",
		name: "crontab"
	},
	DESKTOP: {
		name: "desktop",
		extensions: [
			".desktop",
			".desktop.in",
			".service"
		]
	},
	DIRCOLORS: {
		name: "dircolors",
		extensions: [".dircolors"]
	},
	EC: {
		color: "#913960",
		name: "eC",
		extensions: [".ec", ".eh"]
	},
	EDN: {
		name: "edn",
		extensions: [".edn"]
	},
	FISH: {
		color: "#4aae47",
		name: "fish",
		extensions: [".fish"]
	},
	HOON: {
		color: "#00b171",
		name: "hoon",
		extensions: [".hoon"]
	},
	ICALENDAR: {
		color: "#ec564c",
		name: "iCalendar",
		extensions: [".ics", ".ical"]
	},
	JQ: {
		color: "#c7254e",
		name: "jq",
		extensions: [".jq"]
	},
	KVLANG: {
		color: "#1da6e0",
		name: "kvlang",
		extensions: [".kv"]
	},
	"MIRC SCRIPT": {
		color: "#3d57c3",
		name: "mIRC Script",
		extensions: [".mrc"]
	},
	MCFUNCTION: {
		color: "#E22837",
		name: "mcfunction",
		extensions: [".mcfunction"]
	},
	MDSVEX: {
		color: "#5f9ea0",
		name: "mdsvex",
		extensions: [".svx"],
		wrap: true
	},
	MUPAD: {
		color: "#244963",
		name: "mupad",
		extensions: [".mu"]
	},
	NANORC: {
		color: "#2d004d",
		name: "nanorc",
		extensions: [".nanorc"]
	},
	NESC: {
		color: "#94B0C7",
		name: "nesC",
		extensions: [".nc"]
	},
	OOC: {
		color: "#b0b77e",
		name: "ooc",
		extensions: [".ooc"]
	},
	Q: {
		color: "#0040cd",
		name: "q",
		extensions: [".q"]
	},
	RESTRUCTUREDTEXT: {
		color: "#141414",
		name: "reStructuredText",
		extensions: [
			".rst",
			".rest",
			".rest.txt",
			".rst.txt"
		],
		wrap: true
	},
	"ROBOTS.TXT": { name: "robots.txt" },
	SED: {
		color: "#64b970",
		name: "sed",
		extensions: [".sed"]
	},
	TEMPL: {
		color: "#66D0DD",
		name: "templ",
		extensions: [".templ"]
	},
	VCARD: {
		color: "#ee2647",
		name: "vCard",
		extensions: [".vcf"]
	},
	WISP: {
		color: "#7582D1",
		name: "wisp",
		extensions: [".wisp"]
	},
	XBASE: {
		color: "#403a40",
		name: "xBase",
		extensions: [
			".prg",
			".ch",
			".prw"
		]
	}
};
export { getLanguageInfo as n, languageMap as r, docLanguages as t };
