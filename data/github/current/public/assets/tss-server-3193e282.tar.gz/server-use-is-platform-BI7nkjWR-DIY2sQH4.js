import { useCallback, useSyncExternalStore } from "react";
import { c } from "react/compiler-runtime";
function getPlatform() {
	if (typeof navigator === "undefined") return null;
	else if (/Windows/.test(navigator.userAgent)) return "windows";
	else if (/Macintosh/.test(navigator.userAgent)) return "mac";
	return null;
}
function subscribe() {
	return () => {};
}
function getServerSnapshot() {
	return false;
}
/**
* SSR-friendly hook to retrieve information about the user platform.
*
* @param platforms @type {Array<Platform>} platforms to check
* @returns {boolean} true if user platform matches one of the provided platforms.
*/
function useIsPlatform(platforms) {
	const $ = c(2);
	let t0;
	if ($[0] !== platforms) {
		t0 = () => {
			const platform = getPlatform();
			return platform !== null && platforms.includes(platform);
		};
		$[0] = platforms;
		$[1] = t0;
	} else t0 = $[1];
	return useSyncExternalStore(subscribe, t0, getServerSnapshot);
}
export { useIsPlatform as t };
