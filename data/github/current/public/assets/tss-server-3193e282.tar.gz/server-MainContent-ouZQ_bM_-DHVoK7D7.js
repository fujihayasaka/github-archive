import { r as getLocale } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { Bi as useFocusZone, Qt as Heading$2 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { i as VerifiedHTMLText } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { t as areCharacterKeyShortcutsEnabled } from "./server-keyboard-shortcuts-helper-BRqP2m0f-DOsDhPIe.js";
import { t as Octicon } from "./server-deprecated-NWt92s1C-CJVCDSxf.js";
import { n as DragAndDrop, o as useSyncedState, t as ActionBar } from "./server-drag-and-drop-ekoR4DH7-Bqpb-P1q.js";
import { Children, Fragment, createContext, use, useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { iterateFocusableElements } from "@primer/behaviors/utils";
import { FocusKeys } from "@primer/behaviors";
import { c } from "react/compiler-runtime";
var HeaderTags = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
var HeaderTagLevels = [
	"list-view",
	"list-view-metadata",
	"listitem"
];
var defaultHeaderTags = {
	"list-view": "h2",
	"list-view-metadata": "h3",
	listitem: "h3"
};
var defaultVariant = "default";
function useRovingTabIndex(t0) {
	const $ = c(4);
	const strict = t0 === void 0 ? true : t0;
	const usesStrictFocusZone = strict === void 0 ? true : strict;
	const unconditionallyEnabledKeys = FocusKeys.ArrowVertical | FocusKeys.HomeAndEnd | FocusKeys.PageUpDown | FocusKeys.Tab;
	const bindKeys = areCharacterKeyShortcutsEnabled() ? unconditionallyEnabledKeys | FocusKeys.JK : unconditionallyEnabledKeys;
	let t1;
	if ($[0] !== usesStrictFocusZone) {
		t1 = (direction, from, event) => {
			if (!(from instanceof HTMLElement)) return;
			if (event.key === "Tab" || event.code === "Tab") {
				if (event.shiftKey && from.id.includes("list-view-node")) return getFocusElementOutsideOfListView(from, "previous");
				const listItem = from.closest("[role=list] li");
				if (!listItem) return;
				const focusableElements = [...iterateFocusableElements(listItem, { strict: usesStrictFocusZone })];
				const hasTrailingBadgeIndex = focusableElements.findIndex(_temp2);
				const hasSelectableElementIndex = focusableElements.findIndex(_temp3);
				if (hasTrailingBadgeIndex >= 0 && hasSelectableElementIndex >= 0) {
					focusableElements.splice(hasTrailingBadgeIndex, 0, focusableElements[hasSelectableElementIndex]);
					focusableElements.splice(hasSelectableElementIndex + 1, 1);
				}
				const eventIndex = focusableElements.indexOf(event.target);
				if (eventIndex === focusableElements.length - 1 && !event.shiftKey) return getFocusElementOutsideOfListView(from, "next");
				else if (eventIndex > 0) {
					if (event.shiftKey) return focusableElements[eventIndex - 1];
					return focusableElements[eventIndex + 1];
				}
				return;
			}
			if (direction === "previous") return getListItemElement(from, direction) || getFirstElement(from);
			if (direction === "next") return getListItemElement(from, direction) || getLastElement(from);
			if (direction === "start") return getFirstElement(from);
			if (direction === "end") return getLastElement(from);
		};
		$[0] = usesStrictFocusZone;
		$[1] = t1;
	} else t1 = $[1];
	const { containerRef: t2 } = useFocusZone({
		strict: usesStrictFocusZone,
		bindKeys,
		focusInStrategy: () => {
			if (!containerRef.current) return;
			const lastFocused = containerRef.current.querySelector("[tabindex=\"0\"]");
			const listItemToFocus = lastFocused?.closest("[role=list] li");
			return listItemToFocus ? listItemToFocus : lastFocused;
		},
		focusableElementFilter: _temp,
		getNextFocusable: t1
	});
	const containerRef = t2;
	let t3;
	if ($[2] !== containerRef) {
		t3 = { containerRef };
		$[2] = containerRef;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
}
function _temp3(element_1) {
	return element_1.getAttribute("data-listview-component") === "selection-input";
}
function _temp2(element_0) {
	return element_0.parentElement?.getAttribute("data-listview-component") === "trailing-badge";
}
function _temp(element) {
	return element.getAttribute("role") !== "list";
}
function getListItemElement(element, direction) {
	let listItem = element;
	const foundListItem = element.closest("[role=list] li");
	if (foundListItem) listItem = foundListItem;
	const root = listItem.closest("[role=list]");
	if (!root) return;
	const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, (node) => {
		if (!(node instanceof HTMLElement)) return NodeFilter.FILTER_SKIP;
		if (!node.id.includes("list-view-node")) return NodeFilter.FILTER_SKIP;
		let parent = node.parentElement;
		while (parent && parent !== root) {
			if (parent.id.includes("list-view-node")) return NodeFilter.FILTER_SKIP;
			parent = parent.parentElement;
		}
		return NodeFilter.FILTER_ACCEPT;
	});
	let current = walker.firstChild();
	let i = 0;
	while (current !== listItem) {
		current = walker.nextNode();
		i++;
		if (i > 500) break;
	}
	let next = direction === "next" ? walker.nextNode() : walker.previousNode();
	while (next instanceof HTMLElement && next.parentElement?.closest("[role=list] li[aria-expanded=false]")) next = direction === "next" ? walker.nextNode() : walker.previousNode();
	return next instanceof HTMLElement ? next : void 0;
}
function getFirstElement(element) {
	const first = element.closest("[role=list]")?.querySelector("[role=list] li");
	return first instanceof HTMLElement ? first : void 0;
}
function getLastElement(element) {
	const items = element.closest("[role=list]")?.querySelectorAll("[role=list] li");
	if (!items || items.length < 1) return;
	const last = items[items.length - 1];
	if (last instanceof HTMLElement) return last;
}
function getFocusElementOutsideOfListView(element, direction) {
	const focusableElements = [...iterateFocusableElements(document.documentElement, {
		strict: true,
		onlyTabbable: true
	})];
	const currentFocusedElementIndex = focusableElements.indexOf(element);
	return direction === "next" ? focusableElements[currentFocusedElementIndex + 1] : focusableElements[currentFocusedElementIndex - 1];
}
var IdContext = createContext(void 0);
IdContext.displayName = "IdContext";
var IdProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const idPrefix = useId();
	let t1;
	if ($[0] !== idPrefix) {
		t1 = { idPrefix };
		$[0] = idPrefix;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(IdContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
IdProvider.displayName = "IdProvider";
IdProvider.displayName = "ListViewIdProvider";
var useListViewId = () => {
	const context = use(IdContext);
	if (!context) throw new Error("useListViewId must be used with IdProvider.");
	return context;
};
var ItemsContext = createContext({
	anyItemsWithActionBar: false,
	setAnyItemsWithActionBar: noop,
	hasResizableActionsWithActionBar: false,
	setHasResizableActionsWithActionBar: noop
});
ItemsContext.displayName = "ItemsContext";
var ItemsProvider = (t0) => {
	const $ = c(6);
	const { children } = t0;
	const [anyItemsWithActionBar, setAnyItemsWithActionBar] = useState(false);
	const [hasResizableActionsWithActionBar, setHasResizableActionsWithActionBar] = useState(false);
	let t1;
	if ($[0] !== anyItemsWithActionBar || $[1] !== hasResizableActionsWithActionBar) {
		t1 = {
			anyItemsWithActionBar,
			setAnyItemsWithActionBar,
			hasResizableActionsWithActionBar,
			setHasResizableActionsWithActionBar
		};
		$[0] = anyItemsWithActionBar;
		$[1] = hasResizableActionsWithActionBar;
		$[2] = t1;
	} else t1 = $[2];
	const contextProps = t1;
	let t2;
	if ($[3] !== children || $[4] !== contextProps) {
		t2 = jsx(ItemsContext, {
			value: contextProps,
			children
		});
		$[3] = children;
		$[4] = contextProps;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
};
ItemsProvider.displayName = "ItemsProvider";
ItemsProvider.displayName = "ListViewItemsProvider";
var useListViewItems = () => {
	return use(ItemsContext);
};
var ListView_module_default = {
	container: "ListView-module_KCyZMG_container",
	ul: "ListView-module_KCyZMG_ul"
};
var MultiPageSelectionContext = createContext({ multiPageSelectionAllowed: false });
MultiPageSelectionContext.displayName = "MultiPageSelectionContext";
var MultiPageSelectionProvider = (t0) => {
	const $ = c(5);
	const { children, multiPageSelectionAllowed: t1 } = t0;
	const [multiPageSelectionAllowed, setMultiPageSelectionAllowed] = useState(t1 === void 0 ? false : t1);
	let t2;
	if ($[0] !== multiPageSelectionAllowed) {
		t2 = {
			multiPageSelectionAllowed,
			setMultiPageSelectionAllowed
		};
		$[0] = multiPageSelectionAllowed;
		$[1] = t2;
	} else t2 = $[1];
	const contextProps = t2;
	let t3;
	if ($[2] !== children || $[3] !== contextProps) {
		t3 = jsx(MultiPageSelectionContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t3;
	} else t3 = $[4];
	return t3;
};
MultiPageSelectionProvider.displayName = "MultiPageSelectionProvider";
MultiPageSelectionProvider.displayName = "ListViewMultiPageSelectionProvider";
var useListViewMultiPageSelection = () => {
	return use(MultiPageSelectionContext);
};
var defaultSingularUnits = "list item";
var defaultPluralUnits = "list items";
var SelectionContext$1 = createContext({
	selectedCount: 0,
	setSelectedCount: noop,
	countOnPage: 0,
	isSelectAllChecked: false,
	anyItemsSelected: false,
	singularUnits: defaultSingularUnits,
	pluralUnits: defaultPluralUnits,
	isSelectable: false,
	hasDragHandle: false
});
SelectionContext$1.displayName = "SelectionContext";
var SelectionProvider$1 = ({ children, countOnPage = 0, singularUnits = defaultSingularUnits, pluralUnits = defaultPluralUnits, totalCount, selectedCount: externalSelectedCount = 0, isSelectable = false, hasDragHandle = false } = {
	singularUnits: defaultSingularUnits,
	pluralUnits: defaultPluralUnits,
	selectedCount: 0,
	countOnPage: 0,
	isSelectable: false,
	hasDragHandle: false
}) => {
	const [selectedCount, setSelectedCount] = useState(externalSelectedCount);
	useEffect(() => setSelectedCount(externalSelectedCount), [externalSelectedCount]);
	const isSelectAllChecked = selectedCount > 0 && selectedCount >= countOnPage;
	const anyItemsSelected = selectedCount > 0;
	return /* @__PURE__ */ jsx(SelectionContext$1, {
		value: useMemo(() => {
			return {
				totalCount,
				countOnPage,
				selectedCount,
				setSelectedCount,
				isSelectAllChecked,
				anyItemsSelected,
				singularUnits,
				pluralUnits,
				isSelectable,
				hasDragHandle
			};
		}, [
			totalCount,
			countOnPage,
			selectedCount,
			setSelectedCount,
			isSelectAllChecked,
			anyItemsSelected,
			singularUnits,
			pluralUnits,
			isSelectable,
			hasDragHandle
		]),
		children
	});
};
SelectionProvider$1.displayName = "SelectionProvider";
SelectionProvider$1.displayName = "ListViewSelectionProvider";
var useListViewSelection = () => {
	return use(SelectionContext$1);
};
var TitleContext$1 = createContext(void 0);
TitleContext$1.displayName = "TitleContext";
var TitleProvider$1 = (t0) => {
	const $ = c(9);
	const { children, title, titleHeaderTag: t1 } = t0;
	const titleHeaderTag = t1 === void 0 ? "h2" : t1;
	const [hasMetadataTitle, setHasMetadataTitle] = useState(false);
	let t2;
	if ($[0] !== title) {
		t2 = title.trim() || "List view";
		$[0] = title;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hasMetadataTitle || $[3] !== t2 || $[4] !== titleHeaderTag) {
		t3 = {
			title: t2,
			titleHeaderTag,
			hasMetadataTitle,
			setHasMetadataTitle
		};
		$[2] = hasMetadataTitle;
		$[3] = t2;
		$[4] = titleHeaderTag;
		$[5] = t3;
	} else t3 = $[5];
	const contextProps = t3;
	let t4;
	if ($[6] !== children || $[7] !== contextProps) {
		t4 = jsx(TitleContext$1, {
			value: contextProps,
			children
		});
		$[6] = children;
		$[7] = contextProps;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
};
TitleProvider$1.displayName = "TitleProvider";
TitleProvider$1.displayName = "ListViewTitleProvider";
var useListViewTitle = () => {
	const context = use(TitleContext$1);
	if (!context) throw new Error("useListViewTitle must be used with TitleProvider.");
	return context;
};
var VariantContext = createContext(void 0);
VariantContext.displayName = "VariantContext";
var VariantProvider = (t0) => {
	const $ = c(6);
	const { children, variant: t1, setVariant: t2 } = t0;
	const variant = t1 === void 0 ? defaultVariant : t1;
	const setVariant = t2 === void 0 ? noop : t2;
	let t3;
	if ($[0] !== setVariant || $[1] !== variant) {
		t3 = {
			variant,
			setVariant
		};
		$[0] = setVariant;
		$[1] = variant;
		$[2] = t3;
	} else t3 = $[2];
	const contextProps = t3;
	let t4;
	if ($[3] !== children || $[4] !== contextProps) {
		t4 = jsx(VariantContext, {
			value: contextProps,
			children
		});
		$[3] = children;
		$[4] = contextProps;
		$[5] = t4;
	} else t4 = $[5];
	return t4;
};
VariantProvider.displayName = "VariantProvider";
VariantProvider.displayName = "ListViewVariantProvider";
var useListViewVariant = () => {
	const context = use(VariantContext);
	if (!context) throw new Error("useListViewVariant must be used with VariantProvider.");
	return context;
};
var ListView = (t0) => {
	const $ = c(6);
	const { children, hasDragHandle, isSelectable, onVariantChange: t1, pluralUnits, selectedCount: t2, singularUnits, title, titleHeaderTag, totalCount, variant: t3, ...rest } = t0;
	const onVariantChange = t1 === void 0 ? noop : t1;
	const selectedCount = t2 === void 0 ? 0 : t2;
	const [variant, setVariant] = useSyncedState(t3 === void 0 ? defaultVariant : t3);
	let t4;
	let t5;
	if ($[0] !== onVariantChange || $[1] !== variant) {
		t4 = () => {
			onVariantChange?.(variant);
		};
		t5 = [onVariantChange, variant];
		$[0] = onVariantChange;
		$[1] = variant;
		$[2] = t4;
		$[3] = t5;
	} else {
		t4 = $[2];
		t5 = $[3];
	}
	useEffect(t4, t5);
	let t6;
	if ($[4] !== children) {
		t6 = Children.toArray(children);
		$[4] = children;
		$[5] = t6;
	} else t6 = $[5];
	const countOnPage = t6.length;
	return jsx(IdProvider, { children: jsx(TitleProvider$1, {
		title,
		titleHeaderTag,
		children: jsx(VariantProvider, {
			variant,
			setVariant,
			children: jsx(SelectionProvider$1, {
				countOnPage,
				selectedCount,
				totalCount,
				singularUnits,
				pluralUnits,
				isSelectable,
				hasDragHandle,
				children: jsx(MultiPageSelectionProvider, { children: jsx(ItemsProvider, { children: jsx(ListViewContainer, {
					...rest,
					children
				}) }) })
			})
		})
	}) });
};
ListView.displayName = "ListView";
var ListViewContainer = ({ ariaLabelledBy: externalAriaLabelledBy, as, children, className, emptyState, itemsListClassName, itemsListStyle: style, listRef, metadata, role, strictFocusZone, ...rest }) => {
	const { idPrefix } = useListViewId();
	const { title, titleHeaderTag } = useListViewTitle();
	const { variant } = useListViewVariant();
	const { containerRef } = useRovingTabIndex(strictFocusZone);
	const [hasListItems, setHasListItems] = useState(true);
	useEffect(() => {
		if (listRef) listRef.current = containerRef.current;
	}, [containerRef, listRef]);
	useLayoutEffect(() => {
		if (containerRef.current) setHasListItems(Array.from(containerRef.current.querySelectorAll("li")).some((li) => {
			let parent = li.parentElement;
			while (parent && parent !== containerRef.current) {
				if (parent.tagName === "UL" || parent.tagName === "OL") return false;
				parent = parent.parentElement;
			}
			return true;
		}));
	}, [containerRef, children]);
	const listViewContainerTitleId = externalAriaLabelledBy ?? `${idPrefix}-list-view-container-title`;
	const showEmptyState = emptyState && !hasListItems;
	const As = as ? as : hasListItems ? "ul" : "div";
	return /* @__PURE__ */ jsxs("div", {
		id: `${idPrefix}-list-view-container`,
		className: clsx(ListView_module_default.container, className),
		children: [
			!externalAriaLabelledBy && /* @__PURE__ */ jsx(Heading$2, {
				className: "sr-only",
				as: titleHeaderTag,
				id: listViewContainerTitleId,
				...testIdProps("list-view-title"),
				children: title
			}),
			metadata,
			/* @__PURE__ */ jsx(As, {
				className: clsx(ListView_module_default.ul, itemsListClassName),
				style,
				ref: containerRef,
				"aria-labelledby": hasListItems ? listViewContainerTitleId : void 0,
				tabIndex: -1,
				role: role ?? hasListItems ? "list" : void 0,
				"data-listview-component": "items-list",
				"data-density": variant,
				...testIdProps("list-view-items"),
				...rest,
				children: showEmptyState ? emptyState : children
			})
		]
	});
};
ListViewContainer.displayName = "ListViewContainer";
var ActionBar_module_default = {
	container: "ActionBar-module_zJjSza_container",
	hasActions: "ActionBar-module_zJjSza_hasActions"
};
var ListItemActionBar = (t0) => {
	const $ = c(3);
	const { anchorIcon, style, className, label: t1, ...props } = t0;
	const label = t1 === void 0 ? "list item action bar" : t1;
	const { setAnyItemsWithActionBar, setHasResizableActionsWithActionBar } = useListViewItems();
	let t2;
	let t3;
	if ($[0] !== setAnyItemsWithActionBar) {
		t2 = () => setAnyItemsWithActionBar(true);
		t3 = [setAnyItemsWithActionBar];
		$[0] = setAnyItemsWithActionBar;
		$[1] = t2;
		$[2] = t3;
	} else {
		t2 = $[1];
		t3 = $[2];
	}
	useEffect(t2, t3);
	useEffect(() => {
		if (props.actions) setHasResizableActionsWithActionBar(true);
	}, [props.actions, setHasResizableActionsWithActionBar]);
	return jsx("div", {
		className: clsx(ActionBar_module_default.container, props.actions && ActionBar_module_default.hasActions, className),
		style,
		...testIdProps("list-view-item-action-bar-container"),
		children: jsx(ActionBar, {
			...props,
			label,
			variant: "menu",
			overflowMenuToggleProps: anchorIcon ? { icon: anchorIcon } : void 0
		})
	});
};
ListItemActionBar.displayName = "ListItemActionBar";
var ActionsContext = createContext({
	actionsOpen: false,
	setActionsOpen: noop
});
ActionsContext.displayName = "ActionsContext";
var ActionsProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [actionsOpen, setActionsOpen] = useState(false);
	let t1;
	if ($[0] !== actionsOpen) {
		t1 = {
			actionsOpen,
			setActionsOpen
		};
		$[0] = actionsOpen;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(ActionsContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
ActionsProvider.displayName = "ActionsProvider";
ActionsProvider.displayName = "ListItemActionsProvider";
var AlignmentContext = createContext({ alignment: "top" });
AlignmentContext.displayName = "AlignmentContext";
var AlignmentProvider = (t0) => {
	const $ = c(5);
	const { alignment, children } = t0;
	const t1 = alignment ?? "top";
	let t2;
	if ($[0] !== t1) {
		t2 = { alignment: t1 };
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	const contextProps = t2;
	let t3;
	if ($[2] !== children || $[3] !== contextProps) {
		t3 = jsx(AlignmentContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t3;
	} else t3 = $[4];
	return t3;
};
AlignmentProvider.displayName = "AlignmentProvider";
AlignmentProvider.displayName = "ListItemAlignmentProvider";
var useListItemAlignment = () => {
	return use(AlignmentContext);
};
var DescriptionContext = createContext(void 0);
DescriptionContext.displayName = "DescriptionContext";
var DescriptionProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [description, setDescription] = useState("");
	let t1;
	if ($[0] !== description) {
		t1 = {
			description,
			setDescription
		};
		$[0] = description;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(DescriptionContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
DescriptionProvider.displayName = "DescriptionProvider";
DescriptionProvider.displayName = "ListItemDescriptionProvider";
var useListItemDescription = () => {
	const context = use(DescriptionContext);
	if (!context) throw new Error("useListItemDescription must be used with DescriptionProvider.");
	return context;
};
var ListItem_module_default = {
	centerAligned: "ListItem-module_YJnJ2q_centerAligned",
	compact: "ListItem-module_YJnJ2q_compact",
	hasActionBar: "ListItem-module_YJnJ2q_hasActionBar",
	listItem: "ListItem-module_YJnJ2q_listItem",
	selected: "ListItem-module_YJnJ2q_selected"
};
var MetadataContainer_module_default = { container: "MetadataContainer-module_1j4PNG_container" };
function ListItemMetadataContainer({ style, className, children }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(MetadataContainer_module_default.container, className),
		style,
		...testIdProps("list-view-item-metadata"),
		children
	});
}
ListItemMetadataContainer.displayName = "ListItemMetadataContainer";
var NewActivityContext = createContext(void 0);
NewActivityContext.displayName = "NewActivityContext";
var NewActivityProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [hasNewActivity, setHasNewActivity] = useState(false);
	let t1;
	if ($[0] !== hasNewActivity) {
		t1 = {
			hasNewActivity,
			setHasNewActivity
		};
		$[0] = hasNewActivity;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NewActivityContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NewActivityProvider.displayName = "NewActivityProvider";
NewActivityProvider.displayName = "ListItemNewActivityProvider";
var useListItemNewActivity = () => {
	const context = use(NewActivityContext);
	if (!context) throw new Error("useListItemNewActivity must be used with NewActivityProvider.");
	return context;
};
var TitleContext = createContext(void 0);
TitleContext.displayName = "TitleContext";
var TitleProvider = ({ children }) => {
	const [title, setTitle] = useState("");
	const [titleAction, setTitleAction] = useState(null);
	const headingRef = useRef(null);
	useEffect(() => {
		if (headingRef?.current?.textContent) setTitle(headingRef.current.textContent.trim());
	}, [headingRef, setTitle]);
	return /* @__PURE__ */ jsx(TitleContext, {
		value: useMemo(() => ({
			title,
			titleAction,
			setTitleAction,
			headingRef
		}), [title, titleAction]),
		children
	});
};
TitleProvider.displayName = "TitleProvider";
TitleProvider.displayName = "ListItemTitleProvider";
var useListItemTitle = () => {
	const context = use(TitleContext);
	if (!context) throw new Error("useListItemTitle must be used with TitleProvider.");
	return context;
};
var SelectionContext = createContext({
	isSelected: false,
	onSelect: noop
});
SelectionContext.displayName = "SelectionContext";
var SelectionProvider = (t0) => {
	const $ = c(9);
	const { children, value: t1 } = t0;
	const { isSelected, onSelect } = t1;
	const { title } = useListItemTitle();
	let t2;
	if ($[0] !== onSelect || $[1] !== title) {
		t2 = (selected) => {
			announce$1(selected ? `Selected. ${title}.` : `Unselected. ${title}.`);
			onSelect(selected);
		};
		$[0] = onSelect;
		$[1] = title;
		$[2] = t2;
	} else t2 = $[2];
	const onSelectAndAnnounce = t2;
	let t3;
	if ($[3] !== isSelected || $[4] !== onSelectAndAnnounce) {
		t3 = {
			isSelected,
			onSelect: onSelectAndAnnounce
		};
		$[3] = isSelected;
		$[4] = onSelectAndAnnounce;
		$[5] = t3;
	} else t3 = $[5];
	const contextProps = t3;
	let t4;
	if ($[6] !== children || $[7] !== contextProps) {
		t4 = jsx(SelectionContext, {
			value: contextProps,
			children
		});
		$[6] = children;
		$[7] = contextProps;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
};
SelectionProvider.displayName = "SelectionProvider";
SelectionProvider.displayName = "ListItemSelectionProvider";
var useListItemSelection = () => {
	return use(SelectionContext);
};
var StatusContext = createContext(void 0);
StatusContext.displayName = "StatusContext";
var StatusProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [status, setStatus] = useState("");
	let t1;
	if ($[0] !== status) {
		t1 = {
			status,
			setStatus
		};
		$[0] = status;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(StatusContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
StatusProvider.displayName = "StatusProvider";
StatusProvider.displayName = "ListItemStatusProvider";
var useListItemStatus = () => {
	const context = use(StatusContext);
	if (!context) throw new Error("useListItemStatus must be used with StatusProvider.");
	return context;
};
var ListItemBase = ({ ref: forwardedRef, children, isActive = false, title, metadata, secondaryActions, style, className, metadataContainerStyle, metadataContainerClassName, as, ...props }) => {
	const { idPrefix } = useListViewId();
	const { isSelectable } = useListViewSelection();
	const { variant } = useListViewVariant();
	const { anyItemsWithActionBar, hasResizableActionsWithActionBar } = useListViewItems();
	const uniqueIdSuffix = useId();
	const { isSelected, onSelect } = useListItemSelection();
	const { status: labelStatus } = useListItemStatus();
	const { title: labelTitle, titleAction, headingRef } = useListItemTitle();
	const { description: labelDescription } = useListItemDescription();
	const { hasNewActivity } = useListItemNewActivity();
	const { alignment } = useListItemAlignment();
	const itemRef = useRef(null);
	useEffect(() => {
		if (typeof forwardedRef === "function") forwardedRef(itemRef.current);
		else if (forwardedRef) forwardedRef.current = itemRef.current;
	}, [forwardedRef]);
	useEffect(() => {
		if (!itemRef.current) return;
		if (isActive && document.activeElement?.tagName === "BODY") itemRef.current.focus();
	});
	const onKeyDown = useCallback((e) => {
		switch (e.key) {
			case "Enter":
				if (titleAction) {
					const activeElement = document.activeElement;
					const isListItemFocused = itemRef.current === activeElement;
					const isTitleFocused = headingRef.current && (headingRef.current === activeElement || headingRef.current.contains(activeElement));
					if (isListItemFocused || isTitleFocused) titleAction(e);
				}
				break;
			case " ":
				if (!isSelectable) break;
				if (itemRef?.current !== document.activeElement) break;
				e.preventDefault();
				onSelect(!isSelected);
				break;
			case "Escape":
				itemRef?.current?.focus();
				break;
			default: break;
		}
	}, [
		titleAction,
		isSelectable,
		onSelect,
		isSelected,
		headingRef
	]);
	const getAriaLabel = useCallback(() => {
		const labelSelected = isSelected ? "Selected" : "";
		const labelNewActivity = hasNewActivity ? "New activity" : "";
		const hasSecondaryActions = !!secondaryActions;
		const hasMetadata = Array.isArray(metadata) && metadata.length > 0 || metadata && !Array.isArray(metadata);
		let labelAdditionalInfo = "";
		if (hasMetadata || hasSecondaryActions) labelAdditionalInfo = "More information available below";
		let main = [labelTitle, labelStatus].filter((str) => str.trim()).join(": ");
		try {
			main = main.replace(/(?<!\.)\.+$/, "");
		} catch {
			while (main.endsWith(".")) main = main.substring(0, main.length - 1);
		}
		const ariaLabel = [
			labelSelected,
			main,
			labelDescription,
			labelNewActivity,
			labelAdditionalInfo
		].filter((str_0) => str_0.trim()).join(". ");
		return ariaLabel.endsWith(".") ? ariaLabel : `${ariaLabel}.`;
	}, [
		secondaryActions,
		metadata,
		isSelected,
		hasNewActivity,
		labelTitle,
		labelStatus,
		labelDescription
	]);
	return /* @__PURE__ */ jsxs(as ? as : "li", {
		ref: itemRef,
		id: `${idPrefix}-list-view-node-${uniqueIdSuffix}`,
		className: clsx(ListItem_module_default.listItem, isSelected && ListItem_module_default.selected, variant === "compact" && ListItem_module_default.compact, alignment === "center" && ListItem_module_default.centerAligned, anyItemsWithActionBar && hasResizableActionsWithActionBar && ListItem_module_default.hasActionBar, className),
		tabIndex: -1,
		"aria-label": getAriaLabel(),
		style,
		onKeyDown,
		...props,
		children: [
			title,
			children,
			Array.isArray(metadata) && metadata.length > 0 ? /* @__PURE__ */ jsx(ListItemMetadataContainer, {
				style: metadataContainerStyle,
				className: metadataContainerClassName,
				children: metadata.map((metadataItem, index) => /* @__PURE__ */ jsx(Fragment, { children: metadataItem }, index))
			}) : Boolean(metadata && !Array.isArray(metadata)) && /* @__PURE__ */ jsx(ListItemMetadataContainer, {
				style: metadataContainerStyle,
				className: metadataContainerClassName,
				children: metadata
			}),
			secondaryActions ?? (anyItemsWithActionBar && /* @__PURE__ */ jsx(ListItemActionBar, {}))
		]
	});
};
ListItemBase.displayName = "ListItemBase";
var ListItem = ({ ref, children, isSelected = false, onSelect = noop, alignment, ...rest }) => {
	const { setSelectedCount } = useListViewSelection();
	const isSelectedRef = useRef(isSelected);
	useEffect(() => {
		isSelectedRef.current = isSelected;
	});
	useEffect(() => {
		setSelectedCount((count) => isSelected ? count + 1 : Math.max(0, count - 1));
	}, [isSelected, setSelectedCount]);
	useEffect(() => {
		return () => {
			if (isSelectedRef.current) setSelectedCount((count_0) => Math.max(0, count_0 - 1));
		};
	}, [setSelectedCount]);
	return /* @__PURE__ */ jsx(ActionsProvider, { children: /* @__PURE__ */ jsx(TitleProvider, { children: /* @__PURE__ */ jsx(SelectionProvider, {
		value: useMemo(() => ({
			isSelected,
			onSelect
		}), [isSelected, onSelect]),
		children: /* @__PURE__ */ jsx(NewActivityProvider, { children: /* @__PURE__ */ jsx(DescriptionProvider, { children: /* @__PURE__ */ jsx(StatusProvider, { children: /* @__PURE__ */ jsx(AlignmentProvider, {
			alignment,
			children: /* @__PURE__ */ jsx(ListItemBase, {
				...rest,
				ref,
				children
			})
		}) }) }) })
	}) }) });
};
ListItem.displayName = "ListItem";
ListItem.displayName = "ListItem";
function useNextHeaderTag(level) {
	const { titleHeaderTag, hasMetadataTitle } = useListViewTitle();
	let t0;
	bb0: {
		const levelIndex = HeaderTagLevels.findIndex((e) => e === level);
		const headerIndex = HeaderTags.indexOf(titleHeaderTag) + (hasMetadataTitle ? levelIndex : levelIndex - 1);
		if (headerIndex > HeaderTags.length - 1) {
			t0 = "h6";
			break bb0;
		}
		t0 = HeaderTags[headerIndex] || defaultHeaderTags[level];
	}
	return t0;
}
var Selection_module_default = {
	centerAligned: "Selection-module_EUC8lq_centerAligned",
	checkbox: "Selection-module_EUC8lq_checkbox",
	compact: "Selection-module_EUC8lq_compact",
	container: "Selection-module_EUC8lq_container",
	containerWithDragHandle: "Selection-module_EUC8lq_containerWithDragHandle",
	dragTrigger: "Selection-module_EUC8lq_dragTrigger"
};
var ListItemSelection = () => {
	const $ = c(10);
	const { variant } = useListViewVariant();
	const { isSelectable, hasDragHandle } = useListViewSelection();
	const { isSelected, onSelect } = useListItemSelection();
	const { title } = useListItemTitle();
	const { alignment } = useListItemAlignment();
	if (!isSelectable) return null;
	let t0;
	if ($[0] !== alignment || $[1] !== hasDragHandle || $[2] !== isSelected || $[3] !== onSelect || $[4] !== title || $[5] !== variant) {
		let t1;
		if ($[7] !== isSelected || $[8] !== onSelect) {
			t1 = () => onSelect(!isSelected);
			$[7] = isSelected;
			$[8] = onSelect;
			$[9] = t1;
		} else t1 = $[9];
		t0 = jsxs("div", {
			className: clsx(hasDragHandle ? Selection_module_default.containerWithDragHandle : Selection_module_default.container, alignment === "center" && Selection_module_default.centerAligned),
			...testIdProps("list-view-item-selection"),
			children: [hasDragHandle && jsx(DragAndDrop.DragTrigger, { className: clsx(Selection_module_default.dragTrigger, variant === "compact" && Selection_module_default.compact) }), jsx(Checkbox, {
				className: clsx(Selection_module_default.checkbox, variant === "compact" && Selection_module_default.compact, alignment === "center" && Selection_module_default.centerAligned),
				checked: isSelected,
				onChange: t1,
				"aria-label": `Select: ${title}`,
				"data-listview-component": "selection-input",
				...testIdProps("list-view-item-selection-input")
			})]
		});
		$[0] = alignment;
		$[1] = hasDragHandle;
		$[2] = isSelected;
		$[3] = onSelect;
		$[4] = title;
		$[5] = variant;
		$[6] = t0;
	} else t0 = $[6];
	return t0;
};
ListItemSelection.displayName = "ListItemSelection";
var Title_module_default = {
	anchor: "Title-module_rvWxIG_anchor",
	centerAligned: "Title-module_rvWxIG_centerAligned",
	compact: "Title-module_rvWxIG_compact",
	container: "Title-module_rvWxIG_container",
	heading: "Title-module_rvWxIG_heading",
	inline: "Title-module_rvWxIG_inline",
	markdown: "Title-module_rvWxIG_markdown",
	trailingBadgesContainer: "Title-module_rvWxIG_trailingBadgesContainer",
	trailingBadgesSpacer: "Title-module_rvWxIG_trailingBadgesSpacer"
};
function InternalTitle({ children, containerStyle, containerClassName, headerContainerRef: containerRef, headingStyle, headingClassName, headingRef: forwardedHeadingRef, leadingBadge, trailingBadges, header }) {
	const { variant } = useListViewVariant();
	const { headingRef: contextHeadingRef } = useListItemTitle();
	const { alignment } = useListItemAlignment();
	const TitleTag = useNextHeaderTag("listitem");
	const combinedRef = (node) => {
		if (contextHeadingRef) contextHeadingRef.current = node;
		if (forwardedHeadingRef && "current" in forwardedHeadingRef) try {
			forwardedHeadingRef.current = node;
		} catch {}
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
		...testIdProps("list-view-item-title-container"),
		style: containerStyle,
		className: clsx(Title_module_default.container, variant === "compact" && Title_module_default.compact, alignment === "center" && Title_module_default.centerAligned, containerClassName),
		ref: containerRef,
		"data-listview-item-title-container": true,
		children: [
			/* @__PURE__ */ jsxs(TitleTag, {
				className: clsx(Title_module_default.heading, variant === "compact" && Title_module_default.compact, headingClassName),
				style: headingStyle,
				ref: combinedRef,
				...testIdProps("list-view-item-title"),
				children: [leadingBadge, header]
			}),
			trailingBadges && /* @__PURE__ */ jsx("span", { className: Title_module_default.trailingBadgesSpacer }),
			/* @__PURE__ */ jsx("span", {
				className: Title_module_default.trailingBadgesContainer,
				children: trailingBadges
			}),
			children
		]
	}), /* @__PURE__ */ jsx(ListItemSelection, {})] });
}
InternalTitle.displayName = "InternalTitle";
function ListItemTitle({ children, value, containerStyle, containerClassName, headerContainerRef, headingStyle, headingClassName, headingRef, leadingBadge, trailingBadges, anchorRef: forwardedAnchorRef, ...headingLinkProps }) {
	const fallbackAnchorRef = useRef(null);
	const anchorRef = forwardedAnchorRef || fallbackAnchorRef;
	useSetTitleAction({
		anchorRef,
		...headingLinkProps
	});
	return /* @__PURE__ */ jsx(InternalTitle, {
		header: headingLinkProps.href || headingLinkProps.onClick ? /* @__PURE__ */ jsx(HeadingLink, {
			anchorRef,
			...headingLinkProps,
			children: /* @__PURE__ */ jsx("span", { children: value })
		}) : /* @__PURE__ */ jsx("span", { children: value }),
		containerStyle,
		containerClassName,
		headerContainerRef,
		headingStyle,
		headingClassName,
		headingRef,
		leadingBadge,
		trailingBadges,
		children
	});
}
ListItemTitle.displayName = "ListItemTitle";
function ListItemSafeHTMLTitle(t0) {
	const $ = c(24);
	let children;
	let containerClassName;
	let containerStyle;
	let headerContainerRef;
	let headerProps;
	let headingClassName;
	let headingRef;
	let headingStyle;
	let html;
	let leadingBadge;
	let trailingBadges;
	if ($[0] !== t0) {
		({children, html, containerStyle, containerClassName, headerContainerRef, headingStyle, headingClassName, headingRef, leadingBadge, trailingBadges, ...headerProps} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = containerClassName;
		$[3] = containerStyle;
		$[4] = headerContainerRef;
		$[5] = headerProps;
		$[6] = headingClassName;
		$[7] = headingRef;
		$[8] = headingStyle;
		$[9] = html;
		$[10] = leadingBadge;
		$[11] = trailingBadges;
	} else {
		children = $[1];
		containerClassName = $[2];
		containerStyle = $[3];
		headerContainerRef = $[4];
		headerProps = $[5];
		headingClassName = $[6];
		headingRef = $[7];
		headingStyle = $[8];
		html = $[9];
		leadingBadge = $[10];
		trailingBadges = $[11];
	}
	useSetTitleAction(headerProps);
	let t1;
	if ($[12] !== children || $[13] !== containerClassName || $[14] !== containerStyle || $[15] !== headerContainerRef || $[16] !== headerProps || $[17] !== headingClassName || $[18] !== headingRef || $[19] !== headingStyle || $[20] !== html || $[21] !== leadingBadge || $[22] !== trailingBadges) {
		t1 = jsx(InternalTitle, {
			header: jsx(UnsafeHTMLText, {
				html,
				...headerProps
			}),
			containerStyle,
			containerClassName,
			headerContainerRef,
			headingStyle,
			headingClassName,
			headingRef,
			leadingBadge,
			trailingBadges,
			children
		});
		$[12] = children;
		$[13] = containerClassName;
		$[14] = containerStyle;
		$[15] = headerContainerRef;
		$[16] = headerProps;
		$[17] = headingClassName;
		$[18] = headingRef;
		$[19] = headingStyle;
		$[20] = html;
		$[21] = leadingBadge;
		$[22] = trailingBadges;
		$[23] = t1;
	} else t1 = $[23];
	return t1;
}
/**
* @warning **CAUTION:** This component is not safe and the HTML must be sanitized before being passed to this component.
* This component should only be used if the html comes from a trusted source on the server, has
* known static contents, or has been sanitized by DOMPurify.
* If not, we recommend using `ListItemSafeHTMLTitle` or ListItemTitle`
**/
ListItemSafeHTMLTitle.displayName = "ListItemSafeHTMLTitle";
function ListItemUnsafeHTMLTitle(t0) {
	const $ = c(24);
	let children;
	let containerClassName;
	let containerStyle;
	let headerContainerRef;
	let headerProps;
	let headingClassName;
	let headingRef;
	let headingStyle;
	let html;
	let leadingBadge;
	let trailingBadges;
	if ($[0] !== t0) {
		({children, html, containerStyle, containerClassName, headerContainerRef, headingStyle, headingClassName, headingRef, leadingBadge, trailingBadges, ...headerProps} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = containerClassName;
		$[3] = containerStyle;
		$[4] = headerContainerRef;
		$[5] = headerProps;
		$[6] = headingClassName;
		$[7] = headingRef;
		$[8] = headingStyle;
		$[9] = html;
		$[10] = leadingBadge;
		$[11] = trailingBadges;
	} else {
		children = $[1];
		containerClassName = $[2];
		containerStyle = $[3];
		headerContainerRef = $[4];
		headerProps = $[5];
		headingClassName = $[6];
		headingRef = $[7];
		headingStyle = $[8];
		html = $[9];
		leadingBadge = $[10];
		trailingBadges = $[11];
	}
	useSetTitleAction(headerProps);
	let t1;
	if ($[12] !== children || $[13] !== containerClassName || $[14] !== containerStyle || $[15] !== headerContainerRef || $[16] !== headerProps || $[17] !== headingClassName || $[18] !== headingRef || $[19] !== headingStyle || $[20] !== html || $[21] !== leadingBadge || $[22] !== trailingBadges) {
		t1 = jsx(InternalTitle, {
			header: jsx(VerifiedHTMLText, {
				html,
				...headerProps
			}),
			containerStyle,
			containerClassName,
			headerContainerRef,
			headingStyle,
			headingClassName,
			headingRef,
			leadingBadge,
			trailingBadges,
			children
		});
		$[12] = children;
		$[13] = containerClassName;
		$[14] = containerStyle;
		$[15] = headerContainerRef;
		$[16] = headerProps;
		$[17] = headingClassName;
		$[18] = headingRef;
		$[19] = headingStyle;
		$[20] = html;
		$[21] = leadingBadge;
		$[22] = trailingBadges;
		$[23] = t1;
	} else t1 = $[23];
	return t1;
}
ListItemUnsafeHTMLTitle.displayName = "ListItemUnsafeHTMLTitle";
function HeadingLink({ anchorStyle, anchorClassName, anchorRef: forwardedAnchorRef, linkProps, children, ...componentProps }) {
	const { as: As = "a", ...restLinkProps } = linkProps ?? {};
	const fallbackAnchorRef = useRef(null);
	const anchorRef = forwardedAnchorRef || fallbackAnchorRef;
	return /* @__PURE__ */ jsx(As, {
		...testIdProps("listitem-title-link"),
		style: anchorStyle,
		ref: anchorRef,
		className: clsx(Title_module_default.anchor, Title_module_default.inline, anchorClassName),
		...componentProps,
		...restLinkProps,
		children
	});
}
HeadingLink.displayName = "HeadingLink";
var useSetTitleAction = (t0) => {
	const $ = c(7);
	const { href, onClick, anchorRef } = t0;
	const { setTitleAction, headingRef } = useListItemTitle();
	let t1;
	let t2;
	if ($[0] !== anchorRef || $[1] !== headingRef || $[2] !== href || $[3] !== onClick || $[4] !== setTitleAction) {
		t1 = () => {
			if (href || onClick) setTitleAction(() => (e) => {
				if (href && (e.metaKey || e.ctrlKey)) window.open(href, "_blank");
				else if (anchorRef?.current) anchorRef.current.click();
				else if (headingRef?.current) {
					const clickableElement = headingRef.current.querySelector("a, button");
					if (clickableElement) clickableElement.click();
				}
			});
		};
		t2 = [
			anchorRef,
			headingRef,
			href,
			onClick,
			setTitleAction
		];
		$[0] = anchorRef;
		$[1] = headingRef;
		$[2] = href;
		$[3] = onClick;
		$[4] = setTitleAction;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	useEffect(t1, t2);
	return null;
};
var LeadingVisual_module_default = {
	inner: "LeadingVisual-module_ZoE06G_inner",
	outer: "LeadingVisual-module_ZoE06G_outer"
};
var UnreadIndicator_module_default = { container: "UnreadIndicator-module_MOv1pq_container" };
var ListItemUnreadIndicator = () => {
	return /* @__PURE__ */ jsx("div", {
		className: UnreadIndicator_module_default.container,
		children: /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			...testIdProps("list-view-item-unread-indicator"),
			children: "New activity."
		})
	});
};
ListItemUnreadIndicator.displayName = "ListItemUnreadIndicator";
var DEFAULT_VISUAL_SIZE = 16;
function ListItemLeadingVisual(t0) {
	const $ = c(10);
	const { icon, color, description, newActivity: t1, className, children, size: t2, ...props } = t0;
	const newActivity = t1 === void 0 ? false : t1;
	const sizeProp = t2 === void 0 ? DEFAULT_VISUAL_SIZE : t2;
	const { variant } = useListViewVariant();
	const { setStatus } = useListItemStatus();
	const { setHasNewActivity } = useListItemNewActivity();
	let t3;
	if ($[0] !== description) {
		t3 = description?.trim();
		$[0] = description;
		$[1] = t3;
	} else t3 = $[1];
	const trimmedDescription = t3;
	const { alignment } = useListItemAlignment();
	const size = useResponsiveValue(sizeProp, DEFAULT_VISUAL_SIZE);
	let t4;
	let t5;
	if ($[2] !== newActivity || $[3] !== setHasNewActivity) {
		t4 = () => {
			setHasNewActivity(newActivity);
		};
		t5 = [newActivity, setHasNewActivity];
		$[2] = newActivity;
		$[3] = setHasNewActivity;
		$[4] = t4;
		$[5] = t5;
	} else {
		t4 = $[4];
		t5 = $[5];
	}
	useEffect(t4, t5);
	let t6;
	let t7;
	if ($[6] !== setStatus || $[7] !== trimmedDescription) {
		t6 = () => {
			if (trimmedDescription) setStatus(trimmedDescription);
		};
		t7 = [setStatus, trimmedDescription];
		$[6] = setStatus;
		$[7] = trimmedDescription;
		$[8] = t6;
		$[9] = t7;
	} else {
		t6 = $[8];
		t7 = $[9];
	}
	useEffect(t6, t7);
	const marginTop = alignment === "center" ? 0 : (variant === "compact" ? 18 : newActivity ? 13 : 22) - size / 2;
	return jsxs("div", {
		className: clsx(LeadingVisual_module_default.outer, className),
		style: { marginTop: `${marginTop}px` },
		...props,
		children: [jsx("div", { children: jsxs("div", {
			...testIdProps("list-view-leading-visual"),
			className: LeadingVisual_module_default.inner,
			style: {
				width: `${size}px`,
				height: `${size}px`
			},
			children: [
				icon && jsx(Octicon, {
					"aria-label": "",
					icon,
					color
				}),
				children,
				trimmedDescription && jsx("span", {
					className: "sr-only",
					...testIdProps("leading-visual-text-description"),
					children: trimmedDescription
				})
			]
		}) }), newActivity && jsx(ListItemUnreadIndicator, {})]
	});
}
ListItemLeadingVisual.displayName = "ListItemLeadingVisual";
var LeadingContent_module_default = {
	centerAligned: "LeadingContent-module_jJiFia_centerAligned",
	container: "LeadingContent-module_jJiFia_container",
	isSelectable: "LeadingContent-module_jJiFia_isSelectable"
};
var ListItemLeadingContent = (t0) => {
	const $ = c(6);
	const { style, className, children } = t0;
	const { isSelectable } = useListViewSelection();
	const { alignment } = useListItemAlignment();
	let t1;
	if ($[0] !== alignment || $[1] !== children || $[2] !== className || $[3] !== isSelectable || $[4] !== style) {
		t1 = jsx("div", {
			className: clsx(LeadingContent_module_default.container, isSelectable && LeadingContent_module_default.isSelectable, alignment === "center" && LeadingContent_module_default.centerAligned, className),
			...testIdProps("list-view-item-leading-content"),
			style,
			children
		});
		$[0] = alignment;
		$[1] = children;
		$[2] = className;
		$[3] = isSelectable;
		$[4] = style;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
};
ListItemLeadingContent.displayName = "ListItemLeadingContent";
var Metadata_module_default = {
	alignRight: "Metadata-module_fpzokG_alignRight",
	metadata: "Metadata-module_fpzokG_metadata",
	primary: "Metadata-module_fpzokG_primary",
	secondary: "Metadata-module_fpzokG_secondary"
};
function ListItemMetadata({ children, alignment, variant, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("list-view-item-metadata-item"),
		...props,
		className: clsx(Metadata_module_default.metadata, variant === "primary" ? Metadata_module_default.primary : Metadata_module_default.secondary, alignment === "right" && Metadata_module_default.alignRight, props.className),
		children
	});
}
ListItemMetadata.displayName = "ListItemMetadata";
function number(value, options) {
	return new Intl.NumberFormat(getLocale(), { maximumFractionDigits: options?.precision }).format(value);
}
var SUFFIXES = [
	"k",
	"m",
	"b"
];
/**
* Formats a number into a human-readable string with optional precision, capping, and suffix.
* @param value - The number to format.
* @param options - An optional object containing formatting options.
*    - precision - The number of decimal places to include in the formatted string. Defaults to 1.
*    - capping - The maximum value to display before adding a capping symbol. Defaults to Infinity.
*    - suffix - Whether to add a suffix indicating the magnitude of the number (e.g. "k" for thousands). Defaults to true.
* @returns A human-readable string representing the formatted number.
*/
function human(value, options) {
	const { suffix = true, capping = Infinity, precision = 1 } = options ?? {};
	let suffixLabel = "";
	let formattedValue = Math.min(capping, value);
	if (suffix) {
		const base = getNumberBase(formattedValue);
		suffixLabel = SUFFIXES[base - 1] || "";
		formattedValue = formattedValue / 1e3 ** base;
	}
	const result = number(formattedValue, { precision }) + suffixLabel;
	if (value > capping) return `${result}+`;
	return result;
}
/**
* Calculates the significance-based precision for a given value.
* If the value is less than or equal to 10,000, the precision is 1.
* Otherwise the precision depends on the order of magnitude.
*
* @param value - The value for which to calculate the significance-based precision.
* @returns The significance-based precision for the given value.
*/
function getSignificanceBasedPrecision(value) {
	if (value <= 1e4) return 1;
	if (value / 1e3 ** getNumberBase(value) >= 10) return 0;
	return 1;
}
/**
* Returns the base for formatting a number.
*
* @param value - The number to determine the base for.
* @returns The base for formatting the number.
*/
function getNumberBase(value) {
	const base = Math.floor(Math.log(Math.max(Math.abs(value), 1)) / Math.log(1e3));
	return Math.min(SUFFIXES.length, base);
}
var Description_module_default = {
	compact: "Description-module_UJyd6W_compact",
	container: "Description-module_UJyd6W_container"
};
function ListItemDescription(t0) {
	const $ = c(5);
	const { children, style, className } = t0;
	const { variant } = useListViewVariant();
	let t1;
	if ($[0] !== children || $[1] !== className || $[2] !== style || $[3] !== variant) {
		t1 = jsx("div", {
			...testIdProps("list-view-item-description"),
			className: clsx(Description_module_default.container, variant === "compact" && Description_module_default.compact, className),
			style,
			children
		});
		$[0] = children;
		$[1] = className;
		$[2] = style;
		$[3] = variant;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
ListItemDescription.displayName = "ListItemDescription";
var MainContent_module_default = {
	centerAligned: "MainContent-module_u-bL2W_centerAligned",
	compact: "MainContent-module_u-bL2W_compact",
	container: "MainContent-module_u-bL2W_container",
	inner: "MainContent-module_u-bL2W_inner"
};
function ListItemMainContent(t0) {
	const $ = c(4);
	const { children } = t0;
	const { variant } = useListViewVariant();
	const { alignment } = useListItemAlignment();
	let t1;
	if ($[0] !== alignment || $[1] !== children || $[2] !== variant) {
		t1 = jsx(Fragment$1, { children: jsx("div", {
			...testIdProps("list-view-item-main-content"),
			className: MainContent_module_default.container,
			children: jsx("div", {
				className: clsx(MainContent_module_default.inner, variant === "compact" && MainContent_module_default.compact, alignment === "center" && MainContent_module_default.centerAligned),
				children
			})
		}) });
		$[0] = alignment;
		$[1] = children;
		$[2] = variant;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
ListItemMainContent.displayName = "ListItemMainContent";
export { useListViewVariant as _, ListItemLeadingVisual as a, ListItemTitle as c, human as d, number as f, useListViewTitle as g, useListViewSelection as h, ListItemLeadingContent as i, ListView as l, useListViewMultiPageSelection as m, ListItemActionBar as n, ListItemMainContent as o, useListViewId as p, ListItemDescription as r, ListItemMetadata as s, ListItem as t, getSignificanceBasedPrecision as u, useNextHeaderTag as v };
