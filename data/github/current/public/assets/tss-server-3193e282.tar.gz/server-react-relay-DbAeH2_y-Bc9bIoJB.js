import { i as __require, t as __commonJSMin } from "./server-chunk-DPETvcc5-SoS15Jre.js";
var require_RelayConcreteNode = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		ACTOR_CHANGE: "ActorChange",
		CATCH_FIELD: "CatchField",
		CONDITION: "Condition",
		CLIENT_COMPONENT: "ClientComponent",
		CLIENT_EDGE_TO_SERVER_OBJECT: "ClientEdgeToServerObject",
		CLIENT_EDGE_TO_CLIENT_OBJECT: "ClientEdgeToClientObject",
		CLIENT_EXTENSION: "ClientExtension",
		DEFER: "Defer",
		CONNECTION: "Connection",
		FRAGMENT: "Fragment",
		FRAGMENT_SPREAD: "FragmentSpread",
		INLINE_DATA_FRAGMENT_SPREAD: "InlineDataFragmentSpread",
		INLINE_DATA_FRAGMENT: "InlineDataFragment",
		INLINE_FRAGMENT: "InlineFragment",
		LINKED_FIELD: "LinkedField",
		LINKED_HANDLE: "LinkedHandle",
		LITERAL: "Literal",
		LIST_VALUE: "ListValue",
		LOCAL_ARGUMENT: "LocalArgument",
		MODULE_IMPORT: "ModuleImport",
		ALIASED_FRAGMENT_SPREAD: "AliasedFragmentSpread",
		ALIASED_INLINE_FRAGMENT_SPREAD: "AliasedInlineFragmentSpread",
		RELAY_RESOLVER: "RelayResolver",
		RELAY_LIVE_RESOLVER: "RelayLiveResolver",
		REQUIRED_FIELD: "RequiredField",
		OBJECT_VALUE: "ObjectValue",
		OPERATION: "Operation",
		REQUEST: "Request",
		ROOT_ARGUMENT: "RootArgument",
		SCALAR_FIELD: "ScalarField",
		SCALAR_HANDLE: "ScalarHandle",
		SPLIT_OPERATION: "SplitOperation",
		STREAM: "Stream",
		TYPE_DISCRIMINATOR: "TypeDiscriminator",
		UPDATABLE_QUERY: "UpdatableQuery",
		VARIABLE: "Variable"
	};
}));
/**
* Copyright (c) 2013-present, Facebook, Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_invariant = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Use invariant() to assert state which your program assumes to be true.
	*
	* Provide sprintf-style format (only %s is supported) and arguments
	* to provide information about what broke and what you were
	* expecting.
	*
	* The invariant message will be stripped in production, but the invariant
	* will remain to ensure logic does not differ in production.
	*/
	var NODE_ENV = "production";
	var invariant = function(condition, format, a, b, c, d, e, f) {
		if (NODE_ENV !== "production") {
			if (format === void 0) throw new Error("invariant requires an error message argument");
		}
		if (!condition) {
			var error;
			if (format === void 0) error = /* @__PURE__ */ new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
			else {
				var args = [
					a,
					b,
					c,
					d,
					e,
					f
				];
				var argIndex = 0;
				error = new Error(format.replace(/%s/g, function() {
					return args[argIndex++];
				}));
				error.name = "Invariant Violation";
			}
			error.framesToPop = 1;
			throw error;
		}
	};
	module.exports = invariant;
}));
var require_emptyFunction = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Copyright (c) 2013-present, Facebook, Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*
	* 
	*/
	function makeEmptyFunction(arg) {
		return function() {
			return arg;
		};
	}
	/**
	* This function accepts and discards inputs; it has no side effects. This is
	* primarily useful idiomatically for overridable function endpoints which
	* always need to be callable, since JS lacks a null-call idiom ala Cocoa.
	*/
	var emptyFunction = function emptyFunction() {};
	emptyFunction.thatReturns = makeEmptyFunction;
	emptyFunction.thatReturnsFalse = makeEmptyFunction(false);
	emptyFunction.thatReturnsTrue = makeEmptyFunction(true);
	emptyFunction.thatReturnsNull = makeEmptyFunction(null);
	emptyFunction.thatReturnsThis = function() {
		return this;
	};
	emptyFunction.thatReturnsArgument = function(arg) {
		return arg;
	};
	module.exports = emptyFunction;
}));
/**
* Copyright (c) 2014-present, Facebook, Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var require_warning = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_emptyFunction();
}));
var require_GraphQLTag = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayConcreteNode = require_RelayConcreteNode();
	var invariant = require_invariant();
	require_warning();
	function graphql(strings) {
		invariant(false);
	}
	function getNode(taggedNode) {
		var node = taggedNode;
		if (typeof node === "function") node = node();
		else if (node["default"]) node = node["default"];
		return node;
	}
	function isFragment(node) {
		var fragment = getNode(node);
		return typeof fragment === "object" && fragment !== null && fragment.kind === RelayConcreteNode.FRAGMENT;
	}
	function isRequest(node) {
		var request = getNode(node);
		return typeof request === "object" && request !== null && request.kind === RelayConcreteNode.REQUEST;
	}
	function isUpdatableQuery(node) {
		var updatableQuery = getNode(node);
		return typeof updatableQuery === "object" && updatableQuery !== null && updatableQuery.kind === RelayConcreteNode.UPDATABLE_QUERY;
	}
	function isInlineDataFragment(node) {
		var fragment = getNode(node);
		return typeof fragment === "object" && fragment !== null && fragment.kind === RelayConcreteNode.INLINE_DATA_FRAGMENT;
	}
	function getFragment(taggedNode) {
		var fragment = getNode(taggedNode);
		!isFragment(fragment) && invariant(false);
		return fragment;
	}
	function getPaginationFragment(taggedNode) {
		var _fragment$metadata;
		var fragment = getFragment(taggedNode);
		var refetch = (_fragment$metadata = fragment.metadata) === null || _fragment$metadata === void 0 ? void 0 : _fragment$metadata.refetch;
		var connection = refetch === null || refetch === void 0 ? void 0 : refetch.connection;
		if (refetch === null || typeof refetch !== "object" || connection === null || typeof connection !== "object") return null;
		return fragment;
	}
	function getRefetchableFragment(taggedNode) {
		var _fragment$metadata2;
		var fragment = getFragment(taggedNode);
		var refetch = (_fragment$metadata2 = fragment.metadata) === null || _fragment$metadata2 === void 0 ? void 0 : _fragment$metadata2.refetch;
		if (refetch === null || typeof refetch !== "object") return null;
		return fragment;
	}
	function getRequest(taggedNode) {
		var request = getNode(taggedNode);
		!isRequest(request) && invariant(false);
		return request;
	}
	function getUpdatableQuery(taggedNode) {
		var updatableQuery = getNode(taggedNode);
		!isUpdatableQuery(updatableQuery) && invariant(false);
		return updatableQuery;
	}
	function getInlineDataFragment(taggedNode) {
		var fragment = getNode(taggedNode);
		!isInlineDataFragment(fragment) && invariant(false);
		return fragment;
	}
	module.exports = {
		getFragment,
		getNode,
		getPaginationFragment,
		getRefetchableFragment,
		getRequest,
		getUpdatableQuery,
		getInlineDataFragment,
		graphql,
		isFragment,
		isRequest,
		isUpdatableQuery,
		isInlineDataFragment
	};
}));
var require_interopRequireDefault = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _interopRequireDefault(e) {
		return e && e.__esModule ? e : { "default": e };
	}
	module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_typeof = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _typeof(o) {
		"@babel/helpers - typeof";
		return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
	}
	module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_toPrimitive = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _typeof = require_typeof()["default"];
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_toPropertyKey = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _typeof = require_typeof()["default"];
	var toPrimitive = require_toPrimitive();
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_defineProperty = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var toPropertyKey = require_toPropertyKey();
	function _defineProperty(e, r, t) {
		return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : e[r] = t, e;
	}
	module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_objectSpread2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var defineProperty = require_defineProperty();
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	module.exports = _objectSpread2, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_arrayLikeToArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _arrayLikeToArray(r, a) {
		(null == a || a > r.length) && (a = r.length);
		for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
		return n;
	}
	module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_unsupportedIterableToArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var arrayLikeToArray = require_arrayLikeToArray();
	function _unsupportedIterableToArray(r, a) {
		if (r) {
			if ("string" == typeof r) return arrayLikeToArray(r, a);
			var t = {}.toString.call(r).slice(8, -1);
			return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? arrayLikeToArray(r, a) : void 0;
		}
	}
	module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_createForOfIteratorHelper = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var unsupportedIterableToArray = require_unsupportedIterableToArray();
	function _createForOfIteratorHelper(r, e) {
		var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
		if (!t) {
			if (Array.isArray(r) || (t = unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
				t && (r = t);
				var _n = 0, F = function F() {};
				return {
					s: F,
					n: function n() {
						return _n >= r.length ? { done: !0 } : {
							done: !1,
							value: r[_n++]
						};
					},
					e: function e(r) {
						throw r;
					},
					f: F
				};
			}
			throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
		}
		var o, a = !0, u = !1;
		return {
			s: function s() {
				t = t.call(r);
			},
			n: function n() {
				var r = t.next();
				return a = r.done, r;
			},
			e: function e(r) {
				u = !0, o = r;
			},
			f: function f() {
				try {
					a || null == t["return"] || t["return"]();
				} finally {
					if (u) throw o;
				}
			}
		};
	}
	module.exports = _createForOfIteratorHelper, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_handlePotentialSnapshotErrors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var invariant = require_invariant();
	function handleFieldErrors(environment, fieldErrors, loggingContext) {
		var _iterator = (0, _createForOfIteratorHelper2["default"])(fieldErrors), _step;
		try {
			for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var fieldError = _step.value;
				environment.relayFieldLogger((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, fieldError), {}, { uiContext: loggingContext }));
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
		var _iterator2 = (0, _createForOfIteratorHelper2["default"])(fieldErrors), _step2;
		try {
			for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
				var _fieldError = _step2.value;
				if (eventShouldThrow(_fieldError)) switch (_fieldError.kind) {
					case "relay_resolver.error": throw new Error("Relay: Resolver error at path '".concat(_fieldError.fieldPath, "' in '").concat(_fieldError.owner, "'. Message: ").concat(_fieldError.error.message));
					case "relay_field_payload.error": throw new Error("Relay: Unexpected response payload - check server logs for details.");
					case "missing_expected_data.throw": throw new Error("Relay: Missing expected data at path '".concat(_fieldError.fieldPath, "' in '").concat(_fieldError.owner, "'."));
					case "missing_required_field.throw": throw new Error("Relay: Missing @required value at path '".concat(_fieldError.fieldPath, "' in '").concat(_fieldError.owner, "'."));
					case "missing_required_field.log":
					case "missing_expected_data.log": break;
					default:
						_fieldError.kind;
						invariant(false);
				}
			}
		} catch (err) {
			_iterator2.e(err);
		} finally {
			_iterator2.f();
		}
	}
	function eventShouldThrow(event) {
		switch (event.kind) {
			case "relay_resolver.error":
			case "relay_field_payload.error": return event.shouldThrow && !event.handled;
			case "missing_expected_data.throw":
			case "missing_required_field.throw": return !event.handled;
			case "missing_required_field.log":
			case "missing_expected_data.log": return false;
			default:
				event.kind;
				throw new Error("Relay: Unexpected event kind");
		}
	}
	function handlePotentialSnapshotErrors(environment, fieldErrors, loggingContext) {
		if (fieldErrors != null) handleFieldErrors(environment, fieldErrors, loggingContext);
	}
	module.exports = {
		handlePotentialSnapshotErrors,
		eventShouldThrow
	};
}));
var require_arrayWithoutHoles = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var arrayLikeToArray = require_arrayLikeToArray();
	function _arrayWithoutHoles(r) {
		if (Array.isArray(r)) return arrayLikeToArray(r);
	}
	module.exports = _arrayWithoutHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_iterableToArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _iterableToArray(r) {
		if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
	}
	module.exports = _iterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_nonIterableSpread = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _nonIterableSpread() {
		throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
	}
	module.exports = _nonIterableSpread, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_toConsumableArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var arrayWithoutHoles = require_arrayWithoutHoles();
	var iterableToArray = require_iterableToArray();
	var unsupportedIterableToArray = require_unsupportedIterableToArray();
	var nonIterableSpread = require_nonIterableSpread();
	function _toConsumableArray(r) {
		return arrayWithoutHoles(r) || iterableToArray(r) || unsupportedIterableToArray(r) || nonIterableSpread();
	}
	module.exports = _toConsumableArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_RelayDefaultHandleKey = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = { DEFAULT_HANDLE_KEY: "" };
}));
var require_getRelayHandleKey = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var DEFAULT_HANDLE_KEY = require_RelayDefaultHandleKey().DEFAULT_HANDLE_KEY;
	var invariant = require_invariant();
	function getRelayHandleKey(handleName, key, fieldName) {
		if (key && key !== DEFAULT_HANDLE_KEY) return "__".concat(key, "_").concat(handleName);
		!(fieldName != null) && invariant(false);
		return "__".concat(fieldName, "_").concat(handleName);
	}
	module.exports = getRelayHandleKey;
}));
var require_RelayFeatureFlags = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		ENABLE_VARIABLE_CONNECTION_KEY: false,
		ENABLE_RELAY_RESOLVERS: false,
		ENABLE_GETFRAGMENTIDENTIFIER_OPTIMIZATION: false,
		ENABLE_FRIENDLY_QUERY_NAME_GQL_URL: false,
		ENABLE_DO_NOT_WRAP_LIVE_QUERY: false,
		ENABLE_NOTIFY_SUBSCRIPTION: false,
		BATCH_ASYNC_MODULE_UPDATES_FN: null,
		ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT: false,
		MAX_DATA_ID_LENGTH: null,
		STRING_INTERN_LEVEL: 0,
		LOG_MISSING_RECORDS_IN_PROD: false,
		ENABLE_STORE_ID_COLLISION_LOGGING: false,
		ENABLE_NONCOMPLIANT_ERROR_HANDLING_ON_LISTS: false,
		ENABLE_LOOSE_SUBSCRIPTION_ATTRIBUTION: false,
		ENABLE_OPERATION_TRACKER_OPTIMISTIC_UPDATES: false,
		ENABLE_RELAY_OPERATION_TRACKER_SUSPENSE: false,
		PROCESS_OPTIMISTIC_UPDATE_BEFORE_SUBSCRIPTION: false,
		MARK_RESOLVER_VALUES_AS_CLEAN_AFTER_FRAGMENT_REREAD: false,
		ENABLE_CYLE_DETECTION_IN_VARIABLES: false,
		ENABLE_ACTIVITY_COMPATIBILITY: false,
		ENABLE_READ_TIME_RESOLVER_STORAGE_KEY_PREFIX: true,
		ENABLE_USE_PAGINATION_IS_LOADING_FIX: false,
		DISALLOW_NESTED_UPDATES: false,
		ENABLE_TYPENAME_PREFIXED_DATA_ID: false,
		ENABLE_UI_CONTEXT_ON_RELAY_LOGGER: false,
		CHECK_ALL_FRAGMENTS_FOR_MISSING_CLIENT_EDGES: false
	};
}));
var require_stableCopy = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function stableCopy(value) {
		if (!value || typeof value !== "object") return value;
		if (Array.isArray(value)) return value.map(stableCopy);
		var keys = Object.keys(value).sort();
		var stable = {};
		for (var i = 0; i < keys.length; i++) stable[keys[i]] = stableCopy(value[keys[i]]);
		return stable;
	}
	function hasCycle(value) {
		var parents = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : /* @__PURE__ */ new Set();
		if (!value || typeof value !== "object") return false;
		if (parents.has(value)) return true;
		var newParents = new Set(parents);
		newParents.add(value);
		return (Array.isArray(value) ? value : Object.values(value)).some(function(v) {
			return hasCycle(v, newParents);
		});
	}
	module.exports = {
		stableCopy,
		hasCycle
	};
}));
var require_RelayStoreUtils = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var getRelayHandleKey = require_getRelayHandleKey();
	var RelayConcreteNode = require_RelayConcreteNode();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var stableCopy = require_stableCopy().stableCopy;
	var invariant = require_invariant();
	var VARIABLE = RelayConcreteNode.VARIABLE, LITERAL = RelayConcreteNode.LITERAL, OBJECT_VALUE = RelayConcreteNode.OBJECT_VALUE, LIST_VALUE = RelayConcreteNode.LIST_VALUE;
	var ERRORS_KEY = "__errors";
	var MODULE_COMPONENT_KEY_PREFIX = "__module_component_";
	var MODULE_OPERATION_KEY_PREFIX = "__module_operation_";
	var RELAY_READ_TIME_RESOLVER_KEY_PREFIX = "$r:";
	function getArgumentValue(arg, variables) {
		if (arg.kind === VARIABLE) return getStableVariableValue(arg.variableName, variables);
		else if (arg.kind === LITERAL) return arg.value;
		else if (arg.kind === OBJECT_VALUE) {
			var value = {};
			arg.fields.forEach(function(field) {
				value[field.name] = getArgumentValue(field, variables);
			});
			return value;
		} else if (arg.kind === LIST_VALUE) {
			var _value = [];
			arg.items.forEach(function(item) {
				item != null && _value.push(getArgumentValue(item, variables));
			});
			return _value;
		}
	}
	function getArgumentValues(args, variables, isWithinUnmatchedTypeRefinement) {
		var values = {};
		if (isWithinUnmatchedTypeRefinement) values[RelayStoreUtils.FRAGMENT_POINTER_IS_WITHIN_UNMATCHED_TYPE_REFINEMENT] = true;
		if (args) args.forEach(function(arg) {
			values[arg.name] = getArgumentValue(arg, variables);
		});
		return values;
	}
	function getHandleStorageKey(handleField, variables) {
		var dynamicKey = handleField.dynamicKey, handle = handleField.handle, key = handleField.key, name = handleField.name, args = handleField.args, filters = handleField.filters;
		var handleName = getRelayHandleKey(handle, key, name);
		var filterArgs = null;
		if (args && filters && args.length !== 0 && filters.length !== 0) filterArgs = args.filter(function(arg) {
			return filters.indexOf(arg.name) > -1;
		});
		if (dynamicKey) filterArgs = filterArgs != null ? [dynamicKey].concat((0, _toConsumableArray2["default"])(filterArgs)) : [dynamicKey];
		if (filterArgs === null) return handleName;
		else return formatStorageKey(handleName, getArgumentValues(filterArgs, variables));
	}
	function getStorageKey(field, variables) {
		if (field.storageKey) return field.storageKey;
		var args = getArguments(field);
		var name = field.name;
		return args && args.length !== 0 ? formatStorageKey(name, getArgumentValues(args, variables)) : name;
	}
	function getReadTimeResolverStorageKey(field, variables) {
		var storageKey = getStorageKey(field, variables);
		return RelayFeatureFlags.ENABLE_READ_TIME_RESOLVER_STORAGE_KEY_PREFIX ? "$r:" + storageKey : storageKey;
	}
	function getArguments(field) {
		if (field.kind === "RelayResolver" || field.kind === "RelayLiveResolver") {
			var _field$fragment2;
			if (field.args == null) {
				var _field$fragment;
				return (_field$fragment = field.fragment) === null || _field$fragment === void 0 ? void 0 : _field$fragment.args;
			}
			if (((_field$fragment2 = field.fragment) === null || _field$fragment2 === void 0 ? void 0 : _field$fragment2.args) == null) return field.args;
			return field.args.concat(field.fragment.args);
		}
		return typeof field.args === "undefined" ? void 0 : field.args;
	}
	function getStableStorageKey(name, args) {
		return formatStorageKey(name, stableCopy(args));
	}
	function formatStorageKey(name, argValues) {
		if (!argValues) return name;
		var values = [];
		for (var argName in argValues) if (argValues.hasOwnProperty(argName)) {
			var value = argValues[argName];
			if (value != null) {
				var _JSON$stringify;
				values.push(argName + ":" + ((_JSON$stringify = JSON.stringify(value)) !== null && _JSON$stringify !== void 0 ? _JSON$stringify : "undefined"));
			}
		}
		return values.length === 0 ? name : name + "(".concat(values.join(","), ")");
	}
	function getStableVariableValue(name, variables) {
		!variables.hasOwnProperty(name) && invariant(false);
		return stableCopy(variables[name]);
	}
	function getModuleComponentKey(documentName) {
		return "".concat(MODULE_COMPONENT_KEY_PREFIX).concat(documentName);
	}
	function getModuleOperationKey(documentName) {
		return "".concat(MODULE_OPERATION_KEY_PREFIX).concat(documentName);
	}
	var RelayStoreUtils = {
		ACTOR_IDENTIFIER_KEY: "__actorIdentifier",
		CLIENT_EDGE_TRAVERSAL_PATH: "__clientEdgeTraversalPath",
		FRAGMENTS_KEY: "__fragments",
		FRAGMENT_OWNER_KEY: "__fragmentOwner",
		FRAGMENT_POINTER_IS_WITHIN_UNMATCHED_TYPE_REFINEMENT: "$isWithinUnmatchedTypeRefinement",
		FRAGMENT_PROP_NAME_KEY: "__fragmentPropName",
		MODULE_COMPONENT_KEY: "__module_component",
		ERRORS_KEY,
		ID_KEY: "__id",
		REF_KEY: "__ref",
		REFS_KEY: "__refs",
		ROOT_ID: "client:root",
		ROOT_TYPE: "__Root",
		TYPENAME_KEY: "__typename",
		INVALIDATED_AT_KEY: "__invalidated_at",
		RELAY_RESOLVER_VALUE_KEY: "__resolverValue",
		RELAY_RESOLVER_INVALIDATION_KEY: "__resolverValueMayBeInvalid",
		RELAY_RESOLVER_SNAPSHOT_KEY: "__resolverSnapshot",
		RELAY_RESOLVER_ERROR_KEY: "__resolverError",
		RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS: "__resolverOutputTypeRecordIDs",
		RELAY_READ_TIME_RESOLVER_KEY_PREFIX,
		formatStorageKey,
		getArgumentValue,
		getArgumentValues,
		getHandleStorageKey,
		getStorageKey,
		getReadTimeResolverStorageKey,
		getStableStorageKey,
		getModuleComponentKey,
		getModuleOperationKey
	};
	module.exports = RelayStoreUtils;
}));
var require_RelayConcreteVariables = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var getArgumentValues = require_RelayStoreUtils().getArgumentValues;
	var invariant = require_invariant();
	function getFragmentVariables(fragment, rootVariables, argumentVariables) {
		if (fragment.argumentDefinitions == null) return argumentVariables;
		var variables;
		fragment.argumentDefinitions.forEach(function(definition) {
			if (argumentVariables.hasOwnProperty(definition.name)) return;
			variables = variables || (0, _objectSpread2["default"])({}, argumentVariables);
			switch (definition.kind) {
				case "LocalArgument":
					variables[definition.name] = definition.defaultValue;
					break;
				case "RootArgument":
					if (!rootVariables.hasOwnProperty(definition.name)) {
						variables[definition.name] = void 0;
						break;
					}
					variables[definition.name] = rootVariables[definition.name];
					break;
				default: invariant(false);
			}
		});
		return variables || argumentVariables;
	}
	function getOperationVariables(operation, providedVariables, variables) {
		var operationVariables = {};
		operation.argumentDefinitions.forEach(function(def) {
			var value = def.defaultValue;
			if (variables[def.name] != null) value = variables[def.name];
			operationVariables[def.name] = value;
		});
		if (providedVariables != null) Object.keys(providedVariables).forEach(function(varName) {
			operationVariables[varName] = providedVariables[varName].get();
		});
		return operationVariables;
	}
	function getLocalVariables(currentVariables, argumentDefinitions, args) {
		if (argumentDefinitions == null) return currentVariables;
		var nextVariables = (0, _objectSpread2["default"])({}, currentVariables);
		var nextArgs = args ? getArgumentValues(args, currentVariables) : {};
		argumentDefinitions.forEach(function(def) {
			var _nextArgs$def$name;
			var value = (_nextArgs$def$name = nextArgs[def.name]) !== null && _nextArgs$def$name !== void 0 ? _nextArgs$def$name : def.defaultValue;
			nextVariables[def.name] = value;
		});
		return nextVariables;
	}
	module.exports = {
		getLocalVariables,
		getFragmentVariables,
		getOperationVariables
	};
}));
var require_areEqual = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Copyright (c) 2013-present, Facebook, Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*
	* 
	*/
	var aStackPool = [];
	var bStackPool = [];
	/**
	* Checks if two values are equal. Values may be primitives, arrays, or objects.
	* Returns true if both arguments have the same keys and values.
	*
	* @see http://underscorejs.org
	* @copyright 2009-2013 Jeremy Ashkenas, DocumentCloud Inc.
	* @license MIT
	*/
	function areEqual(a, b) {
		var aStack = aStackPool.length ? aStackPool.pop() : [];
		var bStack = bStackPool.length ? bStackPool.pop() : [];
		var result = eq(a, b, aStack, bStack);
		aStack.length = 0;
		bStack.length = 0;
		aStackPool.push(aStack);
		bStackPool.push(bStack);
		return result;
	}
	function eq(a, b, aStack, bStack) {
		if (a === b) return a !== 0 || 1 / a == 1 / b;
		if (a == null || b == null) return false;
		if (typeof a != "object" || typeof b != "object") return false;
		var objToStr = Object.prototype.toString;
		var className = objToStr.call(a);
		if (className != objToStr.call(b)) return false;
		switch (className) {
			case "[object String]": return a == String(b);
			case "[object Number]": return isNaN(a) || isNaN(b) ? false : a == Number(b);
			case "[object Date]":
			case "[object Boolean]": return +a == +b;
			case "[object RegExp]": return a.source == b.source && a.global == b.global && a.multiline == b.multiline && a.ignoreCase == b.ignoreCase;
		}
		var length = aStack.length;
		while (length--) if (aStack[length] == a) return bStack[length] == b;
		aStack.push(a);
		bStack.push(b);
		var size = 0;
		if (className === "[object Array]") {
			size = a.length;
			if (size !== b.length) return false;
			while (size--) if (!eq(a[size], b[size], aStack, bStack)) return false;
		} else {
			if (a.constructor !== b.constructor) return false;
			if (a.hasOwnProperty("valueOf") && b.hasOwnProperty("valueOf")) return a.valueOf() == b.valueOf();
			var keys = Object.keys(a);
			if (keys.length != Object.keys(b).length) return false;
			for (var i = 0; i < keys.length; i++) if (!eq(a[keys[i]], b[keys[i]], aStack, bStack)) return false;
		}
		aStack.pop();
		bStack.pop();
		return true;
	}
	module.exports = areEqual;
}));
var require_RelayModernSelector = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getFragmentVariables = require_RelayConcreteVariables().getFragmentVariables;
	var _require2 = require_RelayStoreUtils(), CLIENT_EDGE_TRAVERSAL_PATH = _require2.CLIENT_EDGE_TRAVERSAL_PATH, FRAGMENT_OWNER_KEY = _require2.FRAGMENT_OWNER_KEY, FRAGMENT_POINTER_IS_WITHIN_UNMATCHED_TYPE_REFINEMENT = _require2.FRAGMENT_POINTER_IS_WITHIN_UNMATCHED_TYPE_REFINEMENT, FRAGMENTS_KEY = _require2.FRAGMENTS_KEY, ID_KEY = _require2.ID_KEY;
	var areEqual = require_areEqual();
	var invariant = require_invariant();
	require_warning();
	function getSingularSelector(fragment, item) {
		!(typeof item === "object" && item !== null && !Array.isArray(item)) && invariant(false);
		var dataID = item[ID_KEY];
		var fragments = item[FRAGMENTS_KEY];
		var mixedOwner = item[FRAGMENT_OWNER_KEY];
		var mixedClientEdgeTraversalPath = item[CLIENT_EDGE_TRAVERSAL_PATH];
		if (typeof dataID === "string" && typeof fragments === "object" && fragments !== null && typeof fragments[fragment.name] === "object" && fragments[fragment.name] !== null && typeof mixedOwner === "object" && mixedOwner !== null && (mixedClientEdgeTraversalPath == null || Array.isArray(mixedClientEdgeTraversalPath))) {
			var owner = mixedOwner;
			var clientEdgeTraversalPath = mixedClientEdgeTraversalPath;
			var argumentVariables = fragments[fragment.name];
			return createReaderSelector(fragment, dataID, getFragmentVariables(fragment, owner.variables, argumentVariables), owner, argumentVariables[FRAGMENT_POINTER_IS_WITHIN_UNMATCHED_TYPE_REFINEMENT] === true, clientEdgeTraversalPath);
		}
		return null;
	}
	function getPluralSelector(fragment, items) {
		var selectors = null;
		items.forEach(function(item, ii) {
			var selector = item != null ? getSingularSelector(fragment, item) : null;
			if (selector != null) {
				selectors = selectors || [];
				selectors.push(selector);
			}
		});
		if (selectors == null) return null;
		else return {
			kind: "PluralReaderSelector",
			selectors
		};
	}
	function getSelector(fragment, item) {
		if (item == null) return item;
		else if (fragment.metadata && fragment.metadata.plural === true) {
			!Array.isArray(item) && invariant(false);
			return getPluralSelector(fragment, item);
		} else {
			Array.isArray(item) && invariant(false);
			return getSingularSelector(fragment, item);
		}
	}
	function getSelectorsFromObject(fragments, object) {
		var selectors = {};
		for (var key in fragments) if (fragments.hasOwnProperty(key)) {
			var fragment = fragments[key];
			var item = object[key];
			selectors[key] = getSelector(fragment, item);
		}
		return selectors;
	}
	function getDataIDsFromObject(fragments, object) {
		var ids = {};
		for (var key in fragments) if (fragments.hasOwnProperty(key)) {
			var fragment = fragments[key];
			var item = object[key];
			ids[key] = getDataIDsFromFragment(fragment, item);
		}
		return ids;
	}
	function getDataIDsFromFragment(fragment, item) {
		if (item == null) return item;
		else if (fragment.metadata && fragment.metadata.plural === true) {
			!Array.isArray(item) && invariant(false);
			return getDataIDs(fragment, item);
		} else {
			Array.isArray(item) && invariant(false);
			return getDataID(fragment, item);
		}
	}
	function getDataIDs(fragment, items) {
		var ids = null;
		items.forEach(function(item) {
			var id = item != null ? getDataID(fragment, item) : null;
			if (id != null) {
				ids = ids || [];
				ids.push(id);
			}
		});
		return ids;
	}
	function getDataID(fragment, item) {
		!(typeof item === "object" && item !== null && !Array.isArray(item)) && invariant(false);
		var dataID = item[ID_KEY];
		if (typeof dataID === "string") return dataID;
		return null;
	}
	function getVariablesFromObject(fragments, object) {
		var variables = {};
		for (var key in fragments) if (fragments.hasOwnProperty(key)) {
			var fragment = fragments[key];
			var item = object[key];
			var itemVariables = getVariablesFromFragment(fragment, item);
			Object.assign(variables, itemVariables);
		}
		return variables;
	}
	function getVariablesFromFragment(fragment, item) {
		var _fragment$metadata;
		if (item == null) return {};
		else if (((_fragment$metadata = fragment.metadata) === null || _fragment$metadata === void 0 ? void 0 : _fragment$metadata.plural) === true) {
			!Array.isArray(item) && invariant(false);
			return getVariablesFromPluralFragment(fragment, item);
		} else {
			Array.isArray(item) && invariant(false);
			return getVariablesFromSingularFragment(fragment, item) || {};
		}
	}
	function getVariablesFromSingularFragment(fragment, item) {
		var selector = getSingularSelector(fragment, item);
		if (!selector) return null;
		return selector.variables;
	}
	function getVariablesFromPluralFragment(fragment, items) {
		var variables = {};
		items.forEach(function(value, ii) {
			if (value != null) {
				var itemVariables = getVariablesFromSingularFragment(fragment, value);
				if (itemVariables != null) Object.assign(variables, itemVariables);
			}
		});
		return variables;
	}
	function areEqualSingularSelectors(thisSelector, thatSelector) {
		return thisSelector.dataID === thatSelector.dataID && thisSelector.node === thatSelector.node && areEqual(thisSelector.variables, thatSelector.variables) && areEqualOwners(thisSelector.owner, thatSelector.owner) && thisSelector.isWithinUnmatchedTypeRefinement === thatSelector.isWithinUnmatchedTypeRefinement && areEqualClientEdgeTraversalPaths(thisSelector.clientEdgeTraversalPath, thatSelector.clientEdgeTraversalPath);
	}
	function areEqualOwners(thisOwner, thatOwner) {
		if (thisOwner === thatOwner) return true;
		else return thisOwner.identifier === thatOwner.identifier && areEqual(thisOwner.cacheConfig, thatOwner.cacheConfig);
	}
	function areEqualClientEdgeTraversalPaths(thisPath, thatPath) {
		if (thisPath === thatPath) return true;
		if (thisPath == null || thatPath == null || thisPath.length !== thatPath.length) return false;
		var idx = thisPath.length;
		while (idx--) {
			var a = thisPath[idx];
			var b = thatPath[idx];
			if (a === b) continue;
			if (a == null || b == null || a.clientEdgeDestinationID !== b.clientEdgeDestinationID || a.readerClientEdge !== b.readerClientEdge) return false;
		}
		return true;
	}
	function areEqualSelectors(a, b) {
		if (a === b) return true;
		else if (a == null) return b == null;
		else if (b == null) return a == null;
		else if (a.kind === "SingularReaderSelector" && b.kind === "SingularReaderSelector") return areEqualSingularSelectors(a, b);
		else if (a.kind === "PluralReaderSelector" && b.kind === "PluralReaderSelector") return a.selectors.length === b.selectors.length && a.selectors.every(function(s, i) {
			return areEqualSingularSelectors(s, b.selectors[i]);
		});
		else return false;
	}
	function createReaderSelector(fragment, dataID, variables, request) {
		var isWithinUnmatchedTypeRefinement = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : false;
		var clientEdgeTraversalPath = arguments.length > 5 ? arguments[5] : void 0;
		return {
			kind: "SingularReaderSelector",
			dataID,
			isWithinUnmatchedTypeRefinement,
			clientEdgeTraversalPath: clientEdgeTraversalPath !== null && clientEdgeTraversalPath !== void 0 ? clientEdgeTraversalPath : null,
			node: fragment,
			variables,
			owner: request
		};
	}
	function createNormalizationSelector(node, dataID, variables) {
		return {
			dataID,
			node,
			variables
		};
	}
	module.exports = {
		areEqualSelectors,
		createReaderSelector,
		createNormalizationSelector,
		getDataIDsFromFragment,
		getDataIDsFromObject,
		getSingularSelector,
		getPluralSelector,
		getSelector,
		getSelectorsFromObject,
		getVariablesFromSingularFragment,
		getVariablesFromPluralFragment,
		getVariablesFromFragment,
		getVariablesFromObject
	};
}));
var require_ResolverFragments = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getFragment = require_GraphQLTag().getFragment;
	var eventShouldThrow = require_handlePotentialSnapshotErrors().eventShouldThrow;
	var getSelector = require_RelayModernSelector().getSelector;
	var invariant = require_invariant();
	var contextStack = [];
	function withResolverContext(context, cb) {
		contextStack.push(context);
		try {
			return cb();
		} finally {
			contextStack.pop();
		}
	}
	function readFragment(fragmentInput, fragmentKey) {
		if (!contextStack.length) throw new Error("readFragment should be called only from within a Relay Resolver function.");
		var context = contextStack[contextStack.length - 1];
		var fragmentSelector = getSelector(getFragment(fragmentInput), fragmentKey);
		!(fragmentSelector != null) && invariant(false);
		!(fragmentSelector.kind === "SingularReaderSelector") && invariant(false);
		var _context$getDataForRe = context.getDataForResolverFragment(fragmentSelector, fragmentKey), data = _context$getDataForRe.data, isMissingData = _context$getDataForRe.isMissingData, fieldErrors = _context$getDataForRe.fieldErrors;
		if (isMissingData || fieldErrors != null && fieldErrors.some(eventShouldThrow)) throw RESOLVER_FRAGMENT_ERRORED_SENTINEL;
		return data;
	}
	var RESOLVER_FRAGMENT_ERRORED_SENTINEL = {};
	module.exports = {
		readFragment,
		withResolverContext,
		RESOLVER_FRAGMENT_ERRORED_SENTINEL
	};
}));
var require_resolverDataInjector = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var readFragment = require_ResolverFragments().readFragment;
	var invariant = require_invariant();
	function resolverDataInjector(fragment, _resolverFn, fieldName, isRequiredField) {
		var resolverFn = _resolverFn;
		return function(fragmentKey, args, resolverContext) {
			var data = readFragment(fragment, fragmentKey);
			if (fieldName != null) {
				if (data == null) if (isRequiredField === true) invariant(false);
				else return resolverFn(null, args, resolverContext);
				if (fieldName in data) {
					if (isRequiredField === true) !(data[fieldName] != null) && invariant(false);
					return resolverFn(data[fieldName], args, resolverContext);
				} else invariant(false);
			} else return resolverFn(null, args, resolverContext);
		};
	}
	module.exports = resolverDataInjector;
}));
var require_asyncToGenerator = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function asyncGeneratorStep(n, t, e, r, o, a, c) {
		try {
			var i = n[a](c), u = i.value;
		} catch (n) {
			e(n);
			return;
		}
		i.done ? t(u) : Promise.resolve(u).then(r, o);
	}
	function _asyncToGenerator(n) {
		return function() {
			var t = this, e = arguments;
			return new Promise(function(r, o) {
				var a = n.apply(t, e);
				function _next(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
				}
				function _throw(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
				}
				_next(void 0);
			});
		};
	}
	module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_isPromise = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function isPromise(p) {
		return p != null && typeof p === "object" && typeof p.then === "function";
	}
	module.exports = isPromise;
}));
var require_RelayObservable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var isPromise = require_isPromise();
	var hostReportError = swallowError;
	var RelayObservable = /* @__PURE__ */ function() {
		RelayObservable.create = function create(source) {
			return new RelayObservable(source);
		};
		function RelayObservable(source) {
			this._source = source;
		}
		RelayObservable.onUnhandledError = function onUnhandledError(callback) {
			hostReportError = callback;
		};
		RelayObservable.from = function from(obj) {
			return isObservable(obj) ? fromObservable(obj) : isPromise(obj) ? fromPromise(obj) : fromValue(obj);
		};
		var _proto = RelayObservable.prototype;
		_proto["catch"] = function _catch(fn) {
			var _this = this;
			return RelayObservable.create(function(sink) {
				var subscription;
				_this.subscribe({
					start: function start(sub) {
						subscription = sub;
					},
					next: sink.next,
					complete: sink.complete,
					error: function error(_error2) {
						try {
							fn(_error2).subscribe({
								start: function start(sub) {
									subscription = sub;
								},
								next: sink.next,
								complete: sink.complete,
								error: sink.error
							});
						} catch (error2) {
							sink.error(error2, true);
						}
					}
				});
				return function() {
					return subscription.unsubscribe();
				};
			});
		};
		_proto.concat = function concat(next) {
			var _this2 = this;
			return RelayObservable.create(function(sink) {
				var current;
				_this2.subscribe({
					start: function start(subscription) {
						current = subscription;
					},
					next: sink.next,
					error: sink.error,
					complete: function complete() {
						current = next.subscribe(sink);
					}
				});
				return function() {
					current && current.unsubscribe();
				};
			});
		};
		_proto["do"] = function _do(observer) {
			var _this3 = this;
			return RelayObservable.create(function(sink) {
				var both = function both(action) {
					return function() {
						try {
							observer[action] && observer[action].apply(observer, arguments);
						} catch (error) {
							hostReportError(error, true);
						}
						sink[action] && sink[action].apply(sink, arguments);
					};
				};
				return _this3.subscribe({
					start: both("start"),
					next: both("next"),
					error: both("error"),
					complete: both("complete"),
					unsubscribe: both("unsubscribe")
				});
			});
		};
		_proto["finally"] = function _finally(fn) {
			var _this4 = this;
			return RelayObservable.create(function(sink) {
				var subscription = _this4.subscribe(sink);
				return function() {
					subscription.unsubscribe();
					fn();
				};
			});
		};
		_proto.ifEmpty = function ifEmpty(alternate) {
			var _this5 = this;
			return RelayObservable.create(function(sink) {
				var hasValue = false;
				var current = _this5.subscribe({
					next: function next(value) {
						hasValue = true;
						sink.next(value);
					},
					error: sink.error,
					complete: function complete() {
						if (hasValue) sink.complete();
						else current = alternate.subscribe(sink);
					}
				});
				return function() {
					current && current.unsubscribe();
				};
			});
		};
		_proto.subscribe = function subscribe(observer) {
			return _subscribe(this._source, observer);
		};
		_proto.map = function map(fn) {
			var _this6 = this;
			return RelayObservable.create(function(sink) {
				var subscription = _this6.subscribe({
					complete: sink.complete,
					error: sink.error,
					next: function next(value) {
						try {
							var mapValue = fn(value);
							sink.next(mapValue);
						} catch (error) {
							sink.error(error, true);
						}
					}
				});
				return function() {
					subscription.unsubscribe();
				};
			});
		};
		_proto.mergeMap = function mergeMap(fn) {
			var _this7 = this;
			return RelayObservable.create(function(sink) {
				var subscriptions = [];
				function start(subscription) {
					this._sub = subscription;
					subscriptions.push(subscription);
				}
				function complete() {
					subscriptions.splice(subscriptions.indexOf(this._sub), 1);
					if (subscriptions.length === 0) sink.complete();
				}
				_this7.subscribe({
					start,
					next: function next(value) {
						try {
							if (!sink.closed) RelayObservable.from(fn(value)).subscribe({
								start,
								next: sink.next,
								error: sink.error,
								complete
							});
						} catch (error) {
							sink.error(error, true);
						}
					},
					error: sink.error,
					complete
				});
				return function() {
					subscriptions.forEach(function(sub) {
						return sub.unsubscribe();
					});
					subscriptions.length = 0;
				};
			});
		};
		_proto.poll = function poll(pollInterval) {
			var _this8 = this;
			return RelayObservable.create(function(sink) {
				var subscription;
				var timeout;
				(function poll() {
					subscription = _this8.subscribe({
						next: sink.next,
						error: sink.error,
						complete: function complete() {
							timeout = setTimeout(poll, pollInterval);
						}
					});
				})();
				return function() {
					clearTimeout(timeout);
					subscription.unsubscribe();
				};
			});
		};
		_proto.toPromise = function toPromise() {
			var _this9 = this;
			return new Promise(function(resolve, reject) {
				var resolved = false;
				_this9.subscribe({
					next: function next(val) {
						if (!resolved) {
							resolved = true;
							resolve(val);
						}
					},
					error: reject,
					complete: resolve
				});
			});
		};
		return RelayObservable;
	}();
	function isObservable(obj) {
		return typeof obj === "object" && obj !== null && typeof obj.subscribe === "function";
	}
	function fromObservable(obj) {
		return obj instanceof RelayObservable ? obj : RelayObservable.create(function(sink) {
			return obj.subscribe(sink);
		});
	}
	function fromPromise(promise) {
		return RelayObservable.create(function(sink) {
			promise.then(function(value) {
				sink.next(value);
				sink.complete();
			}, sink.error);
		});
	}
	function fromValue(value) {
		return RelayObservable.create(function(sink) {
			sink.next(value);
			sink.complete();
		});
	}
	function _subscribe(source, observer) {
		var closed = false;
		var cleanup;
		var withClosed = function withClosed(obj) {
			return Object.defineProperty(obj, "closed", { get: function get() {
				return closed;
			} });
		};
		function doCleanup() {
			if (cleanup) {
				if (cleanup.unsubscribe) cleanup.unsubscribe();
				else try {
					cleanup();
				} catch (error) {
					hostReportError(error, true);
				}
				cleanup = void 0;
			}
		}
		var subscription = withClosed({ unsubscribe: function unsubscribe() {
			if (!closed) {
				closed = true;
				try {
					observer.unsubscribe && observer.unsubscribe(subscription);
				} catch (error) {
					hostReportError(error, true);
				} finally {
					doCleanup();
				}
			}
		} });
		try {
			observer.start && observer.start(subscription);
		} catch (error) {
			hostReportError(error, true);
		}
		if (closed) return subscription;
		var sink = withClosed({
			next: function next(value) {
				if (!closed && observer.next) try {
					observer.next(value);
				} catch (error) {
					hostReportError(error, true);
				}
			},
			error: function error(_error3, isUncaughtThrownError) {
				if (closed || !observer.error) {
					closed = true;
					hostReportError(_error3, isUncaughtThrownError || false);
					doCleanup();
				} else {
					closed = true;
					try {
						observer.error(_error3);
					} catch (error2) {
						hostReportError(error2, true);
					} finally {
						doCleanup();
					}
				}
			},
			complete: function complete() {
				if (!closed) {
					closed = true;
					try {
						observer.complete && observer.complete();
					} catch (error) {
						hostReportError(error, true);
					} finally {
						doCleanup();
					}
				}
			}
		});
		try {
			cleanup = source(sink);
		} catch (error) {
			sink.error(error, true);
		}
		if (closed) doCleanup();
		return subscription;
	}
	function swallowError(_error, _isUncaughtThrownError) {}
	module.exports = RelayObservable;
}));
var require_RelayReplaySubject = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var RelayObservable = require_RelayObservable();
	var invariant = require_invariant();
	module.exports = /* @__PURE__ */ function() {
		function RelayReplaySubject() {
			var _this = this;
			(0, _defineProperty2["default"])(this, "_complete", false);
			(0, _defineProperty2["default"])(this, "_events", []);
			(0, _defineProperty2["default"])(this, "_sinks", /* @__PURE__ */ new Set());
			(0, _defineProperty2["default"])(this, "_subscription", []);
			this._observable = RelayObservable.create(function(sink) {
				_this._sinks.add(sink);
				var events = _this._events;
				for (var i = 0; i < events.length; i++) {
					if (sink.closed) break;
					var event = events[i];
					switch (event.kind) {
						case "complete":
							sink.complete();
							break;
						case "error":
							sink.error(event.error);
							break;
						case "next":
							sink.next(event.data);
							break;
						default:
							event.kind;
							invariant(false);
					}
				}
				return function() {
					_this._sinks["delete"](sink);
				};
			});
		}
		var _proto = RelayReplaySubject.prototype;
		_proto.complete = function complete() {
			if (this._complete === true) return;
			this._complete = true;
			this._events.push({ kind: "complete" });
			this._sinks.forEach(function(sink) {
				return sink.complete();
			});
		};
		_proto.error = function error(_error) {
			if (this._complete === true) return;
			this._complete = true;
			this._events.push({
				kind: "error",
				error: _error
			});
			this._sinks.forEach(function(sink) {
				return sink.error(_error);
			});
		};
		_proto.next = function next(data) {
			if (this._complete === true) return;
			this._events.push({
				kind: "next",
				data
			});
			this._sinks.forEach(function(sink) {
				return sink.next(data);
			});
		};
		_proto.subscribe = function subscribe(observer) {
			var subscription = this._observable.subscribe(observer);
			this._subscription.push(subscription);
			return subscription;
		};
		_proto.unsubscribe = function unsubscribe() {
			var _iterator = (0, _createForOfIteratorHelper2["default"])(this._subscription), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) _step.value.unsubscribe();
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			this._subscription = [];
		};
		_proto.getObserverCount = function getObserverCount() {
			return this._sinks.size;
		};
		return RelayReplaySubject;
	}();
}));
var require_fetchQueryInternal = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Observable = require_RelayObservable();
	var RelayReplaySubject = require_RelayReplaySubject();
	var invariant = require_invariant();
	var requestCachesByEnvironment = typeof WeakMap === "function" ? /* @__PURE__ */ new WeakMap() : /* @__PURE__ */ new Map();
	function fetchQuery(environment, operation) {
		return fetchQueryDeduped(environment, operation.request.identifier, function() {
			return environment.execute({ operation });
		});
	}
	function fetchQueryDeduped(environment, identifier, fetchFn) {
		return Observable.create(function(sink) {
			var requestCache = getRequestCache(environment);
			var cachedRequest = requestCache.get(identifier);
			if (!cachedRequest) fetchFn()["finally"](function() {
				return requestCache["delete"](identifier);
			}).subscribe({
				start: function start(subscription) {
					cachedRequest = {
						identifier,
						subject: new RelayReplaySubject(),
						subjectForInFlightStatus: new RelayReplaySubject(),
						subscription,
						promise: null
					};
					requestCache.set(identifier, cachedRequest);
				},
				next: function next(response) {
					var cachedReq = getCachedRequest(requestCache, identifier);
					cachedReq.subject.next(response);
					cachedReq.subjectForInFlightStatus.next(response);
				},
				error: function error(_error) {
					var cachedReq = getCachedRequest(requestCache, identifier);
					cachedReq.subject.error(_error);
					cachedReq.subjectForInFlightStatus.error(_error);
				},
				complete: function complete() {
					var cachedReq = getCachedRequest(requestCache, identifier);
					cachedReq.subject.complete();
					cachedReq.subjectForInFlightStatus.complete();
				},
				unsubscribe: function unsubscribe(subscription) {
					var cachedReq = getCachedRequest(requestCache, identifier);
					cachedReq.subject.unsubscribe();
					cachedReq.subjectForInFlightStatus.unsubscribe();
				}
			});
			!(cachedRequest != null) && invariant(false);
			return getObservableForCachedRequest(requestCache, cachedRequest).subscribe(sink);
		});
	}
	function getObservableForCachedRequest(requestCache, cachedRequest) {
		return Observable.create(function(sink) {
			var subscription = cachedRequest.subject.subscribe(sink);
			return function() {
				subscription.unsubscribe();
				var cachedRequestInstance = requestCache.get(cachedRequest.identifier);
				if (cachedRequestInstance) {
					var requestSubscription = cachedRequestInstance.subscription;
					if (requestSubscription != null && cachedRequestInstance.subject.getObserverCount() === 0) {
						requestSubscription.unsubscribe();
						requestCache["delete"](cachedRequest.identifier);
					}
				}
			};
		});
	}
	function getActiveStatusObservableForCachedRequest(environment, requestCache, cachedRequest) {
		return Observable.create(function(sink) {
			var subscription = cachedRequest.subjectForInFlightStatus.subscribe({
				error: sink.error,
				next: function next(response) {
					if (!environment.isRequestActive(cachedRequest.identifier)) {
						sink.complete();
						return;
					}
					sink.next();
				},
				complete: sink.complete,
				unsubscribe: sink.complete
			});
			return function() {
				subscription.unsubscribe();
			};
		});
	}
	function getPromiseForActiveRequest(environment, request) {
		var requestCache = getRequestCache(environment);
		var cachedRequest = requestCache.get(request.identifier);
		if (!cachedRequest) return null;
		if (!environment.isRequestActive(cachedRequest.identifier)) return null;
		return new Promise(function(resolve, reject) {
			var resolveOnNext = false;
			getActiveStatusObservableForCachedRequest(environment, requestCache, cachedRequest).subscribe({
				complete: resolve,
				error: reject,
				next: function next(response) {
					if (resolveOnNext) resolve(response);
				}
			});
			resolveOnNext = true;
		});
	}
	function getObservableForActiveRequest(environment, request) {
		var requestCache = getRequestCache(environment);
		var cachedRequest = requestCache.get(request.identifier);
		if (!cachedRequest) return null;
		if (!environment.isRequestActive(cachedRequest.identifier)) return null;
		return getActiveStatusObservableForCachedRequest(environment, requestCache, cachedRequest);
	}
	function getRequestCache(environment) {
		var cached = requestCachesByEnvironment.get(environment);
		if (cached != null) return cached;
		var requestCache = /* @__PURE__ */ new Map();
		requestCachesByEnvironment.set(environment, requestCache);
		return requestCache;
	}
	function getCachedRequest(requestCache, identifier) {
		var cached = requestCache.get(identifier);
		!(cached != null) && invariant(false);
		return cached;
	}
	module.exports = {
		fetchQuery,
		fetchQueryDeduped,
		getPromiseForActiveRequest,
		getObservableForActiveRequest
	};
}));
var require_observeFragmentExperimental = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _asyncToGenerator = require_asyncToGenerator().default;
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var Observable = require_RelayObservable();
	var getObservableForActiveRequest = require_fetchQueryInternal().getObservableForActiveRequest;
	var getFragment = require_GraphQLTag().getFragment;
	var handlePotentialSnapshotErrors = require_handlePotentialSnapshotErrors().handlePotentialSnapshotErrors;
	var getSelector = require_RelayModernSelector().getSelector;
	var invariant = require_invariant();
	function waitForFragmentData(_x, _x2, _x3) {
		return _waitForFragmentData.apply(this, arguments);
	}
	function _waitForFragmentData() {
		_waitForFragmentData = _asyncToGenerator(function* (environment, fragment, fragmentRef) {
			var subscription;
			try {
				var _subscription;
				var data = yield new Promise(function(resolve, reject) {
					subscription = observeFragment(environment, fragment, fragmentRef).subscribe({ next: function next(val) {
						if (val.state === "ok") resolve(val.value);
						else if (val.state === "error") reject(val.error);
					} });
				});
				(_subscription = subscription) === null || _subscription === void 0 || _subscription.unsubscribe();
				return data;
			} catch (e) {
				var _subscription2;
				(_subscription2 = subscription) === null || _subscription2 === void 0 || _subscription2.unsubscribe();
				throw e;
			}
		});
		return _waitForFragmentData.apply(this, arguments);
	}
	function observeFragment(environment, fragment, fragmentRef) {
		var _fragmentNode$metadat;
		var fragmentNode = getFragment(fragment);
		var fragmentSelector = getSelector(fragmentNode, fragmentRef);
		!(((_fragmentNode$metadat = fragmentNode.metadata) === null || _fragmentNode$metadat === void 0 ? void 0 : _fragmentNode$metadat.hasClientEdges) == null) && invariant(false);
		!(fragmentSelector != null) && invariant(false);
		switch (fragmentSelector.kind) {
			case "SingularReaderSelector": return observeSingularSelector(environment, fragment, fragmentSelector);
			case "PluralReaderSelector": return observePluralSelector(environment, fragment, fragmentSelector);
		}
		invariant(false);
	}
	function observeSingularSelector(environment, fragmentNode, fragmentSelector) {
		var snapshot = environment.lookup(fragmentSelector);
		return Observable.create(function(sink) {
			sink.next(snapshotToFragmentState(environment, fragmentNode, fragmentSelector.owner, snapshot));
			var subscription = environment.subscribe(snapshot, function(nextSnapshot) {
				sink.next(snapshotToFragmentState(environment, fragmentNode, fragmentSelector.owner, nextSnapshot));
			});
			return function() {
				return subscription.dispose();
			};
		});
	}
	function observePluralSelector(environment, fragmentNode, fragmentSelector) {
		var snapshots = fragmentSelector.selectors.map(function(selector) {
			return environment.lookup(selector);
		});
		return Observable.create(function(sink) {
			var states = snapshots.map(function(snapshot, index) {
				return snapshotToFragmentState(environment, fragmentNode, fragmentSelector.selectors[index].owner, snapshot);
			});
			sink.next(mergeFragmentStates(states));
			var subscriptions = snapshots.map(function(snapshot, index) {
				return environment.subscribe(snapshot, function(latestSnapshot) {
					states[index] = snapshotToFragmentState(environment, fragmentNode, fragmentSelector.selectors[index].owner, latestSnapshot);
					sink.next(mergeFragmentStates(states));
				});
			});
			return function() {
				return subscriptions.forEach(function(subscription) {
					return subscription.dispose();
				});
			};
		});
	}
	function snapshotToFragmentState(environment, fragmentNode, owner, snapshot) {
		var missingLiveResolverFields = snapshot.missingLiveResolverFields != null && snapshot.missingLiveResolverFields.length > 0;
		var missingClientEdges = snapshot.missingClientEdges != null && snapshot.missingClientEdges.length > 0;
		if (missingLiveResolverFields || missingClientEdges) return { state: "loading" };
		if (snapshot.isMissingData) {
			if (getObservableForActiveRequest(environment, owner) != null || environment.getOperationTracker().getPendingOperationsAffectingOwner(owner) != null) return { state: "loading" };
		}
		try {
			handlePotentialSnapshotErrors(environment, snapshot.fieldErrors);
		} catch (error) {
			return {
				error,
				state: "error"
			};
		}
		!(snapshot.data != null) && invariant(false);
		return {
			state: "ok",
			value: snapshot.data
		};
	}
	function mergeFragmentStates(states) {
		var value = [];
		var _iterator = (0, _createForOfIteratorHelper2["default"])(states), _step;
		try {
			for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var state = _step.value;
				if (state.state === "ok") value.push(state.value);
				else return state;
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
		return {
			state: "ok",
			value
		};
	}
	module.exports = {
		observeFragment,
		waitForFragmentData
	};
}));
var require_deepFreeze = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function deepFreeze(object) {
		if (!shouldBeFrozen(object)) return object;
		Object.freeze(object);
		Object.getOwnPropertyNames(object).forEach(function(name) {
			var property = object[name];
			if (property && typeof property === "object" && !Object.isFrozen(property)) deepFreeze(property);
		});
		return object;
	}
	function shouldBeFrozen(value) {
		return value != null && (Array.isArray(value) || typeof value === "object" && value.constructor === Object);
	}
	module.exports = deepFreeze;
}));
var require_getRequestIdentifier = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var stableCopy = require_stableCopy().stableCopy;
	var invariant = require_invariant();
	function getRequestIdentifier(parameters, variables) {
		var requestID = parameters.cacheID != null ? parameters.cacheID : parameters.id;
		!(requestID != null) && invariant(false);
		return requestID + JSON.stringify(stableCopy(variables));
	}
	module.exports = getRequestIdentifier;
}));
var require_RelayModernOperationDescriptor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	require_deepFreeze();
	var getRequestIdentifier = require_getRequestIdentifier();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var hasCycle = require_stableCopy().hasCycle;
	var getOperationVariables = require_RelayConcreteVariables().getOperationVariables;
	var _require3 = require_RelayModernSelector(), createNormalizationSelector = _require3.createNormalizationSelector, createReaderSelector = _require3.createReaderSelector;
	var ROOT_ID = require_RelayStoreUtils().ROOT_ID;
	var invariant = require_invariant();
	function createOperationDescriptor(request, variables, cacheConfig) {
		var dataID = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : ROOT_ID;
		var operation = request.operation;
		var operationVariables = getOperationVariables(operation, request.params.providedVariables, variables);
		if (RelayFeatureFlags.ENABLE_CYLE_DETECTION_IN_VARIABLES) hasCycle(operationVariables) && invariant(false);
		var requestDescriptor = createRequestDescriptor(request, operationVariables, cacheConfig);
		return {
			fragment: createReaderSelector(request.fragment, dataID, operationVariables, requestDescriptor),
			request: requestDescriptor,
			root: createNormalizationSelector(operation, dataID, operationVariables)
		};
	}
	function createRequestDescriptor(request, variables, cacheConfig) {
		return {
			identifier: getRequestIdentifier(request.params, variables),
			node: request,
			variables,
			cacheConfig
		};
	}
	module.exports = {
		createOperationDescriptor,
		createRequestDescriptor
	};
}));
var require_observeQueryExperimental = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var observeFragment = require_observeFragmentExperimental().observeFragment;
	var createOperationDescriptor = require_RelayModernOperationDescriptor().createOperationDescriptor;
	function observeQuery(environment, gqlQuery, variables) {
		var operation = createOperationDescriptor(gqlQuery, variables);
		var rootFragmentRef = {
			__id: operation.fragment.dataID,
			__fragments: (0, _defineProperty2["default"])({}, operation.fragment.node.name, operation.request.variables),
			__fragmentOwner: operation.request
		};
		var fragmentNode = operation.request.node.fragment;
		return observeFragment(environment, fragmentNode, rootFragmentRef);
	}
	module.exports = { observeQuery };
}));
var require_waitForFragmentExperimental = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _asyncToGenerator = require_asyncToGenerator().default;
	var observeFragment = require_observeFragmentExperimental().observeFragment;
	function waitForFragmentData(_x, _x2, _x3) {
		return _waitForFragmentData.apply(this, arguments);
	}
	function _waitForFragmentData() {
		_waitForFragmentData = _asyncToGenerator(function* (environment, fragment, fragmentRef) {
			var subscription;
			try {
				var _subscription;
				var data = yield new Promise(function(resolve, reject) {
					subscription = observeFragment(environment, fragment, fragmentRef).subscribe({ next: function next(val) {
						if (val.state === "ok") resolve(val.value);
						else if (val.state === "error") reject(val.error);
					} });
				});
				(_subscription = subscription) === null || _subscription === void 0 || _subscription.unsubscribe();
				return data;
			} catch (e) {
				var _subscription2;
				(_subscription2 = subscription) === null || _subscription2 === void 0 || _subscription2.unsubscribe();
				throw e;
			}
		});
		return _waitForFragmentData.apply(this, arguments);
	}
	module.exports = { waitForFragmentData };
}));
var require_experimental = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var resolverDataInjector = require_resolverDataInjector();
	var observeFragment = require_observeFragmentExperimental().observeFragment;
	var observeQuery = require_observeQueryExperimental().observeQuery;
	var waitForFragmentData = require_waitForFragmentExperimental().waitForFragmentData;
	function isValueResult(input) {
		return input.ok === true;
	}
	function isErrorResult(input) {
		return input.ok === false;
	}
	module.exports = {
		resolverDataInjector,
		isValueResult,
		isErrorResult,
		observeQuery,
		observeFragment,
		waitForFragmentData
	};
}));
var require_StringInterner = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var internTable = /* @__PURE__ */ new Map();
	var nextIndex = 1;
	var digits = initDigitTable();
	var INTERN_PREFIX = "	";
	var ESCAPE_PREFIX = "\v";
	function initDigitTable() {
		var digits = /* @__PURE__ */ new Set();
		for (var i = 0; i < 10; ++i) digits.add(i.toString());
		return digits;
	}
	function escape(str) {
		if (str[0] === INTERN_PREFIX && digits.has(str[1]) || str[0] === ESCAPE_PREFIX) return ESCAPE_PREFIX + str;
		return str;
	}
	function intern(str, limit) {
		if (limit == null || str.length < limit) return escape(str);
		var internedString = internTable.get(str);
		if (internedString != null) return internedString;
		internedString = INTERN_PREFIX + nextIndex++;
		internTable.set(str, internedString);
		return internedString;
	}
	module.exports = { intern };
}));
var require_ClientID = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var intern = require_StringInterner().intern;
	var PREFIX = "client:";
	function generateClientID(id, storageKey, index) {
		var key = (RelayFeatureFlags.STRING_INTERN_LEVEL <= 0 ? id : intern(id, RelayFeatureFlags.MAX_DATA_ID_LENGTH)) + ":" + storageKey;
		if (index != null) key += ":" + index;
		if (key.indexOf(PREFIX) !== 0) key = PREFIX + key;
		return key;
	}
	function isClientID(id) {
		return id.indexOf(PREFIX) === 0;
	}
	var localID = 0;
	function generateUniqueClientID() {
		return "".concat(PREFIX, "local:").concat(localID++);
	}
	function generateClientObjectClientID(typename, localId, index) {
		var key = "".concat(PREFIX).concat(typename, ":").concat(localId);
		if (index != null) key += ":" + index;
		return key;
	}
	module.exports = {
		generateClientID,
		generateClientObjectClientID,
		generateUniqueClientID,
		isClientID
	};
}));
var require_ConnectionInterface = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var CONNECTION_CALLS = {
		after: true,
		before: true,
		find: true,
		first: true,
		last: true,
		surrounds: true
	};
	var config = {
		CURSOR: "cursor",
		EDGES: "edges",
		END_CURSOR: "endCursor",
		HAS_NEXT_PAGE: "hasNextPage",
		HAS_PREV_PAGE: "hasPreviousPage",
		NODE: "node",
		PAGE_INFO_TYPE: "PageInfo",
		PAGE_INFO: "pageInfo",
		START_CURSOR: "startCursor"
	};
	module.exports = {
		inject: function inject(newConfig) {
			config = newConfig;
		},
		get: function get() {
			return config;
		},
		isConnectionCall: function isConnectionCall(call) {
			return CONNECTION_CALLS.hasOwnProperty(call.name);
		}
	};
}));
var require_ConnectionHandler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var generateClientID = require_ClientID().generateClientID;
	var getStableStorageKey = require_RelayStoreUtils().getStableStorageKey;
	var getRelayHandleKey = require_getRelayHandleKey();
	var ConnectionInterface = require_ConnectionInterface();
	var invariant = require_invariant();
	require_warning();
	var CONNECTION = "connection";
	var NEXT_EDGE_INDEX = "__connection_next_edge_index";
	function update(store, payload) {
		var record = store.get(payload.dataID);
		if (!record) return;
		var _ConnectionInterface$ = ConnectionInterface.get(), EDGES = _ConnectionInterface$.EDGES, END_CURSOR = _ConnectionInterface$.END_CURSOR, HAS_NEXT_PAGE = _ConnectionInterface$.HAS_NEXT_PAGE, HAS_PREV_PAGE = _ConnectionInterface$.HAS_PREV_PAGE, PAGE_INFO = _ConnectionInterface$.PAGE_INFO, PAGE_INFO_TYPE = _ConnectionInterface$.PAGE_INFO_TYPE, START_CURSOR = _ConnectionInterface$.START_CURSOR;
		var serverConnection = record.getLinkedRecord(payload.fieldKey);
		var serverPageInfo = serverConnection && serverConnection.getLinkedRecord(PAGE_INFO);
		if (!serverConnection) {
			record.setValue(null, payload.handleKey, void 0, record.getErrors(payload.fieldKey));
			return;
		}
		var clientConnectionID = generateClientID(record.getDataID(), payload.handleKey);
		var clientConnectionField = record.getLinkedRecord(payload.handleKey);
		var clientConnection = clientConnectionField !== null && clientConnectionField !== void 0 ? clientConnectionField : store.get(clientConnectionID);
		var clientPageInfo = clientConnection && clientConnection.getLinkedRecord(PAGE_INFO);
		if (!clientConnection) {
			var connection = store.create(clientConnectionID, serverConnection.getType());
			connection.setValue(0, NEXT_EDGE_INDEX);
			connection.copyFieldsFrom(serverConnection);
			var serverEdges = serverConnection.getLinkedRecords(EDGES);
			if (serverEdges) {
				serverEdges = serverEdges.map(function(edge) {
					return buildConnectionEdge(store, connection, edge);
				});
				connection.setLinkedRecords(serverEdges, EDGES);
			}
			record.setLinkedRecord(connection, payload.handleKey);
			clientPageInfo = store.create(generateClientID(connection.getDataID(), PAGE_INFO), PAGE_INFO_TYPE);
			clientPageInfo.setValue(false, HAS_NEXT_PAGE);
			clientPageInfo.setValue(false, HAS_PREV_PAGE);
			clientPageInfo.setValue(null, END_CURSOR);
			clientPageInfo.setValue(null, START_CURSOR);
			if (serverPageInfo) clientPageInfo.copyFieldsFrom(serverPageInfo);
			connection.setLinkedRecord(clientPageInfo, PAGE_INFO);
		} else {
			if (clientConnectionField == null) record.setLinkedRecord(clientConnection, payload.handleKey);
			var _connection = clientConnection;
			var _serverEdges = serverConnection.getLinkedRecords(EDGES);
			if (_serverEdges) _serverEdges = _serverEdges.map(function(edge) {
				return buildConnectionEdge(store, _connection, edge);
			});
			var prevEdges = _connection.getLinkedRecords(EDGES);
			var prevPageInfo = _connection.getLinkedRecord(PAGE_INFO);
			_connection.copyFieldsFrom(serverConnection);
			if (prevEdges) _connection.setLinkedRecords(prevEdges, EDGES);
			if (prevPageInfo) _connection.setLinkedRecord(prevPageInfo, PAGE_INFO);
			var nextEdges = [];
			var args = payload.args;
			if (prevEdges && _serverEdges) if (args.after != null) {
				var _clientPageInfo;
				var clientEndCursor = (_clientPageInfo = clientPageInfo) === null || _clientPageInfo === void 0 ? void 0 : _clientPageInfo.getValue(END_CURSOR);
				var serverEndCursor = serverPageInfo === null || serverPageInfo === void 0 ? void 0 : serverPageInfo.getValue(END_CURSOR);
				if (clientPageInfo && args.after === clientEndCursor || clientPageInfo && clientEndCursor === serverEndCursor) {
					var nodeIDs = /* @__PURE__ */ new Set();
					mergeEdges(prevEdges, nextEdges, nodeIDs);
					mergeEdges(_serverEdges, nextEdges, nodeIDs);
				} else return;
			} else if (args.before != null) if (clientPageInfo && args.before === clientPageInfo.getValue(START_CURSOR)) {
				var _nodeIDs = /* @__PURE__ */ new Set();
				mergeEdges(_serverEdges, nextEdges, _nodeIDs);
				mergeEdges(prevEdges, nextEdges, _nodeIDs);
			} else return;
			else nextEdges = _serverEdges;
			else if (_serverEdges) nextEdges = _serverEdges;
			else nextEdges = prevEdges;
			if (nextEdges != null && nextEdges !== prevEdges) _connection.setLinkedRecords(nextEdges, EDGES);
			if (clientPageInfo && serverPageInfo) {
				if (args.after == null && args.before == null) clientPageInfo.copyFieldsFrom(serverPageInfo);
				else if (args.before != null || args.after == null && args.last) {
					clientPageInfo.setValue(!!serverPageInfo.getValue(HAS_PREV_PAGE), HAS_PREV_PAGE);
					var startCursor = serverPageInfo.getValue(START_CURSOR);
					if (typeof startCursor === "string") clientPageInfo.setValue(startCursor, START_CURSOR);
				} else if (args.after != null || args.before == null && args.first) {
					clientPageInfo.setValue(!!serverPageInfo.getValue(HAS_NEXT_PAGE), HAS_NEXT_PAGE);
					var endCursor = serverPageInfo.getValue(END_CURSOR);
					if (typeof endCursor === "string") clientPageInfo.setValue(endCursor, END_CURSOR);
				}
			}
		}
	}
	function getConnection(record, key, filters) {
		var handleKey = getRelayHandleKey(CONNECTION, key, null);
		return record.getLinkedRecord(handleKey, filters);
	}
	function getConnectionID(recordID, key, filters) {
		return generateClientID(recordID, getStableStorageKey(getRelayHandleKey(CONNECTION, key, null), filters));
	}
	function insertEdgeAfter(record, newEdge, cursor) {
		var _ConnectionInterface$2 = ConnectionInterface.get(), CURSOR = _ConnectionInterface$2.CURSOR, EDGES = _ConnectionInterface$2.EDGES;
		var edges = record.getLinkedRecords(EDGES);
		if (!edges) {
			record.setLinkedRecords([newEdge], EDGES);
			return;
		}
		var nextEdges;
		if (cursor == null) nextEdges = edges.concat(newEdge);
		else {
			nextEdges = [];
			var foundCursor = false;
			for (var ii = 0; ii < edges.length; ii++) {
				var edge = edges[ii];
				nextEdges.push(edge);
				if (edge == null) continue;
				if (cursor === edge.getValue(CURSOR)) {
					nextEdges.push(newEdge);
					foundCursor = true;
				}
			}
			if (!foundCursor) nextEdges.push(newEdge);
		}
		record.setLinkedRecords(nextEdges, EDGES);
	}
	function createEdge(store, record, node, edgeType) {
		var NODE = ConnectionInterface.get().NODE;
		var edgeID = generateClientID(record.getDataID(), node.getDataID());
		var edge = store.get(edgeID);
		if (!edge) edge = store.create(edgeID, edgeType);
		edge.setLinkedRecord(node, NODE);
		if (edge.getValue("cursor") == null) edge.setValue(null, "cursor");
		return edge;
	}
	function insertEdgeBefore(record, newEdge, cursor) {
		var _ConnectionInterface$4 = ConnectionInterface.get(), CURSOR = _ConnectionInterface$4.CURSOR, EDGES = _ConnectionInterface$4.EDGES;
		var edges = record.getLinkedRecords(EDGES);
		if (!edges) {
			record.setLinkedRecords([newEdge], EDGES);
			return;
		}
		var nextEdges;
		if (cursor == null) nextEdges = [newEdge].concat(edges);
		else {
			nextEdges = [];
			var foundCursor = false;
			for (var ii = 0; ii < edges.length; ii++) {
				var edge = edges[ii];
				if (edge != null) {
					if (cursor === edge.getValue(CURSOR)) {
						nextEdges.push(newEdge);
						foundCursor = true;
					}
				}
				nextEdges.push(edge);
			}
			if (!foundCursor) nextEdges.unshift(newEdge);
		}
		record.setLinkedRecords(nextEdges, EDGES);
	}
	function deleteNode(record, nodeID) {
		var _ConnectionInterface$5 = ConnectionInterface.get(), EDGES = _ConnectionInterface$5.EDGES, NODE = _ConnectionInterface$5.NODE;
		var edges = record.getLinkedRecords(EDGES);
		if (!edges) return;
		var nextEdges;
		for (var ii = 0; ii < edges.length; ii++) {
			var edge = edges[ii];
			var node = edge && edge.getLinkedRecord(NODE);
			if (node != null && node.getDataID() === nodeID) {
				if (nextEdges === void 0) nextEdges = edges.slice(0, ii);
			} else if (nextEdges !== void 0) nextEdges.push(edge);
		}
		if (nextEdges !== void 0) record.setLinkedRecords(nextEdges, EDGES);
	}
	function buildConnectionEdge(store, connection, edge) {
		if (edge == null) return edge;
		var EDGES = ConnectionInterface.get().EDGES;
		var edgeIndex = connection.getValue(NEXT_EDGE_INDEX);
		!(typeof edgeIndex === "number") && invariant(false);
		var edgeID = generateClientID(connection.getDataID(), EDGES, edgeIndex);
		var connectionEdge = store.create(edgeID, edge.getType());
		connectionEdge.copyFieldsFrom(edge);
		if (connectionEdge.getValue("cursor") == null) connectionEdge.setValue(null, "cursor");
		connection.setValue(edgeIndex + 1, NEXT_EDGE_INDEX);
		return connectionEdge;
	}
	function mergeEdges(sourceEdges, targetEdges, nodeIDs) {
		var NODE = ConnectionInterface.get().NODE;
		for (var ii = 0; ii < sourceEdges.length; ii++) {
			var edge = sourceEdges[ii];
			if (!edge) continue;
			var node = edge.getLinkedRecord(NODE);
			var nodeID = node && node.getDataID();
			if (nodeID) {
				if (nodeIDs.has(nodeID)) continue;
				nodeIDs.add(nodeID);
			}
			targetEdges.push(edge);
		}
	}
	module.exports = {
		buildConnectionEdge,
		createEdge,
		deleteNode,
		getConnection,
		getConnectionID,
		insertEdgeAfter,
		insertEdgeBefore,
		update
	};
}));
var require_MutationHandlers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var ConnectionHandler = require_ConnectionHandler();
	var ConnectionInterface = require_ConnectionInterface();
	var invariant = require_invariant();
	require_warning();
	var DeleteRecordHandler = { update: function update(store, payload) {
		var record = store.get(payload.dataID);
		if (record != null) {
			var idOrIds = record.getValue(payload.fieldKey);
			if (typeof idOrIds === "string") store["delete"](idOrIds);
			else if (Array.isArray(idOrIds)) idOrIds.forEach(function(id) {
				if (typeof id === "string") store["delete"](id);
			});
		}
	} };
	var DeleteEdgeHandler = { update: function update(store, payload) {
		var record = store.get(payload.dataID);
		if (record == null) return;
		var connections = payload.handleArgs.connections;
		!(connections != null) && invariant(false);
		var idOrIds = record.getValue(payload.fieldKey);
		(Array.isArray(idOrIds) ? idOrIds : [idOrIds]).forEach(function(id) {
			if (typeof id === "string") {
				var _iterator = (0, _createForOfIteratorHelper2["default"])(connections), _step;
				try {
					for (_iterator.s(); !(_step = _iterator.n()).done;) {
						var connectionID = _step.value;
						var connection = store.get(connectionID);
						if (connection == null) continue;
						ConnectionHandler.deleteNode(connection, id);
					}
				} catch (err) {
					_iterator.e(err);
				} finally {
					_iterator.f();
				}
			}
		});
	} };
	var AppendEdgeHandler = { update: edgeUpdater(ConnectionHandler.insertEdgeAfter) };
	var PrependEdgeHandler = { update: edgeUpdater(ConnectionHandler.insertEdgeBefore) };
	var AppendNodeHandler = { update: nodeUpdater(ConnectionHandler.insertEdgeAfter) };
	var PrependNodeHandler = { update: nodeUpdater(ConnectionHandler.insertEdgeBefore) };
	function edgeUpdater(insertFn) {
		return function(store, payload) {
			var _serverEdges;
			var record = store.get(payload.dataID);
			if (record == null) return;
			var connections = payload.handleArgs.connections;
			!(connections != null) && invariant(false);
			var singleServerEdge, serverEdges;
			try {
				singleServerEdge = record.getLinkedRecord(payload.fieldKey);
			} catch (_unused) {}
			if (!singleServerEdge) try {
				serverEdges = record.getLinkedRecords(payload.fieldKey);
			} catch (_unused2) {}
			if (singleServerEdge == null && serverEdges == null) return;
			var _ConnectionInterface$ = ConnectionInterface.get(), NODE = _ConnectionInterface$.NODE, EDGES = _ConnectionInterface$.EDGES;
			var serverEdgeList = (_serverEdges = serverEdges) !== null && _serverEdges !== void 0 ? _serverEdges : [singleServerEdge];
			var _iterator2 = (0, _createForOfIteratorHelper2["default"])(serverEdgeList), _step2;
			try {
				var _loop = function _loop() {
					var serverEdge = _step2.value;
					if (serverEdge == null) return "continue";
					var serverNode = serverEdge.getLinkedRecord("node");
					if (!serverNode) return "continue";
					var serverNodeId = serverNode.getDataID();
					var _iterator3 = (0, _createForOfIteratorHelper2["default"])(connections), _step3;
					try {
						for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
							var connectionID = _step3.value;
							var connection = store.get(connectionID);
							if (connection == null) continue;
							if ((_connection$getLinked = connection.getLinkedRecords(EDGES)) === null || _connection$getLinked === void 0 ? void 0 : _connection$getLinked.some(function(edge) {
								var _edge$getLinkedRecord;
								return (edge === null || edge === void 0 ? void 0 : (_edge$getLinkedRecord = edge.getLinkedRecord(NODE)) === null || _edge$getLinkedRecord === void 0 ? void 0 : _edge$getLinkedRecord.getDataID()) === serverNodeId;
							})) continue;
							var clientEdge = ConnectionHandler.buildConnectionEdge(store, connection, serverEdge);
							!(clientEdge != null) && invariant(false);
							insertFn(connection, clientEdge);
						}
					} catch (err) {
						_iterator3.e(err);
					} finally {
						_iterator3.f();
					}
				};
				for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
					var _connection$getLinked;
					if (_loop() === "continue") continue;
				}
			} catch (err) {
				_iterator2.e(err);
			} finally {
				_iterator2.f();
			}
		};
	}
	function nodeUpdater(insertFn) {
		return function(store, payload) {
			var _serverNodes;
			var record = store.get(payload.dataID);
			if (record == null) return;
			var _payload$handleArgs = payload.handleArgs, connections = _payload$handleArgs.connections, edgeTypeName = _payload$handleArgs.edgeTypeName;
			!(connections != null) && invariant(false);
			!(edgeTypeName != null) && invariant(false);
			var singleServerNode;
			var serverNodes;
			try {
				singleServerNode = record.getLinkedRecord(payload.fieldKey);
			} catch (_unused3) {}
			if (!singleServerNode) try {
				serverNodes = record.getLinkedRecords(payload.fieldKey);
			} catch (_unused4) {}
			if (singleServerNode == null && serverNodes == null) return;
			var _ConnectionInterface$2 = ConnectionInterface.get(), NODE = _ConnectionInterface$2.NODE, EDGES = _ConnectionInterface$2.EDGES;
			var serverNodeList = (_serverNodes = serverNodes) !== null && _serverNodes !== void 0 ? _serverNodes : [singleServerNode];
			var _iterator4 = (0, _createForOfIteratorHelper2["default"])(serverNodeList), _step4;
			try {
				var _loop2 = function _loop2() {
					var serverNode = _step4.value;
					if (serverNode == null) return "continue";
					var serverNodeId = serverNode.getDataID();
					var _iterator5 = (0, _createForOfIteratorHelper2["default"])(connections), _step5;
					try {
						for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
							var connectionID = _step5.value;
							var connection = store.get(connectionID);
							if (connection == null) continue;
							if ((_connection$getLinked2 = connection.getLinkedRecords(EDGES)) === null || _connection$getLinked2 === void 0 ? void 0 : _connection$getLinked2.some(function(edge) {
								var _edge$getLinkedRecord2;
								return (edge === null || edge === void 0 ? void 0 : (_edge$getLinkedRecord2 = edge.getLinkedRecord(NODE)) === null || _edge$getLinkedRecord2 === void 0 ? void 0 : _edge$getLinkedRecord2.getDataID()) === serverNodeId;
							})) continue;
							var clientEdge = ConnectionHandler.createEdge(store, connection, serverNode, edgeTypeName);
							!(clientEdge != null) && invariant(false);
							insertFn(connection, clientEdge);
						}
					} catch (err) {
						_iterator5.e(err);
					} finally {
						_iterator5.f();
					}
				};
				for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
					var _connection$getLinked2;
					if (_loop2() === "continue") continue;
				}
			} catch (err) {
				_iterator4.e(err);
			} finally {
				_iterator4.f();
			}
		};
	}
	module.exports = {
		AppendEdgeHandler,
		DeleteRecordHandler,
		PrependEdgeHandler,
		AppendNodeHandler,
		PrependNodeHandler,
		DeleteEdgeHandler
	};
}));
var require_RelayDefaultHandlerProvider = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ConnectionHandler = require_ConnectionHandler();
	var MutationHandlers = require_MutationHandlers();
	var invariant = require_invariant();
	function RelayDefaultHandlerProvider(handle) {
		switch (handle) {
			case "connection": return ConnectionHandler;
			case "deleteRecord": return MutationHandlers.DeleteRecordHandler;
			case "deleteEdge": return MutationHandlers.DeleteEdgeHandler;
			case "appendEdge": return MutationHandlers.AppendEdgeHandler;
			case "prependEdge": return MutationHandlers.PrependEdgeHandler;
			case "appendNode": return MutationHandlers.AppendNodeHandler;
			case "prependNode": return MutationHandlers.PrependNodeHandler;
		}
		invariant(false);
	}
	module.exports = RelayDefaultHandlerProvider;
}));
var require_isRelayModernEnvironment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function isRelayModernEnvironment(environment) {
		return Boolean(environment && environment["@@RelayModernEnvironment"]);
	}
	module.exports = isRelayModernEnvironment;
}));
var require_RelayDeclarativeMutationConfig = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var ConnectionHandler = require_ConnectionHandler();
	require_warning();
	var MutationTypes = Object.freeze({
		RANGE_ADD: "RANGE_ADD",
		RANGE_DELETE: "RANGE_DELETE",
		NODE_DELETE: "NODE_DELETE"
	});
	var RangeOperations = Object.freeze({
		APPEND: "append",
		PREPEND: "prepend"
	});
	function convert(configs, request, optimisticUpdater, updater) {
		var configOptimisticUpdates = optimisticUpdater ? [optimisticUpdater] : [];
		var configUpdates = updater ? [updater] : [];
		configs.forEach(function(config) {
			switch (config.type) {
				case "NODE_DELETE":
					var nodeDeleteResult = nodeDelete(config, request);
					if (nodeDeleteResult) {
						configOptimisticUpdates.push(nodeDeleteResult);
						configUpdates.push(nodeDeleteResult);
					}
					break;
				case "RANGE_ADD":
					var rangeAddResult = rangeAdd(config, request);
					if (rangeAddResult) {
						configOptimisticUpdates.push(rangeAddResult);
						configUpdates.push(rangeAddResult);
					}
					break;
				case "RANGE_DELETE":
					var rangeDeleteResult = rangeDelete(config, request);
					if (rangeDeleteResult) {
						configOptimisticUpdates.push(rangeDeleteResult);
						configUpdates.push(rangeDeleteResult);
					}
					break;
			}
		});
		return {
			optimisticUpdater: function optimisticUpdater(store, data) {
				configOptimisticUpdates.forEach(function(eachOptimisticUpdater) {
					eachOptimisticUpdater(store, data);
				});
			},
			updater: function updater(store, data) {
				configUpdates.forEach(function(eachUpdater) {
					eachUpdater(store, data);
				});
			}
		};
	}
	function nodeDelete(config, request) {
		var deletedIDFieldName = config.deletedIDFieldName;
		var rootField = getRootField(request);
		if (!rootField) return null;
		return function(store, data) {
			var payload = store.getRootField(rootField);
			if (!payload) return;
			var deleteID = payload.getValue(deletedIDFieldName);
			(Array.isArray(deleteID) ? deleteID : [deleteID]).forEach(function(id) {
				if (id && typeof id === "string") store["delete"](id);
			});
		};
	}
	function rangeAdd(config, request) {
		var parentID = config.parentID, connectionInfo = config.connectionInfo, edgeName = config.edgeName;
		if (!parentID) return null;
		var rootField = getRootField(request);
		if (!connectionInfo || !rootField) return null;
		return function(store, data) {
			var parent = store.get(parentID);
			if (!parent) return;
			var payload = store.getRootField(rootField);
			if (!payload) return;
			var serverEdge = payload.getLinkedRecord(edgeName);
			var _iterator = (0, _createForOfIteratorHelper2["default"])(connectionInfo), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var info = _step.value;
					if (!serverEdge) continue;
					var connection = ConnectionHandler.getConnection(parent, info.key, info.filters);
					if (!connection) continue;
					var clientEdge = ConnectionHandler.buildConnectionEdge(store, connection, serverEdge);
					if (!clientEdge) continue;
					switch (info.rangeBehavior) {
						case "append":
							ConnectionHandler.insertEdgeAfter(connection, clientEdge);
							break;
						case "prepend":
							ConnectionHandler.insertEdgeBefore(connection, clientEdge);
							break;
						default: break;
					}
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
		};
	}
	function rangeDelete(config, request) {
		var parentID = config.parentID, connectionKeys = config.connectionKeys, pathToConnection = config.pathToConnection, deletedIDFieldName = config.deletedIDFieldName;
		if (!parentID) return null;
		var rootField = getRootField(request);
		if (!rootField) return null;
		return function(store, data) {
			if (!data) return;
			var deleteIDs = [];
			var deletedIDField = data[rootField];
			if (deletedIDField && Array.isArray(deletedIDFieldName)) {
				var _iterator2 = (0, _createForOfIteratorHelper2["default"])(deletedIDFieldName), _step2;
				try {
					for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
						var eachField = _step2.value;
						if (deletedIDField && typeof deletedIDField === "object") deletedIDField = deletedIDField[eachField];
					}
				} catch (err) {
					_iterator2.e(err);
				} finally {
					_iterator2.f();
				}
				if (Array.isArray(deletedIDField)) deletedIDField.forEach(function(idObject) {
					if (idObject && idObject.id && typeof idObject === "object" && typeof idObject.id === "string") deleteIDs.push(idObject.id);
				});
				else if (deletedIDField && deletedIDField.id && typeof deletedIDField.id === "string") deleteIDs.push(deletedIDField.id);
			} else if (deletedIDField && typeof deletedIDFieldName === "string" && typeof deletedIDField === "object") {
				deletedIDField = deletedIDField[deletedIDFieldName];
				if (typeof deletedIDField === "string") deleteIDs.push(deletedIDField);
				else if (Array.isArray(deletedIDField)) deletedIDField.forEach(function(id) {
					if (typeof id === "string") deleteIDs.push(id);
				});
			}
			deleteNode(parentID, connectionKeys, pathToConnection, store, deleteIDs);
		};
	}
	function deleteNode(parentID, connectionKeys, pathToConnection, store, deleteIDs) {
		var parent = store.get(parentID);
		if (!parent) return;
		if (pathToConnection.length < 2) return;
		var recordProxy = parent;
		for (var i = 1; i < pathToConnection.length - 1; i++) if (recordProxy) recordProxy = recordProxy.getLinkedRecord(pathToConnection[i]);
		if (!connectionKeys || !recordProxy) return;
		var _iterator3 = (0, _createForOfIteratorHelper2["default"])(connectionKeys), _step3;
		try {
			var _loop = function _loop() {
				var key = _step3.value;
				var connection = ConnectionHandler.getConnection(recordProxy, key.key, key.filters);
				if (connection) deleteIDs.forEach(function(deleteID) {
					ConnectionHandler.deleteNode(connection, deleteID);
				});
			};
			for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) _loop();
		} catch (err) {
			_iterator3.e(err);
		} finally {
			_iterator3.f();
		}
	}
	function getRootField(request) {
		if (request.fragment.selections && request.fragment.selections.length > 0 && request.fragment.selections[0].kind === "LinkedField") return request.fragment.selections[0].name;
		return null;
	}
	module.exports = {
		MutationTypes,
		RangeOperations,
		convert
	};
}));
var require_applyOptimisticMutation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getRequest = require_GraphQLTag().getRequest;
	var isRelayModernEnvironment = require_isRelayModernEnvironment();
	var createOperationDescriptor = require_RelayModernOperationDescriptor().createOperationDescriptor;
	var RelayDeclarativeMutationConfig = require_RelayDeclarativeMutationConfig();
	var invariant = require_invariant();
	function applyOptimisticMutation(environment, config) {
		!isRelayModernEnvironment(environment) && invariant(false);
		var mutation = getRequest(config.mutation);
		if (mutation.params.operationKind !== "mutation") throw new Error("commitMutation: Expected mutation operation");
		var optimisticUpdater = config.optimisticUpdater;
		var configs = config.configs, optimisticResponse = config.optimisticResponse, variables = config.variables;
		var operation = createOperationDescriptor(mutation, variables);
		if (configs) optimisticUpdater = RelayDeclarativeMutationConfig.convert(configs, mutation, optimisticUpdater).optimisticUpdater;
		return environment.applyMutation({
			operation,
			response: optimisticResponse,
			updater: optimisticUpdater
		});
	}
	module.exports = applyOptimisticMutation;
}));
var require_commitLocalUpdate = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function commitLocalUpdate(environment, updater) {
		environment.commitUpdate(updater);
	}
	module.exports = commitLocalUpdate;
}));
var require_validateMutation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	_interopRequireDefault(require_objectSpread2());
	require_warning();
	module.exports = function validateMutation() {};
}));
var require_commitMutation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var getRequest = require_GraphQLTag().getRequest;
	var generateUniqueClientID = require_ClientID().generateUniqueClientID;
	var isRelayModernEnvironment = require_isRelayModernEnvironment();
	var createOperationDescriptor = require_RelayModernOperationDescriptor().createOperationDescriptor;
	var RelayDeclarativeMutationConfig = require_RelayDeclarativeMutationConfig();
	require_validateMutation();
	var invariant = require_invariant();
	require_warning();
	function commitMutation(environment, config) {
		!isRelayModernEnvironment(environment) && invariant(false);
		var mutation = getRequest(config.mutation);
		if (mutation.params.operationKind !== "mutation") throw new Error("commitMutation: Expected mutation operation");
		if (mutation.kind !== "Request") throw new Error("commitMutation: Expected mutation to be of type request");
		var optimisticResponse = config.optimisticResponse, optimisticUpdater = config.optimisticUpdater, updater = config.updater;
		var configs = config.configs, cacheConfig = config.cacheConfig, onError = config.onError, onUnsubscribe = config.onUnsubscribe, variables = config.variables, uploadables = config.uploadables;
		var operation = createOperationDescriptor(mutation, variables, cacheConfig, generateUniqueClientID());
		if (typeof optimisticResponse === "function") optimisticResponse = optimisticResponse();
		if (configs) {
			var _RelayDeclarativeMuta = RelayDeclarativeMutationConfig.convert(configs, mutation, optimisticUpdater, updater);
			optimisticUpdater = _RelayDeclarativeMuta.optimisticUpdater;
			updater = _RelayDeclarativeMuta.updater;
		}
		var errors = [];
		return { dispose: environment.executeMutation({
			operation,
			optimisticResponse,
			optimisticUpdater,
			updater,
			uploadables
		}).subscribe({
			next: function next(payload) {
				var _config$onNext;
				if (Array.isArray(payload)) payload.forEach(function(item) {
					if (item.errors) errors.push.apply(errors, (0, _toConsumableArray2["default"])(item.errors));
				});
				else if (payload.errors) errors.push.apply(errors, (0, _toConsumableArray2["default"])(payload.errors));
				(_config$onNext = config.onNext) === null || _config$onNext === void 0 || _config$onNext.call(config);
			},
			complete: function complete() {
				var onCompleted = config.onCompleted;
				if (onCompleted) onCompleted(environment.lookup(operation.fragment).data, errors.length !== 0 ? errors : null);
			},
			error: onError,
			unsubscribe: onUnsubscribe
		}).unsubscribe };
	}
	module.exports = commitMutation;
}));
var require_withProvidedVariables = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	require_areEqual();
	require_warning();
	var debugCache = typeof WeakMap === "function" ? /* @__PURE__ */ new WeakMap() : /* @__PURE__ */ new Map();
	function withProvidedVariables(userSuppliedVariables, providedVariables) {
		if (providedVariables != null) {
			var operationVariables = {};
			Object.assign(operationVariables, userSuppliedVariables);
			Object.keys(providedVariables).forEach(function(varName) {
				var providerFunction = providedVariables[varName].get;
				var providerResult = providerFunction();
				if (!debugCache.has(providerFunction)) {
					debugCache.set(providerFunction, providerResult);
					operationVariables[varName] = providerResult;
				} else operationVariables[varName] = debugCache.get(providerFunction);
			});
			return operationVariables;
		} else return userSuppliedVariables;
	}
	withProvidedVariables.tests_only_resetDebugCache = void 0;
	module.exports = withProvidedVariables;
}));
var require_ConvertToExecuteFunction = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayObservable = require_RelayObservable();
	function convertFetch(fn) {
		return function fetch(request, variables, cacheConfig, uploadables, logRequestInfo) {
			var result = fn(request, variables, cacheConfig, uploadables, logRequestInfo);
			if (result instanceof Error) return RelayObservable.create(function(sink) {
				return sink.error(result);
			});
			return RelayObservable.from(result);
		};
	}
	module.exports = { convertFetch };
}));
var require_RelayNetwork = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var withProvidedVariables = require_withProvidedVariables();
	var convertFetch = require_ConvertToExecuteFunction().convertFetch;
	var invariant = require_invariant();
	function create(fetchFn, subscribe) {
		var observeFetch = convertFetch(fetchFn);
		function execute(request, variables, cacheConfig, uploadables, logRequestInfo) {
			var operationVariables = withProvidedVariables(variables, request.providedVariables);
			if (request.operationKind === "subscription") {
				!subscribe && invariant(false);
				uploadables && invariant(false);
				return subscribe(request, operationVariables, cacheConfig);
			}
			var pollInterval = cacheConfig.poll;
			if (pollInterval != null) {
				uploadables && invariant(false);
				return observeFetch(request, operationVariables, { force: true }).poll(pollInterval);
			}
			return observeFetch(request, operationVariables, cacheConfig, uploadables, logRequestInfo);
		}
		return { execute };
	}
	module.exports = { create };
}));
var require_RelayQueryResponseCache = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var stableCopy = require_stableCopy().stableCopy;
	var invariant = require_invariant();
	var RelayQueryResponseCache = /* @__PURE__ */ function() {
		function RelayQueryResponseCache(_ref) {
			var size = _ref.size, ttl = _ref.ttl;
			!(size > 0) && invariant(false);
			!(ttl > 0) && invariant(false);
			this._responses = /* @__PURE__ */ new Map();
			this._size = size;
			this._ttl = ttl;
		}
		var _proto = RelayQueryResponseCache.prototype;
		_proto.clear = function clear() {
			this._responses.clear();
		};
		_proto.get = function get(queryID, variables) {
			var _this = this;
			var cacheKey = getCacheKey(queryID, variables);
			this._responses.forEach(function(response, key) {
				if (!isCurrent(response.fetchTime, _this._ttl)) _this._responses["delete"](key);
			});
			var response = this._responses.get(cacheKey);
			if (response == null) return null;
			if (Array.isArray(response.payload)) return response.payload.map(function(payload) {
				return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, payload), {}, { extensions: (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, payload.extensions), {}, { cacheTimestamp: response.fetchTime }) });
			});
			return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, response.payload), {}, { extensions: (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, response.payload.extensions), {}, { cacheTimestamp: response.fetchTime }) });
		};
		_proto.set = function set(queryID, variables, payload) {
			var fetchTime = Date.now();
			var cacheKey = getCacheKey(queryID, variables);
			this._responses["delete"](cacheKey);
			this._responses.set(cacheKey, {
				fetchTime,
				payload
			});
			if (this._responses.size > this._size) {
				var firstKey = this._responses.keys().next();
				if (!firstKey.done) this._responses["delete"](firstKey.value);
			}
		};
		return RelayQueryResponseCache;
	}();
	function getCacheKey(queryID, variables) {
		return JSON.stringify(stableCopy({
			queryID,
			variables
		}));
	}
	function isCurrent(fetchTime, ttl) {
		return fetchTime + ttl >= Date.now();
	}
	module.exports = RelayQueryResponseCache;
}));
var require_fetchQuery = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var RelayObservable = require_RelayObservable();
	var createOperationDescriptor = require_RelayModernOperationDescriptor().createOperationDescriptor;
	var handlePotentialSnapshotErrors = require_handlePotentialSnapshotErrors().handlePotentialSnapshotErrors;
	var fetchQueryInternal = require_fetchQueryInternal();
	var getRequest = require_GraphQLTag().getRequest;
	var invariant = require_invariant();
	function fetchQuery(environment, query, variables, options) {
		var _options$fetchPolicy;
		var queryNode = getRequest(query);
		!(queryNode.params.operationKind === "query") && invariant(false);
		var operation = createOperationDescriptor(queryNode, variables, (0, _objectSpread2["default"])({ force: true }, options === null || options === void 0 ? void 0 : options.networkCacheConfig));
		var fetchPolicy = (_options$fetchPolicy = options === null || options === void 0 ? void 0 : options.fetchPolicy) !== null && _options$fetchPolicy !== void 0 ? _options$fetchPolicy : "network-only";
		function readData(snapshot) {
			handlePotentialSnapshotErrors(environment, snapshot.fieldErrors);
			return snapshot.data;
		}
		switch (fetchPolicy) {
			case "network-only": return getNetworkObservable(environment, operation).map(readData);
			case "store-or-network":
				if (environment.check(operation).status === "available") return RelayObservable.from(environment.lookup(operation.fragment)).map(readData);
				return getNetworkObservable(environment, operation).map(readData);
			default: throw new Error("fetchQuery: Invalid fetchPolicy " + fetchPolicy);
		}
	}
	function getNetworkObservable(environment, operation) {
		return fetchQueryInternal.fetchQuery(environment, operation).map(function() {
			return environment.lookup(operation.fragment);
		});
	}
	module.exports = fetchQuery;
}));
var require_fetchQuery_DEPRECATED = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var createOperationDescriptor = require_RelayModernOperationDescriptor().createOperationDescriptor;
	var getRequest = require_GraphQLTag().getRequest;
	function fetchQuery_DEPRECATED(environment, taggedNode, variables, cacheConfig) {
		var query = getRequest(taggedNode);
		if (query.params.operationKind !== "query") throw new Error("fetchQuery: Expected query operation");
		var operation = createOperationDescriptor(query, variables, cacheConfig);
		return environment.execute({ operation }).map(function() {
			return environment.lookup(operation.fragment).data;
		}).toPromise();
	}
	module.exports = fetchQuery_DEPRECATED;
}));
var require_PreloadableQueryRegistry = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = new (/* @__PURE__ */ function() {
		function PreloadableQueryRegistry() {
			this._preloadableQueries = /* @__PURE__ */ new Map();
			this._callbacks = /* @__PURE__ */ new Map();
		}
		var _proto = PreloadableQueryRegistry.prototype;
		_proto.set = function set(key, value) {
			this._preloadableQueries.set(key, value);
			var callbacks = this._callbacks.get(key);
			if (callbacks != null) callbacks.forEach(function(cb) {
				try {
					cb(value);
				} catch (e) {
					setTimeout(function() {
						throw e;
					}, 0);
				}
			});
		};
		_proto.get = function get(key) {
			return this._preloadableQueries.get(key);
		};
		_proto.onLoad = function onLoad(key, callback) {
			var _this$_callbacks$get;
			var callbacks = (_this$_callbacks$get = this._callbacks.get(key)) !== null && _this$_callbacks$get !== void 0 ? _this$_callbacks$get : /* @__PURE__ */ new Set();
			callbacks.add(callback);
			var dispose = function dispose() {
				callbacks["delete"](callback);
			};
			this._callbacks.set(key, callbacks);
			return { dispose };
		};
		_proto.clear = function clear() {
			this._preloadableQueries.clear();
		};
		return PreloadableQueryRegistry;
	}())();
}));
var require_getPendingOperationsForFragment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getPromiseForActiveRequest = require_fetchQueryInternal().getPromiseForActiveRequest;
	function getPendingOperationsForFragment(environment, fragmentNode, fragmentOwner) {
		var _pendingOperations$ma, _pendingOperations;
		var pendingOperations = [];
		var promise = getPromiseForActiveRequest(environment, fragmentOwner);
		if (promise != null) pendingOperations = [fragmentOwner];
		else {
			var _result$pendingOperat, _result$promise;
			var result = environment.getOperationTracker().getPendingOperationsAffectingOwner(fragmentOwner);
			pendingOperations = (_result$pendingOperat = result === null || result === void 0 ? void 0 : result.pendingOperations) !== null && _result$pendingOperat !== void 0 ? _result$pendingOperat : [];
			promise = (_result$promise = result === null || result === void 0 ? void 0 : result.promise) !== null && _result$promise !== void 0 ? _result$promise : null;
		}
		if (!promise) return null;
		var pendingOperationName = (_pendingOperations$ma = (_pendingOperations = pendingOperations) === null || _pendingOperations === void 0 ? void 0 : _pendingOperations.map(function(op) {
			return op.node.params.name;
		}).join(",")) !== null && _pendingOperations$ma !== void 0 ? _pendingOperations$ma : null;
		if (pendingOperationName == null || pendingOperationName.length === 0) pendingOperationName = "Unknown pending operation";
		var fragmentName = fragmentNode.name;
		var promiseDisplayName = pendingOperationName === fragmentName ? "Relay(".concat(pendingOperationName, ")") : "Relay(".concat(pendingOperationName, ":").concat(fragmentName, ")");
		promise.displayName = promiseDisplayName;
		environment.__log({
			name: "pendingoperation.found",
			fragment: fragmentNode,
			fragmentOwner,
			pendingOperations
		});
		return {
			promise,
			pendingOperations
		};
	}
	module.exports = getPendingOperationsForFragment;
}));
var require_isScalarAndEqual = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function isScalarAndEqual(valueA, valueB) {
		return valueA === valueB && (valueA === null || typeof valueA !== "object");
	}
	module.exports = isScalarAndEqual;
}));
var require_recycleNodesInto = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function recycleNodesInto(prevData, nextData) {
		return recycleNodesIntoImpl(prevData, nextData, true);
	}
	function recycleNodesIntoImpl(prevData, nextData, canMutate) {
		if (prevData === nextData || typeof prevData !== "object" || !prevData || prevData.constructor !== Object && !Array.isArray(prevData) || typeof nextData !== "object" || !nextData || nextData.constructor !== Object && !Array.isArray(nextData)) return nextData;
		var canRecycle = false;
		var prevArray = Array.isArray(prevData) ? prevData : null;
		var nextArray = Array.isArray(nextData) ? nextData : null;
		if (prevArray && nextArray) {
			var canMutateNext = canMutate && !Object.isFrozen(nextArray);
			canRecycle = nextArray.reduce(function(wasEqual, nextItem, ii) {
				var prevValue = prevArray[ii];
				var nextValue = recycleNodesIntoImpl(prevValue, nextItem, canMutateNext);
				if (nextValue !== nextArray[ii] && canMutateNext) nextArray[ii] = nextValue;
				return wasEqual && nextValue === prevArray[ii];
			}, true) && prevArray.length === nextArray.length;
		} else if (!prevArray && !nextArray) {
			var prevObject = prevData;
			var nextObject = nextData;
			var prevKeys = Object.keys(prevObject);
			var nextKeys = Object.keys(nextObject);
			var _canMutateNext = canMutate && !Object.isFrozen(nextObject);
			canRecycle = nextKeys.reduce(function(wasEqual, key) {
				var prevValue = prevObject[key];
				var nextValue = recycleNodesIntoImpl(prevValue, nextObject[key], _canMutateNext);
				if (nextValue !== nextObject[key] && _canMutateNext) nextObject[key] = nextValue;
				return wasEqual && nextValue === prevObject[key];
			}, true) && prevKeys.length === nextKeys.length;
		}
		return canRecycle ? prevData : nextData;
	}
	module.exports = recycleNodesInto;
}));
var require_RelayModernFragmentSpecResolver = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var getPendingOperationsForFragment = require_getPendingOperationsForFragment();
	var handlePotentialSnapshotErrors = require_handlePotentialSnapshotErrors().handlePotentialSnapshotErrors;
	var isScalarAndEqual = require_isScalarAndEqual();
	var recycleNodesInto = require_recycleNodesInto();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var createRequestDescriptor = require_RelayModernOperationDescriptor().createRequestDescriptor;
	var _require3 = require_RelayModernSelector(), areEqualSelectors = _require3.areEqualSelectors, createReaderSelector = _require3.createReaderSelector, getSelectorsFromObject = _require3.getSelectorsFromObject;
	var areEqual = require_areEqual();
	var invariant = require_invariant();
	require_warning();
	var RelayModernFragmentSpecResolver = /* @__PURE__ */ function() {
		function RelayModernFragmentSpecResolver(context, fragments, props, callback, rootIsQueryRenderer) {
			var _this = this;
			(0, _defineProperty2["default"])(this, "_onChange", function() {
				_this._stale = true;
				if (typeof _this._callback === "function") _this._callback();
			});
			this._callback = callback;
			this._context = context;
			this._data = {};
			this._fragments = fragments;
			this._props = {};
			this._resolvers = {};
			this._stale = false;
			this._rootIsQueryRenderer = rootIsQueryRenderer;
			this.setProps(props);
		}
		var _proto = RelayModernFragmentSpecResolver.prototype;
		_proto.dispose = function dispose() {
			for (var key in this._resolvers) if (this._resolvers.hasOwnProperty(key)) disposeCallback(this._resolvers[key]);
		};
		_proto.resolve = function resolve() {
			if (this._stale) {
				var prevData = this._data;
				var nextData;
				for (var key in this._resolvers) if (this._resolvers.hasOwnProperty(key)) {
					var resolver = this._resolvers[key];
					var prevItem = prevData[key];
					if (resolver) {
						var nextItem = resolver.resolve();
						if (nextData || nextItem !== prevItem) {
							nextData = nextData || (0, _objectSpread2["default"])({}, prevData);
							nextData[key] = nextItem;
						}
					} else {
						var prop = this._props[key];
						var _nextItem = prop !== void 0 ? prop : null;
						if (nextData || !isScalarAndEqual(_nextItem, prevItem)) {
							nextData = nextData || (0, _objectSpread2["default"])({}, prevData);
							nextData[key] = _nextItem;
						}
					}
				}
				this._data = nextData || prevData;
				this._stale = false;
			}
			return this._data;
		};
		_proto.setCallback = function setCallback(props, callback) {
			this._callback = callback;
			if (RelayFeatureFlags.ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT === true) this.setProps(props);
		};
		_proto.setProps = function setProps(props) {
			this._props = {};
			var ownedSelectors = getSelectorsFromObject(this._fragments, props);
			for (var key in ownedSelectors) if (ownedSelectors.hasOwnProperty(key)) {
				var ownedSelector = ownedSelectors[key];
				var resolver = this._resolvers[key];
				if (ownedSelector == null) {
					if (resolver != null) resolver.dispose();
					resolver = null;
				} else if (ownedSelector.kind === "PluralReaderSelector") if (resolver == null) resolver = new SelectorListResolver(this._context.environment, this._rootIsQueryRenderer, ownedSelector, this._callback != null, this._onChange);
				else {
					!(resolver instanceof SelectorListResolver) && invariant(false);
					resolver.setSelector(ownedSelector);
				}
				else if (resolver == null) resolver = new SelectorResolver(this._context.environment, this._rootIsQueryRenderer, ownedSelector, this._callback != null, this._onChange);
				else {
					!(resolver instanceof SelectorResolver) && invariant(false);
					resolver.setSelector(ownedSelector);
				}
				this._props[key] = props[key];
				this._resolvers[key] = resolver;
			}
			this._stale = true;
		};
		_proto.setVariables = function setVariables(variables, request) {
			for (var key in this._resolvers) if (this._resolvers.hasOwnProperty(key)) {
				var resolver = this._resolvers[key];
				if (resolver) resolver.setVariables(variables, request);
			}
			this._stale = true;
		};
		return RelayModernFragmentSpecResolver;
	}();
	var SelectorResolver = /* @__PURE__ */ function() {
		function SelectorResolver(environment, rootIsQueryRenderer, selector, subscribeOnConstruction, callback) {
			var _this2 = this;
			(0, _defineProperty2["default"])(this, "_onChange", function(snapshot) {
				_this2._data = snapshot.data;
				_this2._isMissingData = snapshot.isMissingData;
				_this2._fieldErrors = snapshot.fieldErrors;
				_this2._callback();
			});
			var _snapshot = environment.lookup(selector);
			this._callback = callback;
			this._data = _snapshot.data;
			this._isMissingData = _snapshot.isMissingData;
			this._fieldErrors = _snapshot.fieldErrors;
			this._environment = environment;
			this._rootIsQueryRenderer = rootIsQueryRenderer;
			this._selector = selector;
			if (RelayFeatureFlags.ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT === true) {
				if (subscribeOnConstruction) this._subscription = environment.subscribe(_snapshot, this._onChange);
			} else this._subscription = environment.subscribe(_snapshot, this._onChange);
		}
		var _proto2 = SelectorResolver.prototype;
		_proto2.dispose = function dispose() {
			if (this._subscription) {
				this._subscription.dispose();
				this._subscription = null;
			}
		};
		_proto2.resolve = function resolve() {
			if (this._isMissingData === true) {
				var pendingOperationsResult = getPendingOperationsForFragment(this._environment, this._selector.node, this._selector.owner);
				var promise = pendingOperationsResult === null || pendingOperationsResult === void 0 ? void 0 : pendingOperationsResult.promise;
				if (promise != null) if (this._rootIsQueryRenderer) {} else {
					var _pendingOperationsRes;
					var pendingOperations = (_pendingOperationsRes = pendingOperationsResult === null || pendingOperationsResult === void 0 ? void 0 : pendingOperationsResult.pendingOperations) !== null && _pendingOperationsRes !== void 0 ? _pendingOperationsRes : [];
					this._environment.__log({
						name: "suspense.fragment",
						data: this._data,
						fragment: this._selector.node,
						isRelayHooks: false,
						isMissingData: this._isMissingData,
						isPromiseCached: false,
						pendingOperations
					});
					throw promise;
				}
			}
			handlePotentialSnapshotErrors(this._environment, this._fieldErrors);
			return this._data;
		};
		_proto2.setSelector = function setSelector(selector) {
			if (this._subscription != null && areEqualSelectors(selector, this._selector)) return;
			this.dispose();
			var snapshot = this._environment.lookup(selector);
			this._data = recycleNodesInto(this._data, snapshot.data);
			this._isMissingData = snapshot.isMissingData;
			this._fieldErrors = snapshot.fieldErrors;
			this._selector = selector;
			this._subscription = this._environment.subscribe(snapshot, this._onChange);
		};
		_proto2.setVariables = function setVariables(variables, request) {
			if (areEqual(variables, this._selector.variables)) return;
			var requestDescriptor = createRequestDescriptor(request, variables);
			var selector = createReaderSelector(this._selector.node, this._selector.dataID, variables, requestDescriptor);
			this.setSelector(selector);
		};
		return SelectorResolver;
	}();
	var SelectorListResolver = /* @__PURE__ */ function() {
		function SelectorListResolver(environment, rootIsQueryRenderer, selector, subscribeOnConstruction, callback) {
			var _this3 = this;
			(0, _defineProperty2["default"])(this, "_onChange", function(data) {
				_this3._stale = true;
				_this3._callback();
			});
			this._callback = callback;
			this._data = [];
			this._environment = environment;
			this._resolvers = [];
			this._stale = true;
			this._rootIsQueryRenderer = rootIsQueryRenderer;
			this._subscribeOnConstruction = subscribeOnConstruction;
			this.setSelector(selector);
		}
		var _proto3 = SelectorListResolver.prototype;
		_proto3.dispose = function dispose() {
			this._resolvers.forEach(disposeCallback);
		};
		_proto3.resolve = function resolve() {
			if (this._stale) {
				var prevData = this._data;
				var nextData;
				for (var ii = 0; ii < this._resolvers.length; ii++) {
					var prevItem = prevData[ii];
					var nextItem = this._resolvers[ii].resolve();
					if (nextData || nextItem !== prevItem) {
						nextData = nextData || prevData.slice(0, ii);
						nextData.push(nextItem);
					}
				}
				if (!nextData && this._resolvers.length !== prevData.length) nextData = prevData.slice(0, this._resolvers.length);
				this._data = nextData || prevData;
				this._stale = false;
			}
			return this._data;
		};
		_proto3.setSelector = function setSelector(selector) {
			var selectors = selector.selectors;
			while (this._resolvers.length > selectors.length) this._resolvers.pop().dispose();
			for (var ii = 0; ii < selectors.length; ii++) if (ii < this._resolvers.length) this._resolvers[ii].setSelector(selectors[ii]);
			else this._resolvers[ii] = new SelectorResolver(this._environment, this._rootIsQueryRenderer, selectors[ii], this._subscribeOnConstruction, this._onChange);
			this._stale = true;
		};
		_proto3.setVariables = function setVariables(variables, request) {
			this._resolvers.forEach(function(resolver) {
				return resolver.setVariables(variables, request);
			});
			this._stale = true;
		};
		return SelectorListResolver;
	}();
	function disposeCallback(disposable) {
		disposable && disposable.dispose();
	}
	module.exports = RelayModernFragmentSpecResolver;
}));
var require_createFragmentSpecResolver = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayModernFragmentSpecResolver = require_RelayModernFragmentSpecResolver();
	require_warning();
	function createFragmentSpecResolver(context, containerName, fragments, props, rootIsQueryRenderer, callback) {
		return new RelayModernFragmentSpecResolver(context, fragments, props, callback, rootIsQueryRenderer);
	}
	module.exports = createFragmentSpecResolver;
}));
var require_createRelayContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	var relayContext;
	var firstReact;
	function createRelayContext(react) {
		if (!relayContext) {
			relayContext = react.createContext(null);
			firstReact = react;
		}
		!(react === firstReact) && invariant(false);
		return relayContext;
	}
	module.exports = createRelayContext;
}));
var require_createRelayLoggingContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	var relayLoggingContext;
	var firstReact;
	function createRelayLoggingContext(react) {
		if (!relayLoggingContext) {
			relayLoggingContext = react.createContext(null);
			firstReact = react;
		}
		!(react === firstReact) && invariant(false);
		return relayLoggingContext;
	}
	module.exports = createRelayLoggingContext;
}));
var require_LiveResolverSuspenseSentinel = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var LIVE_RESOLVER_SUSPENSE_SENTINEL = Object.freeze({ __LIVE_RESOLVER_SUSPENSE_SENTINEL: true });
	function suspenseSentinel() {
		return LIVE_RESOLVER_SUSPENSE_SENTINEL;
	}
	function isSuspenseSentinel(value) {
		return value === LIVE_RESOLVER_SUSPENSE_SENTINEL;
	}
	module.exports = {
		isSuspenseSentinel,
		suspenseSentinel
	};
}));
var require_objectWithoutPropertiesLoose = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _objectWithoutPropertiesLoose(r, e) {
		if (null == r) return {};
		var t = {};
		for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
			if (-1 !== e.indexOf(n)) continue;
			t[n] = r[n];
		}
		return t;
	}
	module.exports = _objectWithoutPropertiesLoose, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_RelayModernRecord = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require_objectWithoutPropertiesLoose());
	var _toPropertyKey2 = _interopRequireDefault(require_toPropertyKey());
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var deepFreeze = require_deepFreeze(), _require = require_ClientID(), generateClientObjectClientID = _require.generateClientObjectClientID;
	_require.isClientID;
	var isSuspenseSentinel = require_LiveResolverSuspenseSentinel().isSuspenseSentinel, _require3 = require_RelayStoreUtils(), ACTOR_IDENTIFIER_KEY = _require3.ACTOR_IDENTIFIER_KEY, ERRORS_KEY = _require3.ERRORS_KEY, ID_KEY = _require3.ID_KEY, INVALIDATED_AT_KEY = _require3.INVALIDATED_AT_KEY, REF_KEY = _require3.REF_KEY, REFS_KEY = _require3.REFS_KEY, RELAY_RESOLVER_VALUE_KEY = _require3.RELAY_RESOLVER_VALUE_KEY;
	_require3.ROOT_ID;
	var TYPENAME_KEY = _require3.TYPENAME_KEY;
	var areEqual = require_areEqual();
	var invariant = require_invariant();
	require_warning();
	function clone(record) {
		return (0, _objectSpread2["default"])({}, record);
	}
	function copyFields(source, sink) {
		for (var key in source) if (source.hasOwnProperty(key)) {
			if (key !== ID_KEY && key !== TYPENAME_KEY) sink[key] = source[key];
		}
	}
	function create(dataID, typeName) {
		var record = {};
		record[ID_KEY] = dataID;
		record[TYPENAME_KEY] = typeName;
		return record;
	}
	function fromObject(json) {
		return json;
	}
	function getDataID(record) {
		return record[ID_KEY];
	}
	function getFields(record) {
		if (ERRORS_KEY in record) return Object.keys(record).filter(function(field) {
			return field !== ERRORS_KEY;
		});
		return Object.keys(record);
	}
	function getType(record) {
		return record[TYPENAME_KEY];
	}
	function getErrors(record, storageKey) {
		var _record$ERRORS_KEY;
		return (_record$ERRORS_KEY = record[ERRORS_KEY]) === null || _record$ERRORS_KEY === void 0 ? void 0 : _record$ERRORS_KEY[storageKey];
	}
	function getValue(record, storageKey) {
		var value = record[storageKey];
		if (value && typeof value === "object") !(!value.hasOwnProperty(REF_KEY) && !value.hasOwnProperty(REFS_KEY)) && invariant(false);
		return value;
	}
	function hasValue(record, storageKey) {
		return storageKey in record;
	}
	function getLinkedRecordID(record, storageKey) {
		var maybeLink = record[storageKey];
		if (maybeLink == null) return maybeLink;
		var link = maybeLink;
		!(typeof link === "object" && link && typeof link[REF_KEY] === "string") && invariant(false);
		return link[REF_KEY];
	}
	function hasLinkedRecordID(record, storageKey) {
		var maybeLink = record[storageKey];
		if (maybeLink == null) return false;
		var link = maybeLink;
		return typeof link === "object" && link && typeof link[REF_KEY] === "string";
	}
	function getLinkedRecordIDs(record, storageKey) {
		var links = record[storageKey];
		if (links == null) return links;
		!(typeof links === "object" && Array.isArray(links[REFS_KEY])) && invariant(false);
		return links[REFS_KEY];
	}
	function hasLinkedRecordIDs(record, storageKey) {
		var links = record[storageKey];
		if (links == null) return false;
		return typeof links === "object" && Array.isArray(links[REFS_KEY]) && links[REFS_KEY].every(function(link) {
			return typeof link === "string";
		});
	}
	function getInvalidationEpoch(record) {
		if (record == null) return null;
		var invalidatedAt = record[INVALIDATED_AT_KEY];
		if (typeof invalidatedAt !== "number") return null;
		return invalidatedAt;
	}
	function update(prevRecord, nextRecord) {
		var _updated2;
		var prevErrorsByKey = prevRecord[ERRORS_KEY];
		var nextErrorsByKey = nextRecord[ERRORS_KEY];
		var updated = null;
		if (prevErrorsByKey == null && nextErrorsByKey == null) {
			var _updated;
			for (var storageKey in nextRecord) if (updated || !areEqual(prevRecord[storageKey], nextRecord[storageKey])) {
				updated = updated !== null ? updated : (0, _objectSpread2["default"])({}, prevRecord);
				updated[storageKey] = nextRecord[storageKey];
			}
			return (_updated = updated) !== null && _updated !== void 0 ? _updated : prevRecord;
		}
		for (var _storageKey2 in nextRecord) {
			if (_storageKey2 === ERRORS_KEY) continue;
			var nextValue = nextRecord[_storageKey2];
			var nextErrors = nextErrorsByKey === null || nextErrorsByKey === void 0 ? void 0 : nextErrorsByKey[_storageKey2];
			if (updated == null) {
				var prevValue = prevRecord[_storageKey2];
				var prevErrors = prevErrorsByKey === null || prevErrorsByKey === void 0 ? void 0 : prevErrorsByKey[_storageKey2];
				if (areEqual(prevValue, nextValue) && areEqual(prevErrors, nextErrors)) continue;
				updated = (0, _objectSpread2["default"])({}, prevRecord);
				if (prevErrorsByKey != null) updated[ERRORS_KEY] = (0, _objectSpread2["default"])({}, prevErrorsByKey);
			}
			setValue(updated, _storageKey2, nextValue);
			setErrors(updated, _storageKey2, nextErrors);
		}
		return (_updated2 = updated) !== null && _updated2 !== void 0 ? _updated2 : prevRecord;
	}
	function merge(record1, record2) {
		if (ERRORS_KEY in record1 || ERRORS_KEY in record2) {
			var errors1 = record1[ERRORS_KEY], fields1 = (0, _objectWithoutPropertiesLoose2["default"])(record1, [ERRORS_KEY].map(_toPropertyKey2["default"]));
			var errors2 = record2[ERRORS_KEY], fields2 = (0, _objectWithoutPropertiesLoose2["default"])(record2, [ERRORS_KEY].map(_toPropertyKey2["default"]));
			var updated = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, fields1), fields2);
			if (errors1 == null && errors2 == null) return updated;
			var updatedErrors = {};
			for (var storageKey in errors1) {
				if (fields2.hasOwnProperty(storageKey)) continue;
				updatedErrors[storageKey] = errors1[storageKey];
			}
			for (var _storageKey3 in errors2) updatedErrors[_storageKey3] = errors2[_storageKey3];
			for (var _storageKey in updatedErrors) {
				updated[ERRORS_KEY] = updatedErrors;
				break;
			}
			return updated;
		} else return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, record1), record2);
	}
	function freeze(record) {
		deepFreeze(record);
	}
	function setErrors(record, storageKey, errors) {
		var errorsByStorageKey = record[ERRORS_KEY];
		if (errors != null && errors.length > 0) if (errorsByStorageKey == null) record[ERRORS_KEY] = (0, _defineProperty2["default"])({}, storageKey, errors);
		else errorsByStorageKey[storageKey] = errors;
		else if (errorsByStorageKey != null) {
			if (delete errorsByStorageKey[storageKey]) {
				for (var otherStorageKey in errorsByStorageKey) if (errorsByStorageKey.hasOwnProperty(otherStorageKey)) return;
				delete record[ERRORS_KEY];
			}
		}
	}
	function setValue(record, storageKey, value) {
		record[storageKey] = value;
	}
	function setLinkedRecordID(record, storageKey, linkedID) {
		var link = {};
		link[REF_KEY] = linkedID;
		record[storageKey] = link;
	}
	function setLinkedRecordIDs(record, storageKey, linkedIDs) {
		var links = {};
		links[REFS_KEY] = linkedIDs;
		record[storageKey] = links;
	}
	function setActorLinkedRecordID(record, storageKey, actorIdentifier, linkedID) {
		var link = {};
		link[REF_KEY] = linkedID;
		link[ACTOR_IDENTIFIER_KEY] = actorIdentifier;
		record[storageKey] = link;
	}
	function getActorLinkedRecordID(record, storageKey) {
		var link = record[storageKey];
		if (link == null) return link;
		!(typeof link === "object" && typeof link[REF_KEY] === "string" && link[ACTOR_IDENTIFIER_KEY] != null) && invariant(false);
		return [link[ACTOR_IDENTIFIER_KEY], link[REF_KEY]];
	}
	function getResolverLinkedRecordID(record, typeName) {
		var id = getValue(record, RELAY_RESOLVER_VALUE_KEY);
		if (id == null || isSuspenseSentinel(id)) return null;
		if (typeof id === "object") id = id.id;
		!(typeof id === "string") && invariant(false);
		return generateClientObjectClientID(typeName, id);
	}
	function getResolverLinkedRecordIDs(record, typeName) {
		var resolverValue = getValue(record, RELAY_RESOLVER_VALUE_KEY);
		if (resolverValue == null || isSuspenseSentinel(resolverValue)) return null;
		!Array.isArray(resolverValue) && invariant(false);
		return resolverValue.map(function(id) {
			if (id == null) return null;
			if (typeof id === "object") id = id.id;
			!(typeof id === "string") && invariant(false);
			return generateClientObjectClientID(typeName, id);
		});
	}
	function toJSON(record) {
		return record;
	}
	module.exports = {
		clone,
		copyFields,
		create,
		freeze,
		fromObject,
		getDataID,
		getErrors,
		getFields,
		getInvalidationEpoch,
		getLinkedRecordID,
		getLinkedRecordIDs,
		getType,
		getValue,
		hasValue,
		hasLinkedRecordID,
		hasLinkedRecordIDs,
		merge,
		setErrors,
		setValue,
		setLinkedRecordID,
		setLinkedRecordIDs,
		update,
		getActorLinkedRecordID,
		setActorLinkedRecordID,
		getResolverLinkedRecordID,
		getResolverLinkedRecordIDs,
		toJSON
	};
}));
var require_RelayRecordState = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		EXISTENT: "EXISTENT",
		NONEXISTENT: "NONEXISTENT",
		UNKNOWN: "UNKNOWN"
	};
}));
var require_RelayRecordSource = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var RelayModernRecord = require_RelayModernRecord();
	var RelayRecordState = require_RelayRecordState();
	var EXISTENT = RelayRecordState.EXISTENT, NONEXISTENT = RelayRecordState.NONEXISTENT, UNKNOWN = RelayRecordState.UNKNOWN;
	module.exports = /* @__PURE__ */ function() {
		function RelayRecordSource(records) {
			var _this = this;
			this._records = /* @__PURE__ */ new Map();
			if (records != null) Object.keys(records).forEach(function(key) {
				var object = records[key];
				var record = RelayModernRecord.fromObject(object);
				_this._records.set(key, record);
			});
		}
		RelayRecordSource.create = function create(records) {
			return new RelayRecordSource(records);
		};
		var _proto = RelayRecordSource.prototype;
		_proto.clear = function clear() {
			this._records = /* @__PURE__ */ new Map();
		};
		_proto["delete"] = function _delete(dataID) {
			this._records.set(dataID, null);
		};
		_proto.get = function get(dataID) {
			return this._records.get(dataID);
		};
		_proto.getRecordIDs = function getRecordIDs() {
			return Array.from(this._records.keys());
		};
		_proto.getStatus = function getStatus(dataID) {
			if (!this._records.has(dataID)) return UNKNOWN;
			return this._records.get(dataID) == null ? NONEXISTENT : EXISTENT;
		};
		_proto.has = function has(dataID) {
			return this._records.has(dataID);
		};
		_proto.remove = function remove(dataID) {
			this._records["delete"](dataID);
		};
		_proto.set = function set(dataID, record) {
			this._records.set(dataID, record);
		};
		_proto.size = function size() {
			return this._records.size;
		};
		_proto.toJSON = function toJSON() {
			var obj = {};
			var _iterator = (0, _createForOfIteratorHelper2["default"])(this._records), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var _step$value = _step.value, key = _step$value[0], record = _step$value[1];
					obj[key] = RelayModernRecord.toJSON(record);
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			return obj;
		};
		return RelayRecordSource;
	}();
}));
var require_ActorIdentifier = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	var INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE = "INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE";
	function assertInternalActorIdentifier(actorIdentifier) {
		!(actorIdentifier === INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE) && invariant(false);
	}
	module.exports = {
		assertInternalActorIdentifier,
		getActorIdentifier: function getActorIdentifier(actorID) {
			return actorID;
		},
		getDefaultActorIdentifier: function getDefaultActorIdentifier() {
			throw new Error("Not Implemented");
		},
		INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE
	};
}));
var require_ActorUtils = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ACTOR_IDENTIFIER_FIELD_NAME = "actor_key";
	var getActorIdentifier = require_ActorIdentifier().getActorIdentifier;
	function getActorIdentifierFromPayload(payload) {
		if (payload != null && typeof payload === "object" && typeof payload[ACTOR_IDENTIFIER_FIELD_NAME] === "string") return getActorIdentifier(payload[ACTOR_IDENTIFIER_FIELD_NAME]);
	}
	module.exports = {
		ACTOR_IDENTIFIER_FIELD_NAME,
		getActorIdentifierFromPayload
	};
}));
var require_RelayErrorTrie = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require_objectWithoutPropertiesLoose());
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var _excluded = ["path", "locations"];
	var SELF = Symbol("$SELF");
	function buildErrorTrie(errors) {
		if (errors == null) return null;
		var trie = /* @__PURE__ */ new Map();
		var _iterator = (0, _createForOfIteratorHelper2["default"])(errors), _step;
		try {
			ERRORS: for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var _step$value = _step.value, path = _step$value.path;
				_step$value.locations;
				var error = (0, _objectWithoutPropertiesLoose2["default"])(_step$value, _excluded);
				if (path == null) continue;
				var length = path.length;
				if (length === 0) continue;
				var lastIndex = length - 1;
				var currentTrie = trie;
				for (var index = 0; index < lastIndex; index++) {
					var key = path[index];
					var existingValue = currentTrie.get(key);
					if (existingValue instanceof Map) {
						currentTrie = existingValue;
						continue;
					}
					var newValue = /* @__PURE__ */ new Map();
					if (Array.isArray(existingValue)) newValue.set(SELF, existingValue);
					currentTrie.set(key, newValue);
					currentTrie = newValue;
				}
				var lastKey = path[lastIndex];
				var container = currentTrie.get(lastKey);
				if (container instanceof Map) {
					currentTrie = container;
					container = currentTrie.get(lastKey);
					lastKey = SELF;
				}
				if (Array.isArray(container)) container.push(error);
				else currentTrie.set(lastKey, [error]);
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
		return trie;
	}
	function getErrorsByKey(trie, key) {
		var value = trie.get(key);
		if (value == null) return null;
		if (Array.isArray(value)) return value;
		var errors = [];
		recursivelyCopyErrorsIntoArray(value, errors);
		return errors;
	}
	function recursivelyCopyErrorsIntoArray(trieOrSet, errors) {
		var _iterator2 = (0, _createForOfIteratorHelper2["default"])(trieOrSet), _step2;
		try {
			for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
				var _step2$value = _step2.value, childKey = _step2$value[0], value = _step2$value[1];
				var oldLength = errors.length;
				if (Array.isArray(value)) errors.push.apply(errors, (0, _toConsumableArray2["default"])(value));
				else recursivelyCopyErrorsIntoArray(value, errors);
				if (childKey === SELF) continue;
				var newLength = errors.length;
				for (var index = oldLength; index < newLength; index++) {
					var error = errors[index];
					if (error.path == null) errors[index] = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, error), {}, { path: [childKey] });
					else error.path.unshift(childKey);
				}
			}
		} catch (err) {
			_iterator2.e(err);
		} finally {
			_iterator2.f();
		}
	}
	function getNestedErrorTrieByKey(trie, key) {
		var value = trie.get(key);
		if (value instanceof Map) return value;
		return null;
	}
	module.exports = {
		SELF,
		buildErrorTrie,
		getNestedErrorTrieByKey,
		getErrorsByKey
	};
}));
var require_TypeID = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var PREFIX = "client:__type:";
	var TYPE_SCHEMA_TYPE = "__TypeSchema";
	function generateTypeID(typeName) {
		return PREFIX + typeName;
	}
	function isTypeID(id) {
		return id.indexOf(PREFIX) === 0;
	}
	module.exports = {
		generateTypeID,
		isTypeID,
		TYPE_SCHEMA_TYPE
	};
}));
var require_RelayResponseNormalizer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray()), _require = require_ActorUtils();
	_require.ACTOR_IDENTIFIER_FIELD_NAME;
	var getActorIdentifierFromPayload = _require.getActorIdentifierFromPayload;
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var _require2 = require_ClientID(), generateClientID = _require2.generateClientID, isClientID = _require2.isClientID;
	var getLocalVariables = require_RelayConcreteVariables().getLocalVariables;
	var _require4 = require_RelayErrorTrie(), buildErrorTrie = _require4.buildErrorTrie, getErrorsByKey = _require4.getErrorsByKey, getNestedErrorTrieByKey = _require4.getNestedErrorTrieByKey;
	var RelayModernRecord = require_RelayModernRecord();
	var createNormalizationSelector = require_RelayModernSelector().createNormalizationSelector;
	var _require6 = require_RelayStoreUtils(), ROOT_ID = _require6.ROOT_ID, TYPENAME_KEY = _require6.TYPENAME_KEY, getArgumentValues = _require6.getArgumentValues, getHandleStorageKey = _require6.getHandleStorageKey, getModuleComponentKey = _require6.getModuleComponentKey, getModuleOperationKey = _require6.getModuleOperationKey, getStorageKey = _require6.getStorageKey;
	var _require7 = require_TypeID(), TYPE_SCHEMA_TYPE = _require7.TYPE_SCHEMA_TYPE, generateTypeID = _require7.generateTypeID;
	require_areEqual();
	var invariant = require_invariant();
	require_warning();
	function normalize(recordSource, selector, response, options, errors, useExecTimeResolvers) {
		var dataID = selector.dataID, node = selector.node, variables = selector.variables;
		return new RelayResponseNormalizer(recordSource, variables, options, useExecTimeResolvers !== null && useExecTimeResolvers !== void 0 ? useExecTimeResolvers : false).normalizeResponse(node, dataID, response, errors);
	}
	var RelayResponseNormalizer = /* @__PURE__ */ function() {
		function RelayResponseNormalizer(recordSource, variables, options, useExecTimeResolvers) {
			this._actorIdentifier = options.actorIdentifier;
			this._getDataId = options.getDataID;
			this._handleFieldPayloads = [];
			this._treatMissingFieldsAsNull = options.treatMissingFieldsAsNull;
			this._incrementalPlaceholders = [];
			this._isClientExtension = false;
			this._isUnmatchedAbstractType = false;
			this._useExecTimeResolvers = useExecTimeResolvers;
			this._followupPayloads = [];
			this._path = options.path ? (0, _toConsumableArray2["default"])(options.path) : [];
			this._recordSource = recordSource;
			this._variables = variables;
			this._shouldProcessClientComponents = options.shouldProcessClientComponents;
			this._log = options.log;
		}
		var _proto = RelayResponseNormalizer.prototype;
		_proto.normalizeResponse = function normalizeResponse(node, dataID, data, errors) {
			var record = this._recordSource.get(dataID);
			!record && invariant(false);
			this._assignClientAbstractTypes(node);
			this._errorTrie = buildErrorTrie(errors);
			this._traverseSelections(node, record, data);
			return {
				errors,
				fieldPayloads: this._handleFieldPayloads,
				incrementalPlaceholders: this._incrementalPlaceholders,
				followupPayloads: this._followupPayloads,
				source: this._recordSource,
				isFinal: false
			};
		};
		_proto._assignClientAbstractTypes = function _assignClientAbstractTypes(node) {
			var clientAbstractTypes = node.clientAbstractTypes;
			if (clientAbstractTypes != null) for (var _i = 0, _Object$keys = Object.keys(clientAbstractTypes); _i < _Object$keys.length; _i++) {
				var abstractType = _Object$keys[_i];
				var _iterator = (0, _createForOfIteratorHelper2["default"])(clientAbstractTypes[abstractType]), _step;
				try {
					for (_iterator.s(); !(_step = _iterator.n()).done;) {
						var concreteType = _step.value;
						var typeID = generateTypeID(concreteType);
						var typeRecord = this._recordSource.get(typeID);
						if (typeRecord == null) {
							typeRecord = RelayModernRecord.create(typeID, TYPE_SCHEMA_TYPE);
							this._recordSource.set(typeID, typeRecord);
						}
						RelayModernRecord.setValue(typeRecord, abstractType, true);
					}
				} catch (err) {
					_iterator.e(err);
				} finally {
					_iterator.f();
				}
			}
		};
		_proto._getVariableValue = function _getVariableValue(name) {
			!this._variables.hasOwnProperty(name) && invariant(false);
			return this._variables[name];
		};
		_proto._getRecordType = function _getRecordType(data) {
			var typeName = data[TYPENAME_KEY];
			!(typeName != null) && invariant(false);
			return typeName;
		};
		_proto._traverseSelections = function _traverseSelections(node, record, data) {
			for (var i = 0; i < node.selections.length; i++) {
				var selection = node.selections[i];
				switch (selection.kind) {
					case "ScalarField":
					case "LinkedField":
						this._normalizeField(selection, record, data);
						break;
					case "Condition":
						if (Boolean(this._getVariableValue(selection.condition)) === selection.passingValue) this._traverseSelections(selection, record, data);
						break;
					case "FragmentSpread":
						var prevVariables = this._variables;
						this._variables = getLocalVariables(this._variables, selection.fragment.argumentDefinitions, selection.args);
						this._traverseSelections(selection.fragment, record, data);
						this._variables = prevVariables;
						break;
					case "InlineFragment":
						var abstractKey = selection.abstractKey;
						if (abstractKey == null) {
							if (RelayModernRecord.getType(record) === selection.type) this._traverseSelections(selection, record, data);
						} else {
							var implementsInterface = Object.prototype.hasOwnProperty.call(data, abstractKey);
							var typeID = generateTypeID(RelayModernRecord.getType(record));
							var typeRecord = this._recordSource.get(typeID);
							if (typeRecord == null) {
								typeRecord = RelayModernRecord.create(typeID, TYPE_SCHEMA_TYPE);
								this._recordSource.set(typeID, typeRecord);
							}
							RelayModernRecord.setValue(typeRecord, abstractKey, implementsInterface);
							if (implementsInterface) this._traverseSelections(selection, record, data);
						}
						break;
					case "TypeDiscriminator":
						var _abstractKey = selection.abstractKey;
						var _implementsInterface = Object.prototype.hasOwnProperty.call(data, _abstractKey);
						var _typeID = generateTypeID(RelayModernRecord.getType(record));
						var _typeRecord = this._recordSource.get(_typeID);
						if (_typeRecord == null) {
							_typeRecord = RelayModernRecord.create(_typeID, TYPE_SCHEMA_TYPE);
							this._recordSource.set(_typeID, _typeRecord);
						}
						RelayModernRecord.setValue(_typeRecord, _abstractKey, _implementsInterface);
						break;
					case "LinkedHandle":
					case "ScalarHandle":
						var args = selection.args ? getArgumentValues(selection.args, this._variables) : {};
						var fieldKey = getStorageKey(selection, this._variables);
						var handleKey = getHandleStorageKey(selection, this._variables);
						this._handleFieldPayloads.push({
							args,
							dataID: RelayModernRecord.getDataID(record),
							fieldKey,
							handle: selection.handle,
							handleKey,
							handleArgs: selection.handleArgs ? getArgumentValues(selection.handleArgs, this._variables) : {}
						});
						break;
					case "ModuleImport":
						this._normalizeModuleImport(selection, record, data);
						break;
					case "Defer":
						this._normalizeDefer(selection, record, data);
						break;
					case "Stream":
						this._normalizeStream(selection, record, data);
						break;
					case "ClientExtension":
						var isClientExtension = this._isClientExtension;
						this._isClientExtension = true;
						this._traverseSelections(selection, record, data);
						this._isClientExtension = isClientExtension;
						break;
					case "ClientComponent":
						if (this._shouldProcessClientComponents === false) break;
						this._traverseSelections(selection.fragment, record, data);
						break;
					case "ActorChange":
						this._normalizeActorChange(selection, record, data);
						break;
					case "RelayResolver":
					case "RelayLiveResolver":
						if (!this._useExecTimeResolvers) this._normalizeResolver(selection, record, data);
						break;
					case "ClientEdgeToClientObject":
						if (!this._useExecTimeResolvers) this._normalizeResolver(selection.backingField, record, data);
						break;
					default: invariant(false);
				}
			}
		};
		_proto._normalizeResolver = function _normalizeResolver(resolver, record, data) {
			if (resolver.fragment != null) this._traverseSelections(resolver.fragment, record, data);
		};
		_proto._normalizeDefer = function _normalizeDefer(defer, record, data) {
			if ((defer["if"] === null || this._getVariableValue(defer["if"])) === false) this._traverseSelections(defer, record, data);
			else this._incrementalPlaceholders.push({
				kind: "defer",
				data,
				label: defer.label,
				path: (0, _toConsumableArray2["default"])(this._path),
				selector: createNormalizationSelector(defer, RelayModernRecord.getDataID(record), this._variables),
				typeName: RelayModernRecord.getType(record),
				actorIdentifier: this._actorIdentifier
			});
		};
		_proto._normalizeStream = function _normalizeStream(stream, record, data) {
			this._traverseSelections(stream, record, data);
			if ((stream["if"] === null || this._getVariableValue(stream["if"])) === true) this._incrementalPlaceholders.push({
				kind: "stream",
				label: stream.label,
				path: (0, _toConsumableArray2["default"])(this._path),
				parentID: RelayModernRecord.getDataID(record),
				node: stream,
				variables: this._variables,
				actorIdentifier: this._actorIdentifier
			});
		};
		_proto._normalizeModuleImport = function _normalizeModuleImport(moduleImport, record, data) {
			!(typeof data === "object" && data) && invariant(false);
			var typeName = RelayModernRecord.getType(record);
			var componentKey = getModuleComponentKey(moduleImport.documentName);
			var componentReference = moduleImport.componentModuleProvider || data[componentKey];
			RelayModernRecord.setValue(record, componentKey, componentReference !== null && componentReference !== void 0 ? componentReference : null);
			var operationKey = getModuleOperationKey(moduleImport.documentName);
			var operationReference = moduleImport.operationModuleProvider || data[operationKey];
			RelayModernRecord.setValue(record, operationKey, operationReference !== null && operationReference !== void 0 ? operationReference : null);
			if (operationReference != null) this._followupPayloads.push({
				kind: "ModuleImportPayload",
				args: moduleImport.args,
				data,
				dataID: RelayModernRecord.getDataID(record),
				operationReference,
				path: (0, _toConsumableArray2["default"])(this._path),
				typeName,
				variables: this._variables,
				actorIdentifier: this._actorIdentifier
			});
		};
		_proto._normalizeField = function _normalizeField(selection, record, data) {
			!(typeof data === "object" && data) && invariant(false);
			var responseKey = selection.alias || selection.name;
			var storageKey = getStorageKey(selection, this._variables);
			var fieldValue = data[responseKey];
			var isNoncompliantlyNullish = RelayFeatureFlags.ENABLE_NONCOMPLIANT_ERROR_HANDLING_ON_LISTS && Array.isArray(fieldValue) && fieldValue.length === 0;
			if (fieldValue == null || isNoncompliantlyNullish) {
				if (fieldValue === void 0) {
					if (this._isClientExtension || this._isUnmatchedAbstractType) return;
					else if (!this._treatMissingFieldsAsNull) return;
				}
				if (selection.kind === "ScalarField") this._validateConflictingFieldsWithIdenticalId(record, storageKey, null);
				if (isNoncompliantlyNullish) if (selection.kind === "LinkedField") RelayModernRecord.setLinkedRecordIDs(record, storageKey, []);
				else RelayModernRecord.setValue(record, storageKey, []);
				else RelayModernRecord.setValue(record, storageKey, null);
				var errorTrie = this._errorTrie;
				if (errorTrie != null) {
					var errors = getErrorsByKey(errorTrie, responseKey);
					if (errors != null) RelayModernRecord.setErrors(record, storageKey, errors);
				}
				return;
			}
			if (selection.kind === "ScalarField") {
				this._validateConflictingFieldsWithIdenticalId(record, storageKey, fieldValue);
				RelayModernRecord.setValue(record, storageKey, fieldValue);
			} else if (selection.kind === "LinkedField") {
				this._path.push(responseKey);
				var oldErrorTrie = this._errorTrie;
				this._errorTrie = oldErrorTrie == null ? null : getNestedErrorTrieByKey(oldErrorTrie, responseKey);
				if (selection.plural) this._normalizePluralLink(selection, record, storageKey, fieldValue);
				else this._normalizeLink(selection, record, storageKey, fieldValue);
				this._errorTrie = oldErrorTrie;
				this._path.pop();
			} else invariant(false);
		};
		_proto._normalizeActorChange = function _normalizeActorChange(selection, record, data) {
			var _field$concreteType;
			var field = selection.linkedField;
			!(typeof data === "object" && data) && invariant(false);
			var responseKey = field.alias || field.name;
			var storageKey = getStorageKey(field, this._variables);
			var fieldValue = data[responseKey];
			if (fieldValue == null) {
				if (fieldValue === void 0) {
					if (this._isClientExtension || this._isUnmatchedAbstractType) return;
					else if (!this._treatMissingFieldsAsNull) return;
				}
				RelayModernRecord.setValue(record, storageKey, null);
				return;
			}
			var actorIdentifier = getActorIdentifierFromPayload(fieldValue);
			if (actorIdentifier == null) {
				RelayModernRecord.setValue(record, storageKey, null);
				return;
			}
			var typeName = (_field$concreteType = field.concreteType) !== null && _field$concreteType !== void 0 ? _field$concreteType : this._getRecordType(fieldValue);
			var nextID = this._getDataId(fieldValue, typeName) || RelayModernRecord.getLinkedRecordID(record, storageKey) || generateClientID(RelayModernRecord.getDataID(record), storageKey);
			!(typeof nextID === "string") && invariant(false);
			RelayModernRecord.setActorLinkedRecordID(record, storageKey, actorIdentifier, nextID);
			this._followupPayloads.push({
				kind: "ActorPayload",
				data: fieldValue,
				dataID: nextID,
				path: [].concat((0, _toConsumableArray2["default"])(this._path), [responseKey]),
				typeName,
				variables: this._variables,
				node: field,
				actorIdentifier
			});
		};
		_proto._normalizeLink = function _normalizeLink(field, record, storageKey, fieldValue) {
			var _field$concreteType2;
			!(typeof fieldValue === "object" && fieldValue) && invariant(false);
			var nextID = this._getDataId(fieldValue, (_field$concreteType2 = field.concreteType) !== null && _field$concreteType2 !== void 0 ? _field$concreteType2 : this._getRecordType(fieldValue)) || RelayModernRecord.getLinkedRecordID(record, storageKey) || generateClientID(RelayModernRecord.getDataID(record), storageKey);
			!(typeof nextID === "string") && invariant(false);
			this._validateConflictingLinkedFieldsWithIdenticalId(RelayModernRecord.getLinkedRecordID(record, storageKey), nextID, storageKey);
			RelayModernRecord.setLinkedRecordID(record, storageKey, nextID);
			var nextRecord = this._recordSource.get(nextID);
			if (!nextRecord) {
				var typeName = field.concreteType || this._getRecordType(fieldValue);
				nextRecord = RelayModernRecord.create(nextID, typeName);
				this._recordSource.set(nextID, nextRecord);
			} else this._validateRecordType(nextRecord, field, fieldValue);
			this._traverseSelections(field, nextRecord, fieldValue);
		};
		_proto._normalizePluralLink = function _normalizePluralLink(field, record, storageKey, fieldValue) {
			var _this = this;
			!Array.isArray(fieldValue) && invariant(false);
			var prevIDs = RelayModernRecord.getLinkedRecordIDs(record, storageKey);
			var nextIDs = [];
			fieldValue.forEach(function(item, nextIndex) {
				var _field$concreteType3;
				if (item == null) {
					nextIDs.push(item);
					return;
				}
				_this._path.push(String(nextIndex));
				var oldErrorTrie = _this._errorTrie;
				_this._errorTrie = oldErrorTrie == null ? null : getNestedErrorTrieByKey(oldErrorTrie, nextIndex);
				!(typeof item === "object") && invariant(false);
				var nextID = _this._getDataId(item, (_field$concreteType3 = field.concreteType) !== null && _field$concreteType3 !== void 0 ? _field$concreteType3 : _this._getRecordType(item)) || prevIDs && prevIDs[nextIndex] || generateClientID(RelayModernRecord.getDataID(record), storageKey, nextIndex);
				!(typeof nextID === "string") && invariant(false);
				nextIDs.push(nextID);
				var nextRecord = _this._recordSource.get(nextID);
				if (!nextRecord) {
					var typeName = field.concreteType || _this._getRecordType(item);
					nextRecord = RelayModernRecord.create(nextID, typeName);
					_this._recordSource.set(nextID, nextRecord);
				} else _this._validateRecordType(nextRecord, field, item);
				if (prevIDs) _this._validateConflictingLinkedFieldsWithIdenticalId(prevIDs[nextIndex], nextID, storageKey);
				_this._traverseSelections(field, nextRecord, item);
				_this._errorTrie = oldErrorTrie;
				_this._path.pop();
			});
			RelayModernRecord.setLinkedRecordIDs(record, storageKey, nextIDs);
		};
		_proto._validateRecordType = function _validateRecordType(record, field, payload) {
			if (RelayFeatureFlags.ENABLE_STORE_ID_COLLISION_LOGGING) {
				var _field$concreteType4;
				var typeName = (_field$concreteType4 = field.concreteType) !== null && _field$concreteType4 !== void 0 ? _field$concreteType4 : this._getRecordType(payload);
				var dataID = RelayModernRecord.getDataID(record);
				if (!(isClientID(dataID) && dataID !== ROOT_ID || RelayModernRecord.getType(record) === typeName)) {
					var logEvent = {
						name: "idCollision.typename",
						previous_typename: RelayModernRecord.getType(record),
						new_typename: typeName
					};
					if (this._log != null) this._log(logEvent);
				}
			}
		};
		_proto._validateConflictingFieldsWithIdenticalId = function _validateConflictingFieldsWithIdenticalId(record, storageKey, fieldValue) {};
		_proto._validateConflictingLinkedFieldsWithIdenticalId = function _validateConflictingLinkedFieldsWithIdenticalId(prevID, nextID, storageKey) {};
		return RelayResponseNormalizer;
	}();
	module.exports = { normalize };
}));
var require_normalizeResponse = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _RelayModernRecord = _interopRequireDefault(require_RelayModernRecord());
	var _RelayRecordSource = _interopRequireDefault(require_RelayRecordSource());
	var _RelayResponseNormalizer = _interopRequireDefault(require_RelayResponseNormalizer());
	function normalizeResponse(response, selector, typeName, options, useExecTimeResolvers) {
		var _response$extensions;
		var data = response.data, errors = response.errors;
		var source = _RelayRecordSource["default"].create();
		var record = _RelayModernRecord["default"].create(selector.dataID, typeName);
		source.set(selector.dataID, record);
		var relayPayload = _RelayResponseNormalizer["default"].normalize(source, selector, data, options, errors, useExecTimeResolvers);
		return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, relayPayload), {}, { isFinal: ((_response$extensions = response.extensions) === null || _response$extensions === void 0 ? void 0 : _response$extensions.is_final) === true });
	}
	module.exports = normalizeResponse;
}));
var require_readInlineData = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getInlineDataFragment = require_GraphQLTag().getInlineDataFragment;
	var FRAGMENTS_KEY = require_RelayStoreUtils().FRAGMENTS_KEY;
	var invariant = require_invariant();
	function readInlineData(fragment, fragmentRef) {
		var _fragmentRef$FRAGMENT;
		var inlineDataFragment = getInlineDataFragment(fragment);
		if (fragmentRef == null) return fragmentRef;
		!(typeof fragmentRef === "object") && invariant(false);
		var inlineData = (_fragmentRef$FRAGMENT = fragmentRef[FRAGMENTS_KEY]) === null || _fragmentRef$FRAGMENT === void 0 ? void 0 : _fragmentRef$FRAGMENT[inlineDataFragment.name];
		!(inlineData != null) && invariant(false);
		return inlineData;
	}
	module.exports = readInlineData;
}));
var require_generateID = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var id = 1e5;
	function generateID() {
		return id++;
	}
	module.exports = generateID;
}));
var require_wrapNetworkWithLogObserver = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var generateID = require_generateID();
	function wrapNetworkWithLogObserver(env, network) {
		return { execute: function execute(params, variables, cacheConfig, uploadables, _, encryptedVariables, preprocessResponse, checkOperation) {
			var networkRequestId = generateID();
			return network.execute(params, variables, cacheConfig, uploadables, function logRequestInfo(info) {
				env.__log({
					name: "network.info",
					networkRequestId,
					info
				});
			}, encryptedVariables, preprocessResponse, checkOperation)["do"]({
				start: function start(subscription) {
					env.__log({
						name: "network.start",
						networkRequestId,
						params,
						variables,
						cacheConfig
					});
				},
				next: function next(response) {
					env.__log({
						name: "network.next",
						networkRequestId,
						response
					});
				},
				error: function error(_error) {
					env.__log({
						name: "network.error",
						networkRequestId,
						error: _error
					});
				},
				complete: function complete() {
					env.__log({
						name: "network.complete",
						networkRequestId
					});
				},
				unsubscribe: function unsubscribe() {
					env.__log({
						name: "network.unsubscribe",
						networkRequestId
					});
				}
			});
		} };
	}
	module.exports = wrapNetworkWithLogObserver;
}));
var require_RelayOperationTracker = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var invariant = require_invariant();
	module.exports = /* @__PURE__ */ function() {
		function RelayOperationTracker() {
			this._ownersToPendingOperations = /* @__PURE__ */ new Map();
			this._pendingOperationsToOwners = /* @__PURE__ */ new Map();
			this._ownersToPendingPromise = /* @__PURE__ */ new Map();
		}
		var _proto = RelayOperationTracker.prototype;
		_proto.update = function update(pendingOperation, affectedOwners) {
			if (affectedOwners.size === 0) return;
			var pendingOperationIdentifier = pendingOperation.identifier;
			var newlyAffectedOwnersIdentifier = /* @__PURE__ */ new Set();
			var _iterator = (0, _createForOfIteratorHelper2["default"])(affectedOwners), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var ownerIdentifier = _step.value.identifier;
					var pendingOperationsAffectingOwner = this._ownersToPendingOperations.get(ownerIdentifier);
					if (pendingOperationsAffectingOwner != null) {
						if (!pendingOperationsAffectingOwner.has(pendingOperationIdentifier)) {
							pendingOperationsAffectingOwner.set(pendingOperationIdentifier, pendingOperation);
							newlyAffectedOwnersIdentifier.add(ownerIdentifier);
						}
					} else {
						this._ownersToPendingOperations.set(ownerIdentifier, new Map([[pendingOperationIdentifier, pendingOperation]]));
						newlyAffectedOwnersIdentifier.add(ownerIdentifier);
					}
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			if (newlyAffectedOwnersIdentifier.size === 0) return;
			var ownersAffectedByPendingOperation = this._pendingOperationsToOwners.get(pendingOperationIdentifier) || /* @__PURE__ */ new Set();
			var _iterator2 = (0, _createForOfIteratorHelper2["default"])(newlyAffectedOwnersIdentifier), _step2;
			try {
				for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
					var _ownerIdentifier = _step2.value;
					this._resolveOwnerResolvers(_ownerIdentifier);
					ownersAffectedByPendingOperation.add(_ownerIdentifier);
				}
			} catch (err) {
				_iterator2.e(err);
			} finally {
				_iterator2.f();
			}
			this._pendingOperationsToOwners.set(pendingOperationIdentifier, ownersAffectedByPendingOperation);
		};
		_proto.complete = function complete(pendingOperation) {
			var pendingOperationIdentifier = pendingOperation.identifier;
			var affectedOwnersIdentifier = this._pendingOperationsToOwners.get(pendingOperationIdentifier);
			if (affectedOwnersIdentifier == null) return;
			var completedOwnersIdentifier = /* @__PURE__ */ new Set();
			var updatedOwnersIdentifier = /* @__PURE__ */ new Set();
			var _iterator3 = (0, _createForOfIteratorHelper2["default"])(affectedOwnersIdentifier), _step3;
			try {
				for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
					var ownerIdentifier = _step3.value;
					var pendingOperationsAffectingOwner = this._ownersToPendingOperations.get(ownerIdentifier);
					if (!pendingOperationsAffectingOwner) continue;
					pendingOperationsAffectingOwner["delete"](pendingOperationIdentifier);
					if (pendingOperationsAffectingOwner.size > 0) updatedOwnersIdentifier.add(ownerIdentifier);
					else completedOwnersIdentifier.add(ownerIdentifier);
				}
			} catch (err) {
				_iterator3.e(err);
			} finally {
				_iterator3.f();
			}
			var _iterator4 = (0, _createForOfIteratorHelper2["default"])(completedOwnersIdentifier), _step4;
			try {
				for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
					var _ownerIdentifier2 = _step4.value;
					this._resolveOwnerResolvers(_ownerIdentifier2);
					this._ownersToPendingOperations["delete"](_ownerIdentifier2);
				}
			} catch (err) {
				_iterator4.e(err);
			} finally {
				_iterator4.f();
			}
			var _iterator5 = (0, _createForOfIteratorHelper2["default"])(updatedOwnersIdentifier), _step5;
			try {
				for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
					var _ownerIdentifier3 = _step5.value;
					this._resolveOwnerResolvers(_ownerIdentifier3);
				}
			} catch (err) {
				_iterator5.e(err);
			} finally {
				_iterator5.f();
			}
			this._pendingOperationsToOwners["delete"](pendingOperationIdentifier);
		};
		_proto._resolveOwnerResolvers = function _resolveOwnerResolvers(ownerIdentifier) {
			var promiseEntry = this._ownersToPendingPromise.get(ownerIdentifier);
			if (promiseEntry != null) promiseEntry.resolve();
			this._ownersToPendingPromise["delete"](ownerIdentifier);
		};
		_proto.getPendingOperationsAffectingOwner = function getPendingOperationsAffectingOwner(owner) {
			var ownerIdentifier = owner.identifier;
			var pendingOperationsForOwner = this._ownersToPendingOperations.get(ownerIdentifier);
			if (pendingOperationsForOwner == null || pendingOperationsForOwner.size === 0) return null;
			var cachedPromiseEntry = this._ownersToPendingPromise.get(ownerIdentifier);
			if (cachedPromiseEntry != null) return {
				promise: cachedPromiseEntry.promise,
				pendingOperations: cachedPromiseEntry.pendingOperations
			};
			var resolve;
			var promise = new Promise(function(r) {
				resolve = r;
			});
			!(resolve != null) && invariant(false);
			var pendingOperations = Array.from(pendingOperationsForOwner.values());
			this._ownersToPendingPromise.set(ownerIdentifier, {
				promise,
				resolve,
				pendingOperations
			});
			return {
				promise,
				pendingOperations
			};
		};
		return RelayOperationTracker;
	}();
}));
var require_registerEnvironmentWithDevTools = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function registerEnvironmentWithDevTools(environment) {
		var _global = typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : void 0;
		var devToolsHook = _global && _global.__RELAY_DEVTOOLS_HOOK__;
		if (devToolsHook) devToolsHook.registerEnvironment(environment);
	}
	module.exports = registerEnvironmentWithDevTools;
}));
var require_ViewerPattern = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var generateClientID = require_ClientID().generateClientID;
	var ROOT_ID = require_RelayStoreUtils().ROOT_ID;
	module.exports = {
		VIEWER_ID: generateClientID(ROOT_ID, "viewer"),
		VIEWER_TYPE: "Viewer"
	};
}));
var require_defaultGetDataID = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _require = require_ViewerPattern(), VIEWER_ID = _require.VIEWER_ID, VIEWER_TYPE = _require.VIEWER_TYPE;
	function defaultGetDataID(fieldValue, typeName) {
		if (typeName === VIEWER_TYPE) return fieldValue.id == null ? VIEWER_ID : fieldValue.id;
		return fieldValue.id;
	}
	module.exports = defaultGetDataID;
}));
var require_defaultRelayFieldLogger = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = function defaultRelayFieldLogger(event) {};
}));
var require_getOperation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _require = require_RelayConcreteNode(), REQUEST = _require.REQUEST, SPLIT_OPERATION = _require.SPLIT_OPERATION;
	function getOperation(node) {
		switch (node.kind) {
			case REQUEST: return node.operation;
			case SPLIT_OPERATION:
			default: return node;
		}
	}
	module.exports = getOperation;
}));
var require_RelayError = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function createError(type, name, messageFormat) {
		for (var _len = arguments.length, messageParams = new Array(_len > 3 ? _len - 3 : 0), _key = 3; _key < _len; _key++) messageParams[_key - 3] = arguments[_key];
		var index = 0;
		var message = messageFormat.replace(/%s/g, function() {
			return String(messageParams[index++]);
		});
		var err = new Error(message);
		var error = Object.assign(err, {
			name,
			messageFormat,
			messageParams,
			type,
			taalOpcodes: [2, 2]
		});
		if (error.stack === void 0) try {
			throw error;
		} catch (_unused) {}
		return error;
	}
	module.exports = {
		create: function create(name, messageFormat) {
			for (var _len2 = arguments.length, messageParams = new Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) messageParams[_key2 - 2] = arguments[_key2];
			return createError.apply(void 0, [
				"error",
				name,
				messageFormat
			].concat(messageParams));
		},
		createWarning: function createWarning(name, messageFormat) {
			for (var _len3 = arguments.length, messageParams = new Array(_len3 > 2 ? _len3 - 2 : 0), _key3 = 2; _key3 < _len3; _key3++) messageParams[_key3 - 2] = arguments[_key3];
			return createError.apply(void 0, [
				"warn",
				name,
				messageFormat
			].concat(messageParams));
		}
	};
}));
var require_withStartAndDuration = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _window, _window$performance;
	var isPerformanceNowAvailable = typeof window !== "undefined" && typeof ((_window = window) === null || _window === void 0 ? void 0 : (_window$performance = _window.performance) === null || _window$performance === void 0 ? void 0 : _window$performance.now) === "function";
	function currentTimestamp() {
		if (isPerformanceNowAvailable) return window.performance.now();
		return Date.now();
	}
	function withStartAndDuration(cb) {
		var startTime = currentTimestamp();
		var result = cb();
		return [
			startTime,
			currentTimestamp() - startTime,
			result
		];
	}
	module.exports = withStartAndDuration;
}));
var require_OperationExecutor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var RelayObservable = require_RelayObservable();
	var generateID = require_generateID();
	var getOperation = require_getOperation();
	var RelayError = require_RelayError();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var stableCopy = require_stableCopy().stableCopy;
	var withStartAndDuration = require_withStartAndDuration();
	var _require2 = require_ClientID(), generateClientID = _require2.generateClientID, generateUniqueClientID = _require2.generateUniqueClientID;
	var getLocalVariables = require_RelayConcreteVariables().getLocalVariables;
	var RelayModernRecord = require_RelayModernRecord();
	var _require4 = require_RelayModernSelector(), createNormalizationSelector = _require4.createNormalizationSelector, createReaderSelector = _require4.createReaderSelector;
	var RelayRecordSource = require_RelayRecordSource();
	var _require5 = require_RelayStoreUtils(), ROOT_TYPE = _require5.ROOT_TYPE, TYPENAME_KEY = _require5.TYPENAME_KEY, getStorageKey = _require5.getStorageKey;
	var invariant = require_invariant();
	require_warning();
	function execute(config) {
		return new Executor(config);
	}
	var Executor = /* @__PURE__ */ function() {
		function Executor(_ref3) {
			var _this = this;
			var _ref, _this$_operation$requ, _this$_operation$requ2;
			var actorIdentifier = _ref3.actorIdentifier, getDataID = _ref3.getDataID, getPublishQueue = _ref3.getPublishQueue, getStore = _ref3.getStore, isClientPayload = _ref3.isClientPayload, operation = _ref3.operation, operationExecutions = _ref3.operationExecutions, operationLoader = _ref3.operationLoader, operationTracker = _ref3.operationTracker, optimisticConfig = _ref3.optimisticConfig, scheduler = _ref3.scheduler, shouldProcessClientComponents = _ref3.shouldProcessClientComponents, sink = _ref3.sink, source = _ref3.source, treatMissingFieldsAsNull = _ref3.treatMissingFieldsAsNull, updater = _ref3.updater, log = _ref3.log, normalizeResponse = _ref3.normalizeResponse;
			this._actorIdentifier = actorIdentifier;
			this._getDataID = getDataID;
			this._treatMissingFieldsAsNull = treatMissingFieldsAsNull;
			this._incrementalPayloadsPending = false;
			this._incrementalResults = /* @__PURE__ */ new Map();
			this._log = log;
			this._executeId = generateID();
			this._nextSubscriptionId = 0;
			this._operation = operation;
			this._operationExecutions = operationExecutions;
			this._operationLoader = operationLoader;
			this._operationTracker = operationTracker;
			this._operationUpdateEpochs = /* @__PURE__ */ new Map();
			this._optimisticUpdates = null;
			this._useExecTimeResolvers = (_ref = (_this$_operation$requ = this._operation.request.node.operation.use_exec_time_resolvers) !== null && _this$_operation$requ !== void 0 ? _this$_operation$requ : ((_this$_operation$requ2 = this._operation.request.node.operation.exec_time_resolvers_enabled_provider) === null || _this$_operation$requ2 === void 0 ? void 0 : _this$_operation$requ2.get()) === true) !== null && _ref !== void 0 ? _ref : false;
			this._execTimeResolverResponseComplete = false;
			this._pendingModulePayloadsCount = 0;
			this._getPublishQueue = getPublishQueue;
			this._scheduler = scheduler;
			this._sink = sink;
			this._source = /* @__PURE__ */ new Map();
			this._state = "started";
			this._getStore = getStore;
			this._subscriptions = /* @__PURE__ */ new Map();
			this._updater = updater;
			this._isClientPayload = isClientPayload === true;
			this._isSubscriptionOperation = this._operation.request.node.params.operationKind === "subscription";
			this._shouldProcessClientComponents = shouldProcessClientComponents;
			this._retainDisposables = /* @__PURE__ */ new Map();
			this._seenActors = /* @__PURE__ */ new Set();
			this._completeFns = [];
			this._normalizeResponse = normalizeResponse;
			var id = this._nextSubscriptionId++;
			if (RelayFeatureFlags.PROCESS_OPTIMISTIC_UPDATE_BEFORE_SUBSCRIPTION && optimisticConfig != null) this._processOptimisticResponse(optimisticConfig.response != null ? { data: optimisticConfig.response } : null, optimisticConfig.updater, false);
			source.subscribe({
				complete: function complete() {
					return _this._complete(id);
				},
				error: function error(_error2) {
					return _this._error(_error2);
				},
				next: function next(response) {
					try {
						_this._next(id, response);
					} catch (error) {
						sink.error(error);
					}
				},
				start: function start(subscription) {
					var _this$_operation$requ3;
					_this._start(id, subscription);
					_this._log({
						name: "execute.start",
						executeId: _this._executeId,
						params: _this._operation.request.node.params,
						variables: _this._operation.request.variables,
						cacheConfig: (_this$_operation$requ3 = _this._operation.request.cacheConfig) !== null && _this$_operation$requ3 !== void 0 ? _this$_operation$requ3 : {}
					});
				},
				unsubscribe: function unsubscribe() {
					_this._log({
						name: "execute.unsubscribe",
						executeId: _this._executeId
					});
				}
			});
			if (!RelayFeatureFlags.PROCESS_OPTIMISTIC_UPDATE_BEFORE_SUBSCRIPTION && optimisticConfig != null) this._processOptimisticResponse(optimisticConfig.response != null ? { data: optimisticConfig.response } : null, optimisticConfig.updater, false);
		}
		var _proto = Executor.prototype;
		_proto.cancel = function cancel() {
			var _this2 = this;
			if (this._state === "completed") return;
			this._state = "completed";
			this._operationExecutions["delete"](this._operation.request.identifier);
			if (this._subscriptions.size !== 0) {
				this._subscriptions.forEach(function(sub) {
					return sub.unsubscribe();
				});
				this._subscriptions.clear();
			}
			var optimisticUpdates = this._optimisticUpdates;
			if (optimisticUpdates !== null) {
				this._optimisticUpdates = null;
				optimisticUpdates.forEach(function(update) {
					return _this2._getPublishQueueAndSaveActor().revertUpdate(update);
				});
				this._runPublishQueue();
			}
			this._incrementalResults.clear();
			if (this._asyncStoreUpdateDisposable != null) {
				this._asyncStoreUpdateDisposable.dispose();
				this._asyncStoreUpdateDisposable = null;
			}
			this._completeFns = [];
			this._completeOperationTracker();
			this._disposeRetainedData();
		};
		_proto._updateActiveState = function _updateActiveState() {
			var activeState;
			switch (this._state) {
				case "started":
					activeState = "active";
					break;
				case "loading_incremental":
					activeState = "active";
					break;
				case "completed":
					activeState = "inactive";
					break;
				case "loading_final":
					activeState = this._pendingModulePayloadsCount > 0 || this._useExecTimeResolvers && !this._execTimeResolverResponseComplete ? "active" : "inactive";
					break;
				default:
					this._state;
					invariant(false);
			}
			this._operationExecutions.set(this._operation.request.identifier, activeState);
		};
		_proto._schedule = function _schedule(task, priority) {
			var _this3 = this;
			var scheduler = this._scheduler;
			if (scheduler != null) {
				var id = this._nextSubscriptionId++;
				RelayObservable.create(function(sink) {
					var cancellationToken = scheduler.schedule(function() {
						try {
							task();
							sink.complete();
						} catch (error) {
							sink.error(error);
						}
					}, priority);
					return function() {
						return scheduler.cancel(cancellationToken);
					};
				}).subscribe({
					complete: function complete() {
						return _this3._complete(id);
					},
					error: function error(_error3) {
						return _this3._error(_error3);
					},
					start: function start(subscription) {
						return _this3._start(id, subscription);
					}
				});
			} else task();
		};
		_proto._complete = function _complete(id) {
			this._subscriptions["delete"](id);
			if (this._subscriptions.size === 0) {
				this.cancel();
				this._sink.complete();
				this._log({
					name: "execute.complete",
					executeId: this._executeId
				});
			}
		};
		_proto._error = function _error(error) {
			this.cancel();
			this._sink.error(error);
			this._log({
				name: "execute.error",
				executeId: this._executeId,
				error
			});
		};
		_proto._start = function _start(id, subscription) {
			this._subscriptions.set(id, subscription);
			this._updateActiveState();
		};
		_proto._next = function _next(_id, response) {
			var _this4 = this;
			var priority = this._state === "loading_incremental" ? "low" : "default";
			this._schedule(function() {
				_this4._log({
					name: "execute.next.start",
					executeId: _this4._executeId,
					response,
					operation: _this4._operation
				});
				_this4._handleNext(response);
				_this4._maybeCompleteSubscriptionOperationTracking();
				_this4._log({
					name: "execute.next.end",
					executeId: _this4._executeId,
					response,
					operation: _this4._operation
				});
			}, priority);
		};
		_proto._handleErrorResponse = function _handleErrorResponse(responses) {
			var _this5 = this;
			var results = [];
			responses.forEach(function(response) {
				if (response.data === null && response.extensions != null && !response.hasOwnProperty("errors")) return;
				else if (response.data == null) {
					var errors = response.hasOwnProperty("errors") && response.errors != null ? response.errors : null;
					var messages = errors ? errors.map(function(_ref4) {
						return _ref4.message;
					}).join("\n") : "(No errors)";
					var error = RelayError.create("RelayNetwork", "No data returned for operation `" + _this5._operation.request.node.params.name + "`, got error(s):\n" + messages + "\n\nSee the error `source` property for more information.");
					error.source = {
						errors,
						operation: _this5._operation.request.node,
						variables: _this5._operation.request.variables
					};
					error.stack;
					throw error;
				} else {
					var responseWithData = response;
					results.push(responseWithData);
				}
			});
			return results;
		};
		_proto._handleOptimisticResponses = function _handleOptimisticResponses(responses) {
			var _response$extensions;
			if (responses.length > 1) {
				if (responses.some(function(responsePart) {
					var _responsePart$extensi;
					return ((_responsePart$extensi = responsePart.extensions) === null || _responsePart$extensi === void 0 ? void 0 : _responsePart$extensi.isOptimistic) === true;
				})) invariant(false);
				return false;
			}
			var response = responses[0];
			var isOptimistic = ((_response$extensions = response.extensions) === null || _response$extensions === void 0 ? void 0 : _response$extensions.isOptimistic) === true;
			if (isOptimistic && this._state !== "started") invariant(false);
			if (isOptimistic) {
				this._processOptimisticResponse(response, null, this._treatMissingFieldsAsNull);
				this._sink.next(response);
				return true;
			}
			return false;
		};
		_proto._handleNext = function _handleNext(response) {
			if (this._state === "completed") return;
			this._seenActors.clear();
			var responses = Array.isArray(response) ? response : [response];
			var responsesWithData = this._handleErrorResponse(responses);
			if (responsesWithData.length === 0) {
				var isFinal = responses.some(function(x) {
					var _x$extensions;
					return ((_x$extensions = x.extensions) === null || _x$extensions === void 0 ? void 0 : _x$extensions.is_final) === true;
				});
				if (isFinal) {
					this._state = "loading_final";
					this._updateActiveState();
					this._incrementalPayloadsPending = false;
				}
				this._sink.next(response);
				return;
			}
			if (this._handleOptimisticResponses(responsesWithData)) return;
			var _partitionGraphQLResp = partitionGraphQLResponses(responsesWithData), nonIncrementalResponses = _partitionGraphQLResp[0], incrementalResponses = _partitionGraphQLResp[1], normalizedResponses = _partitionGraphQLResp[2];
			var hasNonIncrementalResponses = nonIncrementalResponses.length > 0;
			var hasNormalizedResponses = normalizedResponses.length > 0;
			if (hasNonIncrementalResponses) {
				if (this._isSubscriptionOperation) {
					var nextID = generateUniqueClientID();
					this._operation = {
						request: this._operation.request,
						fragment: createReaderSelector(this._operation.fragment.node, nextID, this._operation.fragment.variables, this._operation.fragment.owner),
						root: createNormalizationSelector(this._operation.root.node, nextID, this._operation.root.variables)
					};
				}
				var payloadFollowups = this._processResponses(nonIncrementalResponses);
				this._processPayloadFollowups(payloadFollowups);
			}
			if (hasNormalizedResponses) {
				var _payloadFollowups = [];
				for (var i = 0; i < normalizedResponses.length; i++) {
					var _response$extensions2;
					var _response = normalizedResponses[i];
					var source = new RelayRecordSource(_response.data);
					var isFinal = ((_response$extensions2 = _response.extensions) === null || _response$extensions2 === void 0 ? void 0 : _response$extensions2.is_final) === true;
					var payload = {
						errors: [],
						fieldPayloads: [],
						followupPayloads: [],
						incrementalPlaceholders: [],
						isFinal,
						source
					};
					this._getPublishQueueAndSaveActor().commitPayload(this._operation, payload, this._updater);
					_payloadFollowups.push(payload);
					this._execTimeResolverResponseComplete = isFinal;
					if (isFinal) this._updateActiveState();
				}
			}
			if (incrementalResponses.length > 0) {
				var _payloadFollowups2 = this._processIncrementalResponses(incrementalResponses);
				this._processPayloadFollowups(_payloadFollowups2);
			}
			if (this._isSubscriptionOperation) if (responsesWithData[0].extensions == null) responsesWithData[0].extensions = { __relay_subscription_root_id: this._operation.fragment.dataID };
			else responsesWithData[0].extensions.__relay_subscription_root_id = this._operation.fragment.dataID;
			var updatedOwners = this._runPublishQueue(hasNonIncrementalResponses || hasNormalizedResponses ? this._operation : void 0);
			if (hasNonIncrementalResponses) {
				if (this._incrementalPayloadsPending) this._retainData();
			}
			this._updateOperationTracker(updatedOwners);
			this._sink.next(response);
		};
		_proto._processOptimisticResponse = function _processOptimisticResponse(response, updater, treatMissingFieldsAsNull) {
			var _this6 = this;
			!(this._optimisticUpdates === null) && invariant(false);
			if (response == null && updater == null) return;
			var optimisticUpdates = [];
			if (response) {
				var payload = this._normalizeResponse(response, this._operation.root, ROOT_TYPE, {
					actorIdentifier: this._actorIdentifier,
					getDataID: this._getDataID,
					log: this._log,
					path: [],
					shouldProcessClientComponents: this._shouldProcessClientComponents,
					treatMissingFieldsAsNull
				}, this._useExecTimeResolvers);
				validateOptimisticResponsePayload(payload);
				optimisticUpdates.push({
					operation: this._operation,
					payload,
					updater
				});
				this._processOptimisticFollowups(payload, optimisticUpdates);
			} else if (updater) optimisticUpdates.push({
				operation: this._operation,
				payload: {
					errors: null,
					fieldPayloads: null,
					incrementalPlaceholders: null,
					followupPayloads: null,
					source: RelayRecordSource.create(),
					isFinal: false
				},
				updater
			});
			this._optimisticUpdates = optimisticUpdates;
			optimisticUpdates.forEach(function(update) {
				return _this6._getPublishQueueAndSaveActor().applyUpdate(update);
			});
			var updatedOwners = this._runPublishQueue();
			if (RelayFeatureFlags.ENABLE_OPERATION_TRACKER_OPTIMISTIC_UPDATES) this._updateOperationTracker(updatedOwners);
		};
		_proto._processOptimisticFollowups = function _processOptimisticFollowups(payload, optimisticUpdates) {
			if (payload.followupPayloads && payload.followupPayloads.length) {
				var followupPayloads = payload.followupPayloads;
				var _iterator = (0, _createForOfIteratorHelper2["default"])(followupPayloads), _step;
				try {
					for (_iterator.s(); !(_step = _iterator.n()).done;) {
						var followupPayload = _step.value;
						switch (followupPayload.kind) {
							case "ModuleImportPayload":
								var operation = this._expectOperationLoader().get(followupPayload.operationReference);
								if (operation == null) this._processAsyncOptimisticModuleImport(followupPayload);
								else {
									var moduleImportOptimisticUpdates = this._processOptimisticModuleImport(operation, followupPayload);
									optimisticUpdates.push.apply(optimisticUpdates, (0, _toConsumableArray2["default"])(moduleImportOptimisticUpdates));
								}
								break;
							case "ActorPayload": break;
							default: invariant(false);
						}
					}
				} catch (err) {
					_iterator.e(err);
				} finally {
					_iterator.f();
				}
			}
		};
		_proto._normalizeFollowupPayload = function _normalizeFollowupPayload(followupPayload, normalizationNode) {
			var variables;
			if (normalizationNode.kind === "SplitOperation" && followupPayload.kind === "ModuleImportPayload") variables = getLocalVariables(followupPayload.variables, normalizationNode.argumentDefinitions, followupPayload.args);
			else variables = followupPayload.variables;
			var selector = createNormalizationSelector(normalizationNode, followupPayload.dataID, variables);
			var nextResponse = {
				data: followupPayload.data,
				extensions: this._state === "loading_final" ? { is_final: true } : void 0
			};
			return this._normalizeResponse(nextResponse, selector, followupPayload.typeName, {
				actorIdentifier: this._actorIdentifier,
				getDataID: this._getDataID,
				log: this._log,
				path: followupPayload.path,
				treatMissingFieldsAsNull: this._treatMissingFieldsAsNull,
				shouldProcessClientComponents: this._shouldProcessClientComponents
			}, this._useExecTimeResolvers);
		};
		_proto._processOptimisticModuleImport = function _processOptimisticModuleImport(normalizationRootNode, moduleImportPayload) {
			var operation = getOperation(normalizationRootNode);
			var optimisticUpdates = [];
			var modulePayload = this._normalizeFollowupPayload(moduleImportPayload, operation);
			validateOptimisticResponsePayload(modulePayload);
			optimisticUpdates.push({
				operation: this._operation,
				payload: modulePayload,
				updater: null
			});
			this._processOptimisticFollowups(modulePayload, optimisticUpdates);
			return optimisticUpdates;
		};
		_proto._processAsyncOptimisticModuleImport = function _processAsyncOptimisticModuleImport(moduleImportPayload) {
			var _this7 = this;
			this._expectOperationLoader().load(moduleImportPayload.operationReference).then(function(operation) {
				if (operation == null || _this7._state !== "started") return;
				var moduleImportOptimisticUpdates = _this7._processOptimisticModuleImport(operation, moduleImportPayload);
				moduleImportOptimisticUpdates.forEach(function(update) {
					return _this7._getPublishQueueAndSaveActor().applyUpdate(update);
				});
				if (_this7._optimisticUpdates == null) {} else {
					var _this$_optimisticUpda;
					(_this$_optimisticUpda = _this7._optimisticUpdates).push.apply(_this$_optimisticUpda, (0, _toConsumableArray2["default"])(moduleImportOptimisticUpdates));
					_this7._runPublishQueue();
				}
			});
		};
		_proto._processResponses = function _processResponses(responses) {
			var _this8 = this;
			this._log({
				name: "execute.normalize.start",
				operation: this._operation
			});
			if (this._optimisticUpdates !== null) {
				this._optimisticUpdates.forEach(function(update) {
					_this8._getPublishQueueAndSaveActor().revertUpdate(update);
				});
				this._optimisticUpdates = null;
			}
			this._incrementalPayloadsPending = false;
			this._incrementalResults.clear();
			this._source.clear();
			return responses.map(function(payloadPart) {
				var relayPayload = _this8._normalizeResponse(payloadPart, _this8._operation.root, ROOT_TYPE, {
					actorIdentifier: _this8._actorIdentifier,
					getDataID: _this8._getDataID,
					log: _this8._log,
					path: [],
					treatMissingFieldsAsNull: _this8._treatMissingFieldsAsNull,
					shouldProcessClientComponents: _this8._shouldProcessClientComponents
				}, _this8._useExecTimeResolvers);
				_this8._getPublishQueueAndSaveActor().commitPayload(_this8._operation, relayPayload, _this8._updater);
				_this8._log({
					name: "execute.normalize.end",
					operation: _this8._operation
				});
				return relayPayload;
			});
		};
		_proto._processPayloadFollowups = function _processPayloadFollowups(payloads) {
			var _this9 = this;
			if (this._state === "completed") return;
			payloads.forEach(function(payload) {
				var incrementalPlaceholders = payload.incrementalPlaceholders, followupPayloads = payload.followupPayloads, isFinal = payload.isFinal;
				_this9._state = isFinal ? "loading_final" : "loading_incremental";
				_this9._updateActiveState();
				if (isFinal) _this9._incrementalPayloadsPending = false;
				if (followupPayloads && followupPayloads.length !== 0) followupPayloads.forEach(function(followupPayload) {
					var _followupPayload$acto;
					var prevActorIdentifier = _this9._actorIdentifier;
					_this9._actorIdentifier = (_followupPayload$acto = followupPayload.actorIdentifier) !== null && _followupPayload$acto !== void 0 ? _followupPayload$acto : _this9._actorIdentifier;
					_this9._processFollowupPayload(followupPayload);
					_this9._actorIdentifier = prevActorIdentifier;
				});
				if (incrementalPlaceholders && incrementalPlaceholders.length !== 0) {
					_this9._incrementalPayloadsPending = _this9._state !== "loading_final";
					incrementalPlaceholders.forEach(function(incrementalPlaceholder) {
						var _incrementalPlacehold;
						var prevActorIdentifier = _this9._actorIdentifier;
						_this9._actorIdentifier = (_incrementalPlacehold = incrementalPlaceholder.actorIdentifier) !== null && _incrementalPlacehold !== void 0 ? _incrementalPlacehold : _this9._actorIdentifier;
						_this9._processIncrementalPlaceholder(payload, incrementalPlaceholder);
						_this9._actorIdentifier = prevActorIdentifier;
					});
					if (_this9._isClientPayload || _this9._state === "loading_final") {
						var relayPayloads = [];
						incrementalPlaceholders.forEach(function(placeholder) {
							if (placeholder.kind === "defer") relayPayloads.push(_this9._processDeferResponse(placeholder.label, placeholder.path, placeholder, {
								data: placeholder.data,
								extensions: { is_final: true }
							}));
						});
						if (relayPayloads.length > 0) _this9._processPayloadFollowups(relayPayloads);
					}
				}
			});
		};
		_proto._maybeCompleteSubscriptionOperationTracking = function _maybeCompleteSubscriptionOperationTracking() {
			if (!this._isSubscriptionOperation && !(this._useExecTimeResolvers && this._execTimeResolverResponseComplete && this._state === "loading_final")) return;
			if (this._pendingModulePayloadsCount === 0 && this._incrementalPayloadsPending === false) this._completeOperationTracker();
		};
		_proto._processFollowupPayload = function _processFollowupPayload(followupPayload) {
			var _this10 = this;
			switch (followupPayload.kind) {
				case "ModuleImportPayload":
					var operationLoader = this._expectOperationLoader();
					var node = operationLoader.get(followupPayload.operationReference);
					if (node != null) this._processFollowupPayloadWithNormalizationNode(followupPayload, getOperation(node));
					else {
						var id = this._nextSubscriptionId++;
						this._pendingModulePayloadsCount++;
						var decrementPendingCount = function decrementPendingCount() {
							_this10._pendingModulePayloadsCount--;
							_this10._maybeCompleteSubscriptionOperationTracking();
						};
						var networkObservable = RelayObservable.from(new Promise(function(resolve, reject) {
							operationLoader.load(followupPayload.operationReference).then(resolve, reject);
						}));
						RelayObservable.create(function(sink) {
							var cancellationToken;
							var subscription = networkObservable.subscribe({
								next: function next(loadedNode) {
									if (loadedNode != null) {
										var publishModuleImportPayload = function publishModuleImportPayload() {
											try {
												var operation = getOperation(loadedNode);
												var batchAsyncModuleUpdatesFN = RelayFeatureFlags.BATCH_ASYNC_MODULE_UPDATES_FN;
												var shouldScheduleAsyncStoreUpdate = batchAsyncModuleUpdatesFN != null && _this10._pendingModulePayloadsCount > 1, _withStartAndDuration = withStartAndDuration(function() {
													_this10._handleFollowupPayload(followupPayload, operation);
													if (shouldScheduleAsyncStoreUpdate) _this10._scheduleAsyncStoreUpdate(batchAsyncModuleUpdatesFN, sink.complete);
													else {
														var updatedOwners = _this10._runPublishQueue();
														_this10._updateOperationTracker(updatedOwners);
													}
												});
												_withStartAndDuration[0];
												var duration = _withStartAndDuration[1];
												_this10._log({
													name: "execute.async.module",
													executeId: _this10._executeId,
													operationName: operation.name,
													duration
												});
												if (!shouldScheduleAsyncStoreUpdate) sink.complete();
											} catch (error) {
												sink.error(error);
											}
										};
										var scheduler = _this10._scheduler;
										if (scheduler == null) publishModuleImportPayload();
										else cancellationToken = scheduler.schedule(publishModuleImportPayload);
									} else sink.complete();
								},
								error: sink.error
							});
							return function() {
								subscription.unsubscribe();
								if (_this10._scheduler != null && cancellationToken != null) _this10._scheduler.cancel(cancellationToken);
							};
						}).subscribe({
							complete: function complete() {
								_this10._complete(id);
								decrementPendingCount();
							},
							error: function error(_error4) {
								_this10._error(_error4);
								decrementPendingCount();
							},
							start: function start(subscription) {
								return _this10._start(id, subscription);
							}
						});
					}
					break;
				case "ActorPayload":
					this._processFollowupPayloadWithNormalizationNode(followupPayload, followupPayload.node);
					break;
				default: invariant(false);
			}
		};
		_proto._processFollowupPayloadWithNormalizationNode = function _processFollowupPayloadWithNormalizationNode(followupPayload, normalizationNode) {
			this._handleFollowupPayload(followupPayload, normalizationNode);
			this._maybeCompleteSubscriptionOperationTracking();
		};
		_proto._handleFollowupPayload = function _handleFollowupPayload(followupPayload, normalizationNode) {
			var relayPayload = this._normalizeFollowupPayload(followupPayload, normalizationNode);
			this._getPublishQueueAndSaveActor().commitPayload(this._operation, relayPayload);
			this._processPayloadFollowups([relayPayload]);
		};
		_proto._processIncrementalPlaceholder = function _processIncrementalPlaceholder(relayPayload, placeholder) {
			var _relayPayload$fieldPa;
			var label = placeholder.label;
			var pathKey = placeholder.path.map(String).join(".");
			var resultForLabel = this._incrementalResults.get(label);
			if (resultForLabel == null) {
				resultForLabel = /* @__PURE__ */ new Map();
				this._incrementalResults.set(label, resultForLabel);
			}
			var resultForPath = resultForLabel.get(pathKey);
			var pendingResponses = resultForPath != null && resultForPath.kind === "response" ? resultForPath.responses : null;
			resultForLabel.set(pathKey, {
				kind: "placeholder",
				placeholder
			});
			var parentID;
			if (placeholder.kind === "stream") parentID = placeholder.parentID;
			else if (placeholder.kind === "defer") parentID = placeholder.selector.dataID;
			else invariant(false);
			var parentRecord = relayPayload.source.get(parentID);
			var parentPayloads = ((_relayPayload$fieldPa = relayPayload.fieldPayloads) !== null && _relayPayload$fieldPa !== void 0 ? _relayPayload$fieldPa : []).filter(function(fieldPayload) {
				var fieldID = generateClientID(fieldPayload.dataID, fieldPayload.fieldKey);
				return fieldPayload.dataID === parentID || fieldID === parentID;
			});
			!(parentRecord != null) && invariant(false);
			var nextParentRecord;
			var nextParentPayloads;
			var previousParentEntry = this._source.get(parentID);
			if (previousParentEntry != null) {
				nextParentRecord = RelayModernRecord.update(previousParentEntry.record, parentRecord);
				var handlePayloads = /* @__PURE__ */ new Map();
				var dedupePayload = function dedupePayload(payload) {
					var key = stableStringify(payload);
					handlePayloads.set(key, payload);
				};
				previousParentEntry.fieldPayloads.forEach(dedupePayload);
				parentPayloads.forEach(dedupePayload);
				nextParentPayloads = Array.from(handlePayloads.values());
			} else {
				nextParentRecord = parentRecord;
				nextParentPayloads = parentPayloads;
			}
			this._source.set(parentID, {
				record: nextParentRecord,
				fieldPayloads: nextParentPayloads
			});
			if (pendingResponses != null) {
				var payloadFollowups = this._processIncrementalResponses(pendingResponses);
				this._processPayloadFollowups(payloadFollowups);
			}
		};
		_proto._processIncrementalResponses = function _processIncrementalResponses(incrementalResponses) {
			var _this11 = this;
			var relayPayloads = [];
			incrementalResponses.forEach(function(incrementalResponse) {
				var label = incrementalResponse.label, path = incrementalResponse.path, response = incrementalResponse.response;
				var resultForLabel = _this11._incrementalResults.get(label);
				if (resultForLabel == null) {
					resultForLabel = /* @__PURE__ */ new Map();
					_this11._incrementalResults.set(label, resultForLabel);
				}
				if (label.indexOf("$defer$") !== -1) {
					var pathKey = path.map(String).join(".");
					var resultForPath = resultForLabel.get(pathKey);
					if (resultForPath == null) {
						resultForPath = {
							kind: "response",
							responses: [incrementalResponse]
						};
						resultForLabel.set(pathKey, resultForPath);
						return;
					} else if (resultForPath.kind === "response") {
						resultForPath.responses.push(incrementalResponse);
						return;
					}
					var placeholder = resultForPath.placeholder;
					!(placeholder.kind === "defer") && invariant(false);
					relayPayloads.push(_this11._processDeferResponse(label, path, placeholder, response));
				} else {
					var _pathKey = path.slice(0, -2).map(String).join(".");
					var _resultForPath = resultForLabel.get(_pathKey);
					if (_resultForPath == null) {
						_resultForPath = {
							kind: "response",
							responses: [incrementalResponse]
						};
						resultForLabel.set(_pathKey, _resultForPath);
						return;
					} else if (_resultForPath.kind === "response") {
						_resultForPath.responses.push(incrementalResponse);
						return;
					}
					var _placeholder = _resultForPath.placeholder;
					!(_placeholder.kind === "stream") && invariant(false);
					relayPayloads.push(_this11._processStreamResponse(label, path, _placeholder, response));
				}
			});
			return relayPayloads;
		};
		_proto._processDeferResponse = function _processDeferResponse(label, path, placeholder, response) {
			var _placeholder$actorIde;
			var parentID = placeholder.selector.dataID;
			var prevActorIdentifier = this._actorIdentifier;
			this._actorIdentifier = (_placeholder$actorIde = placeholder.actorIdentifier) !== null && _placeholder$actorIde !== void 0 ? _placeholder$actorIde : this._actorIdentifier;
			var relayPayload = this._normalizeResponse(response, placeholder.selector, placeholder.typeName, {
				actorIdentifier: this._actorIdentifier,
				getDataID: this._getDataID,
				log: this._log,
				path: placeholder.path,
				treatMissingFieldsAsNull: this._treatMissingFieldsAsNull,
				shouldProcessClientComponents: this._shouldProcessClientComponents
			}, this._useExecTimeResolvers);
			this._getPublishQueueAndSaveActor().commitPayload(this._operation, relayPayload);
			var parentEntry = this._source.get(parentID);
			!(parentEntry != null) && invariant(false);
			var fieldPayloads = parentEntry.fieldPayloads;
			if (fieldPayloads.length !== 0) {
				var _response$extensions3;
				var handleFieldsRelayPayload = {
					errors: null,
					fieldPayloads,
					incrementalPlaceholders: null,
					followupPayloads: null,
					source: RelayRecordSource.create(),
					isFinal: ((_response$extensions3 = response.extensions) === null || _response$extensions3 === void 0 ? void 0 : _response$extensions3.is_final) === true
				};
				this._getPublishQueueAndSaveActor().commitPayload(this._operation, handleFieldsRelayPayload);
			}
			this._actorIdentifier = prevActorIdentifier;
			return relayPayload;
		};
		_proto._processStreamResponse = function _processStreamResponse(label, path, placeholder, response) {
			var parentID = placeholder.parentID, node = placeholder.node, variables = placeholder.variables, actorIdentifier = placeholder.actorIdentifier;
			var prevActorIdentifier = this._actorIdentifier;
			this._actorIdentifier = actorIdentifier !== null && actorIdentifier !== void 0 ? actorIdentifier : this._actorIdentifier;
			var field = node.selections[0];
			!(field != null && field.kind === "LinkedField" && field.plural === true) && invariant(false);
			var _this$_normalizeStrea = this._normalizeStreamItem(response, parentID, field, variables, path, placeholder.path), fieldPayloads = _this$_normalizeStrea.fieldPayloads, itemID = _this$_normalizeStrea.itemID, itemIndex = _this$_normalizeStrea.itemIndex, prevIDs = _this$_normalizeStrea.prevIDs, relayPayload = _this$_normalizeStrea.relayPayload, storageKey = _this$_normalizeStrea.storageKey;
			this._getPublishQueueAndSaveActor().commitPayload(this._operation, relayPayload, function(store) {
				var currentParentRecord = store.get(parentID);
				if (currentParentRecord == null) return;
				var currentItems = currentParentRecord.getLinkedRecords(storageKey);
				if (currentItems == null) return;
				if (currentItems.length !== prevIDs.length || currentItems.some(function(currentItem, index) {
					return prevIDs[index] !== (currentItem && currentItem.getDataID());
				})) return;
				var nextItems = (0, _toConsumableArray2["default"])(currentItems);
				nextItems[itemIndex] = store.get(itemID);
				currentParentRecord.setLinkedRecords(nextItems, storageKey);
			});
			if (fieldPayloads.length !== 0) {
				var handleFieldsRelayPayload = {
					errors: null,
					fieldPayloads,
					incrementalPlaceholders: null,
					followupPayloads: null,
					source: RelayRecordSource.create(),
					isFinal: false
				};
				this._getPublishQueueAndSaveActor().commitPayload(this._operation, handleFieldsRelayPayload);
			}
			this._actorIdentifier = prevActorIdentifier;
			return relayPayload;
		};
		_proto._normalizeStreamItem = function _normalizeStreamItem(response, parentID, field, variables, path, normalizationPath) {
			var _field$alias, _field$concreteType, _ref2, _this$_getDataID;
			var data = response.data;
			!(typeof data === "object") && invariant(false);
			var responseKey = (_field$alias = field.alias) !== null && _field$alias !== void 0 ? _field$alias : field.name;
			var storageKey = getStorageKey(field, variables);
			var parentEntry = this._source.get(parentID);
			!(parentEntry != null) && invariant(false);
			var parentRecord = parentEntry.record, fieldPayloads = parentEntry.fieldPayloads;
			var prevIDs = RelayModernRecord.getLinkedRecordIDs(parentRecord, storageKey);
			!(prevIDs != null) && invariant(false);
			var finalPathEntry = path[path.length - 1];
			var itemIndex = parseInt(finalPathEntry, 10);
			!(itemIndex === finalPathEntry && itemIndex >= 0) && invariant(false);
			var typeName = (_field$concreteType = field.concreteType) !== null && _field$concreteType !== void 0 ? _field$concreteType : data[TYPENAME_KEY];
			!(typeof typeName === "string") && invariant(false);
			var itemID = (_ref2 = (_this$_getDataID = this._getDataID(data, typeName)) !== null && _this$_getDataID !== void 0 ? _this$_getDataID : prevIDs === null || prevIDs === void 0 ? void 0 : prevIDs[itemIndex]) !== null && _ref2 !== void 0 ? _ref2 : generateClientID(parentID, storageKey, itemIndex);
			!(typeof itemID === "string") && invariant(false);
			var selector = createNormalizationSelector(field, itemID, variables);
			var nextParentRecord = RelayModernRecord.clone(parentRecord);
			var nextIDs = (0, _toConsumableArray2["default"])(prevIDs);
			nextIDs[itemIndex] = itemID;
			RelayModernRecord.setLinkedRecordIDs(nextParentRecord, storageKey, nextIDs);
			this._source.set(parentID, {
				record: nextParentRecord,
				fieldPayloads
			});
			return {
				fieldPayloads,
				itemID,
				itemIndex,
				prevIDs,
				relayPayload: this._normalizeResponse(response, selector, typeName, {
					actorIdentifier: this._actorIdentifier,
					getDataID: this._getDataID,
					log: this._log,
					path: [].concat((0, _toConsumableArray2["default"])(normalizationPath), [responseKey, String(itemIndex)]),
					treatMissingFieldsAsNull: this._treatMissingFieldsAsNull,
					shouldProcessClientComponents: this._shouldProcessClientComponents
				}, this._useExecTimeResolvers),
				storageKey
			};
		};
		_proto._scheduleAsyncStoreUpdate = function _scheduleAsyncStoreUpdate(scheduleFn, completeFn) {
			var _this12 = this;
			this._completeFns.push(completeFn);
			if (this._asyncStoreUpdateDisposable != null) return;
			this._asyncStoreUpdateDisposable = scheduleFn(function() {
				_this12._asyncStoreUpdateDisposable = null;
				var updatedOwners = _this12._runPublishQueue();
				_this12._updateOperationTracker(updatedOwners);
				var _iterator2 = (0, _createForOfIteratorHelper2["default"])(_this12._completeFns), _step2;
				try {
					for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
						var complete = _step2.value;
						complete();
					}
				} catch (err) {
					_iterator2.e(err);
				} finally {
					_iterator2.f();
				}
				_this12._completeFns = [];
			});
		};
		_proto._updateOperationTracker = function _updateOperationTracker(updatedOwners) {
			if (updatedOwners != null && updatedOwners.length > 0) this._operationTracker.update(this._operation.request, new Set(updatedOwners));
		};
		_proto._completeOperationTracker = function _completeOperationTracker() {
			this._operationTracker.complete(this._operation.request);
		};
		_proto._getPublishQueueAndSaveActor = function _getPublishQueueAndSaveActor() {
			this._seenActors.add(this._actorIdentifier);
			return this._getPublishQueue(this._actorIdentifier);
		};
		_proto._getActorsToVisit = function _getActorsToVisit() {
			if (this._seenActors.size === 0) return new Set([this._actorIdentifier]);
			else return this._seenActors;
		};
		_proto._runPublishQueue = function _runPublishQueue(operation) {
			var updatedOwners = /* @__PURE__ */ new Set();
			var _iterator3 = (0, _createForOfIteratorHelper2["default"])(this._getActorsToVisit()), _step3;
			try {
				for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
					var actorIdentifier = _step3.value;
					this._getPublishQueue(actorIdentifier).run(operation).forEach(function(owner) {
						return updatedOwners.add(owner);
					});
				}
			} catch (err) {
				_iterator3.e(err);
			} finally {
				_iterator3.f();
			}
			return Array.from(updatedOwners);
		};
		_proto._retainData = function _retainData() {
			var _iterator4 = (0, _createForOfIteratorHelper2["default"])(this._getActorsToVisit()), _step4;
			try {
				for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
					var actorIdentifier = _step4.value;
					if (!this._retainDisposables.has(actorIdentifier)) this._retainDisposables.set(actorIdentifier, this._getStore(actorIdentifier).retain(this._operation));
				}
			} catch (err) {
				_iterator4.e(err);
			} finally {
				_iterator4.f();
			}
		};
		_proto._disposeRetainedData = function _disposeRetainedData() {
			var _iterator5 = (0, _createForOfIteratorHelper2["default"])(this._retainDisposables.values()), _step5;
			try {
				for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) _step5.value.dispose();
			} catch (err) {
				_iterator5.e(err);
			} finally {
				_iterator5.f();
			}
			this._retainDisposables.clear();
		};
		_proto._expectOperationLoader = function _expectOperationLoader() {
			var operationLoader = this._operationLoader;
			!operationLoader && invariant(false);
			return operationLoader;
		};
		return Executor;
	}();
	function partitionGraphQLResponses(responses) {
		var nonIncrementalResponses = [];
		var incrementalResponses = [];
		var normalizedResponses = [];
		responses.forEach(function(response) {
			var _response$extensions4;
			if (response.path != null || response.label != null) {
				var label = response.label, path = response.path;
				if (label == null || path == null) invariant(false);
				incrementalResponses.push({
					label,
					path,
					response
				});
			} else if (((_response$extensions4 = response.extensions) === null || _response$extensions4 === void 0 ? void 0 : _response$extensions4.is_normalized) === true) normalizedResponses.push(response);
			else nonIncrementalResponses.push(response);
		});
		return [
			nonIncrementalResponses,
			incrementalResponses,
			normalizedResponses
		];
	}
	function stableStringify(value) {
		var _JSON$stringify;
		return (_JSON$stringify = JSON.stringify(stableCopy(value))) !== null && _JSON$stringify !== void 0 ? _JSON$stringify : "";
	}
	function validateOptimisticResponsePayload(payload) {
		var incrementalPlaceholders = payload.incrementalPlaceholders;
		if (incrementalPlaceholders != null && incrementalPlaceholders.length !== 0) invariant(false);
	}
	module.exports = { execute };
}));
var require_resolveImmediate = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var resolvedPromise = Promise.resolve();
	function resolveImmediate(callback) {
		resolvedPromise.then(callback)["catch"](throwNext);
	}
	function throwNext(error) {
		setTimeout(function() {
			throw error;
		}, 0);
	}
	module.exports = resolveImmediate;
}));
var require_RelayRecordSourceMutator = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayModernRecord = require_RelayModernRecord();
	var EXISTENT = require_RelayRecordState().EXISTENT;
	var invariant = require_invariant();
	module.exports = /* @__PURE__ */ function() {
		function RelayRecordSourceMutator(base, sink) {
			this.__sources = [sink, base];
			this._base = base;
			this._sink = sink;
		}
		var _proto = RelayRecordSourceMutator.prototype;
		_proto.unstable_getRawRecordWithChanges = function unstable_getRawRecordWithChanges(dataID) {
			var baseRecord = this._base.get(dataID);
			var sinkRecord = this._sink.get(dataID);
			if (sinkRecord === void 0) {
				if (baseRecord == null) return baseRecord;
				return RelayModernRecord.clone(baseRecord);
			} else if (sinkRecord === null) return null;
			else if (baseRecord != null) return RelayModernRecord.update(baseRecord, sinkRecord);
			else return RelayModernRecord.clone(sinkRecord);
		};
		_proto._getSinkRecord = function _getSinkRecord(dataID) {
			var sinkRecord = this._sink.get(dataID);
			if (!sinkRecord) {
				var baseRecord = this._base.get(dataID);
				!baseRecord && invariant(false);
				sinkRecord = RelayModernRecord.create(dataID, RelayModernRecord.getType(baseRecord));
				this._sink.set(dataID, sinkRecord);
			}
			return sinkRecord;
		};
		_proto.copyFields = function copyFields(sourceID, sinkID) {
			var sinkSource = this._sink.get(sourceID);
			var baseSource = this._base.get(sourceID);
			!(sinkSource || baseSource) && invariant(false);
			var sink = this._getSinkRecord(sinkID);
			if (baseSource) RelayModernRecord.copyFields(baseSource, sink);
			if (sinkSource) RelayModernRecord.copyFields(sinkSource, sink);
		};
		_proto.copyFieldsFromRecord = function copyFieldsFromRecord(record, sinkID) {
			var sink = this._getSinkRecord(sinkID);
			RelayModernRecord.copyFields(record, sink);
		};
		_proto.create = function create(dataID, typeName) {
			!(this._base.getStatus(dataID) !== EXISTENT && this._sink.getStatus(dataID) !== EXISTENT) && invariant(false);
			var record = RelayModernRecord.create(dataID, typeName);
			this._sink.set(dataID, record);
		};
		_proto["delete"] = function _delete(dataID) {
			this._sink["delete"](dataID);
		};
		_proto.getStatus = function getStatus(dataID) {
			return this._sink.has(dataID) ? this._sink.getStatus(dataID) : this._base.getStatus(dataID);
		};
		_proto.getType = function getType(dataID) {
			for (var ii = 0; ii < this.__sources.length; ii++) {
				var record = this.__sources[ii].get(dataID);
				if (record) return RelayModernRecord.getType(record);
				else if (record === null) return null;
			}
		};
		_proto.getValue = function getValue(dataID, storageKey) {
			for (var ii = 0; ii < this.__sources.length; ii++) {
				var record = this.__sources[ii].get(dataID);
				if (record) {
					var value = RelayModernRecord.getValue(record, storageKey);
					if (value !== void 0) return value;
				} else if (record === null) return null;
			}
		};
		_proto.setValue = function setValue(dataID, storageKey, value) {
			var sinkRecord = this._getSinkRecord(dataID);
			RelayModernRecord.setValue(sinkRecord, storageKey, value);
		};
		_proto.getErrors = function getErrors(dataID, storageKey) {
			for (var ii = 0; ii < this.__sources.length; ii++) {
				var record = this.__sources[ii].get(dataID);
				if (record) {
					var value = RelayModernRecord.getErrors(record, storageKey);
					if (value !== void 0) return value;
				} else if (record === null) return null;
			}
		};
		_proto.setErrors = function setErrors(dataID, storageKey, errors) {
			var sinkRecord = this._getSinkRecord(dataID);
			RelayModernRecord.setErrors(sinkRecord, storageKey, errors);
		};
		_proto.getLinkedRecordID = function getLinkedRecordID(dataID, storageKey) {
			for (var ii = 0; ii < this.__sources.length; ii++) {
				var record = this.__sources[ii].get(dataID);
				if (record) {
					var linkedID = RelayModernRecord.getLinkedRecordID(record, storageKey);
					if (linkedID !== void 0) return linkedID;
				} else if (record === null) return null;
			}
		};
		_proto.setLinkedRecordID = function setLinkedRecordID(dataID, storageKey, linkedID) {
			var sinkRecord = this._getSinkRecord(dataID);
			RelayModernRecord.setLinkedRecordID(sinkRecord, storageKey, linkedID);
		};
		_proto.getLinkedRecordIDs = function getLinkedRecordIDs(dataID, storageKey) {
			for (var ii = 0; ii < this.__sources.length; ii++) {
				var record = this.__sources[ii].get(dataID);
				if (record) {
					var linkedIDs = RelayModernRecord.getLinkedRecordIDs(record, storageKey);
					if (linkedIDs !== void 0) return linkedIDs;
				} else if (record === null) return null;
			}
		};
		_proto.setLinkedRecordIDs = function setLinkedRecordIDs(dataID, storageKey, linkedIDs) {
			var sinkRecord = this._getSinkRecord(dataID);
			RelayModernRecord.setLinkedRecordIDs(sinkRecord, storageKey, linkedIDs);
		};
		return RelayRecordSourceMutator;
	}();
}));
var require_createUpdatableProxy = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var getArgumentValues = require_RelayStoreUtils().getArgumentValues;
	var nonUpdatableKeys = [
		"id",
		"__id",
		"__typename",
		"js"
	];
	function createUpdatableProxy(updatableProxyRootRecord, variables, selections, recordSourceProxy, missingFieldHandlers) {
		var mutableUpdatableProxy = {};
		updateProxyFromSelections(mutableUpdatableProxy, updatableProxyRootRecord, variables, selections, recordSourceProxy, missingFieldHandlers);
		return mutableUpdatableProxy;
	}
	function updateProxyFromSelections(mutableUpdatableProxy, updatableProxyRootRecord, variables, selections, recordSourceProxy, missingFieldHandlers) {
		var _selection$alias3;
		var _iterator = (0, _createForOfIteratorHelper2["default"])(selections), _step;
		try {
			var _loop = function _loop() {
				var selection = _step.value;
				switch (selection.kind) {
					case "LinkedField":
						if (selection.plural) Object.defineProperty(mutableUpdatableProxy, (_selection$alias = selection.alias) !== null && _selection$alias !== void 0 ? _selection$alias : selection.name, {
							get: createGetterForPluralLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers),
							set: createSetterForPluralLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy)
						});
						else Object.defineProperty(mutableUpdatableProxy, (_selection$alias2 = selection.alias) !== null && _selection$alias2 !== void 0 ? _selection$alias2 : selection.name, {
							get: createGetterForSingularLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers),
							set: createSetterForSingularLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy)
						});
						break;
					case "ScalarField":
						var scalarFieldName = (_selection$alias3 = selection.alias) !== null && _selection$alias3 !== void 0 ? _selection$alias3 : selection.name;
						Object.defineProperty(mutableUpdatableProxy, scalarFieldName, {
							get: function get() {
								var _selection$args;
								var newVariables = getArgumentValues((_selection$args = selection.args) !== null && _selection$args !== void 0 ? _selection$args : [], variables);
								var value = updatableProxyRootRecord.getValue(selection.name, newVariables);
								if (value == null) value = getScalarUsingMissingFieldHandlers(selection, newVariables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers);
								return value;
							},
							set: nonUpdatableKeys.includes(selection.name) ? void 0 : function(newValue) {
								var _selection$args2;
								var newVariables = getArgumentValues((_selection$args2 = selection.args) !== null && _selection$args2 !== void 0 ? _selection$args2 : [], variables);
								updatableProxyRootRecord.setValue__UNSAFE(newValue, selection.name, newVariables);
							}
						});
						break;
					case "InlineFragment":
						if (updatableProxyRootRecord.getType() === selection.type) updateProxyFromSelections(mutableUpdatableProxy, updatableProxyRootRecord, variables, selection.selections, recordSourceProxy, missingFieldHandlers);
						break;
					case "ClientExtension":
						updateProxyFromSelections(mutableUpdatableProxy, updatableProxyRootRecord, variables, selection.selections, recordSourceProxy, missingFieldHandlers);
						break;
					case "FragmentSpread": break;
					case "Condition":
					case "ActorChange":
					case "InlineDataFragmentSpread":
					case "AliasedInlineFragmentSpread":
					case "ClientEdgeToClientObject":
					case "ClientEdgeToServerObject":
					case "Defer":
					case "ModuleImport":
					case "RequiredField":
					case "CatchField":
					case "Stream":
					case "RelayResolver":
					case "RelayLiveResolver": throw new Error("Encountered an unexpected ReaderSelection variant in RelayRecordSourceProxy. This indicates a bug in Relay.");
					default:
						selection.kind;
						throw new Error("Encountered an unexpected ReaderSelection variant in RelayRecordSourceProxy. This indicates a bug in Relay.");
				}
			};
			for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var _selection$alias;
				var _selection$alias2;
				_loop();
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
	}
	function createSetterForPluralLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy) {
		return function set(newValue) {
			var _selection$args3;
			var newVariables = getArgumentValues((_selection$args3 = selection.args) !== null && _selection$args3 !== void 0 ? _selection$args3 : [], variables);
			if (newValue == null) throw new Error("Do not assign null to plural linked fields; assign an empty array instead.");
			else {
				var recordProxies = newValue.map(function(item) {
					if (item == null) throw new Error("When assigning an array of items, none of the items should be null or undefined.");
					var __id = item.__id;
					if (__id == null) throw new Error("The __id field must be present on each item passed to the setter. This indicates a bug in Relay.");
					var newValueRecord = recordSourceProxy.get(__id);
					if (newValueRecord == null) throw new Error("Did not find item with data id ".concat(__id, " in the store."));
					return newValueRecord;
				});
				updatableProxyRootRecord.setLinkedRecords(recordProxies, selection.name, newVariables);
			}
		};
	}
	function createSetterForSingularLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy) {
		return function set(newValue) {
			var _selection$args4;
			var newVariables = getArgumentValues((_selection$args4 = selection.args) !== null && _selection$args4 !== void 0 ? _selection$args4 : [], variables);
			if (newValue == null) updatableProxyRootRecord.setValue(newValue, selection.name, newVariables);
			else {
				var __id = newValue.__id;
				if (__id == null) throw new Error("The __id field must be present on the argument. This indicates a bug in Relay.");
				var newValueRecord = recordSourceProxy.get(__id);
				if (newValueRecord == null) throw new Error("Did not find item with data id ".concat(__id, " in the store."));
				updatableProxyRootRecord.setLinkedRecord(newValueRecord, selection.name, newVariables);
			}
		};
	}
	function createGetterForPluralLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers) {
		return function() {
			var _selection$args5;
			var newVariables = getArgumentValues((_selection$args5 = selection.args) !== null && _selection$args5 !== void 0 ? _selection$args5 : [], variables);
			var linkedRecords = updatableProxyRootRecord.getLinkedRecords(selection.name, newVariables);
			if (linkedRecords === void 0) linkedRecords = getPluralLinkedRecordUsingMissingFieldHandlers(selection, newVariables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers);
			if (linkedRecords != null) return linkedRecords.map(function(linkedRecord) {
				if (linkedRecord != null) {
					var updatableProxy = {};
					updateProxyFromSelections(updatableProxy, linkedRecord, variables, selection.selections, recordSourceProxy, missingFieldHandlers);
					return updatableProxy;
				} else return linkedRecord;
			});
			else return linkedRecords;
		};
	}
	function createGetterForSingularLinkedField(selection, variables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers) {
		return function() {
			var _selection$args6;
			var newVariables = getArgumentValues((_selection$args6 = selection.args) !== null && _selection$args6 !== void 0 ? _selection$args6 : [], variables);
			var linkedRecord = updatableProxyRootRecord.getLinkedRecord(selection.name, newVariables);
			if (linkedRecord === void 0) linkedRecord = getLinkedRecordUsingMissingFieldHandlers(selection, newVariables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers);
			if (linkedRecord != null) {
				var updatableProxy = {};
				updateProxyFromSelections(updatableProxy, linkedRecord, variables, selection.selections, recordSourceProxy, missingFieldHandlers);
				return updatableProxy;
			} else return linkedRecord;
		};
	}
	function getLinkedRecordUsingMissingFieldHandlers(selection, newVariables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers) {
		var _iterator2 = (0, _createForOfIteratorHelper2["default"])(missingFieldHandlers), _step2;
		try {
			for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
				var handler = _step2.value;
				if (handler.kind === "linked") {
					var newId = handler.handle(selection, updatableProxyRootRecord, newVariables, recordSourceProxy);
					if (newId != null) return recordSourceProxy.get(newId);
				}
			}
		} catch (err) {
			_iterator2.e(err);
		} finally {
			_iterator2.f();
		}
	}
	function getPluralLinkedRecordUsingMissingFieldHandlers(selection, newVariables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers) {
		var _iterator3 = (0, _createForOfIteratorHelper2["default"])(missingFieldHandlers), _step3;
		try {
			for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
				var handler = _step3.value;
				if (handler.kind === "pluralLinked") {
					var newIds = handler.handle(selection, updatableProxyRootRecord, newVariables, recordSourceProxy);
					if (newIds != null) return newIds.map(function(newId) {
						if (newId != null) return recordSourceProxy.get(newId);
					});
				}
			}
		} catch (err) {
			_iterator3.e(err);
		} finally {
			_iterator3.f();
		}
	}
	function getScalarUsingMissingFieldHandlers(selection, newVariables, updatableProxyRootRecord, recordSourceProxy, missingFieldHandlers) {
		var _iterator4 = (0, _createForOfIteratorHelper2["default"])(missingFieldHandlers), _step4;
		try {
			for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
				var handler = _step4.value;
				if (handler.kind === "scalar") {
					var value = handler.handle(selection, updatableProxyRootRecord, newVariables, recordSourceProxy);
					if (value !== void 0) return value;
				}
			}
		} catch (err) {
			_iterator4.e(err);
		} finally {
			_iterator4.f();
		}
	}
	module.exports = { createUpdatableProxy };
}));
var require_readUpdatableFragment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getFragment = require_GraphQLTag().getFragment;
	var getVariablesFromFragment = require_RelayModernSelector().getVariablesFromFragment;
	var ID_KEY = require_RelayStoreUtils().ID_KEY;
	var createUpdatableProxy = require_createUpdatableProxy().createUpdatableProxy;
	var invariant = require_invariant();
	function readUpdatableFragment(fragment, fragmentReference, proxy, missingFieldHandlers) {
		var updatableFragment = getFragment(fragment);
		var fragmentVariables = getVariablesFromFragment(updatableFragment, fragmentReference);
		var id = fragmentReference[ID_KEY];
		var fragmentRoot = proxy.get(id);
		!(fragmentRoot != null) && invariant(false);
		return { updatableData: createUpdatableProxy(fragmentRoot, fragmentVariables, updatableFragment.selections, proxy, missingFieldHandlers) };
	}
	module.exports = { readUpdatableFragment };
}));
var require_readUpdatableQuery = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getUpdatableQuery = require_GraphQLTag().getUpdatableQuery;
	var createUpdatableProxy = require_createUpdatableProxy().createUpdatableProxy;
	function readUpdatableQuery(query, variables, proxy, missingFieldHandlers) {
		var updatableQuery = getUpdatableQuery(query);
		return { updatableData: createUpdatableProxy(proxy.getRoot(), variables, updatableQuery.fragment.selections, proxy, missingFieldHandlers) };
	}
	module.exports = { readUpdatableQuery };
}));
var require_RelayRecordProxy = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var generateClientID = require_ClientID().generateClientID;
	var getStableStorageKey = require_RelayStoreUtils().getStableStorageKey;
	var invariant = require_invariant();
	var RelayRecordProxy = /* @__PURE__ */ function() {
		function RelayRecordProxy(source, mutator, dataID) {
			this._dataID = dataID;
			this._mutator = mutator;
			this._source = source;
		}
		var _proto = RelayRecordProxy.prototype;
		_proto.copyFieldsFrom = function copyFieldsFrom(source) {
			this._mutator.copyFields(source.getDataID(), this._dataID);
		};
		_proto.getDataID = function getDataID() {
			return this._dataID;
		};
		_proto.getType = function getType() {
			var type = this._mutator.getType(this._dataID);
			!(type != null) && invariant(false);
			return type;
		};
		_proto.getValue = function getValue(name, args) {
			var storageKey = getStableStorageKey(name, args);
			return this._mutator.getValue(this._dataID, storageKey);
		};
		_proto.setValue = function setValue(value, name, args, errors) {
			!isValidLeafValue(value) && invariant(false);
			return this.setValue__UNSAFE(value, name, args, errors);
		};
		_proto.getErrors = function getErrors(name, args) {
			var storageKey = getStableStorageKey(name, args);
			return this._mutator.getErrors(this._dataID, storageKey);
		};
		_proto.setValue__UNSAFE = function setValue__UNSAFE(value, name, args, errors) {
			var storageKey = getStableStorageKey(name, args);
			this._mutator.setValue(this._dataID, storageKey, value);
			if (errors != null) if (errors.length === 0) this._mutator.setErrors(this._dataID, storageKey);
			else this._mutator.setErrors(this._dataID, storageKey, errors);
			return this;
		};
		_proto.getLinkedRecord = function getLinkedRecord(name, args) {
			var storageKey = getStableStorageKey(name, args);
			var linkedID = this._mutator.getLinkedRecordID(this._dataID, storageKey);
			return linkedID != null ? this._source.get(linkedID) : linkedID;
		};
		_proto.setLinkedRecord = function setLinkedRecord(record, name, args) {
			!(record instanceof RelayRecordProxy) && invariant(false);
			var storageKey = getStableStorageKey(name, args);
			var linkedID = record.getDataID();
			this._mutator.setLinkedRecordID(this._dataID, storageKey, linkedID);
			return this;
		};
		_proto.getOrCreateLinkedRecord = function getOrCreateLinkedRecord(name, typeName, args) {
			var linkedRecord = this.getLinkedRecord(name, args);
			if (!linkedRecord) {
				var _this$_source$get;
				var storageKey = getStableStorageKey(name, args);
				var clientID = generateClientID(this.getDataID(), storageKey);
				linkedRecord = (_this$_source$get = this._source.get(clientID)) !== null && _this$_source$get !== void 0 ? _this$_source$get : this._source.create(clientID, typeName);
				this.setLinkedRecord(linkedRecord, name, args);
			}
			return linkedRecord;
		};
		_proto.getLinkedRecords = function getLinkedRecords(name, args) {
			var _this = this;
			var storageKey = getStableStorageKey(name, args);
			var linkedIDs = this._mutator.getLinkedRecordIDs(this._dataID, storageKey);
			if (linkedIDs == null) return linkedIDs;
			return linkedIDs.map(function(linkedID) {
				return linkedID != null ? _this._source.get(linkedID) : linkedID;
			});
		};
		_proto.setLinkedRecords = function setLinkedRecords(records, name, args) {
			!Array.isArray(records) && invariant(false);
			var storageKey = getStableStorageKey(name, args);
			var linkedIDs = records.map(function(record) {
				return record && record.getDataID();
			});
			this._mutator.setLinkedRecordIDs(this._dataID, storageKey, linkedIDs);
			return this;
		};
		_proto.invalidateRecord = function invalidateRecord() {
			this._source.markIDForInvalidation(this._dataID);
		};
		return RelayRecordProxy;
	}();
	function isValidLeafValue(value) {
		return value == null || typeof value !== "object" || Array.isArray(value) && value.every(isValidLeafValue);
	}
	module.exports = RelayRecordProxy;
}));
var require_RelayRecordSourceProxy = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayModernRecord = require_RelayModernRecord();
	var _require = require_RelayRecordState(), EXISTENT = _require.EXISTENT, NONEXISTENT = _require.NONEXISTENT;
	var _require2 = require_RelayStoreUtils(), ROOT_ID = _require2.ROOT_ID, ROOT_TYPE = _require2.ROOT_TYPE;
	var _readUpdatableFragment = require_readUpdatableFragment().readUpdatableFragment;
	var _readUpdatableQuery = require_readUpdatableQuery().readUpdatableQuery;
	var RelayRecordProxy = require_RelayRecordProxy();
	var invariant = require_invariant();
	module.exports = /* @__PURE__ */ function() {
		function RelayRecordSourceProxy(mutator, getDataID, handlerProvider, missingFieldHandlers, log) {
			this.__mutator = mutator;
			this._handlerProvider = handlerProvider || null;
			this._proxies = {};
			this._getDataID = getDataID;
			this._invalidatedStore = false;
			this._idsMarkedForInvalidation = /* @__PURE__ */ new Set();
			this._missingFieldHandlers = missingFieldHandlers;
			this._log = log !== null && log !== void 0 ? log : function(LogEvent) {};
		}
		var _proto = RelayRecordSourceProxy.prototype;
		_proto.publishSource = function publishSource(source, fieldPayloads) {
			var _this = this;
			source.getRecordIDs().forEach(function(dataID) {
				var status = source.getStatus(dataID);
				if (status === EXISTENT) {
					var sourceRecord = source.get(dataID);
					if (sourceRecord) {
						if (_this.__mutator.getStatus(dataID) !== EXISTENT) _this.create(dataID, RelayModernRecord.getType(sourceRecord));
						_this.__mutator.copyFieldsFromRecord(sourceRecord, dataID);
					}
				} else if (status === NONEXISTENT) _this["delete"](dataID);
			});
			if (fieldPayloads && fieldPayloads.length) fieldPayloads.forEach(function(fieldPayload) {
				var handler = _this._handlerProvider && _this._handlerProvider(fieldPayload.handle);
				!handler && invariant(false);
				handler.update(_this, fieldPayload);
			});
		};
		_proto.create = function create(dataID, typeName) {
			this.__mutator.create(dataID, typeName);
			delete this._proxies[dataID];
			var record = this.get(dataID);
			!record && invariant(false);
			return record;
		};
		_proto["delete"] = function _delete(dataID) {
			!(dataID !== ROOT_ID) && invariant(false);
			delete this._proxies[dataID];
			this.__mutator["delete"](dataID);
		};
		_proto.get = function get(dataID) {
			if (!this._proxies.hasOwnProperty(dataID)) {
				var status = this.__mutator.getStatus(dataID);
				if (status === EXISTENT) this._proxies[dataID] = new RelayRecordProxy(this, this.__mutator, dataID);
				else this._proxies[dataID] = status === NONEXISTENT ? null : void 0;
			}
			return this._proxies[dataID];
		};
		_proto.getRoot = function getRoot() {
			var root = this.get(ROOT_ID);
			if (!root) root = this.create(ROOT_ID, ROOT_TYPE);
			!(root && root.getType() === ROOT_TYPE) && invariant(false);
			return root;
		};
		_proto.invalidateStore = function invalidateStore() {
			this._invalidatedStore = true;
		};
		_proto.isStoreMarkedForInvalidation = function isStoreMarkedForInvalidation() {
			return this._invalidatedStore;
		};
		_proto.markIDForInvalidation = function markIDForInvalidation(dataID) {
			this._idsMarkedForInvalidation.add(dataID);
		};
		_proto.getIDsMarkedForInvalidation = function getIDsMarkedForInvalidation() {
			return this._idsMarkedForInvalidation;
		};
		_proto.readUpdatableQuery = function readUpdatableQuery(query, variables) {
			return _readUpdatableQuery(query, variables, this, this._missingFieldHandlers);
		};
		_proto.readUpdatableFragment = function readUpdatableFragment(fragment, fragmentReference) {
			return _readUpdatableFragment(fragment, fragmentReference, this, this._missingFieldHandlers);
		};
		return RelayRecordSourceProxy;
	}();
}));
var require_cloneRelayHandleSourceField = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var LINKED_FIELD = require_RelayConcreteNode().LINKED_FIELD;
	var getHandleStorageKey = require_RelayStoreUtils().getHandleStorageKey;
	var areEqual = require_areEqual();
	var invariant = require_invariant();
	function cloneRelayHandleSourceField(handleField, selections, variables) {
		var sourceField = selections.find(function(source) {
			return source.kind === LINKED_FIELD && source.name === handleField.name && source.alias === handleField.alias && areEqual(source.args, handleField.args);
		});
		!(sourceField && sourceField.kind === LINKED_FIELD) && invariant(false);
		var handleKey = getHandleStorageKey(handleField, variables);
		return {
			kind: "LinkedField",
			alias: sourceField.alias,
			name: handleKey,
			storageKey: handleKey,
			args: null,
			concreteType: sourceField.concreteType,
			plural: sourceField.plural,
			selections: sourceField.selections
		};
	}
	module.exports = cloneRelayHandleSourceField;
}));
var require_cloneRelayScalarHandleSourceField = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var SCALAR_FIELD = require_RelayConcreteNode().SCALAR_FIELD;
	var getHandleStorageKey = require_RelayStoreUtils().getHandleStorageKey;
	var areEqual = require_areEqual();
	var invariant = require_invariant();
	function cloneRelayScalarHandleSourceField(handleField, selections, variables) {
		var sourceField = selections.find(function(source) {
			return source.kind === SCALAR_FIELD && source.name === handleField.name && source.alias === handleField.alias && areEqual(source.args, handleField.args);
		});
		!(sourceField && sourceField.kind === SCALAR_FIELD) && invariant(false);
		var handleKey = getHandleStorageKey(handleField, variables);
		return {
			kind: "ScalarField",
			alias: sourceField.alias,
			name: handleKey,
			storageKey: handleKey,
			args: null
		};
	}
	module.exports = cloneRelayScalarHandleSourceField;
}));
var require_DataChecker = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var RelayRecordSourceMutator = require_RelayRecordSourceMutator();
	var RelayRecordSourceProxy = require_RelayRecordSourceProxy();
	var getOperation = require_getOperation();
	var isClientID = require_ClientID().isClientID;
	var cloneRelayHandleSourceField = require_cloneRelayHandleSourceField();
	var cloneRelayScalarHandleSourceField = require_cloneRelayScalarHandleSourceField();
	var getLocalVariables = require_RelayConcreteVariables().getLocalVariables;
	var RelayModernRecord = require_RelayModernRecord();
	var _require3 = require_RelayRecordState(), EXISTENT = _require3.EXISTENT, UNKNOWN = _require3.UNKNOWN;
	var RelayStoreUtils = require_RelayStoreUtils();
	var _require4 = require_TypeID(), TYPE_SCHEMA_TYPE = _require4.TYPE_SCHEMA_TYPE, generateTypeID = _require4.generateTypeID;
	var invariant = require_invariant();
	var getModuleOperationKey = RelayStoreUtils.getModuleOperationKey, getStorageKey = RelayStoreUtils.getStorageKey, getArgumentValues = RelayStoreUtils.getArgumentValues;
	function check(getSourceForActor, getTargetForActor, defaultActorIdentifier, selector, handlers, operationLoader, getDataID, shouldProcessClientComponents, log, useExecTimeResolvers) {
		if (log != null) log({
			name: "store.datachecker.start",
			selector
		});
		var dataID = selector.dataID, node = selector.node, variables = selector.variables;
		var result = new DataChecker(getSourceForActor, getTargetForActor, defaultActorIdentifier, variables, handlers, operationLoader, getDataID, shouldProcessClientComponents, log, useExecTimeResolvers).check(node, dataID);
		if (log != null) log({
			name: "store.datachecker.end",
			selector
		});
		return result;
	}
	var DataChecker = /* @__PURE__ */ function() {
		function DataChecker(getSourceForActor, getTargetForActor, defaultActorIdentifier, variables, handlers, operationLoader, getDataID, shouldProcessClientComponents, log, useExecTimeResolvers) {
			this._getSourceForActor = getSourceForActor;
			this._getTargetForActor = getTargetForActor;
			this._getDataID = getDataID;
			this._source = getSourceForActor(defaultActorIdentifier);
			this._mutatorRecordSourceProxyCache = /* @__PURE__ */ new Map();
			var _this$_getMutatorAndR = this._getMutatorAndRecordProxyForActor(defaultActorIdentifier), mutator = _this$_getMutatorAndR[0], recordSourceProxy = _this$_getMutatorAndR[1];
			this._useExecTimeResolvers = useExecTimeResolvers !== null && useExecTimeResolvers !== void 0 ? useExecTimeResolvers : false;
			this._mostRecentlyInvalidatedAt = null;
			this._handlers = handlers;
			this._mutator = mutator;
			this._operationLoader = operationLoader !== null && operationLoader !== void 0 ? operationLoader : null;
			this._recordSourceProxy = recordSourceProxy;
			this._recordWasMissing = false;
			this._variables = variables;
			this._shouldProcessClientComponents = shouldProcessClientComponents;
			this._log = log;
		}
		var _proto = DataChecker.prototype;
		_proto._getMutatorAndRecordProxyForActor = function _getMutatorAndRecordProxyForActor(actorIdentifier) {
			var tuple = this._mutatorRecordSourceProxyCache.get(actorIdentifier);
			if (tuple == null) {
				var target = this._getTargetForActor(actorIdentifier);
				var mutator = new RelayRecordSourceMutator(this._getSourceForActor(actorIdentifier), target);
				tuple = [mutator, new RelayRecordSourceProxy(mutator, this._getDataID, void 0, this._handlers, this._log)];
				this._mutatorRecordSourceProxyCache.set(actorIdentifier, tuple);
			}
			return tuple;
		};
		_proto.check = function check(node, dataID) {
			this._assignClientAbstractTypes(node);
			this._traverse(node, dataID);
			return this._recordWasMissing === true ? {
				status: "missing",
				mostRecentlyInvalidatedAt: this._mostRecentlyInvalidatedAt
			} : {
				status: "available",
				mostRecentlyInvalidatedAt: this._mostRecentlyInvalidatedAt
			};
		};
		_proto._getVariableValue = function _getVariableValue(name) {
			!this._variables.hasOwnProperty(name) && invariant(false);
			return this._variables[name];
		};
		_proto._handleMissing = function _handleMissing() {
			this._recordWasMissing = true;
		};
		_proto._handleMissingScalarField = function _handleMissingScalarField(field, dataID) {
			if (field.name === "id" && field.alias == null && isClientID(dataID)) return;
			var args = field.args != void 0 ? getArgumentValues(field.args, this._variables) : {};
			var _iterator = (0, _createForOfIteratorHelper2["default"])(this._handlers), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var handler = _step.value;
					if (handler.kind === "scalar") {
						var newValue = handler.handle(field, this._recordSourceProxy.get(dataID), args, this._recordSourceProxy);
						if (newValue !== void 0) return newValue;
					}
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			this._handleMissing();
		};
		_proto._handleMissingLinkField = function _handleMissingLinkField(field, dataID) {
			var args = field.args != void 0 ? getArgumentValues(field.args, this._variables) : {};
			var _iterator2 = (0, _createForOfIteratorHelper2["default"])(this._handlers), _step2;
			try {
				for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
					var handler = _step2.value;
					if (handler.kind === "linked") {
						var newValue = handler.handle(field, this._recordSourceProxy.get(dataID), args, this._recordSourceProxy);
						if (newValue !== void 0 && (newValue === null || this._mutator.getStatus(newValue) === EXISTENT)) return newValue;
					}
				}
			} catch (err) {
				_iterator2.e(err);
			} finally {
				_iterator2.f();
			}
			this._handleMissing();
		};
		_proto._handleMissingPluralLinkField = function _handleMissingPluralLinkField(field, dataID) {
			var _this = this;
			var args = field.args != void 0 ? getArgumentValues(field.args, this._variables) : {};
			var _iterator3 = (0, _createForOfIteratorHelper2["default"])(this._handlers), _step3;
			try {
				for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
					var handler = _step3.value;
					if (handler.kind === "pluralLinked") {
						var newValue = handler.handle(field, this._recordSourceProxy.get(dataID), args, this._recordSourceProxy);
						if (newValue != null) {
							if (newValue.every(function(linkedID) {
								return linkedID != null && _this._mutator.getStatus(linkedID) === EXISTENT;
							})) return newValue;
						} else if (newValue === null) return null;
					}
				}
			} catch (err) {
				_iterator3.e(err);
			} finally {
				_iterator3.f();
			}
			this._handleMissing();
		};
		_proto._traverse = function _traverse(node, dataID) {
			var status = this._mutator.getStatus(dataID);
			if (status === UNKNOWN) this._handleMissing();
			if (status === EXISTENT) {
				var record = this._source.get(dataID);
				var invalidatedAt = RelayModernRecord.getInvalidationEpoch(record);
				if (invalidatedAt != null) this._mostRecentlyInvalidatedAt = this._mostRecentlyInvalidatedAt != null ? Math.max(this._mostRecentlyInvalidatedAt, invalidatedAt) : invalidatedAt;
				this._traverseSelections(node.selections, dataID);
			}
		};
		_proto._traverseSelections = function _traverseSelections(selections, dataID) {
			var _this2 = this;
			selections.forEach(function(selection) {
				switch (selection.kind) {
					case "ScalarField":
						_this2._checkScalar(selection, dataID);
						break;
					case "LinkedField":
						if (selection.plural) _this2._checkPluralLink(selection, dataID);
						else _this2._checkLink(selection, dataID);
						break;
					case "ActorChange":
						_this2._checkActorChange(selection.linkedField, dataID);
						break;
					case "Condition":
						if (Boolean(_this2._getVariableValue(selection.condition)) === selection.passingValue) _this2._traverseSelections(selection.selections, dataID);
						break;
					case "InlineFragment":
						var _abstractKey = selection.abstractKey;
						if (_abstractKey == null) {
							if (_this2._mutator.getType(dataID) === selection.type) _this2._traverseSelections(selection.selections, dataID);
						} else {
							var _recordType = _this2._mutator.getType(dataID);
							!(_recordType != null) && invariant(false);
							var _typeID = generateTypeID(_recordType);
							var _implementsInterface = _this2._mutator.getValue(_typeID, _abstractKey);
							if (_implementsInterface === true) _this2._traverseSelections(selection.selections, dataID);
							else if (_implementsInterface == null) _this2._handleMissing();
						}
						break;
					case "LinkedHandle":
						var handleField = cloneRelayHandleSourceField(selection, selections, _this2._variables);
						if (handleField.plural) _this2._checkPluralLink(handleField, dataID);
						else _this2._checkLink(handleField, dataID);
						break;
					case "ScalarHandle":
						var _handleField = cloneRelayScalarHandleSourceField(selection, selections, _this2._variables);
						_this2._checkScalar(_handleField, dataID);
						break;
					case "ModuleImport":
						_this2._checkModuleImport(selection, dataID);
						break;
					case "Defer":
					case "Stream":
						_this2._traverseSelections(selection.selections, dataID);
						break;
					case "FragmentSpread":
						var prevVariables = _this2._variables;
						_this2._variables = getLocalVariables(_this2._variables, selection.fragment.argumentDefinitions, selection.args);
						_this2._traverseSelections(selection.fragment.selections, dataID);
						_this2._variables = prevVariables;
						break;
					case "ClientExtension":
						var recordWasMissing = _this2._recordWasMissing;
						_this2._traverseSelections(selection.selections, dataID);
						_this2._recordWasMissing = recordWasMissing;
						break;
					case "TypeDiscriminator":
						var abstractKey = selection.abstractKey;
						var recordType = _this2._mutator.getType(dataID);
						!(recordType != null) && invariant(false);
						var typeID = generateTypeID(recordType);
						if (_this2._mutator.getValue(typeID, abstractKey) == null) _this2._handleMissing();
						break;
					case "ClientComponent":
						if (_this2._shouldProcessClientComponents === false) break;
						_this2._traverseSelections(selection.fragment.selections, dataID);
						break;
					case "RelayResolver":
					case "RelayLiveResolver":
						if (!_this2._useExecTimeResolvers) _this2._checkResolver(selection, dataID);
						break;
					case "ClientEdgeToClientObject":
						if (!_this2._useExecTimeResolvers) _this2._checkResolver(selection.backingField, dataID);
						break;
					default: invariant(false);
				}
			});
		};
		_proto._checkResolver = function _checkResolver(resolver, dataID) {
			if (resolver.fragment) this._traverseSelections([resolver.fragment], dataID);
		};
		_proto._checkModuleImport = function _checkModuleImport(moduleImport, dataID) {
			var operationLoader = this._operationLoader;
			!(operationLoader !== null) && invariant(false);
			var operationKey = getModuleOperationKey(moduleImport.documentName);
			var operationReference = this._mutator.getValue(dataID, operationKey);
			if (operationReference == null) {
				if (operationReference === void 0) this._handleMissing();
				return;
			}
			var normalizationRootNode = operationLoader.get(operationReference);
			if (normalizationRootNode != null) {
				var operation = getOperation(normalizationRootNode);
				var prevVariables = this._variables;
				this._variables = getLocalVariables(this._variables, operation.argumentDefinitions, moduleImport.args);
				this._traverse(operation, dataID);
				this._variables = prevVariables;
			} else this._handleMissing();
		};
		_proto._checkScalar = function _checkScalar(field, dataID) {
			var storageKey = getStorageKey(field, this._variables);
			var fieldValue = this._mutator.getValue(dataID, storageKey);
			if (fieldValue === void 0) {
				fieldValue = this._handleMissingScalarField(field, dataID);
				if (fieldValue !== void 0) this._mutator.setValue(dataID, storageKey, fieldValue);
			}
		};
		_proto._checkLink = function _checkLink(field, dataID) {
			var storageKey = getStorageKey(field, this._variables);
			var linkedID = this._mutator.getLinkedRecordID(dataID, storageKey);
			if (linkedID === void 0) {
				linkedID = this._handleMissingLinkField(field, dataID);
				if (linkedID != null) this._mutator.setLinkedRecordID(dataID, storageKey, linkedID);
				else if (linkedID === null) this._mutator.setValue(dataID, storageKey, null);
			}
			if (linkedID != null) this._traverse(field, linkedID);
		};
		_proto._checkPluralLink = function _checkPluralLink(field, dataID) {
			var _this3 = this;
			var storageKey = getStorageKey(field, this._variables);
			var linkedIDs = this._mutator.getLinkedRecordIDs(dataID, storageKey);
			if (linkedIDs === void 0) {
				linkedIDs = this._handleMissingPluralLinkField(field, dataID);
				if (linkedIDs != null) this._mutator.setLinkedRecordIDs(dataID, storageKey, linkedIDs);
				else if (linkedIDs === null) this._mutator.setValue(dataID, storageKey, null);
			}
			if (linkedIDs) linkedIDs.forEach(function(linkedID) {
				if (linkedID != null) _this3._traverse(field, linkedID);
			});
		};
		_proto._checkActorChange = function _checkActorChange(field, dataID) {
			var storageKey = getStorageKey(field, this._variables);
			var record = this._source.get(dataID);
			var tuple = record != null ? RelayModernRecord.getActorLinkedRecordID(record, storageKey) : record;
			if (tuple == null) {
				if (tuple === void 0) this._handleMissing();
			} else {
				var actorIdentifier = tuple[0], linkedID = tuple[1];
				var prevSource = this._source;
				var prevMutator = this._mutator;
				var prevRecordSourceProxy = this._recordSourceProxy;
				var _this$_getMutatorAndR2 = this._getMutatorAndRecordProxyForActor(actorIdentifier), mutator = _this$_getMutatorAndR2[0], recordSourceProxy = _this$_getMutatorAndR2[1];
				this._source = this._getSourceForActor(actorIdentifier);
				this._mutator = mutator;
				this._recordSourceProxy = recordSourceProxy;
				this._assignClientAbstractTypes(field);
				this._traverse(field, linkedID);
				this._source = prevSource;
				this._mutator = prevMutator;
				this._recordSourceProxy = prevRecordSourceProxy;
			}
		};
		_proto._assignClientAbstractTypes = function _assignClientAbstractTypes(node) {
			var clientAbstractTypes = node.clientAbstractTypes;
			if (clientAbstractTypes != null) for (var _i = 0, _Object$keys = Object.keys(clientAbstractTypes); _i < _Object$keys.length; _i++) {
				var abstractType = _Object$keys[_i];
				var _iterator4 = (0, _createForOfIteratorHelper2["default"])(clientAbstractTypes[abstractType]), _step4;
				try {
					for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
						var concreteType = _step4.value;
						var typeID = generateTypeID(concreteType);
						if (this._source.get(typeID) == null) this._mutator.create(typeID, TYPE_SCHEMA_TYPE);
						if (this._mutator.getValue(typeID, abstractType) == null) this._mutator.setValue(typeID, abstractType, true);
					}
				} catch (err) {
					_iterator4.e(err);
				} finally {
					_iterator4.f();
				}
			}
		};
		return DataChecker;
	}();
	module.exports = { check };
}));
var require_shallowFreeze = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = function shallowFreeze(value) {
		if (typeof value === "object" && value != null && (Array.isArray(value) || value.constructor === Object)) Object.freeze(value);
	};
}));
var require_getOutputTypeRecordIDs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayModernRecord = require_RelayModernRecord();
	var RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS = require_RelayStoreUtils().RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS;
	var invariant = require_invariant();
	function getOutputTypeRecordIDs(record) {
		var maybeOutputTypeRecordIDs = RelayModernRecord.getValue(record, RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS);
		if (maybeOutputTypeRecordIDs == null) return null;
		!(maybeOutputTypeRecordIDs instanceof Set) && invariant(false);
		return maybeOutputTypeRecordIDs;
	}
	module.exports = getOutputTypeRecordIDs;
}));
var require_isLiveStateValue = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function isLiveStateValue(v) {
		return v != null && typeof v === "object" && typeof v.read === "function" && typeof v.subscribe === "function";
	}
	module.exports = isLiveStateValue;
}));
var require_LiveResolverCache = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var recycleNodesInto = require_recycleNodesInto();
	var RELAY_LIVE_RESOLVER = require_RelayConcreteNode().RELAY_LIVE_RESOLVER;
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var shallowFreeze = require_shallowFreeze();
	var _require2 = require_ClientID(), generateClientID = _require2.generateClientID, generateClientObjectClientID = _require2.generateClientObjectClientID;
	var RelayModernRecord = require_RelayModernRecord();
	var createNormalizationSelector = require_RelayModernSelector().createNormalizationSelector;
	var RelayRecordSource = require_RelayRecordSource();
	var normalize = require_RelayResponseNormalizer().normalize;
	var _require5 = require_RelayStoreUtils(), RELAY_RESOLVER_ERROR_KEY = _require5.RELAY_RESOLVER_ERROR_KEY, RELAY_RESOLVER_INVALIDATION_KEY = _require5.RELAY_RESOLVER_INVALIDATION_KEY, RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS = _require5.RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS, RELAY_RESOLVER_SNAPSHOT_KEY = _require5.RELAY_RESOLVER_SNAPSHOT_KEY, RELAY_RESOLVER_VALUE_KEY = _require5.RELAY_RESOLVER_VALUE_KEY, getReadTimeResolverStorageKey = _require5.getReadTimeResolverStorageKey, getStorageKey = _require5.getStorageKey;
	var getOutputTypeRecordIDs = require_getOutputTypeRecordIDs();
	var isLiveStateValue = require_isLiveStateValue();
	var isSuspenseSentinel = require_LiveResolverSuspenseSentinel().isSuspenseSentinel;
	var invariant = require_invariant();
	require_warning();
	var RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY = "__resolverLiveStateSubscription";
	var RELAY_RESOLVER_LIVE_STATE_VALUE = "__resolverLiveStateValue";
	var RELAY_RESOLVER_LIVE_STATE_DIRTY = "__resolverLiveStateDirty";
	var RELAY_RESOLVER_RECORD_TYPENAME = "__RELAY_RESOLVER__";
	var MODEL_PROPERTY_NAME = "__relay_model_instance";
	function addDependencyEdge(edges, from, to) {
		var set = edges.get(from);
		if (!set) {
			set = /* @__PURE__ */ new Set();
			edges.set(from, set);
		}
		set.add(to);
	}
	var LiveResolverCache = /* @__PURE__ */ function() {
		function LiveResolverCache(getRecordSource, store) {
			this._resolverIDToRecordIDs = /* @__PURE__ */ new Map();
			this._recordIDToResolverIDs = /* @__PURE__ */ new Map();
			this._getRecordSource = getRecordSource;
			this._store = store;
			this._handlingBatch = false;
			this._liveResolverBatchRecordSource = null;
		}
		var _proto = LiveResolverCache.prototype;
		_proto.readFromCacheOrEvaluate = function readFromCacheOrEvaluate(recordID, field, variables, evaluate, getDataForResolverFragment) {
			var recordSource = this._getRecordSource();
			var record = expectRecord(recordSource, recordID);
			var storageKey = getReadTimeResolverStorageKey(field, variables);
			var linkedID = RelayModernRecord.getLinkedRecordID(record, storageKey);
			var linkedRecord = linkedID == null ? null : recordSource.get(linkedID);
			var updatedDataIDs;
			if (linkedRecord == null || this._isInvalid(linkedRecord, getDataForResolverFragment)) {
				var _linkedID;
				if (linkedRecord != null) maybeUnsubscribeFromLiveState(linkedRecord);
				linkedID = (_linkedID = linkedID) !== null && _linkedID !== void 0 ? _linkedID : generateClientID(recordID, storageKey);
				linkedRecord = RelayModernRecord.create(linkedID, RELAY_RESOLVER_RECORD_TYPENAME);
				var evaluationResult = evaluate();
				RelayModernRecord.setValue(linkedRecord, RELAY_RESOLVER_SNAPSHOT_KEY, evaluationResult.snapshot);
				RelayModernRecord.setValue(linkedRecord, RELAY_RESOLVER_ERROR_KEY, evaluationResult.error);
				if (field.kind === RELAY_LIVE_RESOLVER) {
					if (evaluationResult.resolverResult != null) {
						!(evaluationResult.error == null) && invariant(false);
						var liveState = evaluationResult.resolverResult;
						updatedDataIDs = this._setLiveStateValue(linkedRecord, linkedID, liveState, field, variables);
					}
				} else updatedDataIDs = this._setResolverValue(linkedRecord, evaluationResult.resolverResult, field, variables);
				recordSource.set(linkedID, linkedRecord);
				var currentRecord = expectRecord(recordSource, recordID);
				var nextRecord = RelayModernRecord.clone(currentRecord);
				RelayModernRecord.setLinkedRecordID(nextRecord, storageKey, linkedID);
				recordSource.set(recordID, nextRecord);
				if (field.fragment != null) {
					var _evaluationResult$sna2;
					var resolverID = generateClientID(recordID, getStorageKey(field.fragment, variables));
					addDependencyEdge(this._resolverIDToRecordIDs, resolverID, linkedID);
					addDependencyEdge(this._recordIDToResolverIDs, recordID, resolverID);
					var seenRecordIds = (_evaluationResult$sna2 = evaluationResult.snapshot) === null || _evaluationResult$sna2 === void 0 ? void 0 : _evaluationResult$sna2.seenRecords;
					if (seenRecordIds != null) {
						var _iterator = (0, _createForOfIteratorHelper2["default"])(seenRecordIds), _step;
						try {
							for (_iterator.s(); !(_step = _iterator.n()).done;) {
								var seenRecordID = _step.value;
								addDependencyEdge(this._recordIDToResolverIDs, seenRecordID, resolverID);
							}
						} catch (err) {
							_iterator.e(err);
						} finally {
							_iterator.f();
						}
					}
				}
			} else if (field.kind === RELAY_LIVE_RESOLVER && RelayModernRecord.getValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_DIRTY)) {
				var _linkedID2;
				linkedID = (_linkedID2 = linkedID) !== null && _linkedID2 !== void 0 ? _linkedID2 : generateClientID(recordID, storageKey);
				linkedRecord = RelayModernRecord.clone(linkedRecord);
				var _liveState = RelayModernRecord.getValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_VALUE);
				if (!isLiveStateValue(_liveState)) invariant(false);
				updatedDataIDs = this._setLiveResolverValue(linkedRecord, _liveState, field, variables);
				RelayModernRecord.setValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_DIRTY, false);
				recordSource.set(linkedID, linkedRecord);
			}
			var answer = this._getResolverValue(linkedRecord);
			var snapshot = RelayModernRecord.getValue(linkedRecord, RELAY_RESOLVER_SNAPSHOT_KEY);
			var error = RelayModernRecord.getValue(linkedRecord, RELAY_RESOLVER_ERROR_KEY);
			var suspenseID = null;
			if (isSuspenseSentinel(answer)) {
				var _linkedID3;
				suspenseID = (_linkedID3 = linkedID) !== null && _linkedID3 !== void 0 ? _linkedID3 : generateClientID(recordID, storageKey);
			}
			return [
				answer,
				linkedID,
				error,
				snapshot,
				suspenseID,
				updatedDataIDs
			];
		};
		_proto.getLiveResolverPromise = function getLiveResolverPromise(liveStateID) {
			var liveStateRecord = this._getRecordSource().get(liveStateID);
			!(liveStateRecord != null) && invariant(false);
			var liveState = RelayModernRecord.getValue(liveStateRecord, RELAY_RESOLVER_LIVE_STATE_VALUE);
			return new Promise(function(resolve) {
				var unsubscribe = liveState.subscribe(function() {
					unsubscribe();
					resolve();
				});
			});
		};
		_proto._setLiveStateValue = function _setLiveStateValue(linkedRecord, linkedID, liveState, field, variables) {
			var handler = this._makeLiveStateHandler(linkedID);
			var unsubscribe = liveState.subscribe(handler);
			RelayModernRecord.setValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_VALUE, liveState);
			var updatedDataIDs = this._setLiveResolverValue(linkedRecord, liveState, field, variables);
			RelayModernRecord.setValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_DIRTY, false);
			RelayModernRecord.setValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY, unsubscribe);
			return updatedDataIDs;
		};
		_proto._makeLiveStateHandler = function _makeLiveStateHandler(linkedID) {
			var _this = this;
			return function() {
				var currentRecord = _this._getRecordSource().get(linkedID);
				if (!currentRecord) return;
				if (!RelayModernRecord.hasValue(currentRecord, RELAY_RESOLVER_LIVE_STATE_VALUE)) return;
				var nextRecord = RelayModernRecord.clone(currentRecord);
				RelayModernRecord.setValue(nextRecord, RELAY_RESOLVER_LIVE_STATE_DIRTY, true);
				_this._setLiveResolverUpdate(linkedID, nextRecord);
			};
		};
		_proto._setLiveResolverUpdate = function _setLiveResolverUpdate(linkedId, record) {
			if (this._handlingBatch) {
				if (this._liveResolverBatchRecordSource == null) this._liveResolverBatchRecordSource = RelayRecordSource.create();
				this._liveResolverBatchRecordSource.set(linkedId, record);
			} else {
				var nextSource = RelayRecordSource.create();
				nextSource.set(linkedId, record);
				this._store.publish(nextSource);
				this._store.notify();
			}
		};
		_proto.batchLiveStateUpdates = function batchLiveStateUpdates(callback) {
			this._handlingBatch && invariant(false);
			this._handlingBatch = true;
			try {
				callback();
			} finally {
				if (this._liveResolverBatchRecordSource != null) {
					this._store.publish(this._liveResolverBatchRecordSource);
					this._store.notify();
				}
				this._liveResolverBatchRecordSource = null;
				this._handlingBatch = false;
			}
		};
		_proto._setLiveResolverValue = function _setLiveResolverValue(resolverRecord, liveValue, field, variables) {
			var value = null;
			var resolverError = null;
			try {
				value = liveValue.read();
			} catch (e) {
				resolverError = e;
			}
			RelayModernRecord.setValue(resolverRecord, RELAY_RESOLVER_ERROR_KEY, resolverError);
			return this._setResolverValue(resolverRecord, value, field, variables);
		};
		_proto._setResolverValue = function _setResolverValue(resolverRecord, value, field, variables) {
			var normalizationInfo = field.normalizationInfo;
			var updatedDataIDs = null;
			if (value != null && normalizationInfo != null && !isSuspenseSentinel(value)) {
				var resolverValue;
				var prevOutputTypeRecordIDs = getOutputTypeRecordIDs(resolverRecord);
				var nextOutputTypeRecordIDs = /* @__PURE__ */ new Set();
				var currentSource = this._getRecordSource();
				if (normalizationInfo.plural) {
					!Array.isArray(value) && invariant(false);
					resolverValue = [];
					var nextSource = RelayRecordSource.create();
					for (var ii = 0; ii < value.length; ii++) {
						var currentValue = value[ii];
						if (currentValue == null) continue;
						!(typeof currentValue === "object") && invariant(false);
						var typename = getConcreteTypename(normalizationInfo, currentValue);
						var outputTypeDataID = generateClientObjectClientID(typename, RelayModernRecord.getDataID(resolverRecord), ii);
						var source = this._normalizeOutputTypeValue(outputTypeDataID, currentValue, variables, normalizationInfo, [field.path, String(ii)], typename);
						var _iterator2 = (0, _createForOfIteratorHelper2["default"])(source.getRecordIDs()), _step2;
						try {
							for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
								var recordID = _step2.value;
								nextSource.set(recordID, expectRecord(source, recordID));
								nextOutputTypeRecordIDs.add(recordID);
							}
						} catch (err) {
							_iterator2.e(err);
						} finally {
							_iterator2.f();
						}
						resolverValue.push(outputTypeDataID);
					}
					updatedDataIDs = updateCurrentSource(currentSource, nextSource, prevOutputTypeRecordIDs);
				} else {
					!(typeof value === "object") && invariant(false);
					var _typename = getConcreteTypename(normalizationInfo, value);
					var _outputTypeDataID = generateClientObjectClientID(_typename, RelayModernRecord.getDataID(resolverRecord));
					var _nextSource = this._normalizeOutputTypeValue(_outputTypeDataID, value, variables, normalizationInfo, [field.path], _typename);
					var _iterator3 = (0, _createForOfIteratorHelper2["default"])(_nextSource.getRecordIDs()), _step3;
					try {
						for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
							var _recordID = _step3.value;
							nextOutputTypeRecordIDs.add(_recordID);
						}
					} catch (err) {
						_iterator3.e(err);
					} finally {
						_iterator3.f();
					}
					resolverValue = _outputTypeDataID;
					updatedDataIDs = updateCurrentSource(currentSource, _nextSource, prevOutputTypeRecordIDs);
				}
				RelayModernRecord.setValue(resolverRecord, RELAY_RESOLVER_OUTPUT_TYPE_RECORD_IDS, nextOutputTypeRecordIDs);
				shallowFreeze(resolverValue);
				RelayModernRecord.setValue(resolverRecord, RELAY_RESOLVER_VALUE_KEY, resolverValue);
			} else {
				shallowFreeze(value);
				RelayModernRecord.setValue(resolverRecord, RELAY_RESOLVER_VALUE_KEY, value);
			}
			return updatedDataIDs;
		};
		_proto.notifyUpdatedSubscribers = function notifyUpdatedSubscribers(updatedDataIDs) {
			this._store.__notifyUpdatedSubscribers(updatedDataIDs);
		};
		_proto._getResolverValue = function _getResolverValue(resolverRecord) {
			return RelayModernRecord.getValue(resolverRecord, RELAY_RESOLVER_VALUE_KEY);
		};
		_proto.invalidateDataIDs = function invalidateDataIDs(updatedDataIDs) {
			var recordSource = this._getRecordSource();
			var visited = /* @__PURE__ */ new Set();
			var recordsToVisit = Array.from(updatedDataIDs);
			while (recordsToVisit.length) {
				var recordID = recordsToVisit.pop();
				visited.add(recordID);
				updatedDataIDs.add(recordID);
				var fragmentSet = this._recordIDToResolverIDs.get(recordID);
				if (fragmentSet == null) continue;
				var _iterator4 = (0, _createForOfIteratorHelper2["default"])(fragmentSet), _step4;
				try {
					for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
						var fragment = _step4.value;
						if (!visited.has(fragment)) {
							visited.add(fragment);
							var recordSet = this._resolverIDToRecordIDs.get(fragment);
							if (recordSet == null) continue;
							var _iterator5 = (0, _createForOfIteratorHelper2["default"])(recordSet), _step5;
							try {
								for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
									var anotherRecordID = _step5.value;
									markInvalidatedResolverRecord(anotherRecordID, recordSource);
									if (!visited.has(anotherRecordID)) {
										visited.add(anotherRecordID);
										recordsToVisit.push(anotherRecordID);
									}
								}
							} catch (err) {
								_iterator5.e(err);
							} finally {
								_iterator5.f();
							}
						}
					}
				} catch (err) {
					_iterator4.e(err);
				} finally {
					_iterator4.f();
				}
			}
		};
		_proto._isInvalid = function _isInvalid(record, getDataForResolverFragment) {
			if (!RelayModernRecord.getValue(record, RELAY_RESOLVER_INVALIDATION_KEY)) return false;
			var snapshot = RelayModernRecord.getValue(record, RELAY_RESOLVER_SNAPSHOT_KEY);
			var originalInputs = snapshot === null || snapshot === void 0 ? void 0 : snapshot.data;
			var readerSelector = snapshot === null || snapshot === void 0 ? void 0 : snapshot.selector;
			if (originalInputs == null || readerSelector == null) return true;
			var latestValues = getDataForResolverFragment(readerSelector).data;
			if (recycleNodesInto(originalInputs, latestValues) !== originalInputs) return true;
			if (RelayFeatureFlags.MARK_RESOLVER_VALUES_AS_CLEAN_AFTER_FRAGMENT_REREAD) {
				var nextRecord = RelayModernRecord.clone(record);
				RelayModernRecord.setValue(nextRecord, RELAY_RESOLVER_INVALIDATION_KEY, false);
				this._getRecordSource().set(RelayModernRecord.getDataID(record), nextRecord);
			}
			return false;
		};
		_proto._normalizeOutputTypeValue = function _normalizeOutputTypeValue(outputTypeDataID, value, variables, normalizationInfo, fieldPath, typename) {
			var source = RelayRecordSource.create();
			switch (normalizationInfo.kind) {
				case "OutputType":
					var record = RelayModernRecord.create(outputTypeDataID, typename);
					source.set(outputTypeDataID, record);
					return normalize(source, createNormalizationSelector(normalizationInfo.normalizationNode, outputTypeDataID, variables), value, this._store.__getNormalizationOptions(fieldPath), void 0, false).source;
				case "WeakModel":
					var _record = RelayModernRecord.create(outputTypeDataID, typename);
					RelayModernRecord.setValue(_record, MODEL_PROPERTY_NAME, value);
					source.set(outputTypeDataID, _record);
					return source;
				default:
					normalizationInfo.kind;
					invariant(false);
			}
		};
		_proto.ensureClientRecord = function ensureClientRecord(id, typeName) {
			var key = generateClientObjectClientID(typeName, id);
			var recordSource = this._getRecordSource();
			if (!recordSource.has(key)) {
				var newRecord = RelayModernRecord.create(key, typeName);
				RelayModernRecord.setValue(newRecord, "id", id);
				recordSource.set(key, newRecord);
			}
			return key;
		};
		_proto.unsubscribeFromLiveResolverRecords = function unsubscribeFromLiveResolverRecords(invalidatedDataIDs) {
			return unsubscribeFromLiveResolverRecordsImpl(this._getRecordSource(), invalidatedDataIDs);
		};
		_proto.invalidateResolverRecords = function invalidateResolverRecords(invalidatedDataIDs) {
			if (invalidatedDataIDs.size === 0) return;
			var _iterator6 = (0, _createForOfIteratorHelper2["default"])(invalidatedDataIDs), _step6;
			try {
				for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
					var dataID = _step6.value;
					var record = this._getRecordSource().get(dataID);
					if (record != null && isResolverRecord(record)) this._getRecordSource()["delete"](dataID);
				}
			} catch (err) {
				_iterator6.e(err);
			} finally {
				_iterator6.f();
			}
		};
		return LiveResolverCache;
	}();
	function updateCurrentSource(currentSource, nextSource, prevOutputTypeRecordIDs) {
		var updatedDataIDs = /* @__PURE__ */ new Set();
		if (prevOutputTypeRecordIDs != null) {
			var _iterator7 = (0, _createForOfIteratorHelper2["default"])(prevOutputTypeRecordIDs), _step7;
			try {
				for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
					var recordID = _step7.value;
					if (!nextSource.has(recordID)) {
						updatedDataIDs.add(recordID);
						currentSource.remove(recordID);
					}
				}
			} catch (err) {
				_iterator7.e(err);
			} finally {
				_iterator7.f();
			}
		}
		var _iterator8 = (0, _createForOfIteratorHelper2["default"])(nextSource.getRecordIDs()), _step8;
		try {
			for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
				var _recordID2 = _step8.value;
				var nextRecord = expectRecord(nextSource, _recordID2);
				if (currentSource.has(_recordID2)) {
					var currentRecord = expectRecord(currentSource, _recordID2);
					var updatedRecord = RelayModernRecord.update(currentRecord, nextRecord);
					if (updatedRecord !== currentRecord) {
						updatedDataIDs.add(_recordID2);
						currentSource.set(_recordID2, updatedRecord);
						markInvalidatedLinkedResolverRecords(currentRecord, currentSource);
					}
				} else currentSource.set(_recordID2, nextRecord);
			}
		} catch (err) {
			_iterator8.e(err);
		} finally {
			_iterator8.f();
		}
		return updatedDataIDs;
	}
	function getAllLinkedRecordIds(record) {
		var linkedRecordIDs = /* @__PURE__ */ new Set();
		RelayModernRecord.getFields(record).forEach(function(field) {
			if (RelayModernRecord.hasLinkedRecordID(record, field)) {
				var linkedRecordID = RelayModernRecord.getLinkedRecordID(record, field);
				if (linkedRecordID != null) linkedRecordIDs.add(linkedRecordID);
			} else if (RelayModernRecord.hasLinkedRecordIDs(record, field)) {
				var _RelayModernRecord$ge;
				(_RelayModernRecord$ge = RelayModernRecord.getLinkedRecordIDs(record, field)) === null || _RelayModernRecord$ge === void 0 || _RelayModernRecord$ge.forEach(function(linkedRecordID) {
					if (linkedRecordID != null) linkedRecordIDs.add(linkedRecordID);
				});
			}
		});
		return linkedRecordIDs;
	}
	function markInvalidatedResolverRecord(dataID, recordSource) {
		var record = recordSource.get(dataID);
		if (!record) return;
		var nextRecord = RelayModernRecord.clone(record);
		RelayModernRecord.setValue(nextRecord, RELAY_RESOLVER_INVALIDATION_KEY, true);
		recordSource.set(dataID, nextRecord);
	}
	function markInvalidatedLinkedResolverRecords(record, recordSource) {
		var currentLinkedDataIDs = getAllLinkedRecordIds(record);
		var _iterator9 = (0, _createForOfIteratorHelper2["default"])(currentLinkedDataIDs), _step9;
		try {
			for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
				var recordID = _step9.value;
				var _record2 = recordSource.get(recordID);
				if (_record2 != null && isResolverRecord(_record2)) markInvalidatedResolverRecord(recordID, recordSource);
			}
		} catch (err) {
			_iterator9.e(err);
		} finally {
			_iterator9.f();
		}
	}
	function unsubscribeFromLiveResolverRecordsImpl(recordSource, invalidatedDataIDs) {
		if (invalidatedDataIDs.size === 0) return;
		var _iterator10 = (0, _createForOfIteratorHelper2["default"])(invalidatedDataIDs), _step10;
		try {
			for (_iterator10.s(); !(_step10 = _iterator10.n()).done;) {
				var dataID = _step10.value;
				var record = recordSource.get(dataID);
				if (record != null && isResolverRecord(record)) maybeUnsubscribeFromLiveState(record);
			}
		} catch (err) {
			_iterator10.e(err);
		} finally {
			_iterator10.f();
		}
	}
	function isResolverRecord(record) {
		return RelayModernRecord.getType(record) === RELAY_RESOLVER_RECORD_TYPENAME;
	}
	function maybeUnsubscribeFromLiveState(linkedRecord) {
		var previousUnsubscribe = RelayModernRecord.getValue(linkedRecord, RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY);
		if (previousUnsubscribe != null) previousUnsubscribe();
	}
	function expectRecord(source, recordID) {
		var record = source.get(recordID);
		!(record != null) && invariant(false);
		return record;
	}
	function getUpdatedDataIDs(updatedRecords) {
		return updatedRecords;
	}
	function getConcreteTypename(normalizationInfo, currentValue) {
		var _normalizationInfo$co;
		var typename = (_normalizationInfo$co = normalizationInfo.concreteType) !== null && _normalizationInfo$co !== void 0 ? _normalizationInfo$co : currentValue.__typename;
		!(typename != null) && invariant(false);
		return typename;
	}
	module.exports = {
		LiveResolverCache,
		getUpdatedDataIDs,
		RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY
	};
}));
var require_RelayOptimisticRecordSource = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var RelayModernRecord = require_RelayModernRecord();
	var RelayRecordSource = require_RelayRecordSource();
	var invariant = require_invariant();
	var UNPUBLISH_RECORD_SENTINEL = RelayModernRecord.fromObject(Object.freeze({ __UNPUBLISH_RECORD_SENTINEL: true }));
	var RelayOptimisticRecordSource = /* @__PURE__ */ function() {
		function RelayOptimisticRecordSource(base) {
			this._base = base;
			this._sink = RelayRecordSource.create();
		}
		var _proto = RelayOptimisticRecordSource.prototype;
		_proto.has = function has(dataID) {
			if (this._sink.has(dataID)) return this._sink.get(dataID) !== UNPUBLISH_RECORD_SENTINEL;
			else return this._base.has(dataID);
		};
		_proto.get = function get(dataID) {
			if (this._sink.has(dataID)) {
				var sinkRecord = this._sink.get(dataID);
				if (sinkRecord === UNPUBLISH_RECORD_SENTINEL) return;
				else return sinkRecord;
			} else return this._base.get(dataID);
		};
		_proto.getStatus = function getStatus(dataID) {
			var record = this.get(dataID);
			if (record === void 0) return "UNKNOWN";
			else if (record === null) return "NONEXISTENT";
			else return "EXISTENT";
		};
		_proto.clear = function clear() {
			this._base = RelayRecordSource.create();
			this._sink.clear();
		};
		_proto["delete"] = function _delete(dataID) {
			this._sink["delete"](dataID);
		};
		_proto.remove = function remove(dataID) {
			this._sink.set(dataID, UNPUBLISH_RECORD_SENTINEL);
		};
		_proto.set = function set(dataID, record) {
			this._sink.set(dataID, record);
		};
		_proto.getRecordIDs = function getRecordIDs() {
			return Object.keys(this.toJSON());
		};
		_proto.size = function size() {
			return Object.keys(this.toJSON()).length;
		};
		_proto.toJSON = function toJSON() {
			var _this = this;
			var merged = (0, _objectSpread2["default"])({}, this._base.toJSON());
			this._sink.getRecordIDs().forEach(function(dataID) {
				var record = _this.get(dataID);
				if (record === void 0) delete merged[dataID];
				else merged[dataID] = RelayModernRecord.toJSON(record);
			});
			return merged;
		};
		_proto.getOptimisticRecordIDs = function getOptimisticRecordIDs() {
			return new Set(this._sink.getRecordIDs());
		};
		return RelayOptimisticRecordSource;
	}();
	function create(base) {
		return new RelayOptimisticRecordSource(base);
	}
	function getOptimisticRecordIDs(source) {
		!(source instanceof RelayOptimisticRecordSource) && invariant(false);
		return source.getOptimisticRecordIDs();
	}
	module.exports = {
		create,
		getOptimisticRecordIDs
	};
}));
var require_ResolverCache = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RELAY_LIVE_RESOLVER = require_RelayConcreteNode().RELAY_LIVE_RESOLVER;
	var invariant = require_invariant();
	module.exports = { NoopResolverCache: /* @__PURE__ */ function() {
		function NoopResolverCache() {}
		var _proto = NoopResolverCache.prototype;
		_proto.readFromCacheOrEvaluate = function readFromCacheOrEvaluate(recordID, field, variables, evaluate, getDataForResolverFragment) {
			!(field.kind !== RELAY_LIVE_RESOLVER) && invariant(false);
			var _evaluate = evaluate(), resolverResult = _evaluate.resolverResult, snapshot = _evaluate.snapshot;
			return [
				resolverResult,
				void 0,
				_evaluate.error,
				snapshot,
				void 0,
				void 0
			];
		};
		_proto.invalidateDataIDs = function invalidateDataIDs(updatedDataIDs) {};
		_proto.ensureClientRecord = function ensureClientRecord(id, typeName) {
			invariant(false);
		};
		_proto.notifyUpdatedSubscribers = function notifyUpdatedSubscribers(updatedDataIDs) {};
		return NoopResolverCache;
	}() };
}));
var require_RelayReader = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require_objectWithoutPropertiesLoose());
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var _excluded = ["message"];
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var isSuspenseSentinel = require_LiveResolverSuspenseSentinel().isSuspenseSentinel;
	var RelayConcreteVariables = require_RelayConcreteVariables();
	var RelayModernRecord = require_RelayModernRecord();
	var _require2 = require_RelayStoreUtils(), CLIENT_EDGE_TRAVERSAL_PATH = _require2.CLIENT_EDGE_TRAVERSAL_PATH, FRAGMENT_OWNER_KEY = _require2.FRAGMENT_OWNER_KEY, FRAGMENT_PROP_NAME_KEY = _require2.FRAGMENT_PROP_NAME_KEY, FRAGMENTS_KEY = _require2.FRAGMENTS_KEY, ID_KEY = _require2.ID_KEY, MODULE_COMPONENT_KEY = _require2.MODULE_COMPONENT_KEY, ROOT_ID = _require2.ROOT_ID, getArgumentValues = _require2.getArgumentValues, getModuleComponentKey = _require2.getModuleComponentKey, getStorageKey = _require2.getStorageKey;
	var NoopResolverCache = require_ResolverCache().NoopResolverCache;
	var _require4 = require_ResolverFragments(), RESOLVER_FRAGMENT_ERRORED_SENTINEL = _require4.RESOLVER_FRAGMENT_ERRORED_SENTINEL, withResolverContext = _require4.withResolverContext;
	var generateTypeID = require_TypeID().generateTypeID;
	var invariant = require_invariant();
	function read(recordSource, selector, resolverCache, resolverContext) {
		return new RelayReader(recordSource, selector, resolverCache !== null && resolverCache !== void 0 ? resolverCache : new NoopResolverCache(), resolverContext).read();
	}
	var RelayReader = /* @__PURE__ */ function() {
		function RelayReader(recordSource, selector, resolverCache, resolverContext) {
			var _selector$clientEdgeT, _ref, _this$_owner$node$ope, _this$_owner$node$ope2;
			this._clientEdgeTraversalPath = (_selector$clientEdgeT = selector.clientEdgeTraversalPath) !== null && _selector$clientEdgeT !== void 0 && _selector$clientEdgeT.length ? (0, _toConsumableArray2["default"])(selector.clientEdgeTraversalPath) : [];
			this._missingClientEdges = [];
			this._missingLiveResolverFields = [];
			this._isMissingData = false;
			this._isWithinUnmatchedTypeRefinement = false;
			this._fieldErrors = null;
			this._owner = selector.owner;
			this._useExecTimeResolvers = (_ref = (_this$_owner$node$ope = this._owner.node.operation.use_exec_time_resolvers) !== null && _this$_owner$node$ope !== void 0 ? _this$_owner$node$ope : ((_this$_owner$node$ope2 = this._owner.node.operation.exec_time_resolvers_enabled_provider) === null || _this$_owner$node$ope2 === void 0 ? void 0 : _this$_owner$node$ope2.get()) === true) !== null && _ref !== void 0 ? _ref : false;
			this._recordSource = recordSource;
			this._seenRecords = /* @__PURE__ */ new Set();
			this._selector = selector;
			this._variables = selector.variables;
			this._resolverCache = resolverCache;
			this._fragmentName = selector.node.name;
			this._updatedDataIDs = /* @__PURE__ */ new Set();
			this._resolverContext = resolverContext;
		}
		var _proto = RelayReader.prototype;
		_proto.read = function read() {
			var _this$_selector$node$;
			var _this$_selector = this._selector, node = _this$_selector.node, dataID = _this$_selector.dataID, isWithinUnmatchedTypeRefinement = _this$_selector.isWithinUnmatchedTypeRefinement;
			var abstractKey = node.abstractKey;
			var record = this._recordSource.get(dataID);
			var isDataExpectedToBePresent = !isWithinUnmatchedTypeRefinement;
			if (isDataExpectedToBePresent && abstractKey == null && record != null) {
				if (!this._recordMatchesTypeCondition(record, node.type)) isDataExpectedToBePresent = false;
			}
			if (isDataExpectedToBePresent && abstractKey != null && record != null) {
				if (this._implementsInterface(record, abstractKey) === false) isDataExpectedToBePresent = false;
			}
			this._isWithinUnmatchedTypeRefinement = !isDataExpectedToBePresent;
			var data = this._traverse(node, dataID, null);
			var catchTo = (_this$_selector$node$ = this._selector.node.metadata) === null || _this$_selector$node$ === void 0 ? void 0 : _this$_selector$node$.catchTo;
			if (catchTo != null) data = this._catchErrors(data, catchTo, null);
			if (this._updatedDataIDs.size > 0) {
				this._resolverCache.notifyUpdatedSubscribers(this._updatedDataIDs);
				this._updatedDataIDs.clear();
			}
			return {
				data,
				isMissingData: this._isMissingData && isDataExpectedToBePresent,
				missingClientEdges: this._missingClientEdges.length ? this._missingClientEdges : null,
				missingLiveResolverFields: this._missingLiveResolverFields,
				seenRecords: this._seenRecords,
				selector: this._selector,
				fieldErrors: this._fieldErrors
			};
		};
		_proto._maybeAddFieldErrors = function _maybeAddFieldErrors(record, storageKey) {
			var errors = RelayModernRecord.getErrors(record, storageKey);
			if (errors == null) return;
			var owner = this._fragmentName;
			if (this._fieldErrors == null) this._fieldErrors = [];
			for (var i = 0; i < errors.length; i++) {
				var _error$path, _this$_selector$node$2, _this$_selector$node$3;
				var error = errors[i];
				this._fieldErrors.push({
					kind: "relay_field_payload.error",
					owner,
					fieldPath: ((_error$path = error.path) !== null && _error$path !== void 0 ? _error$path : []).join("."),
					error,
					shouldThrow: (_this$_selector$node$2 = (_this$_selector$node$3 = this._selector.node.metadata) === null || _this$_selector$node$3 === void 0 ? void 0 : _this$_selector$node$3.throwOnFieldError) !== null && _this$_selector$node$2 !== void 0 ? _this$_selector$node$2 : false,
					handled: false,
					uiContext: void 0
				});
			}
		};
		_proto._markDataAsMissing = function _markDataAsMissing(fieldName) {
			var _this$_selector$node$4, _this$_selector$node$5;
			if (this._isWithinUnmatchedTypeRefinement) return;
			if (this._fieldErrors == null) this._fieldErrors = [];
			var owner = this._fragmentName;
			this._fieldErrors.push(((_this$_selector$node$4 = (_this$_selector$node$5 = this._selector.node.metadata) === null || _this$_selector$node$5 === void 0 ? void 0 : _this$_selector$node$5.throwOnFieldError) !== null && _this$_selector$node$4 !== void 0 ? _this$_selector$node$4 : false) ? {
				kind: "missing_expected_data.throw",
				owner,
				fieldPath: fieldName,
				handled: false,
				uiContext: void 0
			} : {
				kind: "missing_expected_data.log",
				owner,
				fieldPath: fieldName,
				uiContext: void 0
			});
			this._isMissingData = true;
			if (this._clientEdgeTraversalPath.length) {
				var top = this._clientEdgeTraversalPath[this._clientEdgeTraversalPath.length - 1];
				if (top !== null) this._missingClientEdges.push({
					request: top.readerClientEdge.operation,
					clientEdgeDestinationID: top.clientEdgeDestinationID
				});
			}
		};
		_proto._traverse = function _traverse(node, dataID, prevData) {
			var record = this._recordSource.get(dataID);
			this._seenRecords.add(dataID);
			if (record == null) {
				if (record === void 0) this._markDataAsMissing("<record>");
				return record;
			}
			var data = prevData || {};
			return this._traverseSelections(node.selections, record, data) ? data : null;
		};
		_proto._getVariableValue = function _getVariableValue(name) {
			!this._variables.hasOwnProperty(name) && invariant(false);
			return this._variables[name];
		};
		_proto._maybeReportUnexpectedNull = function _maybeReportUnexpectedNull(selection) {
			if (selection.action === "NONE") return;
			var owner = this._fragmentName;
			if (this._fieldErrors == null) this._fieldErrors = [];
			var fieldName;
			if (selection.field.linkedField != null) {
				var _selection$field$link;
				fieldName = (_selection$field$link = selection.field.linkedField.alias) !== null && _selection$field$link !== void 0 ? _selection$field$link : selection.field.linkedField.name;
			} else {
				var _selection$field$alia;
				fieldName = (_selection$field$alia = selection.field.alias) !== null && _selection$field$alia !== void 0 ? _selection$field$alia : selection.field.name;
			}
			switch (selection.action) {
				case "THROW":
					this._fieldErrors.push({
						kind: "missing_required_field.throw",
						fieldPath: fieldName,
						owner,
						handled: false,
						uiContext: void 0
					});
					return;
				case "LOG":
					this._fieldErrors.push({
						kind: "missing_required_field.log",
						fieldPath: fieldName,
						owner,
						uiContext: void 0
					});
					return;
				default: selection.action;
			}
		};
		_proto._handleRequiredFieldValue = function _handleRequiredFieldValue(selection, value) {
			if (value == null) {
				this._maybeReportUnexpectedNull(selection);
				return false;
			}
			return true;
		};
		_proto._catchErrors = function _catchErrors(_value, to, previousResponseFields) {
			var value = _value;
			switch (to) {
				case "RESULT":
					value = this._asResult(_value);
					break;
				case "NULL":
					if (this._fieldErrors != null && this._fieldErrors.length > 0) value = null;
					break;
				default:
			}
			var childrenFieldErrors = this._fieldErrors;
			this._fieldErrors = previousResponseFields;
			if (childrenFieldErrors != null) {
				if (this._fieldErrors == null) this._fieldErrors = [];
				for (var i = 0; i < childrenFieldErrors.length; i++) this._fieldErrors.push(markFieldErrorHasHandled(childrenFieldErrors[i]));
			}
			return value;
		};
		_proto._asResult = function _asResult(value) {
			if (this._fieldErrors == null || this._fieldErrors.length === 0) return {
				ok: true,
				value
			};
			return {
				ok: false,
				errors: this._fieldErrors.map(function(error) {
					switch (error.kind) {
						case "relay_field_payload.error":
							var _error$error = error.error;
							_error$error.message;
							return (0, _objectWithoutPropertiesLoose2["default"])(_error$error, _excluded);
						case "missing_expected_data.throw":
						case "missing_expected_data.log": return { path: error.fieldPath.split(".") };
						case "relay_resolver.error": return { message: "Relay: Error in resolver for field at ".concat(error.fieldPath, " in ").concat(error.owner) };
						case "missing_required_field.throw": return { message: "Relay: Missing @required value at path '".concat(error.fieldPath, "' in '").concat(error.owner, "'.") };
						case "missing_required_field.log": return null;
						default:
							error.kind;
							invariant(false);
					}
				}).filter(Boolean)
			};
		};
		_proto._traverseSelections = function _traverseSelections(selections, record, data) {
			for (var i = 0; i < selections.length; i++) {
				var selection = selections[i];
				switch (selection.kind) {
					case "RequiredField":
						var requiredFieldValue = this._readClientSideDirectiveField(selection, record, data);
						if (!this._handleRequiredFieldValue(selection, requiredFieldValue)) return false;
						break;
					case "CatchField":
						var _selection$field$back, _selection$field, _field$alias;
						var previousResponseFields = this._fieldErrors;
						this._fieldErrors = null;
						var catchFieldValue = this._readClientSideDirectiveField(selection, record, data);
						var field = (_selection$field$back = (_selection$field = selection.field) === null || _selection$field === void 0 ? void 0 : _selection$field.backingField) !== null && _selection$field$back !== void 0 ? _selection$field$back : selection.field;
						var fieldName = (_field$alias = field === null || field === void 0 ? void 0 : field.alias) !== null && _field$alias !== void 0 ? _field$alias : field === null || field === void 0 ? void 0 : field.name;
						!(fieldName != null) && invariant(false);
						data[fieldName] = this._catchErrors(catchFieldValue, selection.to, previousResponseFields);
						break;
					case "ScalarField":
						this._readScalar(selection, record, data);
						break;
					case "LinkedField":
						if (selection.plural) this._readPluralLink(selection, record, data);
						else this._readLink(selection, record, data);
						break;
					case "Condition":
						if (Boolean(this._getVariableValue(selection.condition)) === selection.passingValue) {
							if (!this._traverseSelections(selection.selections, record, data)) return false;
						}
						break;
					case "InlineFragment":
						if (this._readInlineFragment(selection, record, data, false) === false) return false;
						break;
					case "RelayLiveResolver":
					case "RelayResolver":
						if (this._useExecTimeResolvers) this._readScalar(selection, record, data);
						else this._readResolverField(selection, record, data);
						break;
					case "FragmentSpread":
						this._createFragmentPointer(selection, record, data);
						break;
					case "AliasedInlineFragmentSpread":
						this._readAliasedInlineFragment(selection, record, data);
						break;
					case "ModuleImport":
						this._readModuleImport(selection, record, data);
						break;
					case "InlineDataFragmentSpread":
						this._createInlineDataOrResolverFragmentPointer(selection, record, data);
						break;
					case "Defer":
					case "ClientExtension":
						var isMissingData = this._isMissingData;
						var alreadyMissingClientEdges = this._missingClientEdges.length;
						this._clientEdgeTraversalPath.push(null);
						var _hasExpectedData2 = this._traverseSelections(selection.selections, record, data);
						this._isMissingData = isMissingData || this._missingClientEdges.length > alreadyMissingClientEdges || this._missingLiveResolverFields.length > 0;
						this._clientEdgeTraversalPath.pop();
						if (!_hasExpectedData2) return false;
						break;
					case "Stream":
						if (!this._traverseSelections(selection.selections, record, data)) return false;
						break;
					case "ActorChange":
						this._readActorChange(selection, record, data);
						break;
					case "ClientEdgeToClientObject":
					case "ClientEdgeToServerObject":
						if (this._useExecTimeResolvers && (selection.backingField.kind === "RelayResolver" || selection.backingField.kind === "RelayLiveResolver")) {
							var linkedField = selection.linkedField;
							if (linkedField.plural) this._readPluralLink(linkedField, record, data);
							else this._readLink(linkedField, record, data);
						} else this._readClientEdge(selection, record, data);
						break;
					default: invariant(false);
				}
			}
			return true;
		};
		_proto._readClientSideDirectiveField = function _readClientSideDirectiveField(selection, record, data) {
			switch (selection.field.kind) {
				case "ScalarField": return this._readScalar(selection.field, record, data);
				case "LinkedField": if (selection.field.plural) return this._readPluralLink(selection.field, record, data);
				else return this._readLink(selection.field, record, data);
				case "RelayResolver":
				case "RelayLiveResolver": if (this._useExecTimeResolvers) return this._readScalar(selection.field, record, data);
				else return this._readResolverField(selection.field, record, data);
				case "ClientEdgeToClientObject":
				case "ClientEdgeToServerObject": if (this._useExecTimeResolvers && (selection.field.backingField.kind === "RelayResolver" || selection.field.backingField.kind === "RelayLiveResolver")) {
					var field = selection.field;
					if (field.linkedField.plural) return this._readPluralLink(field.linkedField, record, data);
					else return this._readLink(field.linkedField, record, data);
				} else return this._readClientEdge(selection.field, record, data);
				case "AliasedInlineFragmentSpread": return this._readAliasedInlineFragment(selection.field, record, data);
				default:
					selection.field.kind;
					invariant(false);
			}
		};
		_proto._readResolverField = function _readResolverField(field, record, data) {
			var _field$alias2;
			var parentRecordID = RelayModernRecord.getDataID(record);
			var prevErrors = this._fieldErrors;
			this._fieldErrors = null;
			var result = this._readResolverFieldImpl(field, parentRecordID);
			var fieldName = (_field$alias2 = field.alias) !== null && _field$alias2 !== void 0 ? _field$alias2 : field.name;
			this._prependPreviousErrors(prevErrors, fieldName);
			data[fieldName] = result;
			return result;
		};
		_proto._readResolverFieldImpl = function _readResolverFieldImpl(field, parentRecordID) {
			var _this = this;
			var fragment = field.fragment;
			var snapshot;
			var getDataForResolverFragment = function getDataForResolverFragment(singularReaderSelector) {
				if (snapshot != null) return {
					data: snapshot.data,
					isMissingData: snapshot.isMissingData,
					fieldErrors: snapshot.fieldErrors
				};
				snapshot = read(_this._recordSource, singularReaderSelector, _this._resolverCache);
				return {
					data: snapshot.data,
					isMissingData: snapshot.isMissingData,
					fieldErrors: snapshot.fieldErrors
				};
			};
			var _this$_resolverCache$ = this._resolverCache.readFromCacheOrEvaluate(parentRecordID, field, this._variables, function evaluate() {
				if (fragment != null) {
					var key = {
						__id: parentRecordID,
						__fragmentOwner: _this._owner,
						__fragments: (0, _defineProperty2["default"])({}, fragment.name, fragment.args ? getArgumentValues(fragment.args, _this._variables) : {})
					};
					if (_this._clientEdgeTraversalPath.length > 0 && _this._clientEdgeTraversalPath[_this._clientEdgeTraversalPath.length - 1] !== null) key[CLIENT_EDGE_TRAVERSAL_PATH] = (0, _toConsumableArray2["default"])(_this._clientEdgeTraversalPath);
					return withResolverContext({ getDataForResolverFragment }, function() {
						var _getResolverValue = getResolverValue(field, _this._variables, key, _this._resolverContext), resolverResult = _getResolverValue[0], resolverError = _getResolverValue[1];
						return {
							resolverResult,
							snapshot,
							error: resolverError
						};
					});
				} else {
					var _getResolverValue2 = getResolverValue(field, _this._variables, null, _this._resolverContext);
					return {
						resolverResult: _getResolverValue2[0],
						snapshot: void 0,
						error: _getResolverValue2[1]
					};
				}
			}, getDataForResolverFragment), result = _this$_resolverCache$[0], seenRecord = _this$_resolverCache$[1], resolverError = _this$_resolverCache$[2], cachedSnapshot = _this$_resolverCache$[3], suspenseID = _this$_resolverCache$[4], updatedDataIDs = _this$_resolverCache$[5];
			this._propagateResolverMetadata(field.path, cachedSnapshot, resolverError, seenRecord, suspenseID, updatedDataIDs);
			return result;
		};
		_proto._propagateResolverMetadata = function _propagateResolverMetadata(fieldPath, cachedSnapshot, resolverError, seenRecord, suspenseID, updatedDataIDs) {
			var _this2 = this;
			if (cachedSnapshot != null) {
				if (cachedSnapshot.missingClientEdges != null) for (var i = 0; i < cachedSnapshot.missingClientEdges.length; i++) {
					var missing = cachedSnapshot.missingClientEdges[i];
					this._missingClientEdges.push(missing);
				}
				if (cachedSnapshot.missingLiveResolverFields != null) {
					this._isMissingData = this._isMissingData || cachedSnapshot.missingLiveResolverFields.length > 0;
					for (var _i = 0; _i < cachedSnapshot.missingLiveResolverFields.length; _i++) {
						var missingResolverField = cachedSnapshot.missingLiveResolverFields[_i];
						this._missingLiveResolverFields.push(missingResolverField);
					}
				}
				if (cachedSnapshot.fieldErrors != null) {
					if (this._fieldErrors == null) this._fieldErrors = [];
					for (var _i2 = 0; _i2 < cachedSnapshot.fieldErrors.length; _i2++) {
						var _this$_selector$node$6;
						var error = cachedSnapshot.fieldErrors[_i2];
						if (((_this$_selector$node$6 = this._selector.node.metadata) === null || _this$_selector$node$6 === void 0 ? void 0 : _this$_selector$node$6.throwOnFieldError) === true) this._fieldErrors.push(error);
						else this._fieldErrors.push(markFieldErrorHasHandled(error));
					}
				}
				this._isMissingData = this._isMissingData || cachedSnapshot.isMissingData;
			}
			if (resolverError) {
				var _this$_selector$node$7, _this$_selector$node$8;
				var errorEvent = {
					kind: "relay_resolver.error",
					fieldPath,
					owner: this._fragmentName,
					error: resolverError,
					shouldThrow: (_this$_selector$node$7 = (_this$_selector$node$8 = this._selector.node.metadata) === null || _this$_selector$node$8 === void 0 ? void 0 : _this$_selector$node$8.throwOnFieldError) !== null && _this$_selector$node$7 !== void 0 ? _this$_selector$node$7 : false,
					handled: false,
					uiContext: void 0
				};
				if (this._fieldErrors == null) this._fieldErrors = [errorEvent];
				else this._fieldErrors.push(errorEvent);
			}
			if (seenRecord != null) this._seenRecords.add(seenRecord);
			if (suspenseID != null) {
				this._isMissingData = true;
				this._missingLiveResolverFields.push(suspenseID);
			}
			if (updatedDataIDs != null) updatedDataIDs.forEach(function(recordID) {
				_this2._updatedDataIDs.add(recordID);
			});
		};
		_proto._readClientEdge = function _readClientEdge(field, record, data) {
			var _this3 = this;
			var _backingField$alias;
			var backingField = field.backingField;
			!(backingField.kind !== "ClientExtension") && invariant(false);
			var fieldName = (_backingField$alias = backingField.alias) !== null && _backingField$alias !== void 0 ? _backingField$alias : backingField.name;
			var backingFieldData = {};
			this._traverseSelections([backingField], record, backingFieldData);
			var clientEdgeResolverResponse = backingFieldData[fieldName];
			if (clientEdgeResolverResponse == null || isSuspenseSentinel(clientEdgeResolverResponse)) {
				data[fieldName] = clientEdgeResolverResponse;
				return clientEdgeResolverResponse;
			}
			if (field.linkedField.plural) {
				!Array.isArray(clientEdgeResolverResponse) && invariant(false);
				var storeIDs;
				!(field.kind === "ClientEdgeToClientObject") && invariant(false);
				if (field.backingField.normalizationInfo == null) storeIDs = clientEdgeResolverResponse.map(function(itemResponse) {
					var _field$concreteType;
					var concreteType = (_field$concreteType = field.concreteType) !== null && _field$concreteType !== void 0 ? _field$concreteType : itemResponse.__typename;
					!(typeof concreteType === "string") && invariant(false);
					var localId = extractIdFromResponse(itemResponse, backingField.path, _this3._owner.identifier);
					var id = _this3._resolverCache.ensureClientRecord(localId, concreteType);
					var modelResolvers = field.modelResolvers;
					if (modelResolvers != null) {
						var modelResolver = modelResolvers[concreteType];
						!(modelResolver !== void 0) && invariant(false);
						return _this3._readResolverFieldImpl(modelResolver, id) != null ? id : null;
					}
					return id;
				});
				else storeIDs = clientEdgeResolverResponse.map(function(obj) {
					return extractIdFromResponse(obj, backingField.path, _this3._owner.identifier);
				});
				this._clientEdgeTraversalPath.push(null);
				var edgeValues = this._readLinkedIds(field.linkedField, storeIDs, record, data);
				this._clientEdgeTraversalPath.pop();
				data[fieldName] = edgeValues;
				return edgeValues;
			} else {
				var _field$concreteType2;
				var id = extractIdFromResponse(clientEdgeResolverResponse, backingField.path, this._owner.identifier);
				var storeID;
				var concreteType = (_field$concreteType2 = field.concreteType) !== null && _field$concreteType2 !== void 0 ? _field$concreteType2 : clientEdgeResolverResponse.__typename;
				var traversalPathSegment;
				if (field.kind === "ClientEdgeToClientObject") if (field.backingField.normalizationInfo == null) {
					!(typeof concreteType === "string") && invariant(false);
					storeID = this._resolverCache.ensureClientRecord(id, concreteType);
					traversalPathSegment = null;
				} else {
					storeID = id;
					traversalPathSegment = null;
				}
				else {
					storeID = id;
					traversalPathSegment = {
						readerClientEdge: field,
						clientEdgeDestinationID: id
					};
				}
				var modelResolvers = field.modelResolvers;
				if (modelResolvers != null) {
					!(typeof concreteType === "string") && invariant(false);
					var modelResolver = modelResolvers[concreteType];
					!(modelResolver !== void 0) && invariant(false);
					if (this._readResolverFieldImpl(modelResolver, storeID) == null) {
						data[fieldName] = null;
						return null;
					}
				}
				this._clientEdgeTraversalPath.push(traversalPathSegment);
				var prevData = data[fieldName];
				!(prevData == null || typeof prevData === "object") && invariant(false);
				var prevErrors = this._fieldErrors;
				this._fieldErrors = null;
				var edgeValue = this._traverse(field.linkedField, storeID, prevData);
				this._prependPreviousErrors(prevErrors, fieldName);
				this._clientEdgeTraversalPath.pop();
				data[fieldName] = edgeValue;
				return edgeValue;
			}
		};
		_proto._readScalar = function _readScalar(field, record, data) {
			var _field$alias3;
			var fieldName = (_field$alias3 = field.alias) !== null && _field$alias3 !== void 0 ? _field$alias3 : field.name;
			var storageKey = getStorageKey(field, this._variables);
			var value = RelayModernRecord.getValue(record, storageKey);
			if (value === null || RelayFeatureFlags.ENABLE_NONCOMPLIANT_ERROR_HANDLING_ON_LISTS && Array.isArray(value) && value.length === 0) this._maybeAddFieldErrors(record, storageKey);
			else if (value === void 0) this._markDataAsMissing(fieldName);
			data[fieldName] = value;
			return value;
		};
		_proto._readLink = function _readLink(field, record, data) {
			var _field$alias4;
			var fieldName = (_field$alias4 = field.alias) !== null && _field$alias4 !== void 0 ? _field$alias4 : field.name;
			var storageKey = getStorageKey(field, this._variables);
			var linkedID = RelayModernRecord.getLinkedRecordID(record, storageKey);
			if (linkedID == null) {
				data[fieldName] = linkedID;
				if (linkedID === null) this._maybeAddFieldErrors(record, storageKey);
				else if (linkedID === void 0) this._markDataAsMissing(fieldName);
				return linkedID;
			}
			var prevData = data[fieldName];
			!(prevData == null || typeof prevData === "object") && invariant(false);
			var prevErrors = this._fieldErrors;
			this._fieldErrors = null;
			var value = this._traverse(field, linkedID, prevData);
			this._prependPreviousErrors(prevErrors, fieldName);
			data[fieldName] = value;
			return value;
		};
		_proto._prependPreviousErrors = function _prependPreviousErrors(prevErrors, fieldNameOrIndex) {
			if (this._fieldErrors != null) {
				for (var i = 0; i < this._fieldErrors.length; i++) {
					var event = this._fieldErrors[i];
					if (event.owner === this._fragmentName && (event.kind === "missing_expected_data.throw" || event.kind === "missing_expected_data.log" || event.kind === "missing_required_field.throw" || event.kind === "missing_required_field.log")) event.fieldPath = "".concat(fieldNameOrIndex, ".").concat(event.fieldPath);
				}
				if (prevErrors != null) {
					for (var _i3 = this._fieldErrors.length - 1; _i3 >= 0; _i3--) prevErrors.push(this._fieldErrors[_i3]);
					this._fieldErrors = prevErrors;
				}
			} else this._fieldErrors = prevErrors;
		};
		_proto._readActorChange = function _readActorChange(field, record, data) {
			var _field$alias5;
			var fieldName = (_field$alias5 = field.alias) !== null && _field$alias5 !== void 0 ? _field$alias5 : field.name;
			var storageKey = getStorageKey(field, this._variables);
			var externalRef = RelayModernRecord.getActorLinkedRecordID(record, storageKey);
			if (externalRef == null) {
				data[fieldName] = externalRef;
				if (externalRef === void 0) this._markDataAsMissing(fieldName);
				else if (externalRef === null) this._maybeAddFieldErrors(record, storageKey);
				return data[fieldName];
			}
			var actorIdentifier = externalRef[0], dataID = externalRef[1];
			var fragmentRef = {};
			this._createFragmentPointer(field.fragmentSpread, RelayModernRecord.fromObject({ __id: dataID }), fragmentRef);
			data[fieldName] = {
				__fragmentRef: fragmentRef,
				__viewer: actorIdentifier
			};
			return data[fieldName];
		};
		_proto._readPluralLink = function _readPluralLink(field, record, data) {
			var storageKey = getStorageKey(field, this._variables);
			var linkedIDs = RelayModernRecord.getLinkedRecordIDs(record, storageKey);
			if (linkedIDs === null || RelayFeatureFlags.ENABLE_NONCOMPLIANT_ERROR_HANDLING_ON_LISTS && Array.isArray(linkedIDs) && linkedIDs.length === 0) this._maybeAddFieldErrors(record, storageKey);
			return this._readLinkedIds(field, linkedIDs, record, data);
		};
		_proto._readLinkedIds = function _readLinkedIds(field, linkedIDs, record, data) {
			var _this4 = this;
			var _field$alias6;
			var fieldName = (_field$alias6 = field.alias) !== null && _field$alias6 !== void 0 ? _field$alias6 : field.name;
			if (linkedIDs == null) {
				data[fieldName] = linkedIDs;
				if (linkedIDs === void 0) this._markDataAsMissing(fieldName);
				return linkedIDs;
			}
			var prevData = data[fieldName];
			!(prevData == null || Array.isArray(prevData)) && invariant(false);
			var prevErrors = this._fieldErrors;
			this._fieldErrors = null;
			var linkedArray = prevData || [];
			linkedIDs.forEach(function(linkedID, nextIndex) {
				if (linkedID == null) {
					if (linkedID === void 0) _this4._markDataAsMissing(String(nextIndex));
					linkedArray[nextIndex] = linkedID;
					return;
				}
				var prevItem = linkedArray[nextIndex];
				!(prevItem == null || typeof prevItem === "object") && invariant(false);
				var prevErrors = _this4._fieldErrors;
				_this4._fieldErrors = null;
				linkedArray[nextIndex] = _this4._traverse(field, linkedID, prevItem);
				_this4._prependPreviousErrors(prevErrors, nextIndex);
			});
			this._prependPreviousErrors(prevErrors, fieldName);
			data[fieldName] = linkedArray;
			return linkedArray;
		};
		_proto._readModuleImport = function _readModuleImport(moduleImport, record, data) {
			var componentKey = getModuleComponentKey(moduleImport.documentName);
			var relayStoreComponent = RelayModernRecord.getValue(record, componentKey);
			var component = relayStoreComponent !== void 0 ? relayStoreComponent : moduleImport.componentModuleProvider;
			if (component == null) {
				if (component === void 0) this._markDataAsMissing("<module-import>");
				return;
			}
			this._createFragmentPointer({
				kind: "FragmentSpread",
				name: moduleImport.fragmentName,
				args: moduleImport.args
			}, record, data);
			data[FRAGMENT_PROP_NAME_KEY] = moduleImport.fragmentPropName;
			data[MODULE_COMPONENT_KEY] = component;
		};
		_proto._readAliasedInlineFragment = function _readAliasedInlineFragment(aliasedInlineFragment, record, data) {
			var prevErrors = this._fieldErrors;
			this._fieldErrors = null;
			var fieldValue = this._readInlineFragment(aliasedInlineFragment.fragment, record, {}, true);
			this._prependPreviousErrors(prevErrors, aliasedInlineFragment.name);
			if (fieldValue === false) fieldValue = null;
			data[aliasedInlineFragment.name] = fieldValue;
		};
		_proto._readInlineFragment = function _readInlineFragment(inlineFragment, record, data, skipUnmatchedAbstractTypes) {
			if (inlineFragment.type == null) {
				var hasExpectedData = this._traverseSelections(inlineFragment.selections, record, data);
				if (hasExpectedData === false) return false;
				return data;
			}
			var abstractKey = inlineFragment.abstractKey;
			if (abstractKey == null) if (!this._recordMatchesTypeCondition(record, inlineFragment.type)) return null;
			else {
				var hasExpectedData = this._traverseSelections(inlineFragment.selections, record, data);
				if (!hasExpectedData) return false;
			}
			else {
				var implementsInterface = this._implementsInterface(record, abstractKey);
				if (implementsInterface === false && skipUnmatchedAbstractTypes) return null;
				var parentIsMissingData = this._isMissingData;
				var parentIsWithinUnmatchedTypeRefinement = this._isWithinUnmatchedTypeRefinement;
				this._isWithinUnmatchedTypeRefinement = parentIsWithinUnmatchedTypeRefinement || implementsInterface === false;
				var hasMissingData = this._traverseSelections(inlineFragment.selections, record, data);
				this._isWithinUnmatchedTypeRefinement = parentIsWithinUnmatchedTypeRefinement;
				if (implementsInterface === false) {
					this._isMissingData = parentIsMissingData;
					return null;
				} else if (implementsInterface == null) return;
				else if (hasMissingData === false) return false;
			}
			return data;
		};
		_proto._recordMatchesTypeCondition = function _recordMatchesTypeCondition(record, type) {
			var typeName = RelayModernRecord.getType(record);
			return typeName != null && typeName === type || RelayModernRecord.getDataID(record) === ROOT_ID;
		};
		_proto._createFragmentPointer = function _createFragmentPointer(fragmentSpread, record, data) {
			var fragmentPointers = data[FRAGMENTS_KEY];
			if (fragmentPointers == null) fragmentPointers = data[FRAGMENTS_KEY] = {};
			!(typeof fragmentPointers === "object" && fragmentPointers != null) && invariant(false);
			if (data[ID_KEY] == null) data[ID_KEY] = RelayModernRecord.getDataID(record);
			fragmentPointers[fragmentSpread.name] = getArgumentValues(fragmentSpread.args, this._variables, this._isWithinUnmatchedTypeRefinement);
			data[FRAGMENT_OWNER_KEY] = this._owner;
			if (this._clientEdgeTraversalPath.length > 0 && this._clientEdgeTraversalPath[this._clientEdgeTraversalPath.length - 1] !== null) data[CLIENT_EDGE_TRAVERSAL_PATH] = (0, _toConsumableArray2["default"])(this._clientEdgeTraversalPath);
		};
		_proto._createInlineDataOrResolverFragmentPointer = function _createInlineDataOrResolverFragmentPointer(fragmentSpreadOrFragment, record, data) {
			var fragmentPointers = data[FRAGMENTS_KEY];
			if (fragmentPointers == null) fragmentPointers = data[FRAGMENTS_KEY] = {};
			!(typeof fragmentPointers === "object" && fragmentPointers != null) && invariant(false);
			if (data[ID_KEY] == null) data[ID_KEY] = RelayModernRecord.getDataID(record);
			var inlineData = {};
			var parentFragmentName = this._fragmentName;
			this._fragmentName = fragmentSpreadOrFragment.name;
			var parentVariables = this._variables;
			var argumentVariables = fragmentSpreadOrFragment.args ? getArgumentValues(fragmentSpreadOrFragment.args, this._variables) : {};
			this._variables = RelayConcreteVariables.getFragmentVariables(fragmentSpreadOrFragment, this._owner.variables, argumentVariables);
			this._traverseSelections(fragmentSpreadOrFragment.selections, record, inlineData);
			this._variables = parentVariables;
			this._fragmentName = parentFragmentName;
			fragmentPointers[fragmentSpreadOrFragment.name] = inlineData;
		};
		_proto._implementsInterface = function _implementsInterface(record, abstractKey) {
			var typeName = RelayModernRecord.getType(record);
			var typeRecord = this._recordSource.get(generateTypeID(typeName));
			var implementsInterface = typeRecord != null ? RelayModernRecord.getValue(typeRecord, abstractKey) : null;
			if (implementsInterface == null) this._markDataAsMissing("<abstract-type-hint>");
			return implementsInterface;
		};
		return RelayReader;
	}();
	function markFieldErrorHasHandled(event) {
		switch (event.kind) {
			case "missing_expected_data.throw":
			case "missing_required_field.throw":
			case "relay_field_payload.error":
			case "relay_resolver.error": return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, event), {}, { handled: true });
			case "missing_expected_data.log":
			case "missing_required_field.log": return event;
			default:
				event.kind;
				invariant(false);
		}
	}
	function getResolverValue(field, variables, fragmentKey, resolverContext) {
		var resolverFunction = typeof field.resolverModule === "function" ? field.resolverModule : field.resolverModule["default"];
		var resolverResult = null;
		var resolverError = null;
		try {
			var resolverFunctionArgs = [];
			if (field.fragment != null) resolverFunctionArgs.push(fragmentKey);
			var args = field.args ? getArgumentValues(field.args, variables) : void 0;
			resolverFunctionArgs.push(args);
			resolverFunctionArgs.push(resolverContext);
			resolverResult = resolverFunction.apply(null, resolverFunctionArgs);
		} catch (e) {
			resolverResult = null;
			if (e !== RESOLVER_FRAGMENT_ERRORED_SENTINEL) resolverError = e;
		}
		return [resolverResult, resolverError];
	}
	function extractIdFromResponse(individualResponse, path, owner) {
		if (typeof individualResponse === "string") return individualResponse;
		else if (typeof individualResponse === "object" && individualResponse != null && typeof individualResponse.id === "string") return individualResponse.id;
		invariant(false);
	}
	module.exports = { read };
}));
var require_RelayReferenceMarker = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var getOperation = require_getOperation();
	var cloneRelayHandleSourceField = require_cloneRelayHandleSourceField();
	var getOutputTypeRecordIDs = require_getOutputTypeRecordIDs();
	var getLocalVariables = require_RelayConcreteVariables().getLocalVariables;
	var RelayModernRecord = require_RelayModernRecord();
	var RelayStoreUtils = require_RelayStoreUtils();
	var generateTypeID = require_TypeID().generateTypeID;
	var invariant = require_invariant();
	var getReadTimeResolverStorageKey = RelayStoreUtils.getReadTimeResolverStorageKey, getStorageKey = RelayStoreUtils.getStorageKey, getModuleOperationKey = RelayStoreUtils.getModuleOperationKey;
	function mark(recordSource, selector, references, operationLoader, shouldProcessClientComponents, useExecTimeResolvers) {
		var dataID = selector.dataID, node = selector.node, variables = selector.variables;
		new RelayReferenceMarker(recordSource, variables, references, operationLoader, shouldProcessClientComponents, useExecTimeResolvers).mark(node, dataID);
	}
	var RelayReferenceMarker = /* @__PURE__ */ function() {
		function RelayReferenceMarker(recordSource, variables, references, operationLoader, shouldProcessClientComponents, useExecTimeResolvers) {
			this._operationLoader = operationLoader !== null && operationLoader !== void 0 ? operationLoader : null;
			this._operationName = null;
			this._useExecTimeResolvers = useExecTimeResolvers !== null && useExecTimeResolvers !== void 0 ? useExecTimeResolvers : false;
			this._recordSource = recordSource;
			this._references = references;
			this._variables = variables;
			this._shouldProcessClientComponents = shouldProcessClientComponents;
		}
		var _proto = RelayReferenceMarker.prototype;
		_proto.mark = function mark(node, dataID) {
			if (node.kind === "Operation" || node.kind === "SplitOperation") this._operationName = node.name;
			this._traverse(node, dataID);
		};
		_proto._traverse = function _traverse(node, dataID) {
			this._references.add(dataID);
			var record = this._recordSource.get(dataID);
			if (record == null) return;
			this._traverseSelections(node.selections, record);
		};
		_proto._getVariableValue = function _getVariableValue(name) {
			!this._variables.hasOwnProperty(name) && invariant(false);
			return this._variables[name];
		};
		_proto._traverseSelections = function _traverseSelections(selections, record) {
			var _this = this;
			selections.forEach(function(selection) {
				switch (selection.kind) {
					case "ActorChange":
						_this._traverseLink(selection.linkedField, record);
						break;
					case "LinkedField":
						if (selection.plural) _this._traversePluralLink(selection, record);
						else _this._traverseLink(selection, record);
						break;
					case "Condition":
						if (Boolean(_this._getVariableValue(selection.condition)) === selection.passingValue) _this._traverseSelections(selection.selections, record);
						break;
					case "InlineFragment":
						if (selection.abstractKey == null) {
							var typeName = RelayModernRecord.getType(record);
							if (typeName != null && typeName === selection.type || typeName === RelayStoreUtils.ROOT_TYPE) _this._traverseSelections(selection.selections, record);
						} else {
							var typeID = generateTypeID(RelayModernRecord.getType(record));
							_this._references.add(typeID);
							_this._traverseSelections(selection.selections, record);
						}
						break;
					case "FragmentSpread":
						var prevVariables = _this._variables;
						_this._variables = getLocalVariables(_this._variables, selection.fragment.argumentDefinitions, selection.args);
						_this._traverseSelections(selection.fragment.selections, record);
						_this._variables = prevVariables;
						break;
					case "LinkedHandle":
						var handleField = cloneRelayHandleSourceField(selection, selections, _this._variables);
						if (handleField.plural) _this._traversePluralLink(handleField, record);
						else _this._traverseLink(handleField, record);
						break;
					case "Defer":
					case "Stream":
						_this._traverseSelections(selection.selections, record);
						break;
					case "ScalarField":
					case "ScalarHandle": break;
					case "TypeDiscriminator":
						var _typeID = generateTypeID(RelayModernRecord.getType(record));
						_this._references.add(_typeID);
						break;
					case "ModuleImport":
						_this._traverseModuleImport(selection, record);
						break;
					case "ClientExtension":
						_this._traverseSelections(selection.selections, record);
						break;
					case "ClientComponent":
						if (_this._shouldProcessClientComponents === false) break;
						_this._traverseSelections(selection.fragment.selections, record);
						break;
					case "RelayResolver":
					case "RelayLiveResolver":
						_this._traverseResolverField(selection, record);
						break;
					case "ClientEdgeToClientObject":
						_this._traverseClientEdgeToClientObject(selection, record);
						break;
					default: invariant(false);
				}
			});
		};
		_proto._traverseClientEdgeToClientObject = function _traverseClientEdgeToClientObject(field, record) {
			if (this._useExecTimeResolvers) {
				this._traverseLink(field.linkedField, record);
				return;
			}
			var dataID = this._traverseResolverField(field.backingField, record);
			if (dataID == null) return;
			var resolverRecord = this._recordSource.get(dataID);
			if (resolverRecord == null) return;
			if (field.backingField.isOutputType) {
				var outputTypeRecordIDs = getOutputTypeRecordIDs(resolverRecord);
				if (outputTypeRecordIDs != null) {
					var _iterator = (0, _createForOfIteratorHelper2["default"])(outputTypeRecordIDs), _step;
					try {
						for (_iterator.s(); !(_step = _iterator.n()).done;) {
							var _dataID = _step.value;
							this._references.add(_dataID);
						}
					} catch (err) {
						_iterator.e(err);
					} finally {
						_iterator.f();
					}
				}
			} else {
				var linkedField = field.linkedField;
				var concreteType = linkedField.concreteType;
				if (concreteType == null) return;
				if (linkedField.plural) {
					var dataIDs = RelayModernRecord.getResolverLinkedRecordIDs(resolverRecord, concreteType);
					if (dataIDs != null) {
						var _iterator2 = (0, _createForOfIteratorHelper2["default"])(dataIDs), _step2;
						try {
							for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
								var _dataID2 = _step2.value;
								if (_dataID2 != null) this._traverse(linkedField, _dataID2);
							}
						} catch (err) {
							_iterator2.e(err);
						} finally {
							_iterator2.f();
						}
					}
				} else {
					var _dataID3 = RelayModernRecord.getResolverLinkedRecordID(resolverRecord, concreteType);
					if (_dataID3 != null) this._traverse(linkedField, _dataID3);
				}
			}
		};
		_proto._traverseResolverField = function _traverseResolverField(field, record) {
			if (this._useExecTimeResolvers) return;
			var storageKey = getReadTimeResolverStorageKey(field, this._variables);
			var dataID = RelayModernRecord.getLinkedRecordID(record, storageKey);
			if (dataID != null) this._references.add(dataID);
			var fragment = field.fragment;
			if (fragment != null) this._traverseSelections([fragment], record);
			return dataID;
		};
		_proto._traverseModuleImport = function _traverseModuleImport(moduleImport, record) {
			var operationLoader = this._operationLoader;
			!(operationLoader !== null) && invariant(false);
			var operationKey = getModuleOperationKey(moduleImport.documentName);
			var operationReference = RelayModernRecord.getValue(record, operationKey);
			if (operationReference == null) return;
			var normalizationRootNode = operationLoader.get(operationReference);
			if (normalizationRootNode != null) {
				var operation = getOperation(normalizationRootNode);
				var prevVariables = this._variables;
				this._variables = getLocalVariables(this._variables, operation.argumentDefinitions, moduleImport.args);
				this._traverseSelections(operation.selections, record);
				this._variables = prevVariables;
			}
		};
		_proto._traverseLink = function _traverseLink(field, record) {
			var storageKey = getStorageKey(field, this._variables);
			var linkedID = RelayModernRecord.getLinkedRecordID(record, storageKey);
			if (linkedID == null) return;
			this._traverse(field, linkedID);
		};
		_proto._traversePluralLink = function _traversePluralLink(field, record) {
			var _this2 = this;
			var storageKey = getStorageKey(field, this._variables);
			var linkedIDs = RelayModernRecord.getLinkedRecordIDs(record, storageKey);
			if (linkedIDs == null) return;
			linkedIDs.forEach(function(linkedID) {
				if (linkedID != null) _this2._traverse(field, linkedID);
			});
		};
		return RelayReferenceMarker;
	}();
	module.exports = { mark };
}));
var require_hasOverlappingIDs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ITERATOR_KEY = Symbol.iterator;
	function hasOverlappingIDs(seenRecords, updatedRecordIDs) {
		var iterator = seenRecords[ITERATOR_KEY]();
		var next = iterator.next();
		while (!next.done) {
			var key = next.value;
			if (updatedRecordIDs.has(key)) return true;
			next = iterator.next();
		}
		return false;
	}
	module.exports = hasOverlappingIDs;
}));
var require_hasSignificantOverlappingIDs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ROOT_ID = require_RelayStoreUtils().ROOT_ID;
	var VIEWER_ID = require_ViewerPattern().VIEWER_ID;
	var ITERATOR_KEY = Symbol.iterator;
	function hasSignificantOverlappingIDs(seenRecords, updatedRecordIDs) {
		var iterator = seenRecords[ITERATOR_KEY]();
		var next = iterator.next();
		while (!next.done) {
			var key = next.value;
			if (updatedRecordIDs.has(key) && key !== ROOT_ID && key !== VIEWER_ID) return true;
			next = iterator.next();
		}
		return false;
	}
	module.exports = hasSignificantOverlappingIDs;
}));
var require_RelayStoreSubscriptions = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	require_deepFreeze();
	var recycleNodesInto = require_recycleNodesInto();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var hasOverlappingIDs = require_hasOverlappingIDs();
	var hasSignificantOverlappingIDs = require_hasSignificantOverlappingIDs();
	var RelayReader = require_RelayReader();
	module.exports = /* @__PURE__ */ function() {
		function RelayStoreSubscriptions(log, resolverCache, resolverContext) {
			this._subscriptions = /* @__PURE__ */ new Set();
			this.__log = log;
			this._resolverCache = resolverCache;
			this._resolverContext = resolverContext;
		}
		var _proto = RelayStoreSubscriptions.prototype;
		_proto.subscribe = function subscribe(snapshot, callback) {
			var _this = this;
			var subscription = {
				backup: null,
				callback,
				snapshot,
				stale: false
			};
			var dispose = function dispose() {
				_this._subscriptions["delete"](subscription);
			};
			this._subscriptions.add(subscription);
			return { dispose };
		};
		_proto.snapshotSubscriptions = function snapshotSubscriptions(source) {
			var _this2 = this;
			this._subscriptions.forEach(function(subscription) {
				if (!subscription.stale) {
					subscription.backup = subscription.snapshot;
					return;
				}
				var snapshot = subscription.snapshot;
				var backup = RelayReader.read(source, snapshot.selector, _this2._resolverCache, _this2._resolverContext);
				backup.data = recycleNodesInto(snapshot.data, backup.data);
				subscription.backup = backup;
			});
		};
		_proto.restoreSubscriptions = function restoreSubscriptions() {
			this._subscriptions.forEach(function(subscription) {
				var backup = subscription.backup;
				subscription.backup = null;
				if (backup) {
					if (backup.data !== subscription.snapshot.data) subscription.stale = true;
					subscription.snapshot = {
						data: subscription.snapshot.data,
						isMissingData: backup.isMissingData,
						missingClientEdges: backup.missingClientEdges,
						missingLiveResolverFields: backup.missingLiveResolverFields,
						seenRecords: backup.seenRecords,
						selector: backup.selector,
						fieldErrors: backup.fieldErrors
					};
				} else subscription.stale = true;
			});
		};
		_proto.updateSubscriptions = function updateSubscriptions(source, updatedRecordIDs, updatedOwners, sourceOperation) {
			var _this3 = this;
			var hasUpdatedRecords = updatedRecordIDs.size !== 0;
			this._subscriptions.forEach(function(subscription) {
				var owner = _this3._updateSubscription(source, subscription, updatedRecordIDs, hasUpdatedRecords, sourceOperation);
				if (owner != null) updatedOwners.push(owner);
			});
		};
		_proto._updateSubscription = function _updateSubscription(source, subscription, updatedRecordIDs, hasUpdatedRecords, sourceOperation) {
			var backup = subscription.backup, callback = subscription.callback, snapshot = subscription.snapshot, stale = subscription.stale;
			var hasOverlappingUpdates = hasUpdatedRecords && hasOverlappingIDs(snapshot.seenRecords, updatedRecordIDs);
			if (!stale && !hasOverlappingUpdates) return;
			var nextSnapshot = hasOverlappingUpdates || !backup ? RelayReader.read(source, snapshot.selector, this._resolverCache, this._resolverContext) : backup;
			nextSnapshot = {
				data: recycleNodesInto(snapshot.data, nextSnapshot.data),
				isMissingData: nextSnapshot.isMissingData,
				missingClientEdges: nextSnapshot.missingClientEdges,
				missingLiveResolverFields: nextSnapshot.missingLiveResolverFields,
				seenRecords: nextSnapshot.seenRecords,
				selector: nextSnapshot.selector,
				fieldErrors: nextSnapshot.fieldErrors
			};
			subscription.snapshot = nextSnapshot;
			subscription.stale = false;
			if (nextSnapshot.data !== snapshot.data) {
				if (this.__log && RelayFeatureFlags.ENABLE_NOTIFY_SUBSCRIPTION) this.__log({
					name: "store.notify.subscription",
					sourceOperation,
					snapshot,
					nextSnapshot
				});
				callback(nextSnapshot);
				return snapshot.selector.owner;
			}
			if (RelayFeatureFlags.ENABLE_LOOSE_SUBSCRIPTION_ATTRIBUTION && (stale || hasSignificantOverlappingIDs(snapshot.seenRecords, updatedRecordIDs))) return snapshot.selector.owner;
		};
		_proto.size = function size() {
			return this._subscriptions.size;
		};
		return RelayStoreSubscriptions;
	}();
}));
var require_RelayModernStore = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _require = require_ActorIdentifier(), INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE = _require.INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE, assertInternalActorIdentifier = _require.assertInternalActorIdentifier;
	require_deepFreeze();
	var resolveImmediate = require_resolveImmediate();
	var DataChecker = require_DataChecker();
	var defaultGetDataID = require_defaultGetDataID();
	var _require2 = require_LiveResolverCache(), LiveResolverCache = _require2.LiveResolverCache, RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY = _require2.RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY, getUpdatedDataIDs = _require2.getUpdatedDataIDs;
	var RelayModernRecord = require_RelayModernRecord();
	var RelayOptimisticRecordSource = require_RelayOptimisticRecordSource();
	var RelayReader = require_RelayReader();
	var RelayReferenceMarker = require_RelayReferenceMarker();
	var RelayStoreSubscriptions = require_RelayStoreSubscriptions();
	var RelayStoreUtils = require_RelayStoreUtils();
	var _require3 = require_RelayStoreUtils(), ROOT_ID = _require3.ROOT_ID, ROOT_TYPE = _require3.ROOT_TYPE;
	var invariant = require_invariant();
	var DEFAULT_RELEASE_BUFFER_SIZE = 10;
	var RelayModernStore = /* @__PURE__ */ function() {
		function RelayModernStore(source, options) {
			var _this = this;
			var _options$gcReleaseBuf, _options$shouldRetain, _options$gcScheduler, _options$getDataID, _options$log, _options$operationLoa, _options$shouldProces, _options$treatMissing;
			(0, _defineProperty2["default"])(this, "_gcStep", function() {
				if (_this._gcRun) if (_this._gcRun.next().done) _this._gcRun = null;
				else _this._gcScheduler(_this._gcStep);
			});
			this._currentWriteEpoch = 0;
			this._gcHoldCounter = 0;
			this._gcReleaseBufferSize = (_options$gcReleaseBuf = options === null || options === void 0 ? void 0 : options.gcReleaseBufferSize) !== null && _options$gcReleaseBuf !== void 0 ? _options$gcReleaseBuf : DEFAULT_RELEASE_BUFFER_SIZE;
			this._shouldRetainWithinTTL_EXPERIMENTAL = (_options$shouldRetain = options === null || options === void 0 ? void 0 : options.shouldRetainWithinTTL_EXPERIMENTAL) !== null && _options$shouldRetain !== void 0 ? _options$shouldRetain : false;
			this._gcRun = null;
			this._gcScheduler = (_options$gcScheduler = options === null || options === void 0 ? void 0 : options.gcScheduler) !== null && _options$gcScheduler !== void 0 ? _options$gcScheduler : resolveImmediate;
			this._getDataID = (_options$getDataID = options === null || options === void 0 ? void 0 : options.getDataID) !== null && _options$getDataID !== void 0 ? _options$getDataID : defaultGetDataID;
			this._globalInvalidationEpoch = null;
			this._invalidationSubscriptions = /* @__PURE__ */ new Set();
			this._invalidatedRecordIDs = /* @__PURE__ */ new Set();
			this.__log = (_options$log = options === null || options === void 0 ? void 0 : options.log) !== null && _options$log !== void 0 ? _options$log : null;
			this._queryCacheExpirationTime = options === null || options === void 0 ? void 0 : options.queryCacheExpirationTime;
			this._operationLoader = (_options$operationLoa = options === null || options === void 0 ? void 0 : options.operationLoader) !== null && _options$operationLoa !== void 0 ? _options$operationLoa : null;
			this._optimisticSource = null;
			this._recordSource = source;
			this._releaseBuffer = [];
			this._roots = /* @__PURE__ */ new Map();
			this._shouldScheduleGC = false;
			this._resolverCache = new LiveResolverCache(function() {
				return _this._getMutableRecordSource();
			}, this);
			this._resolverContext = options === null || options === void 0 ? void 0 : options.resolverContext;
			this._storeSubscriptions = new RelayStoreSubscriptions(options === null || options === void 0 ? void 0 : options.log, this._resolverCache, this._resolverContext);
			this._updatedRecordIDs = /* @__PURE__ */ new Set();
			this._shouldProcessClientComponents = (_options$shouldProces = options === null || options === void 0 ? void 0 : options.shouldProcessClientComponents) !== null && _options$shouldProces !== void 0 ? _options$shouldProces : false;
			this._treatMissingFieldsAsNull = (_options$treatMissing = options === null || options === void 0 ? void 0 : options.treatMissingFieldsAsNull) !== null && _options$treatMissing !== void 0 ? _options$treatMissing : false;
			this._actorIdentifier = options === null || options === void 0 ? void 0 : options.actorIdentifier;
			initializeRecordSource(this._recordSource);
		}
		var _proto = RelayModernStore.prototype;
		_proto.getSource = function getSource() {
			var _this$_optimisticSour;
			return (_this$_optimisticSour = this._optimisticSource) !== null && _this$_optimisticSour !== void 0 ? _this$_optimisticSour : this._recordSource;
		};
		_proto.getOperationLoader = function getOperationLoader() {
			return this._operationLoader;
		};
		_proto._getMutableRecordSource = function _getMutableRecordSource() {
			var _this$_optimisticSour2;
			return (_this$_optimisticSour2 = this._optimisticSource) !== null && _this$_optimisticSour2 !== void 0 ? _this$_optimisticSour2 : this._recordSource;
		};
		_proto.getLiveResolverPromise = function getLiveResolverPromise(recordID) {
			return this._resolverCache.getLiveResolverPromise(recordID);
		};
		_proto.batchLiveStateUpdates = function batchLiveStateUpdates(callback) {
			if (this.__log != null) this.__log({ name: "liveresolver.batch.start" });
			try {
				this._resolverCache.batchLiveStateUpdates(callback);
			} finally {
				if (this.__log != null) this.__log({ name: "liveresolver.batch.end" });
			}
		};
		_proto.check = function check(operation, options) {
			var _ref, _operation$request$no, _operation$request$no2, _options$handlers, _options$getSourceFor, _options$getTargetFor, _options$defaultActor;
			var selector = operation.root;
			var source = this._getMutableRecordSource();
			var globalInvalidationEpoch = this._globalInvalidationEpoch;
			var useExecTimeResolvers = (_ref = (_operation$request$no = operation.request.node.operation.use_exec_time_resolvers) !== null && _operation$request$no !== void 0 ? _operation$request$no : ((_operation$request$no2 = operation.request.node.operation.exec_time_resolvers_enabled_provider) === null || _operation$request$no2 === void 0 ? void 0 : _operation$request$no2.get()) === true) !== null && _ref !== void 0 ? _ref : false;
			var rootEntry = this._roots.get(operation.request.identifier);
			var operationLastWrittenAt = rootEntry != null ? rootEntry.epoch : null;
			if (globalInvalidationEpoch != null) {
				if (operationLastWrittenAt == null || operationLastWrittenAt <= globalInvalidationEpoch) return { status: "stale" };
			}
			var handlers = (_options$handlers = options === null || options === void 0 ? void 0 : options.handlers) !== null && _options$handlers !== void 0 ? _options$handlers : [];
			var getSourceForActor = (_options$getSourceFor = options === null || options === void 0 ? void 0 : options.getSourceForActor) !== null && _options$getSourceFor !== void 0 ? _options$getSourceFor : function(actorIdentifier) {
				assertInternalActorIdentifier(actorIdentifier);
				return source;
			};
			var getTargetForActor = (_options$getTargetFor = options === null || options === void 0 ? void 0 : options.getTargetForActor) !== null && _options$getTargetFor !== void 0 ? _options$getTargetFor : function(actorIdentifier) {
				assertInternalActorIdentifier(actorIdentifier);
				return source;
			};
			return getAvailabilityStatus(DataChecker.check(getSourceForActor, getTargetForActor, (_options$defaultActor = options === null || options === void 0 ? void 0 : options.defaultActorIdentifier) !== null && _options$defaultActor !== void 0 ? _options$defaultActor : INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE, selector, handlers, this._operationLoader, this._getDataID, this._shouldProcessClientComponents, this.__log, useExecTimeResolvers), operationLastWrittenAt, rootEntry === null || rootEntry === void 0 ? void 0 : rootEntry.fetchTime, this._queryCacheExpirationTime);
		};
		_proto.retain = function retain(operation) {
			var _this2 = this;
			var id = operation.request.identifier;
			var disposed = false;
			var dispose = function dispose() {
				if (disposed) return;
				disposed = true;
				var rootEntry = _this2._roots.get(id);
				if (rootEntry == null) return;
				rootEntry.refCount--;
				if (rootEntry.refCount === 0) {
					var _queryCacheExpirationTime = _this2._queryCacheExpirationTime;
					if (rootEntry.fetchTime != null && _queryCacheExpirationTime != null && rootEntry.fetchTime <= Date.now() - _queryCacheExpirationTime) {
						if (!_this2._shouldRetainWithinTTL_EXPERIMENTAL) _this2._roots["delete"](id);
						_this2.scheduleGC();
					} else {
						_this2._releaseBuffer.push(id);
						if (_this2._releaseBuffer.length > _this2._gcReleaseBufferSize) {
							var _id = _this2._releaseBuffer.shift();
							if (!_this2._shouldRetainWithinTTL_EXPERIMENTAL) _this2._roots["delete"](_id);
							_this2.scheduleGC();
						}
					}
				}
			};
			var rootEntry = this._roots.get(id);
			if (rootEntry != null) {
				if (rootEntry.refCount === 0) this._releaseBuffer = this._releaseBuffer.filter(function(_id) {
					return _id !== id;
				});
				rootEntry.refCount += 1;
			} else this._roots.set(id, {
				operation,
				refCount: 1,
				epoch: null,
				fetchTime: null
			});
			return { dispose };
		};
		_proto.lookup = function lookup(selector) {
			var log = this.__log;
			if (log != null) log({
				name: "store.lookup.start",
				selector
			});
			var source = this.getSource();
			var snapshot = RelayReader.read(source, selector, this._resolverCache, this._resolverContext);
			if (log != null) log({
				name: "store.lookup.end",
				selector
			});
			return snapshot;
		};
		_proto.notify = function notify(sourceOperation, invalidateStore) {
			var _this3 = this;
			var log = this.__log;
			if (log != null) log({
				name: "store.notify.start",
				sourceOperation
			});
			this._currentWriteEpoch++;
			if (invalidateStore === true) this._globalInvalidationEpoch = this._currentWriteEpoch;
			this._resolverCache.invalidateDataIDs(this._updatedRecordIDs);
			var source = this.getSource();
			var updatedOwners = [];
			this._storeSubscriptions.updateSubscriptions(source, this._updatedRecordIDs, updatedOwners, sourceOperation);
			this._invalidationSubscriptions.forEach(function(subscription) {
				_this3._updateInvalidationSubscription(subscription, invalidateStore === true);
			});
			if (sourceOperation != null) {
				var id = sourceOperation.request.identifier;
				var rootEntry = this._roots.get(id);
				if (rootEntry != null) {
					rootEntry.epoch = this._currentWriteEpoch;
					rootEntry.fetchTime = Date.now();
				} else if (sourceOperation.request.node.params.operationKind === "query" && this._gcReleaseBufferSize > 0 && this._releaseBuffer.length < this._gcReleaseBufferSize) {
					var temporaryRootEntry = {
						operation: sourceOperation,
						refCount: 0,
						epoch: this._currentWriteEpoch,
						fetchTime: Date.now()
					};
					this._releaseBuffer.push(id);
					this._roots.set(id, temporaryRootEntry);
				}
			}
			if (log != null) log({
				name: "store.notify.complete",
				sourceOperation,
				updatedRecordIDs: this._updatedRecordIDs,
				invalidatedRecordIDs: this._invalidatedRecordIDs,
				subscriptionsSize: this._storeSubscriptions.size(),
				updatedOwners
			});
			this._updatedRecordIDs.clear();
			this._invalidatedRecordIDs.clear();
			return updatedOwners;
		};
		_proto.publish = function publish(source, idsMarkedForInvalidation) {
			var target = this._getMutableRecordSource();
			updateTargetFromSource(target, source, this._currentWriteEpoch + 1, idsMarkedForInvalidation, this._updatedRecordIDs, this._invalidatedRecordIDs);
			var log = this.__log;
			if (log != null) log({
				name: "store.publish",
				source,
				optimistic: target === this._optimisticSource
			});
		};
		_proto.subscribe = function subscribe(snapshot, callback) {
			return this._storeSubscriptions.subscribe(snapshot, callback);
		};
		_proto.holdGC = function holdGC() {
			var _this4 = this;
			if (this._gcRun) {
				this._gcRun = null;
				this._shouldScheduleGC = true;
			}
			this._gcHoldCounter++;
			return { dispose: function dispose() {
				if (_this4._gcHoldCounter > 0) {
					_this4._gcHoldCounter--;
					if (_this4._gcHoldCounter === 0 && _this4._shouldScheduleGC) {
						_this4.scheduleGC();
						_this4._shouldScheduleGC = false;
					}
				}
			} };
		};
		_proto.toJSON = function toJSON() {
			return "RelayModernStore()";
		};
		_proto.getEpoch = function getEpoch() {
			return this._currentWriteEpoch;
		};
		_proto.__getUpdatedRecordIDs = function __getUpdatedRecordIDs() {
			return this._updatedRecordIDs;
		};
		_proto.lookupInvalidationState = function lookupInvalidationState(dataIDs) {
			var _this5 = this;
			var invalidations = /* @__PURE__ */ new Map();
			dataIDs.forEach(function(dataID) {
				var _RelayModernRecord$ge;
				var record = _this5.getSource().get(dataID);
				invalidations.set(dataID, (_RelayModernRecord$ge = RelayModernRecord.getInvalidationEpoch(record)) !== null && _RelayModernRecord$ge !== void 0 ? _RelayModernRecord$ge : null);
			});
			invalidations.set("global", this._globalInvalidationEpoch);
			return {
				dataIDs,
				invalidations
			};
		};
		_proto.checkInvalidationState = function checkInvalidationState(prevInvalidationState) {
			var currentInvalidations = this.lookupInvalidationState(prevInvalidationState.dataIDs).invalidations;
			var prevInvalidations = prevInvalidationState.invalidations;
			if (currentInvalidations.get("global") !== prevInvalidations.get("global")) return true;
			var _iterator = (0, _createForOfIteratorHelper2["default"])(prevInvalidationState.dataIDs), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var dataID = _step.value;
					if (currentInvalidations.get(dataID) !== prevInvalidations.get(dataID)) return true;
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			return false;
		};
		_proto.subscribeToInvalidationState = function subscribeToInvalidationState(invalidationState, callback) {
			var _this6 = this;
			var subscription = {
				callback,
				invalidationState
			};
			var dispose = function dispose() {
				_this6._invalidationSubscriptions["delete"](subscription);
			};
			this._invalidationSubscriptions.add(subscription);
			return { dispose };
		};
		_proto._updateInvalidationSubscription = function _updateInvalidationSubscription(subscription, invalidatedStore) {
			var _this7 = this;
			var callback = subscription.callback;
			var dataIDs = subscription.invalidationState.dataIDs;
			if (!(invalidatedStore || dataIDs.some(function(dataID) {
				return _this7._invalidatedRecordIDs.has(dataID);
			}))) return;
			callback();
		};
		_proto.snapshot = function snapshot() {
			!(this._optimisticSource == null) && invariant(false);
			var log = this.__log;
			if (log != null) log({ name: "store.snapshot" });
			this._storeSubscriptions.snapshotSubscriptions(this.getSource());
			if (this._gcRun) {
				this._gcRun = null;
				this._shouldScheduleGC = true;
			}
			this._optimisticSource = RelayOptimisticRecordSource.create(this.getSource());
		};
		_proto.restore = function restore() {
			var optimisticSource = this._optimisticSource;
			!optimisticSource && invariant(false);
			var log = this.__log;
			if (log != null) log({ name: "store.restore" });
			var optimisticIDs = RelayOptimisticRecordSource.getOptimisticRecordIDs(optimisticSource);
			this._resolverCache.unsubscribeFromLiveResolverRecords(optimisticIDs);
			this._optimisticSource = null;
			if (this._shouldScheduleGC) this.scheduleGC();
			this._storeSubscriptions.restoreSubscriptions();
			this._resolverCache.invalidateResolverRecords(optimisticIDs);
		};
		_proto.scheduleGC = function scheduleGC() {
			if (this._gcHoldCounter > 0) {
				this._shouldScheduleGC = true;
				return;
			}
			if (this._gcRun) return;
			this._gcRun = this._collect();
			this._gcScheduler(this._gcStep);
		};
		_proto.__gc = function __gc() {
			if (this._optimisticSource != null) return;
			var gcRun = this._collect();
			while (!gcRun.next().done);
		};
		_proto._collect = function* _collect() {
			if (this._shouldRetainWithinTTL_EXPERIMENTAL && this._queryCacheExpirationTime == null) return;
			var log = this.__log;
			top: while (true) {
				if (log != null) log({ name: "store.gc.start" });
				var startEpoch = this._currentWriteEpoch;
				var references = /* @__PURE__ */ new Set();
				var _iterator2 = (0, _createForOfIteratorHelper2["default"])(this._roots.entries()), _step2;
				try {
					for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
						var _ref2, _operation$request$no3, _operation$request$no4;
						var _step2$value = _step2.value, _dataID = _step2$value[0], _step2$value$ = _step2$value[1], operation = _step2$value$.operation, refCount = _step2$value$.refCount, fetchTime = _step2$value$.fetchTime;
						if (this._shouldRetainWithinTTL_EXPERIMENTAL) {
							var _queryCacheExpirationTime = this._queryCacheExpirationTime;
							!(_queryCacheExpirationTime != null) && invariant(false);
							if ((fetchTime == null || fetchTime <= Date.now() - _queryCacheExpirationTime) && refCount === 0 && !this._releaseBuffer.includes(_dataID)) continue;
						}
						var selector = operation.root;
						var useExecTimeResolvers = (_ref2 = (_operation$request$no3 = operation.request.node.operation.use_exec_time_resolvers) !== null && _operation$request$no3 !== void 0 ? _operation$request$no3 : ((_operation$request$no4 = operation.request.node.operation.exec_time_resolvers_enabled_provider) === null || _operation$request$no4 === void 0 ? void 0 : _operation$request$no4.get()) === true) !== null && _ref2 !== void 0 ? _ref2 : false;
						RelayReferenceMarker.mark(this._recordSource, selector, references, this._operationLoader, this._shouldProcessClientComponents, useExecTimeResolvers);
						yield;
						if (startEpoch !== this._currentWriteEpoch) {
							if (log != null) log({ name: "store.gc.interrupted" });
							continue top;
						}
					}
				} catch (err) {
					_iterator2.e(err);
				} finally {
					_iterator2.f();
				}
				var storeIDs = this._recordSource.getRecordIDs();
				for (var ii = 0; ii < storeIDs.length; ii++) {
					var dataID = storeIDs[ii];
					if (!references.has(dataID)) {
						var record = this._recordSource.get(dataID);
						if (record != null) {
							var maybeResolverSubscription = RelayModernRecord.getValue(record, RELAY_RESOLVER_LIVE_STATE_SUBSCRIPTION_KEY);
							if (maybeResolverSubscription != null) maybeResolverSubscription();
						}
						this._recordSource.remove(dataID);
						if (this._shouldRetainWithinTTL_EXPERIMENTAL) this._roots["delete"](dataID);
					}
				}
				if (log != null) log({
					name: "store.gc.end",
					references
				});
				return;
			}
		};
		_proto.__getNormalizationOptions = function __getNormalizationOptions(path) {
			return {
				path,
				getDataID: this._getDataID,
				log: this.__log,
				treatMissingFieldsAsNull: this._treatMissingFieldsAsNull,
				shouldProcessClientComponents: this._shouldProcessClientComponents,
				actorIdentifier: this._actorIdentifier
			};
		};
		_proto.__notifyUpdatedSubscribers = function __notifyUpdatedSubscribers(updatedRecords) {
			var nextUpdatedRecordIDs = getUpdatedDataIDs(updatedRecords);
			var prevUpdatedRecordIDs = this._updatedRecordIDs;
			this._updatedRecordIDs = nextUpdatedRecordIDs;
			this.notify();
			this._updatedRecordIDs = prevUpdatedRecordIDs;
		};
		return RelayModernStore;
	}();
	function initializeRecordSource(target) {
		if (!target.has(ROOT_ID)) {
			var rootRecord = RelayModernRecord.create(ROOT_ID, ROOT_TYPE);
			target.set(ROOT_ID, rootRecord);
		}
	}
	function updateTargetFromSource(target, source, currentWriteEpoch, idsMarkedForInvalidation, updatedRecordIDs, invalidatedRecordIDs) {
		if (idsMarkedForInvalidation) idsMarkedForInvalidation.forEach(function(dataID) {
			var targetRecord = target.get(dataID);
			var sourceRecord = source.get(dataID);
			if (sourceRecord === null) return;
			var nextRecord;
			if (targetRecord != null) nextRecord = RelayModernRecord.clone(targetRecord);
			else nextRecord = sourceRecord != null ? RelayModernRecord.clone(sourceRecord) : null;
			if (!nextRecord) return;
			RelayModernRecord.setValue(nextRecord, RelayStoreUtils.INVALIDATED_AT_KEY, currentWriteEpoch);
			invalidatedRecordIDs.add(dataID);
			target.set(dataID, nextRecord);
		});
		var dataIDs = source.getRecordIDs();
		for (var ii = 0; ii < dataIDs.length; ii++) {
			var dataID = dataIDs[ii];
			var sourceRecord = source.get(dataID);
			var targetRecord = target.get(dataID);
			if (sourceRecord && targetRecord) {
				var nextRecord = RelayModernRecord.update(targetRecord, sourceRecord);
				if (nextRecord !== targetRecord) {
					updatedRecordIDs.add(dataID);
					target.set(dataID, nextRecord);
				}
			} else if (sourceRecord === null) {
				target["delete"](dataID);
				if (targetRecord !== null) updatedRecordIDs.add(dataID);
			} else if (sourceRecord) {
				target.set(dataID, sourceRecord);
				updatedRecordIDs.add(dataID);
			}
		}
	}
	function getAvailabilityStatus(operationAvailability, operationLastWrittenAt, operationFetchTime, queryCacheExpirationTime) {
		var mostRecentlyInvalidatedAt = operationAvailability.mostRecentlyInvalidatedAt, status = operationAvailability.status;
		if (typeof mostRecentlyInvalidatedAt === "number") {
			if (operationLastWrittenAt == null || mostRecentlyInvalidatedAt > operationLastWrittenAt) return { status: "stale" };
		}
		if (status === "missing") return { status: "missing" };
		if (operationFetchTime != null && queryCacheExpirationTime != null) {
			if (operationFetchTime <= Date.now() - queryCacheExpirationTime) return { status: "stale" };
		}
		return {
			status: "available",
			fetchTime: operationFetchTime !== null && operationFetchTime !== void 0 ? operationFetchTime : null
		};
	}
	module.exports = RelayModernStore;
}));
var require_RelayRecordSourceSelectorProxy = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _require = require_RelayStoreUtils(), ROOT_TYPE = _require.ROOT_TYPE, getStorageKey = _require.getStorageKey;
	var _readUpdatableFragment = require_readUpdatableFragment().readUpdatableFragment;
	var _readUpdatableQuery = require_readUpdatableQuery().readUpdatableQuery;
	var invariant = require_invariant();
	module.exports = /* @__PURE__ */ function() {
		function RelayRecordSourceSelectorProxy(mutator, recordSource, readSelector, missingFieldHandlers) {
			this.__mutator = mutator;
			this.__recordSource = recordSource;
			this._readSelector = readSelector;
			this._missingFieldHandlers = missingFieldHandlers;
		}
		var _proto = RelayRecordSourceSelectorProxy.prototype;
		_proto.create = function create(dataID, typeName) {
			return this.__recordSource.create(dataID, typeName);
		};
		_proto["delete"] = function _delete(dataID) {
			this.__recordSource["delete"](dataID);
		};
		_proto.get = function get(dataID) {
			return this.__recordSource.get(dataID);
		};
		_proto.getRoot = function getRoot() {
			return this.__recordSource.getRoot();
		};
		_proto.getOperationRoot = function getOperationRoot() {
			var root = this.__recordSource.get(this._readSelector.dataID);
			if (!root) root = this.__recordSource.create(this._readSelector.dataID, ROOT_TYPE);
			return root;
		};
		_proto._getRootField = function _getRootField(selector, fieldName, plural) {
			var field = selector.node.selections.find(function(selection) {
				return selection.kind === "LinkedField" && selection.name === fieldName || selection.kind === "RequiredField" && selection.field.name === fieldName;
			});
			if (field && field.kind === "RequiredField") field = field.field;
			!(field && field.kind === "LinkedField") && invariant(false);
			!(field.plural === plural) && invariant(false);
			return field;
		};
		_proto.getRootField = function getRootField(fieldName) {
			var storageKey = getStorageKey(this._getRootField(this._readSelector, fieldName, false), this._readSelector.variables);
			return this.getOperationRoot().getLinkedRecord(storageKey);
		};
		_proto.getPluralRootField = function getPluralRootField(fieldName) {
			var storageKey = getStorageKey(this._getRootField(this._readSelector, fieldName, true), this._readSelector.variables);
			return this.getOperationRoot().getLinkedRecords(storageKey);
		};
		_proto.invalidateStore = function invalidateStore() {
			this.__recordSource.invalidateStore();
		};
		_proto.readUpdatableQuery = function readUpdatableQuery(query, variables) {
			return _readUpdatableQuery(query, variables, this, this._missingFieldHandlers);
		};
		_proto.readUpdatableFragment = function readUpdatableFragment(fragment, fragmentReference) {
			return _readUpdatableFragment(fragment, fragmentReference, this, this._missingFieldHandlers);
		};
		return RelayRecordSourceSelectorProxy;
	}();
}));
var require_RelayPublishQueue = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _global$ErrorUtils$ap, _global$ErrorUtils;
	var RelayRecordSourceMutator = require_RelayRecordSourceMutator();
	var RelayRecordSourceProxy = require_RelayRecordSourceProxy();
	var RelayRecordSourceSelectorProxy = require_RelayRecordSourceSelectorProxy();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var RelayReader = require_RelayReader();
	var RelayRecordSource = require_RelayRecordSource();
	var invariant = require_invariant();
	require_warning();
	var _global = typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : void 0;
	var applyWithGuard = (_global$ErrorUtils$ap = _global === null || _global === void 0 ? void 0 : (_global$ErrorUtils = _global.ErrorUtils) === null || _global$ErrorUtils === void 0 ? void 0 : _global$ErrorUtils.applyWithGuard) !== null && _global$ErrorUtils$ap !== void 0 ? _global$ErrorUtils$ap : function(callback, context, args, onError, name) {
		return callback.apply(context, args);
	};
	var RelayPublishQueue = /* @__PURE__ */ function() {
		function RelayPublishQueue(store, handlerProvider, getDataID, missingFieldHandlers, log) {
			this._hasStoreSnapshot = false;
			this._handlerProvider = handlerProvider || null;
			this._pendingBackupRebase = false;
			this._pendingData = /* @__PURE__ */ new Set();
			this._pendingOptimisticUpdates = /* @__PURE__ */ new Set();
			this._store = store;
			this._appliedOptimisticUpdates = /* @__PURE__ */ new Set();
			this._gcHold = null;
			this._getDataID = getDataID;
			this._missingFieldHandlers = missingFieldHandlers;
			this._log = log;
		}
		var _proto = RelayPublishQueue.prototype;
		_proto.applyUpdate = function applyUpdate(updater) {
			!(!this._appliedOptimisticUpdates.has(updater) && !this._pendingOptimisticUpdates.has(updater)) && invariant(false);
			this._pendingOptimisticUpdates.add(updater);
		};
		_proto.revertUpdate = function revertUpdate(updater) {
			if (this._pendingOptimisticUpdates.has(updater)) this._pendingOptimisticUpdates["delete"](updater);
			else if (this._appliedOptimisticUpdates.has(updater)) {
				this._pendingBackupRebase = true;
				this._appliedOptimisticUpdates["delete"](updater);
			}
		};
		_proto.revertAll = function revertAll() {
			this._pendingBackupRebase = true;
			this._pendingOptimisticUpdates.clear();
			this._appliedOptimisticUpdates.clear();
		};
		_proto.commitPayload = function commitPayload(operation, payload, updater) {
			this._pendingBackupRebase = true;
			this._pendingData.add({
				kind: "payload",
				operation,
				payload,
				updater
			});
		};
		_proto.commitUpdate = function commitUpdate(updater) {
			this._pendingBackupRebase = true;
			this._pendingData.add({
				kind: "updater",
				updater
			});
		};
		_proto.commitSource = function commitSource(source) {
			this._pendingBackupRebase = true;
			this._pendingData.add({
				kind: "source",
				source
			});
		};
		_proto.run = function run(sourceOperation) {
			var runWillClearGcHold = this._appliedOptimisticUpdates === 0 && !!this._gcHold;
			var runIsANoop = !this._pendingBackupRebase && this._pendingOptimisticUpdates.size === 0 && !runWillClearGcHold;
			RelayFeatureFlags.DISALLOW_NESTED_UPDATES && !(this._isRunning !== true) && invariant(false);
			this._isRunning = true;
			if (runIsANoop) {
				this._isRunning = false;
				return [];
			}
			if (this._pendingBackupRebase) {
				if (this._hasStoreSnapshot) {
					this._store.restore();
					this._hasStoreSnapshot = false;
				}
			}
			var invalidatedStore = this._commitData();
			if (this._pendingOptimisticUpdates.size || this._pendingBackupRebase && this._appliedOptimisticUpdates.size) {
				if (!this._hasStoreSnapshot) {
					this._store.snapshot();
					this._hasStoreSnapshot = true;
				}
				this._applyUpdates();
			}
			this._pendingBackupRebase = false;
			if (this._appliedOptimisticUpdates.size > 0) {
				if (!this._gcHold) this._gcHold = this._store.holdGC();
			} else if (this._gcHold) {
				this._gcHold.dispose();
				this._gcHold = null;
			}
			this._isRunning = false;
			return this._store.notify(sourceOperation, invalidatedStore);
		};
		_proto._publishSourceFromPayload = function _publishSourceFromPayload(pendingPayload) {
			var _this = this;
			var payload = pendingPayload.payload, operation = pendingPayload.operation, updater = pendingPayload.updater;
			var source = payload.source, fieldPayloads = payload.fieldPayloads;
			var mutator = new RelayRecordSourceMutator(this._store.getSource(), source);
			var recordSourceProxy = new RelayRecordSourceProxy(mutator, this._getDataID, this._handlerProvider, this._missingFieldHandlers, this._log);
			if (fieldPayloads && fieldPayloads.length) fieldPayloads.forEach(function(fieldPayload) {
				var handler = _this._handlerProvider && _this._handlerProvider(fieldPayload.handle);
				!handler && invariant(false);
				handler.update(recordSourceProxy, fieldPayload);
			});
			if (updater) {
				var selector = operation.fragment;
				!(selector != null) && invariant(false);
				updater(new RelayRecordSourceSelectorProxy(mutator, recordSourceProxy, selector, this._missingFieldHandlers), lookupSelector(source, selector));
			}
			var idsMarkedForInvalidation = recordSourceProxy.getIDsMarkedForInvalidation();
			this._store.publish(source, idsMarkedForInvalidation);
			return recordSourceProxy.isStoreMarkedForInvalidation();
		};
		_proto._commitData = function _commitData() {
			var _this2 = this;
			if (!this._pendingData.size) return false;
			var invalidatedStore = false;
			this._pendingData.forEach(function(data) {
				if (data.kind === "payload") {
					var payloadInvalidatedStore = _this2._publishSourceFromPayload(data);
					invalidatedStore = invalidatedStore || payloadInvalidatedStore;
				} else if (data.kind === "source") {
					var source = data.source;
					_this2._store.publish(source);
				} else {
					var updater = data.updater;
					var sink = RelayRecordSource.create();
					var recordSourceProxy = new RelayRecordSourceProxy(new RelayRecordSourceMutator(_this2._store.getSource(), sink), _this2._getDataID, _this2._handlerProvider, _this2._missingFieldHandlers, _this2._log);
					applyWithGuard(updater, null, [recordSourceProxy], null, "RelayPublishQueue:commitData");
					invalidatedStore = invalidatedStore || recordSourceProxy.isStoreMarkedForInvalidation();
					var idsMarkedForInvalidation = recordSourceProxy.getIDsMarkedForInvalidation();
					_this2._store.publish(sink, idsMarkedForInvalidation);
				}
			});
			this._pendingData.clear();
			return invalidatedStore;
		};
		_proto._applyUpdates = function _applyUpdates() {
			var _this3 = this;
			var sink = RelayRecordSource.create();
			var mutator = new RelayRecordSourceMutator(this._store.getSource(), sink);
			var recordSourceProxy = new RelayRecordSourceProxy(mutator, this._getDataID, this._handlerProvider, this._missingFieldHandlers, this._log);
			var processUpdate = function processUpdate(optimisticUpdate) {
				if (optimisticUpdate.storeUpdater) {
					var storeUpdater = optimisticUpdate.storeUpdater;
					applyWithGuard(storeUpdater, null, [recordSourceProxy], null, "RelayPublishQueue:applyUpdates");
				} else {
					var operation = optimisticUpdate.operation, payload = optimisticUpdate.payload, updater = optimisticUpdate.updater;
					var source = payload.source, fieldPayloads = payload.fieldPayloads;
					if (source) recordSourceProxy.publishSource(source, fieldPayloads);
					if (updater) {
						var selectorData;
						if (source) selectorData = lookupSelector(source, operation.fragment);
						applyWithGuard(updater, null, [new RelayRecordSourceSelectorProxy(mutator, recordSourceProxy, operation.fragment, _this3._missingFieldHandlers), selectorData], null, "RelayPublishQueue:applyUpdates");
					}
				}
			};
			if (this._pendingBackupRebase && this._appliedOptimisticUpdates.size) this._appliedOptimisticUpdates.forEach(processUpdate);
			if (this._pendingOptimisticUpdates.size) {
				this._pendingOptimisticUpdates.forEach(function(optimisticUpdate) {
					processUpdate(optimisticUpdate);
					_this3._appliedOptimisticUpdates.add(optimisticUpdate);
				});
				this._pendingOptimisticUpdates.clear();
			}
			this._store.publish(sink);
		};
		return RelayPublishQueue;
	}();
	function lookupSelector(source, selector) {
		return RelayReader.read(source, selector).data;
	}
	module.exports = RelayPublishQueue;
}));
var require_RelayModernEnvironment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var RelayDefaultHandlerProvider = require_RelayDefaultHandlerProvider();
	var _require = require_ActorIdentifier(), INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE = _require.INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE, assertInternalActorIdentifier = _require.assertInternalActorIdentifier;
	var RelayObservable = require_RelayObservable();
	var wrapNetworkWithLogObserver = require_wrapNetworkWithLogObserver();
	var RelayOperationTracker = require_RelayOperationTracker();
	var registerEnvironmentWithDevTools = require_registerEnvironmentWithDevTools();
	var defaultGetDataID = require_defaultGetDataID();
	var defaultRelayFieldLogger = require_defaultRelayFieldLogger();
	var normalizeResponse = require_normalizeResponse();
	var OperationExecutor = require_OperationExecutor();
	var RelayModernStore = require_RelayModernStore();
	var RelayPublishQueue = require_RelayPublishQueue();
	var RelayRecordSource = require_RelayRecordSource();
	require_invariant();
	var RelayModernEnvironment = /* @__PURE__ */ function() {
		function RelayModernEnvironment(config) {
			var _this = this;
			var _config$store, _config$log, _config$relayFieldLog, _config$UNSTABLE_defa, _config$getDataID, _config$missingFieldH, _config$handlerProvid, _config$scheduler, _config$isServer, _config$normalizeResp, _config$operationTrac;
			this.configName = config.configName;
			this._treatMissingFieldsAsNull = config.treatMissingFieldsAsNull === true;
			var operationLoader = config.operationLoader;
			var store = (_config$store = config.store) !== null && _config$store !== void 0 ? _config$store : new RelayModernStore(new RelayRecordSource(), {
				log: config.log,
				operationLoader: config.operationLoader,
				getDataID: config.getDataID,
				shouldProcessClientComponents: config.shouldProcessClientComponents
			});
			this.__log = (_config$log = config.log) !== null && _config$log !== void 0 ? _config$log : emptyFunction;
			this.relayFieldLogger = (_config$relayFieldLog = config.relayFieldLogger) !== null && _config$relayFieldLog !== void 0 ? _config$relayFieldLog : defaultRelayFieldLogger;
			this._defaultRenderPolicy = (_config$UNSTABLE_defa = config.UNSTABLE_defaultRenderPolicy) !== null && _config$UNSTABLE_defa !== void 0 ? _config$UNSTABLE_defa : "partial";
			this._operationLoader = operationLoader;
			this._operationExecutions = /* @__PURE__ */ new Map();
			this._network = wrapNetworkWithLogObserver(this, config.network);
			this._getDataID = (_config$getDataID = config.getDataID) !== null && _config$getDataID !== void 0 ? _config$getDataID : defaultGetDataID;
			this._missingFieldHandlers = (_config$missingFieldH = config.missingFieldHandlers) !== null && _config$missingFieldH !== void 0 ? _config$missingFieldH : [];
			this._publishQueue = new RelayPublishQueue(store, (_config$handlerProvid = config.handlerProvider) !== null && _config$handlerProvid !== void 0 ? _config$handlerProvid : RelayDefaultHandlerProvider, this._getDataID, this._missingFieldHandlers, this.__log);
			this._scheduler = (_config$scheduler = config.scheduler) !== null && _config$scheduler !== void 0 ? _config$scheduler : null;
			this._store = store;
			this.options = config.options;
			this._isServer = (_config$isServer = config.isServer) !== null && _config$isServer !== void 0 ? _config$isServer : false;
			this._normalizeResponse = (_config$normalizeResp = config.normalizeResponse) !== null && _config$normalizeResp !== void 0 ? _config$normalizeResp : normalizeResponse;
			this.__setNet = function(newNet) {
				return _this._network = wrapNetworkWithLogObserver(_this, newNet);
			};
			this._operationTracker = (_config$operationTrac = config.operationTracker) !== null && _config$operationTrac !== void 0 ? _config$operationTrac : new RelayOperationTracker();
			this._shouldProcessClientComponents = config.shouldProcessClientComponents;
			registerEnvironmentWithDevTools(this);
		}
		var _proto = RelayModernEnvironment.prototype;
		_proto.getStore = function getStore() {
			return this._store;
		};
		_proto.getNetwork = function getNetwork() {
			return this._network;
		};
		_proto.getOperationTracker = function getOperationTracker() {
			return this._operationTracker;
		};
		_proto.getScheduler = function getScheduler() {
			return this._scheduler;
		};
		_proto.isRequestActive = function isRequestActive(requestIdentifier) {
			return this._operationExecutions.get(requestIdentifier) === "active";
		};
		_proto.UNSTABLE_getDefaultRenderPolicy = function UNSTABLE_getDefaultRenderPolicy() {
			return this._defaultRenderPolicy;
		};
		_proto.applyUpdate = function applyUpdate(optimisticUpdate) {
			var _this2 = this;
			var dispose = function dispose() {
				_this2._scheduleUpdates(function() {
					_this2._publishQueue.revertUpdate(optimisticUpdate);
					_this2._publishQueue.run();
				});
			};
			this._scheduleUpdates(function() {
				_this2._publishQueue.applyUpdate(optimisticUpdate);
				_this2._publishQueue.run();
			});
			return { dispose };
		};
		_proto.revertUpdate = function revertUpdate(update) {
			var _this3 = this;
			this._scheduleUpdates(function() {
				_this3._publishQueue.revertUpdate(update);
				_this3._publishQueue.run();
			});
		};
		_proto.replaceUpdate = function replaceUpdate(update, newUpdate) {
			var _this4 = this;
			this._scheduleUpdates(function() {
				_this4._publishQueue.revertUpdate(update);
				_this4._publishQueue.applyUpdate(newUpdate);
				_this4._publishQueue.run();
			});
		};
		_proto.applyMutation = function applyMutation(optimisticConfig) {
			var subscription = this._execute({
				createSource: function createSource() {
					return RelayObservable.create(function(_sink) {});
				},
				isClientPayload: false,
				operation: optimisticConfig.operation,
				optimisticConfig,
				updater: null
			}).subscribe({});
			return { dispose: function dispose() {
				return subscription.unsubscribe();
			} };
		};
		_proto.check = function check(operation) {
			if (this._missingFieldHandlers.length === 0 && !operationHasClientAbstractTypes(operation)) return this._store.check(operation);
			return this._checkSelectorAndHandleMissingFields(operation, this._missingFieldHandlers);
		};
		_proto.commitPayload = function commitPayload(operation, payload) {
			this._execute({
				createSource: function createSource() {
					return RelayObservable.from({ data: payload });
				},
				isClientPayload: true,
				operation,
				optimisticConfig: null,
				updater: null
			}).subscribe({});
		};
		_proto.commitUpdate = function commitUpdate(updater) {
			var _this5 = this;
			this._scheduleUpdates(function() {
				_this5._publishQueue.commitUpdate(updater);
				_this5._publishQueue.run();
			});
		};
		_proto.lookup = function lookup(readSelector) {
			return this._store.lookup(readSelector);
		};
		_proto.subscribe = function subscribe(snapshot, callback) {
			return this._store.subscribe(snapshot, callback);
		};
		_proto.retain = function retain(operation) {
			return this._store.retain(operation);
		};
		_proto.isServer = function isServer() {
			return this._isServer;
		};
		_proto._checkSelectorAndHandleMissingFields = function _checkSelectorAndHandleMissingFields(operation, handlers) {
			var _this6 = this;
			var target = RelayRecordSource.create();
			var source = this._store.getSource();
			var result = this._store.check(operation, {
				handlers,
				defaultActorIdentifier: INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE,
				getSourceForActor: function getSourceForActor(actorIdentifier) {
					assertInternalActorIdentifier(actorIdentifier);
					return source;
				},
				getTargetForActor: function getTargetForActor(actorIdentifier) {
					assertInternalActorIdentifier(actorIdentifier);
					return target;
				}
			});
			if (target.size() > 0) this._scheduleUpdates(function() {
				_this6._publishQueue.commitSource(target);
				_this6._publishQueue.run();
			});
			return result;
		};
		_proto._scheduleUpdates = function _scheduleUpdates(task) {
			var scheduler = this._scheduler;
			if (scheduler != null) scheduler.schedule(task);
			else task();
		};
		_proto.execute = function execute(_ref) {
			var _this7 = this;
			var operation = _ref.operation;
			return this._execute({
				createSource: function createSource() {
					return _this7.getNetwork().execute(operation.request.node.params, operation.request.variables, operation.request.cacheConfig || {}, null, void 0, void 0, void 0, function() {
						return _this7.check(operation);
					});
				},
				isClientPayload: false,
				operation,
				optimisticConfig: null,
				updater: null
			});
		};
		_proto.executeSubscription = function executeSubscription(_ref2) {
			var _this8 = this;
			var operation = _ref2.operation, updater = _ref2.updater;
			return this._execute({
				createSource: function createSource() {
					return _this8.getNetwork().execute(operation.request.node.params, operation.request.variables, operation.request.cacheConfig || {}, null);
				},
				isClientPayload: false,
				operation,
				optimisticConfig: null,
				updater
			});
		};
		_proto.executeMutation = function executeMutation(_ref3) {
			var _this9 = this;
			var operation = _ref3.operation, optimisticResponse = _ref3.optimisticResponse, optimisticUpdater = _ref3.optimisticUpdater, updater = _ref3.updater, uploadables = _ref3.uploadables;
			var optimisticConfig;
			if (optimisticResponse || optimisticUpdater) optimisticConfig = {
				operation,
				response: optimisticResponse,
				updater: optimisticUpdater
			};
			return this._execute({
				createSource: function createSource() {
					return _this9.getNetwork().execute(operation.request.node.params, operation.request.variables, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, operation.request.cacheConfig), {}, { force: true }), uploadables);
				},
				isClientPayload: false,
				operation,
				optimisticConfig,
				updater
			});
		};
		_proto.executeWithSource = function executeWithSource(_ref4) {
			var operation = _ref4.operation, source = _ref4.source;
			return this._execute({
				createSource: function createSource() {
					return source;
				},
				isClientPayload: false,
				operation,
				optimisticConfig: null,
				updater: null
			});
		};
		_proto.toJSON = function toJSON() {
			var _this$configName;
			return "RelayModernEnvironment(".concat((_this$configName = this.configName) !== null && _this$configName !== void 0 ? _this$configName : "", ")");
		};
		_proto._execute = function _execute(_ref5) {
			var _this10 = this;
			var createSource = _ref5.createSource, isClientPayload = _ref5.isClientPayload, operation = _ref5.operation, optimisticConfig = _ref5.optimisticConfig, updater = _ref5.updater;
			var publishQueue = this._publishQueue;
			var store = this._store;
			return RelayObservable.create(function(sink) {
				var executor = OperationExecutor.execute({
					actorIdentifier: INTERNAL_ACTOR_IDENTIFIER_DO_NOT_USE,
					getDataID: _this10._getDataID,
					isClientPayload,
					log: _this10.__log,
					operation,
					operationExecutions: _this10._operationExecutions,
					operationLoader: _this10._operationLoader,
					operationTracker: _this10._operationTracker,
					optimisticConfig,
					getPublishQueue: function getPublishQueue(actorIdentifier) {
						assertInternalActorIdentifier(actorIdentifier);
						return publishQueue;
					},
					scheduler: _this10._scheduler,
					shouldProcessClientComponents: _this10._shouldProcessClientComponents,
					sink,
					source: createSource(),
					getStore: function getStore(actorIdentifier) {
						assertInternalActorIdentifier(actorIdentifier);
						return store;
					},
					treatMissingFieldsAsNull: _this10._treatMissingFieldsAsNull,
					updater,
					normalizeResponse: _this10._normalizeResponse
				});
				return function() {
					return executor.cancel();
				};
			});
		};
		return RelayModernEnvironment;
	}();
	function operationHasClientAbstractTypes(operation) {
		return operation.root.node.kind === "Operation" && operation.root.node.clientAbstractTypes != null;
	}
	RelayModernEnvironment.prototype["@@RelayModernEnvironment"] = true;
	function emptyFunction() {}
	module.exports = RelayModernEnvironment;
}));
var require_requestSubscription = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RelayDeclarativeMutationConfig = require_RelayDeclarativeMutationConfig();
	var getRequest = require_GraphQLTag().getRequest;
	var createOperationDescriptor = require_RelayModernOperationDescriptor().createOperationDescriptor;
	var createReaderSelector = require_RelayModernSelector().createReaderSelector;
	require_warning();
	function requestSubscription(environment, config) {
		var subscription = getRequest(config.subscription);
		if (subscription.params.operationKind !== "subscription") throw new Error("requestSubscription: Must use Subscription operation");
		var configs = config.configs, onCompleted = config.onCompleted, onError = config.onError, onNext = config.onNext, variables = config.variables, cacheConfig = config.cacheConfig;
		var operation = createOperationDescriptor(subscription, variables, cacheConfig);
		var updater = (configs ? RelayDeclarativeMutationConfig.convert(configs, subscription, null, config.updater) : config).updater;
		return { dispose: environment.executeSubscription({
			operation,
			updater
		}).subscribe({
			next: function next(responses) {
				if (onNext != null) {
					var selector = operation.fragment;
					var nextID;
					if (Array.isArray(responses)) {
						var _responses$, _responses$$extension;
						nextID = (_responses$ = responses[0]) === null || _responses$ === void 0 ? void 0 : (_responses$$extension = _responses$.extensions) === null || _responses$$extension === void 0 ? void 0 : _responses$$extension.__relay_subscription_root_id;
					} else {
						var _responses$extensions;
						nextID = (_responses$extensions = responses.extensions) === null || _responses$extensions === void 0 ? void 0 : _responses$extensions.__relay_subscription_root_id;
					}
					if (typeof nextID === "string") selector = createReaderSelector(selector.node, nextID, selector.variables, selector.owner);
					var data = environment.lookup(selector).data;
					onNext(data);
				}
			},
			error: onError,
			complete: onCompleted
		}).unsubscribe };
	}
	module.exports = requestSubscription;
}));
var require_createPayloadFor3DField = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _require = require_RelayStoreUtils(), getModuleComponentKey = _require.getModuleComponentKey, getModuleOperationKey = _require.getModuleOperationKey;
	function createPayloadFor3DField(name, operation, component, response) {
		var data = (0, _objectSpread2["default"])({}, response);
		data[getModuleComponentKey(name)] = component;
		data[getModuleOperationKey(name)] = operation;
		return data;
	}
	module.exports = createPayloadFor3DField;
}));
var require_isEmptyObject = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	function isEmptyObject(obj) {
		for (var _key in obj) if (hasOwnProperty.call(obj, _key)) return false;
		return true;
	}
	module.exports = isEmptyObject;
}));
var require_getFragmentIdentifier = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _require = require_RelayModernSelector(), getDataIDsFromFragment = _require.getDataIDsFromFragment, getSelector = _require.getSelector, getVariablesFromFragment = _require.getVariablesFromFragment;
	var isEmptyObject = require_isEmptyObject();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var stableCopy = require_stableCopy().stableCopy;
	var intern = require_StringInterner().intern;
	function getFragmentIdentifier(fragmentNode, fragmentRef) {
		var selector = getSelector(fragmentNode, fragmentRef);
		var fragmentOwnerIdentifier = selector == null ? "null" : selector.kind === "SingularReaderSelector" ? selector.owner.identifier : "[" + selector.selectors.map(function(sel) {
			return sel.owner.identifier;
		}).join(",") + "]";
		var fragmentVariables = getVariablesFromFragment(fragmentNode, fragmentRef);
		var dataIDs = getDataIDsFromFragment(fragmentNode, fragmentRef);
		if (RelayFeatureFlags.ENABLE_GETFRAGMENTIDENTIFIER_OPTIMIZATION) {
			var ids = typeof dataIDs === "undefined" ? "missing" : dataIDs == null ? "null" : Array.isArray(dataIDs) ? "[" + dataIDs.join(",") + "]" : dataIDs;
			ids = RelayFeatureFlags.STRING_INTERN_LEVEL <= 1 ? ids : intern(ids, RelayFeatureFlags.MAX_DATA_ID_LENGTH);
			return fragmentOwnerIdentifier + "/" + fragmentNode.name + "/" + (fragmentVariables == null || isEmptyObject(fragmentVariables) ? "{}" : JSON.stringify(stableCopy(fragmentVariables))) + "/" + ids;
		} else {
			var _JSON$stringify;
			var _ids = (_JSON$stringify = JSON.stringify(dataIDs)) !== null && _JSON$stringify !== void 0 ? _JSON$stringify : "missing";
			_ids = RelayFeatureFlags.STRING_INTERN_LEVEL <= 1 ? _ids : intern(_ids, RelayFeatureFlags.MAX_DATA_ID_LENGTH);
			return fragmentOwnerIdentifier + "/" + fragmentNode.name + "/" + JSON.stringify(stableCopy(fragmentVariables)) + "/" + _ids;
		}
	}
	module.exports = getFragmentIdentifier;
}));
var require_getRefetchMetadata = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	function getRefetchMetadata(fragmentNode, componentDisplayName) {
		var _fragmentNode$metadat, _fragmentNode$metadat2;
		!(((_fragmentNode$metadat = fragmentNode.metadata) === null || _fragmentNode$metadat === void 0 ? void 0 : _fragmentNode$metadat.plural) !== true) && invariant(false);
		var refetchMetadata = (_fragmentNode$metadat2 = fragmentNode.metadata) === null || _fragmentNode$metadat2 === void 0 ? void 0 : _fragmentNode$metadat2.refetch;
		!(refetchMetadata != null) && invariant(false);
		var refetchableRequest = refetchMetadata.operation["default"] ? refetchMetadata.operation["default"] : refetchMetadata.operation;
		var fragmentRefPathInResponse = refetchMetadata.fragmentPathInResult;
		!(typeof refetchableRequest !== "string") && invariant(false);
		var identifierInfo = refetchMetadata.identifierInfo;
		if (identifierInfo != null) {
			!(identifierInfo.identifierField == null || typeof identifierInfo.identifierField === "string") && invariant(false);
			!(identifierInfo.identifierQueryVariableName == null || typeof identifierInfo.identifierQueryVariableName === "string") && invariant(false);
		}
		return {
			fragmentRefPathInResponse,
			identifierInfo,
			refetchableRequest,
			refetchMetadata
		};
	}
	module.exports = getRefetchMetadata;
}));
var require_getPaginationMetadata = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getRefetchMetadata = require_getRefetchMetadata();
	var invariant = require_invariant();
	function getPaginationMetadata(fragmentNode, componentDisplayName) {
		var _fragmentNode$metadat, _fragmentNode$metadat2;
		var _getRefetchMetadata = getRefetchMetadata(fragmentNode, componentDisplayName), paginationRequest = _getRefetchMetadata.refetchableRequest, refetchMetadata = _getRefetchMetadata.refetchMetadata;
		var paginationMetadata = refetchMetadata.connection;
		!(paginationMetadata != null) && invariant(false);
		var connectionPathInFragmentData = paginationMetadata.path;
		var connectionMetadata = ((_fragmentNode$metadat = (_fragmentNode$metadat2 = fragmentNode.metadata) === null || _fragmentNode$metadat2 === void 0 ? void 0 : _fragmentNode$metadat2.connection) !== null && _fragmentNode$metadat !== void 0 ? _fragmentNode$metadat : [])[0];
		!(connectionMetadata != null) && invariant(false);
		var identifierInfo = refetchMetadata.identifierInfo;
		!((identifierInfo === null || identifierInfo === void 0 ? void 0 : identifierInfo.identifierField) == null || typeof identifierInfo.identifierField === "string") && invariant(false);
		return {
			connectionPathInFragmentData,
			identifierField: identifierInfo === null || identifierInfo === void 0 ? void 0 : identifierInfo.identifierField,
			paginationRequest,
			paginationMetadata,
			stream: connectionMetadata.stream === true
		};
	}
	module.exports = getPaginationMetadata;
}));
var require_getPaginationVariables = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _objectSpread4 = _interopRequireDefault(require_objectSpread2());
	var invariant = require_invariant();
	require_warning();
	function getPaginationVariables(direction, count, cursor, baseVariables, extraVariables, paginationMetadata) {
		var _objectSpread3;
		var backwardMetadata = paginationMetadata.backward, forwardMetadata = paginationMetadata.forward;
		if (direction === "backward") {
			var _objectSpread2;
			!(backwardMetadata != null && backwardMetadata.count != null && backwardMetadata.cursor != null) && invariant(false);
			var _paginationVariables = (0, _objectSpread4["default"])((0, _objectSpread4["default"])((0, _objectSpread4["default"])({}, baseVariables), extraVariables), {}, (_objectSpread2 = {}, (0, _defineProperty2["default"])(_objectSpread2, backwardMetadata.cursor, cursor), (0, _defineProperty2["default"])(_objectSpread2, backwardMetadata.count, count), _objectSpread2));
			if (forwardMetadata && forwardMetadata.cursor) _paginationVariables[forwardMetadata.cursor] = null;
			if (forwardMetadata && forwardMetadata.count) _paginationVariables[forwardMetadata.count] = null;
			return _paginationVariables;
		}
		!(forwardMetadata != null && forwardMetadata.count != null && forwardMetadata.cursor != null) && invariant(false);
		var paginationVariables = (0, _objectSpread4["default"])((0, _objectSpread4["default"])((0, _objectSpread4["default"])({}, baseVariables), extraVariables), {}, (_objectSpread3 = {}, (0, _defineProperty2["default"])(_objectSpread3, forwardMetadata.cursor, cursor), (0, _defineProperty2["default"])(_objectSpread3, forwardMetadata.count, count), _objectSpread3));
		if (backwardMetadata && backwardMetadata.cursor) paginationVariables[backwardMetadata.cursor] = null;
		if (backwardMetadata && backwardMetadata.count) paginationVariables[backwardMetadata.count] = null;
		return paginationVariables;
	}
	module.exports = getPaginationVariables;
}));
var require_getValueAtPath = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var invariant = require_invariant();
	function getValueAtPath(data, path) {
		var result = data;
		var _iterator = (0, _createForOfIteratorHelper2["default"])(path), _step;
		try {
			for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var key = _step.value;
				if (result == null) return null;
				if (typeof key === "number") {
					!Array.isArray(result) && invariant(false);
					result = result[key];
				} else {
					!(typeof result === "object" && !Array.isArray(result)) && invariant(false);
					result = result[key];
				}
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
		return result;
	}
	module.exports = getValueAtPath;
}));
var require_RelayProfiler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var profileHandlersByName = {};
	var defaultProfiler = { stop: function stop() {} };
	var RelayProfiler = {
		profile: function profile(name, state) {
			var handlers = profileHandlersByName[name];
			if (handlers && handlers.length > 0) {
				var stopHandlers = [];
				for (var ii = handlers.length - 1; ii >= 0; ii--) {
					var stopHandler = handlers[ii](name, state);
					stopHandlers.unshift(stopHandler);
				}
				return { stop: function stop(error) {
					stopHandlers.forEach(function(stopHandler) {
						return stopHandler(error);
					});
				} };
			}
			return defaultProfiler;
		},
		attachProfileHandler: function attachProfileHandler(name, handler) {
			if (!profileHandlersByName.hasOwnProperty(name)) profileHandlersByName[name] = [];
			profileHandlersByName[name].push(handler);
		},
		detachProfileHandler: function detachProfileHandler(name, handler) {
			if (profileHandlersByName.hasOwnProperty(name)) removeFromArray(profileHandlersByName[name], handler);
		}
	};
	function removeFromArray(array, element) {
		var index = array.indexOf(element);
		if (index !== -1) array.splice(index, 1);
	}
	module.exports = RelayProfiler;
}));
var require_lib$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _require = require_experimental(), isErrorResult = _require.isErrorResult, isValueResult = _require.isValueResult;
	var ConnectionHandler = require_ConnectionHandler();
	var ConnectionInterface = require_ConnectionInterface();
	var MutationHandlers = require_MutationHandlers();
	var RelayDefaultHandlerProvider = require_RelayDefaultHandlerProvider();
	var applyOptimisticMutation = require_applyOptimisticMutation();
	var commitLocalUpdate = require_commitLocalUpdate();
	var commitMutation = require_commitMutation();
	var RelayDeclarativeMutationConfig = require_RelayDeclarativeMutationConfig();
	var RelayNetwork = require_RelayNetwork();
	var RelayObservable = require_RelayObservable();
	var RelayQueryResponseCache = require_RelayQueryResponseCache();
	var fetchQuery = require_fetchQuery();
	var fetchQuery_DEPRECATED = require_fetchQuery_DEPRECATED();
	var fetchQueryInternal = require_fetchQueryInternal();
	var GraphQLTag = require_GraphQLTag();
	var PreloadableQueryRegistry = require_PreloadableQueryRegistry();
	var _require2 = require_ClientID(), generateClientID = _require2.generateClientID, generateUniqueClientID = _require2.generateUniqueClientID, isClientID = _require2.isClientID;
	var createFragmentSpecResolver = require_createFragmentSpecResolver();
	var createRelayContext = require_createRelayContext();
	var createRelayLoggingContext = require_createRelayLoggingContext();
	var isRelayModernEnvironment = require_isRelayModernEnvironment();
	var _require3 = require_LiveResolverSuspenseSentinel(), isSuspenseSentinel = _require3.isSuspenseSentinel, suspenseSentinel = _require3.suspenseSentinel;
	var normalizeResponse = require_normalizeResponse();
	var readInlineData = require_readInlineData();
	var RelayConcreteVariables = require_RelayConcreteVariables();
	var RelayModernEnvironment = require_RelayModernEnvironment();
	var RelayModernOperationDescriptor = require_RelayModernOperationDescriptor();
	var RelayModernRecord = require_RelayModernRecord();
	var RelayModernSelector = require_RelayModernSelector();
	var RelayModernStore = require_RelayModernStore();
	var RelayOperationTracker = require_RelayOperationTracker();
	var RelayRecordSource = require_RelayRecordSource();
	var RelayStoreUtils = require_RelayStoreUtils();
	var ResolverFragments = require_ResolverFragments();
	var ViewerPattern = require_ViewerPattern();
	var requestSubscription = require_requestSubscription();
	var createPayloadFor3DField = require_createPayloadFor3DField();
	var deepFreeze = require_deepFreeze();
	var getFragmentIdentifier = require_getFragmentIdentifier();
	var getPaginationMetadata = require_getPaginationMetadata();
	var getPaginationVariables = require_getPaginationVariables();
	var getPendingOperationsForFragment = require_getPendingOperationsForFragment();
	var getRefetchMetadata = require_getRefetchMetadata();
	var getRelayHandleKey = require_getRelayHandleKey();
	var getRequestIdentifier = require_getRequestIdentifier();
	var getValueAtPath = require_getValueAtPath();
	var handlePotentialSnapshotErrors = require_handlePotentialSnapshotErrors().handlePotentialSnapshotErrors;
	var isPromise = require_isPromise();
	var isScalarAndEqual = require_isScalarAndEqual();
	var recycleNodesInto = require_recycleNodesInto();
	var RelayConcreteNode = require_RelayConcreteNode();
	var RelayDefaultHandleKey = require_RelayDefaultHandleKey();
	var RelayError = require_RelayError();
	var RelayFeatureFlags = require_RelayFeatureFlags();
	var RelayProfiler = require_RelayProfiler();
	var RelayReplaySubject = require_RelayReplaySubject();
	var _require5 = require_stableCopy(), hasCycle = _require5.hasCycle, stableCopy = _require5.stableCopy;
	var withProvidedVariables = require_withProvidedVariables();
	module.exports = {
		Environment: RelayModernEnvironment,
		Network: RelayNetwork,
		Observable: RelayObservable,
		QueryResponseCache: RelayQueryResponseCache,
		RecordSource: RelayRecordSource,
		Record: RelayModernRecord,
		ReplaySubject: RelayReplaySubject,
		Store: RelayModernStore,
		areEqualSelectors: RelayModernSelector.areEqualSelectors,
		createFragmentSpecResolver,
		createNormalizationSelector: RelayModernSelector.createNormalizationSelector,
		createOperationDescriptor: RelayModernOperationDescriptor.createOperationDescriptor,
		createReaderSelector: RelayModernSelector.createReaderSelector,
		createRequestDescriptor: RelayModernOperationDescriptor.createRequestDescriptor,
		getArgumentValues: RelayStoreUtils.getArgumentValues,
		getDataIDsFromFragment: RelayModernSelector.getDataIDsFromFragment,
		getDataIDsFromObject: RelayModernSelector.getDataIDsFromObject,
		getNode: GraphQLTag.getNode,
		getFragment: GraphQLTag.getFragment,
		getInlineDataFragment: GraphQLTag.getInlineDataFragment,
		getModuleComponentKey: RelayStoreUtils.getModuleComponentKey,
		getModuleOperationKey: RelayStoreUtils.getModuleOperationKey,
		getPaginationFragment: GraphQLTag.getPaginationFragment,
		getPluralSelector: RelayModernSelector.getPluralSelector,
		getRefetchableFragment: GraphQLTag.getRefetchableFragment,
		getRequest: GraphQLTag.getRequest,
		getRequestIdentifier,
		getSelector: RelayModernSelector.getSelector,
		getSelectorsFromObject: RelayModernSelector.getSelectorsFromObject,
		getSingularSelector: RelayModernSelector.getSingularSelector,
		getStorageKey: RelayStoreUtils.getStorageKey,
		getVariablesFromFragment: RelayModernSelector.getVariablesFromFragment,
		getVariablesFromObject: RelayModernSelector.getVariablesFromObject,
		getVariablesFromPluralFragment: RelayModernSelector.getVariablesFromPluralFragment,
		getVariablesFromSingularFragment: RelayModernSelector.getVariablesFromSingularFragment,
		handlePotentialSnapshotErrors,
		graphql: GraphQLTag.graphql,
		isErrorResult,
		isValueResult,
		isFragment: GraphQLTag.isFragment,
		isInlineDataFragment: GraphQLTag.isInlineDataFragment,
		isSuspenseSentinel,
		suspenseSentinel,
		isRequest: GraphQLTag.isRequest,
		readInlineData,
		readFragment: ResolverFragments.readFragment,
		MutationTypes: RelayDeclarativeMutationConfig.MutationTypes,
		RangeOperations: RelayDeclarativeMutationConfig.RangeOperations,
		DefaultHandlerProvider: RelayDefaultHandlerProvider,
		ConnectionHandler,
		MutationHandlers,
		VIEWER_ID: ViewerPattern.VIEWER_ID,
		VIEWER_TYPE: ViewerPattern.VIEWER_TYPE,
		applyOptimisticMutation,
		commitLocalUpdate,
		commitMutation,
		fetchQuery,
		fetchQuery_DEPRECATED,
		isRelayModernEnvironment,
		requestSubscription,
		ConnectionInterface,
		PreloadableQueryRegistry,
		RelayProfiler,
		createPayloadFor3DField,
		RelayConcreteNode,
		RelayError,
		RelayFeatureFlags,
		DEFAULT_HANDLE_KEY: RelayDefaultHandleKey.DEFAULT_HANDLE_KEY,
		FRAGMENTS_KEY: RelayStoreUtils.FRAGMENTS_KEY,
		FRAGMENT_OWNER_KEY: RelayStoreUtils.FRAGMENT_OWNER_KEY,
		ID_KEY: RelayStoreUtils.ID_KEY,
		REF_KEY: RelayStoreUtils.REF_KEY,
		REFS_KEY: RelayStoreUtils.REFS_KEY,
		ROOT_ID: RelayStoreUtils.ROOT_ID,
		ROOT_TYPE: RelayStoreUtils.ROOT_TYPE,
		TYPENAME_KEY: RelayStoreUtils.TYPENAME_KEY,
		deepFreeze,
		generateClientID,
		generateUniqueClientID,
		getRelayHandleKey,
		isClientID,
		isPromise,
		isScalarAndEqual,
		recycleNodesInto,
		stableCopy,
		hasCycle,
		getFragmentIdentifier,
		getRefetchMetadata,
		getPaginationMetadata,
		getPaginationVariables,
		getPendingOperationsForFragment,
		getValueAtPath,
		__internal: {
			ResolverFragments,
			OperationTracker: RelayOperationTracker,
			createRelayContext,
			createRelayLoggingContext,
			getOperationVariables: RelayConcreteVariables.getOperationVariables,
			getLocalVariables: RelayConcreteVariables.getLocalVariables,
			fetchQuery: fetchQueryInternal.fetchQuery,
			fetchQueryDeduped: fetchQueryInternal.fetchQueryDeduped,
			getPromiseForActiveRequest: fetchQueryInternal.getPromiseForActiveRequest,
			getObservableForActiveRequest: fetchQueryInternal.getObservableForActiveRequest,
			normalizeResponse,
			withProvidedVariables
		}
	};
}));
var require_relay_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Relay v20.1.1
	*
	* Copyright (c) Meta Platforms, Inc. and affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	module.exports = require_lib$1();
}));
var require_ReactRelayContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var React$14 = __require("react");
	var createRelayContext = require_relay_runtime().__internal.createRelayContext;
	module.exports = createRelayContext(React$14);
}));
var require_extends = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _extends() {
		return module.exports = _extends = Object.assign ? Object.assign.bind() : function(n) {
			for (var e = 1; e < arguments.length; e++) {
				var t = arguments[e];
				for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
			}
			return n;
		}, module.exports.__esModule = true, module.exports["default"] = module.exports, _extends.apply(null, arguments);
	}
	module.exports = _extends, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_assertThisInitialized = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _assertThisInitialized(e) {
		if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
		return e;
	}
	module.exports = _assertThisInitialized, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_setPrototypeOf = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _setPrototypeOf(t, e) {
		return module.exports = _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
			return t.__proto__ = e, t;
		}, module.exports.__esModule = true, module.exports["default"] = module.exports, _setPrototypeOf(t, e);
	}
	module.exports = _setPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_inheritsLoose = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var setPrototypeOf = require_setPrototypeOf();
	function _inheritsLoose(t, o) {
		t.prototype = Object.create(o.prototype), t.prototype.constructor = t, setPrototypeOf(t, o);
	}
	module.exports = _inheritsLoose, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
var require_assertFragmentMap = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	function assertFragmentMap(componentName, fragmentSpec) {
		!(fragmentSpec && typeof fragmentSpec === "object") && invariant(false);
		for (var key in fragmentSpec) if (fragmentSpec.hasOwnProperty(key)) {
			var fragment = fragmentSpec[key];
			!(fragment && (typeof fragment === "object" || typeof fragment === "function")) && invariant(false);
		}
	}
	module.exports = assertFragmentMap;
}));
var require_ReactRelayContainerUtils = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function getComponentName(component) {
		return component.displayName || component.name || "Component";
	}
	function getContainerName(Component) {
		return "Relay(" + getComponentName(Component) + ")";
	}
	module.exports = {
		getComponentName,
		getContainerName
	};
}));
var require_ReactRelayQueryRendererContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = __require("react").createContext({ rootIsQueryRenderer: false });
}));
var require_buildReactRelayContainer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _extends2 = _interopRequireDefault(require_extends());
	var assertFragmentMap = require_assertFragmentMap();
	var _require = require_ReactRelayContainerUtils(), getComponentName = _require.getComponentName, getContainerName = _require.getContainerName;
	var ReactRelayContext = require_ReactRelayContext();
	var ReactRelayQueryRendererContext = require_ReactRelayQueryRendererContext();
	var invariant = require_invariant();
	var React$12 = __require("react");
	var getFragment = require_relay_runtime().getFragment;
	var useContext = React$12.useContext;
	function buildReactRelayContainer(ComponentClass, fragmentSpec, createContainerWithFragments) {
		var containerName = getContainerName(ComponentClass);
		assertFragmentMap(getComponentName(ComponentClass), fragmentSpec);
		var fragments = {};
		for (var key in fragmentSpec) fragments[key] = getFragment(fragmentSpec[key]);
		var Container = createContainerWithFragments(ComponentClass, fragments);
		Container.displayName = containerName;
		function ForwardRef(props, ref) {
			var _queryRendererContext;
			var context = useContext(ReactRelayContext);
			!(context != null) && invariant(false);
			var queryRendererContext = useContext(ReactRelayQueryRendererContext);
			return /* @__PURE__ */ React$12.createElement(Container, (0, _extends2["default"])({}, props, {
				__relayContext: context,
				__rootIsQueryRenderer: (_queryRendererContext = queryRendererContext === null || queryRendererContext === void 0 ? void 0 : queryRendererContext.rootIsQueryRenderer) !== null && _queryRendererContext !== void 0 ? _queryRendererContext : false,
				componentRef: props.componentRef || ref
			}));
		}
		ForwardRef.displayName = containerName;
		return React$12.forwardRef(ForwardRef);
	}
	module.exports = buildReactRelayContainer;
}));
var require_isRelayEnvironment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function isRelayEnvironment(environment) {
		return typeof environment === "object" && environment !== null && typeof environment.check === "function" && typeof environment.lookup === "function" && typeof environment.retain === "function" && typeof environment.execute === "function" && typeof environment.subscribe === "function";
	}
	module.exports = isRelayEnvironment;
}));
var require_RelayContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var isRelayEnvironment = require_isRelayEnvironment();
	var invariant = require_invariant();
	function assertRelayContext(relay) {
		!isRelayContext(relay) && invariant(false);
		return relay;
	}
	function isRelayContext(context) {
		return typeof context === "object" && context !== null && !Array.isArray(context) && isRelayEnvironment(context.environment);
	}
	module.exports = {
		assertRelayContext,
		isRelayContext
	};
}));
var require_ReactRelayFragmentContainer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _extends2 = _interopRequireDefault(require_extends());
	var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require_objectWithoutPropertiesLoose());
	var _assertThisInitialized2 = _interopRequireDefault(require_assertThisInitialized());
	var _inheritsLoose2 = _interopRequireDefault(require_inheritsLoose());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _excluded = [
		"componentRef",
		"__relayContext",
		"__rootIsQueryRenderer"
	];
	var buildReactRelayContainer = require_buildReactRelayContainer();
	var getContainerName = require_ReactRelayContainerUtils().getContainerName;
	var assertRelayContext = require_RelayContext().assertRelayContext;
	var areEqual = require_areEqual();
	var React$11 = __require("react");
	var _require3 = require_relay_runtime(), createFragmentSpecResolver = _require3.createFragmentSpecResolver, getDataIDsFromObject = _require3.getDataIDsFromObject, isScalarAndEqual = _require3.isScalarAndEqual;
	function createContainerWithFragments(Component, fragments) {
		var _class;
		var containerName = getContainerName(Component);
		return _class = /* @__PURE__ */ function(_React$Component) {
			(0, _inheritsLoose2["default"])(_class, _React$Component);
			function _class(props) {
				var _props$__rootIsQueryR, _this = _React$Component.call(this, props) || this;
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_handleFragmentDataUpdate", function() {
					var resolverFromThisUpdate = _this.state.resolver;
					_this.setState(function(updatedState) {
						return resolverFromThisUpdate === updatedState.resolver ? {
							data: updatedState.resolver.resolve(),
							relayProp: getRelayProp(updatedState.relayProp.environment)
						} : null;
					});
				});
				var relayContext = assertRelayContext(props.__relayContext);
				var resolver = createFragmentSpecResolver(relayContext, containerName, fragments, props, (_props$__rootIsQueryR = props.__rootIsQueryRenderer) !== null && _props$__rootIsQueryR !== void 0 ? _props$__rootIsQueryR : false);
				_this.state = {
					data: resolver.resolve(),
					prevProps: props,
					prevPropsContext: relayContext,
					relayProp: getRelayProp(relayContext.environment),
					resolver
				};
				return _this;
			}
			_class.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
				var _nextProps$__rootIsQu;
				var prevProps = prevState.prevProps;
				var relayContext = assertRelayContext(nextProps.__relayContext);
				var rootIsQueryRenderer = (_nextProps$__rootIsQu = nextProps.__rootIsQueryRenderer) !== null && _nextProps$__rootIsQu !== void 0 ? _nextProps$__rootIsQu : false;
				var prevIDs = getDataIDsFromObject(fragments, prevProps);
				var nextIDs = getDataIDsFromObject(fragments, nextProps);
				var resolver = prevState.resolver;
				if (prevState.prevPropsContext.environment !== relayContext.environment || !areEqual(prevIDs, nextIDs)) {
					resolver = createFragmentSpecResolver(relayContext, containerName, fragments, nextProps, rootIsQueryRenderer);
					return {
						data: resolver.resolve(),
						prevPropsContext: relayContext,
						prevProps: nextProps,
						relayProp: getRelayProp(relayContext.environment),
						resolver
					};
				} else {
					resolver.setProps(nextProps);
					var data = resolver.resolve();
					if (data !== prevState.data) return {
						data,
						prevProps: nextProps,
						prevPropsContext: relayContext,
						relayProp: getRelayProp(relayContext.environment)
					};
				}
				return null;
			};
			var _proto = _class.prototype;
			_proto.componentDidMount = function componentDidMount() {
				this._subscribeToNewResolverAndRerenderIfStoreHasChanged();
			};
			_proto.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
				if (this.state.resolver !== prevState.resolver) {
					prevState.resolver.dispose();
					this._subscribeToNewResolverAndRerenderIfStoreHasChanged();
				} else this._rerenderIfStoreHasChanged();
			};
			_proto.componentWillUnmount = function componentWillUnmount() {
				this.state.resolver.dispose();
			};
			_proto.shouldComponentUpdate = function shouldComponentUpdate(nextProps, nextState) {
				if (nextState.data !== this.state.data) return true;
				var keys = Object.keys(nextProps);
				for (var ii = 0; ii < keys.length; ii++) {
					var key = keys[ii];
					if (key === "__relayContext") {
						if (nextState.prevPropsContext.environment !== this.state.prevPropsContext.environment) return true;
					} else if (!fragments.hasOwnProperty(key) && !isScalarAndEqual(nextProps[key], this.props[key])) return true;
				}
				return false;
			};
			_proto._rerenderIfStoreHasChanged = function _rerenderIfStoreHasChanged() {
				var _this$state = this.state, data = _this$state.data;
				var maybeNewData = _this$state.resolver.resolve();
				if (data !== maybeNewData) this.setState({ data: maybeNewData });
			};
			_proto._subscribeToNewResolverAndRerenderIfStoreHasChanged = function _subscribeToNewResolverAndRerenderIfStoreHasChanged() {
				var _this$state2 = this.state, data = _this$state2.data, resolver = _this$state2.resolver;
				var maybeNewData = resolver.resolve();
				resolver.setCallback(this.props, this._handleFragmentDataUpdate);
				if (data !== maybeNewData) this.setState({ data: maybeNewData });
			};
			_proto.render = function render() {
				var _this$props = this.props, componentRef = _this$props.componentRef;
				_this$props.__relayContext;
				_this$props.__rootIsQueryRenderer;
				var props = (0, _objectWithoutPropertiesLoose2["default"])(_this$props, _excluded);
				return /* @__PURE__ */ React$11.createElement(Component, (0, _extends2["default"])({}, props, this.state.data, {
					ref: componentRef,
					relay: this.state.relayProp
				}));
			};
			return _class;
		}(React$11.Component), (0, _defineProperty2["default"])(_class, "displayName", containerName), _class;
	}
	function getRelayProp(environment) {
		return { environment };
	}
	function createContainer(Component, fragmentSpec) {
		return buildReactRelayContainer(Component, fragmentSpec, createContainerWithFragments);
	}
	module.exports = { createContainer };
}));
var require_ReactRelayLocalQueryRenderer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactRelayContext = require_ReactRelayContext();
	var ReactRelayQueryRendererContext = require_ReactRelayQueryRendererContext();
	var areEqual = require_areEqual();
	var React$10 = __require("react"), _require$10 = require_relay_runtime(), createOperationDescriptor$1 = _require$10.createOperationDescriptor;
	_require$10.deepFreeze;
	var getRequest = _require$10.getRequest;
	var useLayoutEffect = React$10.useLayoutEffect, useState = React$10.useState, useRef = React$10.useRef, useMemo = React$10.useMemo;
	var queryRendererContext = { rootIsQueryRenderer: true };
	function useDeepCompare(value) {
		var latestValue = React$10.useRef(value);
		if (!areEqual(latestValue.current, value)) latestValue.current = value;
		return latestValue.current;
	}
	function ReactRelayLocalQueryRenderer(props) {
		var environment = props.environment, query = props.query, variables = props.variables, render = props.render;
		var latestVariables = useDeepCompare(variables);
		var operation = useMemo(function() {
			return createOperationDescriptor$1(getRequest(query), latestVariables);
		}, [query, latestVariables]);
		var relayContext = useMemo(function() {
			return { environment };
		}, [environment]);
		var dataRef = useRef(null);
		var forceUpdate = useState(null)[1];
		var cleanupFnRef = useRef(null);
		useLayoutEffect(function() {
			var cleanupFn = cleanupFnRef.current;
			return function() {
				cleanupFn && cleanupFn();
			};
		}, [useMemo(function() {
			environment.check(operation);
			var res = environment.lookup(operation.fragment);
			dataRef.current = res.data;
			var retainDisposable = environment.retain(operation);
			var subscribeDisposable = environment.subscribe(res, function(newSnapshot) {
				dataRef.current = newSnapshot.data;
				forceUpdate(dataRef.current);
			});
			var disposed = false;
			function nextCleanupFn() {
				if (!disposed) {
					disposed = true;
					cleanupFnRef.current = null;
					retainDisposable.dispose();
					subscribeDisposable.dispose();
				}
			}
			if (cleanupFnRef.current) cleanupFnRef.current();
			cleanupFnRef.current = nextCleanupFn;
			return res;
		}, [environment, operation])]);
		return /* @__PURE__ */ React$10.createElement(ReactRelayContext.Provider, { value: relayContext }, /* @__PURE__ */ React$10.createElement(ReactRelayQueryRendererContext.Provider, { value: queryRendererContext }, render({ props: dataRef.current })));
	}
	module.exports = ReactRelayLocalQueryRenderer;
}));
var require_getRootVariablesForFragments = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var getSelector = require_relay_runtime().getSelector;
	function getRootVariablesForFragments(fragments, props) {
		var rootVariables = {};
		Object.keys(fragments).forEach(function(key) {
			var _selector$selectors$, _selector$selectors$2, _selector$owner$varia;
			var fragmentNode = fragments[key];
			var fragmentRef = props[key];
			var selector = getSelector(fragmentNode, fragmentRef);
			var fragmentOwnerVariables = selector != null && selector.kind === "PluralReaderSelector" ? (_selector$selectors$ = (_selector$selectors$2 = selector.selectors[0]) === null || _selector$selectors$2 === void 0 ? void 0 : _selector$selectors$2.owner.variables) !== null && _selector$selectors$ !== void 0 ? _selector$selectors$ : {} : (_selector$owner$varia = selector === null || selector === void 0 ? void 0 : selector.owner.variables) !== null && _selector$owner$varia !== void 0 ? _selector$owner$varia : {};
			rootVariables = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, rootVariables), fragmentOwnerVariables);
		});
		return rootVariables;
	}
	module.exports = getRootVariablesForFragments;
}));
var require_ReactRelayQueryFetcher = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var invariant = require_invariant();
	var _require = require_relay_runtime(), fetchQuery = _require.__internal.fetchQuery, createOperationDescriptor = _require.createOperationDescriptor, isRelayModernEnvironment = _require.isRelayModernEnvironment;
	module.exports = /* @__PURE__ */ function() {
		function ReactRelayQueryFetcher(args) {
			(0, _defineProperty2["default"])(this, "_selectionReferences", []);
			(0, _defineProperty2["default"])(this, "_didFetchFinish", false);
			if (args != null) {
				this._cacheSelectionReference = args.cacheSelectionReference;
				this._selectionReferences = args.selectionReferences;
			}
		}
		var _proto = ReactRelayQueryFetcher.prototype;
		_proto.getSelectionReferences = function getSelectionReferences() {
			return {
				cacheSelectionReference: this._cacheSelectionReference,
				selectionReferences: this._selectionReferences
			};
		};
		_proto.lookupInStore = function lookupInStore(environment, operation, fetchPolicy) {
			if (fetchPolicy === "store-and-network" || fetchPolicy === "store-or-network") {
				if (environment.check(operation).status === "available") {
					this._retainCachedOperation(environment, operation);
					return environment.lookup(operation.fragment);
				}
			}
			return null;
		};
		_proto.getFetchResult = function getFetchResult() {
			if (this._didFetchFinish) {
				if (this._error != null) return { error: this._error };
				else if (this._snapshot != null) return { snapshot: this._snapshot };
			} else return null;
		};
		_proto.execute = function execute(_ref) {
			var _this = this;
			var environment = _ref.environment, operation = _ref.operation, _ref$preservePrevious = _ref.preservePreviousReferences, preservePreviousReferences = _ref$preservePrevious === void 0 ? false : _ref$preservePrevious;
			var reference = environment.retain(operation);
			var error = function error() {
				_this._selectionReferences = _this._selectionReferences.concat(reference);
			};
			var complete = function complete() {
				if (!preservePreviousReferences) _this.disposeSelectionReferences();
				_this._selectionReferences = _this._selectionReferences.concat(reference);
			};
			var unsubscribe = function unsubscribe() {
				_this._selectionReferences = _this._selectionReferences.concat(reference);
			};
			if (!isRelayModernEnvironment(environment)) return environment.execute({ operation })["do"]({
				error,
				complete,
				unsubscribe
			});
			return fetchQuery(environment, operation)["do"]({
				error,
				complete,
				unsubscribe
			});
		};
		_proto.setOnDataChange = function setOnDataChange(onDataChange) {
			!this._fetchOptions && invariant(false);
			if (typeof onDataChange === "function") {
				this._fetchOptions.onDataChangeCallbacks = this._fetchOptions.onDataChangeCallbacks || [];
				this._fetchOptions.onDataChangeCallbacks.push(onDataChange);
				if (this._didFetchFinish) {
					if (this._error != null) onDataChange({ error: this._error });
					else if (this._snapshot != null) onDataChange({ snapshot: this._snapshot });
				}
			}
		};
		_proto.fetch = function fetch(fetchOptions, cacheConfigOverride) {
			var _this2 = this;
			var environment = fetchOptions.environment, operation = fetchOptions.operation, onDataChange = fetchOptions.onDataChange;
			var fetchHasReturned = false;
			var _error;
			this.disposeRequest();
			this._fetchOptions = {
				environment,
				onDataChangeCallbacks: this._fetchOptions && this._fetchOptions.onDataChangeCallbacks || [],
				operation
			};
			if (onDataChange && this._fetchOptions.onDataChangeCallbacks.indexOf(onDataChange) === -1) this._fetchOptions.onDataChangeCallbacks.push(onDataChange);
			var operationOverride = cacheConfigOverride ? createOperationDescriptor(operation.request.node, operation.request.variables, cacheConfigOverride) : operation;
			var request = this.execute({
				environment,
				operation: operationOverride
			})["finally"](function() {
				_this2._pendingRequest = null;
			}).subscribe({
				next: function next() {
					_this2._didFetchFinish = true;
					_this2._error = null;
					_this2._onQueryDataAvailable({ notifyFirstResult: fetchHasReturned });
				},
				error: function error(err) {
					_this2._didFetchFinish = true;
					_this2._error = err;
					_this2._snapshot = null;
					var onDataChangeCallbacks = _this2._fetchOptions && _this2._fetchOptions.onDataChangeCallbacks;
					if (fetchHasReturned) {
						if (onDataChangeCallbacks) onDataChangeCallbacks.forEach(function(onDataChange) {
							onDataChange({ error: err });
						});
					} else _error = err;
				}
			});
			this._pendingRequest = { dispose: function dispose() {
				request.unsubscribe();
			} };
			fetchHasReturned = true;
			if (_error) throw _error;
			return this._snapshot;
		};
		_proto.retry = function retry(cacheConfigOverride) {
			!this._fetchOptions && invariant(false);
			return this.fetch({
				environment: this._fetchOptions.environment,
				operation: this._fetchOptions.operation,
				onDataChange: null
			}, cacheConfigOverride);
		};
		_proto.dispose = function dispose() {
			this.disposeRequest();
			this.disposeSelectionReferences();
		};
		_proto.disposeRequest = function disposeRequest() {
			this._error = null;
			this._snapshot = null;
			if (this._pendingRequest) this._pendingRequest.dispose();
			if (this._rootSubscription) {
				this._rootSubscription.dispose();
				this._rootSubscription = null;
			}
		};
		_proto._retainCachedOperation = function _retainCachedOperation(environment, operation) {
			this._disposeCacheSelectionReference();
			this._cacheSelectionReference = environment.retain(operation);
		};
		_proto._disposeCacheSelectionReference = function _disposeCacheSelectionReference() {
			this._cacheSelectionReference && this._cacheSelectionReference.dispose();
			this._cacheSelectionReference = null;
		};
		_proto.disposeSelectionReferences = function disposeSelectionReferences() {
			this._disposeCacheSelectionReference();
			this._selectionReferences.forEach(function(r) {
				return r.dispose();
			});
			this._selectionReferences = [];
		};
		_proto._onQueryDataAvailable = function _onQueryDataAvailable(_ref2) {
			var _this3 = this;
			var notifyFirstResult = _ref2.notifyFirstResult;
			!this._fetchOptions && invariant(false);
			var _this$_fetchOptions = this._fetchOptions, environment = _this$_fetchOptions.environment, onDataChangeCallbacks = _this$_fetchOptions.onDataChangeCallbacks, operation = _this$_fetchOptions.operation;
			if (this._snapshot) return;
			this._snapshot = environment.lookup(operation.fragment);
			this._rootSubscription = environment.subscribe(this._snapshot, function(snapshot) {
				if (_this3._fetchOptions != null) {
					var maybeNewOnDataChangeCallbacks = _this3._fetchOptions.onDataChangeCallbacks;
					if (Array.isArray(maybeNewOnDataChangeCallbacks)) maybeNewOnDataChangeCallbacks.forEach(function(onDataChange) {
						return onDataChange({ snapshot });
					});
				}
			});
			if (this._snapshot && notifyFirstResult && Array.isArray(onDataChangeCallbacks)) {
				var snapshot = this._snapshot;
				onDataChangeCallbacks.forEach(function(onDataChange) {
					return onDataChange({ snapshot });
				});
			}
		};
		return ReactRelayQueryFetcher;
	}();
}));
var require_ReactRelayPaginationContainer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _extends2 = _interopRequireDefault(require_extends());
	var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require_objectWithoutPropertiesLoose());
	var _assertThisInitialized2 = _interopRequireDefault(require_assertThisInitialized());
	var _inheritsLoose2 = _interopRequireDefault(require_inheritsLoose());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _objectSpread3 = _interopRequireDefault(require_objectSpread2());
	var _excluded = ["componentRef"], _excluded2 = [
		"componentRef",
		"__relayContext",
		"__rootIsQueryRenderer"
	], _excluded3 = [
		"componentRef",
		"__relayContext",
		"__rootIsQueryRenderer"
	];
	var buildReactRelayContainer = require_buildReactRelayContainer();
	var getRootVariablesForFragments = require_getRootVariablesForFragments();
	var _require = require_ReactRelayContainerUtils(), getComponentName = _require.getComponentName, getContainerName = _require.getContainerName;
	var ReactRelayContext = require_ReactRelayContext();
	var ReactRelayQueryFetcher = require_ReactRelayQueryFetcher();
	var assertRelayContext = require_RelayContext().assertRelayContext;
	var areEqual = require_areEqual();
	var invariant = require_invariant();
	var React$9 = __require("react");
	var _require3 = require_relay_runtime(), ConnectionInterface = _require3.ConnectionInterface, Observable = _require3.Observable, RelayFeatureFlags = _require3.RelayFeatureFlags, createFragmentSpecResolver = _require3.createFragmentSpecResolver, createOperationDescriptor = _require3.createOperationDescriptor, getDataIDsFromObject = _require3.getDataIDsFromObject, getRequest = _require3.getRequest, getVariablesFromObject = _require3.getVariablesFromObject, isScalarAndEqual = _require3.isScalarAndEqual;
	require_warning();
	var FORWARD = "forward";
	function createGetConnectionFromProps(metadata) {
		var path = metadata.path;
		!path && invariant(false);
		return function(props) {
			var data = props[metadata.fragmentName];
			for (var i = 0; i < path.length; i++) {
				if (!data || typeof data !== "object") return null;
				data = data[path[i]];
			}
			return data;
		};
	}
	function createGetFragmentVariables(metadata) {
		var countVariable = metadata.count;
		!countVariable && invariant(false);
		return function(prevVars, totalCount) {
			return (0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, prevVars), {}, (0, _defineProperty2["default"])({}, countVariable, totalCount));
		};
	}
	function findConnectionMetadata(fragments) {
		var foundConnectionMetadata = null;
		var isRelayModern = false;
		for (var fragmentName in fragments) {
			var fragment = fragments[fragmentName];
			var connectionMetadata = fragment.metadata && fragment.metadata.connection;
			if (fragment.metadata !== void 0) isRelayModern = true;
			if (connectionMetadata) {
				!(connectionMetadata.length === 1) && invariant(false);
				foundConnectionMetadata && invariant(false);
				foundConnectionMetadata = (0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, connectionMetadata[0]), {}, { fragmentName });
			}
		}
		!(!isRelayModern || foundConnectionMetadata !== null) && invariant(false);
		return foundConnectionMetadata || {};
	}
	function toObserver(observerOrCallback) {
		return typeof observerOrCallback === "function" ? {
			error: observerOrCallback,
			complete: observerOrCallback,
			unsubscribe: function unsubscribe(subscription) {
				typeof observerOrCallback === "function" && observerOrCallback();
			}
		} : observerOrCallback || {};
	}
	function createContainerWithFragments(Component, fragments, connectionConfig) {
		var _class;
		getComponentName(Component);
		var containerName = getContainerName(Component);
		var metadata = findConnectionMetadata(fragments);
		var getConnectionFromProps = connectionConfig.getConnectionFromProps || createGetConnectionFromProps(metadata);
		var direction = connectionConfig.direction || metadata.direction;
		!direction && invariant(false);
		var getFragmentVariables = connectionConfig.getFragmentVariables || createGetFragmentVariables(metadata);
		return _class = /* @__PURE__ */ function(_React$Component) {
			(0, _inheritsLoose2["default"])(_class, _React$Component);
			function _class(props) {
				var _props$__rootIsQueryR, _this = _React$Component.call(this, props) || this;
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_handleFragmentDataUpdate", function() {
					_this.setState({ data: _this._resolver.resolve() });
				});
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_hasMore", function() {
					var connectionData = _this._getConnectionData();
					return !!(connectionData && connectionData.hasMore && connectionData.cursor);
				});
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_isLoading", function() {
					return !!_this._refetchSubscription;
				});
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_refetchConnection", function(totalCount, observerOrCallback, refetchVariables) {
					if (!_this._canFetchPage("refetchConnection")) return { dispose: function dispose() {} };
					_this._refetchVariables = refetchVariables;
					var paginatingVariables = {
						count: totalCount,
						cursor: null,
						totalCount
					};
					return { dispose: _this._fetchPage(paginatingVariables, toObserver(observerOrCallback), { force: true }).unsubscribe };
				});
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_loadMore", function(pageSize, observerOrCallback, options) {
					if (!_this._canFetchPage("loadMore")) return { dispose: function dispose() {} };
					var observer = toObserver(observerOrCallback);
					var connectionData = _this._getConnectionData();
					if (!connectionData) {
						Observable.create(function(sink) {
							return sink.complete();
						}).subscribe(observer);
						return null;
					}
					var totalCount = connectionData.edgeCount + pageSize;
					if (options && options.force) return _this._refetchConnection(totalCount, observerOrCallback);
					var _ConnectionInterface$ = ConnectionInterface.get();
					_ConnectionInterface$.END_CURSOR;
					_ConnectionInterface$.START_CURSOR;
					var paginatingVariables = {
						count: pageSize,
						cursor: connectionData.cursor,
						totalCount
					};
					return { dispose: _this._fetchPage(paginatingVariables, observer, options).unsubscribe };
				});
				var relayContext = assertRelayContext(props.__relayContext);
				var rootIsQueryRenderer = (_props$__rootIsQueryR = props.__rootIsQueryRenderer) !== null && _props$__rootIsQueryR !== void 0 ? _props$__rootIsQueryR : false;
				_this._isARequestInFlight = false;
				_this._refetchSubscription = null;
				_this._refetchVariables = null;
				if (RelayFeatureFlags.ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT === true) _this._resolver = createFragmentSpecResolver(relayContext, containerName, fragments, props, rootIsQueryRenderer);
				else _this._resolver = createFragmentSpecResolver(relayContext, containerName, fragments, props, rootIsQueryRenderer, _this._handleFragmentDataUpdate);
				_this.state = {
					data: _this._resolver.resolve(),
					prevContext: relayContext,
					contextForChildren: relayContext,
					relayProp: _this._buildRelayProp(relayContext),
					resolverGeneration: 0
				};
				_this._isUnmounted = false;
				_this._hasFetched = false;
				return _this;
			}
			var _proto = _class.prototype;
			_proto.componentDidMount = function componentDidMount() {
				this._isUnmounted = false;
				if (RelayFeatureFlags.ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT === true) this._subscribeToNewResolverAndRerenderIfStoreHasChanged();
			};
			_proto.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
				if (RelayFeatureFlags.ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT === true) if (prevState.resolverGeneration !== this.state.resolverGeneration) this._subscribeToNewResolverAndRerenderIfStoreHasChanged();
				else this._rerenderIfStoreHasChanged();
			};
			_proto.UNSAFE_componentWillReceiveProps = function UNSAFE_componentWillReceiveProps(nextProps) {
				var _this2 = this;
				var _nextProps$__rootIsQu;
				var relayContext = assertRelayContext(nextProps.__relayContext);
				var rootIsQueryRenderer = (_nextProps$__rootIsQu = nextProps.__rootIsQueryRenderer) !== null && _nextProps$__rootIsQu !== void 0 ? _nextProps$__rootIsQu : false;
				var prevIDs = getDataIDsFromObject(fragments, this.props);
				var nextIDs = getDataIDsFromObject(fragments, nextProps);
				var prevRootVariables = getRootVariablesForFragments(fragments, this.props);
				var nextRootVariables = getRootVariablesForFragments(fragments, nextProps);
				if (relayContext.environment !== this.state.prevContext.environment || !areEqual(prevRootVariables, nextRootVariables) || !areEqual(prevIDs, nextIDs)) {
					this._cleanup();
					if (RelayFeatureFlags.ENABLE_CONTAINERS_SUBSCRIBE_ON_COMMIT === true) this._resolver = createFragmentSpecResolver(relayContext, containerName, fragments, nextProps, rootIsQueryRenderer);
					else this._resolver = createFragmentSpecResolver(relayContext, containerName, fragments, nextProps, rootIsQueryRenderer, this._handleFragmentDataUpdate);
					this.setState(function(prevState) {
						return {
							prevContext: relayContext,
							contextForChildren: relayContext,
							relayProp: _this2._buildRelayProp(relayContext),
							resolverGeneration: prevState.resolverGeneration + 1
						};
					});
				} else if (!this._hasFetched) this._resolver.setProps(nextProps);
				var data = this._resolver.resolve();
				if (data !== this.state.data) this.setState({ data });
			};
			_proto.componentWillUnmount = function componentWillUnmount() {
				this._isUnmounted = true;
				this._cleanup();
			};
			_proto.shouldComponentUpdate = function shouldComponentUpdate(nextProps, nextState) {
				if (nextState.data !== this.state.data || nextState.relayProp !== this.state.relayProp || nextState.resolverGeneration !== this.state.resolverGeneration) return true;
				var keys = Object.keys(nextProps);
				for (var ii = 0; ii < keys.length; ii++) {
					var key = keys[ii];
					if (key === "__relayContext") {
						if (nextState.prevContext.environment !== this.state.prevContext.environment) return true;
					} else if (!fragments.hasOwnProperty(key) && !isScalarAndEqual(nextProps[key], this.props[key])) return true;
				}
				return false;
			};
			_proto._buildRelayProp = function _buildRelayProp(relayContext) {
				return {
					hasMore: this._hasMore,
					isLoading: this._isLoading,
					loadMore: this._loadMore,
					refetchConnection: this._refetchConnection,
					environment: relayContext.environment
				};
			};
			_proto._rerenderIfStoreHasChanged = function _rerenderIfStoreHasChanged() {
				var data = this.state.data;
				var maybeNewData = this._resolver.resolve();
				if (data !== maybeNewData) this.setState({ data: maybeNewData });
			};
			_proto._subscribeToNewResolverAndRerenderIfStoreHasChanged = function _subscribeToNewResolverAndRerenderIfStoreHasChanged() {
				var data = this.state.data;
				var maybeNewData = this._resolver.resolve();
				this._resolver.setCallback(this.props, this._handleFragmentDataUpdate);
				if (data !== maybeNewData) this.setState({ data: maybeNewData });
			};
			_proto._getConnectionData = function _getConnectionData() {
				var _this$props = this.props;
				_this$props.componentRef;
				var restProps = (0, _objectWithoutPropertiesLoose2["default"])(_this$props, _excluded);
				var connectionData = getConnectionFromProps((0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, restProps), this.state.data));
				if (connectionData == null) return null;
				var _ConnectionInterface$2 = ConnectionInterface.get(), EDGES = _ConnectionInterface$2.EDGES, PAGE_INFO = _ConnectionInterface$2.PAGE_INFO, HAS_NEXT_PAGE = _ConnectionInterface$2.HAS_NEXT_PAGE, HAS_PREV_PAGE = _ConnectionInterface$2.HAS_PREV_PAGE, END_CURSOR = _ConnectionInterface$2.END_CURSOR, START_CURSOR = _ConnectionInterface$2.START_CURSOR;
				!(typeof connectionData === "object") && invariant(false);
				var edges = connectionData[EDGES];
				var pageInfo = connectionData[PAGE_INFO];
				if (edges == null || pageInfo == null) return null;
				!Array.isArray(edges) && invariant(false);
				!(typeof pageInfo === "object") && invariant(false);
				var hasMore = direction === FORWARD ? pageInfo[HAS_NEXT_PAGE] : pageInfo[HAS_PREV_PAGE];
				var cursor = direction === FORWARD ? pageInfo[END_CURSOR] : pageInfo[START_CURSOR];
				if (typeof hasMore !== "boolean" || edges.length !== 0 && typeof cursor === "undefined") return null;
				return {
					cursor,
					edgeCount: edges.length,
					hasMore
				};
			};
			_proto._getQueryFetcher = function _getQueryFetcher() {
				if (!this._queryFetcher) this._queryFetcher = new ReactRelayQueryFetcher();
				return this._queryFetcher;
			};
			_proto._canFetchPage = function _canFetchPage(method) {
				if (this._isUnmounted) return false;
				return true;
			};
			_proto._fetchPage = function _fetchPage(paginatingVariables, observer, options) {
				var _this3 = this;
				var environment = assertRelayContext(this.props.__relayContext).environment, _this$props2 = this.props;
				_this$props2.componentRef;
				_this$props2.__relayContext;
				_this$props2.__rootIsQueryRenderer;
				var restProps = (0, _objectWithoutPropertiesLoose2["default"])(_this$props2, _excluded2);
				var props = (0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, restProps), this.state.data);
				var fragmentVariables;
				var rootVariables = getRootVariablesForFragments(fragments, restProps);
				fragmentVariables = getVariablesFromObject(fragments, restProps);
				fragmentVariables = (0, _objectSpread3["default"])((0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, rootVariables), fragmentVariables), this._refetchVariables);
				var fetchVariables = connectionConfig.getVariables(props, {
					count: paginatingVariables.count,
					cursor: paginatingVariables.cursor
				}, fragmentVariables);
				!(typeof fetchVariables === "object" && fetchVariables !== null) && invariant(false);
				fetchVariables = (0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, fetchVariables), this._refetchVariables);
				fragmentVariables = (0, _objectSpread3["default"])((0, _objectSpread3["default"])({}, fetchVariables), fragmentVariables);
				var cacheConfig = options ? { force: !!options.force } : void 0;
				if (cacheConfig != null && (options === null || options === void 0 ? void 0 : options.metadata) != null) cacheConfig.metadata = options === null || options === void 0 ? void 0 : options.metadata;
				var operation = createOperationDescriptor(getRequest(connectionConfig.query), fetchVariables, cacheConfig);
				var refetchSubscription = null;
				if (this._refetchSubscription) this._refetchSubscription.unsubscribe();
				this._hasFetched = true;
				var onNext = function onNext(payload, complete) {
					var prevData = _this3._resolver.resolve();
					_this3._resolver.setVariables(getFragmentVariables(fragmentVariables, paginatingVariables.totalCount), operation.request.node);
					var nextData = _this3._resolver.resolve();
					if (!areEqual(prevData, nextData)) _this3.setState({
						data: nextData,
						contextForChildren: { environment: _this3.props.__relayContext.environment }
					}, complete);
					else complete();
				};
				var cleanup = function cleanup() {
					if (_this3._refetchSubscription === refetchSubscription) {
						_this3._refetchSubscription = null;
						_this3._isARequestInFlight = false;
					}
				};
				this._isARequestInFlight = true;
				refetchSubscription = this._getQueryFetcher().execute({
					environment,
					operation,
					preservePreviousReferences: true
				}).mergeMap(function(payload) {
					return Observable.create(function(sink) {
						onNext(payload, function() {
							sink.next();
							sink.complete();
						});
					});
				})["do"]({
					error: cleanup,
					complete: cleanup,
					unsubscribe: cleanup
				}).subscribe(observer || {});
				this._refetchSubscription = this._isARequestInFlight ? refetchSubscription : null;
				return refetchSubscription;
			};
			_proto._cleanup = function _cleanup() {
				this._resolver.dispose();
				this._refetchVariables = null;
				this._hasFetched = false;
				if (this._refetchSubscription) {
					this._refetchSubscription.unsubscribe();
					this._refetchSubscription = null;
					this._isARequestInFlight = false;
				}
				if (this._queryFetcher) this._queryFetcher.dispose();
			};
			_proto.render = function render() {
				var _this$props3 = this.props, componentRef = _this$props3.componentRef;
				_this$props3.__relayContext;
				_this$props3.__rootIsQueryRenderer;
				var props = (0, _objectWithoutPropertiesLoose2["default"])(_this$props3, _excluded3);
				return /* @__PURE__ */ React$9.createElement(ReactRelayContext.Provider, { value: this.state.contextForChildren }, /* @__PURE__ */ React$9.createElement(Component, (0, _extends2["default"])({}, props, this.state.data, {
					ref: componentRef,
					relay: this.state.relayProp
				})));
			};
			return _class;
		}(React$9.Component), (0, _defineProperty2["default"])(_class, "displayName", containerName), _class;
	}
	function createContainer(Component, fragmentSpec, connectionConfig) {
		return buildReactRelayContainer(Component, fragmentSpec, function(ComponentClass, fragments) {
			return createContainerWithFragments(ComponentClass, fragments, connectionConfig);
		});
	}
	module.exports = { createContainer };
}));
var require_ReactRelayQueryRenderer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _assertThisInitialized2 = _interopRequireDefault(require_assertThisInitialized());
	var _inheritsLoose2 = _interopRequireDefault(require_inheritsLoose());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var ReactRelayContext = require_ReactRelayContext();
	var ReactRelayQueryFetcher = require_ReactRelayQueryFetcher();
	var ReactRelayQueryRendererContext = require_ReactRelayQueryRendererContext();
	var areEqual = require_areEqual();
	var React$8 = __require("react"), _require$9 = require_relay_runtime(), createOperationDescriptor = _require$9.createOperationDescriptor;
	_require$9.deepFreeze;
	var getRequest = _require$9.getRequest;
	var requestCache = {};
	var queryRendererContext = { rootIsQueryRenderer: true };
	var ReactRelayQueryRenderer = /* @__PURE__ */ function(_React$Component) {
		(0, _inheritsLoose2["default"])(ReactRelayQueryRenderer, _React$Component);
		function ReactRelayQueryRenderer(props) {
			var _this = _React$Component.call(this, props) || this;
			(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_handleDataChange", function(params) {
				var error = params.error == null ? null : params.error;
				var snapshot = params.snapshot == null ? null : params.snapshot;
				_this.setState(function(prevState) {
					var prevRequestCacheKey = prevState.requestCacheKey;
					if (prevRequestCacheKey) delete requestCache[prevRequestCacheKey];
					if (snapshot === prevState.snapshot && error === prevState.error) return null;
					return {
						renderProps: getRenderProps(error, snapshot, prevState.queryFetcher, prevState.retryCallbacks),
						snapshot,
						requestCacheKey: null
					};
				});
			});
			var retryCallbacks = {
				handleDataChange: null,
				handleRetryAfterError: null
			};
			var queryFetcher;
			var requestCacheKey;
			if (props.query) {
				var query = props.query;
				requestCacheKey = getRequestCacheKey(getRequest(query).params, props.variables);
				queryFetcher = requestCache[requestCacheKey] ? requestCache[requestCacheKey].queryFetcher : new ReactRelayQueryFetcher();
			} else queryFetcher = new ReactRelayQueryFetcher();
			_this._maybeHiddenOrFastRefresh = false;
			_this.state = (0, _objectSpread2["default"])({
				prevPropsEnvironment: props.environment,
				prevPropsVariables: props.variables,
				prevQuery: props.query,
				queryFetcher,
				retryCallbacks
			}, fetchQueryAndComputeStateFromProps(props, queryFetcher, retryCallbacks, requestCacheKey));
			return _this;
		}
		ReactRelayQueryRenderer.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
			if (prevState.prevQuery !== nextProps.query || prevState.prevPropsEnvironment !== nextProps.environment || !areEqual(prevState.prevPropsVariables, nextProps.variables)) return resetQueryStateForUpdate(nextProps, prevState);
			return null;
		};
		var _proto = ReactRelayQueryRenderer.prototype;
		_proto.componentDidMount = function componentDidMount() {
			var _this2 = this;
			if (this._maybeHiddenOrFastRefresh === true) {
				this._maybeHiddenOrFastRefresh = false;
				this.setState(function(prevState) {
					var newState = resetQueryStateForUpdate(_this2.props, prevState);
					var requestCacheKey = newState.requestCacheKey, queryFetcher = newState.queryFetcher;
					if (requestCacheKey != null && requestCache[requestCacheKey] != null) queryFetcher.setOnDataChange(_this2._handleDataChange);
					return newState;
				});
				return;
			}
			var _this$state = this.state, retryCallbacks = _this$state.retryCallbacks, queryFetcher = _this$state.queryFetcher, requestCacheKey = _this$state.requestCacheKey;
			if (requestCacheKey) delete requestCache[requestCacheKey];
			retryCallbacks.handleDataChange = this._handleDataChange;
			retryCallbacks.handleRetryAfterError = function(error) {
				return _this2.setState(function(prevState) {
					var prevRequestCacheKey = prevState.requestCacheKey;
					if (prevRequestCacheKey) delete requestCache[prevRequestCacheKey];
					return {
						renderProps: getLoadingRenderProps(),
						requestCacheKey: null
					};
				});
			};
			if (this.props.query) queryFetcher.setOnDataChange(this._handleDataChange);
		};
		_proto.componentDidUpdate = function componentDidUpdate(_prevProps, prevState) {
			var _this$state2 = this.state, queryFetcher = _this$state2.queryFetcher, requestCacheKey = _this$state2.requestCacheKey;
			if (requestCacheKey) {
				delete requestCache[requestCacheKey];
				delete this.state.requestCacheKey;
			}
			if (this.props.query && queryFetcher !== prevState.queryFetcher) queryFetcher.setOnDataChange(this._handleDataChange);
		};
		_proto.componentWillUnmount = function componentWillUnmount() {
			this.state.queryFetcher.dispose();
			this._maybeHiddenOrFastRefresh = true;
		};
		_proto.shouldComponentUpdate = function shouldComponentUpdate(nextProps, nextState) {
			return nextProps.render !== this.props.render || nextState.renderProps !== this.state.renderProps;
		};
		_proto.render = function render() {
			var _this$state3 = this.state, renderProps = _this$state3.renderProps, relayContext = _this$state3.relayContext;
			return /* @__PURE__ */ React$8.createElement(ReactRelayContext.Provider, { value: relayContext }, /* @__PURE__ */ React$8.createElement(ReactRelayQueryRendererContext.Provider, { value: queryRendererContext }, this.props.render(renderProps)));
		};
		return ReactRelayQueryRenderer;
	}(React$8.Component);
	function getLoadingRenderProps() {
		return {
			error: null,
			props: null,
			retry: null
		};
	}
	function getEmptyRenderProps() {
		return {
			error: null,
			props: {},
			retry: null
		};
	}
	function getRenderProps(error, snapshot, queryFetcher, retryCallbacks) {
		return {
			error: error ? error : null,
			props: snapshot ? snapshot.data : null,
			retry: function retry(cacheConfigOverride) {
				var syncSnapshot = queryFetcher.retry(cacheConfigOverride);
				if (syncSnapshot && typeof retryCallbacks.handleDataChange === "function") retryCallbacks.handleDataChange({ snapshot: syncSnapshot });
				else if (error && typeof retryCallbacks.handleRetryAfterError === "function") retryCallbacks.handleRetryAfterError(error);
			}
		};
	}
	function getRequestCacheKey(request, variables) {
		return JSON.stringify({
			id: request.cacheID ? request.cacheID : request.id,
			variables
		});
	}
	function resetQueryStateForUpdate(props, prevState) {
		var query = props.query;
		var prevSelectionReferences = prevState.queryFetcher.getSelectionReferences();
		prevState.queryFetcher.disposeRequest();
		var queryFetcher;
		if (query) {
			var requestCacheKey = getRequestCacheKey(getRequest(query).params, props.variables);
			queryFetcher = requestCache[requestCacheKey] ? requestCache[requestCacheKey].queryFetcher : new ReactRelayQueryFetcher(prevSelectionReferences);
		} else queryFetcher = new ReactRelayQueryFetcher(prevSelectionReferences);
		return (0, _objectSpread2["default"])({
			prevQuery: props.query,
			prevPropsEnvironment: props.environment,
			prevPropsVariables: props.variables,
			queryFetcher
		}, fetchQueryAndComputeStateFromProps(props, queryFetcher, prevState.retryCallbacks));
	}
	function fetchQueryAndComputeStateFromProps(props, queryFetcher, retryCallbacks, requestCacheKey) {
		var environment = props.environment, query = props.query, variables = props.variables, cacheConfig = props.cacheConfig;
		var genericEnvironment = environment;
		if (query) {
			var request = getRequest(query);
			var operation = createOperationDescriptor(request, variables, cacheConfig);
			var relayContext = { environment: genericEnvironment };
			if (typeof requestCacheKey === "string" && requestCache[requestCacheKey]) {
				var snapshot = requestCache[requestCacheKey].snapshot;
				if (snapshot) return {
					error: null,
					relayContext,
					renderProps: getRenderProps(null, snapshot, queryFetcher, retryCallbacks),
					snapshot,
					requestCacheKey
				};
				else return {
					error: null,
					relayContext,
					renderProps: getLoadingRenderProps(),
					snapshot: null,
					requestCacheKey
				};
			}
			try {
				var storeSnapshot = queryFetcher.lookupInStore(genericEnvironment, operation, props.fetchPolicy);
				var _snapshot = queryFetcher.fetch({
					environment: genericEnvironment,
					onDataChange: null,
					operation
				}) || storeSnapshot;
				requestCacheKey = requestCacheKey || getRequestCacheKey(request.params, props.variables);
				requestCache[requestCacheKey] = {
					queryFetcher,
					snapshot: _snapshot
				};
				if (!_snapshot) return {
					error: null,
					relayContext,
					renderProps: getLoadingRenderProps(),
					snapshot: null,
					requestCacheKey
				};
				return {
					error: null,
					relayContext,
					renderProps: getRenderProps(null, _snapshot, queryFetcher, retryCallbacks),
					snapshot: _snapshot,
					requestCacheKey
				};
			} catch (error) {
				return {
					error,
					relayContext,
					renderProps: getRenderProps(error, null, queryFetcher, retryCallbacks),
					snapshot: null,
					requestCacheKey
				};
			}
		} else {
			queryFetcher.dispose();
			return {
				error: null,
				relayContext: { environment: genericEnvironment },
				renderProps: getEmptyRenderProps(),
				requestCacheKey: null
			};
		}
	}
	module.exports = ReactRelayQueryRenderer;
}));
var require_ReactRelayRefetchContainer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _extends2 = _interopRequireDefault(require_extends());
	var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require_objectWithoutPropertiesLoose());
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _assertThisInitialized2 = _interopRequireDefault(require_assertThisInitialized());
	var _inheritsLoose2 = _interopRequireDefault(require_inheritsLoose());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var _excluded = [
		"componentRef",
		"__relayContext",
		"__rootIsQueryRenderer"
	];
	var buildReactRelayContainer = require_buildReactRelayContainer();
	var getRootVariablesForFragments = require_getRootVariablesForFragments();
	var getContainerName = require_ReactRelayContainerUtils().getContainerName;
	var ReactRelayContext = require_ReactRelayContext();
	var ReactRelayQueryFetcher = require_ReactRelayQueryFetcher();
	var assertRelayContext = require_RelayContext().assertRelayContext;
	var areEqual = require_areEqual();
	var React$7 = __require("react");
	var _require3 = require_relay_runtime(), Observable = _require3.Observable, createFragmentSpecResolver = _require3.createFragmentSpecResolver, createOperationDescriptor = _require3.createOperationDescriptor, getDataIDsFromObject = _require3.getDataIDsFromObject, getRequest = _require3.getRequest, getVariablesFromObject = _require3.getVariablesFromObject, isScalarAndEqual = _require3.isScalarAndEqual;
	require_warning();
	function createContainerWithFragments(Component, fragments, taggedNode) {
		var _class;
		var containerName = getContainerName(Component);
		return _class = /* @__PURE__ */ function(_React$Component) {
			(0, _inheritsLoose2["default"])(_class, _React$Component);
			function _class(props) {
				var _props$__rootIsQueryR, _this = _React$Component.call(this, props) || this;
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_handleFragmentDataUpdate", function() {
					var resolverFromThisUpdate = _this.state.resolver;
					_this.setState(function(updatedState) {
						return resolverFromThisUpdate === updatedState.resolver ? { data: updatedState.resolver.resolve() } : null;
					});
				});
				(0, _defineProperty2["default"])((0, _assertThisInitialized2["default"])(_this), "_refetch", function(refetchVariables, renderVariables, observerOrCallback, options) {
					if (_this._isUnmounted) return { dispose: function dispose() {} };
					var environment = assertRelayContext(_this.props.__relayContext).environment;
					var rootVariables = getRootVariablesForFragments(fragments, _this.props);
					var fetchVariables = typeof refetchVariables === "function" ? refetchVariables(_this._getFragmentVariables()) : refetchVariables;
					fetchVariables = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, rootVariables), fetchVariables);
					var fragmentVariables = renderVariables ? (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, fetchVariables), renderVariables) : fetchVariables;
					var cacheConfig = options ? { force: !!options.force } : void 0;
					if (cacheConfig != null && (options === null || options === void 0 ? void 0 : options.metadata) != null) cacheConfig.metadata = options === null || options === void 0 ? void 0 : options.metadata;
					var observer = typeof observerOrCallback === "function" ? {
						next: observerOrCallback,
						error: observerOrCallback
					} : observerOrCallback || {};
					var operation = createOperationDescriptor(getRequest(taggedNode), fetchVariables, cacheConfig);
					_this.state.localVariables = fetchVariables;
					_this._refetchSubscription && _this._refetchSubscription.unsubscribe();
					var refetchSubscription;
					if (_this._getQueryFetcher().lookupInStore(environment, operation, options === null || options === void 0 ? void 0 : options.fetchPolicy) != null) {
						_this.state.resolver.setVariables(fragmentVariables, operation.request.node);
						_this.setState(function(latestState) {
							return {
								data: latestState.resolver.resolve(),
								contextForChildren: { environment: _this.props.__relayContext.environment }
							};
						}, function() {
							observer.next && observer.next();
							observer.complete && observer.complete();
						});
						return { dispose: function dispose() {} };
					}
					_this._getQueryFetcher().execute({
						environment,
						operation,
						preservePreviousReferences: true
					}).mergeMap(function(response) {
						_this.state.resolver.setVariables(fragmentVariables, operation.request.node);
						return Observable.create(function(sink) {
							return _this.setState(function(latestState) {
								return {
									data: latestState.resolver.resolve(),
									contextForChildren: { environment: _this.props.__relayContext.environment }
								};
							}, function() {
								sink.next();
								sink.complete();
							});
						});
					})["finally"](function() {
						if (_this._refetchSubscription === refetchSubscription) _this._refetchSubscription = null;
					}).subscribe((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, observer), {}, { start: function start(subscription) {
						_this._refetchSubscription = refetchSubscription = subscription;
						observer.start && observer.start(subscription);
					} }));
					return { dispose: function dispose() {
						refetchSubscription && refetchSubscription.unsubscribe();
					} };
				});
				var relayContext = assertRelayContext(props.__relayContext);
				var rootIsQueryRenderer = (_props$__rootIsQueryR = props.__rootIsQueryRenderer) !== null && _props$__rootIsQueryR !== void 0 ? _props$__rootIsQueryR : false;
				_this._refetchSubscription = null;
				var resolver = createFragmentSpecResolver(relayContext, containerName, fragments, props, rootIsQueryRenderer);
				_this.state = {
					data: resolver.resolve(),
					localVariables: null,
					prevProps: props,
					prevPropsContext: relayContext,
					contextForChildren: relayContext,
					relayProp: getRelayProp(relayContext.environment, _this._refetch),
					resolver
				};
				_this._isUnmounted = false;
				return _this;
			}
			var _proto = _class.prototype;
			_proto.componentDidMount = function componentDidMount() {
				this._isUnmounted = false;
				this._subscribeToNewResolverAndRerenderIfStoreHasChanged();
			};
			_proto.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
				if (this.state.resolver !== prevState.resolver) {
					prevState.resolver.dispose();
					this._queryFetcher && this._queryFetcher.dispose();
					this._refetchSubscription && this._refetchSubscription.unsubscribe();
					this._subscribeToNewResolverAndRerenderIfStoreHasChanged();
				} else this._rerenderIfStoreHasChanged();
			};
			_class.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
				var _nextProps$__rootIsQu;
				var prevProps = prevState.prevProps;
				var relayContext = assertRelayContext(nextProps.__relayContext);
				var rootIsQueryRenderer = (_nextProps$__rootIsQu = nextProps.__rootIsQueryRenderer) !== null && _nextProps$__rootIsQu !== void 0 ? _nextProps$__rootIsQu : false;
				var prevIDs = getDataIDsFromObject(fragments, prevProps);
				var nextIDs = getDataIDsFromObject(fragments, nextProps);
				var prevRootVariables = getRootVariablesForFragments(fragments, prevProps);
				var nextRootVariables = getRootVariablesForFragments(fragments, nextProps);
				var resolver = prevState.resolver;
				if (prevState.prevPropsContext.environment !== relayContext.environment || !areEqual(prevRootVariables, nextRootVariables) || !areEqual(prevIDs, nextIDs)) {
					resolver = createFragmentSpecResolver(relayContext, containerName, fragments, nextProps, rootIsQueryRenderer);
					return {
						data: resolver.resolve(),
						localVariables: null,
						prevProps: nextProps,
						prevPropsContext: relayContext,
						contextForChildren: relayContext,
						relayProp: getRelayProp(relayContext.environment, prevState.relayProp.refetch),
						resolver
					};
				} else if (!prevState.localVariables) resolver.setProps(nextProps);
				var data = resolver.resolve();
				if (data !== prevState.data) return {
					data,
					prevProps: nextProps
				};
				return null;
			};
			_proto.componentWillUnmount = function componentWillUnmount() {
				this._isUnmounted = true;
				this.state.resolver.dispose();
				this._queryFetcher && this._queryFetcher.dispose();
				this._refetchSubscription && this._refetchSubscription.unsubscribe();
			};
			_proto.shouldComponentUpdate = function shouldComponentUpdate(nextProps, nextState) {
				if (nextState.data !== this.state.data || nextState.relayProp !== this.state.relayProp) return true;
				var keys = Object.keys(nextProps);
				for (var ii = 0; ii < keys.length; ii++) {
					var key = keys[ii];
					if (key === "__relayContext") {
						if (this.state.prevPropsContext.environment !== nextState.prevPropsContext.environment) return true;
					} else if (!fragments.hasOwnProperty(key) && !isScalarAndEqual(nextProps[key], this.props[key])) return true;
				}
				return false;
			};
			_proto._rerenderIfStoreHasChanged = function _rerenderIfStoreHasChanged() {
				var _this$state = this.state, data = _this$state.data;
				var maybeNewData = _this$state.resolver.resolve();
				if (data !== maybeNewData) this.setState({ data: maybeNewData });
			};
			_proto._subscribeToNewResolverAndRerenderIfStoreHasChanged = function _subscribeToNewResolverAndRerenderIfStoreHasChanged() {
				var _this$state2 = this.state, data = _this$state2.data, resolver = _this$state2.resolver;
				var maybeNewData = resolver.resolve();
				resolver.setCallback(this.props, this._handleFragmentDataUpdate);
				if (data !== maybeNewData) this.setState({ data: maybeNewData });
			};
			_proto._getFragmentVariables = function _getFragmentVariables() {
				return getVariablesFromObject(fragments, this.props);
			};
			_proto._getQueryFetcher = function _getQueryFetcher() {
				if (!this._queryFetcher) this._queryFetcher = new ReactRelayQueryFetcher();
				return this._queryFetcher;
			};
			_proto.render = function render() {
				var _this$props = this.props, componentRef = _this$props.componentRef;
				_this$props.__relayContext;
				_this$props.__rootIsQueryRenderer;
				var props = (0, _objectWithoutPropertiesLoose2["default"])(_this$props, _excluded);
				var _this$state3 = this.state, relayProp = _this$state3.relayProp, contextForChildren = _this$state3.contextForChildren;
				return /* @__PURE__ */ React$7.createElement(ReactRelayContext.Provider, { value: contextForChildren }, /* @__PURE__ */ React$7.createElement(Component, (0, _extends2["default"])({}, props, this.state.data, {
					ref: componentRef,
					relay: relayProp
				})));
			};
			return _class;
		}(React$7.Component), (0, _defineProperty2["default"])(_class, "displayName", containerName), _class;
	}
	function getRelayProp(environment, refetch) {
		return {
			environment,
			refetch
		};
	}
	function createContainer(Component, fragmentSpec, taggedNode) {
		return buildReactRelayContainer(Component, fragmentSpec, function(ComponentClass, fragments) {
			return createContainerWithFragments(ComponentClass, fragments, taggedNode);
		});
	}
	module.exports = { createContainer };
}));
var require_ProfilerContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = __require("react").createContext({ wrapPrepareQueryResource: function wrapPrepareQueryResource(cb) {
		return cb();
	} });
}));
var require_useRelayEnvironment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactRelayContext = require_ReactRelayContext();
	var invariant = require_invariant();
	var useContext$3 = __require("react").useContext;
	function useRelayEnvironment() {
		var context = useContext$3(ReactRelayContext);
		!(context != null) && invariant(false);
		return context.environment;
	}
	module.exports = useRelayEnvironment;
}));
var require_EntryPointContainer_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ProfilerContext = require_ProfilerContext();
	var useRelayEnvironment = require_useRelayEnvironment();
	var React$6 = __require("react");
	var _require$8 = __require("react"), useContext$2 = _require$8.useContext, useEffect$8 = _require$8.useEffect;
	require_warning();
	function EntryPointContainer(_ref) {
		var entryPointReference = _ref.entryPointReference, props = _ref.props;
		var getComponent = entryPointReference.getComponent, queries = entryPointReference.queries, entryPoints = entryPointReference.entryPoints, extraProps = entryPointReference.extraProps, rootModuleID = entryPointReference.rootModuleID;
		var Component = getComponent();
		var profilerContext = useContext$2(ProfilerContext);
		var environment = useRelayEnvironment();
		useEffect$8(function() {
			environment.__log({
				name: "entrypoint.root.consume",
				profilerContext,
				rootModuleID
			});
		}, [
			environment,
			profilerContext,
			rootModuleID
		]);
		return /* @__PURE__ */ React$6.createElement(Component, {
			entryPoints,
			extraProps,
			props,
			queries
		});
	}
	module.exports = EntryPointContainer;
}));
var require_loadQuery = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var invariant = require_invariant();
	var _require = require_relay_runtime(), fetchQueryDeduped = _require.__internal.fetchQueryDeduped, Observable = _require.Observable, PreloadableQueryRegistry = _require.PreloadableQueryRegistry, ReplaySubject = _require.ReplaySubject, createOperationDescriptor = _require.createOperationDescriptor, getRequest = _require.getRequest, getRequestIdentifier = _require.getRequestIdentifier;
	var fetchKey = 100001;
	function loadQuery(environment, preloadableRequest, variables, options, environmentProviderOptions) {
		var _options$fetchPolicy;
		fetchKey++;
		var fetchPolicy = (_options$fetchPolicy = options === null || options === void 0 ? void 0 : options.fetchPolicy) !== null && _options$fetchPolicy !== void 0 ? _options$fetchPolicy : "store-or-network";
		var networkCacheConfig = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, options === null || options === void 0 ? void 0 : options.networkCacheConfig), {}, { force: true });
		var retainReference;
		var didExecuteNetworkSource = false;
		var executeWithNetworkSource = function executeWithNetworkSource(operation, networkObservable) {
			didExecuteNetworkSource = true;
			return environment.executeWithSource({
				operation,
				source: networkObservable
			});
		};
		var executionSubject = new ReplaySubject();
		var returnedObservable = Observable.create(function(sink) {
			return executionSubject.subscribe(sink);
		});
		var unsubscribeFromNetworkRequest;
		var networkError = null;
		var didMakeNetworkRequest = false;
		var makeNetworkRequest = function makeNetworkRequest(params, checkOperation) {
			didMakeNetworkRequest = true;
			var subject = new ReplaySubject();
			unsubscribeFromNetworkRequest = fetchQueryDeduped(environment, "raw-network-request-" + getRequestIdentifier(params, variables), function() {
				return environment.getNetwork().execute(params, variables, networkCacheConfig, void 0, void 0, void 0, void 0, checkOperation);
			}).subscribe({
				error: function error(err) {
					networkError = err;
					subject.error(err);
				},
				next: function next(data) {
					subject.next(data);
				},
				complete: function complete() {
					subject.complete();
				}
			}).unsubscribe;
			return Observable.create(function(sink) {
				var subjectSubscription = subject.subscribe(sink);
				return function() {
					subjectSubscription.unsubscribe();
					unsubscribeFromNetworkRequest();
				};
			});
		};
		var unsubscribeFromExecution;
		var executeDeduped = function executeDeduped(operation, fetchFn) {
			didMakeNetworkRequest = true;
			unsubscribeFromExecution = fetchQueryDeduped(environment, operation.request.identifier, fetchFn).subscribe({
				error: function error(err) {
					executionSubject.error(err);
				},
				next: function next(data) {
					executionSubject.next(data);
				},
				complete: function complete() {
					executionSubject.complete();
				}
			}).unsubscribe;
		};
		var checkAvailabilityAndExecute = function checkAvailabilityAndExecute(concreteRequest) {
			var operation = createOperationDescriptor(concreteRequest, variables, networkCacheConfig);
			retainReference = environment.retain(operation);
			if (fetchPolicy === "store-only") return;
			if (fetchPolicy !== "store-or-network" || environment.check(operation).status !== "available") executeDeduped(operation, function() {
				return executeWithNetworkSource(operation, makeNetworkRequest(concreteRequest.params, function() {
					return environment.check(operation);
				}));
			});
		};
		var params;
		var cancelOnLoadCallback;
		var queryId;
		if (preloadableRequest.kind === "PreloadableConcreteRequest") {
			params = preloadableRequest.params;
			queryId = params.id;
			!(queryId !== null) && invariant(false);
			var _module = PreloadableQueryRegistry.get(queryId);
			if (_module != null) checkAvailabilityAndExecute(_module);
			else {
				var networkObservable = fetchPolicy === "store-only" ? null : makeNetworkRequest(params);
				cancelOnLoadCallback = PreloadableQueryRegistry.onLoad(queryId, function(preloadedModule) {
					cancelOnLoadCallback();
					var operation = createOperationDescriptor(preloadedModule, variables, networkCacheConfig);
					retainReference = environment.retain(operation);
					if (networkObservable != null) executeDeduped(operation, function() {
						return executeWithNetworkSource(operation, networkObservable);
					});
				}).dispose;
			}
		} else {
			var request = getRequest(preloadableRequest);
			params = request.params;
			queryId = params.cacheID != null ? params.cacheID : params.id;
			checkAvailabilityAndExecute(request);
		}
		var isDisposed = false;
		var isReleased = false;
		var isNetworkRequestCancelled = false;
		var releaseQuery = function releaseQuery() {
			if (isReleased) return;
			retainReference && retainReference.dispose();
			isReleased = true;
		};
		var cancelNetworkRequest = function cancelNetworkRequest() {
			if (isNetworkRequestCancelled) return;
			if (didExecuteNetworkSource) unsubscribeFromExecution && unsubscribeFromExecution();
			else unsubscribeFromNetworkRequest && unsubscribeFromNetworkRequest();
			cancelOnLoadCallback && cancelOnLoadCallback();
			isNetworkRequestCancelled = true;
		};
		return {
			kind: "PreloadedQuery",
			environment,
			environmentProviderOptions,
			dispose: function dispose() {
				if (isDisposed) return;
				releaseQuery();
				cancelNetworkRequest();
				isDisposed = true;
			},
			releaseQuery,
			cancelNetworkRequest,
			fetchKey,
			id: queryId,
			get isDisposed() {
				return isDisposed || isReleased;
			},
			get networkError() {
				return networkError;
			},
			name: params.name,
			networkCacheConfig,
			fetchPolicy,
			source: didMakeNetworkRequest ? returnedObservable : void 0,
			variables
		};
	}
	module.exports = { loadQuery };
}));
var require_loadEntryPoint = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var loadQuery = require_loadQuery().loadQuery;
	function loadEntryPoint(environmentProvider, entryPoint, entryPointParams) {
		var loadingPromise = null;
		if (entryPoint.root.getModuleIfRequired() == null) loadingPromise = entryPoint.root.load();
		var preloadProps = entryPoint.getPreloadProps(entryPointParams);
		var queries = preloadProps.queries, entryPoints = preloadProps.entryPoints, extraProps = preloadProps.extraProps;
		var preloadedQueries = {};
		var preloadedEntryPoints = {};
		if (queries != null) Object.keys(queries).forEach(function(queryPropName) {
			var query = queries[queryPropName];
			if (query == null) return;
			var environmentProviderOptions = query.environmentProviderOptions, options = query.options, parameters = query.parameters, variables = query.variables;
			if ((options === null || options === void 0 ? void 0 : options.includeIf) === false) return;
			preloadedQueries[queryPropName] = loadQuery(environmentProvider.getEnvironment(environmentProviderOptions), parameters, variables, {
				fetchPolicy: options === null || options === void 0 ? void 0 : options.fetchPolicy,
				networkCacheConfig: options === null || options === void 0 ? void 0 : options.networkCacheConfig,
				__nameForWarning: "loadEntryPoint"
			}, environmentProviderOptions);
		});
		if (entryPoints != null) Object.keys(entryPoints).forEach(function(entryPointPropName) {
			var entryPointDescription = entryPoints[entryPointPropName];
			if (entryPointDescription == null) return;
			var nestedEntryPoint = entryPointDescription.entryPoint, nestedParams = entryPointDescription.entryPointParams;
			preloadedEntryPoints[entryPointPropName] = loadEntryPoint(environmentProvider, nestedEntryPoint, nestedParams);
		});
		var isDisposed = false;
		return {
			dispose: function dispose() {
				if (isDisposed) return;
				if (preloadedQueries != null) Object.values(preloadedQueries).forEach(function(_ref) {
					var innerDispose = _ref.dispose;
					innerDispose();
				});
				if (preloadedEntryPoints != null) Object.values(preloadedEntryPoints).forEach(function(_ref2) {
					var innerDispose = _ref2.dispose;
					innerDispose();
				});
				isDisposed = true;
			},
			entryPoints: preloadedEntryPoints,
			extraProps: extraProps !== null && extraProps !== void 0 ? extraProps : null,
			getComponent: function getComponent() {
				var componentModule = entryPoint.root.getModuleIfRequired();
				if (componentModule == null) {
					var _loadingPromise;
					loadingPromise = (_loadingPromise = loadingPromise) !== null && _loadingPromise !== void 0 ? _loadingPromise : entryPoint.root.load();
					throw loadingPromise;
				}
				return componentModule["default"] != null ? componentModule["default"] : componentModule;
			},
			get isDisposed() {
				return isDisposed;
			},
			queries: preloadedQueries,
			rootModuleID: entryPoint.root.getModuleId()
		};
	}
	module.exports = loadEntryPoint;
}));
var require_RelayEnvironmentProvider = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactRelayContext = require_ReactRelayContext();
	var React$5 = __require("react");
	var useMemo = React$5.useMemo;
	function RelayEnvironmentProvider(props) {
		var children = props.children, environment = props.environment, getEnvironmentForActor = props.getEnvironmentForActor;
		var context = useMemo(function() {
			return {
				environment,
				getEnvironmentForActor
			};
		}, [environment, getEnvironmentForActor]);
		return /* @__PURE__ */ React$5.createElement(ReactRelayContext.Provider, { value: context }, children);
	}
	module.exports = RelayEnvironmentProvider;
}));
var require_LRUCache = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	var LRUCache = /* @__PURE__ */ function() {
		function LRUCache(capacity) {
			this._capacity = capacity;
			!(this._capacity > 0) && invariant(false);
			this._map = /* @__PURE__ */ new Map();
		}
		var _proto = LRUCache.prototype;
		_proto.set = function set(key, value) {
			this._map["delete"](key);
			this._map.set(key, value);
			if (this._map.size > this._capacity) {
				var firstKey = this._map.keys().next();
				if (!firstKey.done) this._map["delete"](firstKey.value);
			}
		};
		_proto.get = function get(key) {
			var value = this._map.get(key);
			if (value != null) {
				this._map["delete"](key);
				this._map.set(key, value);
			}
			return value;
		};
		_proto.has = function has(key) {
			return this._map.has(key);
		};
		_proto["delete"] = function _delete(key) {
			this._map["delete"](key);
		};
		_proto.size = function size() {
			return this._map.size;
		};
		_proto.capacity = function capacity() {
			return this._capacity - this._map.size;
		};
		_proto.clear = function clear() {
			this._map.clear();
		};
		return LRUCache;
	}();
	function create(capacity) {
		return new LRUCache(capacity);
	}
	module.exports = { create };
}));
var require_SuspenseResource = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	require_warning();
	var TEMPORARY_RETAIN_DURATION_MS = 300 * 1e3;
	module.exports = /* @__PURE__ */ function() {
		function SuspenseResource(retain) {
			var _this = this;
			(0, _defineProperty2["default"])(this, "_retainCount", 0);
			(0, _defineProperty2["default"])(this, "_retainDisposable", null);
			(0, _defineProperty2["default"])(this, "_releaseTemporaryRetain", null);
			this._retain = function(environment) {
				_this._retainCount++;
				if (_this._retainCount === 1) _this._retainDisposable = retain(environment);
				return { dispose: function dispose() {
					_this._retainCount = Math.max(0, _this._retainCount - 1);
					if (_this._retainCount === 0) {
						if (_this._retainDisposable != null) {
							_this._retainDisposable.dispose();
							_this._retainDisposable = null;
						}
					}
				} };
			};
		}
		var _proto = SuspenseResource.prototype;
		_proto.temporaryRetain = function temporaryRetain(environment) {
			var _this2 = this;
			var _this$_releaseTempora;
			if (environment.isServer()) return { dispose: function dispose() {} };
			var retention = this._retain(environment);
			var releaseQueryTimeout = null;
			var releaseTemporaryRetain = function releaseTemporaryRetain() {
				clearTimeout(releaseQueryTimeout);
				releaseQueryTimeout = null;
				_this2._releaseTemporaryRetain = null;
				retention.dispose();
			};
			releaseQueryTimeout = setTimeout(releaseTemporaryRetain, TEMPORARY_RETAIN_DURATION_MS);
			(_this$_releaseTempora = this._releaseTemporaryRetain) === null || _this$_releaseTempora === void 0 || _this$_releaseTempora.call(this);
			this._releaseTemporaryRetain = releaseTemporaryRetain;
			return { dispose: function dispose() {
				var _this$_releaseTempora2;
				(_this$_releaseTempora2 = _this2._releaseTemporaryRetain) === null || _this$_releaseTempora2 === void 0 || _this$_releaseTempora2.call(_this2);
			} };
		};
		_proto.permanentRetain = function permanentRetain(environment) {
			var disposable = this._retain(environment);
			this.releaseTemporaryRetain();
			return disposable;
		};
		_proto.releaseTemporaryRetain = function releaseTemporaryRetain() {
			var _this$_releaseTempora3;
			(_this$_releaseTempora3 = this._releaseTemporaryRetain) === null || _this$_releaseTempora3 === void 0 || _this$_releaseTempora3.call(this);
			this._releaseTemporaryRetain = null;
		};
		_proto.getRetainCount = function getRetainCount() {
			return this._retainCount;
		};
		return SuspenseResource;
	}();
}));
var require_QueryResource = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _defineProperty2 = _interopRequireDefault(require_defineProperty());
	var LRUCache = require_LRUCache();
	var SuspenseResource = require_SuspenseResource();
	var invariant = require_invariant();
	var isPromise = require_relay_runtime().isPromise;
	require_warning();
	var CACHE_CAPACITY = 1e3;
	var DEFAULT_FETCH_POLICY = "store-or-network";
	var DEFAULT_LIVE_FETCH_POLICY = "store-and-network";
	var WEAKMAP_SUPPORTED = typeof WeakMap === "function";
	function operationIsLiveQuery(operation) {
		return operation.request.node.params.metadata.live !== void 0;
	}
	function getQueryCacheIdentifier(environment, operation, maybeFetchPolicy, maybeRenderPolicy, cacheBreaker) {
		var fetchPolicy = maybeFetchPolicy !== null && maybeFetchPolicy !== void 0 ? maybeFetchPolicy : operationIsLiveQuery(operation) ? DEFAULT_LIVE_FETCH_POLICY : DEFAULT_FETCH_POLICY;
		var renderPolicy = maybeRenderPolicy !== null && maybeRenderPolicy !== void 0 ? maybeRenderPolicy : environment.UNSTABLE_getDefaultRenderPolicy();
		var cacheIdentifier = "".concat(fetchPolicy, "-").concat(renderPolicy, "-").concat(operation.request.identifier);
		if (cacheBreaker != null) return "".concat(cacheIdentifier, "-").concat(cacheBreaker);
		return cacheIdentifier;
	}
	function getQueryResult(operation, cacheIdentifier) {
		var rootFragmentRef = {
			__id: operation.fragment.dataID,
			__fragments: (0, _defineProperty2["default"])({}, operation.fragment.node.name, operation.request.variables),
			__fragmentOwner: operation.request
		};
		return {
			cacheIdentifier,
			fragmentNode: operation.request.node.fragment,
			fragmentRef: rootFragmentRef,
			operation
		};
	}
	var nextID = 2e5;
	function createCacheEntry(cacheIdentifier, operation, operationAvailability, value, networkSubscription, onDispose) {
		var isLiveQuery = operationIsLiveQuery(operation);
		var currentValue = value;
		var currentNetworkSubscription = networkSubscription;
		var suspenseResource = new SuspenseResource(function(environment) {
			var retention = environment.retain(operation);
			return { dispose: function dispose() {
				if (isLiveQuery && currentNetworkSubscription != null) currentNetworkSubscription.unsubscribe();
				retention.dispose();
				onDispose(cacheEntry);
			} };
		});
		var cacheEntry = {
			cacheIdentifier,
			id: nextID++,
			processedPayloadsCount: 0,
			operationAvailability,
			getValue: function getValue() {
				return currentValue;
			},
			setValue: function setValue(val) {
				currentValue = val;
			},
			setNetworkSubscription: function setNetworkSubscription(subscription) {
				if (isLiveQuery && currentNetworkSubscription != null) currentNetworkSubscription.unsubscribe();
				currentNetworkSubscription = subscription;
			},
			temporaryRetain: function temporaryRetain(environment) {
				return suspenseResource.temporaryRetain(environment);
			},
			permanentRetain: function permanentRetain(environment) {
				return suspenseResource.permanentRetain(environment);
			},
			releaseTemporaryRetain: function releaseTemporaryRetain() {
				suspenseResource.releaseTemporaryRetain();
			}
		};
		return cacheEntry;
	}
	var QueryResourceImpl = /* @__PURE__ */ function() {
		function QueryResourceImpl(environment) {
			var _this = this;
			(0, _defineProperty2["default"])(this, "_clearCacheEntry", function(cacheEntry) {
				_this._cache["delete"](cacheEntry.cacheIdentifier);
			});
			this._environment = environment;
			this._cache = LRUCache.create(CACHE_CAPACITY);
		}
		var _proto = QueryResourceImpl.prototype;
		_proto.prepare = function prepare(operation, fetchObservable, maybeFetchPolicy, maybeRenderPolicy, observer, cacheBreaker, profilerContext) {
			var cacheIdentifier = getQueryCacheIdentifier(this._environment, operation, maybeFetchPolicy, maybeRenderPolicy, cacheBreaker);
			return this.prepareWithIdentifier(cacheIdentifier, operation, fetchObservable, maybeFetchPolicy, maybeRenderPolicy, observer, profilerContext);
		};
		_proto.prepareWithIdentifier = function prepareWithIdentifier(cacheIdentifier, operation, fetchObservable, maybeFetchPolicy, maybeRenderPolicy, observer, profilerContext) {
			var environment = this._environment;
			var fetchPolicy = maybeFetchPolicy !== null && maybeFetchPolicy !== void 0 ? maybeFetchPolicy : operationIsLiveQuery(operation) ? DEFAULT_LIVE_FETCH_POLICY : DEFAULT_FETCH_POLICY;
			var renderPolicy = maybeRenderPolicy !== null && maybeRenderPolicy !== void 0 ? maybeRenderPolicy : environment.UNSTABLE_getDefaultRenderPolicy();
			var cacheEntry = this._cache.get(cacheIdentifier);
			var temporaryRetainDisposable = null;
			var entryWasCached = cacheEntry != null;
			if (cacheEntry == null) cacheEntry = this._fetchAndSaveQuery(cacheIdentifier, operation, fetchObservable, fetchPolicy, renderPolicy, profilerContext, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, observer), {}, { unsubscribe: function unsubscribe(subscription) {
				if (temporaryRetainDisposable != null) temporaryRetainDisposable.dispose();
				var observerUnsubscribe = observer === null || observer === void 0 ? void 0 : observer.unsubscribe;
				observerUnsubscribe && observerUnsubscribe(subscription);
			} }));
			temporaryRetainDisposable = cacheEntry.temporaryRetain(environment);
			var cachedValue = cacheEntry.getValue();
			if (isPromise(cachedValue)) {
				environment.__log({
					name: "suspense.query",
					fetchPolicy,
					isPromiseCached: entryWasCached,
					operation,
					queryAvailability: cacheEntry.operationAvailability,
					renderPolicy
				});
				throw cachedValue;
			}
			if (cachedValue instanceof Error) throw cachedValue;
			return cachedValue;
		};
		_proto.retain = function retain(queryResult, profilerContext) {
			var environment = this._environment;
			var cacheIdentifier = queryResult.cacheIdentifier, operation = queryResult.operation;
			var cacheEntry = this._getOrCreateCacheEntry(cacheIdentifier, operation, null, queryResult, null);
			var disposable = cacheEntry.permanentRetain(environment);
			environment.__log({
				name: "queryresource.retain",
				profilerContext,
				resourceID: cacheEntry.id
			});
			return { dispose: function dispose() {
				disposable.dispose();
			} };
		};
		_proto.releaseTemporaryRetain = function releaseTemporaryRetain(queryResult) {
			var cacheEntry = this._cache.get(queryResult.cacheIdentifier);
			if (cacheEntry != null) cacheEntry.releaseTemporaryRetain();
		};
		_proto.TESTS_ONLY__getCacheEntry = function TESTS_ONLY__getCacheEntry(operation, maybeFetchPolicy, maybeRenderPolicy, cacheBreaker) {
			var environment = this._environment;
			var cacheIdentifier = getQueryCacheIdentifier(environment, operation, maybeFetchPolicy, maybeRenderPolicy, cacheBreaker);
			return this._cache.get(cacheIdentifier);
		};
		_proto._getOrCreateCacheEntry = function _getOrCreateCacheEntry(cacheIdentifier, operation, operationAvailability, value, networkSubscription) {
			var cacheEntry = this._cache.get(cacheIdentifier);
			if (cacheEntry == null) {
				cacheEntry = createCacheEntry(cacheIdentifier, operation, operationAvailability, value, networkSubscription, this._clearCacheEntry);
				this._cache.set(cacheIdentifier, cacheEntry);
			}
			return cacheEntry;
		};
		_proto._fetchAndSaveQuery = function _fetchAndSaveQuery(cacheIdentifier, operation, fetchObservable, fetchPolicy, renderPolicy, profilerContext, observer) {
			var _this2 = this;
			var environment = this._environment;
			var queryAvailability = environment.check(operation);
			var queryStatus = queryAvailability.status;
			var hasFullQuery = queryStatus === "available";
			var canPartialRender = hasFullQuery || renderPolicy === "partial" && queryStatus !== "stale";
			var shouldFetch;
			var shouldAllowRender;
			var resolveNetworkPromise = function resolveNetworkPromise() {};
			switch (fetchPolicy) {
				case "store-only":
					shouldFetch = false;
					shouldAllowRender = true;
					break;
				case "store-or-network":
					shouldFetch = !hasFullQuery;
					shouldAllowRender = canPartialRender;
					break;
				case "store-and-network":
					shouldFetch = true;
					shouldAllowRender = canPartialRender;
					break;
				default:
					shouldFetch = true;
					shouldAllowRender = false;
					break;
			}
			if (shouldAllowRender) {
				var _cacheEntry = createCacheEntry(cacheIdentifier, operation, queryAvailability, getQueryResult(operation, cacheIdentifier), null, this._clearCacheEntry);
				this._cache.set(cacheIdentifier, _cacheEntry);
			}
			if (shouldFetch) {
				var _queryResult = getQueryResult(operation, cacheIdentifier);
				var networkSubscription;
				fetchObservable.subscribe({
					start: function start(subscription) {
						networkSubscription = subscription;
						var cacheEntry = _this2._cache.get(cacheIdentifier);
						if (cacheEntry) cacheEntry.setNetworkSubscription(networkSubscription);
						var observerStart = observer === null || observer === void 0 ? void 0 : observer.start;
						if (observerStart) observerStart((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, subscription), {}, { unsubscribe: function unsubscribe() {
							if (operationIsLiveQuery(operation)) subscription.unsubscribe();
						} }));
					},
					next: function next() {
						var cacheEntry = _this2._getOrCreateCacheEntry(cacheIdentifier, operation, queryAvailability, _queryResult, networkSubscription);
						cacheEntry.processedPayloadsCount += 1;
						cacheEntry.setValue(_queryResult);
						resolveNetworkPromise();
						var observerNext = observer === null || observer === void 0 ? void 0 : observer.next;
						if (observerNext != null) observerNext(environment.lookup(operation.fragment));
					},
					error: function error(_error) {
						var cacheEntry = _this2._getOrCreateCacheEntry(cacheIdentifier, operation, queryAvailability, _error, networkSubscription);
						if (cacheEntry.processedPayloadsCount === 0) cacheEntry.setValue(_error);
						resolveNetworkPromise();
						networkSubscription = null;
						cacheEntry.setNetworkSubscription(null);
						var observerError = observer === null || observer === void 0 ? void 0 : observer.error;
						observerError && observerError(_error);
					},
					complete: function complete() {
						resolveNetworkPromise();
						networkSubscription = null;
						var cacheEntry = _this2._cache.get(cacheIdentifier);
						if (cacheEntry) cacheEntry.setNetworkSubscription(null);
						var observerComplete = observer === null || observer === void 0 ? void 0 : observer.complete;
						observerComplete && observerComplete();
					},
					unsubscribe: observer === null || observer === void 0 ? void 0 : observer.unsubscribe
				});
				var _cacheEntry2 = this._cache.get(cacheIdentifier);
				if (!_cacheEntry2) {
					var networkPromise = new Promise(function(resolve) {
						resolveNetworkPromise = resolve;
					});
					networkPromise.displayName = "Relay(" + operation.fragment.node.name + ")";
					_cacheEntry2 = createCacheEntry(cacheIdentifier, operation, queryAvailability, networkPromise, networkSubscription, this._clearCacheEntry);
					this._cache.set(cacheIdentifier, _cacheEntry2);
				}
			} else {
				var observerComplete = observer === null || observer === void 0 ? void 0 : observer.complete;
				observerComplete && observerComplete();
			}
			var cacheEntry = this._cache.get(cacheIdentifier);
			!(cacheEntry != null) && invariant(false);
			environment.__log({
				name: "queryresource.fetch",
				resourceID: cacheEntry.id,
				operation,
				profilerContext,
				fetchPolicy,
				renderPolicy,
				queryAvailability,
				shouldFetch
			});
			return cacheEntry;
		};
		return QueryResourceImpl;
	}();
	function createQueryResource(environment) {
		return new QueryResourceImpl(environment);
	}
	var dataResources = WEAKMAP_SUPPORTED ? /* @__PURE__ */ new WeakMap() : /* @__PURE__ */ new Map();
	function getQueryResourceForEnvironment(environment) {
		var cached = dataResources.get(environment);
		if (cached) return cached;
		var newDataResource = createQueryResource(environment);
		dataResources.set(environment, newDataResource);
		return newDataResource;
	}
	module.exports = {
		createQueryResource,
		getQueryResourceForEnvironment,
		getQueryCacheIdentifier
	};
}));
var require_useUnsafeRef_DEPRECATED = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useMemo = __require("react").useMemo;
	function useUnsafeRef_DEPRECATED(init) {
		return useMemo(function() {
			return { current: init };
		}, []);
	}
	module.exports = useUnsafeRef_DEPRECATED;
}));
var require_useFetchTrackingRef = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useUnsafeRef_DEPRECATED = require_useUnsafeRef_DEPRECATED();
	var _require$7 = __require("react"), useCallback$8 = _require$7.useCallback, useEffect$7 = _require$7.useEffect;
	function useFetchTrackingRef() {
		var subscriptionRef = useUnsafeRef_DEPRECATED(null);
		var isFetchingRef = useUnsafeRef_DEPRECATED(false);
		var disposeFetch = useCallback$8(function() {
			if (subscriptionRef.current != null) {
				subscriptionRef.current.unsubscribe();
				subscriptionRef.current = null;
			}
			isFetchingRef.current = false;
		}, []);
		var startFetch = useCallback$8(function(subscription) {
			subscriptionRef.current = subscription;
			isFetchingRef.current = true;
		}, []);
		var completeFetch = useCallback$8(function() {
			subscriptionRef.current = null;
			isFetchingRef.current = false;
		}, []);
		useEffect$7(function() {
			return disposeFetch;
		}, [disposeFetch]);
		return {
			isFetchingRef,
			startFetch,
			disposeFetch,
			completeFetch
		};
	}
	module.exports = useFetchTrackingRef;
}));
var require_ReactRelayLoggingContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var React$4 = __require("react");
	var createRelayLoggingContext = require_relay_runtime().__internal.createRelayLoggingContext;
	module.exports = createRelayLoggingContext(React$4);
}));
var require_useRelayLoggingContext = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactRelayLoggingContext = require_ReactRelayLoggingContext();
	var useContext$1 = __require("react").useContext;
	function useRelayLoggingContext() {
		return useContext$1(ReactRelayLoggingContext);
	}
	module.exports = useRelayLoggingContext;
}));
var require_useFragmentInternal_CURRENT = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var getQueryResourceForEnvironment = require_QueryResource().getQueryResourceForEnvironment;
	var useRelayEnvironment = require_useRelayEnvironment();
	var useRelayLoggingContext = require_useRelayLoggingContext();
	var invariant$2 = require_invariant(), _require2$4 = __require("react");
	_require2$4.useDebugValue;
	var useEffect = _require2$4.useEffect, useMemo = _require2$4.useMemo, useRef = _require2$4.useRef, useState = _require2$4.useState;
	var _require3 = require_relay_runtime(), _require3$__internal = _require3.__internal, fetchQueryInternal = _require3$__internal.fetchQuery, getPromiseForActiveRequest = _require3$__internal.getPromiseForActiveRequest, RelayFeatureFlags = _require3.RelayFeatureFlags, areEqualSelectors = _require3.areEqualSelectors, createOperationDescriptor = _require3.createOperationDescriptor, getPendingOperationsForFragment = _require3.getPendingOperationsForFragment, getSelector = _require3.getSelector, getVariablesFromFragment = _require3.getVariablesFromFragment, handlePotentialSnapshotErrors = _require3.handlePotentialSnapshotErrors, recycleNodesInto = _require3.recycleNodesInto;
	require_warning();
	function isMissingData(state) {
		if (state.kind === "bailout") return false;
		else if (state.kind === "singular") return state.snapshot.isMissingData;
		else return state.snapshots.some(function(s) {
			return s.isMissingData;
		});
	}
	function getMissingClientEdges(state) {
		if (state.kind === "bailout") return null;
		else if (state.kind === "singular") {
			var _state$snapshot$missi;
			return (_state$snapshot$missi = state.snapshot.missingClientEdges) !== null && _state$snapshot$missi !== void 0 ? _state$snapshot$missi : null;
		} else {
			var edges = null;
			var _iterator = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var snapshot = _step.value;
					if (snapshot.missingClientEdges) {
						var _edges;
						edges = (_edges = edges) !== null && _edges !== void 0 ? _edges : [];
						var _iterator2 = (0, _createForOfIteratorHelper2["default"])(snapshot.missingClientEdges), _step2;
						try {
							for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
								var edge = _step2.value;
								edges.push(edge);
							}
						} catch (err) {
							_iterator2.e(err);
						} finally {
							_iterator2.f();
						}
					}
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			return edges;
		}
	}
	function getSuspendingLiveResolver(state) {
		if (state.kind === "bailout") return null;
		else if (state.kind === "singular") {
			var _state$snapshot$missi2;
			return (_state$snapshot$missi2 = state.snapshot.missingLiveResolverFields) !== null && _state$snapshot$missi2 !== void 0 ? _state$snapshot$missi2 : null;
		} else {
			var missingFields = null;
			var _iterator3 = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step3;
			try {
				for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
					var snapshot = _step3.value;
					if (snapshot.missingLiveResolverFields) {
						var _missingFields;
						missingFields = (_missingFields = missingFields) !== null && _missingFields !== void 0 ? _missingFields : [];
						var _iterator4 = (0, _createForOfIteratorHelper2["default"])(snapshot.missingLiveResolverFields), _step4;
						try {
							for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
								var edge = _step4.value;
								missingFields.push(edge);
							}
						} catch (err) {
							_iterator4.e(err);
						} finally {
							_iterator4.f();
						}
					}
				}
			} catch (err) {
				_iterator3.e(err);
			} finally {
				_iterator3.f();
			}
			return missingFields;
		}
	}
	function handlePotentialSnapshotErrorsForState(environment, state, loggingContext) {
		if (state.kind === "singular") handlePotentialSnapshotErrors(environment, state.snapshot.fieldErrors, loggingContext);
		else if (state.kind === "plural") {
			var _iterator5 = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step5;
			try {
				for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
					var snapshot = _step5.value;
					handlePotentialSnapshotErrors(environment, snapshot.fieldErrors, loggingContext);
				}
			} catch (err) {
				_iterator5.e(err);
			} finally {
				_iterator5.f();
			}
		}
	}
	function handleMissedUpdates(environment, state) {
		if (state.kind === "bailout") return null;
		var currentEpoch = environment.getStore().getEpoch();
		if (currentEpoch === state.epoch) return null;
		if (state.kind === "singular") {
			var currentSnapshot = environment.lookup(state.snapshot.selector);
			var updatedData = recycleNodesInto(state.snapshot.data, currentSnapshot.data);
			var updatedCurrentSnapshot = {
				data: updatedData,
				isMissingData: currentSnapshot.isMissingData,
				missingClientEdges: currentSnapshot.missingClientEdges,
				missingLiveResolverFields: currentSnapshot.missingLiveResolverFields,
				seenRecords: currentSnapshot.seenRecords,
				selector: currentSnapshot.selector,
				fieldErrors: currentSnapshot.fieldErrors
			};
			return [updatedData !== state.snapshot.data, {
				kind: "singular",
				snapshot: updatedCurrentSnapshot,
				epoch: currentEpoch
			}];
		} else {
			var didMissUpdates = false;
			var currentSnapshots = [];
			for (var index = 0; index < state.snapshots.length; index++) {
				var snapshot = state.snapshots[index];
				var _currentSnapshot = environment.lookup(snapshot.selector);
				var _updatedData = recycleNodesInto(snapshot.data, _currentSnapshot.data);
				var _updatedCurrentSnapshot = {
					data: _updatedData,
					isMissingData: _currentSnapshot.isMissingData,
					missingClientEdges: _currentSnapshot.missingClientEdges,
					missingLiveResolverFields: _currentSnapshot.missingLiveResolverFields,
					seenRecords: _currentSnapshot.seenRecords,
					selector: _currentSnapshot.selector,
					fieldErrors: _currentSnapshot.fieldErrors
				};
				if (_updatedData !== snapshot.data) didMissUpdates = true;
				currentSnapshots.push(_updatedCurrentSnapshot);
			}
			!(currentSnapshots.length === state.snapshots.length) && invariant$2(false);
			return [didMissUpdates, {
				kind: "plural",
				snapshots: currentSnapshots,
				epoch: currentEpoch
			}];
		}
	}
	function handleMissingClientEdge(environment, parentFragmentNode, parentFragmentRef, missingClientEdgeRequestInfo, queryOptions) {
		var originalVariables = getVariablesFromFragment(parentFragmentNode, parentFragmentRef);
		var variables = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, originalVariables), {}, { id: missingClientEdgeRequestInfo.clientEdgeDestinationID });
		var queryOperationDescriptor = createOperationDescriptor(missingClientEdgeRequestInfo.request, variables, queryOptions === null || queryOptions === void 0 ? void 0 : queryOptions.networkCacheConfig);
		return [getQueryResourceForEnvironment(environment).prepare(queryOperationDescriptor, fetchQueryInternal(environment, queryOperationDescriptor), queryOptions === null || queryOptions === void 0 ? void 0 : queryOptions.fetchPolicy), getPromiseForActiveRequest(environment, queryOperationDescriptor.request)];
	}
	function subscribeToSnapshot(environment, state, setState, hasPendingStateChanges) {
		if (state.kind === "bailout") return function() {};
		else if (state.kind === "singular") {
			var disposable = environment.subscribe(state.snapshot, function(latestSnapshot) {
				setState(function(prevState) {
					if (prevState.kind !== "singular" || prevState.snapshot.selector !== latestSnapshot.selector) {
						var updates = handleMissedUpdates(environment, prevState);
						if (updates != null) {
							var dataChanged = updates[0], nextState = updates[1];
							environment.__log({
								name: "useFragment.subscription.missedUpdates",
								hasDataChanges: dataChanged
							});
							hasPendingStateChanges.current = dataChanged;
							return dataChanged ? nextState : prevState;
						} else return prevState;
					}
					hasPendingStateChanges.current = true;
					return {
						kind: "singular",
						snapshot: latestSnapshot,
						epoch: environment.getStore().getEpoch()
					};
				});
			});
			return function() {
				disposable.dispose();
			};
		} else {
			var disposables = state.snapshots.map(function(snapshot, index) {
				return environment.subscribe(snapshot, function(latestSnapshot) {
					setState(function(prevState) {
						var _prevState$snapshots$;
						if (prevState.kind !== "plural" || ((_prevState$snapshots$ = prevState.snapshots[index]) === null || _prevState$snapshots$ === void 0 ? void 0 : _prevState$snapshots$.selector) !== latestSnapshot.selector) {
							var updates = handleMissedUpdates(environment, prevState);
							if (updates != null) {
								var dataChanged = updates[0], nextState = updates[1];
								environment.__log({
									name: "useFragment.subscription.missedUpdates",
									hasDataChanges: dataChanged
								});
								hasPendingStateChanges.current = hasPendingStateChanges.current || dataChanged;
								return dataChanged ? nextState : prevState;
							} else return prevState;
						}
						var updated = (0, _toConsumableArray2["default"])(prevState.snapshots);
						updated[index] = latestSnapshot;
						hasPendingStateChanges.current = true;
						return {
							kind: "plural",
							snapshots: updated,
							epoch: environment.getStore().getEpoch()
						};
					});
				});
			});
			return function() {
				var _iterator6 = (0, _createForOfIteratorHelper2["default"])(disposables), _step6;
				try {
					for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) _step6.value.dispose();
				} catch (err) {
					_iterator6.e(err);
				} finally {
					_iterator6.f();
				}
			};
		}
	}
	function getFragmentState(environment, fragmentSelector) {
		if (fragmentSelector == null) return { kind: "bailout" };
		else if (fragmentSelector.kind === "PluralReaderSelector") return {
			kind: "plural",
			snapshots: fragmentSelector.selectors.map(function(s) {
				return environment.lookup(s);
			}),
			epoch: environment.getStore().getEpoch()
		};
		else return {
			kind: "singular",
			snapshot: environment.lookup(fragmentSelector),
			epoch: environment.getStore().getEpoch()
		};
	}
	function useFragmentInternal(fragmentNode, fragmentRef, hookDisplayName, queryOptions) {
		var _fragmentNode$metadat, _fragmentNode$metadat2;
		var fragmentSelector = useMemo(function() {
			return getSelector(fragmentNode, fragmentRef);
		}, [fragmentNode, fragmentRef]);
		var isPlural = (fragmentNode === null || fragmentNode === void 0 ? void 0 : (_fragmentNode$metadat = fragmentNode.metadata) === null || _fragmentNode$metadat === void 0 ? void 0 : _fragmentNode$metadat.plural) === true;
		if (isPlural) !(fragmentRef == null || Array.isArray(fragmentRef)) && invariant$2(false);
		else Array.isArray(fragmentRef) && invariant$2(false);
		!(fragmentRef == null || isPlural && Array.isArray(fragmentRef) && fragmentRef.length === 0 || fragmentSelector != null) && invariant$2(false);
		var environment = useRelayEnvironment();
		var loggerContext;
		if (RelayFeatureFlags.ENABLE_UI_CONTEXT_ON_RELAY_LOGGER) loggerContext = useRelayLoggingContext();
		var _useState = useState(function() {
			return getFragmentState(environment, fragmentSelector);
		}), _state = _useState[0], setState = _useState[1];
		var state = _state;
		var _useState2 = useState(state), _subscribedState = _useState2[0], setSubscribedState = _useState2[1];
		var subscribedState = _subscribedState;
		var _useState3 = useState(fragmentSelector), previousFragmentSelector = _useState3[0], setPreviousFragmentSelector = _useState3[1];
		var _useState4 = useState(environment), previousEnvironment = _useState4[0], setPreviousEnvironment = _useState4[1];
		if (!areEqualSelectors(fragmentSelector, previousFragmentSelector) || environment !== previousEnvironment) {
			setPreviousFragmentSelector(fragmentSelector);
			setPreviousEnvironment(environment);
			var newState = getFragmentState(environment, fragmentSelector);
			setState(newState);
			setSubscribedState(newState);
			state = newState;
			subscribedState = newState;
		}
		var committedFragmentSelectorRef = useRef(false);
		useEffect(function() {
			committedFragmentSelectorRef.current = fragmentSelector;
		}, [fragmentSelector]);
		if (((_fragmentNode$metadat2 = fragmentNode.metadata) === null || _fragmentNode$metadat2 === void 0 ? void 0 : _fragmentNode$metadat2.hasClientEdges) === true || RelayFeatureFlags.CHECK_ALL_FRAGMENTS_FOR_MISSING_CLIENT_EDGES) {
			var _useMemo = useMemo(function() {
				var missingClientEdges = getMissingClientEdges(state);
				var clientEdgeQueries;
				var activeRequestPromises = [];
				if (missingClientEdges !== null && missingClientEdges !== void 0 && missingClientEdges.length) {
					clientEdgeQueries = [];
					var _iterator7 = (0, _createForOfIteratorHelper2["default"])(missingClientEdges), _step7;
					try {
						for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
							var edge = _step7.value;
							var _handleMissingClientE = handleMissingClientEdge(environment, fragmentNode, fragmentRef, edge, queryOptions), queryResult = _handleMissingClientE[0], requestPromise = _handleMissingClientE[1];
							clientEdgeQueries.push(queryResult);
							if (requestPromise != null) activeRequestPromises.push(requestPromise);
						}
					} catch (err) {
						_iterator7.e(err);
					} finally {
						_iterator7.f();
					}
				}
				return [clientEdgeQueries, activeRequestPromises];
			}, [
				state,
				environment,
				fragmentNode,
				fragmentRef,
				queryOptions
			]), clientEdgeQueries = _useMemo[0], activeRequestPromises = _useMemo[1];
			if (activeRequestPromises.length) throw Promise.all(activeRequestPromises);
			useEffect(function() {
				var QueryResource = getQueryResourceForEnvironment(environment);
				if (clientEdgeQueries !== null && clientEdgeQueries !== void 0 && clientEdgeQueries.length) {
					var disposables = [];
					var _iterator8 = (0, _createForOfIteratorHelper2["default"])(clientEdgeQueries), _step8;
					try {
						for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
							var query = _step8.value;
							disposables.push(QueryResource.retain(query));
						}
					} catch (err) {
						_iterator8.e(err);
					} finally {
						_iterator8.f();
					}
					return function() {
						for (var _i = 0, _disposables = disposables; _i < _disposables.length; _i++) _disposables[_i].dispose();
					};
				}
			}, [environment, clientEdgeQueries]);
		}
		if (isMissingData(state)) {
			var suspendingLiveResolvers = getSuspendingLiveResolver(state);
			if (suspendingLiveResolvers != null && suspendingLiveResolvers.length > 0) throw Promise.all(suspendingLiveResolvers.map(function(liveStateID) {
				return environment.getStore().getLiveResolverPromise(liveStateID);
			}));
			if (RelayFeatureFlags.ENABLE_RELAY_OPERATION_TRACKER_SUSPENSE || environment !== previousEnvironment || !committedFragmentSelectorRef.current || !areEqualSelectors(committedFragmentSelectorRef.current, fragmentSelector)) {
				!(fragmentSelector != null) && invariant$2(false);
				var pendingOperationsResult = getPendingOperationsForFragment(environment, fragmentNode, fragmentSelector.kind === "PluralReaderSelector" ? fragmentSelector.selectors[0].owner : fragmentSelector.owner);
				if (pendingOperationsResult) throw pendingOperationsResult.promise;
			}
		}
		handlePotentialSnapshotErrorsForState(environment, state, loggerContext);
		var hasPendingStateChanges = useRef(false);
		useEffect(function() {
			var currentState = subscribedState;
			var updates = handleMissedUpdates(environment, subscribedState);
			if (updates !== null) {
				var didMissUpdates = updates[0], updatedState = updates[1];
				if (didMissUpdates) setState(updatedState);
				currentState = updatedState;
			}
			return subscribeToSnapshot(environment, currentState, setState, hasPendingStateChanges);
		}, [environment, subscribedState]);
		if (hasPendingStateChanges.current) {
			var updates = handleMissedUpdates(environment, state);
			if (updates != null) {
				var hasStateUpdates = updates[0], updatedState = updates[1];
				if (hasStateUpdates) {
					setState(updatedState);
					state = updatedState;
				}
			}
			hasPendingStateChanges.current = false;
		}
		var data;
		if (isPlural) {
			var fragmentRefIsNullish = fragmentRef == null;
			data = useMemo(function() {
				if (state.kind === "bailout") return fragmentRefIsNullish ? null : [];
				else {
					!(state.kind === "plural") && invariant$2(false);
					return state.snapshots.map(function(s) {
						return s.data;
					});
				}
			}, [state, fragmentRefIsNullish]);
		} else if (state.kind === "bailout") data = null;
		else {
			!(state.kind === "singular") && invariant$2(false);
			data = state.snapshot.data;
		}
		if (RelayFeatureFlags.LOG_MISSING_RECORDS_IN_PROD || false) {
			if (fragmentRef != null && (data === void 0 || Array.isArray(data) && data.length > 0 && data.every(function(d) {
				return d === void 0;
			}))) {}
		}
		return data;
	}
	module.exports = useFragmentInternal;
}));
var require_useFragmentInternal_EXPERIMENTAL = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var _toConsumableArray2 = _interopRequireDefault(require_toConsumableArray());
	var getQueryResourceForEnvironment = require_QueryResource().getQueryResourceForEnvironment;
	var useRelayEnvironment = require_useRelayEnvironment();
	var useRelayLoggingContext = require_useRelayLoggingContext();
	var invariant$1 = require_invariant(), _require2$3 = __require("react");
	_require2$3.useDebugValue;
	var useEffect = _require2$3.useEffect, useMemo = _require2$3.useMemo, useRef = _require2$3.useRef, useState = _require2$3.useState;
	var _require3 = require_relay_runtime(), _require3$__internal = _require3.__internal, fetchQueryInternal = _require3$__internal.fetchQuery, getPromiseForActiveRequest = _require3$__internal.getPromiseForActiveRequest, RelayFeatureFlags = _require3.RelayFeatureFlags, areEqualSelectors = _require3.areEqualSelectors, createOperationDescriptor = _require3.createOperationDescriptor, getPendingOperationsForFragment = _require3.getPendingOperationsForFragment, getSelector = _require3.getSelector, getVariablesFromFragment = _require3.getVariablesFromFragment, handlePotentialSnapshotErrors = _require3.handlePotentialSnapshotErrors, recycleNodesInto = _require3.recycleNodesInto;
	require_warning();
	function isMissingData(state) {
		if (state.kind === "bailout") return false;
		else if (state.kind === "singular") return state.snapshot.isMissingData;
		else return state.snapshots.some(function(s) {
			return s.isMissingData;
		});
	}
	function getMissingClientEdges(state) {
		if (state.kind === "bailout") return null;
		else if (state.kind === "singular") {
			var _state$snapshot$missi;
			return (_state$snapshot$missi = state.snapshot.missingClientEdges) !== null && _state$snapshot$missi !== void 0 ? _state$snapshot$missi : null;
		} else {
			var edges = null;
			var _iterator = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var snapshot = _step.value;
					if (snapshot.missingClientEdges) {
						var _edges;
						edges = (_edges = edges) !== null && _edges !== void 0 ? _edges : [];
						var _iterator2 = (0, _createForOfIteratorHelper2["default"])(snapshot.missingClientEdges), _step2;
						try {
							for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
								var edge = _step2.value;
								edges.push(edge);
							}
						} catch (err) {
							_iterator2.e(err);
						} finally {
							_iterator2.f();
						}
					}
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			return edges;
		}
	}
	function getSuspendingLiveResolver(state) {
		if (state.kind === "bailout") return null;
		else if (state.kind === "singular") {
			var _state$snapshot$missi2;
			return (_state$snapshot$missi2 = state.snapshot.missingLiveResolverFields) !== null && _state$snapshot$missi2 !== void 0 ? _state$snapshot$missi2 : null;
		} else {
			var missingFields = null;
			var _iterator3 = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step3;
			try {
				for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
					var snapshot = _step3.value;
					if (snapshot.missingLiveResolverFields) {
						var _missingFields;
						missingFields = (_missingFields = missingFields) !== null && _missingFields !== void 0 ? _missingFields : [];
						var _iterator4 = (0, _createForOfIteratorHelper2["default"])(snapshot.missingLiveResolverFields), _step4;
						try {
							for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
								var edge = _step4.value;
								missingFields.push(edge);
							}
						} catch (err) {
							_iterator4.e(err);
						} finally {
							_iterator4.f();
						}
					}
				}
			} catch (err) {
				_iterator3.e(err);
			} finally {
				_iterator3.f();
			}
			return missingFields;
		}
	}
	function handlePotentialSnapshotErrorsForState(environment, state, loggingContext) {
		if (state.kind === "singular") handlePotentialSnapshotErrors(environment, state.snapshot.fieldErrors, loggingContext);
		else if (state.kind === "plural") {
			var _iterator5 = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step5;
			try {
				for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
					var snapshot = _step5.value;
					handlePotentialSnapshotErrors(environment, snapshot.fieldErrors, loggingContext);
				}
			} catch (err) {
				_iterator5.e(err);
			} finally {
				_iterator5.f();
			}
		}
	}
	function handleMissedUpdates(environment, state) {
		if (state.kind === "bailout") return null;
		var currentEpoch = environment.getStore().getEpoch();
		if (currentEpoch === state.epoch) return null;
		if (state.kind === "singular") {
			var currentSnapshot = environment.lookup(state.snapshot.selector);
			var updatedData = recycleNodesInto(state.snapshot.data, currentSnapshot.data);
			var updatedCurrentSnapshot = {
				data: updatedData,
				isMissingData: currentSnapshot.isMissingData,
				missingClientEdges: currentSnapshot.missingClientEdges,
				missingLiveResolverFields: currentSnapshot.missingLiveResolverFields,
				seenRecords: currentSnapshot.seenRecords,
				selector: currentSnapshot.selector,
				fieldErrors: currentSnapshot.fieldErrors
			};
			return [updatedData !== state.snapshot.data, {
				kind: "singular",
				snapshot: updatedCurrentSnapshot,
				epoch: currentEpoch,
				selector: state.selector,
				environment: state.environment
			}];
		} else {
			var didMissUpdates = false;
			var currentSnapshots = [];
			for (var index = 0; index < state.snapshots.length; index++) {
				var snapshot = state.snapshots[index];
				var _currentSnapshot = environment.lookup(snapshot.selector);
				var _updatedData = recycleNodesInto(snapshot.data, _currentSnapshot.data);
				var _updatedCurrentSnapshot = {
					data: _updatedData,
					isMissingData: _currentSnapshot.isMissingData,
					missingClientEdges: _currentSnapshot.missingClientEdges,
					missingLiveResolverFields: _currentSnapshot.missingLiveResolverFields,
					seenRecords: _currentSnapshot.seenRecords,
					selector: _currentSnapshot.selector,
					fieldErrors: _currentSnapshot.fieldErrors
				};
				if (_updatedData !== snapshot.data) didMissUpdates = true;
				currentSnapshots.push(_updatedCurrentSnapshot);
			}
			!(currentSnapshots.length === state.snapshots.length) && invariant$1(false);
			return [didMissUpdates, {
				kind: "plural",
				snapshots: currentSnapshots,
				epoch: currentEpoch,
				selector: state.selector,
				environment: state.environment
			}];
		}
	}
	function handleMissingClientEdge(environment, parentFragmentNode, parentFragmentRef, missingClientEdgeRequestInfo, queryOptions) {
		var originalVariables = getVariablesFromFragment(parentFragmentNode, parentFragmentRef);
		var variables = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, originalVariables), {}, { id: missingClientEdgeRequestInfo.clientEdgeDestinationID });
		var queryOperationDescriptor = createOperationDescriptor(missingClientEdgeRequestInfo.request, variables, queryOptions === null || queryOptions === void 0 ? void 0 : queryOptions.networkCacheConfig);
		var queryResult = getQueryResourceForEnvironment(environment).prepare(queryOperationDescriptor, fetchQueryInternal(environment, queryOperationDescriptor), queryOptions === null || queryOptions === void 0 ? void 0 : queryOptions.fetchPolicy);
		var promise = getPromiseForActiveRequest(environment, queryOperationDescriptor.request);
		if (promise != null && promise.displayName == null) promise.displayName = missingClientEdgeRequestInfo.request.params.name;
		return [queryResult, promise];
	}
	function subscribeToSnapshot(environment, state, setState) {
		if (state.kind === "bailout") return function() {};
		else if (state.kind === "singular") {
			var disposable = environment.subscribe(state.snapshot, function(latestSnapshot) {
				setState(function(prevState) {
					var nextState = null;
					if (prevState.kind !== "singular" || prevState.snapshot.selector !== latestSnapshot.selector || prevState.environment !== environment) {
						var updates = handleMissedUpdates(prevState.environment, prevState);
						if (updates != null) {
							var dataChanged = updates[0], updatedState = updates[1];
							environment.__log({
								name: "useFragment.subscription.missedUpdates",
								hasDataChanges: dataChanged
							});
							nextState = dataChanged ? updatedState : prevState;
						} else nextState = prevState;
					} else nextState = {
						kind: "singular",
						snapshot: latestSnapshot,
						epoch: environment.getStore().getEpoch(),
						selector: state.selector,
						environment: state.environment
					};
					return nextState;
				});
			});
			return function() {
				disposable.dispose();
			};
		} else {
			var disposables = state.snapshots.map(function(snapshot, index) {
				return environment.subscribe(snapshot, function(latestSnapshot) {
					setState(function(prevState) {
						var _prevState$snapshots$;
						var nextState = null;
						if (prevState.kind !== "plural" || ((_prevState$snapshots$ = prevState.snapshots[index]) === null || _prevState$snapshots$ === void 0 ? void 0 : _prevState$snapshots$.selector) !== latestSnapshot.selector || prevState.environment !== environment) {
							var updates = handleMissedUpdates(prevState.environment, prevState);
							if (updates != null) {
								var dataChanged = updates[0], updatedState = updates[1];
								environment.__log({
									name: "useFragment.subscription.missedUpdates",
									hasDataChanges: dataChanged
								});
								nextState = dataChanged ? updatedState : prevState;
							} else nextState = prevState;
						} else {
							var updated = (0, _toConsumableArray2["default"])(prevState.snapshots);
							updated[index] = latestSnapshot;
							nextState = {
								kind: "plural",
								snapshots: updated,
								epoch: environment.getStore().getEpoch(),
								selector: state.selector,
								environment: state.environment
							};
						}
						return nextState;
					});
				});
			});
			return function() {
				var _iterator6 = (0, _createForOfIteratorHelper2["default"])(disposables), _step6;
				try {
					for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) _step6.value.dispose();
				} catch (err) {
					_iterator6.e(err);
				} finally {
					_iterator6.f();
				}
			};
		}
	}
	function getFragmentState(environment, fragmentSelector) {
		if (fragmentSelector == null) return {
			kind: "bailout",
			environment
		};
		else if (fragmentSelector.kind === "PluralReaderSelector") return {
			kind: "plural",
			snapshots: fragmentSelector.selectors.map(function(s) {
				return environment.lookup(s);
			}),
			epoch: environment.getStore().getEpoch(),
			selector: fragmentSelector,
			environment
		};
		else return {
			kind: "singular",
			snapshot: environment.lookup(fragmentSelector),
			epoch: environment.getStore().getEpoch(),
			selector: fragmentSelector,
			environment
		};
	}
	function useFragmentInternal_EXPERIMENTAL(fragmentNode, fragmentRef, hookDisplayName, queryOptions) {
		var _fragmentNode$metadat, _fragmentNode$metadat2;
		var fragmentSelector = useMemo(function() {
			return getSelector(fragmentNode, fragmentRef);
		}, [fragmentNode, fragmentRef]);
		var isPlural = (fragmentNode === null || fragmentNode === void 0 ? void 0 : (_fragmentNode$metadat = fragmentNode.metadata) === null || _fragmentNode$metadat === void 0 ? void 0 : _fragmentNode$metadat.plural) === true;
		if (isPlural) !(fragmentRef == null || Array.isArray(fragmentRef)) && invariant$1(false);
		else Array.isArray(fragmentRef) && invariant$1(false);
		!(fragmentRef == null || isPlural && Array.isArray(fragmentRef) && fragmentRef.length === 0 || fragmentSelector != null) && invariant$1(false);
		var environment = useRelayEnvironment();
		var loggerContext;
		if (RelayFeatureFlags.ENABLE_UI_CONTEXT_ON_RELAY_LOGGER) loggerContext = useRelayLoggingContext();
		var _useState = useState(function() {
			return getFragmentState(environment, fragmentSelector);
		}), _state = _useState[0], setState = _useState[1];
		var state = _state;
		var previousEnvironment = state.environment;
		if (!areEqualSelectors(fragmentSelector, state.selector) || environment !== state.environment) {
			var newState = getFragmentState(environment, fragmentSelector);
			setState(newState);
			state = newState;
		}
		var committedFragmentSelectorRef = useRef(false);
		useEffect(function() {
			committedFragmentSelectorRef.current = fragmentSelector;
		}, [fragmentSelector]);
		if (((_fragmentNode$metadat2 = fragmentNode.metadata) === null || _fragmentNode$metadat2 === void 0 ? void 0 : _fragmentNode$metadat2.hasClientEdges) === true || RelayFeatureFlags.CHECK_ALL_FRAGMENTS_FOR_MISSING_CLIENT_EDGES) {
			var _useMemo = useMemo(function() {
				var missingClientEdges = getMissingClientEdges(state);
				var clientEdgeQueries;
				var activeRequestPromises = [];
				if (missingClientEdges !== null && missingClientEdges !== void 0 && missingClientEdges.length) {
					clientEdgeQueries = [];
					var _iterator7 = (0, _createForOfIteratorHelper2["default"])(missingClientEdges), _step7;
					try {
						for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
							var edge = _step7.value;
							var _handleMissingClientE = handleMissingClientEdge(environment, fragmentNode, fragmentRef, edge, queryOptions), queryResult = _handleMissingClientE[0], requestPromise = _handleMissingClientE[1];
							clientEdgeQueries.push(queryResult);
							if (requestPromise != null) activeRequestPromises.push(requestPromise);
						}
					} catch (err) {
						_iterator7.e(err);
					} finally {
						_iterator7.f();
					}
				}
				return [clientEdgeQueries, activeRequestPromises];
			}, [
				state,
				environment,
				fragmentNode,
				fragmentRef,
				queryOptions
			]), clientEdgeQueries = _useMemo[0], activeRequestPromises = _useMemo[1];
			if (activeRequestPromises.length) {
				var allPromises = Promise.all(activeRequestPromises);
				allPromises.displayName = "RelayClientEdge(".concat(activeRequestPromises.map(function(promise) {
					return promise.displayName;
				}).join(","), ")");
				throw allPromises;
			}
			useEffect(function() {
				var QueryResource = getQueryResourceForEnvironment(environment);
				if (clientEdgeQueries !== null && clientEdgeQueries !== void 0 && clientEdgeQueries.length) {
					var disposables = [];
					var _iterator8 = (0, _createForOfIteratorHelper2["default"])(clientEdgeQueries), _step8;
					try {
						for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
							var query = _step8.value;
							disposables.push(QueryResource.retain(query));
						}
					} catch (err) {
						_iterator8.e(err);
					} finally {
						_iterator8.f();
					}
					return function() {
						for (var _i = 0, _disposables = disposables; _i < _disposables.length; _i++) _disposables[_i].dispose();
					};
				}
			}, [environment, clientEdgeQueries]);
		}
		if (isMissingData(state)) {
			var suspendingLiveResolvers = getSuspendingLiveResolver(state);
			if (suspendingLiveResolvers != null && suspendingLiveResolvers.length > 0) {
				var promise = Promise.all(suspendingLiveResolvers.map(function(liveStateID) {
					return environment.getStore().getLiveResolverPromise(liveStateID);
				}));
				promise.displayName = "RelayLiveResolver(" + fragmentNode.name + ")";
				throw promise;
			}
			if (RelayFeatureFlags.ENABLE_RELAY_OPERATION_TRACKER_SUSPENSE || environment !== previousEnvironment || !committedFragmentSelectorRef.current || !areEqualSelectors(committedFragmentSelectorRef.current, fragmentSelector)) {
				!(fragmentSelector != null) && invariant$1(false);
				var pendingOperationsResult = getPendingOperationsForFragment(environment, fragmentNode, fragmentSelector.kind === "PluralReaderSelector" ? fragmentSelector.selectors[0].owner : fragmentSelector.owner);
				if (pendingOperationsResult) throw pendingOperationsResult.promise;
			}
		}
		handlePotentialSnapshotErrorsForState(environment, state, loggerContext);
		var storeSubscriptionRef = useRef(null);
		useEffect(function() {
			var storeSubscription = storeSubscriptionRef.current;
			if (storeSubscription != null) if (state.environment === storeSubscription.environment && state.selector === storeSubscription.selector) return;
			else storeSubscription.dispose();
			if (state.kind === "bailout") return;
			var stateForSubscription = state;
			var updates = handleMissedUpdates(state.environment, state);
			if (updates !== null) {
				var didMissUpdates = updates[0], updatedState = updates[1];
				if (didMissUpdates) {
					setState(updatedState);
					return;
				}
				stateForSubscription = updatedState;
			}
			storeSubscriptionRef.current = {
				dispose: subscribeToSnapshot(state.environment, stateForSubscription, setState),
				selector: state.selector,
				environment: state.environment
			};
		}, [state]);
		useEffect(function() {
			if (storeSubscriptionRef.current == null && state.kind !== "bailout") storeSubscriptionRef.current = {
				dispose: subscribeToSnapshot(state.environment, state, setState),
				selector: state.selector,
				environment: state.environment
			};
			return function() {
				var _storeSubscriptionRef;
				(_storeSubscriptionRef = storeSubscriptionRef.current) === null || _storeSubscriptionRef === void 0 || _storeSubscriptionRef.dispose();
				storeSubscriptionRef.current = null;
			};
		}, []);
		var data;
		if (isPlural) {
			var fragmentRefIsNullish = fragmentRef == null;
			data = useMemo(function() {
				if (state.kind === "bailout") return fragmentRefIsNullish ? null : [];
				else {
					!(state.kind === "plural") && invariant$1(false);
					return state.snapshots.map(function(s) {
						return s.data;
					});
				}
			}, [state, fragmentRefIsNullish]);
		} else if (state.kind === "bailout") data = null;
		else {
			!(state.kind === "singular") && invariant$1(false);
			data = state.snapshot.data;
		}
		if (RelayFeatureFlags.LOG_MISSING_RECORDS_IN_PROD || false) {
			if (fragmentRef != null && (data === void 0 || Array.isArray(data) && data.length > 0 && data.every(function(d) {
				return d === void 0;
			}))) {}
		}
		return data;
	}
	module.exports = useFragmentInternal_EXPERIMENTAL;
}));
var require_useFragmentInternal = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _useFragmentInternal_CURRENT = _interopRequireDefault(require_useFragmentInternal_CURRENT());
	var _useFragmentInternal_EXPERIMENTAL = _interopRequireDefault(require_useFragmentInternal_EXPERIMENTAL());
	var _relayRuntime = require_relay_runtime();
	function useFragmentInternal(fragmentNode, fragmentRef, hookDisplayName, queryOptions) {
		if (_relayRuntime.RelayFeatureFlags.ENABLE_ACTIVITY_COMPATIBILITY) return (0, _useFragmentInternal_EXPERIMENTAL["default"])(fragmentNode, fragmentRef, hookDisplayName, queryOptions);
		return (0, _useFragmentInternal_CURRENT["default"])(fragmentNode, fragmentRef, hookDisplayName, queryOptions);
	}
	module.exports = useFragmentInternal;
}));
var require_useLazyLoadQueryNode = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ProfilerContext = require_ProfilerContext();
	var _require = require_QueryResource(), getQueryCacheIdentifier = _require.getQueryCacheIdentifier, getQueryResourceForEnvironment = _require.getQueryResourceForEnvironment;
	var useFetchTrackingRef = require_useFetchTrackingRef();
	var useFragmentInternal = require_useFragmentInternal();
	var useRelayEnvironment = require_useRelayEnvironment();
	var React$3 = __require("react");
	var useContext = React$3.useContext, useEffect = React$3.useEffect, useState = React$3.useState, useRef = React$3.useRef;
	function useLazyLoadQueryNode(_ref) {
		var query = _ref.query, componentDisplayName = _ref.componentDisplayName, fetchObservable = _ref.fetchObservable, fetchPolicy = _ref.fetchPolicy, fetchKey = _ref.fetchKey, renderPolicy = _ref.renderPolicy;
		var environment = useRelayEnvironment();
		var profilerContext = useContext(ProfilerContext);
		var QueryResource = getQueryResourceForEnvironment(environment);
		var _useState = useState(0), forceUpdateKey = _useState[0], forceUpdate = _useState[1];
		var _useFetchTrackingRef = useFetchTrackingRef(), startFetch = _useFetchTrackingRef.startFetch, completeFetch = _useFetchTrackingRef.completeFetch;
		var cacheIdentifier = getQueryCacheIdentifier(environment, query, fetchPolicy, renderPolicy, "".concat(forceUpdateKey, "-").concat(fetchKey !== null && fetchKey !== void 0 ? fetchKey : ""));
		var preparedQueryResult = profilerContext.wrapPrepareQueryResource(function() {
			return QueryResource.prepareWithIdentifier(cacheIdentifier, query, fetchObservable, fetchPolicy, renderPolicy, {
				start: startFetch,
				complete: completeFetch,
				error: completeFetch
			}, profilerContext);
		});
		var maybeHiddenOrFastRefresh = useRef(false);
		useEffect(function() {
			return function() {
				maybeHiddenOrFastRefresh.current = true;
			};
		}, []);
		useEffect(function() {
			if (maybeHiddenOrFastRefresh.current === true) {
				maybeHiddenOrFastRefresh.current = false;
				forceUpdate(function(n) {
					return n + 1;
				});
				return;
			}
			var disposable = QueryResource.retain(preparedQueryResult, profilerContext);
			return function() {
				disposable.dispose();
			};
		}, [environment, cacheIdentifier]);
		useEffect(function() {
			QueryResource.releaseTemporaryRetain(preparedQueryResult);
		});
		var fragmentNode = preparedQueryResult.fragmentNode, fragmentRef = preparedQueryResult.fragmentRef;
		return useFragmentInternal(fragmentNode, fragmentRef, componentDisplayName);
	}
	module.exports = useLazyLoadQueryNode;
}));
var require_useMemoVariables = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var areEqual = require_areEqual();
	var useState$5 = __require("react").useState;
	function useMemoVariables(variables) {
		var _useState = useState$5(variables), mirroredVariables = _useState[0], setMirroredVariables = _useState[1];
		if (areEqual(variables, mirroredVariables)) return mirroredVariables;
		else {
			setMirroredVariables(variables);
			return variables;
		}
	}
	module.exports = useMemoVariables;
}));
var require_useMemoOperationDescriptor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useMemoVariables = require_useMemoVariables();
	var React$2 = __require("react");
	var _require = require_relay_runtime(), createOperationDescriptor = _require.createOperationDescriptor, getRequest = _require.getRequest;
	var useMemo = React$2.useMemo;
	function useMemoOperationDescriptor(gqlQuery, variables, cacheConfig) {
		var memoVariables = useMemoVariables(variables);
		var memoCacheConfig = useMemoVariables(cacheConfig || {});
		return useMemo(function() {
			return createOperationDescriptor(getRequest(gqlQuery), memoVariables, memoCacheConfig);
		}, [
			gqlQuery,
			memoVariables,
			memoCacheConfig
		]);
	}
	module.exports = useMemoOperationDescriptor;
}));
var require_useLazyLoadQuery = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useLazyLoadQueryNode = require_useLazyLoadQueryNode();
	var useMemoOperationDescriptor = require_useMemoOperationDescriptor();
	var useRelayEnvironment = require_useRelayEnvironment();
	var fetchQuery = require_relay_runtime().__internal.fetchQuery;
	function useLazyLoadQuery(gqlQuery, variables, options) {
		var environment = useRelayEnvironment();
		var query = useMemoOperationDescriptor(gqlQuery, variables, options && options.networkCacheConfig ? options.networkCacheConfig : { force: true });
		return useLazyLoadQueryNode({
			componentDisplayName: "useLazyLoadQuery()",
			fetchKey: options === null || options === void 0 ? void 0 : options.fetchKey,
			fetchObservable: fetchQuery(environment, query),
			fetchPolicy: options === null || options === void 0 ? void 0 : options.fetchPolicy,
			query,
			renderPolicy: options === null || options === void 0 ? void 0 : options.UNSTABLE_renderPolicy
		});
	}
	module.exports = useLazyLoadQuery;
}));
var require_useClientQuery = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var useLazyLoadQuery = require_useLazyLoadQuery();
	function useClientQuery(gqlQuery, variables, options) {
		return useLazyLoadQuery(gqlQuery, variables, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, options), {}, { fetchPolicy: "store-only" }));
	}
	module.exports = useClientQuery;
}));
var require_useIsMountedRef = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _require$6 = __require("react"), useEffect$6 = _require$6.useEffect, useRef$5 = _require$6.useRef;
	function useIsMountedRef() {
		var isMountedRef = useRef$5(true);
		useEffect$6(function() {
			isMountedRef.current = true;
			return function() {
				isMountedRef.current = false;
			};
		}, []);
		return isMountedRef;
	}
	module.exports = useIsMountedRef;
}));
var require_useEntryPointLoader = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var loadEntryPoint = require_loadEntryPoint();
	var useIsMountedRef = require_useIsMountedRef();
	var _require$5 = __require("react"), useCallback$7 = _require$5.useCallback, useEffect$5 = _require$5.useEffect, useRef$4 = _require$5.useRef, useState$4 = _require$5.useState;
	var initialNullEntryPointReferenceState = { kind: "NullEntryPointReference" };
	function useLoadEntryPoint(environmentProvider, entryPoint, options) {
		var _options$TEST_ONLY__i, _options$TEST_ONLY__i2, _options$TEST_ONLY__i3, _options$TEST_ONLY__i4;
		var initialEntryPointReferenceInternal = (_options$TEST_ONLY__i = options === null || options === void 0 ? void 0 : (_options$TEST_ONLY__i2 = options.TEST_ONLY__initialEntryPointData) === null || _options$TEST_ONLY__i2 === void 0 ? void 0 : _options$TEST_ONLY__i2.entryPointReference) !== null && _options$TEST_ONLY__i !== void 0 ? _options$TEST_ONLY__i : initialNullEntryPointReferenceState;
		var initialEntryPointParamsInternal = (_options$TEST_ONLY__i3 = options === null || options === void 0 ? void 0 : (_options$TEST_ONLY__i4 = options.TEST_ONLY__initialEntryPointData) === null || _options$TEST_ONLY__i4 === void 0 ? void 0 : _options$TEST_ONLY__i4.entryPointParams) !== null && _options$TEST_ONLY__i3 !== void 0 ? _options$TEST_ONLY__i3 : null;
		var isMountedRef = useIsMountedRef();
		var undisposedEntryPointReferencesRef = useRef$4(new Set([initialEntryPointReferenceInternal]));
		var _useState = useState$4(initialEntryPointReferenceInternal), entryPointReference = _useState[0], setEntryPointReference = _useState[1];
		var _useState2 = useState$4(initialEntryPointParamsInternal), entryPointParams = _useState2[0], setEntryPointParams = _useState2[1];
		var disposeEntryPoint = useCallback$7(function() {
			if (isMountedRef.current) {
				var nullEntryPointReference = { kind: "NullEntryPointReference" };
				undisposedEntryPointReferencesRef.current.add(nullEntryPointReference);
				setEntryPointReference(nullEntryPointReference);
			}
		}, [setEntryPointReference, isMountedRef]);
		var entryPointLoaderCallback = useCallback$7(function(params) {
			if (isMountedRef.current) {
				var updatedEntryPointReference = loadEntryPoint(environmentProvider, entryPoint, params);
				undisposedEntryPointReferencesRef.current.add(updatedEntryPointReference);
				setEntryPointReference(updatedEntryPointReference);
				setEntryPointParams(params);
			}
		}, [
			environmentProvider,
			entryPoint,
			setEntryPointReference,
			isMountedRef
		]);
		var maybeHiddenOrFastRefresh = useRef$4(false);
		useEffect$5(function() {
			return function() {
				maybeHiddenOrFastRefresh.current = true;
			};
		}, []);
		useEffect$5(function() {
			if (maybeHiddenOrFastRefresh.current === true) {
				maybeHiddenOrFastRefresh.current = false;
				if (entryPointReference.kind !== "NullEntryPointReference" && entryPointParams != null) entryPointLoaderCallback(entryPointParams);
				return;
			}
			var undisposedEntryPointReferences = undisposedEntryPointReferencesRef.current;
			if (isMountedRef.current) {
				var _iterator = (0, _createForOfIteratorHelper2["default"])(undisposedEntryPointReferences), _step;
				try {
					for (_iterator.s(); !(_step = _iterator.n()).done;) {
						var undisposedEntryPointReference = _step.value;
						if (undisposedEntryPointReference === entryPointReference) break;
						undisposedEntryPointReferences["delete"](undisposedEntryPointReference);
						if (undisposedEntryPointReference.kind !== "NullEntryPointReference") undisposedEntryPointReference.dispose();
					}
				} catch (err) {
					_iterator.e(err);
				} finally {
					_iterator.f();
				}
			}
		}, [
			entryPointReference,
			entryPointParams,
			entryPointLoaderCallback,
			isMountedRef
		]);
		useEffect$5(function() {
			return function disposeAllRemainingEntryPointReferences() {
				var _iterator2 = (0, _createForOfIteratorHelper2["default"])(undisposedEntryPointReferencesRef.current), _step2;
				try {
					for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
						var unhandledStateChange = _step2.value;
						if (unhandledStateChange.kind !== "NullEntryPointReference") unhandledStateChange.dispose();
					}
				} catch (err) {
					_iterator2.e(err);
				} finally {
					_iterator2.f();
				}
			};
		}, []);
		return [
			entryPointReference.kind === "NullEntryPointReference" ? null : entryPointReference,
			entryPointLoaderCallback,
			disposeEntryPoint
		];
	}
	module.exports = useLoadEntryPoint;
}));
var require_useStaticFragmentNodeWarning = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	require_useUnsafeRef_DEPRECATED();
	require_warning();
	function useStaticFragmentNodeWarning(fragmentNode, warningContext) {}
	module.exports = useStaticFragmentNodeWarning;
}));
var require_useFragment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useFragmentInternal = require_useFragmentInternal();
	var useStaticFragmentNodeWarning = require_useStaticFragmentNodeWarning();
	__require("react").useDebugValue;
	var getFragment = require_relay_runtime().getFragment;
	function useFragment(fragment, key) {
		var fragmentNode = getFragment(fragment);
		useStaticFragmentNodeWarning(fragmentNode, "first argument of useFragment()");
		return useFragmentInternal(fragmentNode, key, "useFragment()");
	}
	module.exports = useFragment;
}));
var require_useMutation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var useIsMountedRef = require_useIsMountedRef();
	var useRelayEnvironment = require_useRelayEnvironment();
	var React$1 = __require("react");
	var defaultCommitMutation = require_relay_runtime().commitMutation;
	var useState = React$1.useState, useEffect = React$1.useEffect, useRef = React$1.useRef, useCallback = React$1.useCallback;
	function useMutation(mutation) {
		var commitMutationFn = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : defaultCommitMutation;
		var environment = useRelayEnvironment();
		var isMountedRef = useIsMountedRef();
		var environmentRef = useRef(environment);
		var mutationRef = useRef(mutation);
		var inFlightMutationsRef = useRef(/* @__PURE__ */ new Set());
		var _useState = useState(false), isMutationInFlight = _useState[0], setMutationInFlight = _useState[1];
		var cleanup = useCallback(function(disposable) {
			if (environmentRef.current === environment && mutationRef.current === mutation) {
				inFlightMutationsRef.current["delete"](disposable);
				if (isMountedRef.current) setMutationInFlight(inFlightMutationsRef.current.size > 0);
			}
		}, [
			environment,
			isMountedRef,
			mutation
		]);
		useEffect(function() {
			if (environmentRef.current !== environment || mutationRef.current !== mutation) {
				inFlightMutationsRef.current = /* @__PURE__ */ new Set();
				if (isMountedRef.current) setMutationInFlight(false);
				environmentRef.current = environment;
				mutationRef.current = mutation;
			}
		}, [
			environment,
			isMountedRef,
			mutation
		]);
		return [useCallback(function(config) {
			if (isMountedRef.current) setMutationInFlight(true);
			var disposable = commitMutationFn(environment, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, config), {}, {
				mutation,
				onCompleted: function onCompleted(response, errors) {
					var _config$onCompleted;
					cleanup(disposable);
					(_config$onCompleted = config.onCompleted) === null || _config$onCompleted === void 0 || _config$onCompleted.call(config, response, errors);
				},
				onError: function onError(error) {
					var _config$onError;
					cleanup(disposable);
					(_config$onError = config.onError) === null || _config$onError === void 0 || _config$onError.call(config, error);
				},
				onUnsubscribe: function onUnsubscribe() {
					var _config$onUnsubscribe;
					cleanup(disposable);
					(_config$onUnsubscribe = config.onUnsubscribe) === null || _config$onUnsubscribe === void 0 || _config$onUnsubscribe.call(config);
				},
				onNext: function onNext() {
					var _config$onNext;
					(_config$onNext = config.onNext) === null || _config$onNext === void 0 || _config$onNext.call(config);
				}
			}));
			inFlightMutationsRef.current.add(disposable);
			return disposable;
		}, [
			cleanup,
			commitMutationFn,
			environment,
			isMountedRef,
			mutation
		]), isMutationInFlight];
	}
	module.exports = useMutation;
}));
var require_getConnectionState = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var invariant = require_invariant();
	var _require = require_relay_runtime(), ConnectionInterface = _require.ConnectionInterface, getValueAtPath = _require.getValueAtPath;
	function getConnectionState(direction, fragmentNode, fragmentData, connectionPathInFragmentData) {
		var _pageInfo$END_CURSOR, _pageInfo$START_CURSO;
		var _ConnectionInterface$ = ConnectionInterface.get(), EDGES = _ConnectionInterface$.EDGES, PAGE_INFO = _ConnectionInterface$.PAGE_INFO, HAS_NEXT_PAGE = _ConnectionInterface$.HAS_NEXT_PAGE, HAS_PREV_PAGE = _ConnectionInterface$.HAS_PREV_PAGE, END_CURSOR = _ConnectionInterface$.END_CURSOR, START_CURSOR = _ConnectionInterface$.START_CURSOR;
		var connection = getValueAtPath(fragmentData, connectionPathInFragmentData);
		if (connection == null) return {
			cursor: null,
			hasMore: false
		};
		!(typeof connection === "object") && invariant(false);
		var edges = connection[EDGES];
		var pageInfo = connection[PAGE_INFO];
		if (edges == null || pageInfo == null) return {
			cursor: null,
			hasMore: false
		};
		!Array.isArray(edges) && invariant(false);
		!(typeof pageInfo === "object") && invariant(false);
		var cursor = direction === "forward" ? (_pageInfo$END_CURSOR = pageInfo[END_CURSOR]) !== null && _pageInfo$END_CURSOR !== void 0 ? _pageInfo$END_CURSOR : null : (_pageInfo$START_CURSO = pageInfo[START_CURSOR]) !== null && _pageInfo$START_CURSO !== void 0 ? _pageInfo$START_CURSO : null;
		!(cursor === null || typeof cursor === "string") && invariant(false);
		var hasMore;
		if (direction === "forward") hasMore = cursor != null && pageInfo[HAS_NEXT_PAGE] === true;
		else hasMore = cursor != null && pageInfo[HAS_PREV_PAGE] === true;
		return {
			cursor,
			hasMore
		};
	}
	module.exports = getConnectionState;
}));
var require_useIsOperationNodeActive = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useRelayEnvironment = require_useRelayEnvironment();
	var invariant = require_invariant();
	var React = __require("react");
	var _require = require_relay_runtime(), getObservableForActiveRequest = _require.__internal.getObservableForActiveRequest, getSelector = _require.getSelector;
	var useEffect = React.useEffect, useState = React.useState, useMemo = React.useMemo;
	function useIsOperationNodeActive(fragmentNode, fragmentRef) {
		var environment = useRelayEnvironment();
		var observable = useMemo(function() {
			var selector = getSelector(fragmentNode, fragmentRef);
			if (selector == null) return null;
			!(selector.kind === "SingularReaderSelector") && invariant(false);
			return getObservableForActiveRequest(environment, selector.owner);
		}, [
			environment,
			fragmentNode,
			fragmentRef
		]);
		var _useState = useState(observable != null), isActive = _useState[0], setIsActive = _useState[1];
		useEffect(function() {
			var subscription;
			setIsActive(observable != null);
			if (observable != null) {
				var onCompleteOrError = function onCompleteOrError() {
					setIsActive(false);
				};
				subscription = observable.subscribe({
					complete: onCompleteOrError,
					error: onCompleteOrError
				});
			}
			return function() {
				if (subscription) subscription.unsubscribe();
			};
		}, [observable]);
		return isActive;
	}
	module.exports = useIsOperationNodeActive;
}));
var require_useLoadMoreFunction_EXPERIMENTAL = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var getConnectionState = require_getConnectionState();
	var useIsMountedRef = require_useIsMountedRef();
	var useIsOperationNodeActive = require_useIsOperationNodeActive();
	var useRelayEnvironment = require_useRelayEnvironment();
	var invariant = require_invariant();
	var _require$4 = __require("react"), useCallback$6 = _require$4.useCallback, useRef$3 = _require$4.useRef, useState$3 = _require$4.useState;
	var _require2 = require_relay_runtime(), fetchQuery = _require2.__internal.fetchQuery, createOperationDescriptor = _require2.createOperationDescriptor, getPaginationVariables = _require2.getPaginationVariables, getRefetchMetadata = _require2.getRefetchMetadata, getSelector = _require2.getSelector;
	require_warning();
	function useLoadMoreFunction_EXPERIMENTAL(args) {
		var direction = args.direction, fragmentNode = args.fragmentNode, fragmentRef = args.fragmentRef, fragmentIdentifier = args.fragmentIdentifier, fragmentData = args.fragmentData, connectionPathInFragmentData = args.connectionPathInFragmentData, paginationRequest = args.paginationRequest, paginationMetadata = args.paginationMetadata, componentDisplayName = args.componentDisplayName, observer = args.observer, onReset = args.onReset;
		var environment = useRelayEnvironment();
		var identifierInfo = getRefetchMetadata(fragmentNode, componentDisplayName).identifierInfo;
		var identifierValue = (identifierInfo === null || identifierInfo === void 0 ? void 0 : identifierInfo.identifierField) != null && fragmentData != null && typeof fragmentData === "object" ? fragmentData[identifierInfo.identifierField] : null;
		var fetchStatusRef = useRef$3({ kind: "none" });
		var _useState = useState$3(environment), mirroredEnvironment = _useState[0], setMirroredEnvironment = _useState[1];
		var _useState2 = useState$3(fragmentIdentifier), mirroredFragmentIdentifier = _useState2[0], setMirroredFragmentIdentifier = _useState2[1];
		var isParentQueryActive = useIsOperationNodeActive(fragmentNode, fragmentRef);
		var forceDisposeFn = useCallback$6(function() {
			if (fetchStatusRef.current.kind === "fetching") fetchStatusRef.current.subscription.unsubscribe();
			fetchStatusRef.current = { kind: "none" };
		}, []);
		if (environment !== mirroredEnvironment || fragmentIdentifier !== mirroredFragmentIdentifier) {
			forceDisposeFn();
			onReset();
			setMirroredEnvironment(environment);
			setMirroredFragmentIdentifier(fragmentIdentifier);
		}
		var _getConnectionState = getConnectionState(direction, fragmentNode, fragmentData, connectionPathInFragmentData), cursor = _getConnectionState.cursor, hasMore = _getConnectionState.hasMore;
		var isRequestInvalid = fragmentData == null || isParentQueryActive;
		var isMountedRef = useIsMountedRef();
		return [
			useCallback$6(function(count, options) {
				var onComplete = options === null || options === void 0 ? void 0 : options.onComplete;
				if (isMountedRef.current !== true) return { dispose: function dispose() {} };
				var fragmentSelector = getSelector(fragmentNode, fragmentRef);
				if (fetchStatusRef.current.kind === "fetching" || isRequestInvalid) {
					if (fragmentSelector == null) {}
					if (onComplete) onComplete(null);
					return { dispose: function dispose() {} };
				}
				!(fragmentSelector != null && fragmentSelector.kind !== "PluralReaderSelector") && invariant(false);
				var parentVariables = fragmentSelector.owner.variables;
				var fragmentVariables = fragmentSelector.variables;
				var extraVariables = options === null || options === void 0 ? void 0 : options.UNSTABLE_extraVariables;
				var paginationVariables = getPaginationVariables(direction, count, cursor, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, parentVariables), fragmentVariables), (0, _objectSpread2["default"])({}, extraVariables), paginationMetadata);
				if (identifierInfo != null) {
					if (typeof identifierValue !== "string") {}
					paginationVariables[identifierInfo.identifierQueryVariableName] = identifierValue;
				}
				fetchQuery(environment, createOperationDescriptor(paginationRequest, paginationVariables, { force: true })).subscribe((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, observer), {}, {
					start: function start(subscription) {
						fetchStatusRef.current = {
							kind: "fetching",
							subscription
						};
						observer.start && observer.start(subscription);
					},
					complete: function complete() {
						fetchStatusRef.current = { kind: "none" };
						observer.complete && observer.complete();
						onComplete && onComplete(null);
					},
					error: function error(_error) {
						fetchStatusRef.current = { kind: "none" };
						observer.complete && observer.complete();
						onComplete && onComplete(_error);
					}
				}));
				return { dispose: function dispose() {} };
			}, [
				environment,
				identifierValue,
				direction,
				cursor,
				isRequestInvalid,
				fragmentNode.name,
				fragmentRef,
				componentDisplayName
			]),
			hasMore,
			forceDisposeFn
		];
	}
	module.exports = useLoadMoreFunction_EXPERIMENTAL;
}));
var require_useLoadMoreFunction = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var getConnectionState = require_getConnectionState();
	var useFetchTrackingRef = require_useFetchTrackingRef();
	var useIsMountedRef = require_useIsMountedRef();
	var useIsOperationNodeActive = require_useIsOperationNodeActive();
	var useLoadMoreFunction_EXPERIMENTAL = require_useLoadMoreFunction_EXPERIMENTAL();
	var useRelayEnvironment = require_useRelayEnvironment();
	var invariant = require_invariant();
	var _require$3 = __require("react"), useCallback$5 = _require$3.useCallback, useEffect$4 = _require$3.useEffect, useState$2 = _require$3.useState;
	var _require2 = require_relay_runtime(), fetchQuery = _require2.__internal.fetchQuery, RelayFeatureFlags = _require2.RelayFeatureFlags, createOperationDescriptor = _require2.createOperationDescriptor, getPaginationVariables = _require2.getPaginationVariables, getRefetchMetadata = _require2.getRefetchMetadata, getSelector = _require2.getSelector;
	require_warning();
	function useLoadMoreFunction(args) {
		if (RelayFeatureFlags.ENABLE_ACTIVITY_COMPATIBILITY) return useLoadMoreFunction_EXPERIMENTAL(args);
		return useLoadMoreFunction_CURRENT(args);
	}
	function useLoadMoreFunction_CURRENT(args) {
		var direction = args.direction, fragmentNode = args.fragmentNode, fragmentRef = args.fragmentRef, fragmentIdentifier = args.fragmentIdentifier, fragmentData = args.fragmentData, connectionPathInFragmentData = args.connectionPathInFragmentData, paginationRequest = args.paginationRequest, paginationMetadata = args.paginationMetadata, componentDisplayName = args.componentDisplayName, observer = args.observer, onReset = args.onReset;
		var environment = useRelayEnvironment();
		var _useFetchTrackingRef = useFetchTrackingRef(), isFetchingRef = _useFetchTrackingRef.isFetchingRef, startFetch = _useFetchTrackingRef.startFetch, disposeFetch = _useFetchTrackingRef.disposeFetch, completeFetch = _useFetchTrackingRef.completeFetch;
		var identifierInfo = getRefetchMetadata(fragmentNode, componentDisplayName).identifierInfo;
		var identifierValue = (identifierInfo === null || identifierInfo === void 0 ? void 0 : identifierInfo.identifierField) != null && fragmentData != null && typeof fragmentData === "object" ? fragmentData[identifierInfo.identifierField] : null;
		var isMountedRef = useIsMountedRef();
		var _useState = useState$2(environment), mirroredEnvironment = _useState[0], setMirroredEnvironment = _useState[1];
		var _useState2 = useState$2(fragmentIdentifier), mirroredFragmentIdentifier = _useState2[0], setMirroredFragmentIdentifier = _useState2[1];
		var isParentQueryActive = useIsOperationNodeActive(fragmentNode, fragmentRef);
		if (environment !== mirroredEnvironment || fragmentIdentifier !== mirroredFragmentIdentifier) {
			disposeFetch();
			onReset();
			setMirroredEnvironment(environment);
			setMirroredFragmentIdentifier(fragmentIdentifier);
		}
		var _getConnectionState = getConnectionState(direction, fragmentNode, fragmentData, connectionPathInFragmentData), cursor = _getConnectionState.cursor, hasMore = _getConnectionState.hasMore;
		useEffect$4(function() {
			return function() {
				disposeFetch();
			};
		}, [disposeFetch]);
		var isRequestInvalid = fragmentData == null || isParentQueryActive;
		return [
			useCallback$5(function(count, options) {
				var onComplete = options === null || options === void 0 ? void 0 : options.onComplete;
				if (isMountedRef.current !== true) return { dispose: function dispose() {} };
				var fragmentSelector = getSelector(fragmentNode, fragmentRef);
				if (isFetchingRef.current === true || isRequestInvalid) {
					if (fragmentSelector == null) {}
					if (onComplete) onComplete(null);
					return { dispose: function dispose() {} };
				}
				!(fragmentSelector != null && fragmentSelector.kind !== "PluralReaderSelector") && invariant(false);
				var parentVariables = fragmentSelector.owner.variables;
				var fragmentVariables = fragmentSelector.variables;
				var extraVariables = options === null || options === void 0 ? void 0 : options.UNSTABLE_extraVariables;
				var paginationVariables = getPaginationVariables(direction, count, cursor, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, parentVariables), fragmentVariables), (0, _objectSpread2["default"])({}, extraVariables), paginationMetadata);
				if (identifierInfo != null) {
					if (typeof identifierValue !== "string") {}
					paginationVariables[identifierInfo.identifierQueryVariableName] = identifierValue;
				}
				fetchQuery(environment, createOperationDescriptor(paginationRequest, paginationVariables, { force: true })).subscribe((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, observer), {}, {
					start: function start(subscription) {
						startFetch(subscription);
						observer.start && observer.start(subscription);
					},
					complete: function complete() {
						completeFetch();
						observer.complete && observer.complete();
						onComplete && onComplete(null);
					},
					error: function error(_error) {
						completeFetch();
						observer.error && observer.error(_error);
						onComplete && onComplete(_error);
					}
				}));
				return { dispose: disposeFetch };
			}, [
				environment,
				identifierValue,
				direction,
				cursor,
				startFetch,
				disposeFetch,
				completeFetch,
				isFetchingRef,
				isRequestInvalid,
				fragmentNode.name,
				fragmentRef,
				componentDisplayName
			]),
			hasMore,
			disposeFetch
		];
	}
	module.exports = useLoadMoreFunction;
}));
var require_readFragmentInternal = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var getQueryResourceForEnvironment = require_QueryResource().getQueryResourceForEnvironment;
	var invariant = require_invariant();
	var _require2 = require_relay_runtime(), fetchQueryInternal = _require2.__internal.fetchQuery, RelayFeatureFlags = _require2.RelayFeatureFlags, createOperationDescriptor = _require2.createOperationDescriptor, getPendingOperationsForFragment = _require2.getPendingOperationsForFragment, getSelector = _require2.getSelector, getVariablesFromFragment = _require2.getVariablesFromFragment, handlePotentialSnapshotErrors = _require2.handlePotentialSnapshotErrors;
	require_warning();
	function isMissingData(state) {
		if (state.kind === "bailout") return false;
		else if (state.kind === "singular") return state.snapshot.isMissingData;
		else return state.snapshots.some(function(s) {
			return s.isMissingData;
		});
	}
	function getMissingClientEdges(state) {
		if (state.kind === "bailout") return null;
		else if (state.kind === "singular") {
			var _state$snapshot$missi;
			return (_state$snapshot$missi = state.snapshot.missingClientEdges) !== null && _state$snapshot$missi !== void 0 ? _state$snapshot$missi : null;
		} else {
			var edges = null;
			var _iterator = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var snapshot = _step.value;
					if (snapshot.missingClientEdges) {
						var _edges;
						edges = (_edges = edges) !== null && _edges !== void 0 ? _edges : [];
						var _iterator2 = (0, _createForOfIteratorHelper2["default"])(snapshot.missingClientEdges), _step2;
						try {
							for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
								var edge = _step2.value;
								edges.push(edge);
							}
						} catch (err) {
							_iterator2.e(err);
						} finally {
							_iterator2.f();
						}
					}
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
			return edges;
		}
	}
	function handlePotentialSnapshotErrorsForState(environment, state) {
		if (state.kind === "singular") handlePotentialSnapshotErrors(environment, state.snapshot.fieldErrors);
		else if (state.kind === "plural") {
			var _iterator3 = (0, _createForOfIteratorHelper2["default"])(state.snapshots), _step3;
			try {
				for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
					var snapshot = _step3.value;
					handlePotentialSnapshotErrors(environment, snapshot.fieldErrors);
				}
			} catch (err) {
				_iterator3.e(err);
			} finally {
				_iterator3.f();
			}
		}
	}
	function handleMissingClientEdge(environment, parentFragmentNode, parentFragmentRef, missingClientEdgeRequestInfo, queryOptions) {
		var originalVariables = getVariablesFromFragment(parentFragmentNode, parentFragmentRef);
		var variables = (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, originalVariables), {}, { id: missingClientEdgeRequestInfo.clientEdgeDestinationID });
		var queryOperationDescriptor = createOperationDescriptor(missingClientEdgeRequestInfo.request, variables, queryOptions === null || queryOptions === void 0 ? void 0 : queryOptions.networkCacheConfig);
		return getQueryResourceForEnvironment(environment).prepare(queryOperationDescriptor, fetchQueryInternal(environment, queryOperationDescriptor), queryOptions === null || queryOptions === void 0 ? void 0 : queryOptions.fetchPolicy);
	}
	function getFragmentState(environment, fragmentSelector) {
		if (fragmentSelector == null) return { kind: "bailout" };
		else if (fragmentSelector.kind === "PluralReaderSelector") if (fragmentSelector.selectors.length === 0) return { kind: "bailout" };
		else return {
			kind: "plural",
			snapshots: fragmentSelector.selectors.map(function(s) {
				return environment.lookup(s);
			}),
			epoch: environment.getStore().getEpoch()
		};
		else return {
			kind: "singular",
			snapshot: environment.lookup(fragmentSelector),
			epoch: environment.getStore().getEpoch()
		};
	}
	function readFragmentInternal(environment, fragmentNode, fragmentRef, hookDisplayName, queryOptions, fragmentKey) {
		var _fragmentNode$metadat, _fragmentNode$metadat2;
		var fragmentSelector = getSelector(fragmentNode, fragmentRef);
		var isPlural = (fragmentNode === null || fragmentNode === void 0 ? void 0 : (_fragmentNode$metadat = fragmentNode.metadata) === null || _fragmentNode$metadat === void 0 ? void 0 : _fragmentNode$metadat.plural) === true;
		if (isPlural) !(fragmentRef == null || Array.isArray(fragmentRef)) && invariant(false);
		else Array.isArray(fragmentRef) && invariant(false);
		!(fragmentRef == null || isPlural && Array.isArray(fragmentRef) && fragmentRef.length === 0 || fragmentSelector != null) && invariant(false);
		var state = getFragmentState(environment, fragmentSelector);
		var clientEdgeQueries = null;
		if (((_fragmentNode$metadat2 = fragmentNode.metadata) === null || _fragmentNode$metadat2 === void 0 ? void 0 : _fragmentNode$metadat2.hasClientEdges) === true || RelayFeatureFlags.CHECK_ALL_FRAGMENTS_FOR_MISSING_CLIENT_EDGES) {
			var missingClientEdges = getMissingClientEdges(state);
			if (missingClientEdges !== null && missingClientEdges !== void 0 && missingClientEdges.length) {
				clientEdgeQueries = [];
				var _iterator4 = (0, _createForOfIteratorHelper2["default"])(missingClientEdges), _step4;
				try {
					for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
						var edge = _step4.value;
						clientEdgeQueries.push(handleMissingClientEdge(environment, fragmentNode, fragmentRef, edge, queryOptions));
					}
				} catch (err) {
					_iterator4.e(err);
				} finally {
					_iterator4.f();
				}
			}
		}
		if (isMissingData(state)) {
			!(fragmentSelector != null) && invariant(false);
			var pendingOperationsResult = getPendingOperationsForFragment(environment, fragmentNode, fragmentSelector.kind === "PluralReaderSelector" ? fragmentSelector.selectors[0].owner : fragmentSelector.owner);
			if (pendingOperationsResult) throw pendingOperationsResult.promise;
			handlePotentialSnapshotErrorsForState(environment, state);
		}
		var data;
		if (state.kind === "bailout") data = isPlural ? [] : null;
		else if (state.kind === "singular") data = state.snapshot.data;
		else data = state.snapshots.map(function(s) {
			return s.data;
		});
		if (RelayFeatureFlags.LOG_MISSING_RECORDS_IN_PROD || false) {
			if (fragmentRef != null && (data === void 0 || Array.isArray(data) && data.length > 0 && data.every(function(d) {
				return d === void 0;
			}))) {}
		}
		return {
			data,
			clientEdgeQueries
		};
	}
	module.exports = readFragmentInternal;
}));
var require_useQueryLoader_EXPERIMENTAL = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var loadQuery = require_loadQuery().loadQuery;
	var useIsMountedRef = require_useIsMountedRef();
	var useRelayEnvironment = require_useRelayEnvironment();
	var _require2$2 = __require("react"), useCallback$4 = _require2$2.useCallback, useEffect$3 = _require2$2.useEffect, useInsertionEffect = _require2$2.useInsertionEffect, useRef$2 = _require2$2.useRef, useState$1 = _require2$2.useState;
	var getRequest = require_relay_runtime().getRequest;
	var initialNullQueryReferenceState = { kind: "NullQueryReference" };
	function requestIsLiveQuery(preloadableRequest) {
		if (preloadableRequest.kind === "PreloadableConcreteRequest") return preloadableRequest.params.metadata.live !== void 0;
		return getRequest(preloadableRequest).params.metadata.live !== void 0;
	}
	var CLEANUP_TIMEOUT = 1e3 * 60 * 5;
	function useQueryLoader_EXPERIMENTAL(preloadableRequest, initialQueryReference) {
		var initialQueryReferenceInternal = initialQueryReference !== null && initialQueryReference !== void 0 ? initialQueryReference : initialNullQueryReferenceState;
		var environment = useRelayEnvironment();
		var isMountedRef = useIsMountedRef();
		var undisposedQueryReferencesRef = useRef$2(null);
		if (undisposedQueryReferencesRef.current == null) undisposedQueryReferencesRef.current = new Set([initialQueryReferenceInternal]);
		var _useState = useState$1(function() {
			return initialQueryReferenceInternal;
		}), queryReference = _useState[0], setQueryReference = _useState[1];
		var _useState2 = useState$1(function() {
			return initialQueryReferenceInternal;
		}), previousInitialQueryReference = _useState2[0], setPreviousInitialQueryReference = _useState2[1];
		if (initialQueryReferenceInternal !== previousInitialQueryReference) {
			var _undisposedQueryRefer;
			(_undisposedQueryRefer = undisposedQueryReferencesRef.current) === null || _undisposedQueryRefer === void 0 || _undisposedQueryRefer.add(initialQueryReferenceInternal);
			setPreviousInitialQueryReference(initialQueryReferenceInternal);
			setQueryReference(initialQueryReferenceInternal);
		}
		var disposeQuery = useCallback$4(function() {
			if (isMountedRef.current) {
				var _undisposedQueryRefer2;
				(_undisposedQueryRefer2 = undisposedQueryReferencesRef.current) === null || _undisposedQueryRefer2 === void 0 || _undisposedQueryRefer2.add(initialNullQueryReferenceState);
				setQueryReference(initialNullQueryReferenceState);
			}
		}, [isMountedRef]);
		var queryLoaderCallback = useCallback$4(function(variables, options) {
			var _options$__environmen, _undisposedQueryRefer3;
			if (!isMountedRef.current) return;
			var mergedOptions = options != null && options.hasOwnProperty("__environment") ? {
				fetchPolicy: options.fetchPolicy,
				networkCacheConfig: options.networkCacheConfig,
				__nameForWarning: options.__nameForWarning
			} : options;
			var updatedQueryReference = loadQuery((_options$__environmen = options === null || options === void 0 ? void 0 : options.__environment) !== null && _options$__environmen !== void 0 ? _options$__environmen : environment, preloadableRequest, variables, mergedOptions);
			(_undisposedQueryRefer3 = undisposedQueryReferencesRef.current) === null || _undisposedQueryRefer3 === void 0 || _undisposedQueryRefer3.add(updatedQueryReference);
			setQueryReference(updatedQueryReference);
		}, [
			environment,
			preloadableRequest,
			setQueryReference,
			isMountedRef
		]);
		var disposeAllRemainingQueryReferences = useCallback$4(function disposeAllRemainingQueryReferences(preloadableRequest, currentQueryReference) {
			var _undisposedQueryRefer4;
			var undisposedQueryReferences = (_undisposedQueryRefer4 = undisposedQueryReferencesRef.current) !== null && _undisposedQueryRefer4 !== void 0 ? _undisposedQueryRefer4 : /* @__PURE__ */ new Set();
			var _iterator = (0, _createForOfIteratorHelper2["default"])(undisposedQueryReferences), _step;
			try {
				for (_iterator.s(); !(_step = _iterator.n()).done;) {
					var undisposedQueryReference = _step.value;
					if (undisposedQueryReference === currentQueryReference) continue;
					if (undisposedQueryReference.kind !== "NullQueryReference") if (requestIsLiveQuery(preloadableRequest)) undisposedQueryReference.dispose && undisposedQueryReference.dispose();
					else undisposedQueryReference.releaseQuery && undisposedQueryReference.releaseQuery();
				}
			} catch (err) {
				_iterator.e(err);
			} finally {
				_iterator.f();
			}
		}, []);
		var cleanupTimerRef = useRef$2(null);
		useEffect$3(function() {
			disposeAllRemainingQueryReferences(preloadableRequest, queryReference);
			if (cleanupTimerRef.current != null) {
				clearTimeout(cleanupTimerRef.current);
				cleanupTimerRef.current = null;
			}
			return function() {
				cleanupTimerRef.current = setTimeout(function() {
					disposeAllRemainingQueryReferences(preloadableRequest, null);
				}, CLEANUP_TIMEOUT);
			};
		}, [preloadableRequest, queryReference]);
		useInsertionEffect(function() {
			return function() {
				cleanupTimerRef.current && clearTimeout(cleanupTimerRef.current);
				cleanupTimerRef.current = null;
				disposeAllRemainingQueryReferences(preloadableRequest, null);
			};
		}, [preloadableRequest]);
		return [
			queryReference.kind === "NullQueryReference" ? null : queryReference,
			queryLoaderCallback,
			disposeQuery
		];
	}
	module.exports = useQueryLoader_EXPERIMENTAL;
}));
var require_useQueryLoader = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _createForOfIteratorHelper2 = _interopRequireDefault(require_createForOfIteratorHelper());
	var loadQuery = require_loadQuery().loadQuery;
	var useIsMountedRef = require_useIsMountedRef();
	var useQueryLoader_EXPERIMENTAL = require_useQueryLoader_EXPERIMENTAL();
	var useRelayEnvironment = require_useRelayEnvironment();
	var _require2$1 = __require("react"), useCallback$3 = _require2$1.useCallback, useEffect$2 = _require2$1.useEffect, useRef$1 = _require2$1.useRef, useState = _require2$1.useState;
	var _require3 = require_relay_runtime(), RelayFeatureFlags = _require3.RelayFeatureFlags, getRequest = _require3.getRequest;
	var initialNullQueryReferenceState = { kind: "NullQueryReference" };
	function requestIsLiveQuery(preloadableRequest) {
		if (preloadableRequest.kind === "PreloadableConcreteRequest") return preloadableRequest.params.metadata.live !== void 0;
		return getRequest(preloadableRequest).params.metadata.live !== void 0;
	}
	function useQueryLoader(preloadableRequest, initialQueryReference) {
		if (RelayFeatureFlags.ENABLE_ACTIVITY_COMPATIBILITY) return useQueryLoader_EXPERIMENTAL(preloadableRequest, initialQueryReference);
		return useQueryLoader_CURRENT(preloadableRequest, initialQueryReference);
	}
	function useQueryLoader_CURRENT(preloadableRequest, initialQueryReference) {
		var initialQueryReferenceInternal = initialQueryReference !== null && initialQueryReference !== void 0 ? initialQueryReference : initialNullQueryReferenceState;
		var environment = useRelayEnvironment();
		var isMountedRef = useIsMountedRef();
		var undisposedQueryReferencesRef = useRef$1(new Set([initialQueryReferenceInternal]));
		var _useState = useState(function() {
			return initialQueryReferenceInternal;
		}), queryReference = _useState[0], setQueryReference = _useState[1];
		var _useState2 = useState(function() {
			return initialQueryReferenceInternal;
		}), previousInitialQueryReference = _useState2[0], setPreviousInitialQueryReference = _useState2[1];
		if (initialQueryReferenceInternal !== previousInitialQueryReference) {
			undisposedQueryReferencesRef.current.add(initialQueryReferenceInternal);
			setPreviousInitialQueryReference(initialQueryReferenceInternal);
			setQueryReference(initialQueryReferenceInternal);
		}
		var disposeQuery = useCallback$3(function() {
			if (isMountedRef.current) {
				undisposedQueryReferencesRef.current.add(initialNullQueryReferenceState);
				setQueryReference(initialNullQueryReferenceState);
			}
		}, [isMountedRef]);
		var queryLoaderCallback = useCallback$3(function(variables, options) {
			var mergedOptions = options != null && options.hasOwnProperty("__environment") ? {
				fetchPolicy: options.fetchPolicy,
				networkCacheConfig: options.networkCacheConfig,
				__nameForWarning: options.__nameForWarning
			} : options;
			if (isMountedRef.current) {
				var _options$__environmen;
				var updatedQueryReference = loadQuery((_options$__environmen = options === null || options === void 0 ? void 0 : options.__environment) !== null && _options$__environmen !== void 0 ? _options$__environmen : environment, preloadableRequest, variables, mergedOptions);
				undisposedQueryReferencesRef.current.add(updatedQueryReference);
				setQueryReference(updatedQueryReference);
			}
		}, [
			environment,
			preloadableRequest,
			setQueryReference,
			isMountedRef
		]);
		var maybeHiddenOrFastRefresh = useRef$1(false);
		useEffect$2(function() {
			return function() {
				maybeHiddenOrFastRefresh.current = true;
			};
		}, []);
		useEffect$2(function() {
			if (maybeHiddenOrFastRefresh.current === true) {
				maybeHiddenOrFastRefresh.current = false;
				if (queryReference.kind !== "NullQueryReference") queryLoaderCallback(queryReference.variables, {
					fetchPolicy: queryReference.fetchPolicy,
					networkCacheConfig: queryReference.networkCacheConfig
				});
				return;
			}
			var undisposedQueryReferences = undisposedQueryReferencesRef.current;
			if (isMountedRef.current) {
				var _iterator = (0, _createForOfIteratorHelper2["default"])(undisposedQueryReferences), _step;
				try {
					for (_iterator.s(); !(_step = _iterator.n()).done;) {
						var undisposedQueryReference = _step.value;
						if (undisposedQueryReference === queryReference) break;
						undisposedQueryReferences["delete"](undisposedQueryReference);
						if (undisposedQueryReference.kind !== "NullQueryReference") if (requestIsLiveQuery(preloadableRequest)) undisposedQueryReference.dispose && undisposedQueryReference.dispose();
						else undisposedQueryReference.releaseQuery && undisposedQueryReference.releaseQuery();
					}
				} catch (err) {
					_iterator.e(err);
				} finally {
					_iterator.f();
				}
			}
		}, [
			queryReference,
			isMountedRef,
			queryLoaderCallback,
			preloadableRequest
		]);
		useEffect$2(function() {
			return function disposeAllRemainingQueryReferences() {
				var _iterator2 = (0, _createForOfIteratorHelper2["default"])(undisposedQueryReferencesRef.current), _step2;
				try {
					for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
						var undisposedQueryReference = _step2.value;
						if (undisposedQueryReference.kind !== "NullQueryReference") if (requestIsLiveQuery(preloadableRequest)) undisposedQueryReference.dispose && undisposedQueryReference.dispose();
						else undisposedQueryReference.releaseQuery && undisposedQueryReference.releaseQuery();
					}
				} catch (err) {
					_iterator2.e(err);
				} finally {
					_iterator2.f();
				}
			};
		}, [preloadableRequest]);
		return [
			queryReference.kind === "NullQueryReference" ? null : queryReference,
			queryLoaderCallback,
			disposeQuery
		];
	}
	module.exports = useQueryLoader;
}));
var require_useRefetchableFragmentInternal = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var ProfilerContext = require_ProfilerContext();
	var getQueryResourceForEnvironment = require_QueryResource().getQueryResourceForEnvironment;
	var readFragmentInternal = require_readFragmentInternal();
	var useFragmentInternal = require_useFragmentInternal();
	var useIsMountedRef = require_useIsMountedRef();
	var useQueryLoader = require_useQueryLoader();
	var useRelayEnvironment = require_useRelayEnvironment();
	var invariant = require_invariant();
	var _require2 = __require("react"), useCallback$2 = _require2.useCallback, useContext = _require2.useContext, useReducer = _require2.useReducer;
	var _require3 = require_relay_runtime(), fetchQuery = _require3.__internal.fetchQuery, createOperationDescriptor = _require3.createOperationDescriptor, getFragmentIdentifier = _require3.getFragmentIdentifier, getRefetchMetadata = _require3.getRefetchMetadata, getSelector = _require3.getSelector, getValueAtPath = _require3.getValueAtPath;
	require_warning();
	function reducer(state, action) {
		switch (action.type) {
			case "refetch":
				var _action$refetchEnviro;
				return (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, state), {}, {
					fetchPolicy: action.fetchPolicy,
					mirroredEnvironment: (_action$refetchEnviro = action.refetchEnvironment) !== null && _action$refetchEnviro !== void 0 ? _action$refetchEnviro : state.mirroredEnvironment,
					onComplete: action.onComplete,
					refetchEnvironment: action.refetchEnvironment,
					refetchQuery: action.refetchQuery,
					renderPolicy: action.renderPolicy
				});
			case "reset": return {
				fetchPolicy: void 0,
				mirroredEnvironment: action.environment,
				mirroredFragmentIdentifier: action.fragmentIdentifier,
				onComplete: void 0,
				refetchQuery: null,
				renderPolicy: void 0
			};
			default:
				action.type;
				throw new Error("useRefetchableFragmentNode: Unexpected action type");
		}
	}
	function useRefetchableFragmentInternal(fragmentNode, parentFragmentRef, componentDisplayName) {
		var parentEnvironment = useRelayEnvironment();
		var _getRefetchMetadata = getRefetchMetadata(fragmentNode, componentDisplayName), refetchableRequest = _getRefetchMetadata.refetchableRequest, fragmentRefPathInResponse = _getRefetchMetadata.fragmentRefPathInResponse, identifierInfo = _getRefetchMetadata.identifierInfo;
		var fragmentIdentifier = getFragmentIdentifier(fragmentNode, parentFragmentRef);
		var _useReducer = useReducer(reducer, {
			fetchPolicy: void 0,
			mirroredEnvironment: parentEnvironment,
			mirroredFragmentIdentifier: fragmentIdentifier,
			onComplete: void 0,
			refetchEnvironment: null,
			refetchQuery: null,
			renderPolicy: void 0
		}), refetchState = _useReducer[0], dispatch = _useReducer[1];
		var fetchPolicy = refetchState.fetchPolicy, mirroredEnvironment = refetchState.mirroredEnvironment, mirroredFragmentIdentifier = refetchState.mirroredFragmentIdentifier, onComplete = refetchState.onComplete, refetchEnvironment = refetchState.refetchEnvironment, refetchQuery = refetchState.refetchQuery, renderPolicy = refetchState.renderPolicy;
		var environment = refetchEnvironment !== null && refetchEnvironment !== void 0 ? refetchEnvironment : parentEnvironment;
		var QueryResource = getQueryResourceForEnvironment(environment);
		var profilerContext = useContext(ProfilerContext);
		var shouldReset = environment !== mirroredEnvironment || fragmentIdentifier !== mirroredFragmentIdentifier;
		var _useQueryLoader = useQueryLoader(refetchableRequest), queryRef = _useQueryLoader[0], loadQuery = _useQueryLoader[1], disposeQuery = _useQueryLoader[2];
		var fragmentRef = parentFragmentRef;
		if (shouldReset) {
			dispatch({
				type: "reset",
				environment,
				fragmentIdentifier
			});
			disposeQuery();
		} else if (refetchQuery != null && queryRef != null) {
			var handleQueryCompleted = function handleQueryCompleted(maybeError) {
				onComplete && onComplete(maybeError !== null && maybeError !== void 0 ? maybeError : null);
			};
			var fetchObservable = queryRef.source != null ? queryRef.source : fetchQuery(environment, refetchQuery);
			var queryResult = profilerContext.wrapPrepareQueryResource(function() {
				return QueryResource.prepare(refetchQuery, fetchObservable, fetchPolicy, renderPolicy, {
					error: handleQueryCompleted,
					complete: function complete() {
						handleQueryCompleted();
					}
				}, queryRef.fetchKey, profilerContext);
			});
			var queryData = readFragmentInternal(environment, queryResult.fragmentNode, queryResult.fragmentRef, componentDisplayName).data;
			!(queryData != null) && invariant(false);
			fragmentRef = getValueAtPath(queryData, fragmentRefPathInResponse);
		}
		var fragmentData = useFragmentInternal(fragmentNode, fragmentRef, componentDisplayName);
		var refetch = useRefetchFunction(componentDisplayName, dispatch, disposeQuery, fragmentData, fragmentIdentifier, fragmentNode, fragmentRefPathInResponse, identifierInfo, loadQuery, parentFragmentRef, refetchableRequest);
		return {
			fragmentData,
			fragmentRef,
			refetch
		};
	}
	function useRefetchFunction(componentDisplayName, dispatch, disposeQuery, fragmentData, fragmentIdentifier, fragmentNode, fragmentRefPathInResponse, identifierInfo, loadQuery, parentFragmentRef, refetchableRequest) {
		var isMountedRef = useIsMountedRef();
		var identifierValue = (identifierInfo === null || identifierInfo === void 0 ? void 0 : identifierInfo.identifierField) != null && fragmentData != null && typeof fragmentData === "object" ? fragmentData[identifierInfo.identifierField] : null;
		return useCallback$2(function(providedRefetchVariables, options) {
			if (isMountedRef.current !== true) return { dispose: function dispose() {} };
			if (parentFragmentRef == null) {}
			var refetchEnvironment = options === null || options === void 0 ? void 0 : options.__environment;
			var fetchPolicy = options === null || options === void 0 ? void 0 : options.fetchPolicy;
			var renderPolicy = options === null || options === void 0 ? void 0 : options.UNSTABLE_renderPolicy;
			var onComplete = options === null || options === void 0 ? void 0 : options.onComplete;
			var fragmentSelector = getSelector(fragmentNode, parentFragmentRef);
			var parentVariables;
			var fragmentVariables;
			if (fragmentSelector == null) {
				parentVariables = {};
				fragmentVariables = {};
			} else if (fragmentSelector.kind === "PluralReaderSelector") {
				var _fragmentSelector$sel, _fragmentSelector$sel2, _fragmentSelector$sel3, _fragmentSelector$sel4;
				parentVariables = (_fragmentSelector$sel = (_fragmentSelector$sel2 = fragmentSelector.selectors[0]) === null || _fragmentSelector$sel2 === void 0 ? void 0 : _fragmentSelector$sel2.owner.variables) !== null && _fragmentSelector$sel !== void 0 ? _fragmentSelector$sel : {};
				fragmentVariables = (_fragmentSelector$sel3 = (_fragmentSelector$sel4 = fragmentSelector.selectors[0]) === null || _fragmentSelector$sel4 === void 0 ? void 0 : _fragmentSelector$sel4.variables) !== null && _fragmentSelector$sel3 !== void 0 ? _fragmentSelector$sel3 : {};
			} else {
				parentVariables = fragmentSelector.owner.variables;
				fragmentVariables = fragmentSelector.variables;
			}
			var refetchVariables = (0, _objectSpread2["default"])((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, parentVariables), fragmentVariables), providedRefetchVariables);
			if (identifierInfo != null && !providedRefetchVariables.hasOwnProperty(identifierInfo.identifierQueryVariableName)) {
				if (typeof identifierValue !== "string") {}
				refetchVariables[identifierInfo.identifierQueryVariableName] = identifierValue;
			}
			var refetchQuery = createOperationDescriptor(refetchableRequest, refetchVariables, { force: true });
			loadQuery(refetchQuery.request.variables, {
				fetchPolicy,
				__environment: refetchEnvironment,
				__nameForWarning: "refetch"
			});
			dispatch({
				type: "refetch",
				fetchPolicy,
				onComplete,
				refetchEnvironment,
				refetchQuery,
				renderPolicy
			});
			return { dispose: disposeQuery };
		}, [
			fragmentIdentifier,
			dispatch,
			disposeQuery,
			identifierValue,
			loadQuery
		]);
	}
	module.exports = useRefetchableFragmentInternal;
}));
var require_usePaginationFragment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var useLoadMoreFunction = require_useLoadMoreFunction();
	var useRefetchableFragmentInternal = require_useRefetchableFragmentInternal();
	var useRelayEnvironment = require_useRelayEnvironment();
	var useStaticFragmentNodeWarning = require_useStaticFragmentNodeWarning(), _require$2 = __require("react"), useCallback$1 = _require$2.useCallback;
	_require$2.useDebugValue;
	var useState = _require$2.useState;
	var _require2 = require_relay_runtime(), RelayFeatureFlags = _require2.RelayFeatureFlags, getFragment = _require2.getFragment, getFragmentIdentifier = _require2.getFragmentIdentifier, getPaginationMetadata = _require2.getPaginationMetadata;
	function usePaginationFragment(fragmentInput, parentFragmentRef) {
		var fragmentNode = getFragment(fragmentInput);
		useStaticFragmentNodeWarning(fragmentNode, "first argument of usePaginationFragment()");
		var componentDisplayName = "usePaginationFragment()";
		var _getPaginationMetadat = getPaginationMetadata(fragmentNode, componentDisplayName), connectionPathInFragmentData = _getPaginationMetadat.connectionPathInFragmentData, paginationRequest = _getPaginationMetadat.paginationRequest, paginationMetadata = _getPaginationMetadat.paginationMetadata;
		var _useRefetchableFragme = useRefetchableFragmentInternal(fragmentNode, parentFragmentRef, componentDisplayName), fragmentData = _useRefetchableFragme.fragmentData, fragmentRef = _useRefetchableFragme.fragmentRef, refetch = _useRefetchableFragme.refetch;
		var fragmentIdentifier = getFragmentIdentifier(fragmentNode, fragmentRef);
		var _useLoadMore = useLoadMore({
			componentDisplayName,
			connectionPathInFragmentData,
			direction: "backward",
			fragmentData,
			fragmentIdentifier,
			fragmentNode,
			fragmentRef,
			paginationMetadata,
			paginationRequest
		}), loadPrevious = _useLoadMore[0], hasPrevious = _useLoadMore[1], isLoadingPrevious = _useLoadMore[2], disposeFetchPrevious = _useLoadMore[3];
		var _useLoadMore2 = useLoadMore({
			componentDisplayName,
			connectionPathInFragmentData,
			direction: "forward",
			fragmentData,
			fragmentIdentifier,
			fragmentNode,
			fragmentRef,
			paginationMetadata,
			paginationRequest
		}), loadNext = _useLoadMore2[0], hasNext = _useLoadMore2[1], isLoadingNext = _useLoadMore2[2], disposeFetchNext = _useLoadMore2[3];
		return {
			data: fragmentData,
			loadNext,
			loadPrevious,
			hasNext,
			hasPrevious,
			isLoadingNext,
			isLoadingPrevious,
			refetch: useCallback$1(function(variables, options) {
				disposeFetchNext();
				disposeFetchPrevious();
				return refetch(variables, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, options), {}, { __environment: void 0 }));
			}, [
				disposeFetchNext,
				disposeFetchPrevious,
				refetch
			])
		};
	}
	function useLoadMore(args) {
		var environment = useRelayEnvironment();
		var _useState = useState(false), isLoadingMore = _useState[0], reallySetIsLoadingMore = _useState[1];
		var setIsLoadingMore = function setIsLoadingMore(value) {
			var _environment$getSched;
			var schedule = (_environment$getSched = environment.getScheduler()) === null || _environment$getSched === void 0 ? void 0 : _environment$getSched.schedule;
			if (schedule) schedule(function() {
				reallySetIsLoadingMore(value);
			});
			else reallySetIsLoadingMore(value);
		};
		var observer = {
			start: function start() {
				return setIsLoadingMore(true);
			},
			complete: function complete() {
				return setIsLoadingMore(false);
			},
			error: function error() {
				return setIsLoadingMore(false);
			},
			unsubscribe: RelayFeatureFlags.ENABLE_USE_PAGINATION_IS_LOADING_FIX ? function() {
				return setIsLoadingMore(false);
			} : void 0
		};
		var _useLoadMoreFunction = useLoadMoreFunction((0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, args), {}, {
			observer,
			onReset: function handleReset() {
				return setIsLoadingMore(false);
			}
		}));
		return [
			_useLoadMoreFunction[0],
			_useLoadMoreFunction[1],
			isLoadingMore,
			_useLoadMoreFunction[2]
		];
	}
	module.exports = usePaginationFragment;
}));
var require_usePrefetchableForwardPaginationFragment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _interopRequireDefault = require_interopRequireDefault()["default"];
	var _objectSpread2 = _interopRequireDefault(require_objectSpread2());
	var useFragment = require_useFragment();
	var useLoadMoreFunction = require_useLoadMoreFunction();
	var useRefetchableFragmentInternal = require_useRefetchableFragmentInternal();
	var useRelayEnvironment = require_useRelayEnvironment();
	var useStaticFragmentNodeWarning = require_useStaticFragmentNodeWarning();
	var invariant = require_invariant(), _require$1 = __require("react"), useCallback = _require$1.useCallback;
	_require$1.useDebugValue;
	var useEffect = _require$1.useEffect, useLayoutEffect = _require$1.useLayoutEffect, useMemo = _require$1.useMemo, useRef = _require$1.useRef, useState = _require$1.useState;
	var _require2 = require_relay_runtime(), getFragment = _require2.getFragment, getFragmentIdentifier = _require2.getFragmentIdentifier, getPaginationMetadata = _require2.getPaginationMetadata;
	var _require3 = require_relay_runtime(), ConnectionInterface = _require3.ConnectionInterface, RelayFeatureFlags = _require3.RelayFeatureFlags, getSelector = _require3.getSelector, getValueAtPath = _require3.getValueAtPath;
	function usePrefetchableForwardPaginationFragment(fragmentInput, parentFragmentRef, bufferSize, initialSize, prefetchingLoadMoreOptions) {
		var _fragmentInput$metada, _fragmentInput$metada2;
		var minimalFetchSize = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 1;
		var disablePrefetching = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : false;
		var fragmentNode = getFragment(fragmentInput);
		useStaticFragmentNodeWarning(fragmentNode, "first argument of usePrefetchableForwardPaginationFragment()");
		var componentDisplayName = "usePrefetchableForwardPaginationFragment()";
		var _getPaginationMetadat = getPaginationMetadata(fragmentNode, componentDisplayName), connectionPathInFragmentData = _getPaginationMetadat.connectionPathInFragmentData, paginationRequest = _getPaginationMetadat.paginationRequest, paginationMetadata = _getPaginationMetadat.paginationMetadata;
		var _useRefetchableFragme = useRefetchableFragmentInternal(fragmentNode, parentFragmentRef, componentDisplayName), fragmentData = _useRefetchableFragme.fragmentData, fragmentRef = _useRefetchableFragme.fragmentRef, refetch = _useRefetchableFragme.refetch;
		var fragmentIdentifier = getFragmentIdentifier(fragmentNode, fragmentRef);
		var edgeKeys = useMemo(function() {
			var connection = getValueAtPath(fragmentData, connectionPathInFragmentData);
			if (connection == null) return null;
			return connection[ConnectionInterface.get().EDGES];
		}, [connectionPathInFragmentData, fragmentData]);
		var sourceSize = edgeKeys == null ? -1 : edgeKeys.length;
		var _useState = useState(initialSize != null ? initialSize : sourceSize), _numInUse = _useState[0], setNumInUse = _useState[1];
		var numInUse = _numInUse;
		if (_numInUse === -1 && sourceSize !== -1) {
			numInUse = initialSize != null ? initialSize : sourceSize;
			setNumInUse(numInUse);
		}
		var environment = useRelayEnvironment();
		var _useState2 = useState(false), isLoadingMore = _useState2[0], reallySetIsLoadingMore = _useState2[1];
		var _useState3 = useState(false), isRefetching = _useState3[0], setIsRefetching = _useState3[1];
		var availableSizeRef = useRef(0);
		var setIsLoadingMore = useCallback(function(value) {
			var _environment$getSched;
			var schedule = (_environment$getSched = environment.getScheduler()) === null || _environment$getSched === void 0 ? void 0 : _environment$getSched.schedule;
			if (schedule) schedule(function() {
				reallySetIsLoadingMore(value);
			});
			else reallySetIsLoadingMore(value);
		}, [environment]);
		var isLoadingMoreRef = useRef(false);
		var _useLoadMoreFunction = useLoadMoreFunction({
			componentDisplayName,
			connectionPathInFragmentData,
			direction: "forward",
			fragmentData,
			fragmentIdentifier,
			fragmentNode,
			fragmentRef,
			paginationMetadata,
			paginationRequest,
			observer: useMemo(function() {
				function setIsLoadingFalse() {
					isLoadingMoreRef.current = false;
					setIsLoadingMore(false);
				}
				return {
					start: function start() {
						isLoadingMoreRef.current = true;
						reallySetIsLoadingMore(true);
					},
					complete: setIsLoadingFalse,
					error: setIsLoadingFalse,
					unsubscribe: RelayFeatureFlags.ENABLE_USE_PAGINATION_IS_LOADING_FIX ? setIsLoadingFalse : void 0
				};
			}, [setIsLoadingMore]),
			onReset: useCallback(function() {
				if (!isRefetching) {
					var _environment$getSched2;
					var schedule = (_environment$getSched2 = environment.getScheduler()) === null || _environment$getSched2 === void 0 ? void 0 : _environment$getSched2.schedule;
					if (schedule) schedule(function() {
						setNumInUse(-1);
					});
					else setNumInUse(-1);
				}
				isLoadingMoreRef.current = false;
				setIsLoadingMore(false);
			}, [
				environment,
				isRefetching,
				setIsLoadingMore
			])
		}), loadMore = _useLoadMoreFunction[0], hasNext = _useLoadMoreFunction[1], disposeFetchNext = _useLoadMoreFunction[2];
		useLayoutEffect(function() {
			availableSizeRef.current = sourceSize - numInUse;
		}, [numInUse, sourceSize]);
		var prefetchingUNSTABLE_extraVariables = prefetchingLoadMoreOptions === null || prefetchingLoadMoreOptions === void 0 ? void 0 : prefetchingLoadMoreOptions.UNSTABLE_extraVariables;
		var prefetchingOnComplete = prefetchingLoadMoreOptions === null || prefetchingLoadMoreOptions === void 0 ? void 0 : prefetchingLoadMoreOptions.onComplete;
		var showMore = useCallback(function(numToAdd, options) {
			if (!isLoadingMoreRef.current || availableSizeRef.current >= 0) {
				availableSizeRef.current -= numToAdd;
				setNumInUse(function(lastNumInUse) {
					return lastNumInUse + numToAdd;
				});
				if (!isLoadingMoreRef.current && availableSizeRef.current < 0) loadMore(Math.max(minimalFetchSize, Math.min(numToAdd, bufferSize - availableSizeRef.current)), options !== null && options !== void 0 ? options : {
					onComplete: prefetchingOnComplete,
					UNSTABLE_extraVariables: typeof prefetchingUNSTABLE_extraVariables === "function" ? prefetchingUNSTABLE_extraVariables({
						hasNext,
						data: fragmentData,
						getServerEdges: function getServerEdges() {
							var selector = getSelector(edgesFragment, edgeKeys);
							if (selector == null) return [];
							!(selector.kind === "PluralReaderSelector") && invariant(false);
							return selector.selectors.map(function(sel) {
								return environment.lookup(sel).data;
							});
						}
					}) : prefetchingUNSTABLE_extraVariables
				});
			}
		}, [
			bufferSize,
			loadMore,
			minimalFetchSize,
			edgeKeys,
			fragmentData,
			prefetchingUNSTABLE_extraVariables,
			prefetchingOnComplete
		]);
		var edgesFragment = (_fragmentInput$metada = fragmentInput.metadata) === null || _fragmentInput$metada === void 0 ? void 0 : (_fragmentInput$metada2 = _fragmentInput$metada.refetch) === null || _fragmentInput$metada2 === void 0 ? void 0 : _fragmentInput$metada2.edgesFragment;
		!(edgesFragment != null) && invariant(false);
		useEffect(function() {
			if (!isLoadingMoreRef.current && !isLoadingMore && !isRefetching && !disablePrefetching && hasNext && (sourceSize - numInUse < bufferSize || numInUse > sourceSize)) {
				var onComplete = prefetchingOnComplete;
				loadMore(Math.max(bufferSize - Math.max(sourceSize - numInUse, 0), numInUse - sourceSize, minimalFetchSize), {
					onComplete,
					UNSTABLE_extraVariables: typeof prefetchingUNSTABLE_extraVariables === "function" ? prefetchingUNSTABLE_extraVariables({
						hasNext,
						data: fragmentData,
						getServerEdges: function getServerEdges() {
							var selector = getSelector(edgesFragment, edgeKeys);
							if (selector == null) return [];
							!(selector.kind === "PluralReaderSelector") && invariant(false);
							return selector.selectors.map(function(sel) {
								return environment.lookup(sel).data;
							});
						}
					}) : prefetchingUNSTABLE_extraVariables
				});
			}
		}, [
			hasNext,
			bufferSize,
			isRefetching,
			loadMore,
			numInUse,
			prefetchingUNSTABLE_extraVariables,
			prefetchingOnComplete,
			sourceSize,
			edgeKeys,
			isLoadingMore,
			minimalFetchSize,
			environment,
			edgesFragment
		]);
		var realNumInUse = Math.min(numInUse, sourceSize);
		var edges = useFragment(edgesFragment, useMemo(function() {
			var _edgeKeys$slice;
			return (_edgeKeys$slice = edgeKeys === null || edgeKeys === void 0 ? void 0 : edgeKeys.slice(0, realNumInUse)) !== null && _edgeKeys$slice !== void 0 ? _edgeKeys$slice : [];
		}, [edgeKeys, realNumInUse]));
		var refetchPagination = useCallback(function(variables, options) {
			disposeFetchNext();
			setIsRefetching(true);
			return refetch(variables, (0, _objectSpread2["default"])((0, _objectSpread2["default"])({}, options), {}, {
				onComplete: function onComplete(maybeError) {
					var _environment$getSched3, _options$onComplete;
					var schedule = (_environment$getSched3 = environment.getScheduler()) === null || _environment$getSched3 === void 0 ? void 0 : _environment$getSched3.schedule;
					if (schedule) schedule(function() {
						setIsRefetching(false);
						setNumInUse(-1);
					});
					else {
						setIsRefetching(false);
						setNumInUse(-1);
					}
					options === null || options === void 0 || (_options$onComplete = options.onComplete) == null || _options$onComplete.call(options, maybeError);
				},
				__environment: void 0
			}));
		}, [
			disposeFetchNext,
			environment,
			refetch
		]);
		return {
			edges,
			data: fragmentData,
			loadNext: showMore,
			hasNext: hasNext || sourceSize > numInUse,
			isLoadingNext: isLoadingMore && numInUse > sourceSize,
			refetch: refetchPagination
		};
	}
	module.exports = usePrefetchableForwardPaginationFragment;
}));
var require_usePreloadedQuery = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useLazyLoadQueryNode = require_useLazyLoadQueryNode();
	var useMemoOperationDescriptor = require_useMemoOperationDescriptor();
	var useRelayEnvironment = require_useRelayEnvironment();
	var invariant = require_invariant();
	__require("react").useDebugValue;
	var _require2$__internal = require_relay_runtime().__internal, fetchQueryDeduped = _require2$__internal.fetchQueryDeduped, fetchQuery = _require2$__internal.fetchQuery;
	require_warning();
	function usePreloadedQuery(gqlQuery, preloadedQuery, options) {
		var environment = useRelayEnvironment();
		var fetchKey = preloadedQuery.fetchKey, fetchPolicy = preloadedQuery.fetchPolicy, source = preloadedQuery.source, variables = preloadedQuery.variables, networkCacheConfig = preloadedQuery.networkCacheConfig;
		var operation = useMemoOperationDescriptor(gqlQuery, variables, networkCacheConfig);
		var useLazyLoadQueryNodeParams;
		if (preloadedQuery.kind === "PreloadedQuery_DEPRECATED") {
			!(operation.request.node.params.name === preloadedQuery.name) && invariant(false);
			useLazyLoadQueryNodeParams = {
				componentDisplayName: "usePreloadedQuery()",
				fetchKey,
				fetchObservable: fetchQueryDeduped(environment, operation.request.identifier, function() {
					if (environment === preloadedQuery.environment && source != null) return environment.executeWithSource({
						operation,
						source
					});
					else return environment.execute({ operation });
				}),
				fetchPolicy,
				query: operation,
				renderPolicy: options === null || options === void 0 ? void 0 : options.UNSTABLE_renderPolicy
			};
		} else {
			var fallbackFetchObservable = fetchQuery(environment, operation);
			var fetchObservable;
			if (source != null && environment === preloadedQuery.environment) fetchObservable = source.ifEmpty(fallbackFetchObservable);
			else if (environment !== preloadedQuery.environment) fetchObservable = fallbackFetchObservable;
			else fetchObservable = fallbackFetchObservable;
			useLazyLoadQueryNodeParams = {
				componentDisplayName: "usePreloadedQuery()",
				fetchObservable,
				fetchKey,
				fetchPolicy,
				query: operation,
				renderPolicy: options === null || options === void 0 ? void 0 : options.UNSTABLE_renderPolicy
			};
		}
		return useLazyLoadQueryNode(useLazyLoadQueryNodeParams);
	}
	module.exports = usePreloadedQuery;
}));
var require_useRefetchableFragment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useRefetchableFragmentInternal = require_useRefetchableFragmentInternal();
	var useStaticFragmentNodeWarning = require_useStaticFragmentNodeWarning();
	__require("react").useDebugValue;
	var getFragment = require_relay_runtime().getFragment;
	function useRefetchableFragment(fragmentInput, fragmentRef) {
		var fragmentNode = getFragment(fragmentInput);
		useStaticFragmentNodeWarning(fragmentNode, "first argument of useRefetchableFragment()");
		var _useRefetchableFragme = useRefetchableFragmentInternal(fragmentNode, fragmentRef, "useRefetchableFragment()");
		return [_useRefetchableFragme.fragmentData, _useRefetchableFragme.refetch];
	}
	module.exports = useRefetchableFragment;
}));
var require_useSubscribeToInvalidationState = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useRelayEnvironment = require_useRelayEnvironment();
	var _require = __require("react"), useEffect$1 = _require.useEffect, useRef = _require.useRef;
	function useSubscribeToInvalidationState(dataIDs, callback) {
		var environment = useRelayEnvironment();
		var disposableRef = useRef(null);
		useEffect$1(function() {
			var store = environment.getStore();
			var invalidationState = store.lookupInvalidationState(dataIDs);
			var disposable = store.subscribeToInvalidationState(invalidationState, callback);
			disposableRef.current = disposable;
			return function() {
				return disposable.dispose();
			};
		}, [
			Array.from(dataIDs).sort().join(""),
			callback,
			environment
		]);
		return { dispose: function dispose() {
			if (disposableRef.current != null) disposableRef.current.dispose();
		} };
	}
	module.exports = useSubscribeToInvalidationState;
}));
var require_useSubscription = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var useRelayEnvironment = require_useRelayEnvironment();
	var useEffect = __require("react").useEffect;
	var requestSubscription = require_relay_runtime().requestSubscription;
	function useSubscription(config, requestSubscriptionFn) {
		var actualRequestSubscription = requestSubscriptionFn !== null && requestSubscriptionFn !== void 0 ? requestSubscriptionFn : requestSubscription;
		var environment = useRelayEnvironment();
		useEffect(function() {
			return actualRequestSubscription(environment, config).dispose;
		}, [
			environment,
			config,
			actualRequestSubscription
		]);
	}
	module.exports = useSubscription;
}));
var require_lib = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactRelayContext = require_ReactRelayContext();
	var ReactRelayFragmentContainer = require_ReactRelayFragmentContainer();
	var ReactRelayLocalQueryRenderer = require_ReactRelayLocalQueryRenderer();
	var ReactRelayPaginationContainer = require_ReactRelayPaginationContainer();
	var ReactRelayQueryRenderer = require_ReactRelayQueryRenderer();
	var ReactRelayRefetchContainer = require_ReactRelayRefetchContainer();
	var EntryPointContainer = require_EntryPointContainer_react();
	var loadEntryPoint = require_loadEntryPoint();
	var loadQuery = require_loadQuery().loadQuery;
	var ProfilerContext = require_ProfilerContext();
	var RelayEnvironmentProvider = require_RelayEnvironmentProvider();
	var useClientQuery = require_useClientQuery();
	var useEntryPointLoader = require_useEntryPointLoader();
	var useFragment = require_useFragment();
	var useLazyLoadQuery = require_useLazyLoadQuery();
	var useMutation = require_useMutation();
	var usePaginationFragment = require_usePaginationFragment();
	var usePrefetchableForwardPaginationFragment = require_usePrefetchableForwardPaginationFragment();
	var usePreloadedQuery = require_usePreloadedQuery();
	var useQueryLoader = require_useQueryLoader();
	var useRefetchableFragment = require_useRefetchableFragment();
	var useRelayEnvironment = require_useRelayEnvironment();
	var useSubscribeToInvalidationState = require_useSubscribeToInvalidationState();
	var useSubscription = require_useSubscription();
	var RelayRuntime = require_relay_runtime();
	module.exports = {
		ConnectionHandler: RelayRuntime.ConnectionHandler,
		QueryRenderer: ReactRelayQueryRenderer,
		LocalQueryRenderer: ReactRelayLocalQueryRenderer,
		MutationTypes: RelayRuntime.MutationTypes,
		RangeOperations: RelayRuntime.RangeOperations,
		ReactRelayContext,
		applyOptimisticMutation: RelayRuntime.applyOptimisticMutation,
		commitLocalUpdate: RelayRuntime.commitLocalUpdate,
		commitMutation: RelayRuntime.commitMutation,
		createFragmentContainer: ReactRelayFragmentContainer.createContainer,
		createPaginationContainer: ReactRelayPaginationContainer.createContainer,
		createRefetchContainer: ReactRelayRefetchContainer.createContainer,
		fetchQuery_DEPRECATED: RelayRuntime.fetchQuery_DEPRECATED,
		graphql: RelayRuntime.graphql,
		readInlineData: RelayRuntime.readInlineData,
		requestSubscription: RelayRuntime.requestSubscription,
		EntryPointContainer,
		RelayEnvironmentProvider,
		ProfilerContext,
		fetchQuery: RelayRuntime.fetchQuery,
		loadQuery,
		loadEntryPoint,
		useClientQuery,
		useFragment,
		useLazyLoadQuery,
		useEntryPointLoader,
		useQueryLoader,
		useMutation,
		usePaginationFragment,
		usePreloadedQuery,
		useRefetchableFragment,
		usePrefetchableForwardPaginationFragment,
		useRelayEnvironment,
		useSubscribeToInvalidationState,
		useSubscription
	};
}));
var require_react_relay = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Relay v20.1.1
	*
	* Copyright (c) Meta Platforms, Inc. and affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	module.exports = require_lib();
}));
export { require_useSubscribeToInvalidationState as _, require_loadQuery as a, require_useEntryPointLoader as c, require_useMutation as d, require_usePaginationFragment as f, require_useRelayEnvironment as g, require_useRefetchableFragment as h, require_loadEntryPoint as i, require_useFragment as l, require_useQueryLoader as m, require_ProfilerContext as n, require_react_relay as o, require_usePreloadedQuery as p, require_RelayEnvironmentProvider as r, require_relay_runtime as s, require_EntryPointContainer_react as t, require_useLazyLoadQuery as u, require_useSubscription as v };
