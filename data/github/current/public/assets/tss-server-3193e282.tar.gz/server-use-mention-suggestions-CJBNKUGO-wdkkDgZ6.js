import { n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { n as NO_MATCH, r as fuzzyScore, t as DIRECT_MATCH } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
import { useMemo, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
function applyTone(character, _tone) {
	return character;
}
var useAutocompleteTriggersAndSuggestions = (triggerAndSuggestions) => {
	const $ = c(9);
	const [suggestionEvent, setSuggestionEvent] = useState(null);
	let t0;
	if ($[0] !== triggerAndSuggestions) {
		const triggers = [];
		const calculatorByChar = /* @__PURE__ */ new Map();
		for (const { trigger, suggestionsCalculator } of triggerAndSuggestions) {
			triggers.push(trigger);
			calculatorByChar.set(trigger.triggerChar, suggestionsCalculator);
		}
		t0 = {
			triggers,
			calculatorByChar
		};
		$[0] = triggerAndSuggestions;
		$[1] = t0;
	} else t0 = $[1];
	const normalized = t0;
	let t1;
	if ($[2] !== normalized.calculatorByChar || $[3] !== suggestionEvent) {
		t1 = suggestionEvent == null ? null : normalized.calculatorByChar.get(suggestionEvent.trigger.triggerChar)?.(suggestionEvent.query) ?? null;
		$[2] = normalized.calculatorByChar;
		$[3] = suggestionEvent;
		$[4] = t1;
	} else t1 = $[4];
	const suggestions = t1;
	const t2 = suggestionEvent !== null;
	let t3;
	if ($[5] !== normalized.triggers || $[6] !== suggestions || $[7] !== t2) {
		t3 = {
			triggers: normalized.triggers,
			suggestions,
			setSuggestionEvent,
			active: t2
		};
		$[5] = normalized.triggers;
		$[6] = suggestions;
		$[7] = t2;
		$[8] = t3;
	} else t3 = $[8];
	return t3;
};
var MAX_SUGGESTIONS = 5;
var suggestionsCalculator = (options, score, tieBreaker, toSuggestion, sortInitialOptions) => (query) => {
	if (options === "loading") return "loading";
	const scoredAndSorted = query ? options.map((o) => [score(query, o), o]).filter(([s]) => s > NO_MATCH).sort(([aScore, a], [bScore, b]) => {
		if (bScore === aScore) return -tieBreaker(b, a);
		return bScore - aScore;
	}).slice(0, MAX_SUGGESTIONS).map(([, o]) => o) : options.slice(0, MAX_SUGGESTIONS);
	if (sortInitialOptions) scoredAndSorted.sort(tieBreaker);
	return scoredAndSorted.map(toSuggestion);
};
function isUnicodeEmoji(emoji) {
	return "character" in emoji && emoji.character !== void 0;
}
var PRIORITIZED_EMOJIS = new Set([
	"+1",
	"thumbsup",
	"-1"
]);
var trigger$1 = {
	triggerChar: ":",
	keepTriggerCharOnCommit: false
};
var getUnicodeEmojiContent = (emoji, tone) => tone !== void 0 ? /* @__PURE__ */ jsx("g-emoji", {
	alias: emoji.name,
	tone,
	"fallback-src": emoji.url,
	children: emoji.character
}) : emoji.character;
var getEmojiValue = (emoji, tone) => {
	if (!isUnicodeEmoji(emoji)) return `:${emoji.name}:`;
	return tone !== void 0 ? applyTone(emoji.character, tone) : emoji.character;
};
var RenderEmoji = (props) => {
	const { emoji, tone } = props;
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: isUnicodeEmoji(emoji) ? getUnicodeEmojiContent(emoji, tone) : /* @__PURE__ */ jsx("img", {
			src: emoji.url,
			alt: `${emoji.name} emoji`,
			height: "16",
			width: "16"
		}) }), emoji.name]
	});
};
RenderEmoji.displayName = "RenderEmoji";
var emojiToSuggestionWithTone = (tone) => {
	return (emoji) => ({
		value: getEmojiValue(emoji, tone),
		key: emoji.name,
		render: (props) => RenderEmoji({
			...props,
			emoji,
			tone
		})
	});
};
var scoreSuggestion$1 = (query, emoji) => {
	const name = emoji.name.toLowerCase();
	const q = query.toLowerCase();
	let score = 0;
	if (name.includes(q)) {
		score += 5;
		if (name.startsWith(q)) score += 5;
	}
	return score === 0 ? NO_MATCH : score;
};
var tieBreaker$1 = (emojiOne, emojiTwo) => {
	const nameOne = emojiOne.name.toLowerCase();
	const nameTwo = emojiTwo.name.toLowerCase();
	if (PRIORITIZED_EMOJIS.has(nameOne) && !PRIORITIZED_EMOJIS.has(nameTwo)) return -1;
	else if (PRIORITIZED_EMOJIS.has(nameTwo) && !PRIORITIZED_EMOJIS.has(nameOne)) return 1;
	else return 0;
};
var useEmojiSuggestions = (emojis, opts) => {
	const $ = c(5);
	opts?.tone;
	let t0;
	if ($[0] !== emojis || $[1] !== opts?.tone) {
		t0 = suggestionsCalculator(emojis, scoreSuggestion$1, tieBreaker$1, emojiToSuggestionWithTone(opts?.tone), true);
		$[0] = emojis;
		$[1] = opts?.tone;
		$[2] = t0;
	} else t0 = $[2];
	const calculateSuggestions = t0;
	let t1;
	if ($[3] !== calculateSuggestions) {
		t1 = {
			calculateSuggestions,
			trigger: trigger$1
		};
		$[3] = calculateSuggestions;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
var use_mention_suggestions_module_default = { identifierText: "use-mention-suggestions-module_zIGBGW_identifierText" };
var trigger = { triggerChar: "@" };
var mentionableToSuggestion = (mentionable) => ({
	value: mentionable.identifier,
	render: (props) => /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		children: [
			mentionable.avatarUrl && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, {
				size: 16,
				src: mentionable.avatarUrl
			}) }),
			/* @__PURE__ */ jsx("span", {
				className: use_mention_suggestions_module_default.identifierText,
				children: mentionable.identifier
			}),
			" ",
			/* @__PURE__ */ jsx(ActionList.Description, {
				truncate: true,
				children: mentionable.description
			})
		]
	})
});
var scoreSuggestion = (query, mentionable) => {
	const fzyScore = Math.max(fuzzyScore(query, mentionable.identifier), fuzzyScore(query, mentionable.description));
	if (fzyScore === -Infinity) return fzyScore;
	else if (fzyScore > 0 && mentionable.participant) return DIRECT_MATCH;
	else return mentionable.participant ? fzyScore + 1 : fzyScore;
};
var tieBreaker = (mentionableOne, mentionableTwo) => {
	if (mentionableOne.participant && !mentionableTwo.participant) return -1;
	else if (mentionableTwo.participant && !mentionableOne.participant) return 1;
	return mentionableOne.identifier.localeCompare(mentionableTwo.identifier);
};
var useMentionSuggestions = (mentionables) => {
	const $ = c(4);
	let t0;
	if ($[0] !== mentionables) {
		t0 = suggestionsCalculator(mentionables, scoreSuggestion, tieBreaker, mentionableToSuggestion);
		$[0] = mentionables;
		$[1] = t0;
	} else t0 = $[1];
	const calculateSuggestions = t0;
	let t1;
	if ($[2] !== calculateSuggestions) {
		t1 = {
			calculateSuggestions,
			trigger
		};
		$[2] = calculateSuggestions;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
export { useEmojiSuggestions as a, useAutocompleteTriggersAndSuggestions as i, isUnicodeEmoji as n, useMentionSuggestions as o, suggestionsCalculator as r, getUnicodeEmojiContent as t };
