performance.mark("js-parse-end:server-layout-DmMdwMT3-BIsN_aJZ.js");
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Dt as FileIcon, Fn as MirrorIcon, Gn as PackageDependentsIcon, H as CodeIcon, Hn as NoteIcon, Kn as PackageIcon, T as CalendarIcon, Wn as OrganizationIcon, Zr as StarIcon, _i as Truncate, c as ArchiveIcon, en as HeartIcon, er as PersonIcon, fn as IssueOpenedIcon, hr as RepoForkedIcon, oi as TelescopeIcon, s as AppsIcon, vi as TypographyIcon, vn as LawIcon, yr as RepoTemplateIcon, yt as EyeIcon, zr as SortAscIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as Outlet$1, y as useNavigation } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as PageLayout } from "./server-PageLayout-CYFdz829-BD84oh7w.js";
import { nt as newRepoPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as useRouteQuery, t as useChildRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as ContextualGlobalSsoBanner } from "./server-ContextualGlobalSsoBanner-BxYXWjwo-Dq9T9smw.js";
import { t as useFeatureFlag } from "./server-use-feature-flag-CDC46uBu-B9UHPW6C.js";
import { C as TRUE_FALSE_FILTER_VALUES, M as defaultFilterProviderOptions, c as FilterProviderType, g as ProviderSupportStatus } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
import { t as AnalyticsProvider } from "./server-AnalyticsProvider-D0POAVQk-B5tW16h5.js";
import { $ as useShortcutEditor, D as NumericFilterProvider, E as NestedFilterProvider, F as SelectFilterProvider, L as ShortcutEditingHeader, Q as useShortcutDeletion, R as ShortcutOptionsButton, Z as getShortcutsWithSaved, f as DateFilterProvider, s as BooleanFilterProvider } from "./server-providers-w0hxsmcG-B_8wxADa.js";
import { t as Filter } from "./server-Filter-DGmvUrMW-BT0gplWp.js";
import { a as ReposShortcutSidebar, c as reposFinderPageRoute, n as ListSidebarCollapsedButton, s as reposFinderLayoutRoute, t as ListSidebar } from "./server-repos-finder-page-route-CLW2IkJh-kX9Pej9X.js";
import { n as useReposFinderStateContext, t as ReposFinderStateProvider } from "./server-ReposFinderStateContext-DmypLpye-wNDNZQST.js";
import { useEffect, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:layout-DmMdwMT3.js");
var prefixProviderOptions = { filterTypes: {
	valueless: false,
	hasValue: false
} };
function getCustomPropertiesProvider(definitions) {
	return new NestedFilterProvider({
		key: "props",
		displayName: "Custom properties",
		description: "Filter by custom properties",
		priority: 3,
		icon: NoteIcon,
		subKeys: definitions.map((d) => buildSubKey(d))
	}, prefixProviderOptions);
}
function buildSubKey(definition) {
	const { propertyName, valueType } = definition;
	const values = valueType === "true_false" ? TRUE_FALSE_FILTER_VALUES : (definition.allowedValues || []).map((value, index) => ({
		value,
		displayName: value,
		priority: index + 1
	}));
	return {
		key: propertyName,
		displayName: `Property: ${propertyName}`,
		icon: NoteIcon,
		type: ["string", "url"].includes(valueType) ? "text" : "select",
		values,
		options: getFilterOptions(definition)
	};
}
function getFilterOptions({ valueType, required }) {
	return {
		...defaultFilterProviderOptions,
		filterTypes: {
			multiKey: valueType === "multi_select" ? true : false,
			multiValue: true,
			valueless: !required,
			hasValue: !required
		}
	};
}
function getAllDateProviders() {
	return [new CreatedFilterProvider({ filterTypes: {
		valueless: false,
		hasValue: false
	} }), new PushedFilterProvider({ filterTypes: {
		valueless: false,
		hasValue: false
	} })];
}
var NOT_SHOWN$2 = 10;
var REPOS_DATE_FILTER_KEYS = {
	created: {
		displayName: "Created",
		key: "created",
		priority: NOT_SHOWN$2,
		icon: CalendarIcon,
		description: "Creation date"
	},
	pushed: {
		displayName: "Last updated",
		key: "pushed",
		priority: NOT_SHOWN$2,
		icon: CalendarIcon,
		description: "Last updated date"
	}
};
var TIME_RANGE_VALUES = [
	{
		displayName: "Today",
		value: () => formatDate(/* @__PURE__ */ new Date()),
		priority: 1
	},
	{
		displayName: "This month",
		value: () => `>${formatDate(pastMonthEndDate())}`,
		priority: 2
	},
	{
		displayName: "This year",
		value: () => `>${formatDate(pastYearEndDate())}`,
		priority: 3
	}
];
function formatDate(date) {
	const [withoutTime] = date.toISOString().split("T");
	return withoutTime;
}
function pastMonthEndDate() {
	const today = /* @__PURE__ */ new Date();
	return new Date(today.getFullYear(), today.getMonth(), 0);
}
function pastYearEndDate() {
	const today = /* @__PURE__ */ new Date();
	return new Date(today.getFullYear(), 0, 0);
}
var CreatedFilterProvider = class extends DateFilterProvider {
	constructor(options) {
		super(REPOS_DATE_FILTER_KEYS.created, TIME_RANGE_VALUES, options);
	}
};
var PushedFilterProvider = class extends DateFilterProvider {
	constructor(options) {
		super(REPOS_DATE_FILTER_KEYS.pushed, TIME_RANGE_VALUES, options);
	}
};
var LanguageStaticFilterProvider = class extends SelectFilterProvider {
	constructor() {
		const values = LANGUAGES.map(({ name, color }) => ({
			value: name,
			displayName: name,
			color,
			priority: POPULAR_LANGUAGES.includes(name) ? 5 : 10,
			iconColor: color
		}));
		values.sort((a, b) => a.priority - b.priority);
		super(LANGUAGES_FILTER, values, { filterTypes: {
			multiKey: false,
			multiValue: true,
			valueless: false,
			hasValue: false
		} });
	}
};
var LANGUAGES_FILTER = {
	displayName: "Language",
	key: "language",
	description: "Programming language",
	priority: 3,
	icon: CodeIcon
};
var POPULAR_LANGUAGES = [
	"C++",
	"Go",
	"Java",
	"JavaScript",
	"PHP",
	"Python",
	"Ruby",
	"TypeScript"
];
var LANGUAGES = [
	{
		name: "ABAP",
		color: "#E8274B"
	},
	{
		name: "AGS Script",
		color: "#B9D9FF"
	},
	{
		name: "AMPL",
		color: "#E6EFBB"
	},
	{
		name: "ANTLR",
		color: "#9DC3FF"
	},
	{
		name: "API Blueprint",
		color: "#2ACCA8"
	},
	{
		name: "APL",
		color: "#5A8164"
	},
	{
		name: "ASP",
		color: "#6a40fd"
	},
	{
		name: "ATS",
		color: "#1ac620"
	},
	{
		name: "ActionScript",
		color: "#882B0F"
	},
	{
		name: "Ada",
		color: "#02f88c"
	},
	{
		name: "Agda",
		color: "#315665"
	},
	{
		name: "Alloy",
		color: "#64C800"
	},
	{
		name: "AngelScript",
		color: "#C7D7DC"
	},
	{
		name: "AppleScript",
		color: "#101F1F"
	},
	{
		name: "Arc",
		color: "#aa2afe"
	},
	{
		name: "AspectJ",
		color: "#a957b0"
	},
	{
		name: "Assembly",
		color: "#6E4C13"
	},
	{
		name: "Asymptote",
		color: "#4a0c0c"
	},
	{
		name: "AutoHotkey",
		color: "#6594b9"
	},
	{
		name: "AutoIt",
		color: "#1C3552"
	},
	{
		name: "Ballerina",
		color: "#FF5000"
	},
	{
		name: "Batchfile",
		color: "#C1F12E"
	},
	{
		name: "BlitzMax",
		color: "#cd6400"
	},
	{
		name: "Boo",
		color: "#d4bec1"
	},
	{
		name: "C",
		color: "#555555"
	},
	{
		name: "C++",
		color: "#f34b7d"
	},
	{
		name: "C#",
		color: "#178600"
	},
	{
		name: "CSS",
		color: "#563d7c"
	},
	{
		name: "Ceylon",
		color: "#dfa535"
	},
	{
		name: "Chapel",
		color: "#8dc63f"
	},
	{
		name: "Cirru",
		color: "#ccccff"
	},
	{
		name: "Clarion",
		color: "#db901e"
	},
	{
		name: "Clean",
		color: "#3F85AF"
	},
	{
		name: "Click",
		color: "#E4E6F3"
	},
	{
		name: "Clojure",
		color: "#db5855"
	},
	{
		name: "CoffeeScript",
		color: "#244776"
	},
	{
		name: "ColdFusion",
		color: "#ed2cd6"
	},
	{
		name: "Common Lisp",
		color: "#3fb68b"
	},
	{
		name: "Common Workflow Language",
		color: "#B5314C"
	},
	{
		name: "Component Pascal",
		color: "#B0CE4E"
	},
	{
		name: "Crystal",
		color: "#000100"
	},
	{
		name: "Cuda",
		color: "#3A4E3A"
	},
	{
		name: "D",
		color: "#ba595e"
	},
	{
		name: "DM",
		color: "#447265"
	},
	{
		name: "Dart",
		color: "#00B4AB"
	},
	{
		name: "DataWeave",
		color: "#003a52"
	},
	{
		name: "Dhall",
		color: "#dfafff"
	},
	{
		name: "Dockerfile",
		color: "#384d54"
	},
	{
		name: "Dogescript",
		color: "#cca760"
	},
	{
		name: "Dylan",
		color: "#6c616e"
	},
	{
		name: "E",
		color: "#ccce35"
	},
	{
		name: "ECL",
		color: "#8a1267"
	},
	{
		name: "EQ",
		color: "#a78649"
	},
	{
		name: "Eiffel",
		color: "#946d57"
	},
	{
		name: "Elixir",
		color: "#6e4a7e"
	},
	{
		name: "Elm",
		color: "#60B5CC"
	},
	{
		name: "Emacs Lisp",
		color: "#c065db"
	},
	{
		name: "EmberScript",
		color: "#FFF4F3"
	},
	{
		name: "Erlang",
		color: "#B83998"
	},
	{
		name: "F#",
		color: "#b845fc"
	},
	{
		name: "F*",
		color: "#572e30"
	},
	{
		name: "FLUX",
		color: "#88ccff"
	},
	{
		name: "Factor",
		color: "#636746"
	},
	{
		name: "Fancy",
		color: "#7b9db4"
	},
	{
		name: "Fantom",
		color: "#14253c"
	},
	{
		name: "Forth",
		color: "#341708"
	},
	{
		name: "Fortran",
		color: "#4d41b1"
	},
	{
		name: "FreeMarker",
		color: "#0050b2"
	},
	{
		name: "Frege",
		color: "#00cafe"
	},
	{
		name: "G-code",
		color: "#D08CF2"
	},
	{
		name: "GDScript",
		color: "#355570"
	},
	{
		name: "Game Maker Language",
		color: "#71b417"
	},
	{
		name: "Genie",
		color: "#fb855d"
	},
	{
		name: "Gherkin",
		color: "#5B2063"
	},
	{
		name: "Glyph",
		color: "#c1ac7f"
	},
	{
		name: "Gnuplot",
		color: "#f0a9f0"
	},
	{
		name: "Go",
		color: "#00ADD8"
	},
	{
		name: "Groovy",
		color: "#e69f56"
	},
	{
		name: "HTML",
		color: "#e34c26"
	},
	{
		name: "Hack",
		color: "#878787"
	},
	{
		name: "Harbour",
		color: "#0e60e3"
	},
	{
		name: "Haskell",
		color: "#5e5086"
	},
	{
		name: "Haxe",
		color: "#df7900"
	},
	{
		name: "HCL",
		color: "#844fba"
	},
	{
		name: "HiveQL",
		color: "#dce200"
	},
	{
		name: "HolyC",
		color: "#ffefaf"
	},
	{
		name: "Hy",
		color: "#7790B2"
	},
	{
		name: "IDL",
		color: "#a3522f"
	},
	{
		name: "Idris",
		color: "#b30000"
	},
	{
		name: "Io",
		color: "#a9188d"
	},
	{
		name: "Ioke",
		color: "#078193"
	},
	{
		name: "Isabelle",
		color: "#FEFE00"
	},
	{
		name: "J",
		color: "#9EEDFF"
	},
	{
		name: "Java",
		color: "#b07219"
	},
	{
		name: "JavaScript",
		color: "#f1e05a"
	},
	{
		name: "JSONiq",
		color: "#40d47e"
	},
	{
		name: "Jolie",
		color: "#843179"
	},
	{
		name: "Jsonnet",
		color: "#0064bd"
	},
	{
		name: "Julia",
		color: "#a270ba"
	},
	{
		name: "Jupyter Notebook",
		color: "#DA5B0B"
	},
	{
		name: "KRL",
		color: "#28430A"
	},
	{
		name: "Kotlin",
		color: "#F18E33"
	},
	{
		name: "LFE",
		color: "#4C3023"
	},
	{
		name: "LLVM",
		color: "#185619"
	},
	{
		name: "LSL",
		color: "#3d9970"
	},
	{
		name: "Lasso",
		color: "#999999"
	},
	{
		name: "Lex",
		color: "#DBCA00"
	},
	{
		name: "LiveScript",
		color: "#499886"
	},
	{
		name: "LookML",
		color: "#652B81"
	},
	{
		name: "Lua",
		color: "#000080"
	},
	{
		name: "MATLAB",
		color: "#e16737"
	},
	{
		name: "MAXScript",
		color: "#00a6a6"
	},
	{
		name: "MQL4",
		color: "#62A8D6"
	},
	{
		name: "MQL5",
		color: "#4A76B8"
	},
	{
		name: "MTML",
		color: "#b7e1f4"
	},
	{
		name: "Makefile",
		color: "#427819"
	},
	{
		name: "Markdown",
		color: "#083fa1"
	},
	{
		name: "Mask",
		color: "#f97732"
	},
	{
		name: "Max",
		color: "#c4a79c"
	},
	{
		name: "Mercury",
		color: "#ff2b2b"
	},
	{
		name: "Meson",
		color: "#007800"
	},
	{
		name: "Metal",
		color: "#8f14e9"
	},
	{
		name: "Mirah",
		color: "#c7a938"
	},
	{
		name: "Modula-3",
		color: "#223388"
	},
	{
		name: "NCL",
		color: "#28431f"
	},
	{
		name: "Nearley",
		color: "#990000"
	},
	{
		name: "Nemerle",
		color: "#3d3c6e"
	},
	{
		name: "NetLinx",
		color: "#0aa0ff"
	},
	{
		name: "NetLinx+ERB",
		color: "#747faa"
	},
	{
		name: "NetLogo",
		color: "#ff6375"
	},
	{
		name: "NewLisp",
		color: "#87AED7"
	},
	{
		name: "Nextflow",
		color: "#3ac486"
	},
	{
		name: "Nim",
		color: "#37775b"
	},
	{
		name: "Nit",
		color: "#009917"
	},
	{
		name: "Nix",
		color: "#7e7eff"
	},
	{
		name: "Nu",
		color: "#c9df40"
	},
	{
		name: "OCaml",
		color: "#3be133"
	},
	{
		name: "ObjectScript",
		color: "#424893"
	},
	{
		name: "Objective-C",
		color: "#438eff"
	},
	{
		name: "Objective-C++",
		color: "#6866fb"
	},
	{
		name: "Objective-J",
		color: "#ff0c5a"
	},
	{
		name: "Omgrofl",
		color: "#cabbff"
	},
	{
		name: "Opal",
		color: "#f7ede0"
	},
	{
		name: "Oxygene",
		color: "#cdd0e3"
	},
	{
		name: "Oz",
		color: "#fab738"
	},
	{
		name: "P4",
		color: "#7055b5"
	},
	{
		name: "PLSQL",
		color: "#dad8d8"
	},
	{
		name: "Pan",
		color: "#cc0000"
	},
	{
		name: "Papyrus",
		color: "#6600cc"
	},
	{
		name: "Parrot",
		color: "#f3ca0a"
	},
	{
		name: "Pascal",
		color: "#E3F171"
	},
	{
		name: "Pawn",
		color: "#dbb284"
	},
	{
		name: "Pep8",
		color: "#C76F5B"
	},
	{
		name: "Perl",
		color: "#0298c3"
	},
	{
		name: "Perl 6",
		color: "#0000fb"
	},
	{
		name: "PHP",
		color: "#4F5D95"
	},
	{
		name: "PigLatin",
		color: "#fcd7de"
	},
	{
		name: "Pike",
		color: "#005390"
	},
	{
		name: "PogoScript",
		color: "#d80074"
	},
	{
		name: "PostScript",
		color: "#da291c"
	},
	{
		name: "PowerBuilder",
		color: "#8f0f8d"
	},
	{
		name: "PowerShell",
		color: "#012456"
	},
	{
		name: "Processing",
		color: "#0096D8"
	},
	{
		name: "Prolog",
		color: "#74283c"
	},
	{
		name: "Propeller Spin",
		color: "#7fa2a7"
	},
	{
		name: "Puppet",
		color: "#302B6D"
	},
	{
		name: "PureBasic",
		color: "#5a6986"
	},
	{
		name: "PureScript",
		color: "#1D222D"
	},
	{
		name: "Protocol Buffers",
		color: "#CCCCCC"
	},
	{
		name: "Python",
		color: "#3572A5"
	},
	{
		name: "QML",
		color: "#44a51c"
	},
	{
		name: "Quake",
		color: "#882233"
	},
	{
		name: "R",
		color: "#198CE7"
	},
	{
		name: "RAML",
		color: "#77d9fb"
	},
	{
		name: "Racket",
		color: "#3c5caa"
	},
	{
		name: "Ragel",
		color: "#9d5200"
	},
	{
		name: "Rascal",
		color: "#fffaa0"
	},
	{
		name: "Rebol",
		color: "#358a5b"
	},
	{
		name: "Red",
		color: "#f50000"
	},
	{
		name: "Ren'Py",
		color: "#ff7f7f"
	},
	{
		name: "Ring",
		color: "#2D54CB"
	},
	{
		name: "Roff",
		color: "#ecdebe"
	},
	{
		name: "Rouge",
		color: "#cc0088"
	},
	{
		name: "Ruby",
		color: "#701516"
	},
	{
		name: "Rust",
		color: "#dea584"
	},
	{
		name: "SAS",
		color: "#B34936"
	},
	{
		name: "SQF",
		color: "#3F3F3F"
	},
	{
		name: "SRecode Template",
		color: "#348a34"
	},
	{
		name: "SaltStack",
		color: "#646464"
	},
	{
		name: "Scala",
		color: "#c22d40"
	},
	{
		name: "Scheme",
		color: "#1e4aec"
	},
	{
		name: "Self",
		color: "#0579aa"
	},
	{
		name: "Shell",
		color: "#89e051"
	},
	{
		name: "Shen",
		color: "#120F14"
	},
	{
		name: "Slash",
		color: "#007eff"
	},
	{
		name: "Slice",
		color: "#003fa2"
	},
	{
		name: "Smalltalk",
		color: "#596706"
	},
	{
		name: "Solidity",
		color: "#AA6746"
	},
	{
		name: "SourcePawn",
		color: "#5c7611"
	},
	{
		name: "Squirrel",
		color: "#800000"
	},
	{
		name: "Stan",
		color: "#b2011d"
	},
	{
		name: "Standard ML",
		color: "#dc566d"
	},
	{
		name: "SuperCollider",
		color: "#46390b"
	},
	{
		name: "Swift",
		color: "#ffac45"
	},
	{
		name: "SystemVerilog",
		color: "#DAE1C2"
	},
	{
		name: "TI Program",
		color: "#A0AA87"
	},
	{
		name: "Tcl",
		color: "#e4cc98"
	},
	{
		name: "TeX",
		color: "#3D6117"
	},
	{
		name: "Terra",
		color: "#00004c"
	},
	{
		name: "Turing",
		color: "#cf142b"
	},
	{
		name: "TypeScript",
		color: "#2b7489"
	},
	{
		name: "UnrealScript",
		color: "#a54c4d"
	},
	{
		name: "VCL",
		color: "#148AA8"
	},
	{
		name: "VHDL",
		color: "#adb2cb"
	},
	{
		name: "Vala",
		color: "#fbe5cd"
	},
	{
		name: "Verilog",
		color: "#b2b7f8"
	},
	{
		name: "Vim script",
		color: "#199f4b"
	},
	{
		name: "Visual Basic",
		color: "#945db7"
	},
	{
		name: "Visual Basic .NET",
		color: "#945db7"
	},
	{
		name: "Visual Basic 6.0",
		color: "#2c6353"
	},
	{
		name: "Volt",
		color: "#1F1F1F"
	},
	{
		name: "Vue",
		color: "#2c3e50"
	},
	{
		name: "WebAssembly",
		color: "#04133b"
	},
	{
		name: "Wollok",
		color: "#a23738"
	},
	{
		name: "X10",
		color: "#4B6BEF"
	},
	{
		name: "XC",
		color: "#99DA07"
	},
	{
		name: "XQuery",
		color: "#5232e7"
	},
	{
		name: "XSLT",
		color: "#EB8CEB"
	},
	{
		name: "YARA",
		color: "#220000"
	},
	{
		name: "YASnippet",
		color: "#32AB90"
	},
	{
		name: "Yacc",
		color: "#4B6C4B"
	},
	{
		name: "ZAP",
		color: "#0d665e"
	},
	{
		name: "ZIL",
		color: "#dc75e5"
	},
	{
		name: "ZenScript",
		color: "#00BCD1"
	},
	{
		name: "Zephir",
		color: "#118f9e"
	},
	{
		name: "Zig",
		color: "#ec915c"
	},
	{
		name: "eC",
		color: "#913960"
	},
	{
		name: "mcfunction",
		color: "#E22837"
	},
	{
		name: "nesC",
		color: "#94B0C7"
	},
	{
		name: "ooc",
		color: "#b0b77e"
	},
	{
		name: "sed",
		color: "#64b970"
	},
	{
		name: "wdl",
		color: "#42f1f4"
	},
	{
		name: "wisp",
		color: "#7582D1"
	},
	{
		name: "xBase",
		color: "#403a40"
	}
];
function getAllNumberProviders() {
	return REPOS_KEY_ONLY_FILTERS.map((filter) => new NumberFilterProvider(filter, NUMBER_COUNT_VALUE, { filterTypes: {
		valueless: false,
		hasValue: false
	} }));
}
var NOT_SHOWN$1 = 10;
var REPOS_KEY_ONLY_FILTERS = [
	{
		displayName: "Total stars",
		key: "stars",
		priority: NOT_SHOWN$1,
		icon: StarIcon
	},
	{
		displayName: "Total help-wanted issues",
		key: "help-wanted-issues",
		priority: NOT_SHOWN$1,
		icon: IssueOpenedIcon
	},
	{
		displayName: "Total good-first issues",
		key: "good-first-issues",
		priority: NOT_SHOWN$1,
		icon: IssueOpenedIcon
	},
	{
		displayName: "Total forks",
		key: "forks",
		priority: NOT_SHOWN$1,
		icon: RepoForkedIcon
	},
	{
		displayName: "Size (Kb)",
		key: "size",
		priority: NOT_SHOWN$1,
		icon: FileIcon
	},
	{
		displayName: "Total topics",
		key: "topics",
		priority: NOT_SHOWN$1,
		icon: TelescopeIcon
	}
];
var NUMBER_COUNT_VALUE = [{
	value: ">0",
	displayName: "At least 1",
	priority: 1
}, {
	value: ">10",
	displayName: "More than 10",
	priority: 2
}];
var NumberFilterProvider = class extends NumericFilterProvider {
	constructor(filter, values, options) {
		super(filter, values, options);
	}
};
var single = { filterTypes: {
	multiKey: false,
	multiValue: false,
	valueless: false,
	hasValue: false
} };
var comma = { filterTypes: {
	multiKey: false,
	multiValue: true,
	valueless: false,
	hasValue: false
} };
var multiKey = { filterTypes: {
	multiKey: true,
	multiValue: false,
	valueless: false,
	hasValue: false
} };
var multiComma = { filterTypes: {
	multiKey: true,
	multiValue: true,
	valueless: false,
	hasValue: false
} };
function getAllStaticProviders(orgs = [], options = {}) {
	const { withRelevanceSort, withFinderTerms, withOwnerTerms, includeDeploymentProperties } = options;
	const providers = [
		new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.has, REPOS_STATIC_FILTER_VALUES.has, single),
		new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.in, REPOS_STATIC_FILTER_VALUES.in, comma),
		new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.is, REPOS_STATIC_FILTER_VALUES.is, {
			...comma,
			support: {
				status: ProviderSupportStatus.Deprecated,
				message: "Filter \"is:\" is deprecated, use \"visibility:\" or \"sponsorable:\" instead"
			}
		}),
		new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.license, REPOS_STATIC_FILTER_VALUES.license, comma),
		new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.topic, REPOS_STATIC_FILTER_VALUES.topic, multiComma),
		new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.visibility, REPOS_STATIC_FILTER_VALUES.visibility, comma),
		new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.fork, void 0, single),
		new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.archived, void 0, single),
		new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.mirror, void 0, single),
		new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.sponsorable, void 0, single),
		new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.template, void 0, single)
	];
	const sortingValues = withRelevanceSort ? REPOS_STATIC_FILTER_VALUES.sort : REPOS_STATIC_FILTER_VALUES.sort.filter((sort) => sort.value !== "relevance");
	providers.push(new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.sort, sortingValues, multiKey));
	if (includeDeploymentProperties) providers.push(new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.deployable, void 0, single), new BooleanFilterProvider(REPOS_STATIC_FILTER_KEYS.deployed, void 0, single));
	if (withFinderTerms) providers.push(new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.adminableBy, REPOS_STATIC_FILTER_VALUES.adminableBy, single), new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.contributedBy, REPOS_STATIC_FILTER_VALUES.contributedBy, single));
	if (withOwnerTerms) providers.push(new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.org, getOrgValues(orgs), multiComma, FilterProviderType.Text), new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.owner, REPOS_STATIC_FILTER_VALUES.user, multiComma, FilterProviderType.Text), new ValuesFilterProvider(REPOS_STATIC_FILTER_KEYS.user, REPOS_STATIC_FILTER_VALUES.user, multiComma, FilterProviderType.Text));
	return providers;
}
var NOT_SHOWN = 10;
var REPOS_STATIC_FILTER_KEYS = {
	adminableBy: {
		displayName: "Admin Access",
		key: "admin",
		description: "",
		priority: NOT_SHOWN,
		icon: GearIcon
	},
	archived: {
		displayName: "Archived",
		key: "archived",
		description: "",
		priority: NOT_SHOWN,
		icon: ArchiveIcon
	},
	contributedBy: {
		displayName: "Contributions",
		key: "contributed-by",
		description: "",
		priority: NOT_SHOWN,
		icon: PersonIcon
	},
	fork: {
		displayName: "Fork",
		key: "fork",
		description: "",
		priority: 3,
		icon: RepoForkedIcon
	},
	has: {
		displayName: "Has",
		key: "has",
		description: "",
		priority: NOT_SHOWN,
		icon: FileIcon
	},
	in: {
		displayName: "In",
		key: "in",
		description: "",
		priority: NOT_SHOWN,
		icon: AppsIcon
	},
	is: {
		displayName: "Is",
		key: "is",
		description: "",
		priority: NOT_SHOWN,
		icon: EyeIcon
	},
	license: {
		displayName: "License",
		key: "license",
		description: "",
		priority: 4,
		icon: LawIcon
	},
	mirror: {
		displayName: "Mirror",
		key: "mirror",
		description: "",
		priority: 3,
		icon: MirrorIcon
	},
	org: {
		displayName: "Organization",
		key: "org",
		description: "",
		priority: NOT_SHOWN,
		icon: OrganizationIcon
	},
	owner: {
		displayName: "Owner",
		key: "owner",
		description: "",
		priority: NOT_SHOWN,
		icon: PersonIcon
	},
	sort: {
		displayName: "Sort",
		key: "sort",
		description: "Order of results",
		priority: NOT_SHOWN,
		icon: SortAscIcon
	},
	sponsorable: {
		displayName: "Sponsorable",
		key: "sponsorable",
		description: "",
		priority: NOT_SHOWN,
		icon: HeartIcon
	},
	template: {
		displayName: "Template",
		key: "template",
		description: "",
		priority: NOT_SHOWN,
		icon: RepoTemplateIcon
	},
	topic: {
		displayName: "Topic",
		key: "topic",
		priority: NOT_SHOWN,
		icon: TelescopeIcon
	},
	user: {
		displayName: "User",
		key: "user",
		description: "",
		priority: NOT_SHOWN,
		icon: PersonIcon
	},
	visibility: {
		displayName: "Visibility",
		key: "visibility",
		description: "",
		priority: 3,
		icon: EyeIcon
	},
	deployable: {
		displayName: "Deployable",
		key: "deployable",
		description: "",
		priority: 3,
		icon: PackageIcon
	},
	deployed: {
		displayName: "Deployed",
		key: "deployed",
		description: "",
		priority: 3,
		icon: PackageDependentsIcon
	}
};
var VISIBILITY_FILTER_VALUES = [
	{
		value: "public",
		displayName: "Public",
		priority: 1
	},
	{
		value: "private",
		displayName: "Private",
		priority: 2
	},
	{
		value: "internal",
		displayName: "Internal",
		priority: 3
	}
];
var REPOS_STATIC_FILTER_VALUES = {
	adminableBy: [{
		value: "@me",
		displayName: "Me",
		priority: 1
	}],
	contributedBy: [{
		value: "@me",
		displayName: "Me",
		priority: 1
	}],
	has: [{
		value: "funding-file",
		displayName: "Funding file",
		priority: 1
	}],
	is: [...VISIBILITY_FILTER_VALUES, {
		value: "sponsorable",
		displayName: "Sponsorable",
		priority: 4
	}],
	in: [
		{
			value: "name",
			displayName: "Name",
			priority: 1
		},
		{
			value: "description",
			displayName: "Description",
			priority: 2
		},
		{
			value: "readme",
			displayName: "README",
			priority: 3
		},
		{
			value: "topics",
			displayName: "Topics",
			priority: 4
		}
	],
	license: [
		{
			value: "0bsd",
			displayName: "BSD Zero Clause License",
			priority: 1
		},
		{
			value: "mit",
			displayName: "MIT License",
			priority: 2
		},
		{
			value: "apache-2.0",
			displayName: "Apache License 2.0",
			priority: 3
		},
		{
			value: "cc",
			displayName: "Creative Commons",
			priority: 4
		},
		{
			value: "gpl",
			displayName: "GNU General Public License",
			priority: 5
		},
		{
			value: "lgpl",
			displayName: "GNU Lesser General Public License",
			priority: 6
		}
	],
	sort: [
		{
			value: "updated",
			displayName: "Recently pushed",
			icon: CalendarIcon,
			priority: 1
		},
		{
			value: "name-asc",
			displayName: "Name",
			icon: TypographyIcon,
			priority: 2
		},
		{
			value: "language-asc",
			displayName: "Language",
			icon: CodeIcon,
			priority: 3
		},
		{
			value: "license-asc",
			displayName: "License",
			icon: LawIcon,
			priority: 3
		},
		{
			value: "topics",
			displayName: "Topics",
			icon: TelescopeIcon,
			priority: 3
		},
		{
			value: "size",
			displayName: "Size",
			icon: FileIcon,
			priority: 3
		},
		{
			value: "stars",
			displayName: "Total stars",
			icon: StarIcon,
			priority: 3
		},
		{
			value: "forks",
			displayName: "Total forks",
			icon: RepoForkedIcon,
			priority: 3
		},
		{
			value: "relevance",
			displayName: "Relevance",
			icon: PersonIcon,
			priority: 3
		},
		{
			value: "updated-asc",
			displayName: "Recently pushed (descending)",
			icon: CalendarIcon,
			priority: NOT_SHOWN
		},
		{
			value: "name",
			displayName: "Name (descending)",
			icon: TypographyIcon,
			priority: NOT_SHOWN
		},
		{
			value: "language",
			displayName: "Language (descending)",
			icon: CodeIcon,
			priority: NOT_SHOWN
		},
		{
			value: "license",
			displayName: "License (descending)",
			icon: LawIcon,
			priority: NOT_SHOWN
		},
		{
			value: "topics-asc",
			displayName: "Topics (ascending)",
			icon: TelescopeIcon,
			priority: NOT_SHOWN
		},
		{
			value: "size-asc",
			displayName: "Size (ascending)",
			icon: FileIcon,
			priority: NOT_SHOWN
		},
		{
			value: "stars-asc",
			displayName: "Total stars (ascending)",
			icon: StarIcon,
			priority: NOT_SHOWN
		},
		{
			value: "forks-asc",
			displayName: "Total forks (ascending)",
			icon: RepoForkedIcon,
			priority: NOT_SHOWN
		},
		{
			value: "help-wanted-issues-asc",
			displayName: "Help-wanted issues (ascending)",
			icon: IssueOpenedIcon,
			priority: 5
		},
		{
			value: "help-wanted-issues",
			displayName: "Help-wanted issues (descending)",
			icon: IssueOpenedIcon,
			priority: 5
		}
	],
	topic: [],
	user: [{
		value: "@me",
		displayName: "Me",
		priority: 1
	}],
	visibility: VISIBILITY_FILTER_VALUES
};
function getOrgValues(orgs) {
	return orgs.map((org) => ({
		value: org,
		displayName: org,
		priority: 1,
		icon: OrganizationIcon
	}));
}
var ValuesFilterProvider = class extends SelectFilterProvider {
	constructor(filter, values, options, type) {
		super(filter, values, {
			...options,
			strictMatching: type !== FilterProviderType.Text && values.length > 0
		});
	}
};
function ReposFilter({ definitions, orgs, options, ...props }) {
	const actualProviders = getDefaultReposProviders(definitions, orgs, options);
	return /* @__PURE__ */ jsx(Filter, {
		...props,
		providers: actualProviders
	});
}
ReposFilter.displayName = "ReposFilter";
function getDefaultReposProviders(definitions, orgs, options) {
	const providers = [
		...getAllStaticProviders(orgs, options),
		...getAllNumberProviders(),
		...getAllDateProviders()
	];
	if (definitions && definitions.length > 0) providers.push(getCustomPropertiesProvider(definitions));
	return [...providers, new LanguageStaticFilterProvider()];
}
var FinderHeader_module_default = {
	description: "FinderHeader-module_H86hVW_description",
	gap_2: "FinderHeader-module_H86hVW_gap_2"
};
var sidebarLinks = [
	{
		id: "contributed",
		name: "My contributions",
		searchType: "repositories",
		query: "contributed-by:@me",
		icon: "people",
		color: "gray",
		source: "predefined"
	},
	{
		id: "owned",
		name: "My repositories",
		searchType: "repositories",
		query: "owner:@me",
		icon: "person",
		color: "gray",
		source: "predefined"
	},
	{
		id: "forks",
		name: "My forks",
		searchType: "repositories",
		query: "owner:@me fork:true",
		icon: "repo_forked",
		color: "gray",
		source: "predefined"
	},
	{
		id: "adminable",
		name: "Admin access",
		searchType: "repositories",
		query: "admin:@me",
		icon: "gear",
		color: "gray",
		source: "predefined"
	},
	{
		id: "internal",
		name: "Internal",
		searchType: "repositories",
		query: "visibility:internal archived:false",
		icon: "organization",
		color: "gray",
		source: "predefined"
	},
	{
		id: "private",
		name: "Private",
		searchType: "repositories",
		query: "visibility:private archived:false",
		icon: "repo_locked",
		color: "gray",
		source: "predefined"
	}
];
function FinderSidebar({ type, onSelectLink }) {
	return /* @__PURE__ */ jsx(ListSidebar, {
		links: getSidebarLinks(),
		selectedLink: type,
		onSelectLink
	});
}
FinderSidebar.displayName = "FinderSidebar";
function FinderSidebarCollapsedButton({ type, onSelectLink, shortcuts, onCreateView }) {
	return /* @__PURE__ */ jsx(ListSidebarCollapsedButton, {
		showCreateShortcuts: true,
		links: [...getSidebarLinks(), ...shortcuts],
		selectedLink: type,
		onSelectLink,
		onCreateView
	});
}
FinderSidebarCollapsedButton.displayName = "FinderSidebarCollapsedButton";
function getItemFromQuery(query, shortcuts) {
	return [...sidebarLinks, ...shortcuts].find((item) => item.query === query.trim());
}
function getItemById(id, shortcuts) {
	if (!id) return void 0;
	return [...sidebarLinks, ...shortcuts].find((item) => item.id === id);
}
function getSidebarLinks() {
	if (isFeatureEnabled("repos_finder_unbounded")) return sidebarLinks;
	return sidebarLinks.filter((link) => !["internal", "private"].includes(link.id));
}
function FinderHeader({ selectedSidebarItem, reposFilterProps, shortcuts, onSelectLink, onCreateView, onEditView, onDeleteView, onUpdateQueryView, isQueryModified = false, deleteErrorMessage }) {
	const { name = "Search", description } = selectedSidebarItem || {};
	return /* @__PURE__ */ jsxs("div", { children: [
		deleteErrorMessage && /* @__PURE__ */ jsx(Flash, {
			variant: "danger",
			className: "tmp-mb-3",
			children: deleteErrorMessage
		}),
		/* @__PURE__ */ jsxs("div", {
			className: clsx("d-flex tmp-mb-3", FinderHeader_module_default.gap_2),
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex-1 min-width-0",
				children: [/* @__PURE__ */ jsxs("div", {
					className: clsx("d-flex flex-items-top", FinderHeader_module_default.gap_2),
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "hide-lg hide-xl",
							children: /* @__PURE__ */ jsx(FinderSidebarCollapsedButton, {
								type: selectedSidebarItem?.id || "",
								onSelectLink,
								shortcuts,
								onCreateView
							})
						}),
						/* @__PURE__ */ jsx("h1", {
							className: "h3 hide-sm hide-md min-width-0",
							"data-testid": "finder-header-title",
							children: /* @__PURE__ */ jsx(Truncate, {
								title: name,
								maxWidth: "100%",
								children: name
							})
						}),
						selectedSidebarItem?.source === "user" && /* @__PURE__ */ jsx(ShortcutOptionsButton, {
							onEditView: () => onEditView(selectedSidebarItem),
							onDeleteView: () => onDeleteView(selectedSidebarItem),
							onUpdateQueryView: () => onUpdateQueryView(selectedSidebarItem),
							isQueryModified
						})
					]
				}), description && /* @__PURE__ */ jsx(Truncate, {
					className: FinderHeader_module_default.description,
					title: description,
					maxWidth: "100%",
					children: description
				})]
			}), /* @__PURE__ */ jsx("div", {
				className: "d-flex flex-items-center",
				children: /* @__PURE__ */ jsx(ButtonComponent, {
					as: "a",
					href: newRepoPath(),
					variant: "primary",
					size: "medium",
					children: "New repository"
				})
			})]
		}),
		/* @__PURE__ */ jsx(ReposFilter, { ...reposFilterProps })
	] });
}
FinderHeader.displayName = "FinderHeader";
/**
* Hook to manage the state of the repos finder layout, including query state,
* repository shortcuts, and sidebar selection. Gets data from context rather than props.
* Provides methods for updating and submitting queries, managing shortcuts, and selecting sidebar links.
*
* @returns An object containing:
*   - shortcuts: Array of repository shortcuts
*   - selectedSidebarItem: Currently selected sidebar link
*   - editing: Shortcut editing state and methods
*   - deleting: Shortcut deletion state and methods
*   - methods: Object with selectSidebarLink, createShortcut, editShortcut, and fetchResults functions
*   - reposFilterProps: Props for the repository filter component
*/
function useReposFinderLayoutState() {
	const { payload, fetchedQuery, queryParam, fetchResults, locationSidebarItemId, hasLocationState } = useReposFinderStateContext();
	const [query, setQuery] = useState(queryParam);
	const [shortcuts, setShortcuts] = useState(() => payload.repoShortcuts.map((shortcut) => ({
		...shortcut,
		searchType: "repositories"
	})));
	function deriveSidebarItem(q, sidebarItemId, fromState) {
		if (fromState) return sidebarItemId ? getItemById(sidebarItemId, shortcuts) : void 0;
		return getItemFromQuery(q, shortcuts);
	}
	const [selectedSidebarItem, setSelectedSidebarItem] = useState(() => deriveSidebarItem(query, locationSidebarItemId, hasLocationState));
	useEffect(() => {
		setQuery(queryParam);
		setSelectedSidebarItem(deriveSidebarItem(queryParam, locationSidebarItemId, hasLocationState));
	}, [
		queryParam,
		locationSidebarItemId,
		hasLocationState
	]);
	const onShortcutDeleted = (deletedShortcut) => {
		setShortcuts(shortcuts.filter((shortcut) => shortcut.id !== deletedShortcut.id));
		setSelectedSidebarItem(void 0);
	};
	const deleting = useShortcutDeletion(onShortcutDeleted);
	const onShortcutSaved = (savedShortcut) => {
		setShortcuts(getShortcutsWithSaved(shortcuts, savedShortcut));
		if (fetchedQuery !== savedShortcut.query) fetchResults({
			q: savedShortcut.query,
			page: 1,
			sidebarItemId: savedShortcut.id
		});
		else setSelectedSidebarItem(savedShortcut);
	};
	const editing = useShortcutEditor({
		type: "repositories",
		onShortcutSaved
	});
	const { data: pagePayload } = useChildRouteQuery(reposFinderPageRoute, "mainQuery");
	const showFilterDialog = useFeatureFlag("repos_list_show_filter_dialog");
	const definitions = pagePayload?.customProperties?.definitions ?? [];
	const includeDeploymentProperties = pagePayload?.includeDeploymentProperties ?? false;
	function updateQuery(q) {
		setQuery(q);
		if (editing.shortcut) editing.setValue("query", q);
	}
	async function kindlyDismissEditing() {
		if (editing.shortcut) {
			if (!await editing.dismiss()) return false;
		}
		return true;
	}
	async function selectSidebarLink(linkItem) {
		if (!await kindlyDismissEditing()) return;
		deleting.reset();
		fetchResults({
			q: linkItem.query,
			page: 1,
			sidebarItemId: linkItem.id
		});
	}
	async function createShortcut() {
		if (!await kindlyDismissEditing()) return;
		setSelectedSidebarItem(void 0);
		deleting.reset();
		editing.create(query, selectedSidebarItem);
	}
	function editShortcut(shortcut) {
		deleting.reset();
		editing.edit(shortcut, query);
	}
	function updateShortcut(shortcut) {
		deleting.reset();
		editing.updateQuery(shortcut, fetchedQuery);
	}
	const reposFilterProps = {
		options: {
			withOwnerTerms: true,
			withFinderTerms: true,
			withRelevanceSort: true,
			includeDeploymentProperties
		},
		id: "repos-finder-filter",
		label: "Search repositories",
		variant: showFilterDialog ? "full" : "input",
		placeholder: "Search repositories",
		filterValue: query,
		orgs: payload.suggestedOrgs,
		definitions,
		onChange: updateQuery,
		onSubmit: (filterQuery) => fetchResults({
			q: filterQuery.raw,
			page: 1,
			sidebarItemId: selectedSidebarItem?.id || ""
		})
	};
	return {
		shortcuts,
		selectedSidebarItem,
		editing,
		deleting,
		methods: {
			selectSidebarLink,
			createShortcut,
			editShortcut,
			updateShortcut,
			fetchResults
		},
		reposFilterProps
	};
}
function ReposFinderLayoutEntrypoint() {
	const $ = c(2);
	const { data: payload } = useRouteQuery(reposFinderLayoutRoute, "mainQuery");
	let t0;
	if ($[0] !== payload) {
		t0 = jsxs(AnalyticsProvider, {
			appName: "repos-finder-page",
			category: "Finder page",
			metadata: { page: "repos-finder" },
			children: [jsx(ContextualGlobalSsoBanner, {}), jsx(ReposFinderStateProvider, {
				payload,
				children: jsx(ReposFinderLayout, {})
			})]
		});
		$[0] = payload;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
ReposFinderLayoutEntrypoint.displayName = "ReposFinderLayoutEntrypoint";
function ReposFinderLayout() {
	const $ = c(17);
	const { shortcuts, selectedSidebarItem, editing, deleting, methods, reposFilterProps } = useReposFinderLayoutState();
	const { fetchedQuery } = useReposFinderStateContext();
	const { state: navigationState } = useNavigation();
	const isLoading = navigationState === "loading";
	let t0;
	if ($[0] !== deleting || $[1] !== editing.dismiss || $[2] !== editing.errorMessage || $[3] !== editing.isSaving || $[4] !== editing.saveAndDismiss || $[5] !== editing.setValue || $[6] !== editing.shortcut || $[7] !== fetchedQuery || $[8] !== isLoading || $[9] !== methods.createShortcut || $[10] !== methods.editShortcut || $[11] !== methods.selectSidebarLink || $[12] !== methods.updateShortcut || $[13] !== reposFilterProps || $[14] !== selectedSidebarItem || $[15] !== shortcuts) {
		t0 = jsxs(PageLayout, {
			containerWidth: "full",
			columnGap: "none",
			padding: "none",
			children: [jsx(PageLayout.Pane, {
				divider: "line",
				hidden: {
					narrow: true,
					regular: false,
					wide: false
				},
				padding: "condensed",
				position: "start",
				className: "min-height-full",
				children: jsxs("aside", { children: [jsx(FinderSidebar, {
					type: selectedSidebarItem?.id || "",
					onSelectLink: methods.selectSidebarLink
				}), jsx(ReposShortcutSidebar, {
					shortcuts,
					onSelectLink: methods.selectSidebarLink,
					selectedLink: selectedSidebarItem?.id || "",
					onCreateView: methods.createShortcut
				})] })
			}), jsxs(PageLayout.Content, {
				as: "div",
				padding: "condensed",
				className: "px-2 mx-auto",
				style: { maxWidth: "1400px" },
				children: [editing.shortcut ? jsx(ShortcutEditingHeader, {
					renderFilter: (filterProps) => jsx(ReposFilter, {
						...filterProps,
						...reposFilterProps
					}),
					onSave: editing.saveAndDismiss,
					onDismiss: editing.dismiss,
					shortcut: editing.shortcut,
					setShortcutValue: editing.setValue,
					isSaving: editing.isSaving,
					errorMessage: editing.errorMessage
				}) : jsx(FinderHeader, {
					selectedSidebarItem,
					reposFilterProps,
					shortcuts,
					onSelectLink: methods.selectSidebarLink,
					onCreateView: methods.createShortcut,
					onDeleteView: deleting.deleteShortcut,
					onEditView: methods.editShortcut,
					onUpdateQueryView: methods.updateShortcut,
					isQueryModified: !isLoading && fetchedQuery !== selectedSidebarItem?.query,
					deleteErrorMessage: deleting.errorMessage
				}), jsx(Outlet$1, {})]
			})]
		});
		$[0] = deleting;
		$[1] = editing.dismiss;
		$[2] = editing.errorMessage;
		$[3] = editing.isSaving;
		$[4] = editing.saveAndDismiss;
		$[5] = editing.setValue;
		$[6] = editing.shortcut;
		$[7] = fetchedQuery;
		$[8] = isLoading;
		$[9] = methods.createShortcut;
		$[10] = methods.editShortcut;
		$[11] = methods.selectSidebarLink;
		$[12] = methods.updateShortcut;
		$[13] = reposFilterProps;
		$[14] = selectedSidebarItem;
		$[15] = shortcuts;
		$[16] = t0;
	} else t0 = $[16];
	return t0;
}
ReposFinderLayout.displayName = "ReposFinderLayout";
var SplitComponent = ReposFinderLayoutEntrypoint;
export { SplitComponent as component };
