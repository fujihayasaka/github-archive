import { useEffect, useEffectEvent, useState } from "react";
import { c } from "react/compiler-runtime";
var STICKY_OBSERVER_OPTIONS = {
	threshold: [1],
	rootMargin: "-1px 0px 0px 0px"
};
function useStickyObserver(element) {
	const $ = c(10);
	const managed = arguments.length === 0;
	const [isSticky, setIsSticky] = useState(false);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (entries) => {
			const entry = entries[entries.length - 1];
			if (entry) setIsSticky(entry.intersectionRatio < 1);
		};
		$[0] = t0;
	} else t0 = $[0];
	const handler = useEffectEvent(t0);
	const [trackedElement, setTrackedElement] = useState(null);
	const target = managed ? trackedElement : element ?? null;
	let t1;
	if ($[1] !== handler || $[2] !== target) {
		t1 = () => {
			if (!target) return;
			const observer = new IntersectionObserver((entries_0) => handler(entries_0), STICKY_OBSERVER_OPTIONS);
			observer.observe(target);
			return () => observer.disconnect();
		};
		$[1] = handler;
		$[2] = target;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== target) {
		t2 = [target];
		$[4] = target;
		$[5] = t2;
	} else t2 = $[5];
	useEffect(t1, t2);
	if (managed) {
		let t3;
		if ($[6] !== isSticky) {
			t3 = {
				isSticky,
				sentinelRef: setTrackedElement
			};
			$[6] = isSticky;
			$[7] = t3;
		} else t3 = $[7];
		return t3;
	}
	let t3;
	if ($[8] !== isSticky) {
		t3 = { isSticky };
		$[8] = isSticky;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
export { useStickyObserver as t };
