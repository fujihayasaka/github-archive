import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { s as KeybindingHint, t as Announce } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { $r as StrikethroughIcon, $t as HeadingIcon, Cn as ListOrderedIcon, G as CodeSquareIcon, H as CodeIcon, O as CheckIcon, Q as ComposeIcon, Sn as LinkIcon, Yn as PaperclipIcon, ai as TasklistIcon, bn as Link, gn as ItalicIcon, n as ActionList, o as AlertIcon, ur as QuoteIcon, wn as ListUnorderedIcon, y as BoldIcon, yt as EyeIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { t as TabNav_default } from "./server-TabNav-ChmPEmaf-BGcvB88p.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { t as AlphaLabel } from "./server-AlphaLabel-CP7CzFaj-k7z2o8os.js";
import { t as ActionBar } from "./server-ActionBar-DNCrmOcX-Dfop-h7_.js";
import { n as rehype, t as all } from "./server-lowlight-Dh7yBHKt-DO4QO0C5.js";
import { r as fuzzyScore } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
import { r as suggestionsCalculator } from "./server-use-mention-suggestions-CJBNKUGO-wdkkDgZ6.js";
import { createContext, memo, use, useCallback, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { c as c$1 } from "react/compiler-runtime";
import { EditorView, ViewPlugin, keymap } from "@codemirror/view";
import { Annotation, ChangeSet, EditorSelection, EditorState, StateEffect, StateField, Text } from "@codemirror/state";
import { EXIT, SKIP, visit } from "unist-util-visit";
import { h } from "hastscript";
import { EXIT as EXIT$1, SKIP as SKIP$1, visitParents } from "unist-util-visit-parents";
import { raw } from "hast-util-raw";
import { toHast } from "mdast-util-to-hast";
import { VFile } from "vfile";
import { find, html } from "property-information";
import { defaultSchema, sanitize } from "hast-util-sanitize";
import mergeWith from "lodash-es/mergeWith.js";
import { fromMarkdown } from "mdast-util-from-markdown";
import { gfmFromMarkdown } from "mdast-util-gfm";
import { gfm } from "micromark-extension-gfm";
import { Tokenizer } from "parse5";
function AriaAlert(props) {
	var _props$announceOnShow;
	const $ = c(3);
	const t0 = (_props$announceOnShow = props.announceOnShow) !== null && _props$announceOnShow !== void 0 ? _props$announceOnShow : true;
	let t1;
	if ($[0] !== props || $[1] !== t0) {
		t1 = /* @__PURE__ */ jsx(Announce, {
			...props,
			announceOnShow: t0,
			politeness: "assertive"
		});
		$[0] = props;
		$[1] = t0;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
var ErrorBanner_module_default = { errorBanner: "ErrorBanner-module_1qSxEa_errorBanner" };
/**
* A pre-styled error banner for use inside the MarkdownEditor.
* Wraps content in AriaAlert for accessibility announcements.
*
* @example
* ```tsx
* <MarkdownEditor
*   banner={errorMessage ? <MarkdownEditor.ErrorBanner>{errorMessage}</MarkdownEditor.ErrorBanner> : undefined}
* />
* ```
*/
var ErrorBanner = memo(({ children }) => /* @__PURE__ */ jsx(Banner, {
	hideTitle: true,
	variant: "critical",
	layout: "compact",
	title: "Error",
	description: /* @__PURE__ */ jsx(AriaAlert, { children }),
	flush: true,
	className: ErrorBanner_module_default.errorBanner
}));
ErrorBanner.displayName = "ErrorBanner";
ErrorBanner.displayName = "MarkdownEditor.ErrorBanner";
var segmented_control_module_default = {
	active: "segmented-control-module_Z88TsW_active",
	segmentedControl: "segmented-control-module_Z88TsW_segmentedControl"
};
var SegmentedControlViewSwitch = ({ selectedView, onViewSelect, onLoadPreview, disabled }) => {
	const hybridEnabled = isFeatureEnabled("markdown_experience_hybrid_editor");
	return /* @__PURE__ */ jsx("nav", { children: /* @__PURE__ */ jsxs(SegmentedControl, {
		"aria-label": "View mode",
		children: [
			/* @__PURE__ */ jsx(SegmentedControl.IconButton, {
				className: clsx(segmented_control_module_default.segmentedControl, selectedView === "edit" && segmented_control_module_default.active),
				selected: selectedView === "edit",
				value: "edit",
				"aria-label": "Edit mode",
				disabled,
				icon: /* @__PURE__ */ jsx(CodeIcon, {}),
				onClick: () => onViewSelect?.("edit")
			}),
			/* @__PURE__ */ jsx(SegmentedControl.IconButton, {
				className: clsx(segmented_control_module_default.segmentedControl, selectedView === "preview" && segmented_control_module_default.active),
				selected: selectedView === "preview",
				value: "preview",
				"aria-label": "Preview mode",
				disabled,
				icon: /* @__PURE__ */ jsx(EyeIcon, {}),
				onClick: () => onViewSelect?.("preview"),
				onMouseOver: () => onLoadPreview?.(),
				onFocus: () => onLoadPreview?.()
			}),
			hybridEnabled && /* @__PURE__ */ jsx(SegmentedControl.IconButton, {
				className: clsx(segmented_control_module_default.segmentedControl, selectedView === "hybrid" && segmented_control_module_default.active),
				value: "hybrid",
				selected: selectedView === "hybrid",
				"aria-label": "Hybrid mode",
				disabled,
				icon: /* @__PURE__ */ jsx(ComposeIcon, {}),
				onClick: () => onViewSelect?.("hybrid")
			})
		]
	}) });
};
SegmentedControlViewSwitch.displayName = "SegmentedControlViewSwitch";
var tab_nav_module_default = {
	active: "tab-nav-module_JZPEOq_active",
	lifecycleLabel: "tab-nav-module_JZPEOq_lifecycleLabel",
	tabNavLink: "tab-nav-module_JZPEOq_tabNavLink",
	viewSwitch: "tab-nav-module_JZPEOq_viewSwitch"
};
var TabNavViewSwitch = ({ selectedView, onViewSelect, onLoadPreview, disabled }) => {
	const hybridEnabled = isFeatureEnabled("markdown_experience_hybrid_editor");
	return /* @__PURE__ */ jsx("div", {
		className: tab_nav_module_default.viewSwitch,
		children: /* @__PURE__ */ jsxs(TabNav_default, {
			"aria-label": "View mode",
			children: [
				/* @__PURE__ */ jsx(TabNav_default.Link, {
					as: "button",
					selected: selectedView === "edit",
					disabled,
					className: clsx(tab_nav_module_default.tabNavLink, selectedView === "edit" && tab_nav_module_default.active),
					onClick: () => onViewSelect?.("edit"),
					children: "Write"
				}),
				/* @__PURE__ */ jsx(TabNav_default.Link, {
					as: "button",
					selected: selectedView === "preview",
					disabled,
					className: clsx(tab_nav_module_default.tabNavLink, selectedView === "preview" && tab_nav_module_default.active),
					onClick: () => onViewSelect?.("preview"),
					onMouseOver: () => onLoadPreview?.(),
					onFocus: () => onLoadPreview?.(),
					children: "Preview"
				}),
				hybridEnabled && /* @__PURE__ */ jsx(TabNav_default.Link, {
					as: "button",
					selected: selectedView === "hybrid",
					disabled,
					className: clsx(tab_nav_module_default.tabNavLink, selectedView === "hybrid" && tab_nav_module_default.active),
					onClick: () => onViewSelect?.("hybrid"),
					children: "Hybrid"
				})
			]
		})
	});
};
TabNavViewSwitch.displayName = "TabNavViewSwitch";
var ViewSwitch = (props) => {
	return isFeatureEnabled("markdown_experience_toolbar_redesign") ? /* @__PURE__ */ jsx(SegmentedControlViewSwitch, { ...props }) : /* @__PURE__ */ jsx(TabNavViewSwitch, { ...props });
};
ViewSwitch.displayName = "ViewSwitch";
var Header_module_default = {
	header: "Header-module_3r7X3a_header",
	previewLabel: "Header-module_3r7X3a_previewLabel",
	redesignEnabled: "Header-module_3r7X3a_redesignEnabled"
};
/**
* Header layout container.
* Important: this is also rendered by error fallbacks so logic that might fail should be kept to an absolute minimum.
*/
function Header({ onChangeViewMode, selectedView = "hybrid", children, uploadInProgress = false }) {
	const toolbarRedesignEnabled = isFeatureEnabled("markdown_experience_toolbar_redesign");
	const viewSwitch = /* @__PURE__ */ jsx(ViewSwitch, {
		selectedView,
		onViewSelect: onChangeViewMode,
		disabled: !onChangeViewMode || uploadInProgress
	});
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(Header_module_default.header, toolbarRedesignEnabled && Header_module_default.redesignEnabled),
		children: [
			!toolbarRedesignEnabled && viewSwitch,
			children,
			/* @__PURE__ */ jsx(AlphaLabel, { className: Header_module_default.previewLabel }),
			toolbarRedesignEnabled && viewSwitch
		]
	});
}
Header.displayName = "Header";
var feedbackUrl = "https://github-grid.enterprise.slack.com/archives/C08M545RDCN";
function ErrorFallback({ onChangeViewMode }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Header, {
		onChangeViewMode,
		selectedView: "hybrid"
	}), /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
		/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(AlertIcon, { size: "medium" }) }),
		/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: "Something went wrong" }),
		/* @__PURE__ */ jsxs(BlankslateContainer.Description, {
			style: {
				textAlign: "center",
				maxWidth: "700px"
			},
			children: [
				"The hybrid Markdown editing experience is temporarily unavailable due to an unknown error. Please",
				" ",
				/* @__PURE__ */ jsx(Link, {
					inline: true,
					href: feedbackUrl,
					children: "report this error"
				}),
				" ",
				"to the team along with browser console logs, if possible."
			]
		})
	] })] });
}
ErrorFallback.displayName = "ErrorFallback";
var HybridMarkdownEditor_module_default = {
	container: "HybridMarkdownEditor-module_PC_WOa_container",
	editorWrapper: "HybridMarkdownEditor-module_PC_WOa_editorWrapper",
	generatingText: "HybridMarkdownEditor-module_PC_WOa_generatingText",
	isDraggedOver: "HybridMarkdownEditor-module_PC_WOa_isDraggedOver",
	modPressed: "HybridMarkdownEditor-module_PC_WOa_modPressed",
	skeletonOverlay: "HybridMarkdownEditor-module_PC_WOa_skeletonOverlay"
};
function FileUploadButton(props) {
	return /* @__PURE__ */ jsx(ActionBar.IconButton, {
		onMouseDown: (e) => e.preventDefault(),
		variant: "invisible",
		icon: PaperclipIcon,
		"aria-label": "Attachment",
		...props
	});
}
FileUploadButton.displayName = "FileUploadButton";
function startOfLine(source, offset) {
	return source.slice(0, offset).lastIndexOf("\n") + 1;
}
function endOfLine(source, offset) {
	const end = source.indexOf("\n", offset);
	return end === -1 ? source.length : end;
}
/** Get the start and end of the line that contains this offset. Does not include the `\n` at the end of the line. */
function getLineRange(source, offset) {
	if (offset < 0 || offset > source.length) return null;
	return {
		start: startOfLine(source, offset),
		end: endOfLine(source, offset)
	};
}
/** Get the start and ends of each line that overlaps the range. */
function getLineRanges(source, from, to) {
	const ranges = [];
	let start = startOfLine(source, from);
	while (start <= to) {
		const end = endOfLine(source, start);
		ranges.push({
			start,
			end
		});
		start = end + 1;
	}
	return ranges;
}
/** Type guard to check if a node has a valid position as offsets into the document. */
function isPositionedNode(node) {
	return node.position !== void 0 && node.position.start !== void 0 && node.position.end !== void 0 && typeof node.position.start.offset === "number" && typeof node.position.end.offset === "number";
}
/** Compare node positions for sorting. */
function compareNodePositions(a, b) {
	if (!isPositionedNode(a) || !isPositionedNode(b)) return 0;
	if (a.position.start.offset !== b.position.start.offset) return a.position.start.offset - b.position.start.offset;
	return a.position.end.offset - b.position.end.offset;
}
function overlapsNode(rangeFrom, rangeTo, nodeFrom, nodeTo) {
	return rangeFrom >= nodeFrom && rangeFrom <= nodeTo || rangeTo >= nodeFrom && rangeTo <= nodeTo || rangeFrom <= nodeFrom && rangeTo >= nodeTo;
}
/**
* Returns all the nodes that overlap the given range, including the root node (`parent`).
*/
function getNodesOverlappingRange(tree, from, to) {
	const result = [];
	visit(tree, (node) => {
		if (!isPositionedNode(node)) return;
		if (overlapsNode(from, to, node.position.start.offset, node.position.end.offset)) result.push(node);
		else return SKIP$1;
	});
	return result;
}
/** 'Shallow' version of `getNodesOverlappingRange`; only returns direct descendants. */
function getChildrenOverlappingRange(tree, from, to) {
	return tree.children.filter((node) => isPositionedNode(node) && overlapsNode(from, to, node.position?.start.offset, node.position.end.offset));
}
/** Check if the node fully contains the range. */
function containsRange(rangeFrom, rangeTo, nodeFrom, nodeTo, inclusive) {
	if (inclusive) return rangeFrom >= nodeFrom && rangeTo <= nodeTo;
	return rangeFrom >= nodeFrom && rangeTo <= nodeTo && !(rangeFrom === nodeFrom && rangeTo === nodeTo);
}
/**
* Returns all nodes that fully contain the given range. Inclusive of nodes that start or end at the range
* boundaries:
*
* - Included: `|...range|`, `|range...|`, `|...range...|`
* - Excluded: `range|...|`, `ra|nge..|`
*
* Nodes that both start _and_ end at range boundaries are included if `inclusive` is true (`|range|`).
*/
function getNodesContainingRange(tree, from, to, inclusive) {
	const result = [];
	visit(tree, (node) => {
		if (!isPositionedNode(node)) return;
		if (containsRange(from, to, node.position.start.offset, node.position.end.offset, inclusive)) result.push(node);
		else return SKIP$1;
	});
	return result;
}
/** Check if the range fully contains the node. */
function containsNode(rangeFrom, rangeTo, nodeFrom, nodeTo) {
	return nodeFrom >= rangeFrom && nodeTo <= rangeTo;
}
/**
* Returns all nodes that are fully inside the given range. Inclusive of start and end.
* NOTE: You might expect this method to be exclusive of the end, just like `String.slice` would be. But remember that
* unist nodes are already exclusive of their end position. So if you give the range `0,5` and get a node from `0` to
* `5`, that node actually covers the text from indexes `0` to `4`.
*/
function getNodesInsideRange(tree, from, to) {
	const result = [];
	visit(tree, (node) => {
		if (!isPositionedNode(node)) return;
		const nodeFrom = node.position.start.offset;
		const nodeTo = node.position.end.offset;
		if (!overlapsNode(from, to, nodeFrom, nodeTo)) return SKIP$1;
		if (containsNode(from, to, nodeFrom, nodeTo)) result.push(node);
	});
	return result;
}
/** Return the lowest node in the tree at the given `offset` that is not a `text` or `delimiter` node. */
function getNodeAtOffset(tree, offset) {
	let result = void 0;
	visit(tree, (node) => {
		if (!isPositionedNode(node)) return;
		if (containsRange(offset, offset, node.position.start.offset, node.position.end.offset) && node.type !== "text" && node.type !== "delimiter") result = node;
		else return SKIP$1;
	});
	return result;
}
/** Sum two `Point` objects together. Useful for getting a document-level offset from a local node-relative offset. */
function addPoints(a, b) {
	return {
		column: a.column + b.column - 1,
		line: a.line + b.line - 1,
		offset: (a.offset ?? 0) + (b.offset ?? 0)
	};
}
/** Given a start `Point` and some text, calculate the end `Point`. */
function calculateEndPoint(start, text) {
	const lines = text.split("\n");
	const lastLine = lines.at(-1);
	return {
		...start,
		line: start.line + lines.length - 1,
		column: lines.length === 1 ? start.column + text.length : lastLine.length + 1,
		offset: start.offset !== void 0 ? start.offset + text.length : void 0
	};
}
/** Returns the document-relative position of the delimiter excluding leading and trailing whitespace. */
function trimmedDelimiterPosition(delimiter) {
	const raw = delimiter.raw;
	const startIndex = raw.search(/\S/);
	const endIndex = raw.length - raw.trimEnd().length;
	return {
		startOffset: delimiter.position.start.offset + startIndex,
		endOffset: delimiter.position.end.offset - endIndex
	};
}
/**
* Insert `newChild` at `index` in `node`'s children, expanding the size of `node` to include the child if necessary.
* Does not validate the index (ie, does not compare position to other children). Mutates `node`.
* @param node The node to modify. Start position will be expanded to include `newChild`'s position if necessary.
* @param index Index at which to insert the new child. Use negative indices to count from the end.
* @param newChild The new child to modify. Since only delimiters can exist under every node, this must be a delimiter.
*/
function insertChild(node, index, newChild) {
	node.children ??= [];
	node.children.splice(index, 0, newChild);
	if (isPositionedNode(node) && isPositionedNode(newChild)) {
		if (newChild.position.start.offset < node.position.start.offset) Object.assign(node.position.start, newChild.position.start);
		else if (newChild.position.end.offset > node.position.end.offset) Object.assign(node.position.end, newChild.position.end);
	}
}
/** `insertChild` at the end of the parent. */
function pushChild(node, newChild) {
	insertChild(node, node.children?.length ?? 0, newChild);
}
/** `insertChild` at the beginning of the parent. */
function unshiftChild(node, newChild) {
	insertChild(node, 0, newChild);
}
/** Check if two nodes are immediately adjacent (touching). */
function isAdjacent(a, b) {
	return isPositionedNode(a) && isPositionedNode(b) && a.position.end.offset === b.position.start.offset;
}
/**
* Remove the child at `index` from `node`, reducing the size of `node` if `shrink` is `true`. Mutates `node`.
* @param node The node to modify.
* @param index The index of the child to remove. Use negative indices to count from the end.
* @param shrink If `true` the parent `node` position will be updated to exclude the position of the removed child.
* @returns The removed child, if one was found at that index.
*/
function removeChild(node, index, shrink = false) {
	const isLast = node.children !== void 0 && (index === node.children.length - 1 || index === -1);
	const child = node.children?.splice(index, 1)[0];
	if (shrink && child && isPositionedNode(node) && isPositionedNode(child)) {
		if (index === 0) {
			const nextChild = node.children?.[0];
			if (nextChild) Object.assign(node.position.start, nextChild.position?.start);
		} else if (isLast) {
			const prevChild = node.children?.at(-1);
			if (prevChild) Object.assign(node.position.end, prevChild.position?.end);
		}
	}
	return child;
}
/** `removeChild` at the end of the parent. */
function popChild(node, shrink = false) {
	return removeChild(node, -1, shrink);
}
/**
* Iterate over the children of a parent node in reverse order. Yields tuples of `[index, child]`. Iterating in
* reverse can be useful as it allows you to remove children from the parent as you reach them without modifying
* the indices of the children you haven't encountered yet.
*/
function* reverseChildrenEntries(parent) {
	if (!parent.children) return;
	for (let i = parent.children.length - 1; i >= 0; i--) {
		const child = parent.children[i];
		if (!child) continue;
		yield [i, child];
	}
}
function setsEqual(a, b) {
	if (a === b) return true;
	if (a.size !== b.size) return false;
	for (const item of a) if (!b.has(item)) return false;
	return true;
}
/**
* Helper type function that checks at a type level that every possible value is used. This helps to ensure that
* the list of values is updated if the type ever changes - it's essentially allowing us to go from a type union to a
* runtime `Set` in a safe manner.
*
* @example
* type Value = "value1" | "value2" | "value3"
*
* const allValues = setOfAll<Value>()("value1", "value2", "value3")
*/
var setOfAll = () => (...values) => new Set(values);
function removeTrailingSlash(url) {
	return url.endsWith("/") ? url.slice(0, url.length - 1) : url;
}
/**
* Check if `text` is a valid URL string.
*/
function isUrl(text) {
	try {
		return removeTrailingSlash(new URL(text).href).trim() === removeTrailingSlash(text).trim();
	} catch {
		return false;
	}
}
var phrasingContentNodeTypes = setOfAll()("break", "delete", "emphasis", "footnoteReference", "html", "image", "imageReference", "inlineCode", "link", "linkReference", "strong", "text", "delimiter");
var linkParentNodeTypes = setOfAll()("delete", "emphasis", "heading", "link", "linkReference", "paragraph", "strong", "tableCell", "root");
/** Node types that are allowed for creating links across boundaries (inline formatting only). */
var inlineFormattingNodeTypes = new Set([
	"delete",
	"delimiter",
	"emphasis",
	"inlineCode",
	"paragraph",
	"strong",
	"text",
	"root"
]);
/**
* Types of delimiter tokens that should be treated as prefixes. These are the delimiter tokens for multiline Markdown
* nodes that have prefixes that repeat on every line, like blockquotes.
*/
var prefixTokenTypes = new Set([
	"listItemIndent",
	"listItemPrefix",
	"blockQuotePrefix",
	"linePrefix",
	"taskListCheck"
]);
/**
* Moves delimiters into the blocks they correspond to, to make them easier to control and style. For example,
* blockquote prefixes get moved into the blockquote nodes. This is done recursively, so the blockquote prefixes
* actually get moved into the corresponding _paragraph_ node inside the blockquote node.
*/
function mdastContainDelimiters() {
	return { transforms: [containDelimiters] };
}
/** Check if the node is a 'container' that we can put prefixes into. */
function isContainer(node) {
	return !phrasingContentNodeTypes.has(node.type);
}
/**
* There's a weird edge case (bug?) in the parser where blockquote delimiters will end up trailing inside a list.
* Sometimes we want these to end up in the last list item (ie `> - item\n>   ` where we have a trailing list item
* indent), which we'll handle later, but other times they should be in the parent blockquote
* (ie `> - item\n> > nested quote`). So we first walk the tree and move any trailing prefixes out of lists and
* into the parent node, but only if they don't have listItemIndent tokens. :sob:
*/
function liftTrailingQuotePrefixesFromLists(tree) {
	visitParents(tree, "list", (list, parents) => {
		const parent = parents.at(-1);
		const targetIndex = (parent?.children?.indexOf(list) ?? -1) + 1;
		if (!parent || targetIndex === 0) return;
		let lastChild = list.children.at(-1);
		while (lastChild?.type === "delimiter" && lastChild.tokenType === "blockQuotePrefix") {
			popChild(list, true);
			insertChild(parent, targetIndex, lastChild);
			lastChild = list.children.at(-1);
		}
	});
}
function containDelimiters(tree) {
	liftTrailingQuotePrefixesFromLists(tree);
	visit(tree, (item) => {
		let nextChild = null;
		for (const [i, child] of reverseChildrenEntries(item)) {
			if (child.type === "delimiter" && prefixTokenTypes.has(child.tokenType) && nextChild && isAdjacent(child, nextChild) && isContainer(nextChild)) {
				removeChild(item, i);
				unshiftChild(nextChild, child);
				continue;
			}
			if (child.type === "listItem") while (nextChild?.type === "delimiter" && prefixTokenTypes.has(nextChild.tokenType)) {
				removeChild(item, i + 1);
				pushChild(child, nextChild);
				nextChild = item.children?.[i + 1] ?? null;
			}
			nextChild = child;
		}
	});
}
/** Remove prefixes to escape current node based on the `escapeMarkdownContinuation` value. */
function removeEscapedPrefixes(prefixes, mode) {
	switch (mode) {
		case "escapeBlockquote": return prefixes.slice(0, prefixes.findLastIndex((prefix) => prefix.tokenType === "blockQuotePrefix"));
		case "escapeList": return prefixes.slice(0, prefixes.findLastIndex((prefix) => prefix.tokenType === "listItemPrefix" || prefix.tokenType === "listItemIndent"));
		case "all": return [];
		case void 0: return prefixes;
	}
}
/** Get the string (indentation whitespace) to continue this list item on a following line. */
function buildItemContinuationSyntax(marker) {
	return " ".repeat(marker.length);
}
/** Returns the syntax that, if prepended to following lines, will continue the nodes at the given offset. */
function buildContinuationSyntax(prefixes) {
	return prefixes.map((prefix) => {
		switch (prefix.tokenType) {
			case "listItemPrefix": return buildItemContinuationSyntax(prefix.raw);
			case "taskListCheck": return "";
			default: return prefix.raw;
		}
	}).join("");
}
var defaultUnorderedListMarker = "* ";
var OrderedListMarker = {
	first: {
		prefix: "",
		digits: 1,
		suffix: ". "
	},
	parse(raw) {
		const match = raw.match(/^(?<prefix>\s*)(?<digits>\d{1,9})(?<suffix>[.)]\s*)$/)?.groups;
		return match ? {
			...match,
			digits: parseInt(match.digits, 10)
		} : void 0;
	},
	serialize(marker) {
		return `${marker.prefix}${marker.digits}${marker.suffix}`;
	},
	increment(marker) {
		return {
			...marker,
			digits: Math.min(marker.digits + 1, 999999999)
		};
	},
	reset(marker) {
		return {
			...marker,
			digits: 1
		};
	}
};
var TasklistPrefix = {
	checked: {
		prefix: "[",
		value: "x",
		suffix: "] "
	},
	unchecked: {
		prefix: "[",
		value: " ",
		suffix: "] "
	},
	parse(raw) {
		return raw.match(/^(?<prefix>\[)(?<value>[ xX])(?<suffix>\]\s*)$/)?.groups;
	},
	serialize(marker) {
		return `${marker.prefix}${marker.value}${marker.suffix}`;
	}
};
/** Parse task list prefix syntax (e.g. `[x] `). */
function parseTasklistPrefix(raw) {
	return TasklistPrefix.parse(raw);
}
/** Get the next list item marker string from this item. For unordered items, returns the same marker. */
function buildNextMarkerSyntax(marker) {
	const ordered = OrderedListMarker.parse(marker);
	return ordered ? OrderedListMarker.serialize(OrderedListMarker.increment(ordered)) : marker;
}
/** Get the marker string for the first item matching this list. */
function buildResetMarkerSyntax(marker) {
	const ordered = OrderedListMarker.parse(marker);
	return ordered ? OrderedListMarker.serialize(OrderedListMarker.reset(ordered)) : marker;
}
/** Get the marker string for the first item in a new list. */
function buildFirstMarkerSyntax(ordered) {
	return ordered ? OrderedListMarker.serialize(OrderedListMarker.first) : defaultUnorderedListMarker;
}
/** Create tasklist prefix syntax. */
function buildTasklistPrefixSyntax(checked) {
	return TasklistPrefix.serialize(checked ? TasklistPrefix.checked : TasklistPrefix.unchecked);
}
/** Build toggled task list checkbox syntax, ensuring spacing is preserved. */
function buildToggledTasklistPrefixSyntax(nextChecked, currentPrefix, charAfter = "") {
	const match = parseTasklistPrefix(currentPrefix);
	const suffix = match ? match.suffix.slice(1) : "";
	const ensuredSuffix = suffix.length === 0 && (charAfter.length === 0 || !/\s/.test(charAfter)) ? " " : suffix;
	return `[${nextChecked ? "x" : " "}]${ensuredSuffix}`;
}
function isTasklistPrefix(prefix) {
	return parseTasklistPrefix(prefix) !== void 0;
}
function isChecked(prefix) {
	return parseTasklistPrefix(prefix)?.value.toLowerCase() === "x";
}
/**
* Determine nesting depth by counting list-related prefixes before the final list marker.
*/
function getListNestingDepth(prefixes, listPrefixIndex) {
	if (listPrefixIndex < 0) return 0;
	const linePrefix = prefixes.find((p) => p.tokenType === "linePrefix");
	if (linePrefix) return Math.floor(linePrefix.raw.length / 2);
	return prefixes.slice(0, listPrefixIndex).filter((p) => p.tokenType === "listItemPrefix" || p.tokenType === "listItemIndent").length;
}
/**
* Find the task list checkbox delimiter in the given prefix list, if present.
*/
function findTaskCheckbox(prefixes, listPrefixIndex) {
	return prefixes.slice(listPrefixIndex).find((p) => p.tokenType === "taskListCheck");
}
/**
* Build prefix syntax for pasting list items into an existing list.
* Handles three scenarios based on relative nesting depth:
* 1. Same depth: Use context marker, preserve task checkbox state from inserted content
* 2. More or less nested: Preserve inserted structure
*/
function buildListPrefixSyntax(prefixes, insertedPrefixes) {
	const contextListPrefixIndex = prefixes.findLastIndex((prefix) => prefix.tokenType === "listItemPrefix");
	const insertedListPrefixIndex = insertedPrefixes.findLastIndex((prefix) => prefix.tokenType === "listItemPrefix");
	const contextTaskCheck = findTaskCheckbox(prefixes, contextListPrefixIndex);
	const insertedTaskCheck = findTaskCheckbox(insertedPrefixes, insertedListPrefixIndex);
	const contextNestingDepth = getListNestingDepth(prefixes, contextListPrefixIndex);
	if (getListNestingDepth(insertedPrefixes, insertedListPrefixIndex) === contextNestingDepth) {
		const listBase = buildContinuationSyntax(prefixes.slice(0, contextListPrefixIndex)) + prefixes[contextListPrefixIndex]?.raw;
		if (!contextTaskCheck) return listBase;
		return listBase + (insertedTaskCheck?.raw ?? buildTasklistPrefixSyntax(false));
	}
	return insertedPrefixes.map((p) => p.raw).join("");
}
/**
* Handles pasting list items into an existing list context.
* Adjusts list markers and indentation to match the destination.
*
* @param contextStart - Document offset where the paste begins
* @param contextPrefixes - Delimiters from the destination list item
* @param insertedMarkdownLine - Parsed line from the pasted content
* @returns Change specifications, or empty array if no changes needed
*/
function handleListItemPaste(contextStart, contextPrefixes, insertedPrefixes) {
	const hasListMarker = insertedPrefixes.findLast((prefix) => prefix.tokenType === "listItemPrefix");
	const startPrefixOffset = insertedPrefixes[0]?.position?.start.offset;
	const endPrefixOffset = insertedPrefixes.at(-1)?.position?.end.offset;
	if (!hasListMarker || startPrefixOffset === void 0 || endPrefixOffset === void 0) return [];
	const newSyntax = buildListPrefixSyntax(contextPrefixes, insertedPrefixes);
	if (!newSyntax) return [];
	return [{
		from: contextStart + startPrefixOffset,
		to: contextStart + endPrefixOffset,
		insert: newSyntax
	}];
}
/** Search for the list item marker and tasklist prefix in this item. */
function findItemPrefixes(item) {
	const result = {};
	visit(item, (node) => {
		if (result.listItemPrefix) {
			if (node.type === "delimiter" && node.tokenType === "taskListCheck") result.taskListPrefix = node;
			return EXIT;
		}
		if (node.type === "delimiter" && node.tokenType === "listItemPrefix") result.listItemPrefix = node;
		if (node.type === "list") return SKIP;
	});
	return result;
}
/**
* Utility class that provides an abstraction around a line of Markdown source code, augmented with data from the tree.
* Useful for finding the boundaries of lines and managing their 'prefixes' (Markdown syntax that repeats at the start
* lines to form a block).
*/
var MarkdownLine = class MarkdownLine {
	start;
	end;
	#tree;
	#source;
	constructor(tree, source, start, end) {
		this.#tree = tree;
		this.#source = source;
		this.start = start;
		this.end = end;
	}
	/** Get the array of all prefix delimiter nodes at the beginning of this line. */
	get prefixes() {
		return this.#_prefixes ??= getNodesInsideRange(this.#tree, this.start, this.end).filter((node) => node.type === "delimiter" && prefixTokenTypes.has(node.tokenType));
	}
	#_prefixes = null;
	/** Get the last prefix before the content. */
	get lastPrefix() {
		return this.prefixes.at(-1);
	}
	/** Document relative offset of the start of the content of this line (excluding prefixes). */
	get contentStart() {
		return this.lastPrefix?.position?.end.offset ?? this.start;
	}
	/** Get the text of the line, excluding prefixes. */
	get content() {
		return this.#source.slice(this.contentStart, this.end);
	}
	get isBlank() {
		return isTasklistPrefix(this.content) || this.content.trim().length === 0;
	}
	/** Get the previous line. */
	previous() {
		return this.start === 0 ? null : MarkdownLine.atOffset(this.#tree, this.#source, this.start - 1);
	}
	/** Get the next line. */
	next() {
		return this.end >= this.#source.length ? null : MarkdownLine.atOffset(this.#tree, this.#source, this.end + 1);
	}
	/** Check if the line overlaps the given range. */
	overlaps(from, to) {
		return from >= this.start && from < this.end || to > this.start && to <= this.end || from <= this.start && to >= this.end;
	}
	/** Check if the given offset is within this line. */
	contains(offset) {
		return offset >= this.start && offset < this.end;
	}
	/**
	* Get the prefixes before the given position, ignoring trailing whitespace in prefixes.
	* @param offset A **document-relative** offset inside the line.
	*/
	prefixesBefore(offset) {
		return this.prefixes.filter((node) => isPositionedNode(node) && trimmedDelimiterPosition(node).endOffset <= offset);
	}
	/**
	* Check if the offset is after all prefixes on the line, ignoring trailing whitespace in the last prefix.
	* For example, `> |hello`, `>| hello`, and `>  hello|` would all return true for an offset at `|`.
	* @param offset A **document-relative** offset.
	*/
	isOffsetAfterPrefixes(offset) {
		return this.lastPrefix === this.prefixesBefore(offset).at(-1);
	}
	/**
	* Construct a `MarkdownLine` for the line containing the given offset.
	* @param tree The mdast tree for the entire document.
	* @param source The Markdown source code of the entire document.
	* @param offset Document-relative index of any character which is contained in the line.
	*/
	static atOffset(tree, source, offset) {
		const range = getLineRange(source, offset);
		return range && new MarkdownLine(tree, source, range.start, range.end);
	}
	/**
	* Construct an array of all of the `MarkdownLine`s that overlap the given range.
	* @param tree The mdast tree for the entire document.
	* @param source The Markdown source code of the entire document.
	* @param from Document-relative index of the start of the range.
	* @param to Document-relative index of the end of the range.
	*/
	static linesAtRange(tree, source, from, to) {
		return getLineRanges(source, from, to).map(({ start, end }) => new MarkdownLine(tree, source, start, end));
	}
};
var delimiterProperty = "dataDelimiter";
function getDelimiterChildren(node) {
	const result = [];
	for (const child of node.children ?? []) if (child.type === "delimiter") result.push(child);
	return result;
}
var delimiterTags = {
	tableDelimiter: "td",
	tableDelimiterRow: "tr"
};
function createDelimiterElement(delimiter) {
	const properties = { [delimiterProperty]: delimiter.tokenType };
	const children = delimiter.children?.length ? delimiter.children.map(createDelimiterElement) : delimiter.raw;
	const node = h(delimiterTags[delimiter.tokenType] ?? "span", properties, children);
	if (isPositionedNode(delimiter)) node.position = {
		start: { ...delimiter.position.start },
		end: { ...delimiter.position.end }
	};
	return node;
}
/**
* Nodes that aren't normally expected to have children won't get their children processed by hast, even if we have a
* handler for them. So we have to implement a custom handler that preserves the delimiter children ourselves.
*/
var handleDelimiterParentNode = (state, node) => {
	const result = toHast(node);
	if (result.type === "element") {
		const delimiterChildren = getDelimiterChildren(node).map(createDelimiterElement);
		if (result.children?.length) result.children = [...result.children, ...delimiterChildren].sort(compareNodePositions);
		else result.children = delimiterChildren;
	} else if (node.type === "text") return [result, ...getDelimiterChildren(node).map(createDelimiterElement)];
	return result;
};
var delimiterParentTypes = setOfAll()("break", "blankLine", "code", "definition", "footnoteReference", "image", "imageReference", "inlineCode", "text", "thematicBreak", "yaml");
var delimiterParentHandlers = Object.fromEntries(Array.from(delimiterParentTypes).map((t) => [t, handleDelimiterParentNode]));
var handleDelimiter = (state, delimiter) => {
	return createDelimiterElement(delimiter);
};
function getDelimiterType(element) {
	const prop = element.properties?.[delimiterProperty];
	return typeof prop === "string" ? prop : null;
}
/** Adds support for passing delimiter nodes through from the mdast tree. */
var hastDelimiters = { handlers: {
	...delimiterParentHandlers,
	delimiter: handleDelimiter
} };
var delimitersSanitizeSchema = { attributes: { ["*"]: [delimiterProperty] } };
function isTag(node, tagName) {
	return node.type === "element" && node.tagName === tagName;
}
/**
* Convert hast element `properties` object to an object keyed by the HTML attribute name (eg, `class` rather than
* `className`).
*/
function hastPropertiesToHtmlAttributes(properties) {
	if (!properties) return {};
	const result = {};
	for (const property of Object.getOwnPropertyNames(properties)) {
		const info = find(html, property);
		const value = properties[property]?.toString();
		if (typeof value === "string") result[info.attribute] = value;
	}
	return result;
}
/** Extract the concatenated non-delimiter text nodes from an element */
function getTextContent(node) {
	return node.children.map((child) => child.type === "text" ? child.value : child.type === "element" && !Object.hasOwn(child.properties ?? {}, "dataDelimiter") ? getTextContent(child) : "").join("");
}
function nodesEqual(a, b, options) {
	if (a === b) return true;
	if (a.type !== b.type) return false;
	const replacer = options?.ignorePosition ? (key, value) => key === "position" ? {} : value : void 0;
	return JSON.stringify(a, replacer) === JSON.stringify(b, replacer);
}
/** Updates code/pre nodes to add attributes to disable spellcheck and other browser autocomplete features. */
function disableSpellcheckInCodeElements(tree) {
	visit(tree, "element", (element) => {
		if (isTag(element, "code") || isTag(element, "pre")) {
			element.properties = {
				...element.properties,
				spellcheck: "false",
				autocorrect: "off",
				autocapitalize: "off",
				writingsuggestions: "false"
			};
			return SKIP$1;
		}
	});
}
var keyProp = "dataKey";
function areSameElements(a, b) {
	if (a.tagName !== b.tagName) return false;
	if (!a.properties && !b.properties) return true;
	if (!a.properties || !b.properties) return false;
	const aKeys = Object.keys(a.properties).filter((k) => k !== keyProp);
	if (aKeys.length !== Object.keys(b.properties).filter((k) => k !== keyProp).length) return false;
	for (const name of aKeys) if (a.properties[name] !== b.properties[name]) return false;
	return true;
}
/**
* Add a unique key to otherwise-identical adjacent element nodes so that CodeMirror won't combine their decorations.
* It does this to optimize the DOM tree, but our nodes are semantic and combining them can break the structure (ie,
* by merging two list items).
*/
function hastDistinguishAdjacentElements(tree) {
	visit(tree, "element", (parent) => {
		let previous = null;
		for (const node of parent.children) if (node.type === "element") {
			if (previous && areSameElements(node, previous)) {
				const prevKey = typeof previous.properties?.[keyProp] === "number" ? previous.properties[keyProp] : -1;
				node.properties[keyProp] = prevKey + 1;
			}
			previous = node;
		}
	});
}
var distinguishAdjacentElementsSanitizeSchema = { attributes: { ["*"]: [keyProp] } };
/**
* When hast-util-raw reparses the raw nodes in a document, it automatically closes any unclosed nodes. But it does
* that autoclosing at the last non-whitespace character, trimming whitespace as it would be trimmed in a rendered
* document. This doesn't work for contenteditable because it causes the elements to shrink and extend as the user
* types new content in new blank lines. So this extension expands all the trailing elements in the doc to reach the
* end of the document.
*/
function hastExpandElementsToEnd(tree, markdownSource) {
	const lines = markdownSource.split("\n");
	const lastPosition = {
		column: (lines.at(-1)?.length ?? 0) + 1,
		line: lines.length + 1,
		offset: markdownSource.length
	};
	let lastDepth = -1;
	visitParents(tree, (node, ancestors) => {
		if (ancestors.length <= lastDepth) return EXIT$1;
		lastDepth = ancestors.length;
		if (node.type !== "element" || !isPositionedNode(node) || node.position.end.offset >= lastPosition.offset) return;
		node.position.end = { ...lastPosition };
	}, true);
}
/**
* Calculate and set the `position` data of all children based on their `text` contents.
* NOTE: Assumes that the text content of the element is exactly the same as the text content of the corresponding
* range in the source document. This is always true for code blocks.
* @param start The starting point of the first child in the array.
* @param children Array of nodes to assign positions to. Will recursively assign positions to these nodes' children
* as well.
* @returns The end point of the last child; used for recursion.
*/
function assignNodePositions(start, children) {
	for (const child of children) if (child.type === "text") start = calculateEndPoint(start, child.value);
	else if (child.type === "element") {
		const end = assignNodePositions(start, child.children);
		child.position = {
			start: { ...start },
			end: { ...end }
		};
		start = end;
	}
	return start;
}
function isFencedCode(element) {
	if (!isTag(element, "pre")) return false;
	const firstChild = element.children[0];
	if (!firstChild || firstChild?.type !== "element") return false;
	if (firstChild.properties["dataDelimiter"] !== "codeFencedFence") return false;
	return true;
}
function findCodeBlockTextNode(pre) {
	const code = pre.children.find((child) => isTag(child, "code"));
	if (!code) return null;
	if (code.children.length !== 1) return null;
	const child = code.children[0];
	return child?.type === "text" ? child : null;
}
/**
* Replaces the contents of all language-tagged `code` element nodes with syntax-highlighted spans.
*/
function highlightCode(tree, markdownSource) {
	visit(tree, "element", (element) => {
		if (!isFencedCode(element)) return;
		const text = findCodeBlockTextNode(element);
		if (text) text.value = text.value.trimEnd();
	});
	rehype({ languages: all })(tree, new VFile(markdownSource));
	visit(tree, "element", (element) => {
		if (isFencedCode(element) && isPositionedNode(element)) {
			const source = markdownSource.slice(element.position.start.offset, element.position.end.offset);
			const firstLine = `${source.slice(0, source.indexOf("\n") + 1)}`;
			const codeStartPoint = calculateEndPoint(element.position.start, firstLine);
			const codeNode = element.children.find((child) => isTag(child, "code"));
			if (codeNode) assignNodePositions(codeStartPoint, [codeNode]);
		}
	});
}
var highlightCodeSchema = { attributes: { span: [["className", /^hljs-/]] } };
/**
* Normalizes all <video> elements in the given HTML AST.
*
* In this context, <video> elements are treated as void elements and should not contain any child nodes.
* This function moves any child content (such as fallback text or elements) outside the <video> element,
* inserting them immediately after the video node in the parent's children array.
*
* Additionally, if the <video> element had children, its position is adjusted to end before the first child,
* ensuring accurate source mapping and AST structure.
*
* The function also sets default properties for video playback:
*   - controls: true (if not already set)
*   - preload: 'metadata' (if not already set)
*   - playsinline: true (if not already set)
*
* This normalization ensures that <video> elements are valid, self-contained, and have consistent playback behavior.
*
* @param tree The HTML AST root to normalize.
* @param markdownSource Optional original markdown source to detect explicit boolean attribute usage.
*/
function normalizeVideoElements(tree, markdownSource) {
	visitParents(tree, "element", (node, ancestors) => {
		if (node.tagName !== "video" || !Array.isArray(node.children)) return;
		const parent = ancestors[ancestors.length - 1];
		if (!parent || !Array.isArray(parent.children)) return;
		const parentIndex = parent.children.indexOf(node);
		if (parentIndex === -1) return;
		const parentIsParagraph = parent.type === "element" && parent.tagName === "p";
		const grandparent = parentIsParagraph ? ancestors[ancestors.length - 2] : void 0;
		const container = grandparent && Array.isArray(grandparent.children) ? grandparent : parent;
		if (!Array.isArray(container.children)) return;
		const containerIndex = container === parent ? parentIndex : container.children.indexOf(parent);
		if (containerIndex === -1) return;
		const element = node;
		const properties = element.properties ??= {};
		let playsInlineSnippet;
		if (markdownSource && element.position && typeof element.position.start?.offset === "number" && typeof element.position.end?.offset === "number") playsInlineSnippet = markdownSource.slice(element.position.start.offset, element.position.end.offset);
		const controlsValue = properties.controls;
		if (controlsValue === void 0) properties.controls = true;
		else if (controlsValue === "false") properties.controls = false;
		else if (controlsValue === "true") properties.controls = true;
		if (properties.preload === void 0) properties.preload = "metadata";
		let playsInlineKey = "playsinline";
		let playsInlineValue = properties[playsInlineKey];
		if (playsInlineValue === void 0 && Object.prototype.hasOwnProperty.call(properties, "playsInline")) {
			playsInlineKey = "playsInline";
			playsInlineValue = properties[playsInlineKey];
		}
		const synchronizePlaysInline = (value) => {
			properties.playsinline = value;
			properties.playsInline = value;
		};
		const explicitPlaysInlineFalse = typeof playsInlineSnippet === "string" && /playsinline\s*=\s*['"]?false['"]?/i.test(playsInlineSnippet);
		const explicitPlaysInlineTrue = typeof playsInlineSnippet === "string" && /playsinline\s*=\s*['"]?true['"]?/i.test(playsInlineSnippet);
		if (playsInlineValue === void 0) if (explicitPlaysInlineFalse) synchronizePlaysInline(false);
		else if (explicitPlaysInlineTrue) synchronizePlaysInline(true);
		else synchronizePlaysInline(true);
		else if (playsInlineValue === "false" || playsInlineValue === false) synchronizePlaysInline(false);
		else if (playsInlineValue === "true" || playsInlineValue === true) synchronizePlaysInline(true);
		const childrenToAppend = [];
		for (const child of element.children) {
			if (child.type === "text" && child.value.trim() === "") continue;
			if (child.type === "element" && "properties" in child && child.properties?.dataDelimiter === "htmlTag") continue;
			childrenToAppend.push(child);
		}
		element.children = [];
		if (childrenToAppend.length > 0) {
			const earliestCandidate = childrenToAppend.filter((child) => isPositionedNode(child)).map((child) => ({
				child,
				start: child.position.start
			})).reduce((earliest, candidate) => {
				if (!earliest) return candidate;
				return candidate.start.offset < earliest.start.offset ? candidate : earliest;
			}, void 0);
			if (element.position && earliestCandidate) element.position = {
				...element.position,
				end: { ...earliestCandidate.start }
			};
			container.children.splice(containerIndex + 1, 0, ...childrenToAppend);
		}
		if (parentIsParagraph && grandparent && Array.isArray(grandparent.children)) grandparent.children.splice(containerIndex, 1, element);
	});
}
/** The presence of this prop indicates that a link *might* be an embedded video. */
var videoCandidateProp = "dataVideoCandidate";
function identifyVideoLinks(tree) {
	visit(tree, "element", (node, index, parent) => {
		if (!parent || typeof index !== "number") return;
		if (!isTag(node, "p")) return;
		const meaningfulChildren = node.children.filter((c) => c.type === "element" || c.type === "text" && c.value.trim() !== "");
		if (meaningfulChildren.length !== 1) return;
		const child = meaningfulChildren[0];
		if (child?.type !== "element" || !isTag(child, "a")) return;
		child.properties[videoCandidateProp] = true;
	});
}
/**
* Reimplements the Rails-side HTML pipeline sanitizer as a `hast-util-sanitize` schema.
*
* @see https://github.com/github/github/blob/master/lib/github/html.rb#L191
*/
var schema = mergeWith({}, defaultSchema, {
	allowComments: true,
	ancestors: {
		li: ["ol", "ul"],
		dd: ["dl"],
		dt: ["dl"],
		summary: ["details"],
		source: [
			"audio",
			"video",
			"picture"
		],
		figcaption: ["figure"]
	},
	tagNames: [
		"video",
		"picture",
		"source",
		"figure",
		"figcaption"
	],
	attributes: {
		video: [
			"controls",
			"src",
			"preload",
			"playsinline",
			"aria-label"
		],
		source: [
			"src",
			"srcset",
			"type",
			"media",
			"sizes",
			"height",
			"width"
		]
	}
}, distinguishAdjacentElementsSanitizeSchema, delimitersSanitizeSchema, highlightCodeSchema, { attributes: { ["*"]: [videoCandidateProp] } }, (objValue, srcValue) => Array.isArray(objValue) && Array.isArray(srcValue) ? objValue.concat(srcValue) : void 0);
if (schema.tagNames) schema.tagNames = schema.tagNames.filter((tag) => tag !== "input");
/**
* Sanitize an untrusted hast tree according to the GitHub HTML pipeline rules, while preserving custom `delimiter`
* nodes.
*/
function sanitizeHtml(tree) {
	return sanitize(tree, schema);
}
/** Check if the Markdown tree has any raw `html` nodes. */
function hasHtmlNodes(tree) {
	let hasHtml = false;
	visit(tree, "html", () => {
		hasHtml = true;
		return EXIT;
	});
	return hasHtml;
}
/**
* Convert the Markdown (mdast) AST to an HTML (hast) AST, passing `delimiter` nodes through unchanged.
*/
function buildHtmlTree(markdownTree, markdownSource, parseRaw = true) {
	const fromMarkdown = toHast(markdownTree, {
		...hastDelimiters,
		allowDangerousHtml: true
	});
	hastDistinguishAdjacentElements(fromMarkdown);
	highlightCode(fromMarkdown, markdownSource);
	if (!parseRaw || !hasHtmlNodes(markdownTree)) {
		identifyVideoLinks(fromMarkdown);
		disableSpellcheckInCodeElements(fromMarkdown);
		return fromMarkdown;
	}
	const dangerousReparsedHtml = raw(fromMarkdown, {
		tagfilter: true,
		passThrough: ["delimiter"],
		file: new VFile(markdownSource)
	});
	hastExpandElementsToEnd(dangerousReparsedHtml, markdownSource);
	const sanitized = sanitizeHtml(dangerousReparsedHtml);
	normalizeVideoElements(sanitized, markdownSource);
	identifyVideoLinks(sanitized);
	disableSpellcheckInCodeElements(sanitized);
	return sanitized;
}
function blankLine(position) {
	return {
		type: "blankLine",
		position: {
			start: position,
			end: position
		},
		data: { hProperties: { dataBlankLine: true } }
	};
}
function mdastBlankLines(source) {
	const transform = (tree) => {
		const childrenWithBlankLines = [];
		let lastNodeEnd = {
			column: 0,
			line: 0,
			offset: -1
		};
		function pushNode(node) {
			childrenWithBlankLines.push(node);
			lastNodeEnd = node.position.end;
		}
		for (const rootChild of tree.children) if (isPositionedNode(rootChild)) {
			while (lastNodeEnd.offset + 1 < rootChild.position.start.offset) pushNode(blankLine(calculateEndPoint(lastNodeEnd, "\n")));
			pushNode(rootChild);
		}
		while (lastNodeEnd.offset + 1 < source.length) pushNode(blankLine(calculateEndPoint(lastNodeEnd, "\n")));
		tree.children = childrenWithBlankLines;
	};
	return { transforms: [transform] };
}
/**
* Attaches syntactic delimiter data to the tree by inserting `Delimiter` nodes. Results in a tree with delimiter data
* that can be present in any node type -- even types that wouldn't normally contain `children`.
*
* @example
* This Markdown source:
* ```md
* > ----
* ```
*
* Will result in a tree like:
* ```js
* {
*   type: "root",
*   position: {...},
*   children: [
*     {
*       type: "quote",
*       position: {...},
*       children: [
*         {type: "delimiter", tokenType: "quoteMarker", raw: "> ", position: {...}},
*         {
*           type: "thematicBreak"
*           position: {...},
*           // thematic breaks would not normally allow `children`
*           children: [
*             {type: "delimiter", tokenType: "thematicBreakSequence", raw: "----", position: {...}}
*           ]
*         },
*       ]
*     }
*   ]
* }
* ```
*/
function mdastDelimiters() {
	return {
		enter: {
			...Object.fromEntries(delimiterTokenTypes.map((type) => [type, handleDelimiterEnter])),
			linePrefix: handleLinePrefixEnter
		},
		exit: {
			...Object.fromEntries(delimiterTokenTypes.map((type) => [type, handleDelimiterExit])),
			linePrefix: handleLinePrefixExit
		}
	};
}
/** All Micromark token types that are always treated as delimiters. */
var delimiterTokenTypes = [
	"blockQuotePrefix",
	"strongSequence",
	"emphasisSequence",
	"codeTextSequence",
	"codeTextPadding",
	"strikethroughSequence",
	"thematicBreakSequence",
	"codeFencedFence",
	"atxHeadingSequence",
	"whitespace",
	"setextHeadingLine",
	"labelMarker",
	"labelImageMarker",
	"resource",
	"resourceDestination",
	"linePrefix",
	"listItemIndent",
	"listItemPrefix",
	"taskListCheck",
	"tableCellDivider",
	"tableDelimiterRow",
	"tableDelimiter",
	"autolinkMarker",
	"hardBreakEscape",
	"escapeMarker",
	"characterReference"
];
/** Returns the lowest open node on the stack - the one that we should push children to. */
function getParent(context) {
	if (context.data.delimiterStack?.length) return context.data.delimiterStack.at(-1);
	const parent = context.stack.at(-1);
	if (parent?.type === "fragment") {
		const grandparent = context.stack.at(-2);
		if (grandparent && "value" in grandparent) return grandparent;
	}
	return parent;
}
/** Create a delimiter node and push it to the currently open node. */
var handleDelimiterEnter = function(token) {
	const delimiter = {
		type: "delimiter",
		tokenType: token.type,
		raw: this.sliceSerialize(token),
		position: {
			start: token.start,
			end: token.end
		}
	};
	const parent = getParent(this);
	if (parent) {
		parent.children ??= [];
		parent.children.push(delimiter);
		this.data.delimiterStack ??= [];
		this.data.delimiterStack.push(delimiter);
	}
	return false;
};
/** Remove the delimiter from the stack to close it out. */
var handleDelimiterExit = function(token) {
	if ((this.data.delimiterStack?.pop())?.tokenType !== token.type) throw new Error(`Expected open '${token.type}' delimiter on stack`);
	this.data.lastExitedDelimiterToken = token;
	return false;
};
/**
* Lists have an annoying quirk where an empty list item with a space following the marker will be parsed as
* a `linePrefix` following a `listItemPrefix`, even though that space would usually be considered part of the
* `listItemPrefix` if there was any content in the item. This is a pain to work with because we always have treat it
* as an edge case.
*
* So rather than working around this everywhere in the code, we just drop the `linePrefix` in this case and extend the
* `listItemPrefix` to cover the space.
*/
var handleLinePrefixEnter = function(token) {
	const lastChild = getParent(this)?.children?.at(-1);
	if (token.end.offset - token.start.offset === 1 && lastChild?.type === "delimiter" && lastChild.tokenType === "listItemPrefix" && isPositionedNode(lastChild) && token.start.offset === lastChild.position.end.offset) {
		lastChild.position.end = { ...token.end };
		lastChild.raw += this.sliceSerialize(token);
	} else handleDelimiterEnter.call(this, token);
	return false;
};
/** Only exit `linePrefix` delimiters that were actually entered. */
var handleLinePrefixExit = function(token) {
	const parent = getParent(this);
	if (parent?.type === "delimiter" && parent.tokenType === "linePrefix") handleDelimiterExit.call(this, token);
	return false;
};
function isWhitespaceDelimiter(node) {
	return node && node.type === "delimiter" && node.tokenType === "whitespace";
}
var handleExitHeading = function(token) {
	const openHeading = this.stack.at(-1);
	if (openHeading?.type === "heading" && !isWhitespaceDelimiter(openHeading.children[1])) {
		this.exit(token);
		const parent = this.stack.at(-1);
		parent.children.pop();
		parent.children.push({
			type: "paragraph",
			position: openHeading.position,
			children: []
		});
		return;
	}
	return false;
};
/**
* mdast extension that prevents creating `heading` nodes for headings with no content. With this extension enabled,
* ATX headings *must* have a space immediately after the opening sequence to be parsed.
*/
function mdastSkipEmptyHeadings() {
	return { exit: { atxHeading: handleExitHeading } };
}
/**
* Tokenize a partial HTML string. Does not care about matching tags or valid nesting, just breaks the string into
* a flat array of tokens.
*/
function tokenizeHtml(html) {
	const tokens = [];
	let lastToken = null;
	function handleToken(type, loc) {
		if (!loc) return;
		const end = {
			column: loc.endCol,
			line: loc.endLine,
			offset: loc.endOffset
		};
		if (type === "text" && lastToken?.type === "text") {
			lastToken.position.end = end;
			return;
		}
		const token = {
			type,
			position: {
				start: {
					column: loc.startCol,
					line: loc.startLine,
					offset: loc.startOffset
				},
				end
			}
		};
		tokens.push(token);
		lastToken = token;
	}
	new Tokenizer({ sourceCodeLocationInfo: true }, {
		onCharacter: ({ location }) => handleToken("text", location),
		onWhitespaceCharacter: ({ location }) => handleToken("text", location),
		onNullCharacter: ({ location }) => handleToken("text", location),
		onStartTag: ({ location }) => handleToken("startTag", location),
		onEndTag: ({ location }) => handleToken("endTag", location),
		onDoctype: ({ location }) => handleToken("doctype", location),
		onComment: ({ location }) => handleToken("comment", location),
		onEof: noop,
		onParseError: noop
	}).write(html, true);
	return tokens;
}
/** Split a single node, returning an array of new nodes. */
function splitHtmlNodeByTokens(node) {
	if (!isPositionedNode(node)) return [];
	return tokenizeHtml(node.value).flatMap((token) => {
		const value = node.value.slice(token.position.start.offset, token.position.end.offset);
		const position = {
			start: addPoints(node.position.start, token.position.start),
			end: addPoints(node.position.start, token.position.end)
		};
		switch (token.type) {
			case "text": return [{
				type: "text",
				value,
				position
			}];
			case "endTag": return [{
				type: "delimiter",
				tokenType: "htmlTag",
				raw: value,
				position
			}, {
				type: "html",
				value,
				position
			}];
			case "startTag": return [{
				type: "html",
				value,
				position
			}, {
				type: "delimiter",
				tokenType: "htmlTag",
				raw: value,
				position
			}];
			case "comment":
			case "doctype": return [{
				type: "html",
				value,
				position
			}];
		}
	});
}
/** Split all the HTML nodes in the tree, replacing them with their split nodes. Mutates the tree. */
function splitHtmlNodes(tree) {
	visitParents(tree, "html", (node, ancestors) => {
		const parent = ancestors.at(-1);
		const index = parent.children.indexOf(node);
		parent.children.splice(index, 1, ...splitHtmlNodeByTokens(node));
	}, true);
}
/**
* By default, mdast will output one `html` node for each 'chunk' of HTML. For example, the text
* `<h1><span>Hello world</span>` would be represented as a single `html` node:
*
* ```
* root[1] (1:1-1:29, 0-28)
* └─0 html "<h1><span>Hello world</span>" (1:1-1:29, 0-28)
* ```
*
* This extension splits all `html` nodes apart by tag, injects delimiter nodes for the tags, and replaces any
* remaining text with `text` nodes. So the above example would become seven separate nodes:
*
* ```
* root[7] (1:1-1:29, 0-28)
* ├─0 html "<h1>" (1:1-1:5, 0-4)
* ├─1 delimiter (1:1-1:5, 0-4)
* │     tokenType: "startTag"
* │     raw: "<h1>"
* ├─2 html "<span>" (1:5-1:11, 4-10)
* ├─3 delimiter (1:5-1:11, 4-10)
* │     tokenType: "startTag"
* │     raw: "<span>"
* ├─4 text "Hello world" (1:11-1:22, 10-21)
* ├─5 delimiter (1:22-1:29, 21-28)
* │     tokenType: "endTag"
* │     raw: "</span>"
* └─6 html "</span>" (1:22-1:29, 21-28)
* ```
*/
function mdastSplitHtml() {
	return { transforms: [splitHtmlNodes] };
}
var defaultOptions = { enabledExtensions: {
	delimiters: true,
	containDelimiters: true,
	splitHtml: true,
	skipEmptyHeadings: true,
	blankLines: true
} };
function parseMarkdown(markdown, { enabledExtensions = defaultOptions.enabledExtensions } = defaultOptions) {
	return fromMarkdown(markdown, "utf-8", {
		extensions: [gfm()],
		mdastExtensions: [
			gfmFromMarkdown(),
			enabledExtensions.delimiters ? mdastDelimiters() : [],
			enabledExtensions.containDelimiters ? mdastContainDelimiters() : [],
			enabledExtensions.splitHtml ? mdastSplitHtml() : [],
			enabledExtensions.skipEmptyHeadings ? mdastSkipEmptyHeadings() : [],
			enabledExtensions.blankLines ? mdastBlankLines(markdown) : []
		]
	});
}
function parseDocument(state) {
	const markdownSource = state.doc.toString();
	const markdownTree = parseMarkdown(markdownSource);
	return {
		markdownTree,
		htmlTree: buildHtmlTree(markdownTree, markdownSource)
	};
}
/** Dispatched with the new tree when the parsed Markdown tree is updated. */
var markdownParsedEffect = StateEffect.define();
/**
* Markdown parsing is relatively expensive and state updates are blocking to user interactions, so to keep the editor
* responsive we watch for document changes and dispatch a parse asynchronously.
*
* We can't just do this inside the `markdownDecorationsState` plugin because `StateField`s don't have access to the
* view -- they can't dispatch a new transaction.
*/
var asyncParseMarkdownPlugin = ViewPlugin.define((view) => {
	let timeout = null;
	return { update: (event) => {
		if (event.docChanged) {
			if (timeout) clearTimeout(timeout);
			timeout = setTimeout(() => view.dispatch({ effects: markdownParsedEffect.of(parseDocument(view.state)) }));
		}
	} };
});
/**
* State field for accessing the parsed Markdown tree. Nodes are referenced by identity, so this tree is non-mutable
* once stored in editor state.
*/
var parsedMarkdownField = StateField.define({
	create: parseDocument,
	update: (prev, tr) => tr.effects.find((e) => e.is(markdownParsedEffect))?.value ?? prev,
	provide: () => [asyncParseMarkdownPlugin]
});
/**
* Provides an asynchronous Markdown parser that updates as the document changes.
* Call `getMarkdownTree` or `getHtmlTree` to obtain the parsed tree from the editor state.
*/
var markdownParserExtension = parsedMarkdownField;
/** Get the Markdown (mdast) tree from the editor state. Throws an error if `markdownParserExtension` is not installed. */
function getMarkdownTree(state) {
	return state.field(parsedMarkdownField).markdownTree;
}
/** Get the HTML (hast) tree from the editor state. Throws an error if `markdownParserExtension` is not installed. */
function getHtmlTree(state) {
	return state.field(parsedMarkdownField).htmlTree;
}
/**
* Check if the parsed Markdown (mdast) tree changed in this transaction. Note that because the parser is async, this
* will not happen in the same transaction where the document changed. Therefore, any decorations that depend on the
* Markdown tree should be _mapped_ through transactions where the doc changes but not the tree.
*/
function markdownTreeChanged(transaction) {
	return transaction.effects.some((eff) => eff.is(markdownParsedEffect));
}
/**
* Check if the parsed HTML (hast) tree changed in this transaction. Note that because the parser is async, this
* will not happen in the same transaction where the document changed.
*
* For now, the HTML and Markdown trees always change together, but this may not be the case in the future.
*/
var htmlTreeChanged = markdownTreeChanged;
var initialSelectionContext = [];
/**
* Determines the Markdown context of the current selection.
* For example, if the selection is within bold text, the context will include a `strong` node.
*/
function getSelectionContext(state) {
	const tree = getMarkdownTree(state);
	const selection = state.selection.main;
	return getNodesContainingRange(tree, selection.from, selection.to, true);
}
/**
* State field for accessing the current selection context. The context is updated synchronously
* when the selection changes.
*/
var selectionContextField = StateField.define({
	create: getSelectionContext,
	update: (prev, tr) => {
		if (!tr.startState.selection.eq(tr.newSelection) || markdownTreeChanged(tr)) return getSelectionContext(tr.state);
		return prev;
	},
	provide: () => [markdownParserExtension]
});
/**
* Extension to track selection context that updates as the selection changes.
*/
var selectionContextExtension = selectionContextField;
/** Get the selection context from the editor state. Throws an error if `selectionContextExtension` is not installed. */
function getCurrentSelectionContext(state) {
	return state.field(selectionContextField);
}
/**
* Check if the selection context changed in this transaction.
*/
function selectionContextChanged(transaction) {
	if (!transaction.startState.selection.eq(transaction.newSelection)) return true;
	if (markdownTreeChanged(transaction)) return true;
	const oldContext = transaction.startState.field(selectionContextField);
	const newContext = transaction.state.field(selectionContextField);
	if (oldContext.length !== newContext.length) return true;
	for (let index = 0; index < oldContext.length; index++) if (oldContext[index] !== newContext[index]) return true;
	return false;
}
/** Returns true if there is actual selected text in the editor. */
function hasNonEmptySelection(state) {
	return state.selection.ranges.length === 1 && !state.selection.main.empty;
}
function expandRangeToLineEnds(state) {
	const caretLocation = state.selection.main.anchor;
	const document = state.doc.toString();
	const lineFrom = document.slice(0, caretLocation).lastIndexOf("\n") + 1;
	let lineTo = document.indexOf("\n", caretLocation);
	if (lineTo === -1) lineTo = document.length;
	return {
		from: lineFrom,
		to: lineTo
	};
}
/**
* Find word boundaries around a given position
*
* Treats markdown delimiters and common punctuation as word boundaries, similar to how
* text formatting works. Apostrophes are only treated as boundaries at the start/end of
* words, not in the middle, allowing proper selection of contractions and possessives.
* Hyphens are always treated as word boundaries.
*/
function findWordBoundaries(text, position) {
	let start = position;
	let end = position;
	const isBoundary = (char) => /[^\w\d']/.test(char);
	while (start > 0 && text[start - 1]) {
		const char = text[start - 1];
		if (char === "'") {
			const prevChar = text[start - 2];
			if (!prevChar || isBoundary(prevChar) || /\s/.test(prevChar)) break;
		}
		if (isBoundary(char)) break;
		start--;
	}
	while (end < text.length && text[end]) {
		const char = text[end];
		if (char === "'") {
			const nextChar = text[end + 1];
			if (!nextChar || isBoundary(nextChar) || /\s/.test(nextChar)) break;
		}
		if (isBoundary(char)) break;
		end++;
	}
	return {
		start,
		end
	};
}
function getCaretPosition(state) {
	return state.selection.ranges.length === 1 && state.selection.main.empty ? state.selection.main.anchor : null;
}
/**
* Get accurate coordinates for a caret position, handling decorated blocks correctly.
* Falls back to CodeMirror's `coordsAtPos` if DOM range approach fails.
*/
var getAccurateCaretCoords = (view, pos) => {
	try {
		const domPos = view.domAtPos(pos);
		if (domPos?.node) try {
			const range = document.createRange();
			range.setStart(domPos.node, domPos.offset);
			range.setEnd(domPos.node, domPos.offset);
			const rect = range.getBoundingClientRect();
			if (rect.left !== 0 || rect.right !== 0 || rect.top !== 0 || rect.bottom !== 0) return {
				left: rect.left,
				top: rect.top,
				right: rect.right,
				bottom: rect.bottom
			};
		} catch {}
		return view.coordsAtPos(pos) ?? null;
	} catch {
		return null;
	}
};
var NODE_TYPE_TO_INLINE_DELIMITER_MAP = {
	strong: "**",
	emphasis: "_",
	inlineCode: "`",
	delete: "~"
};
var WRAP_DELIMITER_MAP = {
	"*": "*",
	_: "_",
	$: "$",
	"~": "~",
	"[": "]",
	"(": ")",
	"`": "`"
};
/**
* Checks if the current selection has existing formatting of the specified type
*/
var getExistingFormatting = (view, type) => {
	return getCurrentSelectionContext(view.state).findLast((node) => node.type === type);
};
/**
* Collect all delimiter children in a node
*/
var getDelimiters = (node) => {
	if (!node.children) return [];
	return node.children.filter((child) => child.type === "delimiter");
};
/**
* Removes formatting delimiters around the current selection or cursor position.
*/
var removeFormattingAtSelection = (view, node) => {
	const delimiters = getDelimiters(node).filter(isPositionedNode);
	if (delimiters.length === 0) return;
	const changes = delimiters.map((delimiter) => ({
		from: delimiter.position.start.offset,
		to: delimiter.position.end.offset
	}));
	view.dispatch({
		changes,
		userEvent: "input",
		scrollIntoView: true
	});
};
var wrapSelectionWithDelimiter = (view, prefix, suffix) => {
	view.dispatch(view.state.changeByRange((range) => ({
		changes: [{
			from: range.from,
			insert: prefix
		}, {
			from: range.to,
			insert: suffix
		}],
		range: EditorSelection.range(range.from + prefix.length, range.to + prefix.length)
	})), {
		userEvent: "input",
		scrollIntoView: true
	});
};
/**
* Finds the relevant word node from the selection context
*/
var findWordNodeInContext = (selectionContext) => selectionContext.find((node) => node.type === "text");
var insertDelimiterAtSelection = (view, prefix, suffix, wordNode) => {
	const caretLocation = view.state.selection.main.anchor;
	const hasWordNode = wordNode?.value && isPositionedNode(wordNode);
	const { text, offset } = hasWordNode ? {
		text: wordNode.value,
		offset: caretLocation - wordNode.position.start.offset
	} : {
		text: view.state.doc.toString(),
		offset: caretLocation
	};
	const wordNodeStart = hasWordNode ? wordNode.position.start.offset : 0;
	const { start: wordStart, end: wordEnd } = findWordBoundaries(text, offset);
	view.dispatch({
		changes: [{
			from: wordStart + wordNodeStart,
			insert: prefix
		}, {
			from: wordEnd + wordNodeStart,
			insert: suffix
		}],
		selection: { anchor: caretLocation + prefix.length },
		userEvent: "input",
		scrollIntoView: true
	});
};
/**
* Generic formatter function that handles inline formatting types
*
* This function either removes existing formatting of the specified type
* or applies new formatting to the current selection/cursor position.
*/
var inlineFormatter = (view, type) => {
	if (!view.hasFocus) view.focus();
	const existingFormattedNode = getExistingFormatting(view, type);
	if (existingFormattedNode) {
		removeFormattingAtSelection(view, existingFormattedNode);
		return true;
	}
	const delimiter = NODE_TYPE_TO_INLINE_DELIMITER_MAP[type];
	if (hasNonEmptySelection(view.state)) wrapSelectionWithDelimiter(view, delimiter, delimiter);
	else insertDelimiterAtSelection(view, delimiter, delimiter, findWordNodeInContext(getCurrentSelectionContext(view.state)));
	return true;
};
var CODE_BLOCK_PREFIX = "```\n";
var CODE_BLOCK_SUFFIX = "\n```";
var formatCodeBlock = (view) => {
	if (!view.hasFocus) view.focus();
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const selection = view.state.selection.main;
	const { from, to } = selection;
	const codeNode = getExistingFormatting(view, "code");
	if (codeNode) {
		if (!isPositionedNode(codeNode)) return false;
		if (codeNode.type !== "code") return false;
		const delimiters = getDelimiters(codeNode).filter(isPositionedNode);
		if (delimiters.length === 0) return false;
		const changes = delimiters.map((delimiter, i) => {
			const isFirstDelimiter = i === 0;
			return {
				from: i === delimiters.length - 1 ? delimiter.position.start.offset - 1 : delimiter.position.start.offset,
				to: isFirstDelimiter ? delimiter.position.end.offset + 1 : delimiter.position.end.offset
			};
		});
		view.dispatch({
			changes,
			userEvent: "input",
			scrollIntoView: true
		});
		return true;
	}
	const changes = [];
	const codeBlockDelimiterPositions = [...getNodesOverlappingRange(tree, from, to)].filter((node) => node.type === "code").flatMap((codeBlockNode) => {
		const delimiters = getDelimiters(codeBlockNode).filter(isPositionedNode);
		return delimiters.map((delimiter, i) => {
			const isFirstDelimiter = i === 0;
			return {
				from: i === delimiters.length - 1 ? delimiter.position.start.offset - 1 : delimiter.position.start.offset,
				to: isFirstDelimiter ? delimiter.position.end.offset + 1 : delimiter.position.end.offset
			};
		});
	});
	const startOfFirstCodeBlock = codeBlockDelimiterPositions.at(0)?.from;
	const endOfLastCodeBlock = codeBlockDelimiterPositions.at(-1)?.to;
	changes.push(...codeBlockDelimiterPositions);
	const lines = MarkdownLine.linesAtRange(tree, source, from, to);
	const firstLineStart = lines[0]?.isOffsetAfterPrefixes(from) ? lines[0]?.contentStart : lines[0]?.start;
	const lastLineEnd = lines.at(-1)?.end;
	const start = startOfFirstCodeBlock !== void 0 && firstLineStart !== void 0 ? Math.min(firstLineStart, startOfFirstCodeBlock) : firstLineStart;
	const end = endOfLastCodeBlock !== void 0 && lastLineEnd !== void 0 ? Math.max(lastLineEnd, endOfLastCodeBlock) : lastLineEnd;
	if (start === void 0 || end === void 0) return false;
	changes.push({
		from: start,
		insert: CODE_BLOCK_PREFIX
	}, {
		from: end,
		insert: CODE_BLOCK_SUFFIX
	});
	const isBlankLine = selection.empty && MarkdownLine.atOffset(tree, source, selection.from)?.isBlank;
	view.dispatch({
		changes,
		selection: isBlankLine ? { anchor: start + 4 } : void 0,
		userEvent: "input",
		scrollIntoView: true
	});
	return true;
};
var isLabeledLink = (node) => {
	const hasLabelMarker = node?.children?.some((n) => n.type === "delimiter" && n.tokenType === "labelMarker");
	const hasResource = node?.children?.some((n) => n.type === "delimiter" && n.tokenType === "resource");
	return hasLabelMarker && hasResource;
};
var formatLink = (view) => {
	if (!view.hasFocus) view.focus();
	const selection = view.state.selection.main;
	const linkNode = getExistingFormatting(view, "link");
	if (linkNode && isLabeledLink(linkNode)) {
		removeFormattingAtSelection(view, linkNode);
		return true;
	}
	const { start, end } = hasNonEmptySelection(view.state) ? {
		start: selection.from,
		end: selection.to
	} : findWordBoundaries(view.state.doc.toString(), selection.anchor);
	let prefix;
	let suffix;
	let cursorPosition;
	if (!!linkNode) {
		prefix = "[](";
		suffix = ")";
		cursorPosition = start + 1;
	} else {
		prefix = "[";
		suffix = "]()";
		cursorPosition = end + 3;
	}
	view.dispatch({
		changes: [{
			from: start,
			insert: prefix
		}, {
			from: end,
			insert: suffix
		}],
		selection: { anchor: cursorPosition },
		userEvent: "input",
		scrollIntoView: true
	});
	return true;
};
/**
* Create a `ChangeSpec` that would re-create the prefixes for following items in the list to ensure that they are
* valid with respect to `previousMarker`.
* @param list The parent list node that contains the items.
* @param afterIndex Index of the item after which to remark following items. Exclusive - this item won't be changed.
* @param previousMarker Marker to start building subsequent markers from. Typically, this would be the new marker for
* the item that will be at `afterIndex`. If `null`, the items will be restarted from 1.
*/
function remarkFollowingItems(list, afterIndex, previousMarker) {
	const changes = [];
	for (const followingItem of list.children.slice(afterIndex + 1)) if (followingItem.type === "listItem") {
		const prefix = findItemPrefixes(followingItem).listItemPrefix;
		if (!prefix || !isPositionedNode(prefix)) continue;
		const newMarker = previousMarker === null ? buildResetMarkerSyntax(prefix.raw) : buildNextMarkerSyntax(previousMarker);
		changes.push({
			from: prefix.position.start.offset,
			to: prefix.position.end.offset,
			insert: newMarker
		});
		previousMarker = newMarker;
	}
	return changes;
}
function positionedItems(children) {
	return children.filter((n) => n.type === "listItem" && isPositionedNode(n));
}
/**
* Get the list items that overlap the selection. If multiple items are selected, the `list` returned will be the
* _lowest common list_ across all the items, and the `selectedItems` will be limited to direct descendants of that
* list. In other words, we'll ignore sub-items of selected items.
*
* If the `list` is a nested sublist, `parents` will contain the parent list items and lists. The last item in this
* array will be the immediate parent, and the first item will be the top-level ancestor.
*/
function getListSelection(state) {
	if (state.selection.ranges.length !== 1) return null;
	const selectionFrom = state.selection.main.from;
	const selectionTo = state.selection.main.to;
	const nodesContainingSelection = getNodesContainingRange(getMarkdownTree(state), selectionFrom, selectionTo);
	const listIndex = nodesContainingSelection.findLastIndex((n) => n.type === "list");
	const list = nodesContainingSelection[listIndex];
	if (!list) return null;
	const selectedItems = positionedItems(getChildrenOverlappingRange(list, selectionFrom, selectionTo));
	if (selectedItems.length === 0) return null;
	const nodesContainingList = nodesContainingSelection.slice(0, listIndex);
	const parents = [];
	for (const node of nodesContainingList) if (node.type === "listItem") {
		const last = parents.at(-1);
		if (last) last.item = node;
	} else if (node.type === "list") parents.push({
		list: node,
		item: void 0
	});
	return {
		list,
		selectedItems,
		parents
	};
}
/**
* Gets blockquote prefixes for each line in the selection
*/
var getBlockquotePrefixesForLines = (lines) => {
	return lines.map((line) => line.prefixes.filter((prefix) => prefix.tokenType === "blockQuotePrefix"));
};
/**
* Determines if the selection contains any non-blockquoted lines
*/
var hasMixedBlockquoteContent = (blockquotePrefixes) => {
	const isEmptySelection = blockquotePrefixes.length === 0;
	const hasNonBlockquotedLines = blockquotePrefixes.some((prefixes) => prefixes.length === 0);
	return isEmptySelection || hasNonBlockquotedLines;
};
var BLOCKQUOTE_PREFIX = "> ";
/**
* Handles blockquote formatting by analyzing the selection to determine the appropriate action:
* - If no blockquotes exist: add blockquote to all lines
* - If mixed content: make all lines blockquoted
* - If all blockquotes: remove selected levels
*/
var formatBlockquote = (view) => {
	if (!view.hasFocus) view.focus();
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const selection = view.state.selection.main;
	const selectedLines = MarkdownLine.linesAtRange(tree, source, selection.from, selection.to);
	const blockquotePrefixes = getBlockquotePrefixesForLines(selectedLines);
	if (hasMixedBlockquoteContent(blockquotePrefixes)) {
		if (selectedLines.length === 1 && selectedLines[0]?.isBlank) {
			view.dispatch({
				changes: [{
					from: selection.from,
					insert: BLOCKQUOTE_PREFIX
				}],
				selection: { anchor: selection.from + 2 },
				userEvent: "input",
				scrollIntoView: true
			});
			return true;
		}
		const changes = [];
		for (const line of selectedLines) if (!line.prefixes.some((p) => p.tokenType === "blockQuotePrefix")) changes.push({
			from: line.start,
			insert: BLOCKQUOTE_PREFIX
		});
		view.dispatch({
			changes,
			userEvent: "input",
			scrollIntoView: true
		});
	} else {
		const selectedNestingLevels = [...new Set(blockquotePrefixes.map((prefixes) => prefixes.length))].sort((a, b) => a - b);
		const outermostBlockquote = getNodesOverlappingRange(tree, selection.from, selection.to).find((node) => node.type === "blockquote");
		if (!outermostBlockquote || !isPositionedNode(outermostBlockquote)) return true;
		const blockquoteStart = outermostBlockquote.position.start.offset;
		const blockquoteEnd = outermostBlockquote.position.end.offset;
		const allBlockquotePrefixes = getBlockquotePrefixesForLines(MarkdownLine.linesAtRange(tree, source, blockquoteStart, blockquoteEnd));
		const changes = [];
		for (const prefixes of allBlockquotePrefixes) {
			let removingLastPrefix = false;
			let prefixesRemoved = 0;
			for (const level of selectedNestingLevels) {
				if (prefixes.length < level) continue;
				const prefixToRemove = prefixes[level - 1];
				if (prefixToRemove && isPositionedNode(prefixToRemove)) {
					removingLastPrefix = prefixes.length === level;
					prefixesRemoved++;
					changes.push({
						from: prefixToRemove.position.start.offset,
						to: prefixToRemove.position.end.offset
					});
				}
			}
			const lastPrefix = prefixes[prefixes.length - 1];
			if (lastPrefix && removingLastPrefix && prefixesRemoved < prefixes.length && isPositionedNode(lastPrefix)) changes.push({
				from: lastPrefix.position.start.offset,
				insert: " "
			});
		}
		view.dispatch({
			changes,
			userEvent: "input",
			scrollIntoView: true
		});
	}
	return true;
};
/**
* Annotation to apply to a transaction to indicate that Markdown continuation logic should be skipped to allow the
* user to escape some Markdown syntax. Will skip up to the last instance of the matching prefix. For example, if
* the annotation is `escapeList` and the user is inside a blockquote inside a list item, both the blockquote
* and the list will be escaped.
*/
var escapeMarkdownContinuation = Annotation.define();
/**
* Automatically continues the current Markdown syntax as the user inserts new lines of content.
*/
var markdownContinuationExtension = [markdownParserExtension, EditorState.transactionFilter.of((tr) => {
	const escapeAnnotation = tr.annotation(escapeMarkdownContinuation);
	if (!tr.isUserEvent("input") || !tr.docChanged || tr.changes.empty || escapeAnnotation === "all") return tr;
	const startTree = getMarkdownTree(tr.startState);
	const source = tr.startState.doc.toString();
	/** Will be a set of insertions that can be applied after the original changes to add the continuation syntax. */
	const newChanges = [];
	tr.changes.iterChanges((fromA, toA, fromB, toB, inserted) => {
		const text = inserted.toString();
		if (!text.includes("\n")) return;
		const currentLine = MarkdownLine.atOffset(startTree, source, fromA);
		const prefixes = removeEscapedPrefixes(currentLine?.prefixesBefore(fromA) ?? [], escapeAnnotation);
		if (!currentLine || prefixes.length === 0) return;
		const continuationSyntax = buildContinuationSyntax(prefixes);
		if (continuationSyntax === "") return;
		const insertedTree = parseMarkdown(text);
		const insertedLines = getLineRanges(text, 0, text.length);
		const isInsertingIntoListItem = currentLine.lastPrefix?.tokenType === "listItemPrefix" || currentLine.lastPrefix?.tokenType === "taskListCheck";
		for (let i = 1; i < insertedLines.length; i++) {
			const line = insertedLines[i];
			if (!line) continue;
			if (isInsertingIntoListItem && (tr.isUserEvent("input.paste") || tr.isUserEvent("input.drop"))) {
				const insertedPrefixes = MarkdownLine.atOffset(insertedTree, text, line.start)?.prefixes ?? [];
				const changes = handleListItemPaste(fromB, [...currentLine.prefixes], [...insertedPrefixes]);
				if (changes.length > 0) {
					newChanges.push(...changes);
					continue;
				}
			}
			newChanges.push({
				from: fromB + line.start,
				insert: continuationSyntax
			});
		}
	});
	const newChangeSet = ChangeSet.of(newChanges, tr.newDoc.length);
	return [tr, {
		sequential: true,
		changes: newChangeSet,
		annotations: [escapeMarkdownContinuation.of("all")],
		selection: tr.newSelection.map(newChangeSet, 1)
	}];
})];
/**
* Dispatch an undoable transaction to split the current blockquote apart, if the caret is on a blank line inside
* of a blockquote of any depth. This operation only applies for a single caret with no text selected.
*/
var splitBlockquoteIfBlankLine = (view) => {
	if (view.state.selection.ranges.length !== 1 || !view.state.selection.main.empty) return false;
	const source = view.state.doc.toString();
	const caretPosition = view.state.selection.main.anchor;
	const tree = getMarkdownTree(view.state);
	const line = MarkdownLine.atOffset(tree, source, caretPosition);
	if (!line?.isBlank) return false;
	const lastPrefix = line.lastPrefix;
	if (lastPrefix?.tokenType !== "blockQuotePrefix") return false;
	if (!line.isOffsetAfterPrefixes(caretPosition)) return false;
	const changeFrom = lastPrefix.position?.start.offset ?? line.start;
	let insert = "";
	let newSelection = changeFrom;
	if (line.previous()?.isBlank === false) {
		insert += "\n";
		newSelection += 1;
	}
	if (line.next()?.isBlank === false) insert += "\n";
	view.dispatch({
		changes: [{
			from: changeFrom,
			to: line.end,
			insert
		}],
		selection: EditorSelection.single(newSelection),
		annotations: [escapeMarkdownContinuation.of("escapeBlockquote")],
		userEvent: "input.type",
		scrollIntoView: true
	});
	return true;
};
function isOpenCodeBlock(node) {
	return node.children?.filter((child) => child.type === "delimiter" && child.tokenType === "codeFencedFence").length === 1;
}
/** Checks if the given position is fully inside the code block (not outside or at the ends). */
function isInsideCodeBlock(node, position) {
	return isPositionedNode(node) && containsRange(position, position, node.position.start.offset, node.position.end.offset) && node.position.start.offset !== position && (isOpenCodeBlock(node) || node.position.end.offset !== position);
}
/**
* Extracts the fence sequence (backticks or tildes) from the raw fence content.
* Returns null if the fence doesn't match the expected pattern.
*/
function extractFenceSequence(raw) {
	return raw.match(/^(`{3,}|~{3,})/)?.[1] ?? null;
}
/**
* Auto-closes code blocks when pressing Enter at the end of an opening fence.
* Only triggers when the code block is open (no closing fence exists).
*/
var closeCodeBlock = (view) => {
	if (view.state.selection.ranges.length !== 1 || !view.state.selection.main.empty) return false;
	const source = view.state.doc.toString();
	const caretPosition = view.state.selection.main.anchor;
	const tree = getMarkdownTree(view.state);
	const node = getNodeAtOffset(tree, caretPosition);
	if (node?.type !== "code") return false;
	const codeNode = node;
	const caretLine = MarkdownLine.atOffset(tree, source, caretPosition);
	if (!caretLine) return false;
	if (caretPosition !== caretLine.end) return false;
	const openingFence = codeNode.children?.find((child) => child.type === "delimiter" && child.tokenType === "codeFencedFence");
	if (!openingFence || !isPositionedNode(openingFence) || !caretLine.contains(openingFence.position.start.offset)) return false;
	const fenceString = extractFenceSequence(openingFence.raw);
	if (!fenceString) return false;
	view.dispatch({
		changes: [{
			from: caretPosition,
			insert: `\n\n${fenceString}`
		}],
		selection: { anchor: caretPosition + 1 },
		userEvent: "input.type",
		scrollIntoView: true
	});
	return true;
};
/**
* Check if the caret location is within a code block.
*/
function isCodeBlock(view) {
	const caretLocation = view.state.selection.main.anchor;
	return getNodeAtOffset(getMarkdownTree(view.state), caretLocation)?.type === "code";
}
/**
* Dispatch an undoable transaction to indent a line within the code block.
*/
var indentLineIfCodeBlock = (view) => {
	const { from: lineFrom } = expandRangeToLineEnds(view.state);
	if (isCodeBlock(view)) {
		if (hasNonEmptySelection(view.state)) view.dispatch(view.state.changeByRange((range) => ({
			changes: [{
				from: lineFrom,
				insert: "	"
			}],
			range: EditorSelection.range(range.from + 1, range.to + 1)
		})), {
			userEvent: "input.type",
			scrollIntoView: true
		});
		else view.dispatch(view.state.replaceSelection("	"));
		return true;
	}
	return false;
};
var unindentLineIfCodeBlock = (view) => {
	const caretLocation = view.state.selection.main.anchor;
	const document = view.state.doc.toString();
	const { from: lineFrom, to: lineTo } = expandRangeToLineEnds(view.state);
	if (isCodeBlock(view)) {
		const lineText = document.slice(lineFrom, lineTo);
		if (lineText.startsWith("	")) {
			view.dispatch({
				changes: [{
					from: lineFrom,
					to: lineFrom + 1,
					insert: ""
				}],
				userEvent: "input.type",
				scrollIntoView: true
			});
			return true;
		} else if (lineText.startsWith("    ")) {
			view.dispatch({
				changes: [{
					from: lineFrom,
					to: lineFrom + 4,
					insert: ""
				}],
				selection: EditorSelection.single(caretLocation - 4),
				userEvent: "input.type",
				scrollIntoView: true
			});
			return true;
		} else return true;
	}
	return false;
};
/**
* Finds the first heading node that overlaps with the given range.
*/
var findHeadingNode = (tree, start, end) => getNodesOverlappingRange(tree, start, end).find((node) => node.type === "heading");
/**
* Gets the heading nodes for all lines in the current selection.
* Returns an array where each element corresponds to a selected line and contains
* the heading node for that line, or undefined if the line is not a heading.
* @returns An array of heading nodes (or undefined) for each selected line, or null if no headings are found
*/
var getHeadingNodes = (view) => {
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const { from, to } = view.state.selection.main;
	const headingsByLine = MarkdownLine.linesAtRange(tree, source, from, to).map((line) => findHeadingNode(tree, line.start, line.end));
	if (!headingsByLine.some((n) => n && n.type === "heading")) return null;
	return headingsByLine;
};
/**
* Returns the heading level if all selected lines have the same heading level.
* Returns undefined if not all lines are headings or if they have different levels.
*/
var getHeadingLevelIfUniform = (view) => {
	const selectedHeadings = getHeadingNodes(view);
	const headingNodes = selectedHeadings?.filter((n) => !!n && n.type === "heading") ?? [];
	if (headingNodes.length === 0 || headingNodes.length !== selectedHeadings?.length) return void 0;
	const firstDepth = headingNodes[0].depth;
	return headingNodes.every((node) => node.depth === firstDepth) ? firstDepth : void 0;
};
/**
* Checks whether the heading level can be adjusted in the given direction.
* Returns false if all selected headings are already at the maximum (6) or minimum (1) level for the given direction.
* @returns True if the heading level can be adjusted, false otherwise
*/
var canAdjustHeadingLevel = (view, direction) => {
	const selectedHeadings = getHeadingNodes(view);
	if (!selectedHeadings) return false;
	if (direction === "increase" && selectedHeadings.every((n) => !n || n.depth === 6)) return false;
	if (direction === "decrease" && selectedHeadings.every((n) => !n || n.depth === 1)) return false;
	return true;
};
/**
* Formats the selected lines as a heading at the specified level.
* If all selected lines are already at the target level, removes the heading formatting.
* Supports both ATX (# prefix) and Setext (underline) heading styles.
* @param level - The heading level to apply (1-6)
*/
var formatHeading = (view, level) => {
	if (!view.hasFocus) view.focus();
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const selection = view.state.selection.main;
	const selectedLines = MarkdownLine.linesAtRange(tree, source, selection.from, selection.to);
	const atxPrefix = `${"#".repeat(level)} `;
	const headingNodes = selectedLines.map((line) => findHeadingNode(tree, line.start, line.end));
	const shouldAddLevel = !(headingNodes.length > 0 && headingNodes.every((node) => node?.depth === level));
	const changes = [];
	let changeSelection = void 0;
	for (const line of selectedLines) {
		const headingNode = findHeadingNode(tree, line.start, line.end);
		let headingDelimiter = null;
		if (headingNode) for (const child of headingNode.children ?? []) {
			if (!isPositionedNode(child) || child.type !== "delimiter") continue;
			const isATXDelimiter = child.tokenType === "atxHeadingSequence";
			const isSetextDelimiter = child.tokenType === "setextHeadingLine";
			if (!isATXDelimiter && !isSetextDelimiter) continue;
			headingDelimiter = child;
			if (isATXDelimiter) changes.push({
				from: child.position.start.offset,
				to: child.position.end.offset + 1
			});
			else {
				const setextLine = line.next();
				if (setextLine) changes.push({
					from: setextLine.start,
					to: setextLine.end
				});
			}
			break;
		}
		if (shouldAddLevel) {
			changes.push({
				from: line.start,
				insert: atxPrefix
			});
			const withinHeadingDelimiter = headingDelimiter && isPositionedNode(headingDelimiter) && containsRange(selection.from, selection.to, headingDelimiter.position.start.offset, headingDelimiter.position.end.offset, true);
			if (selection.empty && (selection.from === line.start || withinHeadingDelimiter)) changeSelection = { anchor: line.start + atxPrefix.length };
		}
	}
	view.dispatch({
		changes,
		selection: changeSelection,
		userEvent: "input",
		scrollIntoView: true
	});
	return true;
};
/**
* Adjusts the heading level of all selected lines in the given direction.
* Increases heading level (# to ##) or decreases it (## to #).
* Only works when all selected lines are headings and within valid level bounds.
* @returns True if the adjustment was successful, false otherwise
*/
var adjustHeadingLevel = (view, direction) => {
	if (!view) return false;
	if (!canAdjustHeadingLevel(view, direction)) return false;
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const { from, to } = view.state.selection.main;
	const selectedLines = MarkdownLine.linesAtRange(tree, source, from, to);
	const changes = [];
	for (const line of selectedLines) {
		const headingNode = findHeadingNode(tree, line.start, line.end);
		if (!headingNode) continue;
		let newLevel;
		if (direction === "increase") newLevel = Math.min(6, headingNode.depth + 1);
		else newLevel = Math.max(1, headingNode.depth - 1);
		for (const child of headingNode.children ?? []) {
			if (!isPositionedNode(child) || child.type !== "delimiter") continue;
			const isATXDelimiter = child.tokenType === "atxHeadingSequence";
			const isSetextDelimiter = child.tokenType === "setextHeadingLine";
			if (!isATXDelimiter && !isSetextDelimiter) continue;
			if (isATXDelimiter) changes.push({
				from: child.position.start.offset,
				to: child.position.end.offset,
				insert: "#".repeat(newLevel)
			});
			else {
				const setextLine = line.next();
				if (setextLine) {
					changes.push({
						from: setextLine.start,
						to: setextLine.end
					});
					changes.push({
						from: line.start,
						insert: `${"#".repeat(newLevel)} `
					});
				}
			}
			break;
		}
	}
	if (changes.length === 0) return false;
	view.dispatch({
		changes,
		userEvent: "input",
		scrollIntoView: true
	});
	return true;
};
var formatBold = (view) => {
	return inlineFormatter(view, "strong");
};
var formatItalic = (view) => {
	return inlineFormatter(view, "emphasis");
};
var formatInlineCode = (view) => {
	return inlineFormatter(view, "inlineCode");
};
var formatStrikethrough = (view) => {
	return inlineFormatter(view, "delete");
};
/**
* Get the newlines that should be prepended before inserting content at the given position.
* Ensures proper spacing between content and surrounding text.
*
* @param tree - The mdast tree
* @param source - The full document text
* @param offset - The position where content will be inserted
* @returns A string of newlines ('' for no newlines, '\n' for one, '\n\n' for two)
*/
function getNewlinePrefix(tree, source, offset) {
	const currentLine = MarkdownLine.atOffset(tree, source, offset);
	if (offset !== currentLine?.contentStart && offset !== currentLine?.start) return "\n\n";
	const previousLine = currentLine?.previous();
	if (!previousLine || previousLine?.isBlank) return "";
	return "\n";
}
/**
* Get the newlines that should be appended to ensure that there is a blank line after the position.
*
* @param source - The full document text
* @param offset - The position where content will be inserted
* @returns A string of newlines ('' for no newlines, '\n' for one, '\n\n' for two)
*/
function getNewlineSuffix(source, offset, forceNewline = false) {
	if (source[offset] === "\n") {
		if (source[offset + 1] === "\n") return "";
		return "\n";
	}
	if (offset >= source.length && !forceNewline) return "";
	return "\n\n";
}
var wrapWithDelimiter = (delimiter) => (view) => {
	if (view.state.selection.main.empty) return false;
	if (delimiter === "`" || delimiter === "~") return wrapSelectionWithFence(view, delimiter);
	const suffix = WRAP_DELIMITER_MAP[delimiter];
	wrapSelectionWithDelimiter(view, delimiter, suffix);
	return true;
};
var wrapSelectionWithFence = (view, fenceChar) => {
	const { doc, selection } = view.state;
	const range = selection.main;
	const doubleFenceLength = 2;
	const doubleFence = fenceChar.repeat(doubleFenceLength);
	const prefixStart = Math.max(0, range.from - doubleFenceLength);
	const prefixSample = doc.sliceString(prefixStart, range.from);
	const suffixSample = doc.sliceString(range.to, range.to + doubleFenceLength);
	if (range.from >= doubleFenceLength && prefixSample === doubleFence && suffixSample === doubleFence) {
		const selectionText = doc.sliceString(range.from, range.to);
		const suffixEnd = range.to + doubleFenceLength;
		const docString = doc.toString();
		const leadingNewlines = getNewlinePrefix(getMarkdownTree(view.state), docString, prefixStart);
		const trailingNewlines = getNewlineSuffix(docString, suffixEnd);
		const prefix = `${fenceChar}\n`;
		const suffix = selectionText.endsWith("\n") ? fenceChar : `\n${fenceChar}`;
		const changes = [];
		if (leadingNewlines) changes.push({
			from: prefixStart,
			insert: leadingNewlines
		});
		changes.push({
			from: range.from,
			insert: prefix
		});
		changes.push({
			from: range.to,
			insert: suffix
		});
		if (trailingNewlines) changes.push({
			from: suffixEnd,
			insert: trailingNewlines
		});
		const offsetBeforeSelection = leadingNewlines.length + prefix.length;
		view.dispatch(view.state.changeByRange((r) => ({
			changes,
			range: EditorSelection.range(r.from + offsetBeforeSelection, r.to + offsetBeforeSelection)
		})), {
			userEvent: "input",
			scrollIntoView: true
		});
		return true;
	}
	wrapSelectionWithDelimiter(view, fenceChar, fenceChar);
	return true;
};
/**
* Dedent any selected list items, automatically adjusting numbering or list markers to match their destination.
*/
var dedentSelectedListItems = (view) => {
	if (view.state.selection.ranges.length !== 1) return false;
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const selection = getListSelection(view.state);
	if (!selection) return false;
	const parent = selection?.parents.at(-1);
	let lastPrefix = parent && findItemPrefixes(parent.item).listItemPrefix?.raw;
	const itemLinesByItem = selection.selectedItems.map((item) => MarkdownLine.linesAtRange(tree, source, item.position.start.offset, item.position.end.offset - 1));
	const hasNonBlankContent = itemLinesByItem.some((lines) => lines.some((line) => !line.isBlank));
	const itemsWithRemovedTaskListPrefix = /* @__PURE__ */ new WeakSet();
	const changes = [];
	for (const [itemIndex, item] of selection.selectedItems.entries()) {
		const itemLines = itemLinesByItem[itemIndex] ?? [];
		for (const [index, line] of itemLines.entries()) {
			const prefixToUpdate = index === 0 ? line.prefixes.findLast((p) => p.tokenType === "listItemPrefix") : void 0;
			const indentToRemove = line.prefixes.findLast((p) => p.tokenType === "listItemIndent");
			const taskListPrefix = index === 0 ? line.prefixes.find((p) => p.tokenType === "taskListCheck") : void 0;
			const contentIsTaskListMarker = index === 0 ? isTasklistPrefix(line.content) : false;
			const hasIndentPrefix = line.prefixes.some((p) => p.tokenType === "listItemIndent");
			const shouldRemoveTaskListPrefix = index === 0 && line.isBlank && !hasIndentPrefix && (taskListPrefix !== void 0 || contentIsTaskListMarker);
			if (shouldRemoveTaskListPrefix) itemsWithRemovedTaskListPrefix.add(item);
			const toPosition = shouldRemoveTaskListPrefix && taskListPrefix && isPositionedNode(taskListPrefix) ? taskListPrefix.position.end.offset : shouldRemoveTaskListPrefix && contentIsTaskListMarker ? line.contentStart + line.content.length : prefixToUpdate?.position?.end.offset ?? indentToRemove?.position?.end.offset ?? taskListPrefix?.position?.start.offset ?? line.contentStart;
			const change = {
				from: indentToRemove?.position?.start.offset ?? prefixToUpdate?.position?.start.offset ?? line.start,
				to: toPosition,
				insert: lastPrefix && prefixToUpdate ? lastPrefix = buildNextMarkerSyntax(lastPrefix) : ""
			};
			changes.push(change);
		}
	}
	const lastItemIndex = selection.list.children.indexOf(selection.selectedItems.at(-1));
	if (lastItemIndex > -1) changes.push(remarkFollowingItems(selection.list, lastItemIndex, null));
	const annotations = [];
	if (parent) {
		const parentItemIndex = parent.list.children.indexOf(parent.item);
		changes.push(remarkFollowingItems(parent.list, parentItemIndex, lastPrefix ?? ""));
	} else {
		for (const item of selection.selectedItems) {
			const { taskListPrefix } = findItemPrefixes(item);
			if (taskListPrefix && isPositionedNode(taskListPrefix) && !itemsWithRemovedTaskListPrefix.has(item)) changes.push({
				from: taskListPrefix.position.start.offset,
				to: taskListPrefix.position.end.offset
			});
		}
		if (hasNonBlankContent) {
			const prevLine = MarkdownLine.atOffset(tree, source, selection.selectedItems[0].position.start.offset - 1);
			if (prevLine?.prefixes.some((p) => p.tokenType === "listItemPrefix" || p.tokenType === "listItemIndent")) changes.push({
				from: prevLine.end,
				insert: "\n"
			});
			const nextLine = MarkdownLine.atOffset(tree, source, selection.selectedItems.at(-1).position.end.offset + 1);
			if (nextLine?.prefixes.some((p) => p.tokenType === "listItemPrefix" || p.tokenType === "listItemIndent")) changes.push({
				from: nextLine.start,
				insert: "\n"
			});
			annotations.push(escapeMarkdownContinuation.of("escapeList"));
		}
	}
	view.dispatch({
		scrollIntoView: true,
		userEvent: "input",
		changes,
		annotations
	});
	return true;
};
/** If a single cursor is in a blank list item, dedent or remove that list item. */
var dedentListIfBlankItem = (view) => {
	if (view.state.selection.ranges.length !== 1 || !view.state.selection.main.empty) return false;
	const source = view.state.doc.toString();
	const caretPosition = view.state.selection.main.anchor;
	const tree = getMarkdownTree(view.state);
	const line = MarkdownLine.atOffset(tree, source, caretPosition);
	if (!line || !isCaretInBlankListItem(line, caretPosition)) return false;
	return dedentSelectedListItems(view);
};
var isCaretInBlankListItem = (line, caretOffset) => {
	if (!line.isBlank) return false;
	if (line.lastPrefix?.tokenType !== "listItemPrefix") return false;
	return line.isOffsetAfterPrefixes(caretOffset);
};
function getListPrefixAtDepth(line, depth) {
	for (const prefix of line.prefixes) if (prefix.tokenType === "listItemIndent" || prefix.tokenType === "listItemPrefix") {
		if (depth === 0) return prefix;
		depth--;
	}
}
/**
* Generate changes to remove a list, handling cases where the list is a nested list or has a nested list in it.
* Operates on the lowest list that fully contains the selection.
*/
var removeList = (view) => {
	const tree = getMarkdownTree(view.state);
	const doc = view.state.doc.toString();
	const selection = getListSelection(view.state);
	if (!selection) return false;
	const depth = selection.parents.length;
	const changes = [];
	for (const item of positionedItems(selection.list.children)) for (const line of MarkdownLine.linesAtRange(tree, doc, item.position.start.offset, item.position.end.offset - 1)) {
		const prefix = getListPrefixAtDepth(line, depth);
		if (!prefix || !isPositionedNode(prefix)) continue;
		changes.push({
			from: prefix.position.start.offset,
			to: prefix.position.end.offset
		});
	}
	if (changes.length) {
		view.dispatch({
			changes,
			userEvent: "input",
			scrollIntoView: true
		});
		return true;
	}
	return false;
};
/**
* Finds the position of the end of the blockquote prefix at the given `depth`, where `depth` is the number of
* blockquote ancestors. For example, if the line is `> > > > hello` and the depth is `2`, will return `3` (the index
* after the location of the second '>' prefix).
*/
function findBlockquotePrefixEnd(line, depth) {
	if (depth === 0) return line.start;
	for (const prefix of line.prefixes) if (prefix.tokenType === "blockQuotePrefix") {
		depth--;
		if (depth === 0) return prefix.position?.end.offset ?? line.start;
	}
	return line.start;
}
/** Generate changes to convert an entire list to a different type. Does not actually execute the transaction. */
function buildListConversion(tree, doc, list, toOrdered) {
	const changes = [];
	let lastMarker = null;
	for (const item of positionedItems(list.children)) {
		const lines = MarkdownLine.linesAtRange(tree, doc, item.position.start.offset, item.position.end.offset - 1);
		for (const [i, line] of lines.entries()) if (i === 0) {
			const prefix = line?.prefixes.find((p) => p.tokenType === "listItemPrefix");
			if (!prefix || !isPositionedNode(prefix)) continue;
			const marker = lastMarker ? buildNextMarkerSyntax(lastMarker) : buildFirstMarkerSyntax(toOrdered);
			changes.push({
				from: prefix.position.start.offset,
				to: prefix.position.end.offset,
				insert: marker
			});
			lastMarker = marker;
		} else {
			const indentPrefix = line?.prefixes.find((p) => p.tokenType === "listItemIndent");
			if (!indentPrefix || !lastMarker || !isPositionedNode(indentPrefix) || indentPrefix.raw.length === lastMarker.length) continue;
			changes.push({
				from: indentPrefix.position.start.offset,
				to: indentPrefix.position.end.offset,
				insert: buildItemContinuationSyntax(lastMarker)
			});
		}
	}
	return changes;
}
/**
* Either create, replace, or remove lists depending on the selection and contents.
*/
var formatList = (ordered) => (view, eventSource) => {
	const state = view.state;
	const tree = getMarkdownTree(state);
	const doc = state.doc.toString();
	const selection = state.selection.main;
	const selectionCollapsed = selection.from === selection.to;
	const caretLine = selectionCollapsed ? MarkdownLine.atOffset(tree, doc, selection.from) : null;
	const userEvent = eventSource === "keyboard" ? "input.type" : "input";
	const deepestListContainingSelection = Array.from(getNodesContainingRange(tree, selection.from, selection.to, true)).findLast((n) => n.type === "list");
	if (deepestListContainingSelection) if ((deepestListContainingSelection.ordered ?? false) !== ordered) {
		const changes = buildListConversion(tree, doc, deepestListContainingSelection, ordered);
		view.dispatch({
			changes,
			scrollIntoView: true,
			userEvent
		});
		return true;
	} else return removeList(view);
	/** Array of top-level affected nodes to operate on. */
	let selectedNodes = getChildrenOverlappingRange(tree, selection.from, selection.to);
	/** Track the number of wrapping blockquote elements, so we can determine where on a line to insert the list marker. */
	let blockquoteDepth = 0;
	while (selectedNodes.length === 1 && selectedNodes[0].type === "blockquote") {
		selectedNodes = getChildrenOverlappingRange(selectedNodes[0], selection.from, selection.to);
		blockquoteDepth++;
	}
	const caretBlockquoteDepth = caretLine ? caretLine.prefixes.filter((prefix) => prefix.tokenType === "blockQuotePrefix").length : 0;
	if (caretBlockquoteDepth > blockquoteDepth) blockquoteDepth = caretBlockquoteDepth;
	let lastMarker = null;
	const changes = [];
	let explicitSelection;
	const lineGroups = [];
	for (const node of selectedNodes) {
		if (node.type === "list") {
			changes.push(...buildListConversion(tree, doc, node, ordered));
			continue;
		}
		const nodeLines = isPositionedNode(node) ? MarkdownLine.linesAtRange(tree, doc, node.position.start.offset, node.position.end.offset - 1) : [];
		if (nodeLines.length > 0) lineGroups.push({
			lines: nodeLines,
			nodeType: node.type
		});
	}
	if (lineGroups.length === 0 && caretLine) lineGroups.push({
		lines: [caretLine],
		nodeType: "paragraph"
	});
	const totalGroups = lineGroups.length;
	for (const [groupIndex, group] of lineGroups.entries()) {
		const { lines, nodeType } = group;
		for (const [lineIndex, line] of lines.entries()) {
			const overlapsSelection = line.overlaps(selection.from, selection.to) || selectionCollapsed && (selection.from === line.start || selection.from === line.end);
			if (line.isBlank && !overlapsSelection) continue;
			const from = findBlockquotePrefixEnd(line, blockquoteDepth);
			if (nodeType === "paragraph" && !overlapsSelection) continue;
			if (lineIndex === 0 || nodeType === "paragraph") {
				const prevLine = line.previous();
				const prevLineIsBlank = prevLine && prevLine.isBlank;
				if (lastMarker === null && prevLine && !prevLine.isBlank && !line.isBlank) changes.push({
					from: line.start - 1,
					insert: "\n"
				});
				const marker = lastMarker === null || prevLineIsBlank ? buildFirstMarkerSyntax(ordered) : buildNextMarkerSyntax(lastMarker);
				const markerChange = {
					from,
					insert: marker
				};
				changes.push(markerChange);
				lastMarker = marker;
			} else if (lastMarker) changes.push({
				from,
				insert: buildItemContinuationSyntax(lastMarker)
			});
			if (!line.isBlank && groupIndex === totalGroups - 1 && lineIndex === lines.length - 1) {
				const nextLine = line.next();
				if (nextLine && !nextLine.isBlank) changes.push({
					from: line.end,
					insert: "\n"
				});
			}
		}
	}
	if (changes.length === 0) {
		const line = MarkdownLine.atOffset(tree, doc, selection.from);
		if (line) {
			if (selectionCollapsed && (selection.from === line.start || selection.from === line.end)) {
				const blockquotePrefixDepth = line.prefixes.filter((prefix) => prefix.tokenType === "blockQuotePrefix").length;
				const insertionPoint = findBlockquotePrefixEnd(line, blockquoteDepth || blockquotePrefixDepth);
				const prevLine = line.previous();
				const newlineBeforeInserted = prevLine && !prevLine.isBlank ? 1 : 0;
				if (newlineBeforeInserted) changes.push({
					from: line.start - 1,
					insert: "\n"
				});
				const marker = buildFirstMarkerSyntax(ordered);
				changes.push({
					from: insertionPoint,
					insert: marker
				});
				if (!explicitSelection) {
					const anchor = insertionPoint + newlineBeforeInserted + marker.length;
					explicitSelection = EditorSelection.single(anchor, anchor);
				}
				const nextLine = line.next();
				if (nextLine && !nextLine.isBlank) changes.push({
					from: line.end,
					insert: "\n"
				});
			}
		}
		if (changes.length === 0) return false;
	}
	if (!explicitSelection && selectionCollapsed && changes.length > 0) try {
		const changeSet = ChangeSet.of(changes, doc.length);
		if (caretLine?.isBlank) {
			const anchor = changeSet.mapPos(selection.from, 1);
			explicitSelection = EditorSelection.single(anchor);
		} else {
			const updatedDoc = changeSet.apply(Text.of(doc.split("\n"))).toString();
			const insertedMarker = buildFirstMarkerSyntax(ordered);
			const searchStart = Math.max(0, changeSet.mapPos(selection.from, -1) - insertedMarker.length);
			let markerIndex = updatedDoc.indexOf(insertedMarker, searchStart);
			if (markerIndex === -1) markerIndex = updatedDoc.indexOf(insertedMarker);
			const newlineMarkerIndex = updatedDoc.indexOf(`\n${insertedMarker}`, Math.max(0, selection.from - 1));
			if (newlineMarkerIndex !== -1 && (markerIndex === -1 || newlineMarkerIndex + 1 < markerIndex)) markerIndex = newlineMarkerIndex + 1;
			else if (markerIndex !== -1 && updatedDoc.charAt(markerIndex - 1) !== "\n") {
				const fallbackNewlineIndex = updatedDoc.indexOf(`\n${insertedMarker}`, Math.max(0, selection.from - 1));
				if (fallbackNewlineIndex !== -1) markerIndex = fallbackNewlineIndex + 1;
			}
			let anchor = changeSet.mapPos(selection.from, 1);
			if (markerIndex >= 0 && anchor < markerIndex + insertedMarker.length) anchor = markerIndex + insertedMarker.length;
			if (markerIndex >= 0) {
				const markerNewlineIndex = updatedDoc.indexOf(`\n${insertedMarker}`, Math.max(0, markerIndex - 1));
				if (markerNewlineIndex !== -1) {
					const newlineAnchorTarget = markerNewlineIndex + 1 + insertedMarker.length;
					if (anchor < newlineAnchorTarget) anchor = newlineAnchorTarget;
				}
			}
			const safeAnchor = Math.min(anchor, updatedDoc.length);
			explicitSelection = EditorSelection.single(safeAnchor, safeAnchor);
		}
	} catch {}
	const transaction = {
		changes,
		scrollIntoView: true,
		userEvent
	};
	if (explicitSelection) transaction.selection = explicitSelection;
	view.dispatch(transaction);
	return true;
};
var formatUnorderedList = formatList(false);
var formatOrderedList = formatList(true);
var DEFAULT_TASKLIST_PREFIX = buildTasklistPrefixSyntax(false);
var TASK_LIST_MARKER = `- ${DEFAULT_TASKLIST_PREFIX}`;
var formatTaskList = (view) => {
	if (!view.hasFocus) view.focus();
	const selection = view.state.selection.main;
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const from = selection.from;
	const to = selection.to;
	const lines = MarkdownLine.linesAtRange(tree, source, from, Math.max(to - 1, from));
	const changes = [];
	for (const currentLine of lines) {
		const taskListPrefix = currentLine.prefixes.find((prefix) => prefix.tokenType === "taskListCheck");
		if (taskListPrefix && isPositionedNode(taskListPrefix)) {
			const removeFrom = taskListPrefix.position.start.offset;
			let removeTo = taskListPrefix.position.end.offset;
			if (source.charAt(removeTo) === " ") removeTo += 1;
			changes.push({
				from: removeFrom,
				to: removeTo
			});
			continue;
		}
		const listItemPrefix = currentLine.prefixes.findLast((prefix) => prefix.tokenType === "listItemPrefix");
		if (listItemPrefix && isPositionedNode(listItemPrefix)) {
			const insertPosition = listItemPrefix.position.end.offset;
			const existingTaskMatch = source.slice(insertPosition, currentLine.end).match(/^\[[ xX]\]\s*/);
			if (existingTaskMatch) {
				changes.push({
					from: insertPosition,
					to: insertPosition + existingTaskMatch[0].length
				});
				continue;
			}
			changes.push({
				from: insertPosition,
				to: insertPosition,
				insert: DEFAULT_TASKLIST_PREFIX
			});
			continue;
		}
		const insertPosition = currentLine.contentStart;
		if (view.state.doc.sliceString(insertPosition, insertPosition + TASK_LIST_MARKER.length) === TASK_LIST_MARKER) continue;
		changes.push({
			from: insertPosition,
			to: insertPosition,
			insert: TASK_LIST_MARKER
		});
	}
	if (changes.length === 0) return true;
	const changeSet = ChangeSet.of(changes, view.state.doc.length);
	const selectionIsCollapsed = selection.anchor === selection.head;
	const selectionForward = selection.anchor <= selection.head;
	const anchorAssoc = selectionIsCollapsed ? 1 : selectionForward ? -1 : 1;
	const headAssoc = selectionIsCollapsed ? 1 : selectionForward ? 1 : -1;
	const anchor = changeSet.mapPos(selection.anchor, anchorAssoc);
	const head = changeSet.mapPos(selection.head, headAssoc);
	view.dispatch({
		changes,
		selection: EditorSelection.single(anchor, head),
		userEvent: "input",
		scrollIntoView: true
	});
	return true;
};
/** Get the previous sibling list item if there is one.. */
function getPreviousSibling(list, item) {
	const children = list.children.filter((n) => n.type === "listItem");
	return children[children.indexOf(item) - 1];
}
/** From the selection, travel up the tree to find a valid item for indenting. */
function findValidItemsToIndent(selection) {
	let list = selection.list;
	let items = selection.selectedItems;
	let previousSibling = items[0] && getPreviousSibling(list, items[0]);
	const parents = [...selection.parents];
	while (!previousSibling) {
		const parent = parents.pop();
		if (!parent) return null;
		list = parent.list;
		items = [parent.item];
		previousSibling = getPreviousSibling(list, parent.item);
	}
	return {
		list,
		items,
		previousSibling
	};
}
/**
* Indent any selected list items, automatically adjusting numbering or list markers to match their destination.
*/
var indentSelectedListItems = (view) => {
	if (view.state.selection.ranges.length !== 1) return false;
	const tree = getMarkdownTree(view.state);
	const source = view.state.doc.toString();
	const selection = getListSelection(view.state);
	if (!selection) return false;
	const itemsToIndent = findValidItemsToIndent(selection);
	if (!itemsToIndent || !itemsToIndent.items[0]) return true;
	const prevSiblingPrefix = findItemPrefixes(itemsToIndent.previousSibling).listItemPrefix?.raw ?? "* ";
	const indent = " ".repeat(prevSiblingPrefix.length);
	const newPreviousSibling = itemsToIndent.previousSibling.children?.findLast((n) => n.type === "list")?.children?.findLast((n) => n.type === "listItem");
	let nextPrefix = newPreviousSibling ? buildNextMarkerSyntax(findItemPrefixes(newPreviousSibling).listItemPrefix?.raw ?? "* ") : buildResetMarkerSyntax(findItemPrefixes(itemsToIndent.items[0]).listItemPrefix?.raw ?? "* ");
	const changes = itemsToIndent.items.map((item) => {
		if (!isPositionedNode(item)) return [];
		let listItemPrefixIndex = -1;
		return MarkdownLine.linesAtRange(tree, source, item.position.start.offset, item.position.end.offset - 1).map((line, index) => {
			if (index === 0) {
				listItemPrefixIndex = line.prefixes.findIndex((p) => p.tokenType === "listItemPrefix");
				const change = {
					from: line.prefixes[listItemPrefixIndex]?.position?.start?.offset ?? line.start,
					to: line.prefixes[listItemPrefixIndex]?.position?.end?.offset ?? line.contentStart,
					insert: `${indent}${nextPrefix}`
				};
				nextPrefix = buildNextMarkerSyntax(nextPrefix);
				return change;
			}
			return {
				from: line.prefixes[listItemPrefixIndex]?.position?.start?.offset ?? line.start,
				insert: indent
			};
		});
	});
	const lastItemIndex = itemsToIndent.list.children.indexOf(itemsToIndent.items.at(-1));
	changes.push(remarkFollowingItems(itemsToIndent.list, lastItemIndex, prevSiblingPrefix));
	view.dispatch({
		scrollIntoView: true,
		userEvent: "input",
		changes
	});
	return true;
};
/**
* Replace the selection with a new list item, if the user is in a list. The new item will respect the current
* list item markers and automatically increment following markers if necessary.
*/
var insertNewListItem = (view) => {
	const selection = getListSelection(view.state);
	const firstSelectedItem = selection?.selectedItems[0];
	if (!firstSelectedItem) return false;
	const caretPos = getCaretPosition(view.state);
	if (getCurrentSelectionContext(view.state).some((node) => node.type === "code" && (caretPos === null || isInsideCodeBlock(node, caretPos)))) return false;
	const { listItemPrefix, taskListPrefix } = findItemPrefixes(firstSelectedItem);
	const lastPrefix = taskListPrefix ?? listItemPrefix;
	if (lastPrefix && isPositionedNode(lastPrefix) && trimmedDelimiterPosition(lastPrefix).endOffset > view.state.selection.main.from) return false;
	const currentItemMarker = listItemPrefix?.raw;
	if (!currentItemMarker) return false;
	let nextMarker = buildNextMarkerSyntax(currentItemMarker);
	if (!nextMarker.endsWith(" ")) nextMarker += " ";
	if (taskListPrefix) nextMarker += buildTasklistPrefixSyntax(false);
	const lastSelectedItem = selection.selectedItems.at(-1);
	const additionalChanges = selection.list.ordered ? remarkFollowingItems(selection.list, selection.list.children.indexOf(lastSelectedItem), nextMarker) : [];
	view.dispatch(view.state.replaceSelection(`\n${nextMarker}`), {
		annotations: [escapeMarkdownContinuation.of("escapeList")],
		userEvent: "input",
		scrollIntoView: true,
		changes: additionalChanges
	});
	return true;
};
var visitIfLink = (view) => {
	const caretLocation = view.state.selection.main.anchor;
	const nodeWithCaret = getNodeAtOffset(getMarkdownTree(view.state), caretLocation);
	if (nodeWithCaret?.type === "link") {
		window.open(nodeWithCaret.url, "_blank", "noopener,noreferrer");
		return true;
	}
	return false;
};
var formatLinkKeybinding = {
	key: "Mod-k",
	run: formatLink
};
var formatBoldKeybinding = {
	key: "Mod-b",
	run: formatBold
};
var formatItalicKeybinding = {
	key: "Mod-i",
	run: formatItalic
};
var formatInlineCodeKeybinding = {
	key: "Mod-e",
	run: formatInlineCode
};
var formatBlockquoteKeybinding = {
	key: "Mod-Shift-.",
	run: formatBlockquote
};
var formatUnorderedListKeybinding = {
	key: "Mod-Shift-8",
	run: formatUnorderedList
};
var formatOrderedListKeybinding = {
	key: "Mod-Shift-7",
	run: formatOrderedList
};
var formatHeading1Keybinding = {
	key: "Mod-Alt-1",
	run: (view) => formatHeading(view, 1)
};
var formatHeading2Keybinding = {
	key: "Mod-Alt-2",
	run: (view) => formatHeading(view, 2)
};
var formatHeading3Keybinding = {
	key: "Mod-Alt-3",
	run: (view) => formatHeading(view, 3)
};
var formatHeading4Keybinding = {
	key: "Mod-Alt-4",
	run: (view) => formatHeading(view, 4)
};
var formatHeading5Keybinding = {
	key: "Mod-Alt-5",
	run: (view) => formatHeading(view, 5)
};
var formatHeading6Keybinding = {
	key: "Mod-Alt-6",
	run: (view) => formatHeading(view, 6)
};
var formatStrikethroughKeybinding = {
	key: "Mod-Shift-x",
	run: formatStrikethrough
};
var formatTaskListKeybinding = {
	key: "Mod-Shift-l",
	run: formatTaskList
};
var wrapWithDelimiterKeybindings = Object.keys(WRAP_DELIMITER_MAP).map((key) => ({
	key,
	run: wrapWithDelimiter(key)
}));
function markdownKeymapExtension({ primaryAction, trackKeyboardShortcut }) {
	const track = (binding, commandId) => {
		if (!binding.run || !binding.key) return binding;
		const run = binding.run;
		const shortcut = binding.key;
		return {
			...binding,
			run: (view) => {
				const handled = run(view);
				trackKeyboardShortcut({
					commandId,
					shortcut,
					handled
				});
				return handled;
			}
		};
	};
	const bindings = [
		{
			binding: {
				key: "Enter",
				run: closeCodeBlock
			},
			commandId: "close_code_block"
		},
		{
			binding: {
				key: "Enter",
				run: dedentListIfBlankItem
			},
			commandId: "dedent_list_if_blank_item"
		},
		{
			binding: {
				key: "Enter",
				run: insertNewListItem
			},
			commandId: "insert_new_list_item"
		},
		{
			binding: {
				key: "Enter",
				run: splitBlockquoteIfBlankLine
			},
			commandId: "split_blockquote_if_blank_line"
		},
		{
			binding: {
				key: "Alt-Enter",
				run: visitIfLink
			},
			commandId: "visit_if_link"
		},
		{
			binding: {
				key: "Mod-Enter",
				run: primaryAction
			},
			commandId: "primary_action"
		},
		{
			binding: formatLinkKeybinding,
			commandId: "format_link"
		},
		{
			binding: formatBoldKeybinding,
			commandId: "format_bold"
		},
		{
			binding: formatItalicKeybinding,
			commandId: "format_italic"
		},
		{
			binding: formatInlineCodeKeybinding,
			commandId: "format_inline_code"
		},
		{
			binding: formatStrikethroughKeybinding,
			commandId: "format_strikethrough"
		},
		{
			binding: formatTaskListKeybinding,
			commandId: "format_task_list"
		},
		{
			binding: formatBlockquoteKeybinding,
			commandId: "format_blockquote"
		},
		{
			binding: formatUnorderedListKeybinding,
			commandId: "format_unordered_list"
		},
		{
			binding: formatOrderedListKeybinding,
			commandId: "format_ordered_list"
		},
		{
			binding: formatHeading1Keybinding,
			commandId: "format_heading_1"
		},
		{
			binding: formatHeading2Keybinding,
			commandId: "format_heading_2"
		},
		{
			binding: formatHeading3Keybinding,
			commandId: "format_heading_3"
		},
		{
			binding: formatHeading4Keybinding,
			commandId: "format_heading_4"
		},
		{
			binding: formatHeading5Keybinding,
			commandId: "format_heading_5"
		},
		{
			binding: formatHeading6Keybinding,
			commandId: "format_heading_6"
		},
		...wrapWithDelimiterKeybindings.map((binding) => ({
			binding,
			commandId: binding.key ? `wrap_with_${binding.key.replace(/[^a-zA-Z0-9]+/g, "_").toLowerCase()}` : "wrap_with_delimiter"
		})),
		{
			binding: {
				key: "Tab",
				run: indentLineIfCodeBlock
			},
			commandId: "indent_line_if_code_block"
		},
		{
			binding: {
				key: "Shift-Tab",
				run: unindentLineIfCodeBlock
			},
			commandId: "unindent_line_if_code_block"
		},
		{
			binding: {
				key: "Shift-Tab",
				run: dedentSelectedListItems
			},
			commandId: "dedent_selected_list_items"
		},
		{
			binding: {
				key: "Tab",
				run: indentSelectedListItems
			},
			commandId: "indent_selected_list_items"
		},
		{
			binding: {
				key: "Mod-[",
				run: dedentSelectedListItems
			},
			commandId: "dedent_selected_list_items_mod"
		},
		{
			binding: {
				key: "Mod-]",
				run: indentSelectedListItems
			},
			commandId: "indent_selected_list_items_mod"
		}
	].map(({ binding, commandId }) => track({ ...binding }, commandId));
	return keymap.of(bindings);
}
var EVENT_PREFIX = "hybrid_markdown_editor";
var HybridEditorTelemetryContext = createContext({
	trackViewSwitch: () => {},
	trackToolbarInteraction: () => {},
	trackKeyboardShortcut: () => {},
	trackAutocompleteShown: () => {},
	trackAutocompleteSelected: () => {},
	trackFileUpload: () => {}
});
HybridEditorTelemetryContext.displayName = "HybridEditorTelemetryContext";
function useHybridEditorTelemetry() {
	return use(HybridEditorTelemetryContext);
}
function HybridEditorTelemetryProvider(t0) {
	const $ = c$1(5);
	const { options, children } = t0;
	let t1;
	if ($[0] !== options) {
		t1 = createHybridEditorTelemetry(options);
		$[0] = options;
		$[1] = t1;
	} else t1 = $[1];
	const telemetry = t1;
	let t2;
	if ($[2] !== children || $[3] !== telemetry) {
		t2 = jsx(HybridEditorTelemetryContext, {
			value: telemetry,
			children
		});
		$[2] = children;
		$[3] = telemetry;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
HybridEditorTelemetryProvider.displayName = "HybridEditorTelemetryProvider";
function createHybridEditorTelemetry({ featureFlagEnabled, editorId, surface }) {
	const baseProperties = { ["feature_flag_markdown_experience_hybrid_editor"]: featureFlagEnabled };
	if (editorId) baseProperties["editor_id"] = editorId;
	if (surface) baseProperties.surface = surface;
	const sendWithBaseProperties = (eventName, properties) => {
		const payload = {
			...baseProperties,
			...properties
		};
		try {
			sendEvent(eventName, payload);
		} catch (error) {
			if (error instanceof ReferenceError && typeof error.message === "string" && error.message.includes("telemetry")) return;
			throw error;
		}
	};
	const trackHybridEvent = (event, properties) => {
		sendWithBaseProperties(`${EVENT_PREFIX}.${event}`, properties);
	};
	return {
		trackViewSwitch: ({ from, to, trigger }) => {
			sendWithBaseProperties("markdown_editor.select_view", {
				mode: to,
				["from_mode"]: from ?? "unknown",
				trigger,
				["did_change"]: from ? from !== to : true
			});
		},
		trackToolbarInteraction: ({ control, action, trigger, isActive, keybinding, handled }) => {
			trackHybridEvent("toolbar_interaction", {
				control,
				action,
				trigger,
				["is_active"]: isActive ?? null,
				keybinding: Array.isArray(keybinding) ? keybinding.join(",") : keybinding,
				handled: handled ?? null
			});
		},
		trackKeyboardShortcut: ({ commandId, shortcut, handled }) => {
			trackHybridEvent("keyboard_shortcut", {
				command: commandId,
				shortcut,
				handled
			});
		},
		trackAutocompleteShown: ({ triggerChar, queryLength, suggestionState, suggestionCount }) => {
			trackHybridEvent("autocomplete_shown", {
				["trigger_char"]: triggerChar,
				["query_length"]: queryLength,
				["suggestion_state"]: suggestionState,
				["suggestion_count"]: suggestionCount ?? null
			});
		},
		trackAutocompleteSelected: ({ triggerChar, insertedLength, multiStep, suggestionKind }) => {
			trackHybridEvent("autocomplete_selected", {
				["trigger_char"]: triggerChar,
				["inserted_length"]: insertedLength,
				["multi_step"]: multiStep,
				["suggestion_kind"]: suggestionKind
			});
		},
		trackFileUpload: ({ phase, mimeType, sizeBytes, mediaKind, errorType }) => {
			trackHybridEvent("file_upload", {
				phase,
				["mime_type"]: mimeType,
				["size_bytes"]: sizeBytes,
				["media_kind"]: mediaKind ?? "other",
				["error_type"]: errorType ?? null
			});
		}
	};
}
var Toolbar_module_default = {
	actionBar: "Toolbar-module_wERI9W_actionBar",
	container: "Toolbar-module_wERI9W_container",
	leftAligned: "Toolbar-module_wERI9W_leftAligned",
	menuKeybindingHint: "Toolbar-module_wERI9W_menuKeybindingHint",
	menuLeadingVisualPlaceholder: "Toolbar-module_wERI9W_menuLeadingVisualPlaceholder"
};
/** Provides toolbar button access to the hybrid editor's CodeMirror view and stateful values. */
var ToolbarContext = createContext({
	view: null,
	selectedNodes: []
});
ToolbarContext.displayName = "ToolbarContext";
function formatKeybindingHint(input) {
	return input?.replaceAll("+", "Plus")?.replaceAll("-", "+");
}
var CheckIconPlaceholder = () => /* @__PURE__ */ jsx("div", { className: Toolbar_module_default.menuLeadingVisualPlaceholder });
CheckIconPlaceholder.displayName = "CheckIconPlaceholder";
var generateTrailingVisual = ({ keys }) => function TrailingVisual() {
	return /* @__PURE__ */ jsx(KeybindingHint, {
		className: Toolbar_module_default.menuKeybindingHint,
		keys
	});
};
var HeadingMenu = () => {
	const telemetry = useHybridEditorTelemetry();
	const { view, selectedNodes } = use(ToolbarContext);
	const withinHeadingSelection = useMemo(() => {
		if (!view) return void 0;
		return getHeadingLevelIfUniform(view);
	}, [selectedNodes, view]);
	const isHeadingLevelChangeEnabled = useCallback((direction) => {
		if (!view) return false;
		return canAdjustHeadingLevel(view, direction);
	}, [selectedNodes, view]);
	const getLeadingVisual = useCallback((level) => {
		if (!(withinHeadingSelection !== void 0)) return;
		if (withinHeadingSelection === level) return CheckIcon;
		return CheckIconPlaceholder;
	}, [withinHeadingSelection]);
	const getTrailingVisual = useCallback((keybinding) => {
		const keys = formatKeybindingHint(keybinding.key);
		if (!keys) return void 0;
		return generateTrailingVisual({ keys });
	}, []);
	const runCommand = useCallback((level, keybinding) => {
		if (!view) return;
		const isPressed = withinHeadingSelection === level;
		const handled = (keybinding.run || (() => false))(view, "toolbar");
		telemetry.trackToolbarInteraction({
			control: `heading_${level}`,
			action: `heading_${level}`,
			trigger: "toolbar",
			isActive: isPressed,
			keybinding: keybinding.key,
			handled
		});
	}, [
		telemetry,
		view,
		withinHeadingSelection
	]);
	const handleLevelAdjustment = useCallback((direction) => {
		if (!view) return;
		let handled = false;
		if (direction === "increase") handled = adjustHeadingLevel(view, "increase");
		if (direction === "decrease") handled = adjustHeadingLevel(view, "decrease");
		telemetry.trackToolbarInteraction({
			control: `${direction}_heading_level`,
			action: `${direction}_heading_level`,
			trigger: "toolbar",
			isActive: true,
			handled
		});
	}, [telemetry, view]);
	return /* @__PURE__ */ jsx(ActionBar.Menu, {
		"aria-label": "Heading",
		icon: HeadingIcon,
		items: [
			{
				label: "Heading 1",
				onClick: () => runCommand(1, formatHeading1Keybinding),
				leadingVisual: getLeadingVisual(1),
				trailingVisual: getTrailingVisual(formatHeading1Keybinding)
			},
			{
				label: "Heading 2",
				onClick: () => runCommand(2, formatHeading2Keybinding),
				leadingVisual: getLeadingVisual(2),
				trailingVisual: getTrailingVisual(formatHeading2Keybinding)
			},
			{
				label: "Heading 3",
				onClick: () => runCommand(3, formatHeading3Keybinding),
				leadingVisual: getLeadingVisual(3),
				trailingVisual: getTrailingVisual(formatHeading3Keybinding)
			},
			{
				label: "Heading 4",
				onClick: () => runCommand(4, formatHeading4Keybinding),
				leadingVisual: getLeadingVisual(4),
				trailingVisual: getTrailingVisual(formatHeading4Keybinding)
			},
			{
				label: "Heading 5",
				onClick: () => runCommand(5, formatHeading5Keybinding),
				leadingVisual: getLeadingVisual(5),
				trailingVisual: getTrailingVisual(formatHeading5Keybinding)
			},
			{
				label: "Heading 6",
				onClick: () => runCommand(6, formatHeading6Keybinding),
				leadingVisual: getLeadingVisual(6),
				trailingVisual: getTrailingVisual(formatHeading6Keybinding)
			},
			{ type: "divider" },
			{
				label: "Increase heading level",
				onClick: () => handleLevelAdjustment("increase"),
				disabled: !isHeadingLevelChangeEnabled("increase")
			},
			{
				label: "Decrease heading level",
				onClick: () => handleLevelAdjustment("decrease"),
				disabled: !isHeadingLevelChangeEnabled("decrease")
			}
		]
	});
};
HeadingMenu.displayName = "HeadingMenu";
var ToolbarButton = (t0) => {
	const { command, matchingNodeFilter, resolveIsPressed, telemetryId, ...props } = t0;
	const { view, selectedNodes } = use(ToolbarContext);
	const defaultIsPressed = selectedNodes.some(matchingNodeFilter);
	const isPressed = resolveIsPressed?.(selectedNodes, defaultIsPressed) ?? defaultIsPressed;
	const telemetry = useHybridEditorTelemetry();
	const ariaLabel = props["aria-label"];
	const commandIsKeybinding = typeof command !== "function";
	const fallbackCommand = _temp;
	const commandFn = (commandIsKeybinding ? command.run : command) ?? fallbackCommand;
	const commandHint = commandIsKeybinding ? command.key : void 0;
	const runCommand = () => {
		if (!view) return;
		if (!view.hasFocus) view.focus();
		const handled = commandFn(view, "toolbar");
		telemetry.trackToolbarInteraction({
			control: telemetryId ?? ariaLabel ?? "unknown",
			action: telemetryId ?? ariaLabel ?? "unknown",
			trigger: "toolbar",
			isActive: isPressed,
			keybinding: commandHint,
			handled
		});
	};
	return jsx(ActionBar.IconButton, {
		variant: "invisible",
		onMouseDown: _temp2,
		keybindingHint: formatKeybindingHint(commandHint),
		disabled: !view,
		onClick: runCommand,
		"aria-pressed": isPressed,
		...props
	});
};
ToolbarButton.displayName = "ToolbarButton";
ToolbarButton.displayName = "MarkdownEditor.ToolbarButton";
function _temp() {
	return false;
}
function _temp2(e) {
	return e.preventDefault();
}
var Toolbar = ({ view, fileUploadButton, selectedNodes, customButtons }) => {
	const toolbarRedesignEnabled = isFeatureEnabled("markdown_experience_toolbar_redesign");
	const isListItem = (node) => node.type === "listItem";
	const isTaskListItem = (node) => isListItem(node) && !!findItemPrefixes(node).taskListPrefix;
	const isTaskList = (node) => node.type === "list" && node.children.some((child) => isTaskListItem(child));
	const getSelectionTypeFromListSelection = (selection) => {
		const parentList = selection.list;
		const types = /* @__PURE__ */ new Set();
		for (const item of selection.selectedItems) {
			if (isTaskListItem(item)) types.add("task");
			else types.add(parentList.ordered ? "ordered" : "unordered");
			if (types.size > 1) return null;
		}
		return types.values().next().value ?? null;
	};
	const getSelectionListTypeFromContext = (selectionContext) => {
		for (let index = selectionContext.length - 1; index >= 0; index -= 1) {
			const node = selectionContext[index];
			if (!node || node.type !== "listItem") continue;
			if (isTaskListItem(node)) return "task";
			const rawPrefix = findItemPrefixes(node).listItemPrefix?.raw ?? "";
			return /^\s*(?:\d+\.|\d+\))/u.test(rawPrefix) ? "ordered" : "unordered";
		}
		return null;
	};
	const listSelection = view ? getListSelection(view.state) : null;
	const resolveListIsPressed = (targetType) => (selectionContext, defaultPressed) => {
		const selectionListType = getSelectionListTypeFromContext(selectionContext) ?? (listSelection ? getSelectionTypeFromListSelection(listSelection) : null);
		if (!defaultPressed) return false;
		if (!selectionListType) return false;
		return selectionListType === targetType;
	};
	return /* @__PURE__ */ jsx("div", {
		className: clsx(Toolbar_module_default.container, toolbarRedesignEnabled && Toolbar_module_default.leftAligned),
		children: /* @__PURE__ */ jsx(ActionBar, {
			"aria-label": "Formatting tools",
			className: Toolbar_module_default.actionBar,
			gap: "none",
			children: /* @__PURE__ */ jsxs(ToolbarContext, {
				value: {
					view,
					selectedNodes
				},
				children: [
					customButtons,
					!!customButtons && /* @__PURE__ */ jsx(ActionBar.Divider, {}),
					/* @__PURE__ */ jsx(ToolbarButton, {
						"aria-label": "Bold",
						icon: BoldIcon,
						command: formatBoldKeybinding,
						telemetryId: "bold",
						matchingNodeFilter: (n) => n.type === "strong"
					}),
					/* @__PURE__ */ jsx(ToolbarButton, {
						"aria-label": "Italic",
						icon: ItalicIcon,
						command: formatItalicKeybinding,
						telemetryId: "italic",
						matchingNodeFilter: (n) => n.type === "emphasis"
					}),
					/* @__PURE__ */ jsx(ToolbarButton, {
						"aria-label": "Link",
						icon: LinkIcon,
						command: formatLinkKeybinding,
						telemetryId: "link",
						matchingNodeFilter: (n) => n.type === "link" && isLabeledLink(n)
					}),
					/* @__PURE__ */ jsx(ToolbarButton, {
						"aria-label": "Code",
						icon: CodeIcon,
						command: formatInlineCodeKeybinding,
						telemetryId: "inline_code",
						matchingNodeFilter: (n) => n.type === "inlineCode"
					}),
					/* @__PURE__ */ jsx(ToolbarButton, {
						"aria-label": "Quote",
						icon: QuoteIcon,
						command: formatBlockquoteKeybinding,
						telemetryId: "blockquote",
						matchingNodeFilter: (n) => n.type === "blockquote"
					}),
					/* @__PURE__ */ jsxs(ActionBar.Group, { children: [
						/* @__PURE__ */ jsx(ActionBar.Divider, {}),
						/* @__PURE__ */ jsx(ToolbarButton, {
							"aria-label": "Unordered list",
							icon: ListUnorderedIcon,
							command: formatUnorderedListKeybinding,
							telemetryId: "unordered_list",
							matchingNodeFilter: (n) => n.type === "list" && !n.ordered && !isTaskList(n),
							resolveIsPressed: resolveListIsPressed("unordered")
						}),
						/* @__PURE__ */ jsx(ToolbarButton, {
							"aria-label": "Ordered list",
							icon: ListOrderedIcon,
							command: formatOrderedListKeybinding,
							telemetryId: "ordered_list",
							matchingNodeFilter: (n) => n.type === "list" && !!n.ordered && !isTaskList(n),
							resolveIsPressed: resolveListIsPressed("ordered")
						}),
						/* @__PURE__ */ jsx(ToolbarButton, {
							"aria-label": "Task list",
							icon: TasklistIcon,
							command: formatTaskListKeybinding,
							telemetryId: "task_list",
							matchingNodeFilter: (n) => isTaskListItem(n),
							resolveIsPressed: resolveListIsPressed("task")
						})
					] }),
					/* @__PURE__ */ jsx(ActionBar.Divider, {}),
					fileUploadButton,
					/* @__PURE__ */ jsxs(ActionBar.Group, { children: [
						/* @__PURE__ */ jsx(ToolbarButton, {
							"aria-label": "Code block",
							icon: CodeSquareIcon,
							command: formatCodeBlock,
							telemetryId: "code_block",
							matchingNodeFilter: (n) => n.type === "code"
						}),
						/* @__PURE__ */ jsx(HeadingMenu, {}),
						/* @__PURE__ */ jsx(ToolbarButton, {
							"aria-label": "Strikethrough",
							icon: StrikethroughIcon,
							command: formatStrikethroughKeybinding,
							telemetryId: "strikethrough",
							matchingNodeFilter: (n) => n.type === "delete"
						})
					] })
				]
			})
		})
	});
};
Toolbar.displayName = "Toolbar";
Toolbar.displayName = "HybridMarkdownEditor.Toolbar";
var CRC_WIDTH = 4;
/**
* Utility class for parsing PNG file headers
* Extracts metadata like IHDR (dimensions) and pHYs (DPI information)
*/
var PNGScanner = class {
	dataview;
	pos;
	constructor(buffer) {
		this.dataview = new DataView(buffer);
		this.pos = 0;
	}
	advance(bytes) {
		this.pos += bytes;
	}
	readInt(bytes) {
		const value = (() => {
			switch (bytes) {
				case 1: return this.dataview.getUint8(this.pos);
				case 2: return this.dataview.getUint16(this.pos);
				case 4: return this.dataview.getUint32(this.pos);
				default: throw new Error("bytes parameter must be 1, 2 or 4");
			}
		})();
		this.advance(bytes);
		return value;
	}
	readChar() {
		return this.readInt(1);
	}
	readShort() {
		return this.readInt(2);
	}
	readLong() {
		return this.readInt(4);
	}
	readString(length) {
		const bytes = new Uint8Array(this.dataview.buffer, this.pos, length);
		this.advance(length);
		return new TextDecoder("ascii").decode(bytes);
	}
	scan(fn) {
		const expectedSignature = [
			137,
			80,
			78,
			71,
			13,
			10,
			26,
			10
		];
		for (let i = 0; i < expectedSignature.length; i++) if (this.dataview.getUint8(this.pos + i) !== expectedSignature[i]) throw new Error("Invalid PNG file: header signature mismatch");
		this.advance(8);
		while (this.pos < this.dataview.byteLength) {
			const len = this.readLong();
			const type = this.readString(4);
			const resumeAt = this.pos + len + CRC_WIDTH;
			if (fn.call(this, type, len) === false || type === "IEND") break;
			this.pos = resumeAt;
		}
	}
};
var METERS_PER_INCH = .0254;
/**
* Parse PNG image data to extract dimensions and DPI information
*/
var getImageDimensions = (imgData) => {
	const scanner = new PNGScanner(imgData);
	const meta = {
		width: 0,
		height: 0,
		pixelsPerInch: 72
	};
	scanner.scan(function(type) {
		switch (type) {
			case "IHDR":
				meta.width = this.readLong();
				meta.height = this.readLong();
				return true;
			case "pHYs": {
				const ppuX = this.readLong();
				const ppuY = this.readLong();
				const unit = this.readChar();
				let inchesRatio = void 0;
				if (unit === 1) {
					inchesRatio = METERS_PER_INCH;
					meta.pixelsPerInch = Math.round((ppuX + ppuY) / 2 * inchesRatio);
				}
				return false;
			}
			case "IDAT": return false;
		}
		return true;
	});
	return meta;
};
/**
* Extract image dimensions from a File object by reading and parsing its PNG header
* Returns null if the file cannot be parsed as PNG
*/
var getImageSizeFromFile = async (file) => {
	const imgResult = await new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(reader.result);
		reader.onerror = () => reject(reader.error);
		reader.readAsArrayBuffer(file);
	});
	return imgResult ? getImageDimensions(imgResult) : null;
};
var use_reference_suggestions_module_default = { suggestionTitle: "use-reference-suggestions-module_4dnC7a_suggestionTitle" };
var trigger = {
	triggerChar: "#",
	multiWord: true
};
var referenceToSuggestion = (reference) => ({
	value: reference.id,
	render: (props) => /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		children: [
			reference.iconHtml && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(UnsafeHTMLText, { html: reference.iconHtml }) }),
			/* @__PURE__ */ jsx("span", {
				className: use_reference_suggestions_module_default.suggestionTitle,
				children: /* @__PURE__ */ jsx(UnsafeHTMLText, { html: reference.titleHtml })
			}),
			" ",
			/* @__PURE__ */ jsxs(ActionList.Description, {
				truncate: true,
				children: ["#", reference.id]
			})
		]
	})
});
var scoreSuggestion = (query, reference) => {
	return fuzzyScore(query, `${reference.id} ${reference.titleText}`);
};
var tieBreaker = (_referenceOne, _referenceTwo) => {
	return 0;
};
var useReferenceSuggestions = (references) => {
	const $ = c$1(4);
	let t0;
	if ($[0] !== references) {
		const calculator = suggestionsCalculator(references, scoreSuggestion, tieBreaker, referenceToSuggestion);
		t0 = (query) => {
			if (/^\d+\s/.test(query)) return [];
			return calculator(query);
		};
		$[0] = references;
		$[1] = t0;
	} else t0 = $[1];
	const calculateSuggestions = t0;
	let t1;
	if ($[2] !== calculateSuggestions) {
		t1 = {
			calculateSuggestions,
			trigger
		};
		$[2] = calculateSuggestions;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
export { htmlTreeChanged as A, markdownParserExtension as B, getNodeAtOffset as C, getTextContent as D, getNodesOverlappingRange as E, isTag as F, selectionContextExtension as G, overlapsNode as H, isUrl as I, useReferenceSuggestions as J, setsEqual as K, linkParentNodeTypes as L, inlineFormattingNodeTypes as M, isChecked as N, hasNonEmptySelection as O, isPositionedNode as P, markdownContinuationExtension as R, getNewlineSuffix as S, getNodesInsideRange as T, parseTasklistPrefix as U, nodesEqual as V, selectionContextChanged as W, getHtmlTree as _, Header as a, getMarkdownTree as b, Toolbar as c, buildToggledTasklistPrefixSyntax as d, feedbackUrl as f, getDelimiterType as g, getCurrentSelectionContext as h, FileUploadButton as i, initialSelectionContext as j, hastPropertiesToHtmlAttributes as k, ToolbarContext as l, getAccurateCaretCoords as m, ErrorBanner as n, HybridEditorTelemetryProvider as o, findWordBoundaries as p, useHybridEditorTelemetry as q, ErrorFallback as r, HybridMarkdownEditor_module_default as s, AriaAlert as t, ViewSwitch as u, getImageSizeFromFile as v, getNodesContainingRange as w, getNewlinePrefix as x, getLineRanges as y, markdownKeymapExtension as z };
