performance.mark("js-parse-end:server-analytics-urls-r5iI1mtO-VQgg5ZK0.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as serverConfig } from "./server-config-fAGtGEuQ-g7WI1iQy.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
performance.mark("js-parse-end:analytics-urls-r5iI1mtO.js");
var getAnalyticsUrlsHandler = () => {
	return {
		browserErrorsUrl: serverConfig.browserErrorsUrl,
		browserStatsUrl: serverConfig.browserStatsUrl,
		hydroCollectorUrl: serverConfig.hydroCollectorUrl
	};
};
var getAnalyticsUrls_createServerFn_handler = createServerRpc({
	id: "86c3f6715a2dcfc16d0d89f8f78e0fc935ce178e210cd08d3372ad8b8073efa1",
	name: "getAnalyticsUrls",
	filename: "src/routes/root/analytics-urls.ts"
}, (opts) => getAnalyticsUrls.__executeServer(opts));
var getAnalyticsUrls = createServerFn().handler(getAnalyticsUrls_createServerFn_handler, getAnalyticsUrlsHandler);
export { getAnalyticsUrls_createServerFn_handler };
