import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { B as CircleSlashIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as useResizeObserver } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { a as SelectPanel } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { n as isEditableElement } from "./server-keyboard-shortcuts-helper-BRqP2m0f-DOsDhPIe.js";
import { a as GlobalCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { t as FeatureFlags } from "./server-FeatureFlags-C1NipJFp-82e1Xac8.js";
import { createContext, use, useCallback, useDeferredValue, useEffect, useEffectEvent, useId, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var ModifierKeys = {
	ctrlKey: "ctrlKey",
	altKey: "altKey",
	shiftKey: "shiftKey",
	metaKey: "metaKey"
};
var useKeyPress = (keys, callback, options) => {
	const $ = c(9);
	let t0;
	if ($[0] !== callback || $[1] !== keys || $[2] !== options) {
		t0 = (event) => {
			const keyboardEvent = event;
			const currentKeys = keys;
			const currentOptions = options;
			if (!currentKeys.some((key) => {
				if (/^\d$/.test(key)) return keyboardEvent.code === `Digit${key}`;
				if (key === "/") return keyboardEvent.code === "Slash";
				return keyboardEvent.key === key;
			})) return;
			if (!checkModifierKeys(keyboardEvent, currentOptions) && !currentOptions?.ignoreModifierKeys) return;
			if (!currentOptions?.triggerWhenInputElementHasFocus && isEditableElement(event.target)) return;
			if (!currentOptions?.triggerWhenPortalIsActive && isPortalActive()) return;
			callback(keyboardEvent);
		};
		$[0] = callback;
		$[1] = keys;
		$[2] = options;
		$[3] = t0;
	} else t0 = $[3];
	const handleKeyPress = useEffectEvent(t0);
	const scopeRef = options?.scopeRef;
	let t1;
	if ($[4] !== handleKeyPress || $[5] !== scopeRef?.current) {
		t1 = () => {
			const targetElement = scopeRef?.current || document;
			targetElement.addEventListener("keydown", handleKeyPress);
			return () => targetElement.removeEventListener("keydown", handleKeyPress);
		};
		$[4] = handleKeyPress;
		$[5] = scopeRef?.current;
		$[6] = t1;
	} else t1 = $[6];
	let t2;
	if ($[7] !== scopeRef) {
		t2 = [scopeRef];
		$[7] = scopeRef;
		$[8] = t2;
	} else t2 = $[8];
	useEffect(t1, t2);
};
var portalSelectors = "#__primerPortalRoot__, [id$=\"-portal-root\"]";
function isPortalActive() {
	return [...document.querySelectorAll(portalSelectors)].some(elementHasNonZeroHeight);
}
function elementHasNonZeroHeight(element) {
	if (element.clientHeight > 0) return true;
	for (const child of element.children) if (elementHasNonZeroHeight(child)) return true;
	return false;
}
function checkModifierKeys(keyboardEvent, options) {
	for (const key of Object.values(ModifierKeys)) {
		if (options && options[key] && !keyboardEvent[key]) return false;
		if (keyboardEvent[key] && (!options || !options[key])) return false;
	}
	return true;
}
var IDS = {
	itemPickerRootId: "item-picker-root-id",
	itemPickerTestId: "item-picker-root"
};
var SELECTORS = { activePickerOption: (rootId) => `[data-id="${rootId}"] [data-is-active-descendant="activated-directly"]` };
var ItemPickersContext = createContext({
	updateOpenState: () => void 0,
	anyItemPickerOpen: () => false
});
ItemPickersContext.displayName = "ItemPickersContext";
function ItemPickersContextProvider({ children }) {
	const itemPickerOpenStates = useRef({});
	const updateOpenState = useCallback((id, isOpen) => {
		const previousState = itemPickerOpenStates.current;
		if (previousState[id] === isOpen) return itemPickerOpenStates.current;
		itemPickerOpenStates.current = {
			...previousState,
			[id]: isOpen
		};
		return itemPickerOpenStates.current;
	}, []);
	const anyItemPickerOpen = useCallback(() => {
		return Object.values(itemPickerOpenStates.current).some((s) => s);
	}, [itemPickerOpenStates]);
	return /* @__PURE__ */ jsx(ItemPickersContext, {
		value: useMemo(() => {
			return {
				updateOpenState,
				anyItemPickerOpen
			};
		}, [anyItemPickerOpen, updateOpenState]),
		children
	});
}
ItemPickersContextProvider.displayName = "ItemPickersContextProvider";
function useItemPickersContext() {
	const context = use(ItemPickersContext);
	if (!context) throw new Error("useItemPickersContext must be used within a ItemPickersContextProvider.");
	return context;
}
var ERRORS = {
	couldNotUpdateAssignees: "Could not update assignees",
	couldNotSearchAssignees: "Could not search assignees",
	couldNotUpdateLabels: "Could not update labels",
	couldNotSearchLabels: "Could not search labels",
	couldNotUpdateMilestone: "Could not update milestone",
	couldNotUpdateType: "Could not update type",
	couldNotSearchMilestones: "Could not search milestones",
	couldNotUpdateIssueType: "Could not update issue type",
	couldNotSearchRepositories: "Could not search repositories",
	couldNotSearchPullRequests: "Could not search pull requests",
	couldNotSearchProjects: "Could not search projects",
	couldNotSearchBranches: "Could not search branches",
	noMatches: "No matches",
	noResults: "No results",
	couldNotCreateBranch: "Could not create branch",
	couldNotCreateLabel: "Could not create label",
	couldNotCreateMilestone: "Could not create milestone",
	branchAlreadyExists: (branchName) => `The branch ${branchName} already exists.`
};
var noMatchesItem = {
	leadingVisual: CircleSlashIcon,
	text: ERRORS.noMatches,
	disabled: true,
	selected: void 0,
	key: "no-matches",
	id: "no-matches"
};
var noResultsItem = {
	leadingVisual: CircleSlashIcon,
	text: ERRORS.noResults,
	disabled: true,
	selected: void 0,
	key: "no-results",
	id: "no-results"
};
var maybeIssueUrl = (url) => {
	try {
		new URL(url);
	} catch {
		return false;
	}
	return (/* @__PURE__ */ new RegExp(/^.+\/issues\/\d+$/)).test(url);
};
var maybePullRequestUrl = (url) => {
	try {
		new URL(url);
	} catch {
		return false;
	}
	return (/* @__PURE__ */ new RegExp(/^.+\/pull\/\d+$/)).test(url);
};
var getIssueSearchQueries = (owner = "", query = "", repoNameWithOwner = "") => {
	const ownerPart = owner && `owner:${owner.trim()} `;
	const repoPart = repoNameWithOwner && `repo:${repoNameWithOwner.trim()} `;
	const queryPart = query && `${query.trim()}`;
	const issuePart = "is:issue ";
	const queryIsUrl = maybeIssueUrl(query);
	let inPart = "in:title";
	const maybeNumber = queryPart && queryPart.charAt(0) === "#" ? queryPart.slice(1) : queryPart;
	if (maybeNumber && !isNaN(Number(maybeNumber))) inPart += " in:number";
	const sharedQuery = `${ownerPart}${repoPart}${issuePart}${inPart}`;
	return {
		commenters: `${sharedQuery} commenter:@me ${queryPart}`.trim(),
		mentions: `${sharedQuery} mentions:@me ${queryPart}`.trim(),
		assignee: `${sharedQuery} assignee:@me ${queryPart}`.trim(),
		author: `${sharedQuery} author:@me ${queryPart}`.trim(),
		other: `${sharedQuery} ${queryPart}`.trim(),
		resource: queryIsUrl ? encodeURI(query) : "",
		queryIsUrl
	};
};
function ItemPicker({ items, initialSelectedItems, placeholderText, selectionVariant = "single", loading, groups, filterItems, renderAnchor, getItemKey, convertToItemProps, onSelectionChange, onOpen, onClose, onLiveSelectionChange, eventsTag, height = "small", width = "small", selectPanelRef, enforceAtleastOneSelected, insidePortal, maxVisibleItems = 9, nested = false, resultListAriaLabel, title, subtitle, preventClose, triggerOpen, initialFilter, customNoResultsItem, customNoMatchItem, footer, keybindingCommandId, pickerId, responsiveOnNarrow, secondaryAction, notice, className, improvedNoMatchAccessibility, noMatchMessage, suppressNoMatchItem, focusPrependedElements, anchorSide, portalContainerName, overlayPosition }) {
	const [open, _setOpen] = useState(triggerOpen ?? false);
	const [pickerOpenedTimeStamp, setPickerOpenedTimeStamp] = useState(() => open ? Date.now() : null);
	const [selected, setSelected] = useState([]);
	const [filter, setFilter] = useState(initialFilter ?? "");
	const deferredFilter = useDeferredValue(filter);
	const { updateOpenState, anyItemPickerOpen } = useItemPickersContext();
	const [isNarrow, setIsNarrow] = useState(false);
	let id = useId();
	if (pickerId) id = pickerId;
	const responsiveOnNarrowEnabled = responsiveOnNarrow || isFeatureEnabled("primer_react_select_panel_fullscreen_on_narrow");
	useResizeObserver(() => {
		setIsNarrow(window.innerWidth < 768);
	});
	const setOpen = useCallback((value) => {
		_setOpen(value);
		if (value) setPickerOpenedTimeStamp(Date.now());
		else setPickerOpenedTimeStamp(null);
	}, [_setOpen]);
	useEffect(() => {
		if (triggerOpen !== void 0) setOpen(triggerOpen);
	}, [setOpen, triggerOpen]);
	const handleKeyDown = useCallback(() => {
		if (anyItemPickerOpen() || open) return;
		setOpen(true);
		if (onOpen) onOpen();
	}, [
		anyItemPickerOpen,
		open,
		setOpen,
		onOpen
	]);
	useEffect(() => {
		updateOpenState(id, open);
	}, [
		id,
		open,
		updateOpenState
	]);
	const isLiveMultipleSelection = selectionVariant === "multiple" && !!onLiveSelectionChange;
	const openRef = useRef(open);
	openRef.current = open;
	const map = useMemo(() => /* @__PURE__ */ new Map(), [id, isLiveMultipleSelection ? void 0 : initialSelectedItems]);
	const wrappedGetItemKey = useCallback((item) => typeof item === "string" ? item : getItemKey(item), [getItemKey]);
	useEffect(() => {
		if (isLiveMultipleSelection) {
			const selectedKeys = new Set(initialSelectedItems.map(wrappedGetItemKey));
			let hasChanges = false;
			for (const [key, itemProps] of map.entries()) {
				const shouldBeSelected = selectedKeys.has(key);
				if (itemProps.selected !== shouldBeSelected) {
					hasChanges = true;
					break;
				}
			}
			if (!hasChanges) return;
			for (const [key, itemProps] of map.entries()) {
				const shouldBeSelected = selectedKeys.has(key);
				if (itemProps.selected !== shouldBeSelected) itemProps.selected = shouldBeSelected;
			}
		}
	}, [
		initialSelectedItems,
		map,
		isLiveMultipleSelection,
		wrappedGetItemKey
	]);
	const deselectOthers = useCallback((exclude) => {
		for (const [, value] of map) if (value !== exclude) value.selected = false;
	}, [map]);
	const cleanupUnselectedItems = useCallback(() => {
		if (isLiveMultipleSelection) {
			for (const [key, itemProps] of map.entries()) if (!itemProps.selected) map.delete(key);
		}
	}, [isLiveMultipleSelection, map]);
	const onOpenChange = useCallback((isOpen, gesture) => {
		if (preventClose && !isOpen) return;
		if (gesture === "cancel") return;
		if (!isOpen && document.activeElement instanceof HTMLElement) document.activeElement?.blur();
		setOpen(isOpen);
		if (isOpen && onOpen) {
			onOpen();
			return;
		}
		setFilter("");
		if (onClose) onClose();
		const selectedItems = [...map.values()].filter((i) => i.selected).map((i) => i.source);
		if (selectedItems.length !== initialSelectedItems.length || selectedItems.some((item) => !initialSelectedItems.some((item2) => wrappedGetItemKey(item2) === getItemKey(item)))) {
			if (pickerOpenedTimeStamp && eventsTag) {
				const selectionDuration = Date.now() - pickerOpenedTimeStamp;
				const addedItemsCount = selectedItems.filter((item) => !initialSelectedItems.some((item2) => wrappedGetItemKey(item2) === getItemKey(item))).length;
				const removedItemsCount = initialSelectedItems.filter((item) => !selectedItems.some((item2) => wrappedGetItemKey(item2) === getItemKey(item))).length;
				sendEvent(`item-picker-${eventsTag}-selection-duration`, {
					selectionDuration,
					totalItemsCount: selectedItems.length,
					addedItemsCount,
					removedItemsCount
				});
			}
			onSelectionChange(selectedItems);
		}
		cleanupUnselectedItems();
	}, [
		preventClose,
		setOpen,
		onOpen,
		cleanupUnselectedItems,
		onClose,
		map,
		initialSelectedItems,
		wrappedGetItemKey,
		getItemKey,
		pickerOpenedTimeStamp,
		eventsTag,
		onSelectionChange
	]);
	/**
	* Handles selection for nested pickers, mirrors onSpaceKeyPress by skipping the default onSelectedChange
	* and preventing the OverflowMenu from auto-closing when an item is selected.
	*/
	const toItemProps = useCallback((item, itemSelected) => {
		const itemKey = getItemKey(item);
		let itemProps = map.get(itemKey);
		const parentItemProps = convertToItemProps(item);
		if (itemProps) {
			if (isLiveMultipleSelection && !openRef.current) itemProps.selected = itemSelected;
			return {
				...itemProps,
				disabled: parentItemProps.disabled
			};
		}
		itemProps = parentItemProps;
		itemProps.selected = itemSelected;
		const onAction = itemProps.onAction;
		itemProps.onAction = (props, event) => {
			const i = map.get(itemKey);
			if (!i) return;
			i.selected = !i.selected;
			if (selectionVariant === "single" && item.id !== filter) deselectOthers(i);
			if (onAction) onAction(props, event);
		};
		map.set(itemKey, itemProps);
		return itemProps;
	}, [
		convertToItemProps,
		filter,
		getItemKey,
		map,
		selectionVariant,
		deselectOthers,
		isLiveMultipleSelection
	]);
	const selectPanelItems = useMemo(() => {
		const itemProps = items.map((i) => {
			if (i.__isNew__) {
				delete i.__isNew__;
				if (customNoMatchItem) map.delete(getItemKey(customNoMatchItem));
				return toItemProps(i, true);
			}
			return toItemProps(i, initialSelectedItems.some((is) => wrappedGetItemKey(is) === getItemKey(i)));
		});
		if (itemProps.length === 0) {
			if (improvedNoMatchAccessibility) return [];
			if (customNoMatchItem) return [toItemProps(customNoMatchItem, false)];
			if (suppressNoMatchItem) return [];
			return filter ? [customNoMatchItem ? toItemProps(customNoMatchItem, false) : noMatchesItem] : [customNoResultsItem ?? noResultsItem];
		}
		return itemProps;
	}, [
		customNoMatchItem,
		items,
		map,
		toItemProps,
		initialSelectedItems,
		wrappedGetItemKey,
		getItemKey,
		filter,
		customNoResultsItem,
		improvedNoMatchAccessibility,
		suppressNoMatchItem
	]);
	useEffect(() => {
		setSelected(selectPanelItems.filter((i) => i.selected));
	}, [selectPanelItems]);
	const selectPanelSelectedItems = useMemo(() => {
		if (selectionVariant === "single") return selected[0];
		else return selected;
	}, [selected, selectionVariant]);
	const onSelectedChange = useCallback((param) => {
		if (param === void 0) {
			if (!enforceAtleastOneSelected) setSelected([]);
			return;
		}
		const newSelection = (Array.isArray(param) ? param : [param]).map((i) => selectPanelItems.find((item) => i.id === item.id)).filter((i) => i !== void 0);
		if (isLiveMultipleSelection) {
			const alreadySelectedItemsButNotInItems = initialSelectedItems.filter((i) => !items.some((item) => wrappedGetItemKey(i) === wrappedGetItemKey(item))).map((item) => map.get(wrappedGetItemKey(item))).filter((i) => i !== void 0);
			newSelection.push(...alreadySelectedItemsButNotInItems);
		}
		setSelected(newSelection);
		if (isLiveMultipleSelection) onLiveSelectionChange(newSelection.map((i) => i.source));
	}, [
		isLiveMultipleSelection,
		onLiveSelectionChange,
		enforceAtleastOneSelected,
		selectPanelItems,
		initialSelectedItems,
		items,
		wrappedGetItemKey,
		map
	]);
	const onSpaceKeyPress = (event) => {
		if (open) {
			const activeOption = document.querySelector(SELECTORS.activePickerOption(IDS.itemPickerRootId));
			if (activeOption) {
				const activeDataId = activeOption.getAttribute("data-id");
				const item = [...map.values()].find((i) => i.id === activeDataId);
				if (item) {
					if (convertToItemProps(item.source).disabled) return;
					event.preventDefault();
					event.stopPropagation();
					item.selected = !item.selected;
					setSelected([...map.values()].filter((i) => i.selected));
					if (isLiveMultipleSelection) onLiveSelectionChange([...map.values()].filter((i) => i.selected).map((i) => i.source));
				}
			}
		}
	};
	useKeyPress([" "], onSpaceKeyPress, {
		triggerWhenInputElementHasFocus: true,
		triggerWhenPortalIsActive: true
	});
	const onCancel = useCallback(() => {
		if (preventClose) return;
		setFilter("");
		const selectedItems = [...map.values()].filter((i) => i.selected).map((i) => i.source);
		if (selectedItems.length !== initialSelectedItems.length || selectedItems.some((item) => !initialSelectedItems.some((item2) => wrappedGetItemKey(item2) === getItemKey(item)))) {
			for (const i of map.values()) if (initialSelectedItems.some((item) => wrappedGetItemKey(item) === getItemKey(i.source))) i.selected = true;
			else i.selected = false;
			setSelected([...map.values()].filter((i) => i.selected));
		}
		setOpen(false);
		if (onClose) onClose();
		cleanupUnselectedItems();
	}, [
		preventClose,
		map,
		initialSelectedItems,
		cleanupUnselectedItems,
		setOpen,
		onClose,
		wrappedGetItemKey,
		getItemKey
	]);
	useEffect(() => {
		filterItems(deferredFilter);
	}, [deferredFilter, filterItems]);
	let hasItems = selectPanelItems.length > 0;
	if (selectPanelItems.length === 1 && (selectPanelItems[0].id === noMatchesItem.id || selectPanelItems[0].id === noResultsItem.id)) hasItems = false;
	const groupMetadataProp = useMemo(() => groups && groups?.length > 1 && hasItems ? { groupMetadata: groups } : {}, [groups, hasItems]);
	const regularHeight = selectPanelItems.length <= maxVisibleItems ? "auto" : height;
	const adjustedOverlayProps = useMemo(() => getAdjustedOverlayProps(insidePortal, selectPanelRef, regularHeight, isNarrow && responsiveOnNarrowEnabled, open), [
		insidePortal,
		selectPanelRef,
		regularHeight,
		isNarrow,
		responsiveOnNarrowEnabled,
		open
	]);
	const message = useMemo(() => noMatchMessage ? noMatchMessage : filter ? {
		variant: "empty",
		title: "No matches found",
		body: "Try a different search term"
	} : {
		variant: "empty",
		title: "No items to show",
		body: ""
	}, [noMatchMessage, filter]);
	const selectPanelProps = useMemo(() => ({
		renderAnchor,
		placeholderText,
		open,
		onOpenChange,
		loading,
		items: selectPanelItems,
		selected: selectPanelSelectedItems,
		onSelectedChange,
		filterValue: filter,
		onFilterChange: setFilter,
		showItemDividers: true,
		overlayProps: {
			width,
			className,
			anchorSide,
			portalContainerName,
			...overlayPosition ? { position: overlayPosition } : {},
			...adjustedOverlayProps
		},
		...groupMetadataProp,
		"aria-label": resultListAriaLabel,
		"data-id": IDS.itemPickerRootId,
		"data-testid": IDS.itemPickerTestId,
		title,
		subtitle,
		footer,
		onCancel,
		secondaryAction,
		notice,
		message: improvedNoMatchAccessibility && selectPanelItems.length === 0 ? message : void 0,
		focusPrependedElements,
		scrollBehavior: "instant"
	}), [
		renderAnchor,
		placeholderText,
		open,
		onOpenChange,
		loading,
		selectPanelItems,
		selectPanelSelectedItems,
		onSelectedChange,
		filter,
		width,
		adjustedOverlayProps,
		groupMetadataProp,
		resultListAriaLabel,
		title,
		subtitle,
		footer,
		message,
		onCancel,
		secondaryAction,
		notice,
		className,
		improvedNoMatchAccessibility,
		focusPrependedElements,
		anchorSide,
		portalContainerName,
		overlayPosition
	]);
	return /* @__PURE__ */ jsxs(FeatureFlags, {
		flags: { primer_react_select_panel_fullscreen_on_narrow: footer === void 0 && responsiveOnNarrowEnabled },
		children: [keybindingCommandId && /* @__PURE__ */ jsx(GlobalCommands, { commands: { [keybindingCommandId]: handleKeyDown } }), /* @__PURE__ */ jsx(SelectPanel, {
			anchorRef: nested ? void 0 : selectPanelRef,
			...selectPanelProps
		})]
	});
}
/**
* When `insidePortal` is true, such as with the Create Issue dialog,
* the SelectPanel sometimes gets rendered below the buttons and cut off by the viewport.
* To fix this, we:
* - set a fixed height (`large`, 432px) for the SelectPanel.
* - set the position to `fixed` to handle scrolling and varied portal positions.
* - overwrite the `top` value to the `top` of its anchor button minus the height of the SelectPanel and some padding (4px).
* This will force the SelectPanel to always be rendered just above the buttons and be accessible within the viewport.
*
* Note: This is a workaround that doesn't require fixing the Primer components/behaviors themselves.
* If this gets fixed in Primer, we can remove it.
* Ref: https://github.com/github/primer/issues/4027
*/
ItemPicker.displayName = "ItemPicker";
function getAdjustedOverlayProps(insidePortal, ref, regularHeight, isFullScreen = false, open = false) {
	const height = insidePortal ? "large" : regularHeight;
	if (!insidePortal || !ref?.current || !open) return { height };
	const { top: buttonTop } = ref.current.getBoundingClientRect();
	const top = isFullScreen ? 0 : buttonTop - 436;
	if (top < 0) return { height };
	return {
		height,
		top,
		position: "fixed"
	};
}
export { SELECTORS as a, maybePullRequestUrl as c, ItemPickersContextProvider as i, useItemPickersContext as l, IDS as n, getAdjustedOverlayProps as o, ItemPicker as r, getIssueSearchQueries as s, ERRORS as t, useKeyPress as u };
