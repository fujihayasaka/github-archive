/** Type guard: true when the ask_user prompt uses the elicitation/schema format */
function isElicitationAskUser(args) {
	return "requestedSchema" in args && !!args.requestedSchema && typeof args.requestedSchema === "object" && !!args.requestedSchema.properties && Object.keys(args.requestedSchema.properties).length > 0;
}
/** Set of interactive prompt tool names for runtime checks */
var INTERACTIVE_PROMPT_TOOL_NAMES = new Set([
	"ask_user",
	"exit_plan_mode",
	"permission_request"
]);
function isCompletionChunk(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null) return false;
	return "choices" in logEntry && Array.isArray(logEntry.choices);
}
function isCommandGroup(logEntry) {
	return Array.isArray(logEntry) && logEntry.every((entry) => isCommandMessage(entry));
}
function isCommandMessage(logEntry) {
	return isCompletionUserMessage(logEntry) && "source" in logEntry;
}
function isCompletionUserMessage(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null) return false;
	return "role" in logEntry && logEntry.role === "user";
}
function isCompletionToolMessage(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null) return false;
	return "role" in logEntry && logEntry.role === "tool";
}
function isChatMessage(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null || logEntry === void 0) return false;
	return "role" in logEntry && (logEntry.role === "user" || logEntry.role === "assistant") && "threadID" in logEntry;
}
function isToolUserRequestedMessage(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null) return false;
	if (!("type" in logEntry) || logEntry.type !== "tool.user_requested") return false;
	if (!("toolCallId" in logEntry) || typeof logEntry.toolCallId !== "string") return false;
	if (!("toolName" in logEntry) || typeof logEntry.toolName !== "string") return false;
	if (!("arguments" in logEntry) || typeof logEntry.arguments !== "object") return false;
	if (!("timestamp" in logEntry) || typeof logEntry.timestamp !== "string") return false;
	return true;
}
function isToolExecutionStartMessage(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null) return false;
	if (!("type" in logEntry) || logEntry.type !== "tool.execution_start") return false;
	if (!("id" in logEntry) || typeof logEntry.id !== "string") return false;
	if (!("timestamp" in logEntry) || typeof logEntry.timestamp !== "string") return false;
	if (!("data" in logEntry) || typeof logEntry.data !== "object" || logEntry.data === null) return false;
	const data = logEntry.data;
	if (typeof data.toolCallId !== "string" || typeof data.toolName !== "string") return false;
	return true;
}
function isToolOutputsMessage(logEntry) {
	if (typeof logEntry !== "object" || logEntry === null) return false;
	if (!("type" in logEntry) || logEntry.type !== "tool.outputs") return false;
	if (!("toolCallId" in logEntry) || typeof logEntry.toolCallId !== "string") return false;
	if (!("output" in logEntry) || typeof logEntry.output !== "string") return false;
	if (!("timestamp" in logEntry) || typeof logEntry.timestamp !== "string") return false;
	return true;
}
/**
* Type guard to validate AskUserArguments structure at runtime.
* Accepts both canonical (`question`) and CLI (`message` + `requestedSchema`) formats.
*/
function isAskUserArguments(args) {
	if (typeof args !== "object" || args === null) return false;
	const obj = args;
	if (typeof obj.message === "string" && obj.requestedSchema && typeof obj.requestedSchema === "object") {
		const schema = obj.requestedSchema;
		if (schema.properties && typeof schema.properties === "object" && Object.keys(schema.properties).length > 0) return true;
	}
	if (typeof obj.question === "string") {
		if (obj.choices !== void 0 && !Array.isArray(obj.choices)) return false;
		if (obj.allowFreeform !== void 0 && typeof obj.allowFreeform !== "boolean") return false;
		return true;
	}
	return false;
}
/**
* Type guard to validate ExitPlanModeArguments structure at runtime.
*/
function isExitPlanModeArguments(args) {
	if (typeof args !== "object" || args === null) return false;
	const obj = args;
	if (typeof obj.summary !== "string") return false;
	if (obj.actions !== void 0 && !Array.isArray(obj.actions)) return false;
	if (obj.recommendedAction !== void 0 && typeof obj.recommendedAction !== "string") return false;
	return true;
}
/**
* Type guard to validate PermissionRequestArguments structure at runtime.
*/
function isPermissionRequestArguments(args) {
	if (typeof args !== "object" || args === null) return false;
	const obj = args;
	if (typeof obj.kind !== "string") return false;
	if (obj.toolName !== void 0 && typeof obj.toolName !== "string") return false;
	if (obj.command !== void 0 && typeof obj.command !== "string") return false;
	if (obj.filePath !== void 0 && typeof obj.filePath !== "string") return false;
	if (obj.diff !== void 0 && typeof obj.diff !== "string") return false;
	if (obj.description !== void 0 && typeof obj.description !== "string") return false;
	return true;
}
function isValidLogEntry(message) {
	if (typeof message !== "object" || message === null) return false;
	return isCompletionChunk(message) || isCompletionUserMessage(message) || isCompletionToolMessage(message) || isToolUserRequestedMessage(message) || isToolExecutionStartMessage(message) || typeof message === "object";
}
function isReadonlyAgent(session) {
	if (!session) return false;
	return [
		946600,
		71,
		106,
		776,
		386,
		56
	].includes(session.agent_id);
}
var SessionState = {
	InProgress: "in_progress",
	Completed: "completed",
	Failed: "failed",
	Idle: "idle",
	WaitingForUser: "waiting_for_user",
	TimedOut: "timed_out",
	Cancelled: "cancelled",
	Queued: "queued"
};
var SESSION_STATES_SET = new Set(Object.values(SessionState));
function isSessionState(state) {
	return SESSION_STATES_SET.has(state);
}
function getReadableSessionState(state, options) {
	switch (state) {
		case SessionState.InProgress: return "In progress";
		case SessionState.Completed: return options?.hasPull ? "Ready for review" : "Completed";
		case SessionState.Failed: return "Failed";
		case SessionState.Idle: return "Idle";
		case SessionState.WaitingForUser: return "Waiting for user";
		case SessionState.TimedOut: return "Timed out";
		case SessionState.Cancelled: return "Cancelled";
		case SessionState.Queued: return "Queued";
		default: return "Unknown";
	}
}
function isActiveSession(session) {
	return ["queued", "in_progress"].includes(session.state);
}
function isCompletedSession(session) {
	return session.state === SessionState.Completed;
}
function isPendingSession(session) {
	return !!session.isPending && session.state === SessionState.Queued;
}
function isCancelledSession(session) {
	return session.state === SessionState.Cancelled;
}
function isFailedSession(session) {
	return session.state === SessionState.Failed;
}
export { isToolUserRequestedMessage as C, isToolOutputsMessage as S, isPendingSession as _, isAskUserArguments as a, isSessionState as b, isCommandGroup as c, isCompletionChunk as d, isCompletionToolMessage as f, isFailedSession as g, isExitPlanModeArguments as h, isActiveSession as i, isCommandMessage as l, isElicitationAskUser as m, SessionState as n, isCancelledSession as o, isCompletionUserMessage as p, getReadableSessionState as r, isChatMessage as s, INTERACTIVE_PROMPT_TOOL_NAMES as t, isCompletedSession as u, isPermissionRequestArguments as v, isValidLogEntry as w, isToolExecutionStartMessage as x, isReadonlyAgent as y };
