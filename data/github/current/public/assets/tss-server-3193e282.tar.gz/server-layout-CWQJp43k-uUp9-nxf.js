performance.mark("js-parse-end:server-layout-CWQJp43k-uUp9-nxf.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:layout-CWQJp43k.js");
var reposLayoutServerFn_createServerFn_handler = createServerRpc({
	id: "4049c22acbc78625404fbadcb7664ccb9e28a38a67961cbf52184858fa8188b8",
	name: "reposLayoutServerFn",
	filename: "src/routes/repos/layout.tsx"
}, (opts) => reposLayoutServerFn.__executeServer(opts));
var reposLayoutServerFn = createServerFn().inputValidator(queryValidator.base).handler(reposLayoutServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "reposFinderLayoutRoute");
});
export { reposLayoutServerFn_createServerFn_handler };
