import React from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var LatestCommitContext = React.createContext({
	latestCommit: void 0,
	error: null,
	isLoading: false
});
LatestCommitContext.displayName = "LatestCommitContext";
function LatestCommitProvider(t0) {
	const $ = c(7);
	const { children, latestCommit, error, isLoading } = t0;
	let t1;
	if ($[0] !== error || $[1] !== isLoading || $[2] !== latestCommit) {
		t1 = {
			latestCommit,
			error,
			isLoading
		};
		$[0] = error;
		$[1] = isLoading;
		$[2] = latestCommit;
		$[3] = t1;
	} else t1 = $[3];
	const value = t1;
	let t2;
	if ($[4] !== children || $[5] !== value) {
		t2 = jsx(LatestCommitContext, {
			value,
			children
		});
		$[4] = children;
		$[5] = value;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
LatestCommitProvider.displayName = "LatestCommitProvider";
function useLatestCommitContext() {
	return React.use(LatestCommitContext);
}
export { useLatestCommitContext as n, LatestCommitProvider as t };
