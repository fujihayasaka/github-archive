performance.mark("js-parse-end:server-BlobEditor-b_h3z-tU-Cb1RfzCf.js");
import { a as isFeatureEnabled, r as featureFlag } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Mi as XIcon, O as CheckIcon, On as MarkdownIcon, Qr as StopIcon, Sn as LinkIcon, U as CodeOfConductIcon, a as AlertFillIcon, an as IconButton, bn as Link, dr as Radio, en as HeartIcon, fr as RadioGroup_default, hi as TriangleDownIcon, o as AlertIcon, pi as Tooltip$1, vn as LawIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as SOFT_NAV_STATE } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { l as removeItem, n as getItem, u as setItem } from "./server-utils-4Tqzfq5z-FwA7hod1.js";
import { m as useBlockerLegacy, p as useBlocker$1, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { r as UnderlineNav } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { r as Select$1, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { n as ButtonComponent$1 } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as BranchName_default } from "./server-BranchName-HKnig0CO-C3hpegKL.js";
import { n as useIsDataRouterEnabled } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { B as encodePart, U as getRelativeHref, c as branchPath, ct as ownerPath, o as blobSidePanelMetadataPath, st as ownerAvatarPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { a as EmptyDiffLine, d as lineAnchorFrom, f as lineOrientationFrom, o as HunkHeaderDiffLine, t as DiffLinePart } from "./server-diff-parts-DKuV_5Kq-C34001QS.js";
import { t as isMacOS } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { t as UnsafeHTMLBox } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { c as useUrlCreator } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as Dialog_default } from "./server-Dialog-Bj1Iyrx--DrNEVM4r.js";
import { i as useScreenSize, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { _ as replaceRange, a as getCursor, c as getRange, h as posToOffset, m as offsetToPos, o as getIndentationUnit, p as moveCursorToPositionAndScroll, s as getLine, t as autocompleteTheme, u as helpPanelConstructor } from "./server-theme-BtyxB5Uk-ZXETvnL8.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { a as useShortcut, i as useCodeViewOptions } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { t as ExpandButton } from "./server-ExpandButton-H4onZNiH-BPmYbDb_.js";
import { l as useOpenPanel } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { n as Separator, t as Breadcrumb } from "./server-Breadcrumb-ivvgSfHr-DYsABnl4.js";
import { t as Panel } from "./server-Panel-C4KaHVsW-jwL1gzzi.js";
import { t as GetCharIndexFromBytePosition } from "./server-text-DMnXDgcs-0AUipYfI.js";
import { t as AlphaLabel } from "./server-AlphaLabel-CP7CzFaj-k7z2o8os.js";
import { n as EditingForkBanner, t as EditIssues } from "./server-EditIssues-CxyxDJIu-OavrLrRt.js";
import { t as BetaLabel } from "./server-BetaLabel-D0vwDZNc-CsXfuTFf.js";
import { t as CopilotPopover } from "./server-CopilotPopover-DZ8KZzV--BVOmP6Gt.js";
import { t as LoadingFallback } from "./server-SuspenseFallback-CKhZbbQP-DbruduCY.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as useRoutePayload } from "./server-use-route-payload-MAZr7zfl-DL3BDU9L.js";
import { n as codeViewLayoutRoute } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { t as FileRendererBlob } from "./server-FileRendererBlob-TWxYp7zf-DGngYU18.js";
import { t as CodeLine, y as LineNumber } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { n as setDocumentUri } from "./server-document-uri-CiR3FLCW-BF5w9Niz.js";
import { t as IncludeFragment } from "./server-IncludeFragment-DnVGLtXS-CQrYLuE4.js";
import { t as WebCommitDialog } from "./server-WebCommitDialog-QSR17-Mc-4IZG7qWy.js";
import { Buffer } from "buffer";
import memoize from "@github/memoize";
import React, { Suspense, lazy, useCallback, useEffect, useEffectEvent, useMemo, useRef, useState, useTransition } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { EditorView, ViewPlugin, hoverTooltip, keymap } from "@codemirror/view";
import { Compartment, Prec } from "@codemirror/state";
import yaml from "js-yaml";
import { acceptCompletion, autocompletion, closeCompletion, insertCompletionText, moveCompletionSelection, pickedCompletion, selectedCompletion, startCompletion } from "@codemirror/autocomplete";
import { linter } from "@codemirror/lint";
import leven from "leven";
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
var directives = /* @__PURE__ */ new WeakMap();
const isDirective = (o) => {
	return typeof o === "function" && directives.has(o);
};
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* True if the custom elements polyfill is in use.
*/
const isCEPolyfill = window.customElements !== void 0 && window.customElements.polyfillWrapFlushCallback !== void 0;
/**
* Removes nodes, starting from `start` (inclusive) to `end` (exclusive), from
* `container`.
*/
const removeNodes = (container, start, end = null) => {
	while (start !== end) {
		const n = start.nextSibling;
		container.removeChild(start);
		start = n;
	}
};
/**
* @license
* Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* A sentinel value that signals that a value was handled by a directive and
* should not be written to the DOM.
*/
const noChange = {};
/**
* A sentinel value that signals a NodePart to fully clear its content.
*/
const nothing = {};
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* An expression marker with embedded unique key to avoid collision with
* possible text in templates.
*/
const marker = `{{lit-${String(Math.random()).slice(2)}}}`;
/**
* An expression marker used text-positions, multi-binding attributes, and
* attributes with markup-like text values.
*/
const nodeMarker = `<!--${marker}-->`;
const markerRegex = new RegExp(`${marker}|${nodeMarker}`);
/**
* Suffix appended to all bound attribute names.
*/
const boundAttributeSuffix = "$lit$";
/**
* An updateable Template that tracks the location of dynamic parts.
*/
var Template = class {
	constructor(result, element) {
		this.parts = [];
		this.element = element;
		const nodesToRemove = [];
		const stack = [];
		const walker = document.createTreeWalker(element.content, 133, null, false);
		let lastPartIndex = 0;
		let index = -1;
		let partIndex = 0;
		const { strings, values: { length } } = result;
		while (partIndex < length) {
			const node = walker.nextNode();
			if (node === null) {
				walker.currentNode = stack.pop();
				continue;
			}
			index++;
			if (node.nodeType === 1) {
				if (node.hasAttributes()) {
					const attributes = node.attributes;
					const { length } = attributes;
					let count = 0;
					for (let i = 0; i < length; i++) if (endsWith(attributes[i].name, "$lit$")) count++;
					while (count-- > 0) {
						const stringForPart = strings[partIndex];
						const name = lastAttributeNameRegex.exec(stringForPart)[2];
						const attributeLookupName = name.toLowerCase() + boundAttributeSuffix;
						const attributeValue = node.getAttribute(attributeLookupName);
						node.removeAttribute(attributeLookupName);
						const statics = attributeValue.split(markerRegex);
						this.parts.push({
							type: "attribute",
							index,
							name,
							strings: statics
						});
						partIndex += statics.length - 1;
					}
				}
				if (node.tagName === "TEMPLATE") {
					stack.push(node);
					walker.currentNode = node.content;
				}
			} else if (node.nodeType === 3) {
				const data = node.data;
				if (data.indexOf(marker) >= 0) {
					const parent = node.parentNode;
					const strings = data.split(markerRegex);
					const lastIndex = strings.length - 1;
					for (let i = 0; i < lastIndex; i++) {
						let insert;
						let s = strings[i];
						if (s === "") insert = createMarker();
						else {
							const match = lastAttributeNameRegex.exec(s);
							if (match !== null && endsWith(match[2], "$lit$")) s = s.slice(0, match.index) + match[1] + match[2].slice(0, -5) + match[3];
							insert = document.createTextNode(s);
						}
						parent.insertBefore(insert, node);
						this.parts.push({
							type: "node",
							index: ++index
						});
					}
					if (strings[lastIndex] === "") {
						parent.insertBefore(createMarker(), node);
						nodesToRemove.push(node);
					} else node.data = strings[lastIndex];
					partIndex += lastIndex;
				}
			} else if (node.nodeType === 8) if (node.data === marker) {
				const parent = node.parentNode;
				if (node.previousSibling === null || index === lastPartIndex) {
					index++;
					parent.insertBefore(createMarker(), node);
				}
				lastPartIndex = index;
				this.parts.push({
					type: "node",
					index
				});
				if (node.nextSibling === null) node.data = "";
				else {
					nodesToRemove.push(node);
					index--;
				}
				partIndex++;
			} else {
				let i = -1;
				while ((i = node.data.indexOf(marker, i + 1)) !== -1) {
					this.parts.push({
						type: "node",
						index: -1
					});
					partIndex++;
				}
			}
		}
		for (const n of nodesToRemove) n.parentNode.removeChild(n);
	}
};
var endsWith = (str, suffix) => {
	const index = str.length - suffix.length;
	return index >= 0 && str.slice(index) === suffix;
};
const isTemplatePartActive = (part) => part.index !== -1;
const createMarker = () => document.createComment("");
/**
* This regex extracts the attribute name preceding an attribute-position
* expression. It does this by matching the syntax allowed for attributes
* against the string literal directly preceding the expression, assuming that
* the expression is in an attribute-value position.
*
* See attributes in the HTML spec:
* https://www.w3.org/TR/html5/syntax.html#elements-attributes
*
* " \x09\x0a\x0c\x0d" are HTML space characters:
* https://www.w3.org/TR/html5/infrastructure.html#space-characters
*
* "\0-\x1F\x7F-\x9F" are Unicode control characters, which includes every
* space character except " ".
*
* So an attribute is:
*  * The name: any character except a control character, space character, ('),
*    ("), ">", "=", or "/"
*  * Followed by zero or more space characters
*  * Followed by "="
*  * Followed by zero or more space characters
*  * Followed by:
*    * Any character except space, ('), ("), "<", ">", "=", (`), or
*    * (") then any non-("), or
*    * (') then any non-(')
*/
const lastAttributeNameRegex = /([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* @module lit-html
*/
/**
* An instance of a `Template` that can be attached to the DOM and updated
* with new values.
*/
var TemplateInstance = class {
	constructor(template, processor, options) {
		this.__parts = [];
		this.template = template;
		this.processor = processor;
		this.options = options;
	}
	update(values) {
		let i = 0;
		for (const part of this.__parts) {
			if (part !== void 0) part.setValue(values[i]);
			i++;
		}
		for (const part of this.__parts) if (part !== void 0) part.commit();
	}
	_clone() {
		const fragment = isCEPolyfill ? this.template.element.content.cloneNode(true) : document.importNode(this.template.element.content, true);
		const stack = [];
		const parts = this.template.parts;
		const walker = document.createTreeWalker(fragment, 133, null, false);
		let partIndex = 0;
		let nodeIndex = 0;
		let part;
		let node = walker.nextNode();
		while (partIndex < parts.length) {
			part = parts[partIndex];
			if (!isTemplatePartActive(part)) {
				this.__parts.push(void 0);
				partIndex++;
				continue;
			}
			while (nodeIndex < part.index) {
				nodeIndex++;
				if (node.nodeName === "TEMPLATE") {
					stack.push(node);
					walker.currentNode = node.content;
				}
				if ((node = walker.nextNode()) === null) {
					walker.currentNode = stack.pop();
					node = walker.nextNode();
				}
			}
			if (part.type === "node") {
				const part = this.processor.handleTextExpression(this.options);
				part.insertAfterNode(node.previousSibling);
				this.__parts.push(part);
			} else this.__parts.push(...this.processor.handleAttributeExpressions(node, part.name, part.strings, this.options));
			partIndex++;
		}
		if (isCEPolyfill) {
			document.adoptNode(fragment);
			customElements.upgrade(fragment);
		}
		return fragment;
	}
};
var commentMarker = ` ${marker} `;
/**
* The return type of `html`, which holds a Template and the values from
* interpolated expressions.
*/
var TemplateResult = class {
	constructor(strings, values, type, processor) {
		this.strings = strings;
		this.values = values;
		this.type = type;
		this.processor = processor;
	}
	/**
	* Returns a string of HTML used to create a `<template>` element.
	*/
	getHTML() {
		const l = this.strings.length - 1;
		let html = "";
		let isCommentBinding = false;
		for (let i = 0; i < l; i++) {
			const s = this.strings[i];
			const commentOpen = s.lastIndexOf("<!--");
			isCommentBinding = (commentOpen > -1 || isCommentBinding) && s.indexOf("-->", commentOpen + 1) === -1;
			const attributeMatch = lastAttributeNameRegex.exec(s);
			if (attributeMatch === null) html += s + (isCommentBinding ? commentMarker : nodeMarker);
			else html += s.substr(0, attributeMatch.index) + attributeMatch[1] + attributeMatch[2] + boundAttributeSuffix + attributeMatch[3] + marker;
		}
		html += this.strings[l];
		return html;
	}
	getTemplateElement() {
		const template = document.createElement("template");
		template.innerHTML = this.getHTML();
		return template;
	}
};
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* @module lit-html
*/
const isPrimitive = (value) => {
	return value === null || !(typeof value === "object" || typeof value === "function");
};
const isIterable = (value) => {
	return Array.isArray(value) || !!(value && value[Symbol.iterator]);
};
/**
* Writes attribute values to the DOM for a group of AttributeParts bound to a
* single attibute. The value is only set once even if there are multiple parts
* for an attribute.
*/
var AttributeCommitter = class {
	constructor(element, name, strings) {
		this.dirty = true;
		this.element = element;
		this.name = name;
		this.strings = strings;
		this.parts = [];
		for (let i = 0; i < strings.length - 1; i++) this.parts[i] = this._createPart();
	}
	/**
	* Creates a single part. Override this to create a differnt type of part.
	*/
	_createPart() {
		return new AttributePart(this);
	}
	_getValue() {
		const strings = this.strings;
		const l = strings.length - 1;
		let text = "";
		for (let i = 0; i < l; i++) {
			text += strings[i];
			const part = this.parts[i];
			if (part !== void 0) {
				const v = part.value;
				if (isPrimitive(v) || !isIterable(v)) text += typeof v === "string" ? v : String(v);
				else for (const t of v) text += typeof t === "string" ? t : String(t);
			}
		}
		text += strings[l];
		return text;
	}
	commit() {
		if (this.dirty) {
			this.dirty = false;
			this.element.setAttribute(this.name, this._getValue());
		}
	}
};
/**
* A Part that controls all or part of an attribute value.
*/
var AttributePart = class {
	constructor(committer) {
		this.value = void 0;
		this.committer = committer;
	}
	setValue(value) {
		if (value !== noChange && (!isPrimitive(value) || value !== this.value)) {
			this.value = value;
			if (!isDirective(value)) this.committer.dirty = true;
		}
	}
	commit() {
		while (isDirective(this.value)) {
			const directive = this.value;
			this.value = noChange;
			directive(this);
		}
		if (this.value === noChange) return;
		this.committer.commit();
	}
};
/**
* A Part that controls a location within a Node tree. Like a Range, NodePart
* has start and end locations and can set and update the Nodes between those
* locations.
*
* NodeParts support several value types: primitives, Nodes, TemplateResults,
* as well as arrays and iterables of those types.
*/
var NodePart = class NodePart {
	constructor(options) {
		this.value = void 0;
		this.__pendingValue = void 0;
		this.options = options;
	}
	/**
	* Appends this part into a container.
	*
	* This part must be empty, as its contents are not automatically moved.
	*/
	appendInto(container) {
		this.startNode = container.appendChild(createMarker());
		this.endNode = container.appendChild(createMarker());
	}
	/**
	* Inserts this part after the `ref` node (between `ref` and `ref`'s next
	* sibling). Both `ref` and its next sibling must be static, unchanging nodes
	* such as those that appear in a literal section of a template.
	*
	* This part must be empty, as its contents are not automatically moved.
	*/
	insertAfterNode(ref) {
		this.startNode = ref;
		this.endNode = ref.nextSibling;
	}
	/**
	* Appends this part into a parent part.
	*
	* This part must be empty, as its contents are not automatically moved.
	*/
	appendIntoPart(part) {
		part.__insert(this.startNode = createMarker());
		part.__insert(this.endNode = createMarker());
	}
	/**
	* Inserts this part after the `ref` part.
	*
	* This part must be empty, as its contents are not automatically moved.
	*/
	insertAfterPart(ref) {
		ref.__insert(this.startNode = createMarker());
		this.endNode = ref.endNode;
		ref.endNode = this.startNode;
	}
	setValue(value) {
		this.__pendingValue = value;
	}
	commit() {
		while (isDirective(this.__pendingValue)) {
			const directive = this.__pendingValue;
			this.__pendingValue = noChange;
			directive(this);
		}
		const value = this.__pendingValue;
		if (value === noChange) return;
		if (isPrimitive(value)) {
			if (value !== this.value) this.__commitText(value);
		} else if (value instanceof TemplateResult) this.__commitTemplateResult(value);
		else if (value instanceof Node) this.__commitNode(value);
		else if (isIterable(value)) this.__commitIterable(value);
		else if (value === nothing) {
			this.value = nothing;
			this.clear();
		} else this.__commitText(value);
	}
	__insert(node) {
		this.endNode.parentNode.insertBefore(node, this.endNode);
	}
	__commitNode(value) {
		if (this.value === value) return;
		this.clear();
		this.__insert(value);
		this.value = value;
	}
	__commitText(value) {
		const node = this.startNode.nextSibling;
		value = value == null ? "" : value;
		const valueAsString = typeof value === "string" ? value : String(value);
		if (node === this.endNode.previousSibling && node.nodeType === 3) node.data = valueAsString;
		else this.__commitNode(document.createTextNode(valueAsString));
		this.value = value;
	}
	__commitTemplateResult(value) {
		const template = this.options.templateFactory(value);
		if (this.value instanceof TemplateInstance && this.value.template === template) this.value.update(value.values);
		else {
			const instance = new TemplateInstance(template, value.processor, this.options);
			const fragment = instance._clone();
			instance.update(value.values);
			this.__commitNode(fragment);
			this.value = instance;
		}
	}
	__commitIterable(value) {
		if (!Array.isArray(this.value)) {
			this.value = [];
			this.clear();
		}
		const itemParts = this.value;
		let partIndex = 0;
		let itemPart;
		for (const item of value) {
			itemPart = itemParts[partIndex];
			if (itemPart === void 0) {
				itemPart = new NodePart(this.options);
				itemParts.push(itemPart);
				if (partIndex === 0) itemPart.appendIntoPart(this);
				else itemPart.insertAfterPart(itemParts[partIndex - 1]);
			}
			itemPart.setValue(item);
			itemPart.commit();
			partIndex++;
		}
		if (partIndex < itemParts.length) {
			itemParts.length = partIndex;
			this.clear(itemPart && itemPart.endNode);
		}
	}
	clear(startNode = this.startNode) {
		removeNodes(this.startNode.parentNode, startNode.nextSibling, this.endNode);
	}
};
/**
* Implements a boolean attribute, roughly as defined in the HTML
* specification.
*
* If the value is truthy, then the attribute is present with a value of
* ''. If the value is falsey, the attribute is removed.
*/
var BooleanAttributePart = class {
	constructor(element, name, strings) {
		this.value = void 0;
		this.__pendingValue = void 0;
		if (strings.length !== 2 || strings[0] !== "" || strings[1] !== "") throw new Error("Boolean attributes can only contain a single expression");
		this.element = element;
		this.name = name;
		this.strings = strings;
	}
	setValue(value) {
		this.__pendingValue = value;
	}
	commit() {
		while (isDirective(this.__pendingValue)) {
			const directive = this.__pendingValue;
			this.__pendingValue = noChange;
			directive(this);
		}
		if (this.__pendingValue === noChange) return;
		const value = !!this.__pendingValue;
		if (this.value !== value) {
			if (value) this.element.setAttribute(this.name, "");
			else this.element.removeAttribute(this.name);
			this.value = value;
		}
		this.__pendingValue = noChange;
	}
};
/**
* Sets attribute values for PropertyParts, so that the value is only set once
* even if there are multiple parts for a property.
*
* If an expression controls the whole property value, then the value is simply
* assigned to the property under control. If there are string literals or
* multiple expressions, then the strings are expressions are interpolated into
* a string first.
*/
var PropertyCommitter = class extends AttributeCommitter {
	constructor(element, name, strings) {
		super(element, name, strings);
		this.single = strings.length === 2 && strings[0] === "" && strings[1] === "";
	}
	_createPart() {
		return new PropertyPart(this);
	}
	_getValue() {
		if (this.single) return this.parts[0].value;
		return super._getValue();
	}
	commit() {
		if (this.dirty) {
			this.dirty = false;
			this.element[this.name] = this._getValue();
		}
	}
};
var PropertyPart = class extends AttributePart {};
var eventOptionsSupported = false;
try {
	const options = { get capture() {
		eventOptionsSupported = true;
		return false;
	} };
	window.addEventListener("test", options, options);
	window.removeEventListener("test", options, options);
} catch (_e) {}
var EventPart = class {
	constructor(element, eventName, eventContext) {
		this.value = void 0;
		this.__pendingValue = void 0;
		this.element = element;
		this.eventName = eventName;
		this.eventContext = eventContext;
		this.__boundHandleEvent = (e) => this.handleEvent(e);
	}
	setValue(value) {
		this.__pendingValue = value;
	}
	commit() {
		while (isDirective(this.__pendingValue)) {
			const directive = this.__pendingValue;
			this.__pendingValue = noChange;
			directive(this);
		}
		if (this.__pendingValue === noChange) return;
		const newListener = this.__pendingValue;
		const oldListener = this.value;
		const shouldRemoveListener = newListener == null || oldListener != null && (newListener.capture !== oldListener.capture || newListener.once !== oldListener.once || newListener.passive !== oldListener.passive);
		const shouldAddListener = newListener != null && (oldListener == null || shouldRemoveListener);
		if (shouldRemoveListener) this.element.removeEventListener(this.eventName, this.__boundHandleEvent, this.__options);
		if (shouldAddListener) {
			this.__options = getOptions(newListener);
			this.element.addEventListener(this.eventName, this.__boundHandleEvent, this.__options);
		}
		this.value = newListener;
		this.__pendingValue = noChange;
	}
	handleEvent(event) {
		if (typeof this.value === "function") this.value.call(this.eventContext || this.element, event);
		else this.value.handleEvent(event);
	}
};
var getOptions = (o) => o && (eventOptionsSupported ? {
	capture: o.capture,
	passive: o.passive,
	once: o.once
} : o.capture);
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* Creates Parts when a template is instantiated.
*/
var DefaultTemplateProcessor = class {
	/**
	* Create parts for an attribute-position binding, given the event, attribute
	* name, and string literals.
	*
	* @param element The element containing the binding
	* @param name  The attribute name
	* @param strings The string literals. There are always at least two strings,
	*   event for fully-controlled bindings with a single expression.
	*/
	handleAttributeExpressions(element, name, strings, options) {
		const prefix = name[0];
		if (prefix === ".") return new PropertyCommitter(element, name.slice(1), strings).parts;
		if (prefix === "@") return [new EventPart(element, name.slice(1), options.eventContext)];
		if (prefix === "?") return [new BooleanAttributePart(element, name.slice(1), strings)];
		return new AttributeCommitter(element, name, strings).parts;
	}
	/**
	* Create parts for a text-position binding.
	* @param templateFactory
	*/
	handleTextExpression(options) {
		return new NodePart(options);
	}
};
const defaultTemplateProcessor = new DefaultTemplateProcessor();
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* The default TemplateFactory which caches Templates keyed on
* result.type and result.strings.
*/
function templateFactory(result) {
	let templateCache = templateCaches.get(result.type);
	if (templateCache === void 0) {
		templateCache = {
			stringsArray: /* @__PURE__ */ new WeakMap(),
			keyString: /* @__PURE__ */ new Map()
		};
		templateCaches.set(result.type, templateCache);
	}
	let template = templateCache.stringsArray.get(result.strings);
	if (template !== void 0) return template;
	const key = result.strings.join(marker);
	template = templateCache.keyString.get(key);
	if (template === void 0) {
		template = new Template(result, result.getTemplateElement());
		templateCache.keyString.set(key, template);
	}
	templateCache.stringsArray.set(result.strings, template);
	return template;
}
const templateCaches = /* @__PURE__ */ new Map();
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
* @module lit-html
*/
const parts = /* @__PURE__ */ new WeakMap();
/**
* Renders a template result or other value to a container.
*
* To update a container with new values, reevaluate the template literal and
* call `render` with the new result.
*
* @param result Any value renderable by NodePart - typically a TemplateResult
*     created by evaluating a template tag like `html` or `svg`.
* @param container A DOM parent to render to. The entire contents are either
*     replaced, or efficiently updated if the same result type was previous
*     rendered there.
* @param options RenderOptions for the entire render tree rendered to this
*     container. Render options must *not* change between renders to the same
*     container, as those changes will not effect previously rendered DOM.
*/
const render = (result, container, options) => {
	let part = parts.get(container);
	if (part === void 0) {
		removeNodes(container, container.firstChild);
		parts.set(container, part = new NodePart(Object.assign({ templateFactory }, options)));
		part.appendInto(container);
	}
	part.setValue(result);
	part.commit();
};
/**
* @license
* Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
* This code may only be used under the BSD style license found at
* http://polymer.github.io/LICENSE.txt
* The complete set of authors may be found at
* http://polymer.github.io/AUTHORS.txt
* The complete set of contributors may be found at
* http://polymer.github.io/CONTRIBUTORS.txt
* Code distributed by Google as part of the polymer project is also
* subject to an additional IP rights grant found at
* http://polymer.github.io/PATENTS.txt
*/
/**
*
* Main lit-html module.
*
* Main exports:
*
* -  [[html]]
* -  [[svg]]
* -  [[render]]
*
* @module lit-html
* @preferred
*/
/**
* Do not remove this comment; it keeps typedoc from misplacing the module
* docs.
*/
(window["litHtmlVersions"] || (window["litHtmlVersions"] = [])).push("1.1.2");
/**
* Interprets a template literal as an HTML template that can efficiently
* render to and update a container.
*/
const html = (strings, ...values) => new TemplateResult(strings, values, "html", defaultTemplateProcessor);
/**
* Creates a JSON scanner on the given text.
* If ignoreTrivia is set, whitespaces or comments are ignored.
*/
function createScanner$1(text, ignoreTrivia = false) {
	const len = text.length;
	let pos = 0, value = "", tokenOffset = 0, token = 16, lineNumber = 0, lineStartOffset = 0, tokenLineStartOffset = 0, prevTokenLineStartOffset = 0, scanError = 0;
	function scanHexDigits(count, exact) {
		let digits = 0;
		let value = 0;
		while (digits < count || !exact) {
			let ch = text.charCodeAt(pos);
			if (ch >= 48 && ch <= 57) value = value * 16 + ch - 48;
			else if (ch >= 65 && ch <= 70) value = value * 16 + ch - 65 + 10;
			else if (ch >= 97 && ch <= 102) value = value * 16 + ch - 97 + 10;
			else break;
			pos++;
			digits++;
		}
		if (digits < count) value = -1;
		return value;
	}
	function setPosition(newPosition) {
		pos = newPosition;
		value = "";
		tokenOffset = 0;
		token = 16;
		scanError = 0;
	}
	function scanNumber() {
		let start = pos;
		if (text.charCodeAt(pos) === 48) pos++;
		else {
			pos++;
			while (pos < text.length && isDigit(text.charCodeAt(pos))) pos++;
		}
		if (pos < text.length && text.charCodeAt(pos) === 46) {
			pos++;
			if (pos < text.length && isDigit(text.charCodeAt(pos))) {
				pos++;
				while (pos < text.length && isDigit(text.charCodeAt(pos))) pos++;
			} else {
				scanError = 3;
				return text.substring(start, pos);
			}
		}
		let end = pos;
		if (pos < text.length && (text.charCodeAt(pos) === 69 || text.charCodeAt(pos) === 101)) {
			pos++;
			if (pos < text.length && text.charCodeAt(pos) === 43 || text.charCodeAt(pos) === 45) pos++;
			if (pos < text.length && isDigit(text.charCodeAt(pos))) {
				pos++;
				while (pos < text.length && isDigit(text.charCodeAt(pos))) pos++;
				end = pos;
			} else scanError = 3;
		}
		return text.substring(start, end);
	}
	function scanString() {
		let result = "", start = pos;
		while (true) {
			if (pos >= len) {
				result += text.substring(start, pos);
				scanError = 2;
				break;
			}
			const ch = text.charCodeAt(pos);
			if (ch === 34) {
				result += text.substring(start, pos);
				pos++;
				break;
			}
			if (ch === 92) {
				result += text.substring(start, pos);
				pos++;
				if (pos >= len) {
					scanError = 2;
					break;
				}
				switch (text.charCodeAt(pos++)) {
					case 34:
						result += "\"";
						break;
					case 92:
						result += "\\";
						break;
					case 47:
						result += "/";
						break;
					case 98:
						result += "\b";
						break;
					case 102:
						result += "\f";
						break;
					case 110:
						result += "\n";
						break;
					case 114:
						result += "\r";
						break;
					case 116:
						result += "	";
						break;
					case 117:
						const ch3 = scanHexDigits(4, true);
						if (ch3 >= 0) result += String.fromCharCode(ch3);
						else scanError = 4;
						break;
					default: scanError = 5;
				}
				start = pos;
				continue;
			}
			if (ch >= 0 && ch <= 31) if (isLineBreak(ch)) {
				result += text.substring(start, pos);
				scanError = 2;
				break;
			} else scanError = 6;
			pos++;
		}
		return result;
	}
	function scanNext() {
		value = "";
		scanError = 0;
		tokenOffset = pos;
		lineStartOffset = lineNumber;
		prevTokenLineStartOffset = tokenLineStartOffset;
		if (pos >= len) {
			tokenOffset = len;
			return token = 17;
		}
		let code = text.charCodeAt(pos);
		if (isWhiteSpace(code)) {
			do {
				pos++;
				value += String.fromCharCode(code);
				code = text.charCodeAt(pos);
			} while (isWhiteSpace(code));
			return token = 15;
		}
		if (isLineBreak(code)) {
			pos++;
			value += String.fromCharCode(code);
			if (code === 13 && text.charCodeAt(pos) === 10) {
				pos++;
				value += "\n";
			}
			lineNumber++;
			tokenLineStartOffset = pos;
			return token = 14;
		}
		switch (code) {
			case 123:
				pos++;
				return token = 1;
			case 125:
				pos++;
				return token = 2;
			case 91:
				pos++;
				return token = 3;
			case 93:
				pos++;
				return token = 4;
			case 58:
				pos++;
				return token = 6;
			case 44:
				pos++;
				return token = 5;
			case 34:
				pos++;
				value = scanString();
				return token = 10;
			case 47:
				const start = pos - 1;
				if (text.charCodeAt(pos + 1) === 47) {
					pos += 2;
					while (pos < len) {
						if (isLineBreak(text.charCodeAt(pos))) break;
						pos++;
					}
					value = text.substring(start, pos);
					return token = 12;
				}
				if (text.charCodeAt(pos + 1) === 42) {
					pos += 2;
					const safeLength = len - 1;
					let commentClosed = false;
					while (pos < safeLength) {
						const ch = text.charCodeAt(pos);
						if (ch === 42 && text.charCodeAt(pos + 1) === 47) {
							pos += 2;
							commentClosed = true;
							break;
						}
						pos++;
						if (isLineBreak(ch)) {
							if (ch === 13 && text.charCodeAt(pos) === 10) pos++;
							lineNumber++;
							tokenLineStartOffset = pos;
						}
					}
					if (!commentClosed) {
						pos++;
						scanError = 1;
					}
					value = text.substring(start, pos);
					return token = 13;
				}
				value += String.fromCharCode(code);
				pos++;
				return token = 16;
			case 45:
				value += String.fromCharCode(code);
				pos++;
				if (pos === len || !isDigit(text.charCodeAt(pos))) return token = 16;
			case 48:
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
			case 56:
			case 57:
				value += scanNumber();
				return token = 11;
			default:
				while (pos < len && isUnknownContentCharacter(code)) {
					pos++;
					code = text.charCodeAt(pos);
				}
				if (tokenOffset !== pos) {
					value = text.substring(tokenOffset, pos);
					switch (value) {
						case "true": return token = 8;
						case "false": return token = 9;
						case "null": return token = 7;
					}
					return token = 16;
				}
				value += String.fromCharCode(code);
				pos++;
				return token = 16;
		}
	}
	function isUnknownContentCharacter(code) {
		if (isWhiteSpace(code) || isLineBreak(code)) return false;
		switch (code) {
			case 125:
			case 93:
			case 123:
			case 91:
			case 34:
			case 58:
			case 44:
			case 47: return false;
		}
		return true;
	}
	function scanNextNonTrivia() {
		let result;
		do
			result = scanNext();
		while (result >= 12 && result <= 15);
		return result;
	}
	return {
		setPosition,
		getPosition: () => pos,
		scan: ignoreTrivia ? scanNextNonTrivia : scanNext,
		getToken: () => token,
		getTokenValue: () => value,
		getTokenOffset: () => tokenOffset,
		getTokenLength: () => pos - tokenOffset,
		getTokenStartLine: () => lineStartOffset,
		getTokenStartCharacter: () => tokenOffset - prevTokenLineStartOffset,
		getTokenError: () => scanError
	};
}
function isWhiteSpace(ch) {
	return ch === 32 || ch === 9;
}
function isLineBreak(ch) {
	return ch === 10 || ch === 13;
}
function isDigit(ch) {
	return ch >= 48 && ch <= 57;
}
var CharacterCodes;
(function(CharacterCodes) {
	CharacterCodes[CharacterCodes["lineFeed"] = 10] = "lineFeed";
	CharacterCodes[CharacterCodes["carriageReturn"] = 13] = "carriageReturn";
	CharacterCodes[CharacterCodes["space"] = 32] = "space";
	CharacterCodes[CharacterCodes["_0"] = 48] = "_0";
	CharacterCodes[CharacterCodes["_1"] = 49] = "_1";
	CharacterCodes[CharacterCodes["_2"] = 50] = "_2";
	CharacterCodes[CharacterCodes["_3"] = 51] = "_3";
	CharacterCodes[CharacterCodes["_4"] = 52] = "_4";
	CharacterCodes[CharacterCodes["_5"] = 53] = "_5";
	CharacterCodes[CharacterCodes["_6"] = 54] = "_6";
	CharacterCodes[CharacterCodes["_7"] = 55] = "_7";
	CharacterCodes[CharacterCodes["_8"] = 56] = "_8";
	CharacterCodes[CharacterCodes["_9"] = 57] = "_9";
	CharacterCodes[CharacterCodes["a"] = 97] = "a";
	CharacterCodes[CharacterCodes["b"] = 98] = "b";
	CharacterCodes[CharacterCodes["c"] = 99] = "c";
	CharacterCodes[CharacterCodes["d"] = 100] = "d";
	CharacterCodes[CharacterCodes["e"] = 101] = "e";
	CharacterCodes[CharacterCodes["f"] = 102] = "f";
	CharacterCodes[CharacterCodes["g"] = 103] = "g";
	CharacterCodes[CharacterCodes["h"] = 104] = "h";
	CharacterCodes[CharacterCodes["i"] = 105] = "i";
	CharacterCodes[CharacterCodes["j"] = 106] = "j";
	CharacterCodes[CharacterCodes["k"] = 107] = "k";
	CharacterCodes[CharacterCodes["l"] = 108] = "l";
	CharacterCodes[CharacterCodes["m"] = 109] = "m";
	CharacterCodes[CharacterCodes["n"] = 110] = "n";
	CharacterCodes[CharacterCodes["o"] = 111] = "o";
	CharacterCodes[CharacterCodes["p"] = 112] = "p";
	CharacterCodes[CharacterCodes["q"] = 113] = "q";
	CharacterCodes[CharacterCodes["r"] = 114] = "r";
	CharacterCodes[CharacterCodes["s"] = 115] = "s";
	CharacterCodes[CharacterCodes["t"] = 116] = "t";
	CharacterCodes[CharacterCodes["u"] = 117] = "u";
	CharacterCodes[CharacterCodes["v"] = 118] = "v";
	CharacterCodes[CharacterCodes["w"] = 119] = "w";
	CharacterCodes[CharacterCodes["x"] = 120] = "x";
	CharacterCodes[CharacterCodes["y"] = 121] = "y";
	CharacterCodes[CharacterCodes["z"] = 122] = "z";
	CharacterCodes[CharacterCodes["A"] = 65] = "A";
	CharacterCodes[CharacterCodes["B"] = 66] = "B";
	CharacterCodes[CharacterCodes["C"] = 67] = "C";
	CharacterCodes[CharacterCodes["D"] = 68] = "D";
	CharacterCodes[CharacterCodes["E"] = 69] = "E";
	CharacterCodes[CharacterCodes["F"] = 70] = "F";
	CharacterCodes[CharacterCodes["G"] = 71] = "G";
	CharacterCodes[CharacterCodes["H"] = 72] = "H";
	CharacterCodes[CharacterCodes["I"] = 73] = "I";
	CharacterCodes[CharacterCodes["J"] = 74] = "J";
	CharacterCodes[CharacterCodes["K"] = 75] = "K";
	CharacterCodes[CharacterCodes["L"] = 76] = "L";
	CharacterCodes[CharacterCodes["M"] = 77] = "M";
	CharacterCodes[CharacterCodes["N"] = 78] = "N";
	CharacterCodes[CharacterCodes["O"] = 79] = "O";
	CharacterCodes[CharacterCodes["P"] = 80] = "P";
	CharacterCodes[CharacterCodes["Q"] = 81] = "Q";
	CharacterCodes[CharacterCodes["R"] = 82] = "R";
	CharacterCodes[CharacterCodes["S"] = 83] = "S";
	CharacterCodes[CharacterCodes["T"] = 84] = "T";
	CharacterCodes[CharacterCodes["U"] = 85] = "U";
	CharacterCodes[CharacterCodes["V"] = 86] = "V";
	CharacterCodes[CharacterCodes["W"] = 87] = "W";
	CharacterCodes[CharacterCodes["X"] = 88] = "X";
	CharacterCodes[CharacterCodes["Y"] = 89] = "Y";
	CharacterCodes[CharacterCodes["Z"] = 90] = "Z";
	CharacterCodes[CharacterCodes["asterisk"] = 42] = "asterisk";
	CharacterCodes[CharacterCodes["backslash"] = 92] = "backslash";
	CharacterCodes[CharacterCodes["closeBrace"] = 125] = "closeBrace";
	CharacterCodes[CharacterCodes["closeBracket"] = 93] = "closeBracket";
	CharacterCodes[CharacterCodes["colon"] = 58] = "colon";
	CharacterCodes[CharacterCodes["comma"] = 44] = "comma";
	CharacterCodes[CharacterCodes["dot"] = 46] = "dot";
	CharacterCodes[CharacterCodes["doubleQuote"] = 34] = "doubleQuote";
	CharacterCodes[CharacterCodes["minus"] = 45] = "minus";
	CharacterCodes[CharacterCodes["openBrace"] = 123] = "openBrace";
	CharacterCodes[CharacterCodes["openBracket"] = 91] = "openBracket";
	CharacterCodes[CharacterCodes["plus"] = 43] = "plus";
	CharacterCodes[CharacterCodes["slash"] = 47] = "slash";
	CharacterCodes[CharacterCodes["formFeed"] = 12] = "formFeed";
	CharacterCodes[CharacterCodes["tab"] = 9] = "tab";
})(CharacterCodes || (CharacterCodes = {}));
var ParseOptions;
(function(ParseOptions) {
	ParseOptions.DEFAULT = { allowTrailingComma: false };
})(ParseOptions || (ParseOptions = {}));
/**
* Parses the given text and returns the object the JSON content represents. On invalid input, the parser tries to be as fault tolerant as possible, but still return a result.
* Therefore always check the errors list to find out if the input was valid.
*/
function parse$2(text, errors = [], options = ParseOptions.DEFAULT) {
	let currentProperty = null;
	let currentParent = [];
	const previousParents = [];
	function onValue(value) {
		if (Array.isArray(currentParent)) currentParent.push(value);
		else if (currentProperty !== null) currentParent[currentProperty] = value;
	}
	visit$1(text, {
		onObjectBegin: () => {
			const object = {};
			onValue(object);
			previousParents.push(currentParent);
			currentParent = object;
			currentProperty = null;
		},
		onObjectProperty: (name) => {
			currentProperty = name;
		},
		onObjectEnd: () => {
			currentParent = previousParents.pop();
		},
		onArrayBegin: () => {
			const array = [];
			onValue(array);
			previousParents.push(currentParent);
			currentParent = array;
			currentProperty = null;
		},
		onArrayEnd: () => {
			currentParent = previousParents.pop();
		},
		onLiteralValue: onValue,
		onError: (error, offset, length) => {
			errors.push({
				error,
				offset,
				length
			});
		}
	}, options);
	return currentParent[0];
}
/**
* Gets the JSON path of the given JSON DOM node
*/
function getNodePath$1(node) {
	if (!node.parent || !node.parent.children) return [];
	const path = getNodePath$1(node.parent);
	if (node.parent.type === "property") {
		const key = node.parent.children[0].value;
		path.push(key);
	} else if (node.parent.type === "array") {
		const index = node.parent.children.indexOf(node);
		if (index !== -1) path.push(index);
	}
	return path;
}
/**
* Evaluates the JavaScript object of the given JSON DOM node
*/
function getNodeValue$1(node) {
	switch (node.type) {
		case "array": return node.children.map(getNodeValue$1);
		case "object":
			const obj = Object.create(null);
			for (let prop of node.children) {
				const valueNode = prop.children[1];
				if (valueNode) obj[prop.children[0].value] = getNodeValue$1(valueNode);
			}
			return obj;
		case "null":
		case "string":
		case "number":
		case "boolean": return node.value;
		default: return;
	}
}
function contains(node, offset, includeRightBound = false) {
	return offset >= node.offset && offset < node.offset + node.length || includeRightBound && offset === node.offset + node.length;
}
/**
* Finds the most inner node at the given offset. If includeRightBound is set, also finds nodes that end at the given offset.
*/
function findNodeAtOffset$1(node, offset, includeRightBound = false) {
	if (contains(node, offset, includeRightBound)) {
		const children = node.children;
		if (Array.isArray(children)) for (let i = 0; i < children.length && children[i].offset <= offset; i++) {
			const item = findNodeAtOffset$1(children[i], offset, includeRightBound);
			if (item) return item;
		}
		return node;
	}
}
/**
* Parses the given text and invokes the visitor functions for each object, array and literal reached.
*/
function visit$1(text, visitor, options = ParseOptions.DEFAULT) {
	const _scanner = createScanner$1(text, false);
	const _jsonPath = [];
	let suppressedCallbacks = 0;
	function toNoArgVisit(visitFunction) {
		return visitFunction ? () => suppressedCallbacks === 0 && visitFunction(_scanner.getTokenOffset(), _scanner.getTokenLength(), _scanner.getTokenStartLine(), _scanner.getTokenStartCharacter()) : () => true;
	}
	function toOneArgVisit(visitFunction) {
		return visitFunction ? (arg) => suppressedCallbacks === 0 && visitFunction(arg, _scanner.getTokenOffset(), _scanner.getTokenLength(), _scanner.getTokenStartLine(), _scanner.getTokenStartCharacter()) : () => true;
	}
	function toOneArgVisitWithPath(visitFunction) {
		return visitFunction ? (arg) => suppressedCallbacks === 0 && visitFunction(arg, _scanner.getTokenOffset(), _scanner.getTokenLength(), _scanner.getTokenStartLine(), _scanner.getTokenStartCharacter(), () => _jsonPath.slice()) : () => true;
	}
	function toBeginVisit(visitFunction) {
		return visitFunction ? () => {
			if (suppressedCallbacks > 0) suppressedCallbacks++;
			else if (visitFunction(_scanner.getTokenOffset(), _scanner.getTokenLength(), _scanner.getTokenStartLine(), _scanner.getTokenStartCharacter(), () => _jsonPath.slice()) === false) suppressedCallbacks = 1;
		} : () => true;
	}
	function toEndVisit(visitFunction) {
		return visitFunction ? () => {
			if (suppressedCallbacks > 0) suppressedCallbacks--;
			if (suppressedCallbacks === 0) visitFunction(_scanner.getTokenOffset(), _scanner.getTokenLength(), _scanner.getTokenStartLine(), _scanner.getTokenStartCharacter());
		} : () => true;
	}
	const onObjectBegin = toBeginVisit(visitor.onObjectBegin), onObjectProperty = toOneArgVisitWithPath(visitor.onObjectProperty), onObjectEnd = toEndVisit(visitor.onObjectEnd), onArrayBegin = toBeginVisit(visitor.onArrayBegin), onArrayEnd = toEndVisit(visitor.onArrayEnd), onLiteralValue = toOneArgVisitWithPath(visitor.onLiteralValue), onSeparator = toOneArgVisit(visitor.onSeparator), onComment = toNoArgVisit(visitor.onComment), onError = toOneArgVisit(visitor.onError);
	const disallowComments = options && options.disallowComments;
	const allowTrailingComma = options && options.allowTrailingComma;
	function scanNext() {
		while (true) {
			const token = _scanner.scan();
			switch (_scanner.getTokenError()) {
				case 4:
					handleError(14);
					break;
				case 5:
					handleError(15);
					break;
				case 3:
					handleError(13);
					break;
				case 1:
					if (!disallowComments) handleError(11);
					break;
				case 2:
					handleError(12);
					break;
				case 6:
					handleError(16);
					break;
			}
			switch (token) {
				case 12:
				case 13:
					if (disallowComments) handleError(10);
					else onComment();
					break;
				case 16:
					handleError(1);
					break;
				case 15:
				case 14: break;
				default: return token;
			}
		}
	}
	function handleError(error, skipUntilAfter = [], skipUntil = []) {
		onError(error);
		if (skipUntilAfter.length + skipUntil.length > 0) {
			let token = _scanner.getToken();
			while (token !== 17) {
				if (skipUntilAfter.indexOf(token) !== -1) {
					scanNext();
					break;
				} else if (skipUntil.indexOf(token) !== -1) break;
				token = scanNext();
			}
		}
	}
	function parseString(isValue) {
		const value = _scanner.getTokenValue();
		if (isValue) onLiteralValue(value);
		else {
			onObjectProperty(value);
			_jsonPath.push(value);
		}
		scanNext();
		return true;
	}
	function parseLiteral() {
		switch (_scanner.getToken()) {
			case 11:
				const tokenValue = _scanner.getTokenValue();
				let value = Number(tokenValue);
				if (isNaN(value)) {
					handleError(2);
					value = 0;
				}
				onLiteralValue(value);
				break;
			case 7:
				onLiteralValue(null);
				break;
			case 8:
				onLiteralValue(true);
				break;
			case 9:
				onLiteralValue(false);
				break;
			default: return false;
		}
		scanNext();
		return true;
	}
	function parseProperty() {
		if (_scanner.getToken() !== 10) {
			handleError(3, [], [2, 5]);
			return false;
		}
		parseString(false);
		if (_scanner.getToken() === 6) {
			onSeparator(":");
			scanNext();
			if (!parseValue()) handleError(4, [], [2, 5]);
		} else handleError(5, [], [2, 5]);
		_jsonPath.pop();
		return true;
	}
	function parseObject() {
		onObjectBegin();
		scanNext();
		let needsComma = false;
		while (_scanner.getToken() !== 2 && _scanner.getToken() !== 17) {
			if (_scanner.getToken() === 5) {
				if (!needsComma) handleError(4, [], []);
				onSeparator(",");
				scanNext();
				if (_scanner.getToken() === 2 && allowTrailingComma) break;
			} else if (needsComma) handleError(6, [], []);
			if (!parseProperty()) handleError(4, [], [2, 5]);
			needsComma = true;
		}
		onObjectEnd();
		if (_scanner.getToken() !== 2) handleError(7, [2], []);
		else scanNext();
		return true;
	}
	function parseArray() {
		onArrayBegin();
		scanNext();
		let isFirstElement = true;
		let needsComma = false;
		while (_scanner.getToken() !== 4 && _scanner.getToken() !== 17) {
			if (_scanner.getToken() === 5) {
				if (!needsComma) handleError(4, [], []);
				onSeparator(",");
				scanNext();
				if (_scanner.getToken() === 4 && allowTrailingComma) break;
			} else if (needsComma) handleError(6, [], []);
			if (isFirstElement) {
				_jsonPath.push(0);
				isFirstElement = false;
			} else _jsonPath[_jsonPath.length - 1]++;
			if (!parseValue()) handleError(4, [], [4, 5]);
			needsComma = true;
		}
		onArrayEnd();
		if (!isFirstElement) _jsonPath.pop();
		if (_scanner.getToken() !== 4) handleError(8, [4], []);
		else scanNext();
		return true;
	}
	function parseValue() {
		switch (_scanner.getToken()) {
			case 3: return parseArray();
			case 1: return parseObject();
			case 10: return parseString(true);
			default: return parseLiteral();
		}
	}
	scanNext();
	if (_scanner.getToken() === 17) {
		if (options.allowEmptyContent) return true;
		handleError(4, [], []);
		return false;
	}
	if (!parseValue()) {
		handleError(4, [], []);
		return false;
	}
	if (_scanner.getToken() !== 17) handleError(9, [], []);
	return true;
}
var ScanError;
(function(ScanError) {
	ScanError[ScanError["None"] = 0] = "None";
	ScanError[ScanError["UnexpectedEndOfComment"] = 1] = "UnexpectedEndOfComment";
	ScanError[ScanError["UnexpectedEndOfString"] = 2] = "UnexpectedEndOfString";
	ScanError[ScanError["UnexpectedEndOfNumber"] = 3] = "UnexpectedEndOfNumber";
	ScanError[ScanError["InvalidUnicode"] = 4] = "InvalidUnicode";
	ScanError[ScanError["InvalidEscapeCharacter"] = 5] = "InvalidEscapeCharacter";
	ScanError[ScanError["InvalidCharacter"] = 6] = "InvalidCharacter";
})(ScanError || (ScanError = {}));
var SyntaxKind;
(function(SyntaxKind) {
	SyntaxKind[SyntaxKind["OpenBraceToken"] = 1] = "OpenBraceToken";
	SyntaxKind[SyntaxKind["CloseBraceToken"] = 2] = "CloseBraceToken";
	SyntaxKind[SyntaxKind["OpenBracketToken"] = 3] = "OpenBracketToken";
	SyntaxKind[SyntaxKind["CloseBracketToken"] = 4] = "CloseBracketToken";
	SyntaxKind[SyntaxKind["CommaToken"] = 5] = "CommaToken";
	SyntaxKind[SyntaxKind["ColonToken"] = 6] = "ColonToken";
	SyntaxKind[SyntaxKind["NullKeyword"] = 7] = "NullKeyword";
	SyntaxKind[SyntaxKind["TrueKeyword"] = 8] = "TrueKeyword";
	SyntaxKind[SyntaxKind["FalseKeyword"] = 9] = "FalseKeyword";
	SyntaxKind[SyntaxKind["StringLiteral"] = 10] = "StringLiteral";
	SyntaxKind[SyntaxKind["NumericLiteral"] = 11] = "NumericLiteral";
	SyntaxKind[SyntaxKind["LineCommentTrivia"] = 12] = "LineCommentTrivia";
	SyntaxKind[SyntaxKind["BlockCommentTrivia"] = 13] = "BlockCommentTrivia";
	SyntaxKind[SyntaxKind["LineBreakTrivia"] = 14] = "LineBreakTrivia";
	SyntaxKind[SyntaxKind["Trivia"] = 15] = "Trivia";
	SyntaxKind[SyntaxKind["Unknown"] = 16] = "Unknown";
	SyntaxKind[SyntaxKind["EOF"] = 17] = "EOF";
})(SyntaxKind || (SyntaxKind = {}));
/**
* Parses the given text and returns the object the JSON content represents. On invalid input, the parser tries to be as fault tolerant as possible, but still return a result.
* Therefore, always check the errors list to find out if the input was valid.
*/
const parse$1 = parse$2;
var ParseErrorCode;
(function(ParseErrorCode) {
	ParseErrorCode[ParseErrorCode["InvalidSymbol"] = 1] = "InvalidSymbol";
	ParseErrorCode[ParseErrorCode["InvalidNumberFormat"] = 2] = "InvalidNumberFormat";
	ParseErrorCode[ParseErrorCode["PropertyNameExpected"] = 3] = "PropertyNameExpected";
	ParseErrorCode[ParseErrorCode["ValueExpected"] = 4] = "ValueExpected";
	ParseErrorCode[ParseErrorCode["ColonExpected"] = 5] = "ColonExpected";
	ParseErrorCode[ParseErrorCode["CommaExpected"] = 6] = "CommaExpected";
	ParseErrorCode[ParseErrorCode["CloseBraceExpected"] = 7] = "CloseBraceExpected";
	ParseErrorCode[ParseErrorCode["CloseBracketExpected"] = 8] = "CloseBracketExpected";
	ParseErrorCode[ParseErrorCode["EndOfFileExpected"] = 9] = "EndOfFileExpected";
	ParseErrorCode[ParseErrorCode["InvalidCommentToken"] = 10] = "InvalidCommentToken";
	ParseErrorCode[ParseErrorCode["UnexpectedEndOfComment"] = 11] = "UnexpectedEndOfComment";
	ParseErrorCode[ParseErrorCode["UnexpectedEndOfString"] = 12] = "UnexpectedEndOfString";
	ParseErrorCode[ParseErrorCode["UnexpectedEndOfNumber"] = 13] = "UnexpectedEndOfNumber";
	ParseErrorCode[ParseErrorCode["InvalidUnicode"] = 14] = "InvalidUnicode";
	ParseErrorCode[ParseErrorCode["InvalidEscapeCharacter"] = 15] = "InvalidEscapeCharacter";
	ParseErrorCode[ParseErrorCode["InvalidCharacter"] = 16] = "InvalidCharacter";
})(ParseErrorCode || (ParseErrorCode = {}));
function printParseErrorCode(code) {
	switch (code) {
		case 1: return "InvalidSymbol";
		case 2: return "InvalidNumberFormat";
		case 3: return "PropertyNameExpected";
		case 4: return "ValueExpected";
		case 5: return "ColonExpected";
		case 6: return "CommaExpected";
		case 7: return "CloseBraceExpected";
		case 8: return "CloseBracketExpected";
		case 9: return "EndOfFileExpected";
		case 10: return "InvalidCommentToken";
		case 11: return "UnexpectedEndOfComment";
		case 12: return "UnexpectedEndOfString";
		case 13: return "UnexpectedEndOfNumber";
		case 14: return "InvalidUnicode";
		case 15: return "InvalidEscapeCharacter";
		case 16: return "InvalidCharacter";
	}
	return "<unknown ParseErrorCode>";
}
performance.mark("js-parse-end:BlobEditor-b_h3z-tU.js");
/**
* @source https://github.com/remix-run/react-router/issues/8139#issuecomment-1021457943
*/
function usePrompt(message, when = true) {
	return useIsDataRouterEnabled() ? usePromptDataRouter(message, when) : usePromptJSONRoute(message, when);
}
/**
* @source https://github.com/remix-run/react-router/blob/00cb4d7b310663b2e84152700c05d3b503005e83/packages/react-router/lib/dom/lib.tsx#L3282
*/
function usePromptDataRouter(message, t0) {
	const $ = c(16);
	const when = t0 === void 0 ? true : t0;
	const blocker = useBlocker$1(when);
	let t1;
	if ($[0] !== blocker) {
		t1 = () => {
			blocker.reset?.();
			document.dispatchEvent(new Event(SOFT_NAV_STATE.END));
			document.dispatchEvent(new Event(SOFT_NAV_STATE.PROGRESS_BAR.END));
		};
		$[0] = blocker;
		$[1] = t1;
	} else t1 = $[1];
	const resetBlocker = useEffectEvent(t1);
	let t2;
	if ($[2] !== blocker || $[3] !== message || $[4] !== resetBlocker) {
		t2 = () => {
			if (blocker.state === "blocked") if (window.confirm(message)) {
				const timeoutId = setTimeout(() => {
					blocker.proceed?.();
				}, 0);
				return () => clearTimeout(timeoutId);
			} else resetBlocker();
		};
		$[2] = blocker;
		$[3] = message;
		$[4] = resetBlocker;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== blocker || $[7] !== message) {
		t3 = [blocker, message];
		$[6] = blocker;
		$[7] = message;
		$[8] = t3;
	} else t3 = $[8];
	useEffect(t2, t3);
	let t4;
	if ($[9] !== blocker.state || $[10] !== resetBlocker || $[11] !== when) {
		t4 = () => {
			if (blocker.state === "blocked" && !when) resetBlocker();
		};
		$[9] = blocker.state;
		$[10] = resetBlocker;
		$[11] = when;
		$[12] = t4;
	} else t4 = $[12];
	let t5;
	if ($[13] !== blocker || $[14] !== when) {
		t5 = [blocker, when];
		$[13] = blocker;
		$[14] = when;
		$[15] = t5;
	} else t5 = $[15];
	useEffect(t4, t5);
}
function usePromptJSONRoute(message, t0) {
	const $ = c(2);
	const when = t0 === void 0 ? true : t0;
	let t1;
	if ($[0] !== message) {
		t1 = (tx) => {
			if (window.confirm(message)) tx.retry();
			else {
				document.dispatchEvent(new Event(SOFT_NAV_STATE.END));
				document.dispatchEvent(new Event(SOFT_NAV_STATE.PROGRESS_BAR.END));
			}
		};
		$[0] = message;
		$[1] = t1;
	} else t1 = $[1];
	return useBlockerLegacy(t1, message, when);
}
function emitToCodeMirror(event, editorTarget, detail) {
	if (!editorTarget) return;
	const innerEditorTarget = editorTarget.className.includes("cm-content") ? editorTarget : editorTarget.querySelector(".cm-content");
	if (!innerEditorTarget) return;
	innerEditorTarget.dispatchEvent(new CustomEvent(event, { detail }));
}
var CodeEditorExtensions = class CodeEditorExtensions {
	static #parseDiscoveredSecrets(fileContents, discoveredSecrets) {
		const secrets = JSON.parse(discoveredSecrets);
		if (secrets.length === 0 || secrets[0].locations?.length === 0) return null;
		const location = secrets[0].locations[0];
		const lines = fileContents.split(/\r?\n/);
		const normalizedStartLine = location.start_line || location.startLine;
		const normalizedEndLine = location.end_line || location.endLine;
		const normalizedStartBytePosition = location.start_line_byte_position || location.startLineBytePosition || 0;
		const normalizedEndBytePosition = location.end_line_byte_position || location.endLineBytePosition;
		const startLine = normalizedStartLine - 1;
		const endLine = normalizedEndLine - 1;
		if (startLine > endLine || startLine < 0 || endLine > lines.length) return;
		if (!lines[startLine] || !lines[endLine]) return;
		return {
			startLine,
			endLine,
			startLineCharacter: GetCharIndexFromBytePosition(lines[startLine], normalizedStartBytePosition),
			endLineCharacter: GetCharIndexFromBytePosition(lines[endLine], normalizedEndBytePosition)
		};
	}
	static #parseSingleSecret(fileContents, startLine, endLine, startLineBytePosition, endLineBytePosition) {
		const lines = fileContents.split(/\r?\n/);
		startLine--;
		endLine--;
		if (startLine > endLine || startLine < 0 || endLine > lines.length) return;
		if (!lines[startLine] || !lines[endLine]) return;
		return {
			parsedStartLine: startLine,
			parsedEndLine: endLine,
			startLineCharacter: GetCharIndexFromBytePosition(lines[startLine] || "", startLineBytePosition),
			endLineCharacter: GetCharIndexFromBytePosition(lines[endLine] || "", endLineBytePosition)
		};
	}
	static annotateDiscoveredSecrets(codeEditor, discoveredSecrets) {
		if (!codeEditor) return;
		const secrets = CodeEditorExtensions.#parseDiscoveredSecrets(codeEditor.getValue(), discoveredSecrets);
		if (!secrets) return;
		const { startLine, endLine, startLineCharacter, endLineCharacter } = secrets;
		codeEditor.markText({
			line: startLine,
			ch: startLineCharacter
		}, {
			line: endLine,
			ch: endLineCharacter
		}, { className: "CodeMirror-lint-mark-error" });
	}
	static emitAnnotateDiscoveredSecrets(fileContents, discoveredSecrets, target) {
		const secrets = CodeEditorExtensions.#parseDiscoveredSecrets(fileContents, discoveredSecrets);
		if (!secrets) return;
		const { startLine, endLine, startLineCharacter, endLineCharacter } = secrets;
		emitToCodeMirror("secret-detected:lint", target, {
			from: {
				lineNumber: startLine,
				character: startLineCharacter
			},
			to: {
				lineNumber: endLine,
				character: endLineCharacter
			},
			severity: "error"
		});
	}
	static emitAnnotateDiscoveredSecretsWithLocation(fileContents, startLine, endLine, startLineBytePosition, endLineBytePosition, target) {
		const parsed = CodeEditorExtensions.#parseSingleSecret(fileContents, startLine, endLine, startLineBytePosition, endLineBytePosition);
		if (!parsed) return;
		const { parsedStartLine, parsedEndLine, startLineCharacter, endLineCharacter } = parsed;
		emitToCodeMirror("secret-detected:lint", target, {
			from: {
				lineNumber: parsedStartLine,
				character: startLineCharacter
			},
			to: {
				lineNumber: parsedEndLine,
				character: endLineCharacter
			},
			severity: "error"
		});
	}
};
var BypassReason = {
	FalsePositive: "false_positive",
	UsedInTests: "used_in_tests",
	WillFixLater: "will_fix_later"
};
var AllowSecretBody_module_default = {
	Box: "AllowSecretBody-module_ilA6zq_Box",
	Box_1: "AllowSecretBody-module_ilA6zq_Box_1",
	Box_2: "AllowSecretBody-module_ilA6zq_Box_2",
	Box_3: "AllowSecretBody-module_ilA6zq_Box_3",
	Box_4: "AllowSecretBody-module_ilA6zq_Box_4",
	Box_5: "AllowSecretBody-module_ilA6zq_Box_5",
	Flash: "AllowSecretBody-module_ilA6zq_Flash",
	Link: "AllowSecretBody-module_ilA6zq_Link",
	Octicon: "AllowSecretBody-module_ilA6zq_Octicon",
	Text: "AllowSecretBody-module_ilA6zq_Text"
};
function AllowSecretBody({ onRadioGroupChange, bypassMetadata, helpUrl, isCliExperience, secretLocationHref, onClickSecretLocationLink }) {
	const resolvingBlockedCommitHelpUrl = isCliExperience ? `${helpUrl}/code-security/secret-scanning/working-with-secret-scanning-and-push-protection/working-with-push-protection-from-the-command-line#resolving-a-blocked-push` : `${helpUrl}/code-security/secret-scanning/working-with-secret-scanning-and-push-protection/working-with-push-protection-in-the-github-ui#resolving-a-blocked-commit`;
	const repoPushProtectionUrl = `${helpUrl}/code-security/secret-scanning/protecting-pushes-with-secret-scanning`;
	const userPushProtectionUrl = `${helpUrl}/code-security/secret-scanning/working-with-secret-scanning-and-push-protection/push-protection-for-users`;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Flash, {
		variant: "danger",
		className: AllowSecretBody_module_default.Flash,
		children: /* @__PURE__ */ jsxs("div", {
			className: AllowSecretBody_module_default.Box,
			children: [/* @__PURE__ */ jsx(Octicon, {
				icon: StopIcon,
				className: AllowSecretBody_module_default.Octicon
			}), /* @__PURE__ */ jsxs("div", { children: [
				/* @__PURE__ */ jsx(Link, {
					href: bypassMetadata.limited_user_bypass_experience_only ? userPushProtectionUrl : repoPushProtectionUrl,
					target: "_blank",
					inline: true,
					children: "Secret scanning"
				}),
				"\xA0found a ",
				bypassMetadata.is_custom_pattern && " custom pattern named ",
				/* @__PURE__ */ jsx("b", { children: bypassMetadata.token_label }),
				bypassMetadata.is_custom_pattern ? ", defined by your admins," : " secret",
				isCliExperience && " in your attempted push",
				bypassMetadata.first_secret_location && /* @__PURE__ */ jsxs(Fragment$1, { children: [
					"\xA0on",
					" ",
					/* @__PURE__ */ jsxs(Link, {
						href: secretLocationHref,
						inline: true,
						onClick: onClickSecretLocationLink,
						className: AllowSecretBody_module_default.Link,
						children: ["line ", bypassMetadata.first_secret_location.start_line]
					})
				] }),
				".\xA0"
			] })]
		})
	}), bypassMetadata.use_delegated_bypass_flow ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
		className: AllowSecretBody_module_default.Box_1,
		children: [/* @__PURE__ */ jsx("span", {
			className: AllowSecretBody_module_default.Text,
			children: "Remove detected secrets"
		}), bypassMetadata.push_protection_custom_message ? /* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsx(Link, {
				href: bypassMetadata.push_protection_custom_message?.message,
				target: "_blank",
				inline: true,
				children: "Review guidance"
			}),
			" ",
			"from ",
			/* @__PURE__ */ jsx("b", { children: bypassMetadata.push_protection_custom_message?.owner_name }),
			" and",
			" ",
			/* @__PURE__ */ jsx(Link, {
				href: resolvingBlockedCommitHelpUrl,
				inline: true,
				children: "remove any detected secrets"
			}),
			" ",
			/* @__PURE__ */ jsx("span", { children: "from your commit and commit history." })
		] }) : /* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsx(Link, {
				href: resolvingBlockedCommitHelpUrl,
				inline: true,
				children: "Remove any detected secrets"
			}),
			" ",
			/* @__PURE__ */ jsx("span", { children: "from your commit and commit history." })
		] })]
	}), /* @__PURE__ */ jsxs("div", {
		className: AllowSecretBody_module_default.Box_2,
		children: [/* @__PURE__ */ jsx("span", {
			className: AllowSecretBody_module_default.Text,
			children: "Or request bypass privileges"
		}), /* @__PURE__ */ jsx("span", { children: "Submit a request to bypass these push protections. If granted, you may attempt this push again." })]
	})] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs("div", {
			className: AllowSecretBody_module_default.Box_3,
			children: [
				/* @__PURE__ */ jsx("span", { children: " Allowing this secret risks exposure. Instead, " }),
				bypassMetadata.push_protection_custom_message && /* @__PURE__ */ jsxs("span", { children: [
					/* @__PURE__ */ jsx(Link, {
						href: bypassMetadata.push_protection_custom_message?.message,
						target: "_blank",
						inline: true,
						children: "review guidance"
					}),
					" ",
					"from ",
					/* @__PURE__ */ jsx("b", { children: bypassMetadata.push_protection_custom_message?.owner_name }),
					" and",
					" "
				] }),
				/* @__PURE__ */ jsxs("span", { children: [
					"consider",
					" ",
					/* @__PURE__ */ jsx(Link, {
						href: resolvingBlockedCommitHelpUrl,
						target: "_blank",
						inline: true,
						children: "removing the secret from your commit and commit history"
					}),
					"."
				] })
			]
		}),
		/* @__PURE__ */ jsxs("div", {
			className: AllowSecretBody_module_default.Box_4,
			children: [/* @__PURE__ */ jsx("span", { children: " Exposing this secret can allow someone to: " }), /* @__PURE__ */ jsxs("ul", {
				className: "tmp-mx-4",
				children: [
					!bypassMetadata.is_custom_pattern && /* @__PURE__ */ jsxs("li", { children: [
						"Verify the identity of this ",
						/* @__PURE__ */ jsx("b", { children: bypassMetadata.token_label }),
						" secret"
					] }),
					/* @__PURE__ */ jsx("li", { children: "Know which resources this secret can access" }),
					/* @__PURE__ */ jsx("li", { children: "Act on behalf of the secret's owner" }),
					bypassMetadata.repo_has_secret_scanning_experience && /* @__PURE__ */ jsx("li", { children: "Push this secret to this repository without being blocked" })
				]
			})]
		}),
		/* @__PURE__ */ jsx("div", {
			className: AllowSecretBody_module_default.Box_5,
			children: bypassMetadata.limited_user_bypass_experience_only && /* @__PURE__ */ jsxs("span", { children: [
				" ",
				"Push protection is enabled for your account. To disable, visit your",
				" ",
				/* @__PURE__ */ jsx(Link, {
					href: "/settings/security_analysis",
					target: "_blank",
					inline: true,
					children: "code security settings"
				}),
				"."
			] })
		}),
		/* @__PURE__ */ jsx("hr", { className: "tmp-my-4" }),
		!bypassMetadata.limited_user_bypass_experience_only && /* @__PURE__ */ jsx("div", {
			className: AllowSecretBody_module_default.Box_3,
			children: /* @__PURE__ */ jsxs(RadioGroup_default, {
				name: "bypass-reason",
				onChange: onRadioGroupChange,
				children: [
					/* @__PURE__ */ jsx(RadioGroup_default.Label, {
						visuallyHidden: true,
						children: "Bypass reason"
					}),
					/* @__PURE__ */ jsxs(FormControl$1, { children: [
						/* @__PURE__ */ jsx(Radio, { value: BypassReason.UsedInTests }),
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "It's used in tests" }),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "The secret poses no risk. If anyone finds it, they cannot do any damage or gain access to sensitive information." })
					] }),
					/* @__PURE__ */ jsxs(FormControl$1, { children: [
						/* @__PURE__ */ jsx(Radio, { value: BypassReason.FalsePositive }),
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "It's a false positive" }),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "The detected string is not a secret." })
					] }),
					/* @__PURE__ */ jsxs(FormControl$1, { children: [
						/* @__PURE__ */ jsx(Radio, { value: BypassReason.WillFixLater }),
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "I'll fix it later" }),
						/* @__PURE__ */ jsxs(FormControl$1.Caption, { children: [
							"The secret is real, ",
							/* @__PURE__ */ jsx("b", { children: "I understand the risk" }),
							", and I will need to revoke it. This will open a security alert and notify admins of this repository."
						] })
					] })
				]
			})
		})
	] })] });
}
AllowSecretBody.displayName = "AllowSecretBody";
var promotePushProtectionBypassPath = ({ ownerDisplayLogin, repoName, ksuid }) => `/${encodePart(ownerDisplayLogin)}/${encodePart(repoName)}/security/secret-scanning/unblock-secret/${ksuid}`;
var requestPushProtectionBypassPath = ({ ownerDisplayLogin, repoName, ksuid, ruleSuiteId }) => {
	const hashId = Buffer.from(encodeURI(`secret_scanning-${ruleSuiteId}-${ksuid}`)).toString("base64");
	return `/${encodePart(ownerDisplayLogin)}/${encodePart(repoName)}/secret_scanning/exemptions/new/${hashId}`;
};
var SecretDetectedDialogBlob_module_default = {
	Box: "SecretDetectedDialogBlob-module_eFsQwW_Box",
	Box_1: "SecretDetectedDialogBlob-module_eFsQwW_Box_1",
	Button: "SecretDetectedDialogBlob-module_eFsQwW_Button",
	Flash: "SecretDetectedDialogBlob-module_eFsQwW_Flash",
	secretScanningDialog: "SecretDetectedDialogBlob-module_eFsQwW_secretScanningDialog"
};
function SecretDetectedDialogBlob(t0) {
	const $ = c(21);
	const { bypassMetadata, content, helpUrl } = t0;
	const [isOpen, setIsOpen] = useState(true);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => setIsOpen(false);
		$[0] = t1;
	} else t1 = $[0];
	const closeOverlay = t1;
	const [selectedRadioValue, setSelectedRadioValue] = React.useState("");
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (selected) => {
			setSelectedRadioValue(selected ?? "");
		};
		$[1] = t2;
	} else t2 = $[1];
	const handleRadioGroupChange = t2;
	let t3;
	if ($[2] !== bypassMetadata.owner_display_login || $[3] !== bypassMetadata.placeholder_ksuid || $[4] !== bypassMetadata.repo_name) {
		t3 = promotePushProtectionBypassPath({
			ownerDisplayLogin: bypassMetadata.owner_display_login,
			repoName: bypassMetadata.repo_name,
			ksuid: bypassMetadata.placeholder_ksuid
		});
		$[2] = bypassMetadata.owner_display_login;
		$[3] = bypassMetadata.placeholder_ksuid;
		$[4] = bypassMetadata.repo_name;
		$[5] = t3;
	} else t3 = $[5];
	const promoteBypassPath = t3;
	const requestBypassPath = requestPushProtectionBypassPath({
		ownerDisplayLogin: bypassMetadata.owner_display_login,
		repoName: bypassMetadata.repo_name,
		ksuid: bypassMetadata.placeholder_ksuid,
		ruleSuiteId: bypassMetadata.rule_suite_id || 0
	});
	let t4;
	if ($[6] !== bypassMetadata || $[7] !== selectedRadioValue) {
		t4 = [
			"secret-scanning",
			bypassMetadata,
			selectedRadioValue
		];
		$[6] = bypassMetadata;
		$[7] = selectedRadioValue;
		$[8] = t4;
	} else t4 = $[8];
	let t5;
	if ($[9] !== bypassMetadata.limited_user_bypass_experience_only || $[10] !== bypassMetadata.placeholder_ksuid || $[11] !== content || $[12] !== promoteBypassPath || $[13] !== selectedRadioValue) {
		t5 = async () => {
			const data = {
				value: content,
				reason: bypassMetadata.limited_user_bypass_experience_only ? BypassReason.WillFixLater : selectedRadioValue,
				bypass_placeholder_ksuid: bypassMetadata.placeholder_ksuid,
				parent_action: "edit"
			};
			const formData = new FormData();
			for (const [key, dataValue] of Object.entries(data)) if (dataValue !== void 0) formData.set(key, dataValue);
			const result = await verifiedFetch(promoteBypassPath, {
				method: "post",
				body: formData,
				headers: { Accept: "application/json" }
			});
			closeOverlay();
			if (!result.ok) throw new Error("Failed to promote bypass: request failed");
			return result;
		};
		$[9] = bypassMetadata.limited_user_bypass_experience_only;
		$[10] = bypassMetadata.placeholder_ksuid;
		$[11] = content;
		$[12] = promoteBypassPath;
		$[13] = selectedRadioValue;
		$[14] = t5;
	} else t5 = $[14];
	let t6;
	if ($[15] !== t4 || $[16] !== t5) {
		t6 = {
			queryKey: t4,
			queryFn: t5,
			enabled: false,
			retry: false
		};
		$[15] = t4;
		$[16] = t5;
		$[17] = t6;
	} else t6 = $[17];
	const { isSuccess: unblockSecretSuccess, isError: unblockSecretFailed, refetch: bypassSecret } = useQuery(t6);
	let t7;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = () => {
			setIsOpen(true);
			setSelectedRadioValue("");
		};
		$[18] = t7;
	} else t7 = $[18];
	let t8;
	if ($[19] !== bypassMetadata) {
		t8 = [bypassMetadata];
		$[19] = bypassMetadata;
		$[20] = t8;
	} else t8 = $[20];
	useEffect(t7, t8);
	if (bypassMetadata.first_secret_location) {
		const codeMirrorEditorElement = document.querySelector(".js-codemirror-editor");
		CodeEditorExtensions.emitAnnotateDiscoveredSecretsWithLocation(content, bypassMetadata.first_secret_location?.start_line, bypassMetadata.first_secret_location?.end_line, bypassMetadata.first_secret_location?.start_line_byte_position, bypassMetadata.first_secret_location?.end_line_byte_position, codeMirrorEditorElement);
	}
	return jsxs(Fragment$1, { children: [
		!unblockSecretSuccess && jsx(Dialog_default, {
			className: `${SecretDetectedDialogBlob_module_default.secretScanningDialog}`,
			isOpen,
			onDismiss: () => setIsOpen(false),
			"aria-labelledby": "secret-detected-header",
			children: jsxs("div", {
				className: SecretDetectedDialogBlob_module_default.Box,
				children: [jsx(AllowSecretBody, {
					onRadioGroupChange: handleRadioGroupChange,
					bypassMetadata,
					helpUrl,
					secretLocationHref: bypassMetadata.first_secret_location ? `#L${bypassMetadata.first_secret_location.start_line}` : void 0,
					onClickSecretLocationLink: closeOverlay
				}), jsx("div", {
					className: SecretDetectedDialogBlob_module_default.Box_1,
					children: bypassMetadata.use_delegated_bypass_flow ? jsx(ButtonComponent, {
						variant: "default",
						as: "a",
						href: requestBypassPath,
						target: "_blank",
						children: "Start request"
					}) : jsxs(Fragment$1, { children: [jsx(ButtonComponent, {
						onClick: closeOverlay,
						className: SecretDetectedDialogBlob_module_default.Button,
						children: "Cancel"
					}), jsx(ButtonComponent, {
						variant: "primary",
						disabled: bypassMetadata.limited_user_bypass_experience_only ? false : !selectedRadioValue || selectedRadioValue.length === 0,
						onClick: () => {
							bypassSecret();
						},
						children: "Allow Secret"
					})] })
				})]
			})
		}),
		unblockSecretSuccess && jsxs(Flash, {
			variant: "success",
			className: SecretDetectedDialogBlob_module_default.Flash,
			children: [jsx(Octicon, { icon: CheckIcon }), "Secret allowed. You can now commit these changes."]
		}),
		unblockSecretFailed && jsx(Flash, {
			variant: "danger",
			className: SecretDetectedDialogBlob_module_default.Flash,
			children: "An error occurred when allowing your secret. Please try again."
		})
	] });
}
SecretDetectedDialogBlob.displayName = "SecretDetectedDialogBlob";
var CitationFileBanner_module_default = {
	Button: "CitationFileBanner-module_-F1YKq_Button",
	Flash: "CitationFileBanner-module_-F1YKq_Flash"
};
function CitationFileBanner({ citationHelpUrl, repositoryCitationTemplateUrl, setContent }) {
	const getTemplate = async () => {
		setContent(await (await fetch(repositoryCitationTemplateUrl, { headers: { ...getBaseFetchHeaders() } })).text());
	};
	return /* @__PURE__ */ jsxs(Flash, {
		className: CitationFileBanner_module_default.Flash,
		children: [/* @__PURE__ */ jsxs("div", { children: [
			"Adding a ",
			/* @__PURE__ */ jsx("strong", { children: "CITATION.cff" }),
			" file helps users to easily cite your software from the repository overview. \xA0",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: citationHelpUrl,
				children: "Learn more about CITATION files."
			})
		] }), /* @__PURE__ */ jsx(ButtonComponent, {
			onClick: getTemplate,
			className: CitationFileBanner_module_default.Button,
			children: "Insert example"
		})]
	});
}
CitationFileBanner.displayName = "CitationFileBanner";
var CustomSlashCommandsBanner_module_default = {
	Flash: "CustomSlashCommandsBanner-module_-4gl3G_Flash",
	Label: "CustomSlashCommandsBanner-module_-4gl3G_Label"
};
function CustomSlashCommandsBanner({ customSlashCommandsDocsUrl }) {
	const lifecycleLabelNameEnabled = isFeatureEnabled("lifecycle_label_name_updates");
	return /* @__PURE__ */ jsxs(Flash, {
		className: CustomSlashCommandsBanner_module_default.Flash,
		children: [
			lifecycleLabelNameEnabled ? /* @__PURE__ */ jsx(AlphaLabel, { className: "mr-2" }) : /* @__PURE__ */ jsx(Label, {
				variant: "success",
				className: CustomSlashCommandsBanner_module_default.Label,
				children: "Alpha"
			}),
			"Looks like this file is a custom slash command. Need help? Check out the",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: customSlashCommandsDocsUrl,
				children: "documentation"
			}),
			"."
		]
	});
}
CustomSlashCommandsBanner.displayName = "CustomSlashCommandsBanner";
var FundingBanner_module_default = { Flash: "FundingBanner-module_MOd6Aa_Flash" };
function FundingBanner({ repositoryFundingLinksEnabled, editRepoPath, helpPath }) {
	return /* @__PURE__ */ jsxs(Flash, {
		className: FundingBanner_module_default.Flash,
		children: [/* @__PURE__ */ jsxs("p", { children: [
			/* @__PURE__ */ jsx("code", { children: ".github/FUNDING.yml" }),
			" shows the community how to support this project. Please see our",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: `${helpPath}/articles/displaying-a-sponsor-button-in-your-repository`,
				children: "repository funding links documentation"
			}),
			" for more information on formatting and what is and isn't allowed in this file."
		] }), !repositoryFundingLinksEnabled && /* @__PURE__ */ jsxs("p", { children: [
			"Please note that funding links are currently ",
			/* @__PURE__ */ jsx("em", { children: "disabled" }),
			" on this repository. Visit",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: editRepoPath,
				children: "repository settings"
			}),
			" to enable display of your funding links."
		] })]
	});
}
FundingBanner.displayName = "FundingBanner";
var IssueTemplateBanners_module_default = {
	Flash: "IssueTemplateBanners-module_kpoeLW_Flash",
	Label: "IssueTemplateBanners-module_kpoeLW_Label"
};
var ISSUE_FORM_HELP_URL = "/communities/using-templates-to-encourage-useful-issues-and-pull-requests/configuring-issue-templates-for-your-repository#creating-issue-forms";
var ISSUE_TEMPLATE_CONFIG_URL = "/articles/configuring-issue-templates-for-your-repository#configuring-the-template-chooser";
var ISSUE_TEMPLATE_HELP_URL = "/articles/about-issue-and-pull-request-templates";
function IssueTemplateConfigBanner({ helpUrl }) {
	return /* @__PURE__ */ jsxs(Flash, {
		className: IssueTemplateBanners_module_default.Flash,
		children: [
			"Looks like this file is an ",
			/* @__PURE__ */ jsx("strong", { children: "issue template config" }),
			". Need help? Check out the",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: `${helpUrl}${ISSUE_TEMPLATE_CONFIG_URL}`,
				children: "documentation."
			})
		]
	});
}
IssueTemplateConfigBanner.displayName = "IssueTemplateConfigBanner";
function IssueTemplateLegacyBanner({ helpUrl }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className: IssueTemplateBanners_module_default.Flash,
		children: [
			"You are using an old version of issue templates. Please update to the new issue template workflow.",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: `${helpUrl}${ISSUE_TEMPLATE_HELP_URL}`,
				children: "Learn more about issue templates."
			})
		]
	});
}
IssueTemplateLegacyBanner.displayName = "IssueTemplateLegacyBanner";
function IssueTemplateValidBanner({ helpUrl, filePath }) {
	const isIssueForm = filePath.endsWith(".yml") || filePath.endsWith(".yaml");
	const issueHelpUrl = `${helpUrl}${isIssueForm ? ISSUE_FORM_HELP_URL : ISSUE_TEMPLATE_HELP_URL}`;
	const lifecycleLabelNameEnabled = isFeatureEnabled("lifecycle_label_name_updates");
	return /* @__PURE__ */ jsxs(Flash, {
		className: IssueTemplateBanners_module_default.Flash,
		children: [
			isIssueForm && (lifecycleLabelNameEnabled ? /* @__PURE__ */ jsx(BetaLabel, { className: "mr-2" }) : /* @__PURE__ */ jsx(Label, {
				variant: "success",
				className: IssueTemplateBanners_module_default.Label,
				children: "Beta"
			})),
			"Looks like this file is an issue template. Need help?",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: issueHelpUrl,
				children: "Learn more about issue templates."
			}),
			" ",
			isIssueForm && /* @__PURE__ */ jsx(Link, {
				href: "https://github.com/github/feedback/discussions/categories/issues-feedback",
				children: "Give feedback."
			})
		]
	});
}
IssueTemplateValidBanner.displayName = "IssueTemplateValidBanner";
function LeadingOrTrailingWhitespaceBanner() {
	return /* @__PURE__ */ jsx(Flash, {
		variant: "warning",
		className: "tmp-mb-3",
		children: "Parent directory contains leading or trailing whitespace."
	});
}
LeadingOrTrailingWhitespaceBanner.displayName = "LeadingOrTrailingWhitespaceBanner";
var MixedLineEndingsBanner_module_default = { Flash: "MixedLineEndingsBanner-module_s9qHwq_Flash" };
function MixedLineEndingsBanner() {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className: MixedLineEndingsBanner_module_default.Flash,
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			"We’ve detected the file has mixed line endings. When you commit changes we will normalize them to",
			" ",
			/* @__PURE__ */ jsx("strong", { children: "Windows-style" }),
			"(",
			/* @__PURE__ */ jsx("kbd", { children: "CR" }),
			/* @__PURE__ */ jsx("kbd", { children: "LF" }),
			")."
		]
	});
}
MixedLineEndingsBanner.displayName = "MixedLineEndingsBanner";
var ReadmeCalloutBanners_module_default = { Flash: "ReadmeCalloutBanners-module_YSBhNq_Flash" };
function ProfileReadmeBanner({ name, owner }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "success",
		className: ReadmeCalloutBanners_module_default.Flash,
		children: [
			/* @__PURE__ */ jsx("strong", { children: `${owner}/${name}` }),
			" is a special repository: its ",
			/* @__PURE__ */ jsx("code", { children: "README.md" }),
			" will appear on your profile!"
		]
	});
}
ProfileReadmeBanner.displayName = "ProfileReadmeBanner";
function OrgProfileReadmeBanner({ name, owner }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "success",
		className: ReadmeCalloutBanners_module_default.Flash,
		children: [
			/* @__PURE__ */ jsx("strong", { children: `${owner}/${name}` }),
			" is a special repository: this ",
			/* @__PURE__ */ jsx("code", { children: "README.md" }),
			" will appear on your public organization profile, visible to anyone."
		]
	});
}
OrgProfileReadmeBanner.displayName = "OrgProfileReadmeBanner";
function OrgMemberProfileReadmeBanner({ name, owner }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "success",
		className: ReadmeCalloutBanners_module_default.Flash,
		children: [
			/* @__PURE__ */ jsx("strong", { children: `${owner}/${name}` }),
			" is a special repository: this ",
			/* @__PURE__ */ jsx("code", { children: "README.md" }),
			" will appear on your organization member profile, visible only to organization members."
		]
	});
}
OrgMemberProfileReadmeBanner.displayName = "OrgMemberProfileReadmeBanner";
var TranscodingBanner_module_default = { Flash: "TranscodingBanner-module_2TVleG_Flash" };
function TranscodingBanner({ detectedEncoding }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className: TranscodingBanner_module_default.Flash,
		children: [
			/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
			"We’ve detected the file encoding as ",
			/* @__PURE__ */ jsx("strong", { children: detectedEncoding }),
			". When you commit changes we will transcode it to ",
			/* @__PURE__ */ jsx("strong", { children: "UTF-8" }),
			"."
		]
	});
}
TranscodingBanner.displayName = "TranscodingBanner";
var citationRegex = /^CITATION\.cff$/i;
var readmeRegex = /^README\.md$/i;
var profileReadmeRegex = /^profile\/README\.md$/i;
function BlobEditorBanners(t0) {
	const $ = c(27);
	const { content, editInfo, webCommitInfo, filePath, fileName, hasLeadingOrTrailingWhitespaceInPath, isIssueTemplate, isLegacyIssueTemplate, secretDetected, secretBypassMetadata, onSetContent } = t0;
	const repo = useCurrentRepository();
	const { helpUrl } = useReposAppPayload();
	const banners = editInfo.banners;
	let t1;
	if ($[0] !== banners.citationHelpUrl || $[1] !== banners.editRepoPath || $[2] !== banners.hasMixedLineEndings || $[3] !== banners.orgMemberProfileReadmeCalloutEnabled || $[4] !== banners.orgProfileReadmeCalloutEnabled || $[5] !== banners.profileReadmeCalloutEnabled || $[6] !== banners.replacedDetectedEncoding || $[7] !== banners.repositoryCitationTemplateUrl || $[8] !== banners.repositoryFundingLinksEnabled || $[9] !== banners.sponsorsEnabled || $[10] !== content || $[11] !== editInfo.customSlashCommandsDocsUrl || $[12] !== editInfo.customSlashCommandsEnabled || $[13] !== editInfo.helpUrl || $[14] !== fileName || $[15] !== filePath || $[16] !== hasLeadingOrTrailingWhitespaceInPath || $[17] !== helpUrl || $[18] !== isIssueTemplate || $[19] !== isLegacyIssueTemplate || $[20] !== onSetContent || $[21] !== repo || $[22] !== secretBypassMetadata || $[23] !== secretDetected || $[24] !== webCommitInfo.canCreatePullRequest || $[25] !== webCommitInfo.forkedRepo) {
		const showFundingBanner = banners.sponsorsEnabled && fileName.match(/^funding\.yml$/i);
		const showIssueTemplateConfigBanner = filePath.match(/^(\.github\/ISSUE_TEMPLATE\/config($|\.(yml|yaml)$))/);
		const showCitationBanner = citationRegex.test(filePath);
		const showCustomSlashCommandsBanner = editInfo.customSlashCommandsEnabled && filePath.match(/^(\.github\/commands\/.+\.(yaml|yml))/i);
		const showProfileReadmeCallout = banners.profileReadmeCalloutEnabled && readmeRegex.test(fileName);
		const showOrgProfileReadmeCallout = banners.orgProfileReadmeCalloutEnabled && profileReadmeRegex.test(filePath);
		const showOrgMemberProfileReadmeCallout = banners.orgMemberProfileReadmeCalloutEnabled && profileReadmeRegex.test(filePath);
		t1 = jsxs(Fragment$1, { children: [
			webCommitInfo.forkedRepo && jsx(EditingForkBanner, {
				forkName: webCommitInfo.forkedRepo.name,
				forkOwner: webCommitInfo.forkedRepo.owner,
				canCreatePullRequest: webCommitInfo.canCreatePullRequest
			}),
			banners.replacedDetectedEncoding && jsx(TranscodingBanner, { detectedEncoding: banners.replacedDetectedEncoding }),
			banners.hasMixedLineEndings && jsx(MixedLineEndingsBanner, {}),
			showCitationBanner && jsx(CitationFileBanner, {
				citationHelpUrl: banners.citationHelpUrl,
				repositoryCitationTemplateUrl: banners.repositoryCitationTemplateUrl,
				setContent: onSetContent
			}),
			showFundingBanner && jsx(FundingBanner, {
				editRepoPath: banners.editRepoPath,
				helpPath: helpUrl,
				repositoryFundingLinksEnabled: banners.repositoryFundingLinksEnabled
			}),
			showCustomSlashCommandsBanner && jsx(CustomSlashCommandsBanner, { customSlashCommandsDocsUrl: editInfo.customSlashCommandsDocsUrl }),
			showIssueTemplateConfigBanner && jsx(IssueTemplateConfigBanner, { helpUrl: editInfo.helpUrl }),
			isIssueTemplate ? jsx(IssueTemplateValidBanner, {
				helpUrl: editInfo.helpUrl,
				filePath
			}) : isLegacyIssueTemplate ? jsx(IssueTemplateLegacyBanner, { helpUrl: editInfo.helpUrl }) : null,
			showProfileReadmeCallout && jsx(ProfileReadmeBanner, {
				name: repo.name,
				owner: repo.ownerLogin
			}),
			showOrgProfileReadmeCallout && jsx(OrgProfileReadmeBanner, {
				name: repo.name,
				owner: repo.ownerLogin
			}),
			showOrgMemberProfileReadmeCallout && jsx(OrgMemberProfileReadmeBanner, {
				name: repo.name,
				owner: repo.ownerLogin
			}),
			secretDetected && secretBypassMetadata && jsx(SecretDetectedDialogBlob, {
				content,
				bypassMetadata: secretBypassMetadata,
				helpUrl
			}),
			hasLeadingOrTrailingWhitespaceInPath && jsx(LeadingOrTrailingWhitespaceBanner, {})
		] });
		$[0] = banners.citationHelpUrl;
		$[1] = banners.editRepoPath;
		$[2] = banners.hasMixedLineEndings;
		$[3] = banners.orgMemberProfileReadmeCalloutEnabled;
		$[4] = banners.orgProfileReadmeCalloutEnabled;
		$[5] = banners.profileReadmeCalloutEnabled;
		$[6] = banners.replacedDetectedEncoding;
		$[7] = banners.repositoryCitationTemplateUrl;
		$[8] = banners.repositoryFundingLinksEnabled;
		$[9] = banners.sponsorsEnabled;
		$[10] = content;
		$[11] = editInfo.customSlashCommandsDocsUrl;
		$[12] = editInfo.customSlashCommandsEnabled;
		$[13] = editInfo.helpUrl;
		$[14] = fileName;
		$[15] = filePath;
		$[16] = hasLeadingOrTrailingWhitespaceInPath;
		$[17] = helpUrl;
		$[18] = isIssueTemplate;
		$[19] = isLegacyIssueTemplate;
		$[20] = onSetContent;
		$[21] = repo;
		$[22] = secretBypassMetadata;
		$[23] = secretDetected;
		$[24] = webCommitInfo.canCreatePullRequest;
		$[25] = webCommitInfo.forkedRepo;
		$[26] = t1;
	} else t1 = $[26];
	return t1;
}
BlobEditorBanners.displayName = "BlobEditorBanners";
function UnsavedChangesBanner({ discardContent, restoreContent }) {
	return /* @__PURE__ */ jsx(Banner, {
		title: "Unsaved changes",
		description: "You have unsaved changes on this file that can be restored.",
		variant: "info",
		onDismiss: discardContent,
		primaryAction: /* @__PURE__ */ jsx(Banner.PrimaryAction, {
			onClick: restoreContent,
			children: "Restore"
		}),
		secondaryAction: /* @__PURE__ */ jsx(Banner.SecondaryAction, {
			onClick: discardContent,
			children: "Discard"
		}),
		hideTitle: true,
		className: "tmp-mb-3"
	});
}
UnsavedChangesBanner.displayName = "UnsavedChangesBanner";
function useUnsavedContent(cacheKey) {
	const $ = c(17);
	const [failedToPersist, setFailedToPersist] = useState(false);
	let t0;
	if ($[0] !== cacheKey) {
		t0 = () => !!getItem(cacheKey);
		$[0] = cacheKey;
		$[1] = t0;
	} else t0 = $[1];
	const [hasUnsavedContent, setHasUnsavedContent] = useState(t0);
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[2] !== cacheKey || $[3] !== sendAnalyticsEvent) {
		t1 = () => {
			setHasUnsavedContent(false);
			const content = getItem(cacheKey);
			if (content) sendAnalyticsEvent("code_view.unsaved_changes.restored");
			else sendAnalyticsEvent("code_view.unsaved_changes.restored_no_content");
			return content;
		};
		$[2] = cacheKey;
		$[3] = sendAnalyticsEvent;
		$[4] = t1;
	} else t1 = $[4];
	const restoreContent = t1;
	let t2;
	if ($[5] !== cacheKey || $[6] !== failedToPersist || $[7] !== sendAnalyticsEvent) {
		t2 = (content_0) => {
			if (failedToPersist) return;
			try {
				setItem(cacheKey, content_0);
			} catch {
				setFailedToPersist(true);
				sendAnalyticsEvent("code_view.unsaved_changes.persist_failure");
			}
		};
		$[5] = cacheKey;
		$[6] = failedToPersist;
		$[7] = sendAnalyticsEvent;
		$[8] = t2;
	} else t2 = $[8];
	const debouncedPersistContent = useDebounce(t2, 1e3);
	let t3;
	if ($[9] !== cacheKey || $[10] !== sendAnalyticsEvent) {
		t3 = (source) => {
			setHasUnsavedContent(false);
			removeItem(cacheKey);
			if (source === "banner") sendAnalyticsEvent("code_view.unsaved_changes.discarded");
		};
		$[9] = cacheKey;
		$[10] = sendAnalyticsEvent;
		$[11] = t3;
	} else t3 = $[11];
	const discardContent = t3;
	let t4;
	if ($[12] !== debouncedPersistContent || $[13] !== discardContent || $[14] !== hasUnsavedContent || $[15] !== restoreContent) {
		t4 = {
			hasUnsavedContent,
			restoreContent,
			discardContent,
			persistContent: debouncedPersistContent
		};
		$[12] = debouncedPersistContent;
		$[13] = discardContent;
		$[14] = hasUnsavedContent;
		$[15] = restoreContent;
		$[16] = t4;
	} else t4 = $[16];
	return t4;
}
var BlobEditHeader_module_default = {
	Box: "BlobEditHeader-module_5oioMW_Box",
	Box_1: "BlobEditHeader-module_5oioMW_Box_1",
	Box_2: "BlobEditHeader-module_5oioMW_Box_2",
	Box_3: "BlobEditHeader-module_5oioMW_Box_3",
	Box_4: "BlobEditHeader-module_5oioMW_Box_4",
	Box_5: "BlobEditHeader-module_5oioMW_Box_5",
	CodeMirrorSpacingControls: "BlobEditHeader-module_5oioMW_CodeMirrorSpacingControls",
	CodeMirrorSpacingControls_1: "BlobEditHeader-module_5oioMW_CodeMirrorSpacingControls_1",
	FormControl_Label: "BlobEditHeader-module_5oioMW_FormControl_Label",
	GitIgnoreTemplateSelector: "BlobEditHeader-module_5oioMW_GitIgnoreTemplateSelector",
	LicenseSelector: "BlobEditHeader-module_5oioMW_LicenseSelector",
	SegmentedControl: "BlobEditHeader-module_5oioMW_SegmentedControl"
};
var CodeMirrorSpacingControls_module_default = { Box: "CodeMirrorSpacingControls-module_4Pi4-W_Box" };
var defaultCodeMirrorSpacingOptions = {
	indentSize: "2",
	indentMode: "space",
	lineWrapping: "off"
};
function CodeMirrorSpacingControls(t0) {
	const $ = c(21);
	const { options, onChange, className, formControlClassName } = t0;
	const [indentMode, setIndentMode] = useState(options.indentMode);
	const [indentSize, setIndentSize] = useState(options.indentSize);
	const [lineWrapping, setLineWrapping] = useState(options.lineWrapping);
	let t1;
	if ($[0] !== indentSize || $[1] !== lineWrapping || $[2] !== onChange) {
		t1 = (event) => {
			const updatedIndentMode = event.target.value;
			setIndentMode(updatedIndentMode);
			onChange({
				indentMode: updatedIndentMode,
				indentSize,
				lineWrapping
			});
		};
		$[0] = indentSize;
		$[1] = lineWrapping;
		$[2] = onChange;
		$[3] = t1;
	} else t1 = $[3];
	const onIndentModeChange = t1;
	let t2;
	if ($[4] !== indentMode || $[5] !== lineWrapping || $[6] !== onChange) {
		t2 = (event_0) => {
			const updatedIndentSize = event_0.target.value;
			setIndentSize(updatedIndentSize);
			onChange({
				indentMode,
				indentSize: updatedIndentSize,
				lineWrapping
			});
		};
		$[4] = indentMode;
		$[5] = lineWrapping;
		$[6] = onChange;
		$[7] = t2;
	} else t2 = $[7];
	const onIndentSizeChange = t2;
	let t3;
	if ($[8] !== indentMode || $[9] !== indentSize || $[10] !== onChange) {
		t3 = (event_1) => {
			const updatedLineWrapping = event_1.target.value;
			setLineWrapping(updatedLineWrapping);
			onChange({
				indentMode,
				indentSize,
				lineWrapping: updatedLineWrapping
			});
		};
		$[8] = indentMode;
		$[9] = indentSize;
		$[10] = onChange;
		$[11] = t3;
	} else t3 = $[11];
	const onLineWrappingChange = t3;
	let t4;
	if ($[12] !== className || $[13] !== formControlClassName || $[14] !== indentMode || $[15] !== indentSize || $[16] !== lineWrapping || $[17] !== onIndentModeChange || $[18] !== onIndentSizeChange || $[19] !== onLineWrappingChange) {
		t4 = jsxs("div", {
			className: clsx(className, CodeMirrorSpacingControls_module_default.Box),
			children: [
				jsx(CodeMirrorSpacingControl, {
					onChange: onIndentModeChange,
					value: indentMode,
					label: "Indent mode",
					options: [{
						value: "spaces",
						label: "Spaces"
					}, {
						value: "tab",
						label: "Tabs"
					}],
					className: formControlClassName
				}),
				jsx(CodeMirrorSpacingControl, {
					onChange: onIndentSizeChange,
					value: indentSize,
					label: "Indent size",
					options: [
						{
							value: "2",
							label: "2"
						},
						{
							value: "4",
							label: "4"
						},
						{
							value: "8",
							label: "8"
						}
					],
					className: formControlClassName
				}),
				jsx(CodeMirrorSpacingControl, {
					onChange: onLineWrappingChange,
					value: lineWrapping,
					label: "Line wrap mode",
					options: [{
						value: "off",
						label: "No wrap"
					}, {
						value: "on",
						label: "Soft wrap"
					}],
					className: formControlClassName
				})
			]
		});
		$[12] = className;
		$[13] = formControlClassName;
		$[14] = indentMode;
		$[15] = indentSize;
		$[16] = lineWrapping;
		$[17] = onIndentModeChange;
		$[18] = onIndentSizeChange;
		$[19] = onLineWrappingChange;
		$[20] = t4;
	} else t4 = $[20];
	return t4;
}
CodeMirrorSpacingControls.displayName = "CodeMirrorSpacingControls";
function CodeMirrorSpacingControl({ onChange, value, label, options, className }) {
	return /* @__PURE__ */ jsxs(FormControl$1, {
		className,
		children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
			visuallyHidden: true,
			children: label
		}), /* @__PURE__ */ jsx(Select$1, {
			size: "small",
			onChange,
			value,
			"aria-label": label,
			children: /* @__PURE__ */ jsx(Select$1.OptGroup, {
				label,
				children: options.map((option) => /* @__PURE__ */ jsx(Select$1.Option, {
					value: option.value,
					children: option.label
				}, option.value))
			})
		})]
	});
}
CodeMirrorSpacingControl.displayName = "CodeMirrorSpacingControl";
var ExpandPanelButton = ({ ref, expanded, onToggleExpanded, ariaControls }) => /* @__PURE__ */ jsx(ExpandButton, {
	expanded,
	alignment: "right",
	ariaLabel: expanded ? "Collapse help panel" : "Expand help panel",
	ariaControls,
	tooltipDirection: "nw",
	testid: "help-panel-button",
	ref,
	onToggleExpanded
});
ExpandPanelButton.displayName = "ExpandPanelButton";
ExpandPanelButton.displayName = "ExpandPanelButton";
var CodeOfConductSelector_module_default = { Button: "CodeOfConductSelector-module_hZugJq_Button" };
function CodeOfConductSelector({ url, className }) {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		variant: "invisible",
		as: Link$1,
		to: url,
		leadingVisual: CodeOfConductIcon,
		className: clsx(CodeOfConductSelector_module_default.Button, className),
		children: "Choose a code of conduct template"
	});
}
CodeOfConductSelector.displayName = "CodeOfConductSelector";
function SearchDropdown(t0) {
	const $ = c(29);
	const { allowNoneOption: t1, buttonLabel, buttonSx, buttonClassName, inputLabel, items, onOpen, onSelect, selectedItem, textInputProps, title, anchorButtonProps: t2 } = t0;
	const allowNoneOption = t1 === void 0 ? false : t1;
	let t3;
	if ($[0] !== t2) {
		t3 = t2 === void 0 ? {} : t2;
		$[0] = t2;
		$[1] = t3;
	} else t3 = $[1];
	const anchorButtonProps = t3;
	const [open, setOpen] = useState(false);
	const [searchTerm, setSearchTerm] = useState("");
	let t4;
	if ($[2] !== allowNoneOption || $[3] !== anchorButtonProps || $[4] !== buttonClassName || $[5] !== buttonLabel || $[6] !== buttonSx || $[7] !== inputLabel || $[8] !== items || $[9] !== onOpen || $[10] !== onSelect || $[11] !== open || $[12] !== searchTerm || $[13] !== selectedItem || $[14] !== textInputProps || $[15] !== title) {
		const selectableItems = allowNoneOption ? [{
			text: "None",
			id: ""
		}, ...items] : items;
		let t5;
		if ($[17] !== searchTerm) {
			t5 = (item) => item.text.toLowerCase().includes(searchTerm.toLowerCase());
			$[17] = searchTerm;
			$[18] = t5;
		} else t5 = $[18];
		const filteredItems = selectableItems.filter(t5);
		const buttonTitle = buttonLabel || title;
		const selectedItemDisplay = selectedItem?.text || "None";
		let t6;
		if ($[19] !== onOpen) {
			t6 = (isOpen) => {
				setOpen(isOpen);
				if (isOpen) onOpen?.();
			};
			$[19] = onOpen;
			$[20] = t6;
		} else t6 = $[20];
		let t7;
		if ($[21] !== onSelect) {
			t7 = (item_0) => item_0 && onSelect(item_0);
			$[21] = onSelect;
			$[22] = t7;
		} else t7 = $[22];
		let t8;
		if ($[23] !== anchorButtonProps || $[24] !== buttonClassName || $[25] !== buttonSx || $[26] !== buttonTitle || $[27] !== selectedItemDisplay) {
			t8 = (t9) => {
				const { ...anchorProps } = t9;
				return jsxs(ButtonComponent$1, {
					trailingAction: TriangleDownIcon,
					...anchorProps,
					sx: buttonSx,
					className: buttonClassName,
					size: "small",
					...anchorButtonProps,
					"aria-describedby": "license-picker-label",
					children: [
						jsxs("span", {
							className: "color-fg-muted",
							children: [buttonTitle, ":"]
						}),
						" ",
						selectedItemDisplay
					]
				});
			};
			$[23] = anchorButtonProps;
			$[24] = buttonClassName;
			$[25] = buttonSx;
			$[26] = buttonTitle;
			$[27] = selectedItemDisplay;
			$[28] = t8;
		} else t8 = $[28];
		t4 = jsx(SelectPanel, {
			title,
			showItemDividers: true,
			open,
			inputLabel,
			onFilterChange: setSearchTerm,
			placeholderText: "Filter…",
			onOpenChange: t6,
			onSelectedChange: t7,
			items: filteredItems,
			selected: selectedItem,
			renderAnchor: t8,
			overlayProps: {
				width: "small",
				maxHeight: "large"
			},
			textInputProps
		});
		$[2] = allowNoneOption;
		$[3] = anchorButtonProps;
		$[4] = buttonClassName;
		$[5] = buttonLabel;
		$[6] = buttonSx;
		$[7] = inputLabel;
		$[8] = items;
		$[9] = onOpen;
		$[10] = onSelect;
		$[11] = open;
		$[12] = searchTerm;
		$[13] = selectedItem;
		$[14] = textInputProps;
		$[15] = title;
		$[16] = t4;
	} else t4 = $[16];
	return t4;
}
SearchDropdown.displayName = "SearchDropdown";
function GitIgnoreDropdown(t0) {
	const $ = c(16);
	const { selectedTemplate, buttonLabel, buttonSx, buttonClassName, onSelect, allowNoneOption: t1, onOpen } = t0;
	const allowNoneOption = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[0] = t2;
	} else t2 = $[0];
	const [templates, setTemplates] = useState(t2);
	let t3;
	let t4;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			const getItems = async () => {
				const response = await verifiedFetchJSON("/site/gitignore/templates");
				if (!response.ok) {
					setTemplates(null);
					return;
				}
				try {
					setTemplates(await response.json());
				} catch {
					setTemplates(null);
				}
			};
			getItems();
		};
		t4 = [];
		$[1] = t3;
		$[2] = t4;
	} else {
		t3 = $[1];
		t4 = $[2];
	}
	useEffect(t3, t4);
	let t5;
	if ($[3] !== allowNoneOption || $[4] !== buttonClassName || $[5] !== buttonLabel || $[6] !== buttonSx || $[7] !== onOpen || $[8] !== onSelect || $[9] !== selectedTemplate || $[10] !== templates) {
		const selectableItems = templates?.map(_temp$3) || [];
		let t6;
		if ($[12] !== selectedTemplate) {
			t6 = (item) => item.id === selectedTemplate;
			$[12] = selectedTemplate;
			$[13] = t6;
		} else t6 = $[13];
		let t7;
		if ($[14] !== onSelect) {
			t7 = (item_0) => onSelect(item_0.id);
			$[14] = onSelect;
			$[15] = t7;
		} else t7 = $[15];
		t5 = jsx(SearchDropdown, {
			title: ".gitignore template",
			inputLabel: "Template filter",
			buttonLabel,
			buttonSx,
			buttonClassName,
			selectedItem: selectableItems.find(t6),
			onSelect: t7,
			items: selectableItems,
			allowNoneOption,
			onOpen
		});
		$[3] = allowNoneOption;
		$[4] = buttonClassName;
		$[5] = buttonLabel;
		$[6] = buttonSx;
		$[7] = onOpen;
		$[8] = onSelect;
		$[9] = selectedTemplate;
		$[10] = templates;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
}
GitIgnoreDropdown.displayName = "GitIgnoreDropdown";
function _temp$3(template) {
	return {
		text: template,
		id: template
	};
}
function GitIgnoreTemplateSelector(t0) {
	const $ = c(7);
	const { onTemplateSelect, className } = t0;
	const [selectedTemplate, setSelectedTemplate] = useState();
	let t1;
	if ($[0] !== onTemplateSelect) {
		t1 = async function onSelect(template) {
			setSelectedTemplate(template);
			const content = await fetchTemplateContent(template);
			if (content) onTemplateSelect(content);
		};
		$[0] = onTemplateSelect;
		$[1] = t1;
	} else t1 = $[1];
	const onSelect = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[2] = t2;
	} else t2 = $[2];
	useEffect(_temp$2, t2);
	let t3;
	if ($[3] !== className || $[4] !== onSelect || $[5] !== selectedTemplate) {
		t3 = jsx(GitIgnoreDropdown, {
			selectedTemplate,
			onSelect,
			buttonLabel: "Choose .gitignore template",
			buttonClassName: className
		});
		$[3] = className;
		$[4] = onSelect;
		$[5] = selectedTemplate;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
GitIgnoreTemplateSelector.displayName = "GitIgnoreTemplateSelector";
function _temp$2() {
	return clearGitignoreTemplateCache;
}
var templatesMap = /* @__PURE__ */ new Map();
function clearGitignoreTemplateCache() {
	templatesMap.clear();
}
async function fetchTemplateContent(templateName) {
	const template = templatesMap.get(templateName);
	if (template) return template;
	const response = await verifiedFetchJSON(`/site/gitignore/${encodeURI(templateName)}`);
	if (!response.ok) return null;
	try {
		const content = await response.text();
		templatesMap.set(templateName, content);
		return content;
	} catch {
		return null;
	}
}
var LicenseSelector_module_default = { Button: "LicenseSelector-module_ic67eq_Button" };
function LicenseSelector({ url, className }) {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		variant: "invisible",
		as: Link$1,
		to: url,
		leadingVisual: LawIcon,
		className: clsx(className, LicenseSelector_module_default.Button),
		children: "Choose a license template"
	});
}
LicenseSelector.displayName = "LicenseSelector";
var BlobEditorTab = {
	Edit: 0,
	Preview: 1
};
function isValidBlobEditorTab(value) {
	return value === BlobEditorTab.Edit || value === BlobEditorTab.Preview;
}
function BlobEditHeader(t0) {
	const $ = c(27);
	const { codeMirrorSpacingOptions, editInfo, fileName, isRichtextRenderable, onTabChange, panelIsEnabled, panelIsOpen, selectedTab, setCodeMirrorSpacingOptions, setOpenPanel, setShowMarkdownDiff, setUpdatedFileContent, showMarkdownDiff, copilotInfo } = t0;
	const isNewFile = editInfo.isNewFile;
	const isEditing = selectedTab === BlobEditorTab.Edit;
	const isPreviewing = selectedTab === BlobEditorTab.Preview;
	let t1;
	if ($[0] !== codeMirrorSpacingOptions || $[1] !== copilotInfo || $[2] !== editInfo.codeMirror?.showFileActions || $[3] !== editInfo.pickers.codeOfConductPickerAvailable || $[4] !== editInfo.pickers.codeOfConductToolPath || $[5] !== editInfo.pickers.licensePickerAvailable || $[6] !== editInfo.pickers.licenseToolPath || $[7] !== fileName || $[8] !== isEditing || $[9] !== isNewFile || $[10] !== isPreviewing || $[11] !== isRichtextRenderable || $[12] !== onTabChange || $[13] !== panelIsEnabled || $[14] !== panelIsOpen || $[15] !== setCodeMirrorSpacingOptions || $[16] !== setOpenPanel || $[17] !== setShowMarkdownDiff || $[18] !== setUpdatedFileContent || $[19] !== showMarkdownDiff) {
		const showLicensePicker = editInfo.pickers.licensePickerAvailable && /^(licen[sc]e|copying)(-)?(-\D+)?($|\..)/i.test(fileName);
		const showCodeOfConductPicker = editInfo.pickers.codeOfConductPickerAvailable && /^(code.?of.?conduct|coc)($|\..)/i.test(fileName);
		const showGitIgnoreTemplateSelector = fileName === ".gitignore";
		const showSpacingControls = editInfo.codeMirror?.showFileActions && isEditing;
		const showMarkdownDiffPreview = isRichtextRenderable && isPreviewing && !isNewFile;
		let marginRightOffset = 8;
		if (panelIsEnabled) marginRightOffset = 45;
		let t2;
		bb0: {
			if (!panelIsEnabled) {
				t2 = void 0;
				break bb0;
			}
			let t3;
			if ($[21] !== panelIsOpen || $[22] !== setOpenPanel) {
				t3 = () => setOpenPanel(panelIsOpen ? void 0 : "edit");
				$[21] = panelIsOpen;
				$[22] = setOpenPanel;
				$[23] = t3;
			} else t3 = $[23];
			let t4;
			if ($[24] !== panelIsOpen || $[25] !== t3) {
				t4 = jsx(ExpandPanelButton, {
					ariaControls: blobEditSidePanelId,
					expanded: panelIsOpen,
					onToggleExpanded: t3
				});
				$[24] = panelIsOpen;
				$[25] = t3;
				$[26] = t4;
			} else t4 = $[26];
			t2 = t4;
		}
		const panelToggleElement = t2;
		t1 = jsxs("div", {
			className: BlobEditHeader_module_default.Box,
			children: [jsxs("div", {
				className: BlobEditHeader_module_default.Box_1,
				children: [
					jsxs(SegmentedControl, {
						size: "small",
						"aria-label": "Edit mode",
						onChange: onTabChange,
						className: BlobEditHeader_module_default.SegmentedControl,
						children: [jsx(SegmentedControl.Button, {
							selected: isEditing,
							children: "Edit"
						}), jsx(SegmentedControl.Button, {
							selected: isPreviewing,
							children: "Preview"
						})]
					}),
					jsx("div", {
						style: { "--margin-right-offset": `-${marginRightOffset}px` },
						className: BlobEditHeader_module_default.Box_2
					}),
					isEditing && jsxs(Fragment$1, { children: [
						showGitIgnoreTemplateSelector && jsx(GitIgnoreTemplateSelector, {
							onTemplateSelect: setUpdatedFileContent,
							className: BlobEditHeader_module_default.GitIgnoreTemplateSelector
						}),
						showLicensePicker && jsx(LicenseSelector, {
							url: editInfo.pickers.licenseToolPath,
							className: BlobEditHeader_module_default.LicenseSelector
						}),
						showCodeOfConductPicker && jsx(CodeOfConductSelector, {
							url: editInfo.pickers.codeOfConductToolPath,
							className: BlobEditHeader_module_default.LicenseSelector
						})
					] }),
					jsx(CopilotPopover, {
						copilotInfo,
						view: "edit"
					}),
					jsx("div", { className: BlobEditHeader_module_default.Box_3 }),
					jsxs("div", {
						className: BlobEditHeader_module_default.Box_4,
						children: [showMarkdownDiffPreview && jsx("div", {
							className: BlobEditHeader_module_default.Box_5,
							children: jsxs(FormControl$1, { children: [jsx(Checkbox, {
								checked: showMarkdownDiff,
								onChange: () => setShowMarkdownDiff(!showMarkdownDiff)
							}), jsx(FormControl$1.Label, {
								className: BlobEditHeader_module_default.FormControl_Label,
								children: "Show Diff"
							})] })
						}), showSpacingControls && jsx(CodeMirrorSpacingControls, {
							options: codeMirrorSpacingOptions,
							onChange: setCodeMirrorSpacingOptions,
							className: BlobEditHeader_module_default.CodeMirrorSpacingControls,
							formControlClassName: BlobEditHeader_module_default.CodeMirrorSpacingControls_1
						})]
					})
				]
			}), panelToggleElement]
		});
		$[0] = codeMirrorSpacingOptions;
		$[1] = copilotInfo;
		$[2] = editInfo.codeMirror?.showFileActions;
		$[3] = editInfo.pickers.codeOfConductPickerAvailable;
		$[4] = editInfo.pickers.codeOfConductToolPath;
		$[5] = editInfo.pickers.licensePickerAvailable;
		$[6] = editInfo.pickers.licenseToolPath;
		$[7] = fileName;
		$[8] = isEditing;
		$[9] = isNewFile;
		$[10] = isPreviewing;
		$[11] = isRichtextRenderable;
		$[12] = onTabChange;
		$[13] = panelIsEnabled;
		$[14] = panelIsOpen;
		$[15] = setCodeMirrorSpacingOptions;
		$[16] = setOpenPanel;
		$[17] = setShowMarkdownDiff;
		$[18] = setUpdatedFileContent;
		$[19] = showMarkdownDiff;
		$[20] = t1;
	} else t1 = $[20];
	return t1;
}
BlobEditHeader.displayName = "BlobEditHeader";
var BlobEditor_module_default = {
	Box: "BlobEditor-module_SQyN6a_Box",
	Box_1: "BlobEditor-module_SQyN6a_Box_1",
	Box_2: "BlobEditor-module_SQyN6a_Box_2",
	Box_3: "BlobEditor-module_SQyN6a_Box_3",
	Box_4: "BlobEditor-module_SQyN6a_Box_4",
	Box_5: "BlobEditor-module_SQyN6a_Box_5",
	Box_6: "BlobEditor-module_SQyN6a_Box_6",
	Box_7: "BlobEditor-module_SQyN6a_Box_7",
	Box_8: "BlobEditor-module_SQyN6a_Box_8",
	Box_9: "BlobEditor-module_SQyN6a_Box_9",
	Button: "BlobEditor-module_SQyN6a_Button",
	Button_1: "BlobEditor-module_SQyN6a_Button_1",
	Panel: "BlobEditor-module_SQyN6a_Panel",
	TextInput: "BlobEditor-module_SQyN6a_TextInput"
};
function useCSRFToken(path, method) {
	const { csrf_tokens } = useRoutePayload();
	return csrf_tokens?.[path]?.[method];
}
function buildExtensionsSentence(extensions) {
	return extensions.map((ext, index) => {
		const friendlyName = ext.replace(".", "").toUpperCase();
		if (index === extensions.length - 1 && extensions.length > 1) return `or ${friendlyName}`;
		else return friendlyName;
	}).join(", ");
}
var FileUpload_module_default = { Spinner: "FileUpload-module_TA5SBq_Spinner" };
function FileUpload({ isDataRouter, ...props }) {
	if (isDataRouter) return /* @__PURE__ */ jsx(FileUploadWithQuery, { ...props });
	return /* @__PURE__ */ jsx(FileUploadWithRoutePayload, { ...props });
}
FileUpload.displayName = "FileUpload";
function FileUploadWithQuery(props) {
	const $ = c(3);
	const { data: t0 } = useRouteQuery(codeViewLayoutRoute, "mainQuery");
	const { uploadToken } = t0;
	if (!uploadToken) return null;
	let t1;
	if ($[0] !== props || $[1] !== uploadToken) {
		t1 = jsx(FileUploadInternal, {
			...props,
			uploadToken
		});
		$[0] = props;
		$[1] = uploadToken;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
FileUploadWithQuery.displayName = "FileUploadWithQuery";
function FileUploadWithRoutePayload(props) {
	const $ = c(3);
	const t0 = useCSRFToken(props.uploadPath, "post") || "";
	let t1;
	if ($[0] !== props || $[1] !== t0) {
		t1 = jsx(FileUploadInternal, {
			...props,
			uploadToken: t0
		});
		$[0] = props;
		$[1] = t0;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
FileUploadWithRoutePayload.displayName = "FileUploadWithRoutePayload";
function FileUploadInternal(t0) {
	const $ = c(2);
	const { allowedExtensions, allowDragAndDrop, children, markdownDocsUrl, repositoryId, uploadPath, stickyFooter: t1, disabled: t2, uploadToken } = t0;
	const stickyFooter = t1 === void 0 ? false : t1;
	const disabled = t2 === void 0 ? false : t2;
	const friendlyExtensionSentence = buildExtensionsSentence(allowedExtensions);
	const [isFocused, setIsFocused] = React.useState(false);
	let t3;
	let t4;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => setIsFocused(true);
		t4 = () => setIsFocused(false);
		$[0] = t3;
		$[1] = t4;
	} else {
		t3 = $[0];
		t4 = $[1];
	}
	return jsxs("file-attachment", {
		class: !disabled ? "js-upload-markdown-image is-default file-editor-upload react-file-upload" : void 0,
		input: !disabled ? "blob-dragged-file-input" : void 0,
		"data-upload-repository-id": !disabled ? repositoryId : void 0,
		"data-upload-policy-url": !disabled ? uploadPath : void 0,
		"data-upload-container-type": !disabled ? "blob" : void 0,
		"data-upload-container-id": !disabled ? repositoryId : void 0,
		children: [
			children,
			jsx("input", {
				type: "hidden",
				"data-csrf": "true",
				className: "js-data-upload-policy-url-csrf",
				value: uploadToken
			}),
			jsxs("label", {
				hidden: disabled,
				className: `text-normal drag-and-drop hx_drag-and-drop d-flex flex-justify-between border-0 border-top border-dashed position-relative ${stickyFooter ? "position-sm-sticky bottom-sm-0" : ""}  ${isFocused ? "file-input-focused" : ""}`,
				children: [
					jsx("input", {
						id: "blob-dragged-file-input",
						type: "file",
						accept: allowedExtensions.join(","),
						multiple: true,
						onFocus: t3,
						onBlur: t4,
						className: "manual-file-chooser manual-file-chooser-transparent top-0 right-0 bottom-0 left-0 width-full ml-0 form-control rounded-top-0"
					}),
					jsx("span", {
						className: "color-bg-subtle position-absolute top-0 left-0 rounded-bottom-2 width-full height-full",
						style: { pointerEvents: "none" }
					}),
					jsxs("span", {
						className: "position-relative pr-2",
						style: { pointerEvents: "none" },
						children: [
							jsxs("span", {
								className: "default",
								children: [
									"Attach files by ",
									allowDragAndDrop ? "dragging & dropping, " : "",
									"selecting or pasting them."
								]
							}),
							jsxs("span", {
								className: "loading",
								children: [jsx(Spinner, {
									size: "small",
									className: FileUpload_module_default.Spinner
								}), jsx("span", {
									className: "js-file-upload-loading-text",
									"data-file-upload-message": "Uploading your files…",
									children: "Uploading your files…"
								})]
							}),
							jsxs("span", {
								className: "error bad-file",
								children: ["We don’t support that file type.", jsxs("span", {
									className: "drag-and-drop-error-info",
									children: [
										jsx("span", {
											className: "btn-link",
											children: "Try again"
										}),
										" with a ",
										friendlyExtensionSentence,
										"."
									]
								})]
							}),
							jsxs("span", {
								className: "error bad-permissions",
								children: ["Attaching documents requires write permission to this repository.", jsxs("span", {
									className: "drag-and-drop-error-info",
									children: [
										jsx("span", {
											className: "btn-link",
											children: "Try again"
										}),
										" with a ",
										friendlyExtensionSentence,
										"."
									]
								})]
							}),
							jsxs("span", {
								className: "error repository-required",
								children: ["We don’t support that file type.", jsxs("span", {
									className: "drag-and-drop-error-info",
									children: [
										jsx("span", {
											className: "btn-link",
											children: "Try again"
										}),
										" with a ",
										friendlyExtensionSentence,
										"."
									]
								})]
							}),
							jsx("span", { className: "error too-big js-upload-too-big" }),
							jsxs("span", {
								className: "error empty",
								children: ["This file is empty.", jsxs("span", {
									className: "drag-and-drop-error-info",
									children: [jsx("span", {
										className: "btn-link",
										children: "Try again"
									}), " with a file that’s not empty."]
								})]
							}),
							jsxs("span", {
								className: "error hidden-file",
								children: ["This file is hidden.", jsxs("span", {
									className: "drag-and-drop-error-info",
									children: [jsx("span", {
										className: "btn-link",
										children: "Try again"
									}), " with another file."]
								})]
							}),
							jsxs("span", {
								className: "error failed-request",
								children: ["Something went really wrong, and we can’t process that file.", jsx("span", {
									className: "drag-and-drop-error-info",
									children: jsx("span", {
										className: "btn-link",
										children: "Try again."
									})
								})]
							})
						]
					}),
					jsx(Tooltip$1, {
						id: "blob-markdown-help",
						text: "Styling with Markdown is supported",
						direction: "nw",
						children: jsx("a", {
							"aria-labelledby": "blob-markdown-help",
							className: "Link--muted position-relative d-inline",
							href: markdownDocsUrl,
							target: "_blank",
							"data-ga-click": "Markdown Toolbar, click, help",
							rel: "noreferrer",
							children: jsx(MarkdownIcon, { verticalAlign: "text-bottom" })
						})
					})
				]
			})
		]
	});
}
FileUploadInternal.displayName = "FileUploadInternal";
var CodeMirrorNext = lazy(() => import("./server-CodeMirror-Jr5rxiCl-DkWtYTAE.js"));
CodeMirrorNext.displayName = "CodeMirrorNext";
function onHashChange(editor, hash) {
	const result = /#?(?:L)(\d+)(?:C(\d+))?(-L(\d+)(?:C(\d+))?)?/gi.exec(hash);
	if (!result) return;
	const startLine = result[1] ? parseInt(result[1]) : void 0;
	const startColumn = result[2] ? parseInt(result[2]) : void 0;
	const endLine = result[4] ? parseInt(result[4]) : void 0;
	const endColumn = result[5] ? parseInt(result[5]) : void 0;
	if (startLine === void 0) return;
	moveCursorToPositionAndScroll(editor, startLine, endLine, startColumn, endColumn);
}
var ReactCodeMirror = ({ value = "", fileName, focusOnNextRender, onChange, onPreview, onSave, repositoryId, spacingOptions, uploadPolicyPath, uploadExtensions, markdownDocsUrl, isDataRouter, extensions = [] }) => {
	const onCodeMirrorNextUpdate = useCallback((newValue) => {
		if (onChange) onChange(newValue);
	}, [onChange]);
	const fileExtension = fileName.includes(".") ? fileName.split(".").pop() ?? "" : "";
	const fileUploadEnabled = [
		"md",
		"markdown",
		"mkd"
	].includes(fileExtension);
	const codeMirrorSpacingOptions = {
		indentMode: spacingOptions?.indentMode || defaultCodeMirrorSpacingOptions.indentMode,
		indentSize: spacingOptions?.indentSize || defaultCodeMirrorSpacingOptions.indentSize,
		lineWrapping: spacingOptions?.lineWrapping || defaultCodeMirrorSpacingOptions.lineWrapping
	};
	const codeMirrorOptions = useMemo(() => {
		return {
			indentUnit: parseInt(codeMirrorSpacingOptions.indentSize),
			indentWithTabs: codeMirrorSpacingOptions.indentMode === "tab",
			lineWrapping: codeMirrorSpacingOptions.lineWrapping === "on",
			dragDrop: !fileUploadEnabled
		};
	}, [
		codeMirrorSpacingOptions.indentSize,
		codeMirrorSpacingOptions.indentMode,
		codeMirrorSpacingOptions.lineWrapping,
		fileUploadEnabled
	]);
	const onPreviewRef = useRef(onPreview);
	const onSaveRef = useRef(onSave);
	useEffect(() => {
		onPreviewRef.current = onPreview;
		onSaveRef.current = onSave;
	});
	const keybindings = useMemo(() => [{
		key: "Shift-Mod-p",
		run: () => {
			onPreviewRef.current?.();
			return true;
		}
	}, {
		key: "Mod-s",
		run: () => {
			onSaveRef.current?.();
			return true;
		}
	}], []);
	const editorViewRef = useRef(void 0);
	const handleHashChange = useEffectEvent(() => {
		if (editorViewRef.current) onHashChange(editorViewRef.current, window.location.hash);
	});
	useEffect(() => {
		window.addEventListener("hashchange", handleHashChange);
		return () => window.removeEventListener("hashchange", handleHashChange);
	}, []);
	return /* @__PURE__ */ jsx(FileUpload, {
		allowDragAndDrop: true,
		allowedExtensions: uploadExtensions,
		markdownDocsUrl,
		repositoryId,
		uploadPath: uploadPolicyPath,
		stickyFooter: true,
		disabled: !fileUploadEnabled,
		isDataRouter,
		children: /* @__PURE__ */ jsxs(Suspense, {
			fallback: /* @__PURE__ */ jsx(LoadingFallback, {}),
			children: [/* @__PURE__ */ jsx("span", {
				id: "codemirror-label",
				className: "sr-only",
				children: `Editing ${fileName} file contents`
			}), /* @__PURE__ */ jsx(CodeMirrorNext, {
				value,
				fileName,
				onChange: onCodeMirrorNextUpdate,
				ariaLabelledBy: "codemirror-label",
				spacing: codeMirrorOptions,
				enableFileUpload: fileUploadEnabled,
				extensions,
				isHpc: true,
				keyBindings: keybindings,
				focusNextRenderRef: focusOnNextRender,
				onCreateEditor: (editor) => {
					editorViewRef.current = editor;
					if (!editor.hasFocus) editor.focus();
					onHashChange(editor, window.location.hash);
				},
				onDestroyEditor: () => {
					editorViewRef.current = void 0;
				}
			})]
		})
	});
};
ReactCodeMirror.displayName = "ReactCodeMirror";
function DiffPreview({ diffData, fileName }) {
	const fileAnchor = `diff-${fileName}`;
	return /* @__PURE__ */ jsx("table", { children: /* @__PURE__ */ jsxs("tbody", { children: [
		diffData[0].leftLine.left === 0 && diffData[0].rightLine.right === 0 && /* @__PURE__ */ jsx("tr", {}),
		diffData.map((line, index) => {
			return /* @__PURE__ */ jsxs("tr", { children: [renderLine(fileAnchor, true, true, line.leftLine), renderLine(fileAnchor, false, true, line.rightLine)] }, index);
		}),
		!diffData[diffData.length - 1].leftLine.noNewLine && !diffData[diffData.length - 1].rightLine.noNewLine && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(HunkHeaderDiffLine, {
			currentLine: {
				left: null,
				right: null,
				type: "HUNK",
				html: ""
			},
			isLeftColumn: true,
			isSplit: true
		}) })
	] }) });
}
DiffPreview.displayName = "DiffPreview";
function renderLine(fileAnchor, isLeftColumn, isSplit, line) {
	const lineOrientation = isSplit && isLeftColumn ? "left" : lineOrientationFrom(line.type);
	const lineAnchor = lineAnchorFrom(fileAnchor, lineOrientation, (lineOrientation === "left" ? line.left : line.right) ?? 0);
	switch (line.type) {
		case "EMPTY": return /* @__PURE__ */ jsx(EmptyDiffLine, { isLeftColumn });
		case "HUNK": return /* @__PURE__ */ jsx(HunkHeaderDiffLine, {
			currentLine: line,
			isLeftColumn,
			isSplit
		});
		case "ADDITION":
		case "DELETION":
		case "CONTEXT":
		case "INJECTED_CONTEXT": return /* @__PURE__ */ jsx(DiffLinePart, {
			isLeftColumn,
			isSplit,
			line,
			lineAnchor
		});
		default: throw new Error(`cannot handle type ${line.type}`);
	}
}
var EditorPreview_module_default = {
	Box: "EditorPreview-module_TB_bia_Box",
	Box_1: "EditorPreview-module_TB_bia_Box_1",
	Box_2: "EditorPreview-module_TB_bia_Box_2",
	Text: "EditorPreview-module_TB_bia_Text",
	UnsafeHTMLBox: "EditorPreview-module_TB_bia_UnsafeHTMLBox"
};
var FundingDialog_module_default = {
	Box: "FundingDialog-module_08QnDW_Box",
	Box_1: "FundingDialog-module_08QnDW_Box_1",
	Box_10: "FundingDialog-module_08QnDW_Box_10",
	Box_11: "FundingDialog-module_08QnDW_Box_11",
	Box_12: "FundingDialog-module_08QnDW_Box_12",
	Box_13: "FundingDialog-module_08QnDW_Box_13",
	Box_14: "FundingDialog-module_08QnDW_Box_14",
	Box_15: "FundingDialog-module_08QnDW_Box_15",
	Box_16: "FundingDialog-module_08QnDW_Box_16",
	Box_17: "FundingDialog-module_08QnDW_Box_17",
	Box_18: "FundingDialog-module_08QnDW_Box_18",
	Box_19: "FundingDialog-module_08QnDW_Box_19",
	Box_2: "FundingDialog-module_08QnDW_Box_2",
	Box_20: "FundingDialog-module_08QnDW_Box_20",
	Box_21: "FundingDialog-module_08QnDW_Box_21",
	Box_22: "FundingDialog-module_08QnDW_Box_22",
	Box_23: "FundingDialog-module_08QnDW_Box_23",
	Box_24: "FundingDialog-module_08QnDW_Box_24",
	Box_25: "FundingDialog-module_08QnDW_Box_25",
	Box_26: "FundingDialog-module_08QnDW_Box_26",
	Box_27: "FundingDialog-module_08QnDW_Box_27",
	Box_28: "FundingDialog-module_08QnDW_Box_28",
	Box_29: "FundingDialog-module_08QnDW_Box_29",
	Box_3: "FundingDialog-module_08QnDW_Box_3",
	Box_30: "FundingDialog-module_08QnDW_Box_30",
	Box_31: "FundingDialog-module_08QnDW_Box_31",
	Box_4: "FundingDialog-module_08QnDW_Box_4",
	Box_5: "FundingDialog-module_08QnDW_Box_5",
	Box_6: "FundingDialog-module_08QnDW_Box_6",
	Box_7: "FundingDialog-module_08QnDW_Box_7",
	Box_8: "FundingDialog-module_08QnDW_Box_8",
	Box_9: "FundingDialog-module_08QnDW_Box_9",
	Button: "FundingDialog-module_08QnDW_Button",
	Button_1: "FundingDialog-module_08QnDW_Button_1",
	Flash: "FundingDialog-module_08QnDW_Flash",
	Flash_1: "FundingDialog-module_08QnDW_Flash_1",
	Flash_2: "FundingDialog-module_08QnDW_Flash_2",
	Flash_3: "FundingDialog-module_08QnDW_Flash_3",
	GitHubAvatar: "FundingDialog-module_08QnDW_GitHubAvatar",
	GitHubAvatar_1: "FundingDialog-module_08QnDW_GitHubAvatar_1",
	Link: "FundingDialog-module_08QnDW_Link",
	Link_1: "FundingDialog-module_08QnDW_Link_1",
	Octicon: "FundingDialog-module_08QnDW_Octicon",
	Octicon_1: "FundingDialog-module_08QnDW_Octicon_1",
	"octicon-heart": "FundingDialog-module_08QnDW_octicon-heart"
};
var NON_SPONSORABLE_ERROR = "Some users provided are not enrolled in GitHub Sponsors.";
function FundingDialog(t0) {
	const $ = c(10);
	const { fileName, fundingData } = t0;
	const { helpUrl } = useReposAppPayload();
	const useCondensedLayout = fundingData.sponsorableUsers.length > 1;
	let t1;
	if ($[0] !== fileName || $[1] !== fundingData.errors || $[2] !== fundingData.externalAccounts || $[3] !== fundingData.hasValidPlatform || $[4] !== fundingData.reportAbuseLink || $[5] !== fundingData.sponsorableOrg || $[6] !== fundingData.sponsorableUsers || $[7] !== helpUrl || $[8] !== useCondensedLayout) {
		t1 = jsxs("div", {
			className: FundingDialog_module_default.Box_15,
			children: [jsxs("div", {
				className: FundingDialog_module_default.Box_16,
				children: [fundingData.errors.length ? jsxs(Flash, {
					variant: "danger",
					className: FundingDialog_module_default.Flash_2,
					children: [
						jsxs("p", { children: [
							"Some errors were encountered when parsing the ",
							fileName,
							" file:"
						] }),
						jsx("ul", {
							className: FundingDialog_module_default.Box_17,
							children: fundingData.errors.map(_temp$1)
						}),
						jsxs("p", {
							className: FundingDialog_module_default.Box_18,
							children: [jsxs(Link, {
								inline: true,
								href: `${helpUrl}/articles/displaying-a-sponsor-button-in-your-repository`,
								children: ["Learn more about formatting ", fileName]
							}), "."]
						})
					]
				}) : !fundingData.hasValidPlatform && jsxs(Flash, {
					variant: "danger",
					className: FundingDialog_module_default.Flash_3,
					children: [jsxs("p", { children: [
						"The ",
						fileName,
						" file does not currently contain valid funding links."
					] }), jsxs("p", {
						className: FundingDialog_module_default.Box_18,
						children: [jsxs(Link, {
							inline: true,
							href: `${helpUrl}/articles/displaying-a-sponsor-button-in-your-repository`,
							children: ["Learn more about formatting ", fileName]
						}), "."]
					})]
				}), jsxs("div", {
					className: FundingDialog_module_default.Box_19,
					children: [(fundingData.sponsorableOrg || fundingData.sponsorableUsers.length !== 0) && jsxs("div", {
						className: FundingDialog_module_default.Box_19,
						children: [
							jsxs("div", {
								className: FundingDialog_module_default.Box_20,
								children: [jsx("h5", { children: "GitHub Sponsors" }), jsx(Link, {
									href: "/sponsors",
									children: "Learn more"
								})]
							}),
							fundingData.sponsorableOrg && jsx(GiHubFundingComponent, {
								name: fundingData.sponsorableOrg,
								isOrg: true
							}),
							jsx("div", {
								className: clsx(useCondensedLayout && FundingDialog_module_default.Box_30),
								children: fundingData.sponsorableUsers.map((user, index_0) => jsx(GiHubFundingComponent, {
									name: user,
									condensed: useCondensedLayout
								}, index_0))
							})
						]
					}), fundingData.externalAccounts.length !== 0 && jsxs(Fragment$1, { children: [jsx("h5", {
						className: FundingDialog_module_default.Flash_3,
						children: "External links"
					}), fundingData.externalAccounts.map(_temp2$1)] })]
				})]
			}), jsxs("div", {
				className: FundingDialog_module_default.Box_24,
				children: [jsxs(Fragment$1, { children: [jsx(Link, {
					inline: true,
					href: `${helpUrl}/articles/displaying-a-sponsor-button-in-your-repository`,
					children: "Learn more about funding links in repositories"
				}), "."] }), fundingData.reportAbuseLink && jsx(Link, {
					muted: true,
					href: fundingData.reportAbuseLink,
					children: "Report abuse"
				})]
			})]
		});
		$[0] = fileName;
		$[1] = fundingData.errors;
		$[2] = fundingData.externalAccounts;
		$[3] = fundingData.hasValidPlatform;
		$[4] = fundingData.reportAbuseLink;
		$[5] = fundingData.sponsorableOrg;
		$[6] = fundingData.sponsorableUsers;
		$[7] = helpUrl;
		$[8] = useCondensedLayout;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
FundingDialog.displayName = "FundingDialog";
function _temp2$1(link, index_1) {
	return jsxs("div", {
		className: FundingDialog_module_default.Box_21,
		children: [jsx("div", {
			className: FundingDialog_module_default.Box_22,
			children: link.platform !== "Custom" ? jsx("img", {
				src: `/images/modules/site/icons/funding_platforms/${link.platform.toLocaleLowerCase()}.svg`,
				alt: link.platform,
				className: FundingDialog_module_default.Box_23
			}) : jsx(Octicon, {
				size: 16,
				icon: LinkIcon,
				className: FundingDialog_module_default.Octicon_1
			})
		}), jsx(Link, {
			href: link.link,
			children: link.link
		})]
	}, index_1);
}
function _temp$1(error, index) {
	return jsxs("li", { children: [jsx("span", { children: error }), error === NON_SPONSORABLE_ERROR && jsxs(Fragment$1, { children: [" ", jsx(Link, {
		href: "/sponsors/accounts",
		children: "Apply to Sponsors."
	})] })] }, index);
}
function GiHubFundingComponent({ name, condensed, isOrg }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(FundingDialog_module_default.Flash_3, condensed && FundingDialog_module_default.Box_31),
		children: /* @__PURE__ */ jsxs("div", {
			style: {
				flexDirection: condensed ? "column" : "row",
				alignItems: condensed ? void 0 : "center"
			},
			className: FundingDialog_module_default.Box_25,
			children: [/* @__PURE__ */ jsxs("div", {
				className: FundingDialog_module_default.Box_26,
				children: [/* @__PURE__ */ jsx(GitHubAvatar, {
					square: isOrg,
					size: 40,
					src: ownerAvatarPath({ owner: name }),
					className: FundingDialog_module_default.GitHubAvatar_1
				}), /* @__PURE__ */ jsxs("div", {
					className: FundingDialog_module_default.Box_27,
					children: [/* @__PURE__ */ jsx("p", {
						className: FundingDialog_module_default.Box_28,
						children: /* @__PURE__ */ jsx(Link, {
							href: ownerPath({ owner: name }),
							className: FundingDialog_module_default.Link_1,
							children: name
						})
					}), /* @__PURE__ */ jsx("p", {
						className: FundingDialog_module_default.Box_29,
						children: /* @__PURE__ */ jsx(Link, {
							href: ownerPath({ owner: name }),
							className: FundingDialog_module_default.Link_1,
							children: name
						})
					})]
				})]
			}), /* @__PURE__ */ jsx(ButtonComponent, {
				leadingVisual: HeartIcon,
				size: "small",
				style: { marginTop: condensed ? "var(--base-size-16)" : 0 },
				className: FundingDialog_module_default.Button_1,
				children: "Sponsor"
			})]
		})
	});
}
GiHubFundingComponent.displayName = "GiHubFundingComponent";
var PreviewMessages = {
	DELETED: "preview_deleted",
	RENAMED: "preview_renamed",
	UNCHANGED: "preview_unchanged",
	ERROR: "preview_error",
	BLANK: "preview_blank"
};
function EditorPreview(t0) {
	const $ = c(21);
	const { editInfo, fileContent, fileName, refInfo, showMarkdownDiff, isRichtextRenderable } = t0;
	const [previewHTML, setPreviewHTML] = React.useState(void 0);
	const [diffData, setDiffData] = React.useState(void 0);
	const [blobData, setBlobData] = React.useState(void 0);
	const [message, setMessage] = React.useState(void 0);
	const [displayData, setDisplayData] = React.useState(void 0);
	const [fundingData, setFundingData] = React.useState(void 0);
	let t1;
	if ($[0] !== editInfo.previewEditPath || $[1] !== fileContent || $[2] !== fileName || $[3] !== isRichtextRenderable || $[4] !== refInfo.currentOid || $[5] !== showMarkdownDiff) {
		t1 = async (signal) => {
			const formData = new FormData();
			formData.append("code", fileContent);
			formData.append("commit", refInfo.currentOid);
			formData.append("blobname", fileName);
			formData.append("willcreatebranch", "false");
			formData.append("checkConflict", "true");
			setDiffData(void 0);
			setMessage(void 0);
			setPreviewHTML(void 0);
			setDisplayData(void 0);
			setFundingData(void 0);
			if (isRichtextRenderable) {
				const json = await (await verifiedFetch(!showMarkdownDiff ? `${editInfo.previewEditPath}?avoiddiff=true` : editInfo.previewEditPath, {
					method: "POST",
					body: formData,
					signal,
					headers: { Accept: "application/json" }
				})).json();
				const html = json.data.html || "";
				const markdownMessage = getPreviewMessage(html);
				if (json.data.message) setMessage({
					message: json.data.message,
					messageHTML: json.data.messageHtml ?? ""
				});
				else if (markdownMessage !== html) setMessage({
					message: markdownMessage,
					messageHTML: ""
				});
				else setPreviewHTML(html || "Error getting preview");
			} else {
				const json_0 = await (await verifiedFetch(editInfo.previewEditPath, {
					method: "POST",
					body: formData,
					signal,
					headers: { Accept: "application/json" }
				})).json();
				if (json_0.data.message) setMessage({
					message: json_0.data.message,
					messageHTML: json_0.data.messageHtml ?? ""
				});
				else if (json_0.data.diffLines && json_0.data.diffLines.length > 0) {
					const lines = json_0.data.diffLines;
					for (const line of lines) {
						if (line.rightLine.type === "ADDITION") line.rightLine.html = `+${line.rightLine.html}`;
						else line.rightLine.html = ` ${line.rightLine.html}`;
						if (line.leftLine.type === "DELETION") line.leftLine.html = `-${line.leftLine.html}`;
						else line.leftLine.html = ` ${line.leftLine.html}`;
					}
					setDiffData(lines);
				} else if (json_0.data.rawLines && json_0.data.rawLines.length > 0) setBlobData(json_0.data.rawLines.map((line_0, i) => ({
					lineNumber: i + 1,
					rawText: line_0,
					stylingDirectivesLine: json_0.data.stylingDirectives?.[i]
				})));
				else if (json_0.data.displayData) setDisplayData(json_0.data.displayData);
				else if (json_0.data.fundingLinks) setFundingData(json_0.data.fundingLinks);
				else setMessage({
					message: "There has been an error generating the preview.",
					messageHTML: ""
				});
			}
		};
		$[0] = editInfo.previewEditPath;
		$[1] = fileContent;
		$[2] = fileName;
		$[3] = isRichtextRenderable;
		$[4] = refInfo.currentOid;
		$[5] = showMarkdownDiff;
		$[6] = t1;
	} else t1 = $[6];
	const fetchPreview = useEffectEvent(t1);
	let t2;
	if ($[7] !== fetchPreview) {
		t2 = () => {
			const abortController = new AbortController();
			fetchPreview(abortController.signal);
			return () => {
				abortController.abort();
			};
		};
		$[7] = fetchPreview;
		$[8] = t2;
	} else t2 = $[8];
	let t3;
	if ($[9] !== showMarkdownDiff) {
		t3 = [showMarkdownDiff];
		$[9] = showMarkdownDiff;
		$[10] = t3;
	} else t3 = $[10];
	React.useEffect(t2, t3);
	let t4;
	if ($[11] !== blobData || $[12] !== diffData || $[13] !== displayData || $[14] !== fileName || $[15] !== fundingData || $[16] !== isRichtextRenderable || $[17] !== message || $[18] !== previewHTML || $[19] !== showMarkdownDiff) {
		t4 = jsx(Fragment$1, { children: previewHTML ? jsx("div", {
			className: `readme html-blob blob ${showMarkdownDiff ? "prose-diff" : "tmp-p-5"}`,
			children: jsx(VerifiedHTMLBox, {
				className: "markdown-body container-lg",
				html: previewHTML
			})
		}) : message ? jsxs("div", {
			className: EditorPreview_module_default.Box,
			children: [jsxs("span", {
				className: EditorPreview_module_default.Text,
				children: [getPreviewMessage(message.message), message.messageHTML && " But you can preview the whole file."]
			}), jsx(UnsafeHTMLBox, {
				className: clsx(isRichtextRenderable ? "markdown-body" : void 0, EditorPreview_module_default.UnsafeHTMLBox),
				html: message.messageHTML || ""
			})]
		}) : diffData && diffData.length ? jsx(DiffPreview, {
			diffData,
			fileName
		}) : blobData && blobData.length ? jsxs("div", {
			className: clsx("react-code-file-contents", EditorPreview_module_default.Box_1),
			children: [jsx("div", {
				className: "react-line-numbers",
				children: blobData.map(_temp)
			}), jsx("div", {
				className: "react-code-lines",
				children: blobData.map(_temp2)
			})]
		}) : displayData ? jsx(FileRendererBlob, {
			url: displayData.displayUrl,
			identityUuid: displayData.identityUuid,
			type: displayData.renderFileType,
			size: displayData.size
		}) : fundingData ? jsx(FundingDialog, {
			fileName,
			fundingData
		}) : jsxs("div", {
			className: EditorPreview_module_default.Box_2,
			children: [jsx(Spinner, {}), "Loading preview…"]
		}) });
		$[11] = blobData;
		$[12] = diffData;
		$[13] = displayData;
		$[14] = fileName;
		$[15] = fundingData;
		$[16] = isRichtextRenderable;
		$[17] = message;
		$[18] = previewHTML;
		$[19] = showMarkdownDiff;
		$[20] = t4;
	} else t4 = $[20];
	return t4;
}
EditorPreview.displayName = "EditorPreview";
function _temp2(lineData_0, index_0) {
	return jsx(CodeLine, {
		stylingDirectivesLine: lineData_0.stylingDirectivesLine,
		codeLineData: lineData_0,
		forceVisible: true,
		copilotAccessAllowed: false,
		shouldUseInert: false
	}, index_0);
}
function _temp(lineData, index) {
	return jsx(LineNumber, {
		codeLineData: lineData,
		preventClick: true
	}, index);
}
function getPreviewMessage(message) {
	switch (message) {
		case PreviewMessages.DELETED: return "The document has been deleted.";
		case PreviewMessages.RENAMED: return "The document was renamed without changes.";
		case PreviewMessages.UNCHANGED: return "There are no changes to show.";
		case PreviewMessages.BLANK: return "There is no content to preview.";
		case PreviewMessages.ERROR: return "There has been an error generating the preview.";
		default: return message;
	}
}
var WorkflowEditor_module_default = { Flash: "WorkflowEditor-module_IDw1Oq_Flash" };
function WorkflowEditor(t0) {
	const $ = c(8);
	const { helpUrl, isEnterprise, repositoryActionsEnabled, repositoryActionsReadinessPath } = t0;
	const [needsRunnersConfigured, setNeedsRunnersConfigured] = useState(false);
	let t1;
	let t2;
	if ($[0] !== isEnterprise || $[1] !== repositoryActionsEnabled || $[2] !== repositoryActionsReadinessPath) {
		t1 = () => {
			const getRunnerConfigurationRequired = async () => {
				try {
					const response = await verifiedFetchJSON(repositoryActionsReadinessPath);
					if (!response.ok) {
						setNeedsRunnersConfigured(false);
						return;
					}
					setNeedsRunnersConfigured(!(await response.json()).anyRunnersConfigured);
				} catch {
					setNeedsRunnersConfigured(false);
				}
			};
			if (isEnterprise && repositoryActionsEnabled) getRunnerConfigurationRequired();
		};
		t2 = [
			isEnterprise,
			repositoryActionsEnabled,
			repositoryActionsReadinessPath
		];
		$[0] = isEnterprise;
		$[1] = repositoryActionsEnabled;
		$[2] = repositoryActionsReadinessPath;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
	let t3;
	if ($[5] !== helpUrl || $[6] !== needsRunnersConfigured) {
		t3 = jsxs(Fragment$1, { children: [
			jsx("span", {
				id: "workflow-short-sha-warning-url",
				className: "d-none",
				"data-help-url": `${helpUrl}/actions/learn-github-actions/security-hardening-for-github-actions#using-third-party-actions`
			}),
			jsx("span", {
				id: "workflow-on-schedule-url",
				className: "d-none",
				"data-on-schedule-url": `${helpUrl}/actions/reference/workflow-syntax-for-github-actions#onschedule`
			}),
			jsx("span", {
				id: "workflow-dispatch-help-url",
				className: "d-none",
				"data-help-url": `${helpUrl}/actions/reference/events-that-trigger-workflows#workflow_dispatch`
			}),
			jsx("span", {
				id: "workflow-shell-help-url",
				className: "d-none",
				"data-help-url": `${helpUrl}/actions/using-workflows/workflow-syntax-for-github-actions#jobsjob_idstepsshell`
			}),
			needsRunnersConfigured && jsxs(Flash, {
				variant: "warning",
				"data-testid": "needs-runner-warning",
				className: WorkflowEditor_module_default.Flash,
				children: [
					jsx(Octicon, { icon: AlertIcon }),
					"This workflow will fail until runners are configured for the repository. Finish setting up GitHub Actions by",
					" ",
					jsx("a", {
						className: "Link--inTextBlock",
						href: `${helpUrl}/actions/hosting-your-own-runners/adding-self-hosted-runners`,
						children: "adding runners"
					}),
					"."
				]
			})
		] });
		$[5] = helpUrl;
		$[6] = needsRunnersConfigured;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
WorkflowEditor.displayName = "WorkflowEditor";
/**
* Thin wrapper around CodeMirror's linter extension that styles the lint marks
* @param Linter LintSource that returns array of Diagnostic
* @link https://codemirror.net/docs/ref/#lint.LintSource
* @returns linter extension
*/
function customLinter(lintSource) {
	return [linter(lintSource), EditorView.editorAttributes.of({ class: "custom-tooltips" })];
}
function getRootRule$3() {
	return fullRootRule$2();
}
function fullRootRule$2() {
	return { id: "" };
}
function fileOffsetToLineAndColumn(doc, offset) {
	const lines = doc.split("\n");
	let startLine = 0;
	let startColumn = 0;
	let lineOffset = 0;
	while (lineOffset + lines[startLine].length < offset) {
		lineOffset += lines[startLine].length + 1;
		startLine++;
	}
	startColumn = offset - lineOffset;
	return {
		startLine,
		startColumn
	};
}
function lint$1(text, _getRootRule) {
	const jsonErrors = getJsoncErrors(text);
	const messages = [];
	for (const error of jsonErrors) {
		const { startLine, startColumn } = fileOffsetToLineAndColumn(text, error.offset);
		const from = {
			line: startLine,
			ch: startColumn
		};
		const to = {
			line: startLine,
			ch: startColumn + error.length
		};
		messages.push({
			from,
			to,
			message: tooltipMessage(`JSONC Parser: ${printParseErrorCode(error.error)}`),
			severity: "error"
		});
	}
	return messages;
}
function tooltipMessage(value) {
	return html` <p>${value}</p> `;
}
function getJsoncErrors(doc) {
	const errors = [];
	parse$1(doc, errors);
	return errors;
}
function buildLintMarks(view, annotations) {
	return annotations.map((annotation) => {
		const fromOffset = posToOffset(view, annotation.from);
		const toOffset = posToOffset(view, annotation.to);
		const replaceValue = (value) => {
			return replaceRange(view, fromOffset, toOffset, value);
		};
		return {
			from: fromOffset,
			to: toOffset,
			message: "",
			severity: annotation.severity,
			renderMessage: () => {
				const tooltip = createTooltip(annotation);
				const select = tooltip.querySelector("select");
				const button = tooltip.querySelector("button");
				button.addEventListener("click", () => replaceValue(button.textContent));
				select.addEventListener("change", () => replaceValue(select.value));
				return tooltip;
			}
		};
	});
}
function createTooltip(lintMessage) {
	const { message, fixes } = lintMessage;
	const tooltipTemplate = html`<div class="Box Box--condensed text-small color-shadow-large js-yaml-lint">
    <div class="js-yaml-lint-header Box-row markdown-body f6">
      <p class="mb-0 text-bold js-yaml-lint-title" />
      <p class="color-fg-muted js-yaml-lint-subtitle">
        Did you mean <button class="btn-link btn-sm">todo-here</button>?
      </p>
    </div>
    <div class="Box-footer color-bg-subtle markdown-body f6 js-yaml-lint-message"></div>
    <div class="Box-footer color-bg-subtle js-yaml-lint-fixes">
      <select class="form-select select-sm" aria-label="Suggested fixes">
        <option>Other suggestions…</option>
      </select>
    </div>
  </div>`;
	const tooltip = document.createElement("div");
	render(tooltipTemplate, tooltip);
	const tooltipHeader = tooltip.querySelector(".js-yaml-lint-header");
	const tooltipTitle = tooltip.querySelector(".js-yaml-lint-title");
	const tooltipSubtitle = tooltip.querySelector(".js-yaml-lint-subtitle");
	const tooltipMessage = tooltip.querySelector(".js-yaml-lint-message");
	const tooltipFixes = tooltip.querySelector(".js-yaml-lint-fixes");
	const fixButton = tooltipSubtitle.querySelector("button");
	tooltipHeader.hidden = !fixes;
	tooltipMessage.hidden = !!fixes;
	tooltipSubtitle.hidden = !fixes;
	tooltipFixes.hidden = !fixes || fixes.length < 2;
	if (fixes) {
		render(message, tooltipTitle);
		fixButton.textContent = fixes[0];
		const select = tooltipFixes.querySelector("select");
		for (const fix of fixes.slice(1)) {
			const option = document.createElement("option");
			option.textContent = fix;
			select.appendChild(option);
		}
	} else render(message, tooltipMessage);
	return tooltip;
}
async function jsonLintSource(view) {
	return buildLintMarks(view, await lint$1(view.state.doc.toString(), getRootRule$3));
}
function devContainerEditor() {
	const helpPanelContainer = document.createElement("div");
	render(helpPanel, helpPanelContainer);
	return [customLinter(jsonLintSource), helpPanelConstructor(helpPanelContainer)];
}
var helpPanel = html`
  <div class="color-bg-subtle color-fg-muted px-2 py-1 m-0 border-top">
    <code id="dev-container-editor-help-default">
      See the
      <a target="_blank" rel="noopener noreferrer" href="https://containers.dev/implementors/json_reference/"
        >devcontainer.json</a
      >
      reference for more information
    </code>
  </div>
`;
async function ruleValues(rule, yaml, path) {
	if (!rule.values) throw new Error("Cannot get values of rule because `values` is not defined");
	return typeof rule.values === "function" ? await rule.values(yaml, path) : rule.values;
}
function ruleForPath(path, fullRootRule) {
	let rule = fullRootRule;
	for (const key of path) if (Number.isInteger(+key)) {
		if (!rule.items) return null;
		rule = rule.items;
	} else if (rule.map) rule = rule.map;
	else if (rule.rules && rule.rules[key]) rule = rule.rules[key];
	else return null;
	return rule;
}
function objectKeys(obj) {
	if (obj == null || typeof obj !== "object" || Array.isArray(obj)) return [];
	return Object.keys(obj);
}
function findNode(result, path) {
	let cursor = result;
	for (const key of path) {
		if (typeof cursor !== "object" || cursor == null) return null;
		cursor = cursor[key];
	}
	return cursor;
}
function keysForPath(result, path) {
	return objectKeys(findNode(result, path));
}
function codeTag(value) {
	return html` <code>${value}</code> `;
}
function joinCodeTags(values) {
	return html` ${values.map((value, i) => html` ${i > 0 ? ", " : ""}${codeTag(value)} `)} `;
}
function getIndentation(line) {
	const match = line.match(/^\s*/);
	return match ? match[0] : "";
}
function replaceWhitespaces(text, tab, ind) {
	return text.replace(/\t/g, tab).replace(/\n/g, `\n${ind}`);
}
function containsExpression(str) {
	return str.includes("${{");
}
function getSimplifiedText(textBeforeCursor) {
	const lines = textBeforeCursor.split("\n");
	const lastLine = lines[lines.length - 1];
	const indentation = getIndentation(lastLine);
	const lineStartsWithDash = lastLine.substring(indentation.length).startsWith("-");
	const simplified = lines.slice(0, lines.length - 1).map((ln) => {
		const lineIndentation = getIndentation(ln);
		if (lineIndentation.length > indentation.length) return "";
		if (lineIndentation.length === indentation.length && !lineStartsWithDash) return "";
		const arrStart = ln.substring(lineIndentation.length).match(/^-\s+/);
		if (arrStart && lineIndentation.length + arrStart[0].length >= indentation.length) {
			const totalIndentationLength = lineIndentation.length + arrStart[0].length;
			if (totalIndentationLength > indentation.length) return "";
			if (totalIndentationLength === indentation.length) return `${lineIndentation}-`;
		}
		return ln;
	});
	simplified.push(lastLine);
	return {
		simplifiedText: simplified.join("\n"),
		lastLine
	};
}
function getCurrentNode(result) {
	const path = [];
	let obj = result;
	while (obj && typeof obj === "object") {
		const keys = Object.keys(obj);
		const key = keys[keys.length - 1];
		path.push(key);
		obj = obj[key];
	}
	return {
		path,
		lastValue: obj != null ? String(obj) : ""
	};
}
function parse(start, end) {
	try {
		return {
			result: yaml.load(start + end),
			consumeKey: false
		};
	} catch (err) {
		const { message } = err;
		if (message.includes("mapping")) {
			const match = start.match(/\w+$/);
			return {
				result: yaml.load(`${start}:${end}`),
				lastValue: match ? match[0] : void 0,
				consumeKey: true
			};
		}
		if (message.includes("collection")) {
			const match = start.match(/,\s*$/);
			let full = match ? start.substring(0, start.length - match[0].length) : start;
			full += end.match(/^\]/) ? end : "]";
			const lastValue = match ? "" : void 0;
			return {
				result: yaml.load(full),
				lastValue,
				consumeKey: true
			};
		}
		throw err;
	}
}
function similarity(a, b) {
	const value = leven(a, b);
	if (a.endsWith("-latest")) return value - 1;
	return value;
}
function sortBySimilarity(values, currentValue) {
	return values.sort((a, b) => similarity(a, currentValue) - similarity(b, currentValue));
}
function usedValues(result, path) {
	const arr = findNode(result, path);
	return Array.isArray(arr) ? arr.map(String) : [];
}
function startsWithAndNotEquals(prefix, text) {
	return text.startsWith(prefix) && prefix !== text;
}
function filterValues(values, lastValue, ignoredValues = []) {
	const lowerCasedLastValue = lastValue.toLowerCase();
	const lowerCasedIgnoredValues = ignoredValues.map((s) => s.toLowerCase());
	return values.filter((value) => {
		const valueLower = String((typeof value == "object" && "text" in value ? value.text : null) || value).toLowerCase();
		return startsWithAndNotEquals(lowerCasedLastValue, valueLower) && !lowerCasedIgnoredValues.includes(valueLower);
	});
}
function autoCompleteAfterKey(rule) {
	if (rule.single || rule.values) return " ";
	if (rule.rules && !rule.items && !rule.map) return "\n	";
	if (!rule.rules && rule.items && !rule.map) return "\n	- ";
	return "";
}
async function suggestionsFromValuesWithoutExpression(yaml, path, rule, lastValue, ignoreItems, makeItAnArray) {
	let values;
	if (rule.single && rule.single.length === 1 && rule.single[0] === "boolean") values = ["true", "false"];
	else if (rule.values) values = await ruleValues(rule, yaml, path);
	else return null;
	const filtered = filterValues(values, lastValue, ignoreItems);
	if (filtered.length === 0) return null;
	return filtered.map((str) => ({
		displayText: str,
		snippet: { tokens: [makeItAnArray ? `[${str}]` : str] },
		replace: lastValue
	}));
}
function suggestionsFromRules(rules, lastValue, ignoreKeys) {
	return filterValues(Object.keys(rules), lastValue, ignoreKeys).map((key) => {
		const rule = rules[key];
		return {
			displayText: key,
			snippet: { tokens: [`${key}:${autoCompleteAfterKey(rule)}`] },
			replace: lastValue,
			description: rule.description
		};
	});
}
async function autocomplete(fullText, textBeforeCursor, getRootRule, suggestionsForExpression) {
	try {
		const { simplifiedText, lastLine } = getSimplifiedText(textBeforeCursor);
		const { result, lastValue: lastParsedValue, consumeKey } = parse(simplifiedText, "");
		const { path, lastValue: lastDataValue } = getCurrentNode(result);
		const lastValue = lastParsedValue != null ? lastParsedValue : lastDataValue;
		if (consumeKey) path.pop();
		const nested = lastLine.match(/^\s*(-\s*)?$/) !== null || lastLine.indexOf(":") === -1;
		const { result: workflow } = parse(textBeforeCursor, fullText.substring(textBeforeCursor.length));
		const ignoreKeys = keysForPath(workflow, path);
		const ignoreValues = usedValues(workflow, path);
		return await getSuggestions(getRootRule, suggestionsForExpression, workflow, path, lastValue, [...ignoreKeys, ...ignoreValues], nested);
	} catch {
		return null;
	}
}
async function getSuggestions(getRootRule, suggestionsForExpression, workflow, path, lastValue, ignoreItems, nested) {
	const rule = ruleForPath(path, getRootRule({}));
	if (!rule) return null;
	const currentValue = findNode(workflow, path);
	const isArray = Array.isArray(currentValue);
	if (isArray && rule.multipleValues !== true) return null;
	if (!nested || isArray || !rule.rules) {
		const makeItAnArray = !isArray && rule.multipleValues === true;
		return (suggestionsForExpression ? await suggestionsForExpression(workflow, path, lastValue) : null) || await suggestionsFromValuesWithoutExpression(workflow, path, rule, lastValue, ignoreItems, makeItAnArray);
	}
	return suggestionsFromRules(rule.rules, lastValue, ignoreItems);
}
/**
* Thin wrapper to create a custom, themed autocomplete extension
* @param completionSource function that returns a promise of a CompletionResult
* @param keymaps optional keybindings to override the default Tab keybinding
* @param overrideEnterKey optional boolean to override the default Enter keybinding
* @param compareCompletions optional comparison function for sorting completions
* @returns autocomplete extension
* @link https://codemirror.net/docs/ref/#autocomplete
*/
function customAutocomplete(completionSource, keymaps = [{
	key: "Tab",
	run: acceptCompletion
}], overrideEnterKey = false, compareCompletions) {
	return [
		autocompleteTheme,
		autocompletion({
			override: [completionSource],
			icons: false,
			defaultKeymap: !overrideEnterKey,
			compareCompletions
		}),
		Prec.highest(keymap.of(overrideEnterKey ? defaultKeymapWithoutEnter : [])),
		Prec.highest(keymap.of(keymaps))
	];
}
var defaultKeymapWithoutEnter = [
	{
		key: "Ctrl-Space",
		run: startCompletion
	},
	{
		key: "Escape",
		run: closeCompletion
	},
	{
		key: "ArrowDown",
		run: moveCompletionSelection(true)
	},
	{
		key: "ArrowUp",
		run: moveCompletionSelection(false)
	},
	{
		key: "PageDown",
		run: moveCompletionSelection(true, "page")
	},
	{
		key: "PageUp",
		run: moveCompletionSelection(false, "page")
	}
];
function yamlAutocomplete(completionContext) {
	return customAutocomplete(completionContext, [{
		key: "Tab",
		run: acceptCompletionAndStartNext
	}, {
		key: "Enter",
		run: acceptCompletionAndStartNext
	}], true);
}
/**
* Compare completions using sortText for proper ordering.
* This respects the language server's sortText convention (e.g., "runs-on 1", "runs-on 2").
*/
function compareCompletionsBySortText(a, b) {
	const aSort = a.sortText ?? a.label;
	const bSort = b.sortText ?? b.label;
	return aSort.localeCompare(bSort);
}
/**
* Determines if we should chain completions after accepting a completion.
* Returns true for key completions (text containing ": " or ":\n") or list markers.
*
* Examples that trigger chaining:
*   "runs-on: "    → cursor ready for inline value (e.g., ubuntu-latest)
*   "strategy:\n"  → cursor ready for nested map keys
*   "steps:\n  - " → cursor ready for sequence item keys (e.g., uses, run)
*   "\n  - "       → escape hatch "switch to list" - cursor ready for list item value
*/
function shouldChainCompletion(completion) {
	const lsCompletion = completion;
	if (lsCompletion.skipChaining) return false;
	const appliedText = lsCompletion.insertedText ?? (typeof completion.apply === "string" ? completion.apply : completion.label);
	return /:\s/.test(appliedText) || /- $/.test(appliedText);
}
/**
* Autocomplete configuration for language service integration.
* Features:
* - activateOnTyping: Shows completions automatically as the user types
* - activateOnCompletion: After accepting a completion that ends with `: ` or `:\n`,
*   automatically triggers completions for the value
*/
function yamlAutocompleteLanguageService(completionContext) {
	const acceptCompletionAndMaybeStartNext = (view) => {
		const selected = selectedCompletion(view.state);
		if (selected) {
			acceptCompletion(view);
			if (shouldChainCompletion(selected)) startCompletion(view);
			return true;
		}
		return false;
	};
	return customAutocomplete(completionContext, [{
		key: "Tab",
		run: acceptCompletionAndMaybeStartNext
	}, {
		key: "Enter",
		run: acceptCompletionAndMaybeStartNext
	}], true, compareCompletionsBySortText);
}
function yamlHelpPanel() {
	return helpPanelConstructor(autocompleteHelpPanel());
}
function buildCompletions(suggestions, cursor) {
	const completions = suggestions.map((suggestion) => {
		return {
			label: suggestion.displayText,
			detail: suggestion.description,
			from: suggestion.replace ? cursor - suggestion.replace.length : cursor,
			to: cursor,
			apply: applySnippet,
			snippet: suggestion.snippet
		};
	});
	return {
		from: completions.length > 0 ? completions[0].from : cursor,
		options: completions,
		filter: false
	};
}
function applySnippet(view, completion) {
	const { snippet } = completion;
	return insertSnippet(view, completion, snippet, true);
}
function insertSnippet(view, completion, snippet, indent) {
	const { tokens } = snippet;
	const tab = getIndentationUnit(view);
	for (let i = 0; i < tokens.length; i += 2) {
		const offset = offsetToPos(view, getCursor(view).from);
		const ind = indent ? getIndentation(getLine(view, offset.line + 1).text) : "";
		const token = replaceWhitespaces(tokens[i], tab, ind);
		view.dispatch({ ...insertCompletionText(view.state, token, view.state.selection.main.from, view.state.selection.main.to) });
	}
	view.dispatch({ annotations: pickedCompletion.of(completion) });
}
var acceptCompletionAndStartNext = (view) => {
	if (selectedCompletion(view.state)) {
		acceptCompletion(view);
		startCompletion(view);
		return true;
	}
	return false;
};
function autocompleteHelpPanel() {
	const dom = document.createElement("div");
	dom.className = "cm-help-panel border-top";
	dom.setAttribute("data-testid", "yaml-editor-help-footer");
	render(html`
    <div id="yaml-editor-help-default">
      Use <kbd>Control + Space</kbd>
      ${isMacOS() ? html`or <kbd>Option + Space</kbd>` : html``} to trigger autocomplete in most situations.
    </div>
    <div id="yaml-editor-help" hidden>
      <span className="js-yaml-editor-help-placeholder pr-1" />
      <span className="js-yaml-editor-help-tab"> Use <kbd>Tab</kbd> to navigate to the next placeholder. </span>
    </div>
  `, dom);
	return dom;
}
var timezones = [
	"Africa/Abidjan",
	"Africa/Accra",
	"Africa/Addis_Ababa",
	"Africa/Algiers",
	"Africa/Asmara",
	"Africa/Asmera",
	"Africa/Bamako",
	"Africa/Bangui",
	"Africa/Banjul",
	"Africa/Bissau",
	"Africa/Blantyre",
	"Africa/Brazzaville",
	"Africa/Bujumbura",
	"Africa/Cairo",
	"Africa/Casablanca",
	"Africa/Ceuta",
	"Africa/Conakry",
	"Africa/Dakar",
	"Africa/Dar_es_Salaam",
	"Africa/Djibouti",
	"Africa/Douala",
	"Africa/El_Aaiun",
	"Africa/Freetown",
	"Africa/Gaborone",
	"Africa/Harare",
	"Africa/Johannesburg",
	"Africa/Juba",
	"Africa/Kampala",
	"Africa/Khartoum",
	"Africa/Kigali",
	"Africa/Kinshasa",
	"Africa/Lagos",
	"Africa/Libreville",
	"Africa/Lome",
	"Africa/Luanda",
	"Africa/Lubumbashi",
	"Africa/Lusaka",
	"Africa/Malabo",
	"Africa/Maputo",
	"Africa/Maseru",
	"Africa/Mbabane",
	"Africa/Mogadishu",
	"Africa/Monrovia",
	"Africa/Nairobi",
	"Africa/Ndjamena",
	"Africa/Niamey",
	"Africa/Nouakchott",
	"Africa/Ouagadougou",
	"Africa/Porto-Novo",
	"Africa/Sao_Tome",
	"Africa/Timbuktu",
	"Africa/Tripoli",
	"Africa/Tunis",
	"Africa/Windhoek",
	"America/Adak",
	"America/Anchorage",
	"America/Anguilla",
	"America/Antigua",
	"America/Araguaina",
	"America/Argentina/Buenos_Aires",
	"America/Argentina/Catamarca",
	"America/Argentina/ComodRivadavia",
	"America/Argentina/Cordoba",
	"America/Argentina/Jujuy",
	"America/Argentina/La_Rioja",
	"America/Argentina/Mendoza",
	"America/Argentina/Rio_Gallegos",
	"America/Argentina/Salta",
	"America/Argentina/San_Juan",
	"America/Argentina/San_Luis",
	"America/Argentina/Tucuman",
	"America/Argentina/Ushuaia",
	"America/Aruba",
	"America/Asuncion",
	"America/Atikokan",
	"America/Atka",
	"America/Bahia",
	"America/Bahia_Banderas",
	"America/Barbados",
	"America/Belem",
	"America/Belize",
	"America/Blanc-Sablon",
	"America/Boa_Vista",
	"America/Bogota",
	"America/Boise",
	"America/Buenos_Aires",
	"America/Cambridge_Bay",
	"America/Campo_Grande",
	"America/Cancun",
	"America/Caracas",
	"America/Catamarca",
	"America/Cayenne",
	"America/Cayman",
	"America/Chicago",
	"America/Chihuahua",
	"America/Ciudad_Juarez",
	"America/Coral_Harbour",
	"America/Cordoba",
	"America/Costa_Rica",
	"America/Creston",
	"America/Cuiaba",
	"America/Curacao",
	"America/Danmarkshavn",
	"America/Dawson",
	"America/Dawson_Creek",
	"America/Denver",
	"America/Detroit",
	"America/Dominica",
	"America/Edmonton",
	"America/Eirunepe",
	"America/El_Salvador",
	"America/Ensenada",
	"America/Fort_Nelson",
	"America/Fort_Wayne",
	"America/Fortaleza",
	"America/Glace_Bay",
	"America/Godthab",
	"America/Goose_Bay",
	"America/Grand_Turk",
	"America/Grenada",
	"America/Guadeloupe",
	"America/Guatemala",
	"America/Guayaquil",
	"America/Guyana",
	"America/Halifax",
	"America/Havana",
	"America/Hermosillo",
	"America/Indiana/Indianapolis",
	"America/Indiana/Knox",
	"America/Indiana/Marengo",
	"America/Indiana/Petersburg",
	"America/Indiana/Tell_City",
	"America/Indiana/Vevay",
	"America/Indiana/Vincennes",
	"America/Indiana/Winamac",
	"America/Indianapolis",
	"America/Inuvik",
	"America/Iqaluit",
	"America/Jamaica",
	"America/Jujuy",
	"America/Juneau",
	"America/Kentucky/Louisville",
	"America/Kentucky/Monticello",
	"America/Knox_IN",
	"America/Kralendijk",
	"America/La_Paz",
	"America/Lima",
	"America/Los_Angeles",
	"America/Louisville",
	"America/Lower_Princes",
	"America/Maceio",
	"America/Managua",
	"America/Manaus",
	"America/Marigot",
	"America/Martinique",
	"America/Matamoros",
	"America/Mazatlan",
	"America/Mendoza",
	"America/Menominee",
	"America/Merida",
	"America/Metlakatla",
	"America/Mexico_City",
	"America/Miquelon",
	"America/Moncton",
	"America/Monterrey",
	"America/Montevideo",
	"America/Montreal",
	"America/Montserrat",
	"America/Nassau",
	"America/New_York",
	"America/Nipigon",
	"America/Nome",
	"America/Noronha",
	"America/North_Dakota/Beulah",
	"America/North_Dakota/Center",
	"America/North_Dakota/New_Salem",
	"America/Nuuk",
	"America/Ojinaga",
	"America/Panama",
	"America/Pangnirtung",
	"America/Paramaribo",
	"America/Phoenix",
	"America/Port-au-Prince",
	"America/Port_of_Spain",
	"America/Porto_Acre",
	"America/Porto_Velho",
	"America/Puerto_Rico",
	"America/Punta_Arenas",
	"America/Rainy_River",
	"America/Rankin_Inlet",
	"America/Recife",
	"America/Regina",
	"America/Resolute",
	"America/Rio_Branco",
	"America/Rosario",
	"America/Santa_Isabel",
	"America/Santarem",
	"America/Santiago",
	"America/Santo_Domingo",
	"America/Sao_Paulo",
	"America/Scoresbysund",
	"America/Shiprock",
	"America/Sitka",
	"America/St_Barthelemy",
	"America/St_Johns",
	"America/St_Kitts",
	"America/St_Lucia",
	"America/St_Thomas",
	"America/St_Vincent",
	"America/Swift_Current",
	"America/Tegucigalpa",
	"America/Thule",
	"America/Thunder_Bay",
	"America/Tijuana",
	"America/Toronto",
	"America/Tortola",
	"America/Vancouver",
	"America/Virgin",
	"America/Whitehorse",
	"America/Winnipeg",
	"America/Yakutat",
	"America/Yellowknife",
	"Antarctica/Casey",
	"Antarctica/Davis",
	"Antarctica/DumontDUrville",
	"Antarctica/Macquarie",
	"Antarctica/Mawson",
	"Antarctica/McMurdo",
	"Antarctica/Palmer",
	"Antarctica/Rothera",
	"Antarctica/South_Pole",
	"Antarctica/Syowa",
	"Antarctica/Troll",
	"Antarctica/Vostok",
	"Arctic/Longyearbyen",
	"Asia/Aden",
	"Asia/Almaty",
	"Asia/Amman",
	"Asia/Anadyr",
	"Asia/Aqtau",
	"Asia/Aqtobe",
	"Asia/Ashgabat",
	"Asia/Ashkhabad",
	"Asia/Atyrau",
	"Asia/Baghdad",
	"Asia/Bahrain",
	"Asia/Baku",
	"Asia/Bangkok",
	"Asia/Barnaul",
	"Asia/Beirut",
	"Asia/Bishkek",
	"Asia/Brunei",
	"Asia/Calcutta",
	"Asia/Chita",
	"Asia/Choibalsan",
	"Asia/Chongqing",
	"Asia/Chungking",
	"Asia/Colombo",
	"Asia/Dacca",
	"Asia/Damascus",
	"Asia/Dhaka",
	"Asia/Dili",
	"Asia/Dubai",
	"Asia/Dushanbe",
	"Asia/Famagusta",
	"Asia/Gaza",
	"Asia/Harbin",
	"Asia/Hebron",
	"Asia/Ho_Chi_Minh",
	"Asia/Hong_Kong",
	"Asia/Hovd",
	"Asia/Irkutsk",
	"Asia/Istanbul",
	"Asia/Jakarta",
	"Asia/Jayapura",
	"Asia/Jerusalem",
	"Asia/Kabul",
	"Asia/Kamchatka",
	"Asia/Karachi",
	"Asia/Kashgar",
	"Asia/Kathmandu",
	"Asia/Katmandu",
	"Asia/Khandyga",
	"Asia/Kolkata",
	"Asia/Krasnoyarsk",
	"Asia/Kuala_Lumpur",
	"Asia/Kuching",
	"Asia/Kuwait",
	"Asia/Macao",
	"Asia/Macau",
	"Asia/Magadan",
	"Asia/Makassar",
	"Asia/Manila",
	"Asia/Muscat",
	"Asia/Nicosia",
	"Asia/Novokuznetsk",
	"Asia/Novosibirsk",
	"Asia/Omsk",
	"Asia/Oral",
	"Asia/Phnom_Penh",
	"Asia/Pontianak",
	"Asia/Pyongyang",
	"Asia/Qatar",
	"Asia/Qostanay",
	"Asia/Qyzylorda",
	"Asia/Rangoon",
	"Asia/Riyadh",
	"Asia/Saigon",
	"Asia/Sakhalin",
	"Asia/Samarkand",
	"Asia/Seoul",
	"Asia/Shanghai",
	"Asia/Singapore",
	"Asia/Srednekolymsk",
	"Asia/Taipei",
	"Asia/Tashkent",
	"Asia/Tbilisi",
	"Asia/Tehran",
	"Asia/Tel_Aviv",
	"Asia/Thimbu",
	"Asia/Thimphu",
	"Asia/Tokyo",
	"Asia/Tomsk",
	"Asia/Ujung_Pandang",
	"Asia/Ulaanbaatar",
	"Asia/Ulan_Bator",
	"Asia/Urumqi",
	"Asia/Ust-Nera",
	"Asia/Vientiane",
	"Asia/Vladivostok",
	"Asia/Yakutsk",
	"Asia/Yangon",
	"Asia/Yekaterinburg",
	"Asia/Yerevan",
	"Atlantic/Azores",
	"Atlantic/Bermuda",
	"Atlantic/Canary",
	"Atlantic/Cape_Verde",
	"Atlantic/Faeroe",
	"Atlantic/Faroe",
	"Atlantic/Jan_Mayen",
	"Atlantic/Madeira",
	"Atlantic/Reykjavik",
	"Atlantic/South_Georgia",
	"Atlantic/St_Helena",
	"Atlantic/Stanley",
	"Australia/ACT",
	"Australia/Adelaide",
	"Australia/Brisbane",
	"Australia/Broken_Hill",
	"Australia/Canberra",
	"Australia/Currie",
	"Australia/Darwin",
	"Australia/Eucla",
	"Australia/Hobart",
	"Australia/LHI",
	"Australia/Lindeman",
	"Australia/Lord_Howe",
	"Australia/Melbourne",
	"Australia/NSW",
	"Australia/North",
	"Australia/Perth",
	"Australia/Queensland",
	"Australia/South",
	"Australia/Sydney",
	"Australia/Tasmania",
	"Australia/Victoria",
	"Australia/West",
	"Australia/Yancowinna",
	"Brazil/Acre",
	"Brazil/DeNoronha",
	"Brazil/East",
	"Brazil/West",
	"CET",
	"CST6CDT",
	"Canada/Atlantic",
	"Canada/Central",
	"Canada/Eastern",
	"Canada/Mountain",
	"Canada/Newfoundland",
	"Canada/Pacific",
	"Canada/Saskatchewan",
	"Canada/Yukon",
	"Chile/Continental",
	"Chile/EasterIsland",
	"Cuba",
	"EET",
	"EST",
	"EST5EDT",
	"Egypt",
	"Eire",
	"Etc/GMT",
	"Etc/GMT+0",
	"Etc/GMT+1",
	"Etc/GMT+10",
	"Etc/GMT+11",
	"Etc/GMT+12",
	"Etc/GMT+2",
	"Etc/GMT+3",
	"Etc/GMT+4",
	"Etc/GMT+5",
	"Etc/GMT+6",
	"Etc/GMT+7",
	"Etc/GMT+8",
	"Etc/GMT+9",
	"Etc/GMT-0",
	"Etc/GMT-1",
	"Etc/GMT-10",
	"Etc/GMT-11",
	"Etc/GMT-12",
	"Etc/GMT-13",
	"Etc/GMT-14",
	"Etc/GMT-2",
	"Etc/GMT-3",
	"Etc/GMT-4",
	"Etc/GMT-5",
	"Etc/GMT-6",
	"Etc/GMT-7",
	"Etc/GMT-8",
	"Etc/GMT-9",
	"Etc/GMT0",
	"Etc/Greenwich",
	"Etc/UCT",
	"Etc/UTC",
	"Etc/Universal",
	"Etc/Zulu",
	"Europe/Amsterdam",
	"Europe/Andorra",
	"Europe/Astrakhan",
	"Europe/Athens",
	"Europe/Belfast",
	"Europe/Belgrade",
	"Europe/Berlin",
	"Europe/Bratislava",
	"Europe/Brussels",
	"Europe/Bucharest",
	"Europe/Budapest",
	"Europe/Busingen",
	"Europe/Chisinau",
	"Europe/Copenhagen",
	"Europe/Dublin",
	"Europe/Gibraltar",
	"Europe/Guernsey",
	"Europe/Helsinki",
	"Europe/Isle_of_Man",
	"Europe/Istanbul",
	"Europe/Jersey",
	"Europe/Kaliningrad",
	"Europe/Kiev",
	"Europe/Kirov",
	"Europe/Kyiv",
	"Europe/Lisbon",
	"Europe/Ljubljana",
	"Europe/London",
	"Europe/Luxembourg",
	"Europe/Madrid",
	"Europe/Malta",
	"Europe/Mariehamn",
	"Europe/Minsk",
	"Europe/Monaco",
	"Europe/Moscow",
	"Europe/Nicosia",
	"Europe/Oslo",
	"Europe/Paris",
	"Europe/Podgorica",
	"Europe/Prague",
	"Europe/Riga",
	"Europe/Rome",
	"Europe/Samara",
	"Europe/San_Marino",
	"Europe/Sarajevo",
	"Europe/Saratov",
	"Europe/Simferopol",
	"Europe/Skopje",
	"Europe/Sofia",
	"Europe/Stockholm",
	"Europe/Tallinn",
	"Europe/Tirane",
	"Europe/Tiraspol",
	"Europe/Ulyanovsk",
	"Europe/Uzhgorod",
	"Europe/Vaduz",
	"Europe/Vatican",
	"Europe/Vienna",
	"Europe/Vilnius",
	"Europe/Volgograd",
	"Europe/Warsaw",
	"Europe/Zagreb",
	"Europe/Zaporozhye",
	"Europe/Zurich",
	"Factory",
	"GB",
	"GB-Eire",
	"GMT",
	"GMT+0",
	"GMT-0",
	"GMT0",
	"Greenwich",
	"HST",
	"Hongkong",
	"Iceland",
	"Indian/Antananarivo",
	"Indian/Chagos",
	"Indian/Christmas",
	"Indian/Cocos",
	"Indian/Comoro",
	"Indian/Kerguelen",
	"Indian/Mahe",
	"Indian/Maldives",
	"Indian/Mauritius",
	"Indian/Mayotte",
	"Indian/Reunion",
	"Iran",
	"Israel",
	"Jamaica",
	"Japan",
	"Kwajalein",
	"Libya",
	"MET",
	"MST",
	"MST7MDT",
	"Mexico/BajaNorte",
	"Mexico/BajaSur",
	"Mexico/General",
	"NZ",
	"NZ-CHAT",
	"Navajo",
	"PRC",
	"PST8PDT",
	"Pacific/Apia",
	"Pacific/Auckland",
	"Pacific/Bougainville",
	"Pacific/Chatham",
	"Pacific/Chuuk",
	"Pacific/Easter",
	"Pacific/Efate",
	"Pacific/Enderbury",
	"Pacific/Fakaofo",
	"Pacific/Fiji",
	"Pacific/Funafuti",
	"Pacific/Galapagos",
	"Pacific/Gambier",
	"Pacific/Guadalcanal",
	"Pacific/Guam",
	"Pacific/Honolulu",
	"Pacific/Johnston",
	"Pacific/Kanton",
	"Pacific/Kiritimati",
	"Pacific/Kosrae",
	"Pacific/Kwajalein",
	"Pacific/Majuro",
	"Pacific/Marquesas",
	"Pacific/Midway",
	"Pacific/Nauru",
	"Pacific/Niue",
	"Pacific/Norfolk",
	"Pacific/Noumea",
	"Pacific/Pago_Pago",
	"Pacific/Palau",
	"Pacific/Pitcairn",
	"Pacific/Pohnpei",
	"Pacific/Ponape",
	"Pacific/Port_Moresby",
	"Pacific/Rarotonga",
	"Pacific/Saipan",
	"Pacific/Samoa",
	"Pacific/Tahiti",
	"Pacific/Tarawa",
	"Pacific/Tongatapu",
	"Pacific/Truk",
	"Pacific/Wake",
	"Pacific/Wallis",
	"Pacific/Yap",
	"Poland",
	"Portugal",
	"ROC",
	"ROK",
	"Singapore",
	"Türkiye",
	"UCT",
	"US/Alaska",
	"US/Aleutian",
	"US/Arizona",
	"US/Central",
	"US/East-Indiana",
	"US/Eastern",
	"US/Hawaii",
	"US/Indiana-Starke",
	"US/Michigan",
	"US/Mountain",
	"US/Pacific",
	"US/Samoa",
	"UTC",
	"Universal",
	"W-SU",
	"WET",
	"Zulu"
];
var scheduleRule = (required) => ({
	values: [
		"interval",
		"day",
		"time",
		"timezone"
	],
	required,
	rules: {
		interval: {
			values: [
				"daily",
				"weekly",
				"monthly"
			],
			required: true
		},
		day: {
			values: [
				"monday",
				"tuesday",
				"wednesday",
				"thursday",
				"friday",
				"saturday",
				"sunday"
			],
			sortSuggestions: false
		},
		time: {
			single: ["string"],
			validateValue: async (template, path, value) => {
				if (typeof value != "string") return;
				if (!/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(value)) return {
					message: html`Time must be in the format HH:MM`,
					severity: "error"
				};
			}
		},
		timezone: { values: timezones }
	}
});
function fullRootRule$1() {
	return { rules: {
		version: {
			description: "The version of the dependabot file",
			required: true,
			values: ["2"]
		},
		"enable-beta-ecosystems": {
			description: "Enable beta ecosystems",
			single: ["boolean"]
		},
		registries: {
			description: "Private registries that Dependabot can access",
			map: {
				async validateKey(template, path) {
					if (typeof path[1] != "string") return {
						message: html`Registry id must be a string`,
						severity: "error"
					};
				},
				rules: {
					type: {
						description: "The type of registry",
						values: [
							"composer-repository",
							"docker-registry",
							"git",
							"helm-registry",
							"hex-repository",
							"hex-organization",
							"maven-repository",
							"npm-registry",
							"nuget-feed",
							"python-index",
							"rubygems-server",
							"terraform-registry"
						]
					},
					url: {
						description: "The URL of the registry",
						single: ["string"]
					},
					username: {
						description: "The username to use to access the registry",
						single: ["string"]
					},
					password: {
						description: "The password to use to access the registry",
						single: ["string"]
					},
					key: {
						description: "The key to use to access the registry",
						single: ["string"]
					},
					token: {
						description: "The token to use to access the registry",
						single: ["string"]
					},
					repo: {
						description: "The name to use to identify the repository",
						single: ["string"]
					},
					"auth-key": {
						description: "The auth key to use to access the registry",
						single: ["string"]
					},
					"public-key-fingerprint": {
						description: "The public key fingerprint to use to verify the repository",
						single: ["string"]
					},
					"replaces-base": {
						description: "Resolves dependencies by using the specified URL rather than the base URL of the Python Package Index",
						single: ["boolean"]
					}
				}
			}
		},
		"multi-ecosystem-groups": {
			description: "Groups of dependencies across multiple ecosystems",
			keyPlaceholder: "multi_ecosystem_group_id",
			keyPlaceholderHelp: "Enter the id of the new Multi-Ecosystem Group",
			multipleValues: true,
			map: {
				async validateKey(group, path) {
					const currentGroupName = path[1].toLowerCase();
					if (!/^[a-z_]/i.test(currentGroupName)) return {
						message: html` Group name must start with a letter or ${codeTag("_")} `,
						severity: "error"
					};
					if (!/^[\w-]+$/i.test(currentGroupName)) return {
						message: html`
                  Group name must contain only alphanumeric characters, ${codeTag("-")}, or ${codeTag("_")}
                `,
						severity: "error"
					};
					if (keysForPath(group, path.slice(0, path.length - 1)).map((k) => k.toLowerCase()).filter((groupName) => groupName === currentGroupName).length > 1) return {
						message: html` This group name is already used in another name`,
						severity: "error"
					};
				},
				rules: { schedule: scheduleRule(true) }
			}
		},
		updates: {
			required: true,
			map: { async validateKey(update, path) {
				const jobKeys = keysForPath(update, path);
				if (jobKeys.includes("multi-ecosystem-group") && (!jobKeys.includes("patterns") || !jobKeys.includes("exclude-patterns"))) return {
					message: html`An multi-ecosystem update requires either ${codeTag("patterns")} or
                ${codeTag("exclude-patterns")}`,
					severity: "error"
				};
				if (!jobKeys.includes("multi-ecosystem-group") && !jobKeys.includes("schedule")) return {
					message: html`Missing required key schedule`,
					severity: "error"
				};
			} },
			items: { rules: {
				allow: {
					description: "Customize which updates are allowed",
					items: {
						values: ["dependency-name", "dependency-type"],
						rules: {
							"dependency-name": {
								description: "The name of the dependency",
								single: ["string"]
							},
							"dependency-type": {
								description: "The type of dependency",
								values: [
									"direct",
									"indirect",
									"all",
									"production",
									"development"
								]
							}
						}
					}
				},
				assignees: {
					description: "Assignees to assign to pull requests",
					multipleValues: true
				},
				"commit-message": {
					description: "Commit message preferences",
					rules: {
						prefix: {
							description: "Prefix to use for commit messages",
							single: ["string"],
							validateValue: async (template, path, value) => {
								if (typeof value != "string") return;
								if (value.length > 50) return {
									message: html`Commit message prefix must be 50 characters or less`,
									severity: "error"
								};
							}
						},
						"prefix-development": {
							description: "Prefix to use for commit messages for development dependencies",
							single: ["string"],
							validateValue: async (template, path, value) => {
								if (typeof value != "string") return;
								if (value.length > 50) return {
									message: html`Commit message prefix must be 50 characters or less`,
									severity: "error"
								};
							}
						},
						include: {
							description: "Specifies that any prefix is followed by a list of the dependencies updated in the commit",
							values: ["scope"]
						}
					}
				},
				directory: {
					description: "Location of the package manifests",
					required: true,
					single: ["string"]
				},
				"enable-beta-ecosystems": {
					description: "Enable support for beta ecosystems",
					single: ["boolean"]
				},
				ignore: {
					description: "Specify which dependencies are ignored",
					items: {
						values: [
							"dependency-name",
							"update-types",
							"versions"
						],
						rules: {
							"dependency-name": {
								description: "Ignore updates for dependencies with matching names",
								single: ["string"]
							},
							versions: {
								description: "Ignore updates for dependencies with matching versions",
								items: { single: ["string"] }
							},
							"update-types": {
								description: "Ignore types of updates",
								items: { values: [
									"version-update:semver-major",
									"version-update:semver-minor",
									"version-update:semver-patch"
								] }
							}
						}
					}
				},
				"insecure-external-code-execution": {
					description: "Allow insecure external code execution",
					values: ["allow", "deny"]
				},
				groups: {
					description: "Define a group of dependencies to update together in a single PR",
					multipleValues: true
				},
				labels: {
					description: "Labels to add to pull requests",
					multipleValues: true
				},
				milestone: {
					description: "Milestone to add to pull requests",
					single: ["number"]
				},
				"open-pull-requests-limit": {
					description: "Limit the number of open pull requests",
					single: ["number"]
				},
				"package-ecosystem": {
					description: "Package manager to use",
					values: [
						"bun",
						"bundler",
						"cargo",
						"composer",
						"conda",
						"devcontainers",
						"docker",
						"docker-compose",
						"dotnet-sdk",
						"elm",
						"github-actions",
						"gitsubmodule",
						"gomod",
						"gradle",
						"helm",
						"julia",
						"maven",
						"mix",
						"npm",
						"nuget",
						"opentofu",
						"pip",
						"pre-commit",
						"pub",
						"rust-toolchain",
						"swift",
						"terraform",
						"uv",
						"vcpkg"
					],
					required: true
				},
				"pull-request-branch-name": { rules: { separator: {
					description: "Separator to use between the package manager and the dependency",
					values: [
						"-",
						"/",
						"_"
					]
				} } },
				registries: {
					description: "Private registries that Dependabot can access, as specified above",
					multipleValues: true
				},
				"rebase-strategy": {
					description: "How to rebase pull requests",
					values: ["disabled", "auto"]
				},
				reviewers: {
					description: "Reviewers to assign to pull requests",
					multipleValues: true
				},
				patterns: {
					description: "A regular expression to match against dependency names",
					multipleValues: true
				},
				"exclude-patterns": {
					description: "A regular expression to match against dependency names to exclude them from updates",
					multipleValues: true
				},
				"exclude-paths": {
					description: "List of file paths to exclude from dependency updates",
					multipleValues: true
				},
				"multi-ecosystem-group": {
					description: "The multi-ecosystem group to use for this update",
					single: ["string"]
				},
				schedule: scheduleRule(false),
				"target-branch": {
					description: "The branch to create pull requests against",
					single: ["string"]
				},
				vendor: {
					description: "Update vendored or cached dependencies",
					single: ["boolean"]
				},
				"versioning-strategy": {
					description: "How to update dependencies",
					values: [
						"lockfile-only",
						"auto",
						"widen",
						"increase",
						"increase-if-necessary"
					]
				}
			} }
		}
	} };
}
function getRootRule$2() {
	return fullRootRule$1();
}
function isObject(value) {
	return typeof value === "object" && value !== null;
}
function lineInfo(lineNumber, line) {
	return {
		from: {
			line: lineNumber,
			ch: (line.match(/^\s*/) || [""])[0].length
		},
		to: {
			line: lineNumber,
			ch: line.length
		}
	};
}
function keyInfo(lineNumber, line, key) {
	const ch = line.indexOf(key);
	if (ch === -1) return lineInfo(lineNumber, line);
	return {
		from: {
			line: lineNumber,
			ch
		},
		to: {
			line: lineNumber,
			ch: ch + key.length
		}
	};
}
function valueInfo(lineNumber, line, value) {
	if (isObject(value)) return lineInfo(lineNumber, line);
	const asString = String(value);
	const ch = line.lastIndexOf(asString);
	if (ch === -1) return lineInfo(lineNumber, line);
	return {
		from: {
			line: lineNumber,
			ch
		},
		to: {
			line: lineNumber,
			ch: ch + asString.length
		}
	};
}
function buildKeyMessage(paths, path, validation) {
	const pathInfo = paths[path.join(".")];
	const { message, fixes, severity } = validation;
	return {
		message,
		fixes,
		severity,
		from: pathInfo.key.from,
		to: pathInfo.key.to
	};
}
function buildValueMessage(paths, path, validation) {
	const pathInfo = paths[path.join(".")];
	const { message, fixes, severity } = validation;
	return {
		message,
		fixes,
		severity,
		from: pathInfo.value.from,
		to: pathInfo.value.to
	};
}
function repeatedValues(array) {
	const set = /* @__PURE__ */ new Set();
	const repeated = /* @__PURE__ */ new Set();
	for (const value of array) {
		if (set.has(value)) repeated.add(value);
		set.add(value);
	}
	return [...repeated];
}
function unexpectedTypeMessage(expected, found) {
	return {
		message: html` Invalid type found: ${expected.length === 1 ? html` ${codeTag(expected[0])} was expected ` : html` one of ${joinCodeTags(expected)} were expected `} but ${found} was found `,
		severity: "error"
	};
}
async function validate({ yamlContent, paths, path, object, rule, messages, processExpression }) {
	if (object === void 0) return;
	if (rule === void 0) return;
	if (rule.validateKey) {
		const validation = await rule.validateKey(yamlContent, path);
		if (validation) {
			messages.push(buildKeyMessage(paths, path, validation));
			if (validation.severity === "error") return;
		}
	}
	if (object === null) {
		if (rule.nullable === true) return;
		messages.push(buildValueMessage(paths, path, {
			message: html` This value cannot be null `,
			severity: "error"
		}));
	} else if (typeof object === "object") {
		if (Array.isArray(object)) {
			if (rule.maxLength && object.length > rule.maxLength) messages.push(buildValueMessage(paths, path, {
				message: html` Maximum of ${rule.maxLength.toString()} elements allowed `,
				severity: "error"
			}));
			if (rule.values) {
				if (rule.multipleValues !== true) {
					messages.push(buildValueMessage(paths, path, {
						message: html` Only a single value is allowed here `,
						severity: "error"
					}));
					return;
				}
				const values = await ruleValues(rule, yamlContent, path);
				const unknown = object.map(String).filter((value) => !values.includes(value));
				const repeated = repeatedValues(object.map(String).filter((value) => values.includes(value)));
				if (repeated.length > 0 || unknown.length > 0) {
					const message = html`
            ${repeated.length > 0 ? html` Repeated values: ${joinCodeTags(repeated)} ` : ""}
            ${repeated.length > 0 && unknown.length > 0 ? html` <br /> ` : ""}
            ${unknown.length > 0 ? html` Invalid values: ${joinCodeTags(unknown)} ` : ""}
          `;
					messages.push(buildValueMessage(paths, path, {
						message,
						severity: "error"
					}));
				}
			} else if (rule.items) for (const index in object) await validate({
				yamlContent,
				paths,
				path: [...path, index],
				object: object[index],
				rule: rule.items,
				messages,
				processExpression
			});
			else if (rule.single || rule.map || rule.rules) {
				const expected = rule.single || [];
				if (rule.map) expected.push("map");
				if (rule.rules) expected.push("object");
				messages.push(buildValueMessage(paths, path, unexpectedTypeMessage(expected, "an array")));
			}
		} else if (rule.map) for (const index in object) await validate({
			yamlContent,
			paths,
			path: [...path, index],
			object: object[index],
			rule: rule.map,
			messages,
			processExpression
		});
		else if (rule.rules) {
			const { rules } = rule;
			for (const ruleKey in rules) if (object[ruleKey] !== void 0) await validate({
				yamlContent,
				paths,
				path: [...path, ruleKey],
				object: object[ruleKey],
				rule: rules[ruleKey],
				messages,
				processExpression
			});
			else if (rules[ruleKey].required === true) {
				const keyMessage = path.length === 0 ? "root key" : "key";
				messages.push(buildKeyMessage(paths, path, {
					message: html` Missing required ${keyMessage} ${codeTag(ruleKey)} `,
					severity: "error"
				}));
			}
			for (const index in object) if (!rule.rules[index]) {
				const expected = Object.keys(rule.rules).filter((key) => object[key] === void 0);
				const message = html` Unknown key ${codeTag(index)} `;
				const fixes = rule.sortSuggestions === false ? expected : sortBySimilarity(expected, index);
				messages.push(buildKeyMessage(paths, [...path, index], {
					message,
					fixes,
					severity: "error"
				}));
			}
		} else if (rule.single || rule.items) {
			const expected = rule.single || [];
			if (rule.values || rule.items) expected.push("array");
			messages.push(buildValueMessage(paths, path, unexpectedTypeMessage(expected, object instanceof Date ? "a date" : "an object")));
		}
	} else {
		const str = String(object);
		if (containsExpression(str) && processExpression) {
			const validation = await processExpression(yamlContent, path, str, rule);
			if (validation) messages.push(buildValueMessage(paths, path, validation));
			return;
		}
		if (rule.validateValue) {
			const validation = await rule.validateValue(yamlContent, path, object);
			if (validation) {
				messages.push(buildValueMessage(paths, path, validation));
				if (validation.severity === "error") return;
			}
		}
		if (rule.single) {
			const { single: types } = rule;
			const objectType = typeof object;
			if (!types.includes(objectType)) messages.push(buildValueMessage(paths, path, unexpectedTypeMessage(types, codeTag(objectType))));
		} else if (rule.values) {
			const values = await ruleValues(rule, yamlContent, path);
			if (!values.includes(rule.caseInsensitive ? str.toLowerCase() : str)) {
				const fixes = rule.sortSuggestions === false ? values : sortBySimilarity(values, String(object));
				messages.push(buildValueMessage(paths, path, {
					message: html` Invalid value: ${codeTag(str)} `,
					fixes,
					severity: "error"
				}));
			}
		} else if (rule.map || rule.rules || rule.items) {
			const objectType = object === null ? "null" : typeof object;
			const expected = [];
			if (rule.map || rule.rules) expected.push("object");
			if (rule.items) expected.push("array");
			messages.push(buildValueMessage(paths, path, unexpectedTypeMessage(expected, codeTag(objectType))));
		}
	}
}
function findNewPaths(paths, lines, value, path, lineNumber) {
	if (value === void 0) return;
	const fullPath = path.join(".");
	if (fullPath && !paths[fullPath]) {
		const line = lines[lineNumber];
		const lastKey = path[path.length - 1];
		paths[fullPath] = {
			key: keyInfo(lineNumber, line, lastKey),
			value: valueInfo(lineNumber, line, value)
		};
	}
	if (typeof value !== "object") return;
	for (const key in value) {
		if (!value.hasOwnProperty(key)) continue;
		findNewPaths(paths, lines, value[key], [...path, key], lineNumber);
	}
}
async function lint(text, getRootRule) {
	const paths = {};
	const lines = text.split("\n");
	try {
		if (lines.length > 0) {
			const info = {
				from: {
					line: 0,
					ch: 0
				},
				to: {
					line: lines.length - 1,
					ch: lines[lines.length - 1].length
				}
			};
			paths[""] = {
				key: info,
				value: info
			};
		}
		let yamlObject = null;
		for (let i = 0; i < lines.length; i++) {
			const partial = lines.slice(0, i + 1).join("\n");
			yamlObject = yaml.load(partial);
			findNewPaths(paths, lines, yamlObject, [], i);
		}
		const messages = [];
		const rootRule = getRootRule(yamlObject);
		await validate({
			yamlContent: yamlObject,
			paths,
			path: [],
			object: yamlObject,
			rule: rootRule,
			messages,
			processExpression: rootRule.processExpression
		});
		return messages;
	} catch (err) {
		const { mark } = err;
		if (!mark) return [];
		const { line: lineIndex, column } = mark;
		const line = lineIndex >= lines.length || err.reason.match(/end of the stream within a flow collection/) ? lineIndex - 1 : lineIndex;
		const ch = column >= lines[line].length ? 0 : column;
		return [{
			message: html` ${err.reason} `,
			severity: "error",
			from: {
				line,
				ch
			},
			to: {
				line,
				ch: lines[line].length
			}
		}];
	}
}
function dependabotEditor() {
	return [
		yamlAutocomplete(dependabotAutocompleteContext),
		yamlHelpPanel(),
		customLinter(dependabotLintSource)
	];
}
async function dependabotAutocompleteContext(context) {
	if (!context.explicit) return null;
	const cursor = context.pos;
	const textBeforeCursor = getRange(context.state, 0, cursor);
	const suggestions = await autocomplete(context.state.doc.toString(), textBeforeCursor, getRootRule$2, getRootRule$2().suggestionsForExpression);
	if (!suggestions) return null;
	return buildCompletions(suggestions, cursor);
}
async function dependabotLintSource(view) {
	return buildLintMarks(view, await lint(view.state.doc.toString(), getRootRule$2));
}
var nameRule = {
	description: "A custom name for this prompt",
	single: ["string"]
};
var descriptionRule = {
	description: "A description of this prompt",
	single: ["string"]
};
var modelRule = {
	description: "The model to use",
	single: ["string"]
};
var modelParametersRule = {
	description: "Parameters for configuring the model's behavior",
	map: { single: [
		"string",
		"number",
		"boolean"
	] }
};
var messagesRule = {
	description: "The collection of context messages associated with this chat completion request. Typical usage begins with a chat message for the System role that provides instructions for the behavior of the assistant, followed by alternating messages between the User and Assistant roles.",
	multipleValues: true,
	required: true,
	items: { rules: {
		role: {
			description: "The chat role associated with this message",
			values: [
				"assistant",
				"developer",
				"system",
				"user"
			],
			required: true
		},
		content: {
			description: "The content of the message",
			single: ["string"],
			required: true
		}
	} }
};
var testDataRule = {
	description: "Specify inputs and expected outputs for evaluating the prompt",
	multipleValues: true,
	items: { rules: {
		input: {
			description: "The input string to test",
			single: ["string"]
		},
		expected: {
			description: "The expected output for this input",
			single: ["string"]
		}
	} }
};
var evaluatorsRule = {
	description: "A list of evaluators that test the output of a prompt",
	multipleValues: true,
	items: {
		single: ["string"],
		rules: {
			name: {
				description: "A name for this evaluator",
				single: ["string"],
				required: true
			},
			string: {
				description: "Check if the output contains a specific string",
				rules: {
					contains: { single: ["string"] },
					strict: {
						description: "Is the value case-sensitive",
						single: ["boolean"]
					},
					startsWith: { single: ["string"] },
					endsWith: { single: ["string"] }
				}
			},
			uses: {
				description: "A predefined behavior for this evaluator",
				single: ["string"],
				async validateValue(_yaml, _path, value) {
					if (typeof value !== "string") return {
						severity: "error",
						message: html`A single string is required`
					};
					if (!/^github\/\w+$/.test(value)) return {
						severity: "error",
						message: html`Currently only GitHub behaviors are supported`
					};
				}
			},
			llm: {
				description: "Create a test criteria by writing your own prompt",
				rules: {
					modelId: {
						single: ["string"],
						required: true
					},
					prompt: { single: ["string"] },
					systemPrompt: { single: ["string"] },
					modelParameters: modelParametersRule,
					choices: {
						multipleValues: true,
						items: { rules: {
							choice: {
								single: ["string"],
								required: true
							},
							score: {
								single: ["number"],
								required: true
							}
						} }
					}
				}
			}
		}
	}
};
function fullRootRule() {
	return { rules: {
		name: nameRule,
		description: descriptionRule,
		model: modelRule,
		modelParameters: modelParametersRule,
		messages: messagesRule,
		testData: testDataRule,
		evaluators: evaluatorsRule
	} };
}
function getRootRule$1() {
	return fullRootRule();
}
function githubModelsEditor() {
	return [
		yamlAutocomplete(githubModelsAutocompleteContext),
		yamlHelpPanel(),
		customLinter(githubModelsLintSource)
	];
}
async function githubModelsAutocompleteContext(context) {
	if (!context.explicit) return null;
	const cursor = context.pos;
	const textBeforeCursor = getRange(context.state, 0, cursor);
	const suggestions = await autocomplete(context.state.doc.toString(), textBeforeCursor, getRootRule$1, getRootRule$1().suggestionsForExpression);
	if (!suggestions) return null;
	return buildCompletions(suggestions, cursor);
}
async function githubModelsLintSource(view) {
	return buildLintMarks(view, await lint(view.state.doc.toString(), getRootRule$1));
}
var issueCreateRule = {
	description: "Trigger on new issue creation",
	required: true,
	single: ["boolean"],
	rules: { filter: {
		description: "GitHub search query — matching issues are skipped",
		single: ["string"]
	} }
};
var issueCommentRule = {
	description: "Trigger retriage on @copilot mentions in comments (true/false)",
	required: true,
	single: ["boolean"]
};
var onRule = {
	description: "Events that trigger the triage agent",
	required: true,
	rules: {
		"issue-create": issueCreateRule,
		"issue-comment": issueCommentRule
	}
};
var actionAllowBlockRule = {
	description: "Action permission with allowed/blocked value lists",
	required: true,
	rules: {
		allowed: {
			description: "Permitted values (use [\"*\"] to allow all)",
			multipleValues: true,
			items: { single: ["string"] }
		},
		blocked: {
			description: "Blocked values (use [\"*\"] to block all)",
			multipleValues: true,
			items: { single: ["string"] }
		}
	}
};
var addCommentRule = {
	description: "Whether the agent posts a triage comment (true/false)",
	required: true,
	single: ["boolean"]
};
var allowedActionsRule = {
	description: "Actions the triage agent is permitted to take (required)",
	required: true,
	rules: {
		"add-comment": addCommentRule,
		"add-labels": actionAllowBlockRule,
		"add-type": actionAllowBlockRule,
		"add-fields": actionAllowBlockRule
	},
	items: { values: ["*"] },
	maxLength: 1
};
function getRootRule() {
	return { rules: {
		on: onRule,
		"allowed-actions": allowedActionsRule
	} };
}
/**
* Extracts the YAML frontmatter region from a markdown document.
* Frontmatter is delimited by `---` at the start of the file.
*
* Returns the YAML content (without delimiters) and the line offset
* of the first YAML line within the original document so lint
* positions can be mapped back correctly.
*/
function extractFrontmatter(text) {
	const lines = text.split("\n");
	const firstLine = lines[0];
	if (lines.length === 0 || !firstLine || !/^---\s*$/.test(firstLine)) return null;
	for (let i = 1; i < lines.length; i++) {
		const line = lines[i];
		if (line !== void 0 && /^---\s*$/.test(line)) return {
			yaml: lines.slice(1, i).join("\n"),
			lineOffset: 1
		};
	}
	return null;
}
/**
* Offsets all lint message positions by the given number of lines.
* This maps positions from the extracted YAML back to the full document.
*/
function offsetMessages(messages, lineOffset) {
	return messages.map((msg) => ({
		...msg,
		from: {
			...msg.from,
			line: msg.from.line + lineOffset
		},
		to: {
			...msg.to,
			line: msg.to.line + lineOffset
		}
	}));
}
function triageAgentEditor() {
	return [yamlHelpPanel(), customLinter(triageAgentLintSource)];
}
async function triageAgentLintSource(view) {
	const text = view.state.doc.toString();
	const frontmatter = extractFrontmatter(text);
	if (!frontmatter) {
		const firstLine = text.split("\n")[0] || "";
		return buildLintMarks(view, [{
			message: html`Config must start with YAML frontmatter (<code>---</code>)`,
			severity: "error",
			from: {
				line: 0,
				ch: 0
			},
			to: {
				line: 0,
				ch: firstLine.length || 1
			}
		}]);
	}
	if (frontmatter.yaml.trim().length === 0) return buildLintMarks(view, [{
		message: html`Frontmatter is empty — add configuration keys like <code>on</code> and
          <code>allowed-actions</code>`,
		severity: "error",
		from: {
			line: 0,
			ch: 0
		},
		to: {
			line: 0,
			ch: 3
		}
	}]);
	return buildLintMarks(view, offsetMessages(await lint(frontmatter.yaml, getRootRule), frontmatter.lineOffset));
}
var languageServicePromise = null;
function getLanguageServiceModule() {
	if (!languageServicePromise) languageServicePromise = (async () => {
		try {
			return await import("./server-language-service-DfVdD3rx-M2FhzN69.js");
		} catch (err) {
			languageServicePromise = null;
			throw err;
		}
	})();
	return languageServicePromise;
}
/**
* Compartment for dynamically loading inlay hints extensions.
* This keeps @actions/languageservice scoped to workflow editor initialization,
* not loaded by code that merely imports this module.
*/
var inlayHintsCompartment = new Compartment();
var inlayHintsLoadedViews = /* @__PURE__ */ new WeakSet();
/**
* ViewPlugin that lazy-loads the inlay hints module and reconfigures the editor.
*/
var lazyInlayHintsLoader = ViewPlugin.define((view) => {
	if (!inlayHintsLoadedViews.has(view)) {
		inlayHintsLoadedViews.add(view);
		(async () => {
			try {
				const module = await import("./server-inlay-hints-C3M8RUSj-1v95d5L_.js");
				view.dispatch({ effects: inlayHintsCompartment.reconfigure(module.workflowInlayHints()) });
			} catch (err) {
				console.error("[Language Service] Failed to load inlay hints:", err);
			}
		})();
	}
	return {};
});
var allowCaseFunction = featureFlag.isFeatureEnabled("actions_workflow_language_service_allow_case_function");
var allowCronTimezone = featureFlag.isFeatureEnabled("actions_scheduled_workflow_timezone_enabled");
function workflowEditor(documentUri = ".github/workflows/workflow.yml") {
	setDocumentUri(documentUri);
	const extensions = [
		yamlAutocompleteLanguageService(workflowAutocompleteContext),
		yamlHelpPanel(),
		customLinter(workflowYamlLintSource)
	];
	extensions.push(hoverTooltip(workflowHoverSource));
	extensions.push(inlayHintsCompartment.of([]));
	extensions.push(lazyInlayHintsLoader);
	return extensions;
}
async function workflowAutocompleteContext(context) {
	try {
		return (await getLanguageServiceModule()).workflowAutocompleteContextWithLanguageService(context, allowCaseFunction, allowCronTimezone);
	} catch (err) {
		console.error("[Language Service] Failed to load module:", err);
		return null;
	}
}
async function workflowYamlLintSource(view) {
	try {
		return (await getLanguageServiceModule()).workflowYamlLintSourceWithLanguageService(view, allowCronTimezone);
	} catch (err) {
		console.error("[Language Service] Failed to load module:", err);
		return [];
	}
}
async function workflowHoverSource(view, pos, _side) {
	try {
		const result = await (await getLanguageServiceModule()).workflowHoverWithLanguageService(view, pos);
		if (!result) return null;
		return {
			pos: result.pos,
			end: result.end,
			above: true,
			create: () => ({ dom: result.dom })
		};
	} catch (err) {
		console.error("[Language Service] Failed to load module:", err);
		return null;
	}
}
var VALID_DEVCONTAINER_PATH_GLOB = /\.devcontainer(?:(?:\/(?:[\w\-.'"][\w\-.'"\s]{0,62}[\w\-.'"]|[\w\-.'"]))?\/devcontainer)?\.json/;
var isDevContainerEditorEnabled = (devContainerEditorEnabled, filePath) => {
	return devContainerEditorEnabled && VALID_DEVCONTAINER_PATH_GLOB.test(filePath);
};
var isDependabotEditorEnabled = (dependabotEditorEnabled, filePath) => {
	return dependabotEditorEnabled && /^(\.github\/dependabot\.(yaml|yml))/i.test(filePath);
};
var isGitHubModelsEditorEnabled = (filePath) => {
	return /(\.prompt\.(yaml|yml))$/i.test(filePath);
};
var isTriageAgentEditorEnabled = (triageAgentEditorEnabled, filePath, configPath) => {
	return triageAgentEditorEnabled && !!configPath && filePath.toLowerCase() === configPath.toLowerCase();
};
var isWorkflowEditorEnabled = (actionsEnabled, filePath) => {
	return actionsEnabled && /^(\.github\/(workflows|workflows-lab)\/.+\.(yaml|yml))/i.test(filePath);
};
var isActionEditorEnabled = (actionsEnabled, filePath) => {
	if (!actionsEnabled) return false;
	if (/^\.github\/(workflows|workflows-lab)\//i.test(filePath)) return false;
	return /(^|\/)action\.(yaml|yml)$/i.test(filePath);
};
function getEditorEnablements(editorInfo, completeFilePath, configPaths) {
	const workflowEditorEnabled = isWorkflowEditorEnabled(editorInfo.actionsEnabled, completeFilePath);
	const actionEditorEnabled = isActionEditorEnabled(editorInfo.actionsEnabled, completeFilePath);
	const dependabotEditorEnabled = isDependabotEditorEnabled(editorInfo.dependabotEditorEnabled, completeFilePath);
	const githubModelsEditorEnabled = isGitHubModelsEditorEnabled(completeFilePath);
	return {
		workflowEditorEnabled,
		actionEditorEnabled,
		dependabotEditorEnabled,
		devContainerEditorEnabled: isDevContainerEditorEnabled(editorInfo.devcontainerEditorEnabled, completeFilePath),
		githubModelsEditorEnabled,
		triageAgentEditorEnabled: isTriageAgentEditorEnabled(editorInfo.triageAgentEditorEnabled, completeFilePath, configPaths?.triageAgent)
	};
}
function getEditorExtensions(editorInfo, completeFilePath, configPaths) {
	const { workflowEditorEnabled, actionEditorEnabled, dependabotEditorEnabled, devContainerEditorEnabled, githubModelsEditorEnabled, triageAgentEditorEnabled } = getEditorEnablements(editorInfo, completeFilePath, configPaths);
	let editorExtensions = void 0;
	if (workflowEditorEnabled) editorExtensions = workflowEditor("workflow.yaml");
	else if (actionEditorEnabled) editorExtensions = workflowEditor("action.yaml");
	else if (dependabotEditorEnabled) editorExtensions = dependabotEditor();
	else if (devContainerEditorEnabled) editorExtensions = devContainerEditor();
	else if (githubModelsEditorEnabled) editorExtensions = githubModelsEditor();
	else if (triageAgentEditorEnabled) editorExtensions = triageAgentEditor();
	return editorExtensions;
}
async function fetchJSON(url) {
	const response = await verifiedFetchJSON(url);
	if (response?.ok) return await response.json();
	else return;
}
var memoizeFetchJSON = memoize(fetchJSON, { cache: /* @__PURE__ */ new Map() });
function useSidePanelMetadata(enabledProps) {
	const $ = c(11);
	const repo = useCurrentRepository();
	const [metadata, setMetadata] = useState();
	const [error, setError] = useState(false);
	const [loading, setLoading] = useState(true);
	const { isTriageAgent } = enabledProps;
	let t0;
	if ($[0] !== isTriageAgent || $[1] !== repo.name || $[2] !== repo.ownerLogin) {
		const queryParams = isTriageAgent ? { "triage-agent": 1 } : void 0;
		t0 = getRelativeHref(blobSidePanelMetadataPath, {
			owner: repo.ownerLogin,
			repo: repo.name
		}, queryParams);
		$[0] = isTriageAgent;
		$[1] = repo.name;
		$[2] = repo.ownerLogin;
		$[3] = t0;
	} else t0 = $[3];
	const metadataPath = t0;
	let t1;
	let t2;
	if ($[4] !== metadataPath) {
		t1 = () => {
			let cancelled = false;
			const update = async () => {
				setLoading(true);
				setMetadata(void 0);
				const metadataResponse = await memoizeFetchJSON(metadataPath);
				if (cancelled) return;
				try {
					if (metadataResponse) setMetadata(metadataResponse);
					else setError(true);
				} catch {
					setError(true);
				}
				setLoading(false);
			};
			update();
			return function cancel() {
				cancelled = true;
			};
		};
		t2 = [metadataPath];
		$[4] = metadataPath;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	useEffect(t1, t2);
	let t3;
	if ($[7] !== error || $[8] !== loading || $[9] !== metadata) {
		t3 = [
			metadata,
			loading,
			error
		];
		$[7] = error;
		$[8] = loading;
		$[9] = metadata;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
}
var BlobEditSidePanel_module_default = {
	Box: "BlobEditSidePanel-module_SULtxa_Box",
	IconButton: "BlobEditSidePanel-module_SULtxa_IconButton",
	Panel: "BlobEditSidePanel-module_SULtxa_Panel",
	PanelWide: "BlobEditSidePanel-module_SULtxa_PanelWide",
	StickyHeader: "BlobEditSidePanel-module_SULtxa_StickyHeader",
	Text: "BlobEditSidePanel-module_SULtxa_Text",
	UnderlineNav_Item: "BlobEditSidePanel-module_SULtxa_UnderlineNav_Item"
};
var Documentation_module_default = { Box: "Documentation-module_u7Ee1a_Box" };
function DevContainerDocumentation() {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx("f5 markdown-body", Documentation_module_default.Box),
		children: [
			/* @__PURE__ */ jsxs("p", { children: [/* @__PURE__ */ jsx("a", {
				href: "https://containers.dev",
				children: "Development Containers"
			}), " are configuration files used by Codespaces and tools implementing the dev container specification."] }),
			/* @__PURE__ */ jsx("p", { children: "These files allow you to create a consistent, sharable development environment." }),
			/* @__PURE__ */ jsx("h2", { children: "Features" }),
			/* @__PURE__ */ jsx("p", { children: "Dev Container Features are self-contained units of installation code and development container configuration. Features are designed to install atop a wide-range of base container images. Be sure to check a Feature's documentation to see which base images are supported." }),
			/* @__PURE__ */ jsx("h3", { children: "Usage" }),
			/* @__PURE__ */ jsxs("p", { children: [
				"To reference a Feature, add the desired Feature(s) to a ",
				/* @__PURE__ */ jsx("code", { children: "devcontainer.json" }),
				". See a Feature's README for available options, or leave the options empty to use the default value."
			] }),
			/* @__PURE__ */ jsx("h4", { children: "Example devcontainer.json" }),
			/* @__PURE__ */ jsx("pre", { children: `{
    "name": "my-project-devcontainer",
    "image": "mcr.microsoft.com/devcontainers/base:ubuntu",  // Any generic, debian-based image.
    "features": {
        "ghcr.io/devcontainers/features/go:1": {
            "version": "1.18"
        },
        "ghcr.io/devcontainers/features/docker-in-docker:1": {
            "version": "latest",
            "moby": true
        }
    }
}` })
		]
	});
}
DevContainerDocumentation.displayName = "DevContainerDocumentation";
var Marketplace_module_default$1 = {
	Box: "Marketplace-module_uRRKCq_Box",
	Spinner: "Marketplace-module_uRRKCq_Spinner"
};
function DevContainerMarketplace({ src }) {
	import("./server-editor-devcontainer-sidebar-ByH67Hdl-D6rnk_Wh.js");
	return /* @__PURE__ */ jsxs("div", {
		className: Marketplace_module_default$1.Box,
		children: [/* @__PURE__ */ jsx("input", {
			type: "text",
			form: "marketplace-search",
			className: "form-control input-block input-contrast",
			placeholder: "Search for Features",
			id: "dev-container-search-input"
		}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
			id: "js-devcontainer-editor-sidebar-content-complete",
			children: /* @__PURE__ */ jsx(IncludeFragment, {
				src,
				children: /* @__PURE__ */ jsx(Spinner, { className: Marketplace_module_default$1.Spinner })
			})
		}), /* @__PURE__ */ jsx("span", { id: "js-devcontainer-editor-sidebar-details" })] })]
	});
}
DevContainerMarketplace.displayName = "DevContainerMarketplace";
var ServerSideDocumentation_module_default = { VerifiedHTMLBox: "ServerSideDocumentation-module_v20c0a_VerifiedHTMLBox" };
function ServerSideDocumentation({ documentation }) {
	return /* @__PURE__ */ jsx(VerifiedHTMLBox, {
		html: documentation,
		className: clsx("f5 markdown-body", ServerSideDocumentation_module_default.VerifiedHTMLBox)
	});
}
ServerSideDocumentation.displayName = "ServerSideDocumentation";
var Marketplace_module_default = {
	Box: "Marketplace-module_beob-q_Box",
	Spinner: "Marketplace-module_beob-q_Spinner"
};
function WorkflowMarketplace({ src }) {
	import("./server-actions-sidebar-KIalzbk7-Cs51_avm.js");
	return /* @__PURE__ */ jsxs("div", {
		className: Marketplace_module_default.Box,
		children: [/* @__PURE__ */ jsx("remote-input", {
			param: "query",
			src,
			"aria-owns": "js-workflow-editor-sidebar-content",
			class: "tmp-mb-3 position-relative js-remoteinput",
			children: /* @__PURE__ */ jsx("input", {
				type: "text",
				form: "marketplace-search",
				className: "form-control input-block input-contrast",
				placeholder: "Search Marketplace for Actions",
				"aria-label": "Search Marketplace for Actions"
			})
		}), /* @__PURE__ */ jsx("div", {
			id: "js-workflow-editor-sidebar-content",
			children: /* @__PURE__ */ jsx(IncludeFragment, {
				src,
				children: /* @__PURE__ */ jsx(Spinner, { className: Marketplace_module_default.Spinner })
			})
		})]
	});
}
WorkflowMarketplace.displayName = "WorkflowMarketplace";
function blobEditSidePanelEnabled(enabledProps) {
	return enabledProps.workflowEditorEnabled || enabledProps.devContainerEditorEnabled || enabledProps.isIssueTemplate || enabledProps.isIssueForm || enabledProps.isDiscussionTemplate || enabledProps.isTriageAgent;
}
function SidePanelErrorMessage() {
	return /* @__PURE__ */ jsxs("span", {
		"data-testid": "side-panel-error-message",
		className: BlobEditSidePanel_module_default.Text,
		children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertFillIcon }), "\xA0Cannot retrieve help documentation at this time."]
	});
}
SidePanelErrorMessage.displayName = "SidePanelErrorMessage";
function SidePanelLoading() {
	return /* @__PURE__ */ jsx("div", {
		className: BlobEditSidePanel_module_default.Box,
		children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
	});
}
SidePanelLoading.displayName = "SidePanelLoading";
function BlobEditSidePanel(props) {
	const { isProxima, isNarrow, ...innerProps } = props;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [!isNarrow && /* @__PURE__ */ jsx(BlobEditSidePanelContent, {
		isProxima,
		isNarrow,
		...innerProps
	}), isNarrow && /* @__PURE__ */ jsx(Dialog, {
		onClose: () => innerProps.onClosePanel(),
		renderHeader: () => null,
		renderBody: () => BlobEditSidePanelContent({
			isProxima,
			isNarrow,
			...innerProps
		})
	})] });
}
BlobEditSidePanel.displayName = "BlobEditSidePanel";
function BlobEditSidePanelContent({ enabledProps, isEnterprise, isNarrow, isProxima, onClosePanel, id }) {
	let marketplaceComponent = null;
	let documentationComponent = null;
	const [metadata, loading, error] = useSidePanelMetadata(enabledProps);
	switch (true) {
		case enabledProps.workflowEditorEnabled:
			marketplaceComponent = /* @__PURE__ */ jsx(WorkflowMarketplace, { src: metadata?.marketplaceUrls?.workflow });
			documentationComponent = /* @__PURE__ */ jsx(ServerSideDocumentation, { documentation: metadata?.docsHtml?.workflow });
			break;
		case enabledProps.devContainerEditorEnabled:
			marketplaceComponent = /* @__PURE__ */ jsx(DevContainerMarketplace, { src: metadata?.marketplaceUrls?.devcontainers });
			documentationComponent = /* @__PURE__ */ jsx(DevContainerDocumentation, {});
			break;
		case enabledProps.isIssueForm:
			documentationComponent = /* @__PURE__ */ jsx(ServerSideDocumentation, { documentation: metadata?.docsHtml?.issueForm });
			break;
		case enabledProps.isIssueTemplate:
			documentationComponent = /* @__PURE__ */ jsx(ServerSideDocumentation, { documentation: metadata?.docsHtml?.issueTemplate });
			break;
		case enabledProps.isDiscussionTemplate:
			documentationComponent = /* @__PURE__ */ jsx(ServerSideDocumentation, { documentation: metadata?.docsHtml?.discussionTemplate });
			break;
		case enabledProps.isTriageAgent:
			documentationComponent = /* @__PURE__ */ jsx(ServerSideDocumentation, { documentation: metadata?.docsHtml?.triageAgent });
			break;
	}
	const showMarketplace = !!marketplaceComponent && !isEnterprise && !isProxima;
	const [selectedTab, setSelectedTab] = useState(showMarketplace ? "marketplace" : "documentation");
	return /* @__PURE__ */ jsxs(Panel, {
		"data-testid": "editor-side-panel",
		id,
		className: clsx(BlobEditSidePanel_module_default.Panel, {
			[BlobEditSidePanel_module_default.PanelWide]: !isNarrow,
			[BlobEditSidePanel_module_default.StickyHeader]: true
		}),
		children: [isNarrow && /* @__PURE__ */ jsx(IconButton, {
			"aria-label": "Close help panel",
			tooltipDirection: "sw",
			"data-hotkey": "Escape",
			icon: XIcon,
			onClick: () => onClosePanel(),
			variant: "invisible",
			className: BlobEditSidePanel_module_default.IconButton
		}), error ? /* @__PURE__ */ jsx(SidePanelErrorMessage, {}) : loading ? /* @__PURE__ */ jsx(SidePanelLoading, {}) : metadata ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
			showMarketplace && /* @__PURE__ */ jsxs(UnderlineNav, {
				"aria-label": "Help Panel",
				children: [/* @__PURE__ */ jsx(UnderlineNav.Item, {
					...selectedTab === "marketplace" && { "aria-current": true },
					onSelect: (e) => {
						setSelectedTab("marketplace");
						e.preventDefault();
					},
					children: "Marketplace"
				}), /* @__PURE__ */ jsx(UnderlineNav.Item, {
					...selectedTab === "documentation" && { "aria-current": true },
					onSelect: (e_0) => {
						setSelectedTab("documentation");
						e_0.preventDefault();
					},
					children: "Documentation"
				})]
			}),
			selectedTab === "marketplace" && marketplaceComponent,
			selectedTab === "documentation" && documentationComponent
		] }) : null]
	});
}
BlobEditSidePanelContent.displayName = "BlobEditSidePanelContent";
/**
* Normalize relative changes (../) in the folder path
* @param folderPath the folder path to normalize
* @returns {string} the normalized folder path with relative changes applied
*/
function normalizeRelativePathChange(folderPath) {
	let newFolderPath = folderPath;
	if (newFolderPath === "../") newFolderPath = "";
	const parts = newFolderPath.split("/");
	if (parts.length > 2 && parts[parts.length - 2] === "..") {
		parts.pop();
		parts.pop();
		parts.pop();
		if (parts.length === 0) newFolderPath = "";
		else newFolderPath = `${parts.join("/")}/`;
	}
	return newFolderPath;
}
var unsavedChangesCacheKey = (ref, refOid, path) => {
	return `unsaved-changes-${ref}-${refOid}-${path}-v1`;
};
var blobEditSidePanelId = "blob-edit-side-panel-id";
function BlobEditor({ collapseTree, editInfo, repo, showTree, treeToggleElement, webCommitInfo, copilotInfo, copilotGenerateCommitMessageAuthInfo, isDataRouter }) {
	const [, startTransition] = useTransition();
	const { helpUrl } = useReposAppPayload();
	const { getUrl } = useUrlCreator();
	const path = usePath();
	const refInfo = useRefInfo();
	const payloadFileContents = editInfo.content ?? "";
	const [initialFileContent, setInitialFileContent] = useState(payloadFileContents);
	const [fileName, setFileName] = useState(editInfo.fileName.split("/").pop() ?? "");
	const { hasUnsavedContent, discardContent, persistContent, restoreContent } = useUnsavedContent(unsavedChangesCacheKey(refInfo.name, refInfo.currentOid, path));
	const fileContentsRef = useRef(initialFileContent);
	const updatedFileContent = fileContentsRef.current;
	useEffect(() => {
		fileContentsRef.current = initialFileContent;
	}, [initialFileContent]);
	const [fileContentChanged, setFileContentChanged] = useState(false);
	const onCodeMirrorChange = useCallback((value) => {
		fileContentsRef.current = value;
		if (payloadFileContents !== value) {
			startTransition(() => {
				setFileContentChanged(true);
			});
			persistContent(value);
		}
	}, [payloadFileContents, persistContent]);
	const restoreFileContent = useCallback(() => {
		const restoredContent = restoreContent();
		if (restoredContent) {
			setInitialFileContent(restoredContent);
			setFileContentChanged(true);
		}
	}, [restoreContent]);
	const isNewFile = editInfo.isNewFile;
	let initialPath = path;
	if (isNewFile && editInfo.fileName) if (initialPath) initialPath += `/${editInfo.fileName}`;
	else initialPath = editInfo.fileName;
	const cancelUrl = !isNewFile && editInfo.pullRequestUrl !== null ? editInfo.pullRequestUrl : getUrl({ action: isNewFile ? "tree" : "blob" });
	const [folderPath, setFolderPath] = useState(() => {
		const initialFolders = initialPath.split("/").slice(0, !fileName ? void 0 : -1).join("/");
		return initialFolders ? `${initialFolders}/` : "";
	});
	const initialFolderPathRef = useRef(folderPath);
	const [hasLeadingOrTrailingWhitespaceInPath, setHasLeadingOrTrailingWhitespaceInPath] = useState(false);
	useEffect(() => {
		if (folderPath !== initialFolderPathRef.current) setHasLeadingOrTrailingWhitespaceInPath(folderPath.split("/").some((folder) => folder.trim() !== folder));
	}, [folderPath]);
	const { screenSize } = useScreenSize();
	const isNarrow = screenSize <= ScreenSize.medium;
	const [selectedTab, setSelectedTab] = useState(BlobEditorTab.Edit);
	const isEdit = selectedTab === BlobEditorTab.Edit;
	const isPreview = selectedTab === BlobEditorTab.Preview;
	const { selectEditTabShortcut } = useShortcut();
	const [codeMirrorSpacingOptions, setCodeMirrorSpacingOptions] = useState({
		lineWrapping: editInfo.codeMirror?.lineWrapping,
		indentMode: editInfo.codeMirror?.indentMode,
		indentSize: editInfo.codeMirror?.indentSize
	});
	const [secretDetected, setSecretDetected] = useState(false);
	const [secretBypassMetadata, setSecretBypassMetadata] = useState();
	const completeFilePath = `${folderPath}${fileName}`;
	const nameInputRef = useRef(null);
	const commitChangesRef = useRef(null);
	const previewContainerRef = useRef(null);
	const focusCodeMirrorOnNextRenderRef = useRef(false);
	const focusPreviewOnNextRenderRef = useRef(false);
	const [webCommitDialogState, setWebCommitDialogState] = useState("closed");
	const onFileNameChange = useCallback((newFileName, newFolderPath) => {
		setInitialFileContent(fileContentsRef.current);
		setFileName(newFileName);
		setFolderPath(newFolderPath);
	}, []);
	const contentChanged = fileContentChanged || editInfo.enableCommitButton;
	const fileNameChanged = completeFilePath !== initialPath;
	const commitDisabledRef = useRef(false);
	commitDisabledRef.current = !(contentChanged || fileNameChanged) || fileName.length === 0;
	let placeholderMessage = `Update ${fileName}`;
	if (isNewFile) placeholderMessage = `Create ${fileName}`;
	else if (fileNameChanged) {
		let messageAction;
		if (contentChanged) messageAction = "Update and rename";
		else messageAction = "Rename";
		if (folderPath.split("/").length !== initialPath.split("/").length) placeholderMessage = `${messageAction} ${initialPath} to ${folderPath}${fileName}`;
		else placeholderMessage = `${messageAction} ${editInfo.fileName} to ${fileName}`;
	}
	usePrompt("You have unsaved changes. Do you want to discard them?", (contentChanged || fileNameChanged) && webCommitDialogState !== "saved");
	const fileExtension = fileName.includes(".") ? `.${fileName.split(".").pop()}` : void 0;
	const isRichtextRenderable = !!fileExtension && editInfo.renderableExtensions.includes(fileExtension);
	const [showMarkdownDiff, setShowMarkdownDiff] = useState(isNewFile);
	const { workflowEditorEnabled, devContainerEditorEnabled, dependabotEditorEnabled } = getEditorEnablements(editInfo.editors, completeFilePath, editInfo.configPaths);
	const editorExtensions = getEditorExtensions(editInfo.editors, completeFilePath, editInfo.configPaths);
	const isDiscussionTemplate = completeFilePath.startsWith(".github/DISCUSSION_TEMPLATE/") && /\.(yml|yaml)$/i.test(fileName);
	const isIssueTemplate = completeFilePath.startsWith(".github/ISSUE_TEMPLATE/") && /^((?!config).+\.(md|yml|yaml))$/i.test(fileName);
	const isIssueForm = completeFilePath.startsWith(".github/ISSUE_TEMPLATE/") && /^((?!config).+\.(yml|yaml))$/i.test(fileName);
	const isLegacyIssueTemplate = /^(\.github\/)?issue(_|-)template\.md$/i.test(completeFilePath);
	const isTriageAgent = editInfo.configPaths?.triageAgent ? completeFilePath === editInfo.configPaths.triageAgent : false;
	const sidePanelEnabledProps = {
		workflowEditorEnabled,
		devContainerEditorEnabled,
		isIssueForm,
		isIssueTemplate: isIssueTemplate || isLegacyIssueTemplate,
		isDiscussionTemplate,
		isTriageAgent
	};
	const panelIsEnabled = blobEditSidePanelEnabled(sidePanelEnabledProps) && !editInfo.isOnboardingGuidance;
	const { openPanel, setOpenPanel } = useOpenPanel();
	const panelIsOpen = openPanel === "edit";
	const handleTabChange = useCallback((index) => {
		if (!isValidBlobEditorTab(index)) return;
		startTransition(() => {
			setSelectedTab(index);
		});
	}, [startTransition]);
	useEffect(() => {
		if (focusPreviewOnNextRenderRef.current) {
			focusPreviewOnNextRenderRef.current = false;
			previewContainerRef.current?.focus();
		}
	}, [selectedTab]);
	const generateCommitMessageInfo = useMemo(() => ({
		copilotGenerateCommitMessageAuthInfo,
		initialPath,
		completeFilePath,
		initialFileContent,
		placeholderMessage
	}), [
		copilotGenerateCommitMessageAuthInfo,
		initialPath,
		completeFilePath,
		initialFileContent,
		placeholderMessage
	]);
	const handlePanelIsEnabledChange = useEffectEvent(() => {
		if (panelIsEnabled && !isNarrow) setOpenPanel("edit");
	});
	useEffect(() => {
		handlePanelIsEnabledChange();
	}, [panelIsEnabled, setOpenPanel]);
	useEffect(() => {
		if (panelIsOpen && !panelIsEnabled) setOpenPanel(void 0);
	}, [
		panelIsEnabled,
		panelIsOpen,
		setOpenPanel
	]);
	useEffect(() => {
		if (isNewFile) nameInputRef?.current?.focus();
	}, [isNewFile]);
	useEffect(() => {
		if (repo.isEmpty) collapseTree();
	}, [collapseTree, repo.isEmpty]);
	if (webCommitInfo.shouldFork || webCommitInfo.shouldUpdate || webCommitInfo.lockedOnMigration) return /* @__PURE__ */ jsxs(Fragment$1, { children: [!isNewFile && /* @__PURE__ */ jsx(EditBreadcrumb, {
		showTree,
		treeToggleElement,
		folderPath,
		repo,
		refInfo,
		onChange: onFileNameChange,
		fileName,
		nameInputRef,
		inputDisabled: true
	}), /* @__PURE__ */ jsx(EditIssues, {
		binary: false,
		helpUrl,
		webCommitInfo,
		repositoryName: repo.name
	})] });
	let screenReaderHeading;
	if (isNewFile) screenReaderHeading = "Creating a new";
	else screenReaderHeading = "Editing";
	let generic = false;
	if (workflowEditorEnabled) screenReaderHeading += " workflow file";
	else if (dependabotEditorEnabled) screenReaderHeading += " dependabot file";
	else if (devContainerEditorEnabled) screenReaderHeading += " devcontainer file";
	else if (isIssueTemplate) screenReaderHeading += " issue template file";
	else if (isDiscussionTemplate) screenReaderHeading += " discussion template file";
	else generic = true;
	screenReaderHeading += ` ${isNewFile ? generic ? "file" : "" : ` ${fileName}`} in ${repo.name}`;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(ScreenReaderHeading, {
			as: "h1",
			text: screenReaderHeading
		}),
		workflowEditorEnabled && /* @__PURE__ */ jsx(WorkflowEditor, {
			helpUrl,
			isEnterprise: editInfo.editors.isEnterprise,
			repositoryActionsEnabled: editInfo.editors.repositoryActionsEnabled,
			repositoryActionsReadinessPath: editInfo.editors.repositoryActionsReadinessPath
		}),
		hasUnsavedContent && /* @__PURE__ */ jsx(UnsavedChangesBanner, {
			discardContent: () => discardContent("banner"),
			restoreContent: restoreFileContent
		}),
		/* @__PURE__ */ jsx(BlobEditorBanners, {
			content: updatedFileContent,
			editInfo,
			webCommitInfo,
			fileName,
			filePath: completeFilePath,
			hasLeadingOrTrailingWhitespaceInPath,
			isIssueTemplate,
			isLegacyIssueTemplate,
			secretDetected,
			secretBypassMetadata,
			onSetContent: setInitialFileContent
		}),
		/* @__PURE__ */ jsxs("div", {
			className: BlobEditor_module_default.Box,
			children: [/* @__PURE__ */ jsx(EditBreadcrumb, {
				showTree,
				treeToggleElement,
				folderPath,
				repo,
				refInfo,
				onChange: onFileNameChange,
				fileName,
				nameInputRef,
				inputDisabled: isPreview
			}), /* @__PURE__ */ jsxs("div", {
				className: BlobEditor_module_default.Box_1,
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					as: Link$1,
					to: cancelUrl,
					onClick: () => discardContent("cancel"),
					className: BlobEditor_module_default.Button_1,
					children: "Cancel changes"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					"data-hotkey": "Mod+s",
					disabled: commitDisabledRef.current,
					onClick: () => {
						if (!commitDisabledRef.current) startTransition(() => setWebCommitDialogState("pending"));
					},
					variant: "primary",
					ref: commitChangesRef,
					className: BlobEditor_module_default.Button,
					...testIdProps("open-commit-dialog-button"),
					children: "Commit changes..."
				})]
			})]
		}),
		!editInfo.binary ? /* @__PURE__ */ jsxs("div", {
			className: BlobEditor_module_default.Box_2,
			children: [/* @__PURE__ */ jsxs(Panel, {
				style: { maxWidth: panelIsOpen && !isNarrow ? "70%" : "100%" },
				className: BlobEditor_module_default.Panel,
				children: [/* @__PURE__ */ jsx(BlobEditHeader, {
					codeMirrorSpacingOptions,
					editInfo,
					fileName,
					isRichtextRenderable,
					onTabChange: handleTabChange,
					panelIsEnabled,
					panelIsOpen,
					selectedTab,
					setCodeMirrorSpacingOptions,
					setOpenPanel,
					setShowMarkdownDiff,
					setUpdatedFileContent: setInitialFileContent,
					showMarkdownDiff,
					copilotInfo
				}), /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
					className: clsx("react-code-view-edit", BlobEditor_module_default.Box_3, { ["d-none"]: !isEdit }),
					children: /* @__PURE__ */ jsx(ReactCodeMirror, {
						fileName,
						value: initialFileContent,
						spacingOptions: codeMirrorSpacingOptions,
						onChange: onCodeMirrorChange,
						extensions: editorExtensions,
						onPreview: () => {
							focusPreviewOnNextRenderRef.current = true;
							startTransition(() => {
								setSelectedTab(BlobEditorTab.Preview);
							});
						},
						focusOnNextRender: focusCodeMirrorOnNextRenderRef,
						onSave: () => {
							if (!commitDisabledRef.current) startTransition(() => setWebCommitDialogState("pending"));
						},
						repositoryId: repo.id,
						uploadPolicyPath: editInfo.uploadPolicyPath,
						uploadExtensions: editInfo.uploadExtensions,
						markdownDocsUrl: editInfo.markdownDocsUrl,
						isDataRouter
					})
				}), isPreview && /* @__PURE__ */ jsxs("div", {
					ref: previewContainerRef,
					tabIndex: -1,
					className: BlobEditor_module_default.Box_4,
					children: [/* @__PURE__ */ jsx("button", {
						hidden: true,
						"data-hotkey": selectEditTabShortcut.hotkey,
						onClick: () => {
							focusCodeMirrorOnNextRenderRef.current = true;
							startTransition(() => {
								setSelectedTab(BlobEditorTab.Edit);
							});
						}
					}), /* @__PURE__ */ jsx(EditorPreview, {
						editInfo,
						fileContent: updatedFileContent,
						fileName,
						refInfo,
						showMarkdownDiff,
						isRichtextRenderable
					})]
				})] })]
			}), panelIsOpen && /* @__PURE__ */ jsx(BlobEditSidePanel, {
				id: "blob-edit-side-panel-id",
				isEnterprise: editInfo.editors.isEnterprise,
				isProxima: editInfo.editors.isProxima,
				enabledProps: sidePanelEnabledProps,
				isNarrow,
				onClosePanel: () => setOpenPanel(void 0)
			})]
		}) : /* @__PURE__ */ jsx(EditIssues, {
			binary: true,
			helpUrl,
			webCommitInfo,
			repositoryName: repo.name
		}),
		webCommitDialogState === "pending" || webCommitDialogState === "saving" ? /* @__PURE__ */ jsx(WebCommitDialog, {
			content: updatedFileContent,
			contentChanged,
			fileName: completeFilePath,
			isDelete: false,
			isNewFile,
			helpUrl,
			oldPath: initialPath,
			ownerName: repo.ownerLogin,
			placeholderMessage,
			refName: refInfo.name,
			returnFocusRef: commitChangesRef,
			dialogState: webCommitDialogState,
			setDialogState: (state) => {
				setWebCommitDialogState(state);
				if (state === "saved") discardContent("save");
				if (state === "closed" || state === "saved") window.requestAnimationFrame(() => {
					if (commitChangesRef.current) commitChangesRef.current.focus();
				});
			},
			webCommitInfo,
			setSecretDetected,
			setSecretBypassMetadata,
			generateCommitMessageInfo
		}) : null
	] });
}
BlobEditor.displayName = "BlobEditor";
function EditBreadcrumb({ showTree, treeToggleElement, folderPath: initialFolderPath, repo, refInfo, onChange, fileName: initialFileName, nameInputRef, inputDisabled }) {
	const { codeCenterOption } = useCodeViewOptions();
	const showTreeToggle = !showTree && !repo.isEmpty && !codeCenterOption.enabled;
	const [fileName, setFileName] = useState(initialFileName);
	const [folderPath, setFolderPath] = useState(initialFolderPath);
	const onFileNameInputKeyPress = useCallback((event) => {
		if (event.key === "Backspace" && folderPath.length > 0 && nameInputRef.current?.selectionStart === 0 && nameInputRef.current?.selectionEnd === 0) {
			const pathParts = folderPath.split("/");
			const unchangedPathParts = pathParts.slice(0, -2);
			const newFolderPath = unchangedPathParts.length ? `${unchangedPathParts.join("/")}/` : "";
			const newFileName = pathParts[pathParts.length - 2] + fileName;
			const partLength = pathParts[pathParts.length - 2].length;
			event.preventDefault();
			window.requestAnimationFrame(() => {
				nameInputRef.current?.setSelectionRange(partLength, partLength);
			});
			setFileName(newFileName);
			setFolderPath(newFolderPath);
		}
	}, [
		fileName,
		folderPath,
		nameInputRef
	]);
	const onFileNameChange = useCallback((event_0) => {
		const value = event_0.target.value;
		let newFileName_0 = fileName;
		let newFolderPath_0 = folderPath;
		if (value.includes("/")) {
			const pathParts_0 = value.split("/");
			if (value.endsWith("/")) {
				newFileName_0 = "";
				newFolderPath_0 = `${folderPath}${value}`;
			} else {
				newFileName_0 = pathParts_0[pathParts_0.length - 1] ?? "";
				newFolderPath_0 = `${folderPath}${pathParts_0.slice(0, -1).join("/")}/`;
				if (pathParts_0.length > 1) window.requestAnimationFrame(() => {
					nameInputRef.current?.setSelectionRange(0, 0);
				});
			}
		} else newFileName_0 = value;
		newFolderPath_0 = normalizeRelativePathChange(newFolderPath_0);
		if (newFolderPath_0 !== initialFolderPath || newFileName_0 !== initialFileName) {
			setFolderPath(newFolderPath_0);
			setFileName(newFileName_0);
			onChange(newFileName_0, newFolderPath_0);
		}
	}, [
		onChange,
		fileName,
		folderPath,
		initialFileName,
		initialFolderPath,
		nameInputRef
	]);
	return /* @__PURE__ */ jsxs("div", {
		className: BlobEditor_module_default.Box_5,
		children: [showTreeToggle && /* @__PURE__ */ jsx("div", {
			className: BlobEditor_module_default.Box_6,
			children: treeToggleElement
		}), /* @__PURE__ */ jsxs("div", {
			style: { maxWidth: showTreeToggle ? "calc(100% - 75px)" : "100%" },
			className: BlobEditor_module_default.Box_7,
			children: [/* @__PURE__ */ jsx(Breadcrumb, {
				id: "file-name-editor-breadcrumb",
				path: folderPath,
				repo,
				commitish: refInfo.name,
				isFolder: false
			}), /* @__PURE__ */ jsxs("div", {
				className: BlobEditor_module_default.Box_8,
				children: [
					/* @__PURE__ */ jsx(Separator, {}),
					/* @__PURE__ */ jsx(TextInput$1, {
						"aria-label": "File name",
						"aria-describedby": "file-name-editor-breadcrumb",
						disabled: inputDisabled,
						onChange: onFileNameChange,
						onKeyDown: onFileNameInputKeyPress,
						value: fileName,
						ref: nameInputRef,
						placeholder: "Name your file...",
						className: BlobEditor_module_default.TextInput
					}),
					/* @__PURE__ */ jsx("div", {
						className: BlobEditor_module_default.Box_9,
						children: "in"
					}),
					/* @__PURE__ */ jsx(BranchName_default, {
						href: branchPath({
							owner: repo.ownerLogin,
							repo: repo.name,
							branch: refInfo.name
						}),
						children: refInfo.name
					})
				]
			})]
		})]
	});
}
EditBreadcrumb.displayName = "EditBreadcrumb";
export { blobEditSidePanelId, BlobEditor as default };
