function appEnv() {
	return "production";
}
var testIdProps = (value) => {
	if (appEnv() === "production") return {};
	return { "data-testid": value };
};
export { testIdProps as t };
