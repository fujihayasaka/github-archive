import { n as useAppPayload } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
function useReposAppPayload() {
	return useAppPayload();
}
export { useReposAppPayload as t };
