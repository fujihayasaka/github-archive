performance.mark("js-parse-end:server-GlobalAgentsMenu-CNs9Ls-S-BeuGctZw.js");
import { t as GlobalAgentsMenuWithAnchor } from "./server-GlobalAgentsMenu-DLyAZGA8-WzRfDd2x.js";
performance.mark("js-parse-end:GlobalAgentsMenu-CNs9Ls-S.js");
export { GlobalAgentsMenuWithAnchor };
