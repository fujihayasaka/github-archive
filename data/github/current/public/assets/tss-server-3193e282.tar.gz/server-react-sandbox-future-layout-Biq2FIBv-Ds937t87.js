performance.mark("js-parse-end:server-react-sandbox-future-layout-Biq2FIBv-Ds937t87.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:react-sandbox-future-layout-Biq2FIBv.js");
var layoutLoader_createServerFn_handler = createServerRpc({
	id: "76837b393b559363a9cd378daa2414bc95808736e1245f9fb3a38db41a020fb5",
	name: "layoutLoader",
	filename: "src/routes/react_sandbox_future/react-sandbox-future-layout.tsx"
}, (opts) => layoutLoader.__executeServer(opts));
var layoutLoader = createServerFn().handler(layoutLoader_createServerFn_handler, async () => {
	const { payload } = await fetchDataRouterMainQuery({
		path: "/_react_sandbox_future/_layout",
		service: "dotcom"
	}, "reactSandboxFutureLayoutRoute");
	return payload;
});
export { layoutLoader_createServerFn_handler };
