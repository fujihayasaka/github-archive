import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { t as FETCH_NONCE_HEADER } from "./server-fetch-nonce-CQRTCHX--Bxo3Ybl_.js";
import { n as isDev, t as canAccessUIRuntimeStaging } from "./server-env-CmF5Q86i-CMsKyIar.js";
import { a as getRequestHeader, i as getParsedRequestUrl, o as getRequestHostInfo, r as getOrCreateRequestFetchNonce } from "./server-request-C9AEnFH8-C42vJH27.js";
import { a as buildUrl, f as logger, n as DataService, p as reportError, r as ServiceFetchError, s as getAuthContext, u as isStaff } from "./server-auth-CdSUgQ-0-DHDnXnPo.js";
import { n as getUIVersion } from "./server-ui-manifest-bErCbRQw-CIMAfPrX.js";
import { createHmac } from "node:crypto";
import { Headers as Headers$1, Response } from "undici";
var HMAC_ENV_VAR = "UI_DEPLOYS_HMAC_SECRETS";
var PASS_THROUGH_QUERY_PARAMS = [
	"_features",
	"_ui_sha",
	"_clear_ui_sha"
];
var hmacSecret;
if (!isDev()) {
	const hmacSecrets = process.env[HMAC_ENV_VAR];
	if (!hmacSecrets) logger.warn(`[dotcom] ${HMAC_ENV_VAR} environment variable is not set`);
	else {
		const secret = hmacSecrets.split(" ")[0];
		if (!secret) logger.warn(`[dotcom] ${HMAC_ENV_VAR} contains no valid secrets`);
		else hmacSecret = secret;
	}
}
function getAdditionalHeaders() {
	const headers = { [FETCH_NONCE_HEADER]: getOrCreateRequestFetchNonce() };
	if (isDev() || !hmacSecret) return headers;
	const sha = getUIVersion();
	const timestamp = Math.floor(Date.now() / 1e3).toString();
	const message = `${sha}.${timestamp}`;
	headers["X-GitHub-UI-SHA"] = `${sha}.${timestamp}.${createHmac("sha256", hmacSecret).update(message).digest("hex")}`;
	return headers;
}
/**
* Get additional query parameters for dotcom requests.
* Forwards the _features query param from the incoming request when allowed,
* unless the caller already provides it in params or the path query string.
*
* The decoded _features value is forwarded via buildUrl, which will percent-encode
* as needed. This intentionally normalizes encoding (avoids double-encoding)
* and matches dotcom's decoded query handling.
*/
function getAdditionalParams(options) {
	const additionalParams = {};
	if (!isDev() && !isStaff()) return additionalParams;
	const url = getParsedRequestUrl();
	for (const paramName of PASS_THROUGH_QUERY_PARAMS) {
		const paramsHasParam = options.params != null && paramName in options.params && options.params[paramName] != null;
		const pathHasParam = options.path.includes(`?${paramName}=`) || options.path.includes(`&${paramName}=`);
		if (paramsHasParam || pathHasParam) continue;
		const value = url.searchParams.get(paramName)?.trim();
		if (value) additionalParams[paramName] = value;
	}
	return additionalParams;
}
/**
* Configuration for the dotcom data service.
* Used to fetch data from the main GitHub application.
* Includes HMAC authentication support for secure requests.
*/
var dotcomService = new DataService({
	name: "dotcom",
	service: "unicorn",
	repo: "github",
	port: 80,
	devPort: 3e3,
	forwardHostHeaders: true,
	forwardIETHeader: true,
	warmup: {
		path: "/status",
		method: "GET"
	},
	getAdditionalHeaders,
	getAdditionalParams
});
/**
* Configuration for the feature-flags data service.
* Used to fetch feature flag data from the feature-management-sidecar.
*/
var featureFlagsService = new DataService({
	name: "feature-flags",
	connectionType: "sidecar",
	service: "feature-management-sidecar",
	port: 18383,
	warmup: {
		path: "/_ready",
		method: "GET"
	}
});
/**
* Configuration for the ui-runtime-staging data service.
* Used to proxy preview traffic to the staging ui-runtime instance
* which serves a specific build identified by the `_ui_sha` parameter.
*/
var uiRuntimeStagingService = new DataService({
	name: "ui-runtime-staging",
	service: "ui-runtime",
	repo: "ui-runtime",
	environment: "staging",
	port: 8080,
	devPort: 8080,
	forwardHostHeaders: true
});
var DataServiceRegistry = class {
	servicesMap;
	constructor(services) {
		this.servicesMap = new Map(services.map((service) => [service.name, service]));
	}
	get(name) {
		return this.servicesMap.get(name);
	}
	get all() {
		return Array.from(this.servicesMap.values());
	}
	get services() {
		return this.servicesMap;
	}
	async closeAll() {
		await Promise.all(this.all.map((service) => service.close()));
	}
	async prewarmAll(options = {}) {
		const { services: servicesToWarm, warmupConnections } = options;
		const resolvedServices = servicesToWarm?.length ? servicesToWarm.map((serviceOption) => ({
			service: this.get(serviceOption.service),
			name: serviceOption.service,
			warmup: serviceOption
		})) : this.all.map((service) => ({
			service,
			name: service.name,
			warmup: void 0
		}));
		return Promise.all(resolvedServices.map(({ service, name, warmup }) => {
			if (!service) return Promise.resolve({
				service: name,
				ok: false,
				error: /* @__PURE__ */ new Error(`Unknown data service: ${name}`)
			});
			const warmupOverrides = warmup ? {
				path: warmup.path,
				method: warmup.method,
				headers: warmup.headers
			} : void 0;
			return service.prewarm({
				...warmupOverrides,
				warmupConnections
			});
		}));
	}
};
var registeredServices = [dotcomService, featureFlagsService];
if (canAccessUIRuntimeStaging()) registeredServices.push(uiRuntimeStagingService);
var registry = new DataServiceRegistry(registeredServices);
registry.services;
function getForwardedHostHeaders(requestHostInfo = getRequestHostInfo()) {
	return {
		"x-forwarded-host": requestHostInfo.host,
		"x-forwarded-proto": requestHostInfo.proto,
		"x-forwarded-port": requestHostInfo.port
	};
}
function rewriteLocationHeaderToPublicOrigin({ response, service, metricTag, requestHostInfo = getRequestHostInfo() }) {
	const initialLocation = response.headers.get("location");
	if (!initialLocation) return response;
	let locationUrl;
	try {
		locationUrl = new URL(initialLocation);
	} catch {
		return response;
	}
	if (locationUrl.hostname !== service.parsedBaseUrl.hostname) return response;
	locationUrl.protocol = `${requestHostInfo.proto}:`;
	locationUrl.host = requestHostInfo.host;
	const rewrittenLocation = locationUrl.toString();
	if (rewrittenLocation === initialLocation) return response;
	const responseHeaders = new Headers$1(response.headers);
	responseHeaders.set("location", rewrittenLocation);
	logger.info({
		event: "data_service_location_rewritten",
		service: service.name,
		metricTag,
		initialLocation,
		rewrittenLocation,
		requestHostInfo
	}, `[${service.name}] Rewrote upstream Location header to the public request host`);
	return new Response(response.body, {
		status: response.status,
		statusText: response.statusText,
		headers: responseHeaders
	});
}
async function runPrewarm(options) {
	try {
		const prewarmResults = await registry.prewarmAll(options);
		const failures = prewarmResults.filter((result) => !result.ok);
		if (failures.length) logger.info({
			event: "prewarmDataServices failures",
			msg: failures.map(({ service, status, error }) => ({
				service,
				status,
				error: error?.message,
				cause: error?.cause instanceof Error ? error.cause.message : error?.cause ? String(error.cause) : void 0
			}))
		});
		return prewarmResults;
	} catch (error) {
		logger.info({
			event: "prewarmDataServices failed",
			msg: error.message
		});
		throw error;
	}
}
/**
* Pre-warm data services.
* - runs immediately and schedules recurring warmups; returns a stop function.
* - Defaults: interval 60s, warmupConnections 1 in dev, 10 otherwise.
* - In dev, skips entirely unless DATA_SERVICE_PREWARM is truthy.
*/
async function prewarmDataServices(options = {}) {
	if (isDev() && !process.env.DATA_SERVICE_PREWARM) {
		logger.info({
			event: "prewarmDataServices skipped",
			reason: "dev env without DATA_SERVICE_PREWARM"
		});
		return [];
	}
	const defaultWarmupConnections = isDev() ? 1 : 10;
	const { intervalMs = 55e3, warmupConnections = defaultWarmupConnections, ...rest } = options;
	const prewarmOptions = {
		...rest,
		warmupConnections
	};
	await runPrewarm(prewarmOptions);
	let stopped = false;
	let timeout;
	const scheduleNext = () => {
		timeout = setTimeout(async () => {
			await runPrewarm(prewarmOptions);
			if (!stopped) scheduleNext();
		}, intervalMs);
		timeout.unref?.();
	};
	scheduleNext();
	return () => {
		stopped = true;
		if (timeout) clearTimeout(timeout);
	};
}
/**
* Build headers for a data fetch request.
*
* @param options - The fetch options
* @returns Headers object for the fetch request
*/
function buildHeaders(options, service, additionalHeaders) {
	const headers = new Headers({
		...options.headers,
		...additionalHeaders
	});
	function addHeader(name, value) {
		if (!headers.has(name) && value) headers.set(name, value);
	}
	if (options.body) addHeader("Content-Type", "application/json");
	addHeader("cookie", getRequestHeader("cookie"));
	if (service.forwardIETHeader) try {
		if (isFeatureEnabled("authentication_user_session_iet")) {
			const iet = getAuthContext()?.iet;
			addHeader("x-github-iet", iet);
		}
	} catch {}
	if (service.forwardHostHeaders) {
		const hostHeaders = getForwardedHostHeaders();
		for (const [key, value] of Object.entries(hostHeaders)) addHeader(key, value);
	}
	return headers;
}
/**
* Fetch from an internal service and return the raw Response.
*
* This function must be called from within a request context
* (e.g., from a loader or server function) as it accesses
* the incoming request's cookies.
*
* @param options - Configuration for the fetch request
* @returns Promise resolving to the raw Response
*/
async function fetchFromService(options) {
	const { service: serviceName, path, method = "GET", body } = options;
	const service = registry.get(serviceName);
	if (!service) throw new Error(`Unknown data service: ${serviceName}`);
	if (!service.fetch) throw new Error(`Service ${serviceName} is missing a fetch implementation`);
	const baseUrl = service.baseUrl;
	const additionalParams = options.skipAdditionalParams ? {} : service.getAdditionalParams?.({
		path,
		method,
		params: options.params
	}) ?? {};
	const url = buildUrl(baseUrl, path, {
		...options.params,
		...additionalParams
	});
	const fetchOptions = {
		method,
		headers: buildHeaders(options, service, options.skipAdditionalHeaders ? {} : service.getAdditionalHeaders?.({
			url,
			method,
			body
		}) ?? {}),
		redirect: options.redirect
	};
	if (options.rawBody != null) {
		fetchOptions.body = options.rawBody;
		fetchOptions.duplex = "half";
	} else if (body && method !== "GET") fetchOptions.body = JSON.stringify(body);
	const response = await service.fetchWithMetrics(url, fetchOptions, {
		method,
		mechanism: "fetch",
		metricTag: options.metricTag
	});
	return service.forwardHostHeaders ? rewriteLocationHeaderToPublicOrigin({
		response,
		service,
		metricTag: options.metricTag
	}) : response;
}
/**
* Fetch JSON from an internal service with automatic parsing.
*
* This function must be called from within a request context
* (e.g., from a loader or server function) as it accesses
* the incoming request's cookies.
*
* @param options - Configuration for the fetch request
* @returns Promise resolving to the parsed JSON data
* @throws {ServiceFetchError} When the request fails, returns a non-ok status, or JSON parsing fails (for example, when HTML is returned instead of JSON)
*/
async function fetchServiceJSON(options) {
	const { service: serviceName } = options;
	const response = await fetchFromService({
		...options,
		headers: {
			Accept: "application/json",
			...options.headers
		}
	});
	if (!response.ok) {
		reportError(/* @__PURE__ */ new Error(`Error fetching JSON from ${serviceName}: ${response.status} ${response.statusText}`));
		throw new ServiceFetchError(response.status, response.statusText, serviceName);
	}
	try {
		return await response.json();
	} catch (error) {
		const parseError = error instanceof Error ? error : /* @__PURE__ */ new Error(`Invalid JSON response from ${serviceName} for URL ${response.url}`);
		const errorMessage = parseError.message;
		reportError(parseError, errorMessage);
		throw new ServiceFetchError(406, errorMessage, serviceName);
	}
}
export { fetchServiceJSON as n, prewarmDataServices as r, fetchFromService as t };
