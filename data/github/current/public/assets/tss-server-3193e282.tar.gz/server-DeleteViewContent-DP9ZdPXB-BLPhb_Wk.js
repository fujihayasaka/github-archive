import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { F as ChevronDownIcon, L as ChevronRightIcon, Qt as Heading$2, an as IconButton, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { n as DiffPlaceholder, r as DiffSquares } from "./server-diff-parts-DKuV_5Kq-C34001QS.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { n as EditingForkBanner, t as EditIssues } from "./server-EditIssues-CxyxDJIu-OavrLrRt.js";
import { t as IncludeFragment } from "./server-IncludeFragment-DnVGLtXS-CQrYLuE4.js";
import { useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var DeleteViewEntry_module_default = {
	diffContent: "DeleteViewEntry-module_HWc_ba_diffContent",
	diffContentCollapsed: "DeleteViewEntry-module_HWc_ba_diffContentCollapsed",
	diffEntry: "DeleteViewEntry-module_HWc_ba_diffEntry",
	diffHeader: "DeleteViewEntry-module_HWc_ba_diffHeader",
	diffOverlay: "DeleteViewEntry-module_HWc_ba_diffOverlay",
	loadingSpinner: "DeleteViewEntry-module_HWc_ba_loadingSpinner",
	placeholderPath: "DeleteViewEntry-module_HWc_ba_placeholderPath",
	placeholderSvg: "DeleteViewEntry-module_HWc_ba_placeholderSvg"
};
function DiffEntry(t0) {
	const $ = c(14);
	const { diff, index } = t0;
	const [collapsed, setCollapsed] = useState(false);
	const [showDiff, setShowDiff] = useState(false);
	const [diffLoaded, setDiffLoaded] = useState(false);
	let t1;
	let t2;
	if ($[0] !== collapsed || $[1] !== diff.deletions || $[2] !== diff.diffHTML || $[3] !== diff.loadDiffPath || $[4] !== diff.path || $[5] !== diffLoaded || $[6] !== index || $[7] !== showDiff) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const squares = [];
			for (let i = 0; i < 5; i++) if (diff.deletions > i) squares.push("deletion");
			else squares.push("neutral");
			if (diff.diffHTML) {
				let t3;
				if ($[10] !== diff.diffHTML) {
					t3 = jsx("div", {
						id: "readme",
						className: "readme prose-diff html-blob blob",
						children: jsx(VerifiedHTMLBox, {
							html: diff.diffHTML,
							className: "markdown-body container-lg"
						})
					});
					$[10] = diff.diffHTML;
					$[11] = t3;
				} else t3 = $[11];
				t2 = t3;
				break bb0;
			}
			let t3;
			if ($[12] !== collapsed) {
				t3 = () => setCollapsed(!collapsed);
				$[12] = collapsed;
				$[13] = t3;
			} else t3 = $[13];
			t1 = jsxs("div", {
				className: DeleteViewEntry_module_default.diffEntry,
				id: `diff-entry-${index}`,
				children: [jsxs("div", {
					className: DeleteViewEntry_module_default.diffHeader,
					children: [
						jsx(IconButton, {
							"aria-label": collapsed ? "Expand diff" : "Collapse diff",
							icon: collapsed ? ChevronRightIcon : ChevronDownIcon,
							size: "small",
							tooltipDirection: "s",
							variant: "invisible",
							onClick: t3
						}),
						jsx("span", {
							className: "color-fg-muted",
							children: diff.deletions
						}),
						jsx(DiffSquares, { squares }),
						jsx(Link, {
							href: `#diff-entry-${index}`,
							className: "color-fg-default",
							children: diff.path
						}),
						jsx(CopyToClipboardButton, {
							textToCopy: diff.path,
							ariaLabel: "Copy path to clipboard"
						})
					]
				}), collapsed ? null : jsx("div", {
					className: showDiff ? DeleteViewEntry_module_default.diffContentCollapsed : DeleteViewEntry_module_default.diffContent,
					tabIndex: -1,
					children: showDiff ? jsx(IncludeFragment, {
						"data-testid": "delete-diff-fragment",
						src: diff.loadDiffPath,
						onLoad: () => setDiffLoaded(true),
						children: !diffLoaded && jsx("div", {
							className: DeleteViewEntry_module_default.loadingSpinner,
							children: jsx(Spinner, {})
						})
					}) : jsxs(Fragment$1, { children: [jsx(DiffPlaceholderSvg, {}), jsxs("div", {
						className: DeleteViewEntry_module_default.diffOverlay,
						children: [jsx(Link, {
							as: "button",
							onClick: () => setShowDiff(true),
							inline: true,
							children: "Load diff"
						}), "This file was deleted."]
					})] })
				})]
			});
		}
		$[0] = collapsed;
		$[1] = diff.deletions;
		$[2] = diff.diffHTML;
		$[3] = diff.loadDiffPath;
		$[4] = diff.path;
		$[5] = diffLoaded;
		$[6] = index;
		$[7] = showDiff;
		$[8] = t1;
		$[9] = t2;
	} else {
		t1 = $[8];
		t2 = $[9];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
DiffEntry.displayName = "DiffEntry";
function DiffPlaceholderSvg() {
	return /* @__PURE__ */ jsx("svg", {
		"aria-hidden": "true",
		className: clsx("width-full", DeleteViewEntry_module_default.placeholderSvg),
		viewBox: "0 0 340 84",
		xmlns: "http://www.w3.org/2000/svg",
		children: /* @__PURE__ */ jsx("path", {
			className: clsx("js-diff-placeholder", DeleteViewEntry_module_default.placeholderPath),
			clipPath: "url(#diff-placeholder)",
			d: "M0 0h340v84H0z",
			fillRule: "evenodd"
		})
	});
}
DiffPlaceholderSvg.displayName = "DiffPlaceholderSvg";
function DeleteViewContent(t0) {
	const $ = c(12);
	const { deleteInfo, webCommitInfo } = t0;
	const path = usePath();
	const { helpUrl } = useReposAppPayload();
	const repo = useCurrentRepository();
	if (webCommitInfo.shouldFork || webCommitInfo.shouldUpdate || webCommitInfo.lockedOnMigration) {
		let t1;
		if ($[0] !== helpUrl || $[1] !== repo.name || $[2] !== webCommitInfo) {
			t1 = jsx(EditIssues, {
				binary: false,
				helpUrl,
				webCommitInfo,
				repositoryName: repo.name
			});
			$[0] = helpUrl;
			$[1] = repo.name;
			$[2] = webCommitInfo;
			$[3] = t1;
		} else t1 = $[3];
		return t1;
	}
	let t1;
	if ($[4] !== deleteInfo.diffs || $[5] !== deleteInfo.isBlob || $[6] !== deleteInfo.truncated || $[7] !== path || $[8] !== repo.name || $[9] !== webCommitInfo.canCreatePullRequest || $[10] !== webCommitInfo.forkedRepo) {
		t1 = jsxs("div", {
			className: "container-xl mx-auto",
			children: [
				jsx(Heading$2, {
					as: "h1",
					className: "sr-only",
					children: `Deleting ${deleteInfo.isBlob ? "" : "directory "}${repo.name}/${path}. Commit changes to save.`
				}),
				jsx(DiffPlaceholder, {}),
				webCommitInfo.forkedRepo && jsx(EditingForkBanner, {
					forkName: webCommitInfo.forkedRepo.name,
					forkOwner: webCommitInfo.forkedRepo.owner,
					canCreatePullRequest: webCommitInfo.canCreatePullRequest
				}),
				deleteInfo.truncated && jsx(Flash, {
					variant: "warning",
					className: "mb-2",
					children: "The diff you're trying to view is too large. We only load the first 1000 changed files."
				}),
				deleteInfo.diffs.map(_temp)
			]
		});
		$[4] = deleteInfo.diffs;
		$[5] = deleteInfo.isBlob;
		$[6] = deleteInfo.truncated;
		$[7] = path;
		$[8] = repo.name;
		$[9] = webCommitInfo.canCreatePullRequest;
		$[10] = webCommitInfo.forkedRepo;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
DeleteViewContent.displayName = "DeleteViewContent";
function _temp(diff, index) {
	return jsx(DiffEntry, {
		diff,
		index
	}, index);
}
export { DeleteViewContent as t };
