performance.mark("js-parse-end:server-tree-1hplyQBp-Dmrrvker.js");
import { Qt as Heading$2, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { d as sendCustomMetric } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { S as useSearchParams } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { n as useEditPermissions } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { l as useOpenPanel } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { t as Panel } from "./server-Panel-C4KaHVsW-jwL1gzzi.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { t as useStickyObserver } from "./server-use-sticky-observer-CFnc-YRM-CDkfs7O1.js";
import { n as useTreePaneContext } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { r as CodeViewHeaderDataRouter, s as TreeHeaderActions } from "./server-NavigationMenu-CKgcoy5c-Bbjbrr6N.js";
import { t as codeViewTreeRoute } from "./server-code-view-tree-route-DaWFX48b-q_Z2gZhH.js";
import { t as LatestCommitProvider } from "./server-LatestCommitContext-D4oQqyj7-DHpYqCjL.js";
import { l as TableOfContentsPanel, r as LatestCommitSingleLine, t as CurrentTreeProvider } from "./server-PublishBanners-D6t9Jc-5-BK-GhWxy.js";
import { a as TreeBanners, i as TableOfContents, r as FileNameStickyHeader, s as useStickyHeaderStyle } from "./server-CodeViewBanners-D01K_nCP-X3Rsq57I.js";
import { t as CodeView } from "./server-CodeView-CCvwX-NJ-CNmyXFpi.js";
import { n as isFileOverviewPayload } from "./server-overview-types-BCkg03zy-KrP1i6Gn.js";
import { t as useWebVitals } from "./server-use-web-vitals-ePxIuvZ_-Cf0rAEz6.js";
import { a as DirectoryContent, c as RecentlyTouchedBranchesProvider, i as CommitInfoProvider, l as ReposOverviewPage, n as BranchInfoBar, o as DirectoryRichtextContent, r as BranchInfoBarErrorBanner, s as EditButton, t as BranchAndTagCountProvider } from "./server-ReposOverviewPage-D24MR2RX-CZxxJG-r.js";
import { useEffect } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:tree-1hplyQBp.js");
var DirectoryReadmePreview_module_default = {
	readmeContainer: "DirectoryReadmePreview-module_-OPJuG_readmeContainer",
	readmeContainerFull: "DirectoryReadmePreview-module_-OPJuG_readmeContainerFull",
	readmeContainerWithToc: "DirectoryReadmePreview-module_-OPJuG_readmeContainerWithToc",
	readmeHeader: "DirectoryReadmePreview-module_-OPJuG_readmeHeader",
	readmeHeading: "DirectoryReadmePreview-module_-OPJuG_readmeHeading",
	readmeLink: "DirectoryReadmePreview-module_-OPJuG_readmeLink",
	readmeWrapper: "DirectoryReadmePreview-module_-OPJuG_readmeWrapper"
};
function DirectoryReadmePreview(t0) {
	const { openPanel, readme, setOpenPanel, stickyHeaderHeight } = t0;
	const { displayName, errorMessage, richText, headerInfo, timedOut } = readme;
	const { toc } = headerInfo || {};
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const { canEdit } = useEditPermissions();
	const readmePath = path && path !== "/" ? `${path}/${displayName}` : displayName;
	return jsxs("div", {
		className: DirectoryReadmePreview_module_default.readmeWrapper,
		children: [jsxs("div", {
			id: "readme",
			className: clsx(DirectoryReadmePreview_module_default.readmeContainer, openPanel === "toc" ? DirectoryReadmePreview_module_default.readmeContainerWithToc : DirectoryReadmePreview_module_default.readmeContainerFull),
			children: [jsxs("div", {
				className: DirectoryReadmePreview_module_default.readmeHeader,
				children: [
					jsx(Heading$2, {
						as: "h2",
						className: DirectoryReadmePreview_module_default.readmeHeading,
						children: jsx(Link, {
							className: DirectoryReadmePreview_module_default.readmeLink,
							href: "#readme",
							children: displayName
						})
					}),
					canEdit && jsx(EditButton, {
						editPath: repositoryTreePath({
							repo,
							commitish: refInfo.name,
							action: "edit",
							path: readmePath
						}),
						editTooltip: "Edit README"
					}),
					jsx(TableOfContents, {
						toc,
						openPanel,
						setOpenPanel,
						isDirectoryReadme: true
					})
				]
			}), jsx(DirectoryRichtextContent, {
				richText,
				errorMessage,
				path: readmePath,
				stickyHeaderHeight,
				timedOut
			})]
		}), openPanel === "toc" && jsx(Panel, {
			style: {
				height: "fit-content",
				width: "35%"
			},
			children: jsx(TableOfContentsPanel, {
				onClose: () => {
					setOpenPanel(void 0);
				},
				toc
			})
		})]
	});
}
DirectoryReadmePreview.displayName = "DirectoryReadmePreview";
var FolderViewHeader_module_default = {
	innerWrapper: "FolderViewHeader-module_icIHvG_innerWrapper",
	innerWrapperNotStickied: "FolderViewHeader-module_icIHvG_innerWrapperNotStickied",
	innerWrapperStickied: "FolderViewHeader-module_icIHvG_innerWrapperStickied",
	outerWrapper: "FolderViewHeader-module_icIHvG_outerWrapper",
	outerWrapperStickied: "FolderViewHeader-module_icIHvG_outerWrapperStickied"
};
function FolderViewHeader(t0) {
	const $ = c(6);
	const { showTree, treeToggleElement } = t0;
	const { isSticky: isStickied, sentinelRef: headerRef } = useStickyObserver();
	const stickyStyle = useStickyHeaderStyle();
	let t1;
	if ($[0] !== headerRef || $[1] !== isStickied || $[2] !== showTree || $[3] !== stickyStyle || $[4] !== treeToggleElement) {
		t1 = jsx("div", {
			className: clsx("react-blob-view-header-sticky", isStickied ? FolderViewHeader_module_default.outerWrapperStickied : FolderViewHeader_module_default.outerWrapper),
			style: stickyStyle,
			ref: headerRef,
			children: jsx("div", {
				className: clsx(FolderViewHeader_module_default.innerWrapper, isStickied ? FolderViewHeader_module_default.innerWrapperStickied : FolderViewHeader_module_default.innerWrapperNotStickied),
				children: jsx(FileNameStickyHeader, {
					isStickied,
					showTree,
					treeToggleElement
				})
			})
		});
		$[0] = headerRef;
		$[1] = isStickied;
		$[2] = showTree;
		$[3] = stickyStyle;
		$[4] = treeToggleElement;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
FolderViewHeader.displayName = "FolderViewHeader";
function FileTreeViewContent(t0) {
	const $ = c(6);
	const { tree, showTree, treeToggleElement } = t0;
	const { openPanel, setOpenPanel } = useOpenPanel();
	let t1;
	if ($[0] !== openPanel || $[1] !== setOpenPanel || $[2] !== showTree || $[3] !== tree || $[4] !== treeToggleElement) {
		t1 = jsxs(CurrentTreeProvider, {
			payload: tree,
			children: [
				jsx(LatestCommitSingleLine, {}),
				tree.showBranchInfobar && jsx(ErrorBoundary, {
					fallback: jsx(BranchInfoBarErrorBanner, {}),
					children: jsx(BranchInfoBar, {})
				}),
				jsx(FolderViewHeader, {
					showTree,
					treeToggleElement
				}),
				jsxs("div", {
					className: "d-flex flex-column gap-3",
					children: [jsx(DirectoryContent, {}), tree.readme && jsx(DirectoryReadmePreview, {
						openPanel,
						setOpenPanel,
						readme: tree.readme,
						stickyHeaderHeight: 50
					})]
				})
			]
		});
		$[0] = openPanel;
		$[1] = setOpenPanel;
		$[2] = showTree;
		$[3] = tree;
		$[4] = treeToggleElement;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
FileTreeViewContent.displayName = "FileTreeViewContent";
function CodeViewTreeEntrypoint() {
	const $ = c(8);
	const { data: payload } = useRouteQuery(codeViewTreeRoute, "mainQuery");
	const { data: latestCommit, error: latestCommitError, isLoading: latestCommitLoading } = useRouteQuery(codeViewTreeRoute, "latestCommit");
	const { data: commitInfo, error: commitInfoError, isLoading: commitInfoLoading } = useRouteQuery(codeViewTreeRoute, "treeCommitInfo");
	const t0 = !!commitInfoError;
	let t1;
	if ($[0] !== commitInfo || $[1] !== commitInfoLoading || $[2] !== latestCommit || $[3] !== latestCommitError || $[4] !== latestCommitLoading || $[5] !== payload || $[6] !== t0) {
		t1 = jsx(CommitInfoProvider, {
			commitInfo,
			error: t0,
			loading: commitInfoLoading,
			children: jsx(LatestCommitProvider, {
				latestCommit,
				error: latestCommitError,
				isLoading: latestCommitLoading,
				children: isFileOverviewPayload(payload) ? jsx(CodeViewRepoOnBranch, { payload }) : jsx(CodeViewTree, { payload })
			})
		});
		$[0] = commitInfo;
		$[1] = commitInfoLoading;
		$[2] = latestCommit;
		$[3] = latestCommitError;
		$[4] = latestCommitLoading;
		$[5] = payload;
		$[6] = t0;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
}
CodeViewTreeEntrypoint.displayName = "CodeViewTreeEntrypoint";
function CodeViewRepoOnBranch(t0) {
	const $ = c(27);
	const { payload } = t0;
	const repo = useCurrentRepository();
	const t1 = `/${repo.ownerLogin}/${repo.name}/recently-touched-branches`;
	let t2;
	if ($[0] !== t1) {
		t2 = { pathname: t1 };
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	const recentlyTouchedBranchesQueryDeps = t2;
	let t3;
	if ($[2] !== recentlyTouchedBranchesQueryDeps || $[3] !== repo.name || $[4] !== repo.ownerLogin) {
		t3 = [
			repo.ownerLogin,
			repo.name,
			"recently-touched-branches",
			recentlyTouchedBranchesQueryDeps
		];
		$[2] = recentlyTouchedBranchesQueryDeps;
		$[3] = repo.name;
		$[4] = repo.ownerLogin;
		$[5] = t3;
	} else t3 = $[5];
	let t4;
	if ($[6] !== recentlyTouchedBranchesQueryDeps) {
		t4 = () => queryFnFetch({ queryDeps: recentlyTouchedBranchesQueryDeps });
		$[6] = recentlyTouchedBranchesQueryDeps;
		$[7] = t4;
	} else t4 = $[7];
	let t5;
	if ($[8] !== t3 || $[9] !== t4) {
		t5 = {
			queryKey: t3,
			queryFn: t4
		};
		$[8] = t3;
		$[9] = t4;
		$[10] = t5;
	} else t5 = $[10];
	const { data: recentlyTouchedBranches, refetch } = useQuery(t5);
	const t6 = `/${repo.ownerLogin}/${repo.name}/branch-and-tag-count`;
	let t7;
	if ($[11] !== t6) {
		t7 = { pathname: t6 };
		$[11] = t6;
		$[12] = t7;
	} else t7 = $[12];
	const branchAndTagCountQueryDeps = t7;
	let t8;
	if ($[13] !== branchAndTagCountQueryDeps || $[14] !== repo.name || $[15] !== repo.ownerLogin) {
		t8 = [
			repo.ownerLogin,
			repo.name,
			"branch-and-tag-count",
			branchAndTagCountQueryDeps
		];
		$[13] = branchAndTagCountQueryDeps;
		$[14] = repo.name;
		$[15] = repo.ownerLogin;
		$[16] = t8;
	} else t8 = $[16];
	let t9;
	if ($[17] !== branchAndTagCountQueryDeps) {
		t9 = () => queryFnFetch({ queryDeps: branchAndTagCountQueryDeps });
		$[17] = branchAndTagCountQueryDeps;
		$[18] = t9;
	} else t9 = $[18];
	let t10;
	if ($[19] !== t8 || $[20] !== t9) {
		t10 = {
			queryKey: t8,
			queryFn: t9
		};
		$[19] = t8;
		$[20] = t9;
		$[21] = t10;
	} else t10 = $[21];
	const { data: branchAndTagCount } = useQuery(t10);
	let t11;
	if ($[22] !== branchAndTagCount || $[23] !== payload || $[24] !== recentlyTouchedBranches || $[25] !== refetch) {
		t11 = jsx(BranchAndTagCountProvider, {
			count: branchAndTagCount,
			children: jsx(RecentlyTouchedBranchesProvider, {
				...recentlyTouchedBranches,
				refetch,
				children: jsx(ReposOverviewPage, {
					payload,
					isTree: true
				})
			})
		});
		$[22] = branchAndTagCount;
		$[23] = payload;
		$[24] = recentlyTouchedBranches;
		$[25] = refetch;
		$[26] = t11;
	} else t11 = $[26];
	return t11;
}
CodeViewRepoOnBranch.displayName = "CodeViewRepoOnBranch";
function CodeViewTree({ payload }) {
	const { isTreeExpanded, treeToggleElement, expandTree } = useTreePaneContext();
	const [searchParams] = useSearchParams();
	useWebVitals("hpc", (event) => {
		if (!event.detail.hpc) return;
		sendCustomMetric({
			name: "CODE_VIEW_TREE_HPC",
			value: event.detail.hpc,
			tags: {
				app: "code-view",
				soft: String(event.detail.soft),
				ssr: String(event.detail.ssr),
				mechanism: String(event.detail.mechanism)
			}
		});
	});
	useWebVitals("inp", (event) => {
		if (!event.detail.inp) return;
		sendCustomMetric({
			name: "CODE_VIEW_TREE_INP",
			value: event.detail.inp,
			tags: {
				app: "code-view",
				inpInteractionType: event.detail.inpInteractionType || "unknown",
				inpEventType: event.detail.inpEventType || "unknown",
				inpBottleneck: event.detail.inpBottleneck || "unknown"
			}
		});
	});
	useEffect(() => {
		if (payload.treeExpanded && (searchParams.get("search") || searchParams.get("files"))) expandTree();
	}, []);
	const internal = /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CodeViewHeaderDataRouter, {
		narrowActions: /* @__PURE__ */ jsx(TreeHeaderActions, {
			payload,
			narrow: true,
			path: payload.path
		}),
		wideActions: /* @__PURE__ */ jsx(TreeHeaderActions, {
			payload,
			narrow: false,
			path: payload.path
		}),
		path: payload.path,
		commitish: payload.refInfo.name,
		modelsRepoIntegrationEnabled: payload.modelsRepoIntegrationEnabled
	}), /* @__PURE__ */ jsx(CodeView, {
		payload,
		action: "tree",
		children: () => /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
			className: "react-code-view-bottom-padding",
			children: /* @__PURE__ */ jsx(TreeBanners, {})
		}), /* @__PURE__ */ jsx(FileTreeViewContent, {
			tree: payload.tree,
			showTree: isTreeExpanded,
			treeToggleElement
		})] })
	})] });
	return payload.error ? internal : /* @__PURE__ */ jsx(CurrentTreeProvider, {
		payload: payload.tree,
		children: internal
	});
}
CodeViewTree.displayName = "CodeViewTree";
var SplitComponent = CodeViewTreeEntrypoint;
export { SplitComponent as component };
