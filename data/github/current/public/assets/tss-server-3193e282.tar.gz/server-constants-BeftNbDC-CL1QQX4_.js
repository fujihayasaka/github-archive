import { t as AnalyticsContext } from "./server-context-CRkr38GV-DyKv_rx3.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import React, { use, useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/**
* A context wrapper that provides default values for analytics events in the global navigation.
* This should be used at the top level of any component tree that is part of the global navigation
* (e.g. GlobalNavBar, GlobalNavMenu, DashboardLeftRail) to set the `appName` and `category` for all
* analytics events sent from components within that tree.
*
* This will compose with any existing AnalyticsProvider context (including one provided by the app),
*/
function GlobalNavAnalyticsProvider(props) {
	const $ = c(13);
	const analyticsContext = use(AnalyticsContext);
	let overrides;
	let subCategory;
	if ($[0] !== props) {
		({subCategory, ...overrides} = props);
		$[0] = props;
		$[1] = overrides;
		$[2] = subCategory;
	} else {
		overrides = $[1];
		subCategory = $[2];
	}
	let t0;
	if ($[3] !== analyticsContext?.metadata || $[4] !== subCategory) {
		t0 = subCategory ? {
			...analyticsContext?.metadata,
			subCategory
		} : analyticsContext?.metadata;
		$[3] = analyticsContext?.metadata;
		$[4] = subCategory;
		$[5] = t0;
	} else t0 = $[5];
	let t1;
	if ($[6] !== analyticsContext || $[7] !== overrides || $[8] !== t0) {
		t1 = {
			...analyticsContext,
			...overrides,
			metadata: t0
		};
		$[6] = analyticsContext;
		$[7] = overrides;
		$[8] = t0;
		$[9] = t1;
	} else t1 = $[9];
	const mergedContext = t1;
	let t2;
	if ($[10] !== mergedContext || $[11] !== props.children) {
		t2 = jsx(AnalyticsContext, {
			value: mergedContext,
			children: props.children
		});
		$[10] = mergedContext;
		$[11] = props.children;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
}
/** A hook that provides analytics event tracking for the global navigation. */
GlobalNavAnalyticsProvider.displayName = "GlobalNavAnalyticsProvider";
function useGlobalNavAnalytics(subCategory) {
	const $ = c(4);
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const analyticsContext = use(AnalyticsContext);
	const category = analyticsContext?.category || "GLOBAL_NAV";
	const computedSubCategory = subCategory ?? analyticsContext?.metadata?.subCategory;
	let t0;
	if ($[0] !== category || $[1] !== computedSubCategory || $[2] !== sendClickAnalyticsEvent) {
		t0 = { sendItemClick: (action, label) => {
			sendClickAnalyticsEvent({
				action,
				category: computedSubCategory ? `${category}:${computedSubCategory}` : category,
				label
			});
		} };
		$[0] = category;
		$[1] = computedSubCategory;
		$[2] = sendClickAnalyticsEvent;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
var analyticsCategory = "GLOBAL_NAV_MENU";
export { analyticsCategory as n, useGlobalNavAnalytics as r, GlobalNavAnalyticsProvider as t };
