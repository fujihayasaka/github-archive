function relayEnvironmentWithMissingFieldHandlerForNode() {
	return null;
}
function RelayEnvironmentProvider({ children }) {
	return children;
}
function clientSideRelayFetchQueryRetained({ environment: _environment, query: _query, variables: _variables = {}, metadata: _metadata = {} }) {
	return null;
}
export { clientSideRelayFetchQueryRetained as n, relayEnvironmentWithMissingFieldHandlerForNode as r, RelayEnvironmentProvider as t };
