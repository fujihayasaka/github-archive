import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { useEffect, useState } from "react";
import { c } from "react/compiler-runtime";
function getSchemeFromMode(mode) {
	switch (mode) {
		case "light": return "day";
		case "dark": return "night";
		default: return "auto";
	}
}
function getColorModes(options) {
	const mode = options.colorMode;
	return {
		colorMode: getSchemeFromMode(mode),
		dayScheme: options.lightTheme,
		nightScheme: options.darkTheme
	};
}
var ssrOptions;
function getColorModesSSR() {
	return getColorModes(ssrOptions || {});
}
function useColorModes() {
	const $ = c(11);
	const { documentElement } = ssrSafeDocument;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => getColorModes(documentElement.dataset);
		$[0] = t0;
	} else t0 = $[0];
	const [colorMode, setColorMode] = useState(t0);
	let t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			const observer = new MutationObserver(() => setColorMode(getColorModes(documentElement.dataset)));
			observer.observe(documentElement, {
				attributes: true,
				attributeFilter: [
					"data-color-mode",
					"data-light-theme",
					"data-dark-theme"
				]
			});
			return () => observer.disconnect();
		};
		t2 = [documentElement];
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useEffect(t1, t2);
	let t3;
	if ($[3] !== colorMode.dayScheme) {
		t3 = getColorScheme(colorMode.dayScheme);
		$[3] = colorMode.dayScheme;
		$[4] = t3;
	} else t3 = $[4];
	let t4;
	if ($[5] !== colorMode.nightScheme) {
		t4 = getColorScheme(colorMode.nightScheme);
		$[5] = colorMode.nightScheme;
		$[6] = t4;
	} else t4 = $[6];
	let t5;
	if ($[7] !== colorMode || $[8] !== t3 || $[9] !== t4) {
		t5 = {
			...colorMode,
			dayScheme: t3,
			nightScheme: t4
		};
		$[7] = colorMode;
		$[8] = t3;
		$[9] = t4;
		$[10] = t5;
	} else t5 = $[10];
	return t5;
}
var newHighContrastSupportedThemes = new Set([
	"light_colorblind_high_contrast",
	"light_tritanopia_high_contrast",
	"dark_colorblind_high_contrast",
	"dark_tritanopia_high_contrast",
	"dark_dimmed_high_contrast"
]);
var colorModeHighContrastMappings = {
	light_colorblind_high_contrast: "light_high_contrast",
	light_tritanopia_high_contrast: "light_high_contrast",
	dark_colorblind_high_contrast: "dark_high_contrast",
	dark_tritanopia_high_contrast: "dark_high_contrast",
	dark_dimmed_high_contrast: "dark_high_contrast"
};
function getColorScheme(value) {
	if (value === void 0 || !isHighContrastTheme(value)) return value;
	return colorModeHighContrastMappings[value];
}
function isHighContrastTheme(value) {
	return newHighContrastSupportedThemes.has(value);
}
var use_color_modes_default = ssrSafeDocument ? useColorModes : getColorModesSSR;
export { use_color_modes_default as t };
