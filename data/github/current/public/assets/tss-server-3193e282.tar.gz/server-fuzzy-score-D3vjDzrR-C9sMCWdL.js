import { r as score } from "./server-fzy.js-7qhjn37q.js";
var DIRECT_MATCH = Infinity;
var NO_MATCH = -Infinity;
var fuzzyScore = (searchQuery, text, bonusForStartOrEndMatch = 1) => {
	const safeSearchQuery = searchQuery.trim().toLowerCase();
	const safeText = text.trim().toLowerCase();
	if (safeSearchQuery === safeText) return DIRECT_MATCH;
	if (safeText.length === 0 || safeSearchQuery.length === 0) return NO_MATCH;
	const fzyScore = score(safeSearchQuery, safeText);
	if (fzyScore === Infinity && safeSearchQuery !== safeText) return NO_MATCH;
	if (safeText.startsWith(safeSearchQuery) || safeText.endsWith(safeSearchQuery)) return fzyScore + bonusForStartOrEndMatch;
	else return fzyScore;
};
export { NO_MATCH as n, fuzzyScore as r, DIRECT_MATCH as t };
