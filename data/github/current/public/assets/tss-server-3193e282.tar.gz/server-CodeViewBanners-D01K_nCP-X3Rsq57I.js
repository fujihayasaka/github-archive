import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Dt as FileIcon, Mi as XIcon, O as CheckIcon, an as IconButton, bn as Link, cn as InfoIcon, o as AlertIcon, p as ArrowUpIcon, vn as LawIcon, wn as ListUnorderedIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as Breadcrumbs_default } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { Pt as repositoryPath, a as blobPath, ct as ownerPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { i as VerifiedHTMLText, n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { o as useCurrentUser } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { t as ReposHeaderRefSelector } from "./server-ReposHeaderRefSelector-D_1tuOMj-sntynq8H.js";
import { s as isTreePayload } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { t as BetaLabel } from "./server-BetaLabel-D0vwDZNc-CsXfuTFf.js";
import { n as CodeownersValidationBanner } from "./server-HiddenUnicodeCharacter-CZpsU1rI-DzV8Hc4a.js";
import { M as forceAnnouncementToScreenReaders, X as useCurrentBlame, Z as useCurrentBlob, o as CurrentBlameProvider, rt as useDeferredMetadata, s as CurrentBlobProvider } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { i as useCodeViewBanners } from "./server-CodeViewBannersContext-CEdzkK6e-znl4nx1w.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { l as isBlobPayload, o as ReposHeaderBreadcrumb } from "./server-NavigationMenu-CKgcoy5c-Bbjbrr6N.js";
import { i as PublishBanners, s as SpoofedCommitWarning, t as CurrentTreeProvider, u as useCurrentTree } from "./server-PublishBanners-D6t9Jc-5-BK-GhWxy.js";
import React, { useCallback } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
/**
* Helper function for exhaustive checks of discriminated unions.
*
* @example
* ```
*    type A = {type: 'a'};
*    type B = {type: 'b'};
*    type Union = A | B;
*
*    function doSomething(arg: Union) {
*      if (arg.type === 'a') {
*        return something;
*      }
*
*      if (arg.type === 'b') {
*        return somethingElse;
*      }
*
*      // TS will error if there are other types in the union
*      // Will throw an Error when called at runtime.
*      return assertNever(arg);
*    }
* ```
*/
function assertNever(x) {
	throw new Error(`Unexpected object: ${x}`);
}
var BlameBanners_module_default = {
	Box: "BlameBanners-module_rqeLka_Box",
	Flash: "BlameBanners-module_rqeLka_Flash"
};
function BlameBannersLegacy({ payload }) {
	return /* @__PURE__ */ jsx(CurrentBlameProvider, {
		blame: "blame" in payload ? payload.blame : void 0,
		children: /* @__PURE__ */ jsx(BlameBanners, {})
	});
}
BlameBannersLegacy.displayName = "BlameBannersLegacy";
function BlameBanners() {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(BlameErrorBanner, {}), /* @__PURE__ */ jsx(IgnoreRevsBanner, {})] });
}
BlameBanners.displayName = "BlameBanners";
function BlameErrorBanner() {
	const $ = c(8);
	const repo = useCurrentRepository();
	const refName = useRefInfo().name;
	const blame = useCurrentBlame();
	const [shouldDisplay, setShouldDisplay] = React.useState(true);
	if (!blame) return null;
	const ignoreRefsInfo = blame?.ignoreRevs;
	const blameErrorType = blame?.errorType;
	if (!blameErrorType) return null;
	let t0;
	if ($[0] !== ignoreRefsInfo || $[1] !== refName || $[2] !== repo) {
		t0 = () => jsx(Link$1, {
			to: blobPath({
				repo: repo.name,
				owner: repo.ownerLogin,
				commitish: refName,
				filePath: ignoreRefsInfo.path
			}),
			children: ignoreRefsInfo.path
		});
		$[0] = ignoreRefsInfo;
		$[1] = refName;
		$[2] = repo;
		$[3] = t0;
	} else t0 = $[3];
	const renderIgnoreRefsLink = t0;
	let t1;
	if ($[4] !== blameErrorType || $[5] !== renderIgnoreRefsLink || $[6] !== shouldDisplay) {
		t1 = jsx(Fragment$1, { children: shouldDisplay && jsxs(Flash, {
			variant: "warning",
			className: BlameBanners_module_default.Flash,
			children: [
				jsx(Octicon, { icon: InfoIcon }),
				jsx(BlameErrorText, {
					blameErrorType,
					renderIgnoreRefsLink
				}),
				jsx("div", {
					onClick: () => setShouldDisplay(false),
					className: BlameBanners_module_default.Box,
					children: jsx(Octicon, { icon: XIcon })
				})
			]
		}) });
		$[4] = blameErrorType;
		$[5] = renderIgnoreRefsLink;
		$[6] = shouldDisplay;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
}
BlameErrorBanner.displayName = "BlameErrorBanner";
function BlameErrorText({ blameErrorType, renderIgnoreRefsLink }) {
	switch (blameErrorType) {
		case "invalid_ignore_revs": return /* @__PURE__ */ jsxs("span", { children: [
			"Your ",
			renderIgnoreRefsLink(),
			" file is invalid."
		] });
		case "ignore_revs_too_big": return /* @__PURE__ */ jsxs("span", { children: [
			"Your ",
			renderIgnoreRefsLink(),
			" file is too large."
		] });
		case "symlink_disallowed": return /* @__PURE__ */ jsx("span", { children: "Symlinks are not supported." });
		case "blame_timeout": return /* @__PURE__ */ jsx("span", { children: "Your blame took too long to compute." });
		default: assertNever(blameErrorType);
	}
}
BlameErrorText.displayName = "BlameErrorText";
function IgnoreRevsBanner() {
	const $ = c(7);
	const repo = useCurrentRepository();
	const refName = useRefInfo().name;
	const ignoreRefsInfo = useCurrentBlame()?.ignoreRevs;
	const [shouldDisplay, setShouldDisplay] = React.useState(true);
	if (!ignoreRefsInfo?.present) return null;
	let t0;
	if ($[0] !== ignoreRefsInfo.path || $[1] !== ignoreRefsInfo.timedOut || $[2] !== refName || $[3] !== repo.name || $[4] !== repo.ownerLogin || $[5] !== shouldDisplay) {
		const ignoreRefsLink = jsx(Link$1, {
			to: blobPath({
				repo: repo.name,
				owner: repo.ownerLogin,
				commitish: refName,
				filePath: ignoreRefsInfo.path
			}),
			children: ignoreRefsInfo.path
		});
		t0 = jsx(Fragment$1, { children: shouldDisplay && jsxs(Flash, {
			className: BlameBanners_module_default.Flash,
			children: [
				jsx(Octicon, { icon: InfoIcon }),
				ignoreRefsInfo.timedOut ? jsxs("span", { children: [
					"Failed to ignore revisions in ",
					ignoreRefsLink,
					"."
				] }) : jsxs("span", { children: [
					"Ignoring revisions in ",
					ignoreRefsLink,
					"."
				] }),
				jsx("div", {
					onClick: () => setShouldDisplay(false),
					className: BlameBanners_module_default.Box,
					children: jsx(Octicon, { icon: XIcon })
				})
			]
		}) });
		$[0] = ignoreRefsInfo.path;
		$[1] = ignoreRefsInfo.timedOut;
		$[2] = refName;
		$[3] = repo.name;
		$[4] = repo.ownerLogin;
		$[5] = shouldDisplay;
		$[6] = t0;
	} else t0 = $[6];
	return t0;
}
IgnoreRevsBanner.displayName = "IgnoreRevsBanner";
function useStickyHeaderStyle() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			top: "0px",
			zIndex: 4,
			background: "var(--bgColor-default, var(--color-canvas-default))",
			position: "sticky"
		};
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
var FileNameStickyHeader_module_default = {
	Box_1: "FileNameStickyHeader-module_zoMkrW_Box_1",
	Box_2: "FileNameStickyHeader-module_zoMkrW_Box_2",
	Box_3: "FileNameStickyHeader-module_zoMkrW_Box_3",
	Box_4: "FileNameStickyHeader-module_zoMkrW_Box_4",
	Box_5: "FileNameStickyHeader-module_zoMkrW_Box_5",
	Button: "FileNameStickyHeader-module_zoMkrW_Button",
	GoToTopButton: "FileNameStickyHeader-module_zoMkrW_GoToTopButton",
	outerWrapper: "FileNameStickyHeader-module_zoMkrW_outerWrapper",
	outerWrapperHidden: "FileNameStickyHeader-module_zoMkrW_outerWrapperHidden",
	outerWrapperStickied: "FileNameStickyHeader-module_zoMkrW_outerWrapperStickied",
	outerWrapperVisible: "FileNameStickyHeader-module_zoMkrW_outerWrapperVisible"
};
var StickyReposHeaderBreadcrumb = () => {
	return /* @__PURE__ */ jsx(ReposHeaderBreadcrumb, {
		id: "sticky-breadcrumb",
		fileNameId: "sticky-file-name-id",
		size: "md"
	});
};
StickyReposHeaderBreadcrumb.displayName = "StickyReposHeaderBreadcrumb";
var GoToTopButton = ({ className }) => {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		leadingVisual: ArrowUpIcon,
		variant: "invisible",
		size: "small",
		onClick: (event) => {
			event.preventDefault();
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		},
		className: clsx(FileNameStickyHeader_module_default.Button, className),
		children: "Top"
	});
};
GoToTopButton.displayName = "GoToTopButton";
function FileNameStickyHeader({ isStickied, showTree, treeToggleElement }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(FileNameStickyHeader_module_default.outerWrapper, isStickied ? FileNameStickyHeader_module_default.outerWrapperVisible : FileNameStickyHeader_module_default.outerWrapperHidden, isStickied && FileNameStickyHeader_module_default.outerWrapperStickied),
		children: !showTree ? /* @__PURE__ */ jsxs("div", {
			className: FileNameStickyHeader_module_default.Box_1,
			children: [/* @__PURE__ */ jsxs("div", {
				className: FileNameStickyHeader_module_default.Box_2,
				children: [
					isStickied && treeToggleElement,
					/* @__PURE__ */ jsx("div", {
						className: FileNameStickyHeader_module_default.Box_3,
						children: /* @__PURE__ */ jsx(ReposHeaderRefSelector, { buttonClassName: "ref-selector-class" })
					}),
					/* @__PURE__ */ jsx("div", {
						className: FileNameStickyHeader_module_default.Box_4,
						children: /* @__PURE__ */ jsx(StickyReposHeaderBreadcrumb, {})
					})
				]
			}), /* @__PURE__ */ jsx(GoToTopButton, { className: FileNameStickyHeader_module_default.GoToTopButton })]
		}) : /* @__PURE__ */ jsxs("div", {
			className: FileNameStickyHeader_module_default.Box_5,
			children: [/* @__PURE__ */ jsx(StickyReposHeaderBreadcrumb, {}), /* @__PURE__ */ jsx(GoToTopButton, { className: FileNameStickyHeader_module_default.GoToTopButton })]
		})
	});
}
FileNameStickyHeader.displayName = "FileNameStickyHeader";
var TableOfContents_module_default = { IconButton: "TableOfContents-module_p8qfDq_IconButton" };
function TableOfContents({ toc, openPanel, setOpenPanel, isDirectoryReadme }) {
	const ref = React.useRef(null);
	return showToc(toc) ? /* @__PURE__ */ jsx(IconButton, {
		ref,
		tooltipDirection: "n",
		className: clsx(!isDirectoryReadme && "pr-mr-2", TableOfContents_module_default.IconButton),
		icon: ListUnorderedIcon,
		variant: "invisible",
		"aria-label": "Outline",
		"aria-pressed": openPanel === "toc",
		onClick: () => {
			setOpenPanel?.(openPanel === "toc" ? void 0 : "toc", ref.current);
		},
		size: "small"
	}) : null;
}
TableOfContents.displayName = "TableOfContents";
function showToc(toc) {
	return toc && toc.length >= 2;
}
var BlobLowerBanners_module_default = { Flash: "BlobLowerBanners-module_USji8G_Flash" };
var DiscussionTemplateBanner_module_default = { Flash: "DiscussionTemplateBanner-module_QArZ1q_Flash" };
function DiscussionTemplateBanner({ errors }) {
	if (!errors || errors.length === 0) return null;
	const errorMessageLinkText = [];
	if (errors.length === 1) errorMessageLinkText.push("Learn more about this error.");
	else errors.map((error, index) => {
		errorMessageLinkText.push(`Learn more about error ${index + 1}.`);
	});
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "danger",
		className: DiscussionTemplateBanner_module_default.Flash,
		children: [/* @__PURE__ */ jsxs("p", { children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), /* @__PURE__ */ jsxs("strong", { children: [
			"There ",
			errors.length === 1 ? "is a problem" : "are some problems",
			" with this template"
		] })] }), errors.map((error, index) => {
			return /* @__PURE__ */ jsxs("p", { children: [
				/* @__PURE__ */ jsx(VerifiedHTMLText, { html: error.message }),
				". ",
				/* @__PURE__ */ jsx(Link, {
					href: error.link,
					target: "_blank",
					children: errorMessageLinkText[index]
				})
			] }, `error-${index}`);
		})]
	});
}
DiscussionTemplateBanner.displayName = "DiscussionTemplateBanner";
var IssueTemplateBanner_module_default = {
	Banner: "IssueTemplateBanner-module_AYGcnW_Banner",
	Label: "IssueTemplateBanner-module_AYGcnW_Label"
};
function IssueTemplateBanner(props) {
	const { issueTemplate, showIssueFormWarning, isValidLegacyIssueTemplate, helpUrl, isLoggedIn } = props;
	if (!isLoggedIn || !issueTemplate && !isValidLegacyIssueTemplate && !showIssueFormWarning) return null;
	const lifecycleLabelNameEnabled = isFeatureEnabled("lifecycle_label_name_updates");
	let content = null;
	let bannerType = void 0;
	let bannerTitle = "Info";
	const errorMessageLinkText = [];
	if (issueTemplate) if (issueTemplate.valid === false) {
		bannerType = "critical";
		bannerTitle = "Critical";
		if (issueTemplate.errors) if (issueTemplate.errors.length === 1) errorMessageLinkText.push("Learn more about this error.");
		else issueTemplate.errors.map((error, index) => {
			errorMessageLinkText.push(`Learn more about error ${index + 1}.`);
		});
		content = /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("p", { children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), /* @__PURE__ */ jsxs("strong", { children: [
			"There ",
			issueTemplate.errors?.length === 1 ? "is a problem" : "are some problems",
			" with this template"
		] })] }), issueTemplate.errors?.map((error, index) => {
			return /* @__PURE__ */ jsxs("p", { children: [
				/* @__PURE__ */ jsx(VerifiedHTMLText, { html: error.message }),
				". ",
				/* @__PURE__ */ jsx(Link, {
					href: error.link,
					target: "_blank",
					children: errorMessageLinkText[index]
				})
			] }, `error-${index}`);
		})] });
	} else if (issueTemplate.structured) content = /* @__PURE__ */ jsxs(Fragment$1, { children: [
		lifecycleLabelNameEnabled ? /* @__PURE__ */ jsx(BetaLabel, { className: "mr-2" }) : /* @__PURE__ */ jsx(Label, {
			variant: "success",
			className: IssueTemplateBanner_module_default.Label,
			children: "Beta"
		}),
		"This file is used as an Issue Form template.",
		" ",
		/* @__PURE__ */ jsx("a", {
			href: "https://github.com/orgs/community/discussions/categories/projects-and-issues",
			children: "Give Feedback."
		})
	] });
	else content = "This file is used as a markdown issue template.";
	else if (showIssueFormWarning) {
		content = "Issue form templates are not supported on private repositories.";
		bannerType = "warning";
		bannerTitle = "Warning";
	}
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [(issueTemplate || showIssueFormWarning) && /* @__PURE__ */ jsx(Banner, {
		title: bannerTitle,
		variant: bannerType,
		className: IssueTemplateBanner_module_default.Banner,
		children: content
	}), isValidLegacyIssueTemplate && /* @__PURE__ */ jsx(LegacyIssueTemplateBanner, { helpUrl })] });
}
IssueTemplateBanner.displayName = "IssueTemplateBanner";
function LegacyIssueTemplateBanner({ helpUrl }) {
	return /* @__PURE__ */ jsxs(Banner, {
		title: "Warning",
		variant: "warning",
		className: IssueTemplateBanner_module_default.Banner,
		children: [
			"You are using an old version of issue templates. Please update to the new issue template workflow.",
			" ",
			/* @__PURE__ */ jsx(Link, {
				href: `${helpUrl}/articles/about-issue-and-pull-request-templates`,
				target: "_blank",
				inline: true,
				children: "Learn more about issue templates."
			})
		]
	});
}
LegacyIssueTemplateBanner.displayName = "LegacyIssueTemplateBanner";
function BlobLowerBanners() {
	const $ = c(15);
	const repo = useCurrentRepository();
	const currentUser = useCurrentUser();
	const path = usePath();
	const refInfo = useRefInfo();
	const { helpUrl } = useReposAppPayload();
	const { csvError, isCodeownersFile, publishBannersInfo: t0, discussionTemplate, issueTemplate, showIssueFormWarning, isValidLegacyIssueTemplate } = useCurrentBlob();
	const { showPublishActionBanner, releasePath, dismissActionNoticePath } = t0;
	const showCodeownersValidationBanner = isCodeownersFile && repo.currentUserCanPush;
	let t1;
	if ($[0] !== csvError || $[1] !== currentUser || $[2] !== discussionTemplate || $[3] !== dismissActionNoticePath || $[4] !== helpUrl || $[5] !== isValidLegacyIssueTemplate || $[6] !== issueTemplate || $[7] !== path || $[8] !== refInfo.name || $[9] !== releasePath || $[10] !== repo || $[11] !== showCodeownersValidationBanner || $[12] !== showIssueFormWarning || $[13] !== showPublishActionBanner) {
		t1 = jsxs(Fragment$1, { children: [
			jsx(PublishBanners, {
				showPublishActionBanner,
				releasePath,
				dismissActionNoticePath
			}),
			jsx(IssueTemplateBanner, {
				issueTemplate,
				showIssueFormWarning,
				isValidLegacyIssueTemplate,
				isLoggedIn: !!currentUser,
				helpUrl
			}),
			discussionTemplate?.errors && discussionTemplate.errors.length > 0 && jsx(DiscussionTemplateBanner, { ...discussionTemplate }),
			jsx(TruncatedBanner, {}),
			jsx(CodeownersValidationBanner, {
				filePath: path,
				forceRender: showCodeownersValidationBanner,
				refName: refInfo.name,
				repo
			}),
			csvError && jsx(CSVErrorBanner, { csvError })
		] });
		$[0] = csvError;
		$[1] = currentUser;
		$[2] = discussionTemplate;
		$[3] = dismissActionNoticePath;
		$[4] = helpUrl;
		$[5] = isValidLegacyIssueTemplate;
		$[6] = issueTemplate;
		$[7] = path;
		$[8] = refInfo.name;
		$[9] = releasePath;
		$[10] = repo;
		$[11] = showCodeownersValidationBanner;
		$[12] = showIssueFormWarning;
		$[13] = showPublishActionBanner;
		$[14] = t1;
	} else t1 = $[14];
	return t1;
}
BlobLowerBanners.displayName = "BlobLowerBanners";
function TruncatedBanner() {
	const $ = c(6);
	const { truncated, large, image, renderedFileInfo, rawBlobUrl } = useCurrentBlob();
	let t0;
	if ($[0] !== image || $[1] !== large || $[2] !== rawBlobUrl || $[3] !== renderedFileInfo || $[4] !== truncated) {
		t0 = truncated && !large && !(image || renderedFileInfo) ? jsxs(Flash, {
			className: BlobLowerBanners_module_default.Flash,
			children: [
				"This file has been truncated, but you can",
				" ",
				jsx(Link, {
					inline: true,
					href: rawBlobUrl,
					children: "view the full file"
				}),
				"."
			]
		}) : null;
		$[0] = image;
		$[1] = large;
		$[2] = rawBlobUrl;
		$[3] = renderedFileInfo;
		$[4] = truncated;
		$[5] = t0;
	} else t0 = $[5];
	return t0;
}
TruncatedBanner.displayName = "TruncatedBanner";
function CSVErrorBanner({ csvError }) {
	return /* @__PURE__ */ jsx(Flash, {
		variant: "warning",
		className: BlobLowerBanners_module_default.Flash,
		children: /* @__PURE__ */ jsx(VerifiedHTMLBox, { html: csvError })
	});
}
CSVErrorBanner.displayName = "CSVErrorBanner";
var BlobLicenseBanner_module_default = {
	Box: "BlobLicenseBanner-module__BjTpq_Box",
	Box_1: "BlobLicenseBanner-module__BjTpq_Box_1",
	Box_10: "BlobLicenseBanner-module__BjTpq_Box_10",
	Box_2: "BlobLicenseBanner-module__BjTpq_Box_2",
	Box_3: "BlobLicenseBanner-module__BjTpq_Box_3",
	Box_4: "BlobLicenseBanner-module__BjTpq_Box_4",
	Box_5: "BlobLicenseBanner-module__BjTpq_Box_5",
	Box_6: "BlobLicenseBanner-module__BjTpq_Box_6",
	Box_7: "BlobLicenseBanner-module__BjTpq_Box_7",
	Box_8: "BlobLicenseBanner-module__BjTpq_Box_8",
	Box_9: "BlobLicenseBanner-module__BjTpq_Box_9",
	conditionIcon: "BlobLicenseBanner-module__BjTpq_conditionIcon",
	limitationIcon: "BlobLicenseBanner-module__BjTpq_limitationIcon",
	Octicon: "BlobLicenseBanner-module__BjTpq_Octicon",
	permissionIcon: "BlobLicenseBanner-module__BjTpq_permissionIcon",
	VerifiedHTMLBox: "BlobLicenseBanner-module__BjTpq_VerifiedHTMLBox"
};
function BlobLicenseBanner() {
	const $ = c(5);
	const { license } = useDeferredMetadata();
	const repo = useCurrentRepository();
	const { helpUrl } = useReposAppPayload();
	let t0;
	let t1;
	if ($[0] !== helpUrl || $[1] !== license || $[2] !== repo) {
		t1 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const iconMap = {
				permissions: {
					icon: CheckIcon,
					className: BlobLicenseBanner_module_default.permissionIcon
				},
				limitations: {
					icon: XIcon,
					className: BlobLicenseBanner_module_default.limitationIcon
				},
				conditions: {
					icon: InfoIcon,
					className: BlobLicenseBanner_module_default.conditionIcon
				}
			};
			if (!license) {
				t1 = null;
				break bb0;
			}
			t0 = jsxs("div", {
				className: BlobLicenseBanner_module_default.Box,
				children: [jsxs("div", {
					className: clsx("blob-license-banner-outer", BlobLicenseBanner_module_default.Box_1),
					children: [jsxs("div", {
						className: BlobLicenseBanner_module_default.Box_2,
						children: [jsxs("div", {
							className: BlobLicenseBanner_module_default.Box_3,
							children: [jsx(Octicon, {
								icon: LawIcon,
								size: 32
							}), jsxs("div", {
								className: BlobLicenseBanner_module_default.Box_4,
								children: [jsxs("div", {
									className: BlobLicenseBanner_module_default.Box_5,
									children: [
										`${repo.ownerLogin}/${repo.name} is licensed under`,
										" ",
										license.name.toLowerCase().startsWith("the ") ? "" : " the"
									]
								}), jsx("h3", { children: license.name })]
							})]
						}), jsx(VerifiedHTMLBox, {
							html: license.description,
							className: BlobLicenseBanner_module_default.VerifiedHTMLBox
						})]
					}), jsx("div", {
						className: BlobLicenseBanner_module_default.Box_6,
						children: Object.keys(license.rules).map((group, index) => jsxs("div", {
							className: BlobLicenseBanner_module_default.Box_7,
							children: [jsx("h5", {
								className: BlobLicenseBanner_module_default.Box_8,
								children: group.charAt(0).toUpperCase() + group.substring(1)
							}), license.rules[group].map((rule) => jsxs("div", {
								className: BlobLicenseBanner_module_default.Box_9,
								children: [jsx(Octicon, {
									icon: iconMap[group].icon,
									size: 13,
									className: clsx(BlobLicenseBanner_module_default.Octicon, iconMap[group].className)
								}), rule.label]
							}, rule.tag))]
						}, index))
					})]
				}), jsxs("div", {
					className: BlobLicenseBanner_module_default.Box_10,
					children: ["This is not legal advice.\xA0", jsx(Link, {
						inline: true,
						href: `${helpUrl}/articles/licensing-a-repository/#disclaimer`,
						children: "Learn more about repository licenses"
					})]
				})]
			});
		}
		$[0] = helpUrl;
		$[1] = license;
		$[2] = repo;
		$[3] = t0;
		$[4] = t1;
	} else {
		t0 = $[3];
		t1 = $[4];
	}
	if (t1 !== Symbol.for("react.early_return_sentinel")) return t1;
	return t0;
}
BlobLicenseBanner.displayName = "BlobLicenseBanner";
var InvalidCitationWarning_module_default = { Flash: "InvalidCitationWarning-module_YJL74W_Flash" };
function InvalidCitationWarning({ citationHelpUrl }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className: InvalidCitationWarning_module_default.Flash,
		children: [
			"Your ",
			/* @__PURE__ */ jsx("strong", { children: "CITATION.cff" }),
			"file cannot be parsed. Make sure the formatting is correct.",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: citationHelpUrl,
				children: "Learn more about CITATION files."
			})
		]
	});
}
InvalidCitationWarning.displayName = "InvalidCitationWarning";
var OverridingGlobalFundingFileWarning_module_default = { Flash: "OverridingGlobalFundingFileWarning-module_NpR93q_Flash" };
function OverridingGlobalFundingFileWarning({ globalPreferredFundingPath }) {
	return /* @__PURE__ */ jsxs(Flash, {
		className: OverridingGlobalFundingFileWarning_module_default.Flash,
		children: [
			"This file is overriding the organization-wide ",
			/* @__PURE__ */ jsx("code", { children: "FUNDING.yml" }),
			"file. Removing ",
			/* @__PURE__ */ jsx("code", { children: "FUNDING.yml" }),
			"in this repository will use the organization default.",
			/* @__PURE__ */ jsxs(Link, {
				inline: true,
				href: globalPreferredFundingPath ?? void 0,
				children: [" ", "View organization funding file."]
			})
		]
	});
}
OverridingGlobalFundingFileWarning.displayName = "OverridingGlobalFundingFileWarning";
function BlobMidBanners() {
	const $ = c(6);
	const { topBannersInfo: t0 } = useCurrentBlob();
	const { overridingGlobalFundingFile, globalPreferredFundingPath, showInvalidCitationWarning, citationHelpUrl } = t0;
	const { showLicenseMeta } = useDeferredMetadata();
	let t1;
	if ($[0] !== citationHelpUrl || $[1] !== globalPreferredFundingPath || $[2] !== overridingGlobalFundingFile || $[3] !== showInvalidCitationWarning || $[4] !== showLicenseMeta) {
		t1 = jsxs(Fragment$1, { children: [
			showLicenseMeta && jsx(BlobLicenseBanner, {}),
			showInvalidCitationWarning && jsx(InvalidCitationWarning, { citationHelpUrl }),
			jsx(SpoofedCommitWarning, {}),
			overridingGlobalFundingFile && jsx(OverridingGlobalFundingFileWarning, { globalPreferredFundingPath })
		] });
		$[0] = citationHelpUrl;
		$[1] = globalPreferredFundingPath;
		$[2] = overridingGlobalFundingFile;
		$[3] = showInvalidCitationWarning;
		$[4] = showLicenseMeta;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
BlobMidBanners.displayName = "BlobMidBanners";
var BlobTopBanners_module_default = { Box: "BlobTopBanners-module_huT7ZG_Box" };
var DependabotConfigurationBanner_module_default = {
	Box: "DependabotConfigurationBanner-module_Ptafma_Box",
	Box_1: "DependabotConfigurationBanner-module_Ptafma_Box_1",
	Button: "DependabotConfigurationBanner-module_Ptafma_Button",
	PointerBox: "DependabotConfigurationBanner-module_Ptafma_PointerBox",
	Text: "DependabotConfigurationBanner-module_Ptafma_Text",
	Text_1: "DependabotConfigurationBanner-module_Ptafma_Text_1"
};
function DependabotConfigurationBanner() {
	const $ = c(2);
	const { defaultBranch } = useCurrentRepository();
	const { name: currentRef } = useRefInfo();
	const { dependabotInfo: t0 } = useCurrentBlob();
	const { showConfigurationBanner } = t0;
	if (!showConfigurationBanner) return null;
	const isDefaultBranch = defaultBranch === currentRef;
	let t1;
	if ($[0] !== isDefaultBranch) {
		t1 = isDefaultBranch ? jsx(DefaultBranchDependabotConfigurationBanner, {}) : jsx(DirectionsForNonDefaultBranch, {});
		$[0] = isDefaultBranch;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
DependabotConfigurationBanner.displayName = "DependabotConfigurationBanner";
function DefaultBranchDependabotConfigurationBanner() {
	const $ = c(6);
	const { dependabotInfo: t0 } = useCurrentBlob();
	const { configFilePath, networkDependabotPath, dismissConfigurationNoticePath, configurationNoticeDismissed } = t0;
	let t1;
	if ($[0] !== dismissConfigurationNoticePath) {
		t1 = () => verifiedFetch(dismissConfigurationNoticePath, { method: "POST" });
		$[0] = dismissConfigurationNoticePath;
		$[1] = t1;
	} else t1 = $[1];
	const dismissNotice = t1;
	if (configurationNoticeDismissed) return null;
	let t2;
	if ($[2] !== configFilePath || $[3] !== dismissNotice || $[4] !== networkDependabotPath) {
		t2 = jsx("div", {
			className: DependabotConfigurationBanner_module_default.Box,
			children: jsx(Popover_default, {
				caret: "top",
				open: true,
				children: jsxs(Popover_default.Content, { children: [
					jsx("h5", {
						className: DependabotConfigurationBanner_module_default.Text,
						children: "Dependabot"
					}),
					jsx("p", {
						className: DependabotConfigurationBanner_module_default.Text_1,
						children: "Dependabot creates pull requests to keep your dependencies secure and up-to-date."
					}),
					jsxs("p", {
						className: DependabotConfigurationBanner_module_default.Text_1,
						children: [
							"You can opt out at any time by removing the ",
							jsx("code", { children: configFilePath }),
							" config file."
						]
					}),
					jsxs("div", {
						className: DependabotConfigurationBanner_module_default.Box_1,
						children: [jsx(ButtonComponent, {
							as: "a",
							href: networkDependabotPath,
							children: "View update status"
						}), jsx(ButtonComponent, {
							variant: "invisible",
							onClick: dismissNotice,
							className: DependabotConfigurationBanner_module_default.Button,
							children: "Dismiss"
						})]
					})
				] })
			})
		});
		$[2] = configFilePath;
		$[3] = dismissNotice;
		$[4] = networkDependabotPath;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
DefaultBranchDependabotConfigurationBanner.displayName = "DefaultBranchDependabotConfigurationBanner";
function DirectionsForNonDefaultBranch() {
	const $ = c(5);
	const { defaultBranch, name, ownerLogin } = useCurrentRepository();
	const path = usePath();
	let t0;
	if ($[0] !== defaultBranch || $[1] !== name || $[2] !== ownerLogin || $[3] !== path) {
		const defaultBranchPath = blobPath({
			owner: ownerLogin,
			repo: name,
			commitish: defaultBranch,
			filePath: path
		});
		t0 = jsxs(Flash, {
			variant: "warning",
			children: [jsxs("h5", { children: [jsx(AlertIcon, {}), "Cannot configure Dependabot from this branch"] }), jsxs("p", { children: [
				"To configure Dependabot, you must use",
				" ",
				jsx(Link, {
					inline: true,
					href: defaultBranchPath,
					children: "this repository's default branch"
				})
			] })]
		});
		$[0] = defaultBranch;
		$[1] = name;
		$[2] = ownerLogin;
		$[3] = path;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
DirectionsForNonDefaultBranch.displayName = "DirectionsForNonDefaultBranch";
var OrgOnboardingTip_module_default = {
	Box: "OrgOnboardingTip-module_4_dK1W_Box",
	Box_1: "OrgOnboardingTip-module_4_dK1W_Box_1",
	Box_2: "OrgOnboardingTip-module_4_dK1W_Box_2",
	Box_3: "OrgOnboardingTip-module_4_dK1W_Box_3",
	Box_4: "OrgOnboardingTip-module_4_dK1W_Box_4",
	Box_5: "OrgOnboardingTip-module_4_dK1W_Box_5",
	Box_6: "OrgOnboardingTip-module_4_dK1W_Box_6",
	Box_7: "OrgOnboardingTip-module_4_dK1W_Box_7",
	Breadcrumbs_Item: "OrgOnboardingTip-module_4_dK1W_Breadcrumbs_Item",
	Link: "OrgOnboardingTip-module_4_dK1W_Link",
	Link_1: "OrgOnboardingTip-module_4_dK1W_Link_1",
	Octicon: "OrgOnboardingTip-module_4_dK1W_Octicon",
	Text: "OrgOnboardingTip-module_4_dK1W_Text",
	Text_1: "OrgOnboardingTip-module_4_dK1W_Text_1",
	VerifiedHTMLBox: "OrgOnboardingTip-module_4_dK1W_VerifiedHTMLBox"
};
function OrgOnboardingTip({ children, mediaUrl, mediaPreviewSrc, iconSvg, taskTitle, taskPath, org }) {
	return /* @__PURE__ */ jsxs("section", {
		className: OrgOnboardingTip_module_default.Box,
		children: [/* @__PURE__ */ jsxs("div", {
			className: OrgOnboardingTip_module_default.Box_1,
			children: [/* @__PURE__ */ jsx(SuggestIcon, { iconSvg }), /* @__PURE__ */ jsxs("div", {
				className: OrgOnboardingTip_module_default.Box_2,
				children: [/* @__PURE__ */ jsxs(Breadcrumbs_default, { children: [/* @__PURE__ */ jsx(Breadcrumbs_default.Item, {
					href: ownerPath({ owner: org }),
					children: "Tasks"
				}), /* @__PURE__ */ jsx(Breadcrumbs_default.Item, {
					href: taskPath,
					className: OrgOnboardingTip_module_default.Breadcrumbs_Item,
					children: taskTitle
				})] }), children]
			})]
		}), /* @__PURE__ */ jsx(Media, {
			mediaPreviewSrc,
			mediaUrl
		})]
	});
}
OrgOnboardingTip.displayName = "OrgOnboardingTip";
function SuggestIcon({ iconSvg }) {
	return /* @__PURE__ */ jsxs("div", {
		className: OrgOnboardingTip_module_default.Box_3,
		children: [
			/* @__PURE__ */ jsx(VerifiedHTMLBox, {
				html: iconSvg,
				className: OrgOnboardingTip_module_default.VerifiedHTMLBox
			}),
			/* @__PURE__ */ jsx(Bubble, {
				size: 6,
				color: "#6c84e9",
				bottom: -7,
				left: -7
			}),
			/* @__PURE__ */ jsx(Bubble, {
				size: 4,
				color: "#9e7bff",
				top: -4,
				right: 4
			}),
			/* @__PURE__ */ jsx(Bubble, {
				size: 6,
				color: "#6c84e9",
				top: -7,
				right: -8
			})
		]
	});
}
SuggestIcon.displayName = "SuggestIcon";
function Bubble({ size, color, left, right, top, bottom }) {
	return /* @__PURE__ */ jsx("div", {
		style: {
			width: size,
			height: size,
			left: `${left}px`,
			right: `${right}px`,
			top: `${top}px`,
			bottom: `${bottom}px`,
			backgroundColor: color
		},
		className: OrgOnboardingTip_module_default.Box_4
	});
}
Bubble.displayName = "Bubble";
function Media({ mediaUrl, mediaPreviewSrc }) {
	if ((ssrSafeWindow?.innerWidth ?? 0) < ScreenSize.xlarge || !mediaUrl || !mediaPreviewSrc) return null;
	return /* @__PURE__ */ jsx("div", {
		className: clsx("org-onboarding-tip-media", OrgOnboardingTip_module_default.Box_5),
		children: /* @__PURE__ */ jsx(Link, {
			href: mediaUrl,
			className: OrgOnboardingTip_module_default.Link,
			children: /* @__PURE__ */ jsx("img", {
				src: mediaPreviewSrc,
				alt: "Guidance",
				loading: "lazy",
				style: {
					width: "50%",
					height: "50%"
				}
			})
		})
	});
}
Media.displayName = "Media";
function ActionsOnboardingPrompt({ repo, owner }) {
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
		className: OrgOnboardingTip_module_default.Text,
		children: "Auto-assign new issue with GitHub Actions"
	}), /* @__PURE__ */ jsxs("div", {
		className: OrgOnboardingTip_module_default.Box_6,
		children: [
			/* @__PURE__ */ jsxs("p", { children: [
				"The ",
				/* @__PURE__ */ jsx("span", {
					className: OrgOnboardingTip_module_default.Text_1,
					children: "auto-assign.yml"
				}),
				" file below lives inside your",
				" ",
				/* @__PURE__ */ jsx("span", {
					className: OrgOnboardingTip_module_default.Text_1,
					children: "demo-repository"
				}),
				" and defines when and how it’s automatically triggered. This",
				" ",
				/* @__PURE__ */ jsx("a", {
					href: "https://github.com/marketplace/actions/auto-assign-issues-prs",
					target: "_blank",
					rel: "noreferrer",
					children: "“Auto Assign” workflow"
				}),
				" ",
				"happens to add reviewers and assignees to issues and pull requests when they’re opened in this repository."
			] }),
			/* @__PURE__ */ jsxs("p", { children: [
				"You can see the results of this workflow in any",
				" ",
				/* @__PURE__ */ jsx("a", {
					href: repositoryPath({
						owner,
						repo,
						action: "issues"
					}),
					children: "issue"
				}),
				" or",
				" ",
				/* @__PURE__ */ jsx("a", {
					href: repositoryPath({
						owner,
						repo,
						action: "pulls"
					}),
					children: "pull request"
				}),
				" that you create in this repository, as it’ll assign them to the specified members. And you can see a log of any workflows you run in",
				" ",
				/* @__PURE__ */ jsx("a", {
					href: repositoryPath({
						owner,
						repo,
						action: "actions"
					}),
					children: "your repository’s “Actions” tab."
				})
			] }),
			/* @__PURE__ */ jsxs("div", {
				className: OrgOnboardingTip_module_default.Box_7,
				children: [/* @__PURE__ */ jsx(LinkButton, {
					variant: "primary",
					href: repositoryPath({
						owner,
						repo,
						action: "issues/new"
					}),
					className: LinkButton_module_default.linkButton,
					children: "Create new issue to see results"
				}), /* @__PURE__ */ jsxs(Link, {
					href: "https://docs.github.com/actions",
					target: "_blank",
					className: OrgOnboardingTip_module_default.Link_1,
					children: [/* @__PURE__ */ jsx(Octicon, {
						icon: FileIcon,
						className: OrgOnboardingTip_module_default.Octicon
					}), "Learn how automation works on GitHub"]
				})]
			})
		]
	})] });
}
ActionsOnboardingPrompt.displayName = "ActionsOnboardingPrompt";
var PlanSupportBanner_module_default = {
	Box: "PlanSupportBanner-module_YRhwya_Box",
	Flash: "PlanSupportBanner-module_YRhwya_Flash",
	Text: "PlanSupportBanner-module_YRhwya_Text"
};
function PlanSupportBanner({ feature, featureName, repoIsFork, repoOwnedByCurrentUser, requestFullPath, showFreeOrgGatedFeatureMessage, showPlanSupportBanner, upgradeDataAttributes, upgradePath }) {
	const dataAttributes = {};
	if (upgradeDataAttributes) for (const key in upgradeDataAttributes) dataAttributes[`data-${key}`] = upgradeDataAttributes[key];
	return showPlanSupportBanner ? /* @__PURE__ */ jsx(Flash, {
		variant: "warning",
		className: PlanSupportBanner_module_default.Flash,
		children: repoOwnedByCurrentUser ? repoIsFork ? `This repository is a fork, and inherits the features of the parent repository. Contact the owner of the root repository to enable ${featureName || "this feature"}` : /* @__PURE__ */ jsxs("div", {
			className: PlanSupportBanner_module_default.Box,
			children: [/* @__PURE__ */ jsx("span", {
				className: PlanSupportBanner_module_default.Text,
				children: `Upgrade to GitHub Pro or make this repository public to enable ${featureName || "this feature"}.`
			}), /* @__PURE__ */ jsx(UpgradeButton, {
				dataAttributes,
				individual: true,
				requestFullPath,
				feature,
				upgradePath
			})]
		}) : showFreeOrgGatedFeatureMessage ? /* @__PURE__ */ jsxs("div", {
			className: PlanSupportBanner_module_default.Box,
			children: [/* @__PURE__ */ jsx("span", {
				className: PlanSupportBanner_module_default.Text,
				children: `Upgrade to GitHub Team or make this repository public to enable ${featureName || "this feature"}.`
			}), /* @__PURE__ */ jsx(UpgradeButton, {
				dataAttributes,
				individual: false,
				requestFullPath,
				feature,
				upgradePath
			})]
		}) : `Contact the owner of the repository to enable ${featureName || "this feature"}.`
	}) : null;
}
PlanSupportBanner.displayName = "PlanSupportBanner";
function UpgradeButton({ dataAttributes, individual, requestFullPath, feature, upgradePath }) {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		...dataAttributes,
		"data-ga-click": `Change ${individual ? "individual" : "organization"}, click to upgrade, ref_page:${requestFullPath};ref_cta:Upgrade now;ref_loc:${feature};location:${feature};text:Upgrade now`,
		onClick: () => {
			location.href = upgradePath;
		},
		children: "Upgrade now"
	});
}
UpgradeButton.displayName = "UpgradeButton";
function BlobTopBanners() {
	const $ = c(4);
	const { planSupportInfo, topBannersInfo } = useCurrentBlob();
	const { actionsOnboardingTip } = topBannersInfo;
	const repo = useCurrentRepository();
	let t0;
	if ($[0] !== actionsOnboardingTip || $[1] !== planSupportInfo || $[2] !== repo) {
		t0 = jsxs("div", {
			className: BlobTopBanners_module_default.Box,
			children: [
				jsx(PlanSupportBanner, {
					...planSupportInfo,
					feature: "codeowners",
					featureName: "CODEOWNERS"
				}),
				jsx(DependabotConfigurationBanner, {}),
				actionsOnboardingTip && jsx(OrgOnboardingTip, {
					iconSvg: actionsOnboardingTip.iconSvg,
					mediaPreviewSrc: actionsOnboardingTip.mediaPreviewSrc,
					mediaUrl: actionsOnboardingTip.mediaUrl,
					taskTitle: actionsOnboardingTip.taskTitle,
					taskPath: actionsOnboardingTip.taskPath,
					org: actionsOnboardingTip.orgName,
					children: jsx(ActionsOnboardingPrompt, {
						owner: repo.ownerLogin,
						repo: repo.name
					})
				})
			]
		});
		$[0] = actionsOnboardingTip;
		$[1] = planSupportInfo;
		$[2] = repo;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
BlobTopBanners.displayName = "BlobTopBanners";
function CodeViewBanners({ payload }) {
	if (isTreePayload(payload)) return /* @__PURE__ */ jsx(TreeBannersLegacy, { tree: payload.tree });
	else if (isBlobPayload(payload)) return /* @__PURE__ */ jsx(BlobBannersLegacy, {
		blob: payload.blob,
		payload
	});
	return null;
}
CodeViewBanners.displayName = "CodeViewBanners";
function TreeBannersLegacy({ tree }) {
	return /* @__PURE__ */ jsx(CurrentTreeProvider, {
		payload: tree,
		children: /* @__PURE__ */ jsx(TreeBanners, {})
	});
}
TreeBannersLegacy.displayName = "TreeBannersLegacy";
function TreeBanners() {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(SpoofedCommitWarning, {}),
		/* @__PURE__ */ jsx(TruncatedTreeBanner, {}),
		/* @__PURE__ */ jsx(CodeViewContextBanners, {})
	] });
}
TreeBanners.displayName = "TreeBanners";
function BlobBannersLegacy({ blob, payload }) {
	return /* @__PURE__ */ jsxs(CurrentBlobProvider, {
		blob,
		children: [/* @__PURE__ */ jsx(BlobBanners, {}), /* @__PURE__ */ jsx(BlameBannersLegacy, { payload })]
	});
}
BlobBannersLegacy.displayName = "BlobBannersLegacy";
function BlobBanners() {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(BlobTopBanners, {}),
		/* @__PURE__ */ jsx(BlobMidBanners, {}),
		/* @__PURE__ */ jsx(BlobLowerBanners, {}),
		/* @__PURE__ */ jsx(CodeViewContextBanners, {})
	] });
}
BlobBanners.displayName = "BlobBanners";
function TruncatedTreeBanner() {
	const $ = c(3);
	const { items, totalCount } = useCurrentTree();
	const omittedCount = totalCount - items.length;
	let t0;
	if ($[0] !== items.length || $[1] !== omittedCount) {
		t0 = omittedCount > 0 ? jsxs(Flash, {
			variant: "warning",
			"data-testid": "repo-truncation-warning",
			className: "pr-mt-3",
			children: [
				"Sorry, we had to truncate this directory to ",
				items.length.toLocaleString(),
				" files. ",
				omittedCount.toLocaleString(),
				" ",
				omittedCount === 1 ? "entry was" : "entries were",
				" omitted from the list. Latest commit info may be omitted."
			]
		}) : null;
		$[0] = items.length;
		$[1] = omittedCount;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
TruncatedTreeBanner.displayName = "TruncatedTreeBanner";
function CodeViewContextBanners() {
	const $ = c(2);
	const banners = useCodeViewBanners();
	let messageToAnnounce = "";
	for (const b of banners) messageToAnnounce = messageToAnnounce + b.message;
	forceAnnouncementToScreenReaders(messageToAnnounce);
	let t0;
	if ($[0] !== banners) {
		t0 = jsx(Fragment$1, { children: banners.map(_temp) });
		$[0] = banners;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
CodeViewContextBanners.displayName = "CodeViewContextBanners";
function _temp(b_0, i) {
	return jsx(Flash, {
		variant: b_0.variant,
		className: "pr-mt-3",
		children: b_0.message
	}, i);
}
export { TreeBanners as a, TableOfContents as i, BlobBanners as n, assertNever as o, FileNameStickyHeader as r, useStickyHeaderStyle as s, BlameBanners as t };
