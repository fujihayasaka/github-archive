import { i as ssrSafeLocation, n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { o as useId$1, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, n as AriaStatus } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ai as XCircleFillIcon, At as FileSubmoduleIcon, Bi as useFocusZone, Bn as NodeIcon, Ct as FileDiffIcon, Dt as FileIcon, F as ChevronDownIcon, G as CodeSquareIcon, Gi as useSlots, Gr as SquareFillIcon, H as CodeIcon, Hi as useProvidedRefOrCreate, Hn as NoteIcon, Ir as SkipIcon, It as FoldDownIcon, Jn as PaperAirplaneIcon, Jt as GitPullRequestIcon, Kt as GitPullRequestClosedIcon, L as ChevronRightIcon, Li as invariant, Mi as XIcon, On as MarkdownIcon, Pt as FilterRemoveIcon, Qt as Heading$2, Ri as isSlot, Rt as FoldUpIcon, Sn as LinkIcon, St as FileCodeIcon, Ut as GitCommitIcon, Vr as SpaceIcon, Wi as useSafeTimeout, Wt as GitMergeIcon, X as CommentDiscussionIcon, Xr as StarFillIcon, Yt as GlobeIcon, Z as CommentIcon, Zn as PencilIcon, _i as Truncate, _n as KebabHorizontalIcon, _r as RepoLockedIcon, a as AlertFillIcon, an as IconButton, ar as PlusIcon, bn as Link, d as ArrowRightIcon, dn as IssueDraftIcon, dt as DiscussionClosedIcon, fn as IssueOpenedIcon, gr as RepoIcon, hi as TriangleDownIcon, kr as ShieldLockIcon, mi as TrashIcon, mr as RepoCloneIcon, n as ActionList, o as AlertIcon, oi as TelescopeIcon, qr as Stack, qt as GitPullRequestDraftIcon, r as ActionListContainerContext, rr as PlayIcon, s as AppsIcon, u as ArrowLeftIcon, un as IssueClosedIcon, vt as EyeClosedIcon, wi as UploadIcon, wr as SearchIcon, wt as FileDirectoryFillIcon, xn as LinkExternalIcon, xr as RocketIcon, yt as EyeIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { a as useAnchoredPosition, i as heightMap, n as BaseOverlay, t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { S as useSearchParams, g as useLocation$1, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel$1, c as useFormControlForwardedProps, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { n as InputLabel, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { n as useConfirm } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as BranchName_default } from "./server-BranchName-HKnig0CO-C3hpegKL.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { n as TreeView } from "./server-TreeView-BeVCvZ0v-BAEuIsb-.js";
import { n as useCurrentRepository, t as CurrentRepositoryProvider } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery, s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { h as codeNavSearchPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { K as makePlaceholderReference, M as getRenderableReferences, Q as referenceName, R as isCopilotSpaceReference, U as makeFileReference, W as makeFolderReference, Z as referenceID, b as copilotFeatureFlags, et as referenceURL, m as ModeSupportName, n as COPILOT_PATH, nt as renderableReferenceTypes, q as makeRepositoryReference, tt as referencesAreEqual, w as findAgentCorrespondents } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { n as positions } from "./server-fzy.js-7qhjn37q.js";
import { a as useTreeList, i as useFileQueryContext, n as WebWorker, r as findFileWorkerJob, t as FileQueryProvider } from "./server-find-file-BEBNNIhZ-BiOBklr2.js";
import { n as usePath, t as PathProvider } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { t as RefInfoProvider } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { c as useUrlCreator, n as AllShortcutsEnabled, r as AllShortcutsEnabledProvider, s as useReposAnalytics, t as ActionProvider } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as getScrollableParent } from "./server-get-scrollable-parent-CYFmVGg0-DxdSiurz.js";
import { t as PortalTooltip } from "./server-PortalTooltip-DECeLuvi-BZbUqJOn.js";
import { t as useFileTreeTooltip } from "./server-use-file-tree-tooltip-DhTyi11E-CX1wlHJi.js";
import { t as CopilotSettingsProvider } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { t as EditPermissionsProvider } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { i as useScreenSize, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { r as languageMap, t as docLanguages } from "./server-language-info-CBuUUErk-BvCk1GBy.js";
import { a as getCopilotSpacePath, l as useRouteSpaceId, n as customCopilotApiPath, r as customCopilotIdsAreEqual, s as useIsCopilotSpacePath, t as SLUG_ERROR_MESSAGE } from "./server-custom-copilots-helpers-DK-3dkih-DB1BoMiI.js";
import { C as useChatStateValues, D as useGetChatState, O as usePlugins, S as useChatStateValue, T as useDefaultModel, b as useChatState, d as copilotChatTextAreaId, f as copilotSpaceIdFromThread, o as UploadableFileAttachment, w as useCopilotSpaceSelection, x as useChatStateLens, y as useChatManager } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { n as CommandButton, o as ScopedCommands, r as CommandIconButton } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { n as useSyntheticChange, t as InlineAutocomplete } from "./server-InlineAutocomplete-ByKImo4X-BNUEsRr4.js";
import { t as ReposSelector } from "./server-ReposSelector-DzGKvaFx-Dm7ShIoG.js";
import { S as useLastSelectedAgent, T as useOverlayDirection, _ as TopicPickerPortalContainer, g as TaskChatInputToolbar, i as COPILOT_CHAT_MENU_PORTAL_ROOT, p as ModelPicker, s as DecoupledModeBanner } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { c as resourceMetadataToRailsPayload, i as SpacesOwnerDropdown, n as COPILOT_SPACES_QUERY_KEY, o as copilotSpacesQueryKey, r as SpaceDialogFooter, s as fetchCopilotSpace } from "./server-SpacesOwnerDropdown-CTkfR2yL-BX_FStD5.js";
import { n as fuzzyScore } from "./server-fuzzy-filter-DktYDqCY-DJk6_pK9.js";
import { t as LoopsIcon } from "./server-CustomIcon-CTl7CX1Z-5XxrNXUA.js";
import React, { memo, useCallback, useDeferredValue, useEffect, useEffectEvent, useId, useImperativeHandle, useLayoutEffect, useMemo, useReducer, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys, scrollIntoView } from "@primer/behaviors";
import { flushSync } from "react-dom";
import { c } from "react/compiler-runtime";
import { visit } from "unist-util-visit";
import { unified } from "unified";
import throttle$1 from "lodash-es/throttle.js";
var classes = {
	"Overlay": "prc-SelectPanel2-Overlay--Q-FI",
	"Form": "prc-SelectPanel2-Form-bZ9HS",
	"Container": "prc-SelectPanel2-Container-e5e6-",
	"HeaderContent": "prc-SelectPanel2-HeaderContent-MsaAS",
	"TitleWrapper": "prc-SelectPanel2-TitleWrapper-HzPu3",
	"TextInput": "prc-SelectPanel2-TextInput-lHH1n",
	"Checkbox": "prc-SelectPanel2-Checkbox-AYR38",
	"FlexBox": "prc-SelectPanel2-FlexBox-gWPRg",
	"Title": "prc-SelectPanel2-Title-T-h3f",
	"Description": "prc-SelectPanel2-Description-qTXfi",
	"ClearAction": "prc-SelectPanel2-ClearAction-tQj-f",
	"Footer": "prc-SelectPanel2-Footer-TibV0",
	"FooterContent": "prc-SelectPanel2-FooterContent-UjAOM",
	"FooterActions": "prc-SelectPanel2-FooterActions-T6yQR",
	"SecondaryCheckbox": "prc-SelectPanel2-SecondaryCheckbox-omkf-",
	"SmallText": "prc-SelectPanel2-SmallText-c42ay",
	"SelectPanelLoading": "prc-SelectPanel2-SelectPanelLoading-mtyhD",
	"LoadingText": "prc-SelectPanel2-LoadingText-DB0wN",
	"MessageFull": "prc-SelectPanel2-MessageFull-nY-qF",
	"Octicon": "prc-SelectPanel2-Octicon-zt-zU",
	"Error": "prc-SelectPanel2-Error-ZrZQQ",
	"Warning": "prc-SelectPanel2-Warning-PDsVF",
	"MessageTitle": "prc-SelectPanel2-MessageTitle-T7v9d",
	"MessageContent": "prc-SelectPanel2-MessageContent-UZ9vY",
	"MessageInline": "prc-SelectPanel2-MessageInline-sErQf",
	"Header": "prc-SelectPanel2-Header-LKyEJ"
};
var SelectPanelContext = /* @__PURE__ */ React.createContext({
	title: "",
	description: void 0,
	panelId: "",
	onCancel: () => {},
	onClearSelection: void 0,
	searchQuery: "",
	setSearchQuery: () => {},
	selectionVariant: "multiple",
	moveFocusToList: () => {}
});
var responsiveButtonSizes = {
	narrow: "medium",
	regular: "small"
};
var Panel = ({ title, description, variant: propsVariant, selectionVariant = "multiple", id, defaultOpen = false, open: propsOpen, anchorRef: providedAnchorRef, anchoredPositionSettings, onCancel: propsOnCancel, onClearSelection: propsOnClearSelection, onSubmit: propsOnSubmit, width = "medium", maxHeight = "large", className, ...props }) => {
	var _position$top, _position$left, _slots$header;
	const [internalOpen, setInternalOpen] = React.useState(defaultOpen);
	const currentVariant = useResponsiveValue(Object.assign({
		regular: "anchored",
		narrow: "full-screen"
	}, typeof propsVariant === "string" ? { regular: propsVariant } : propsVariant), "anchored");
	if (propsOpen !== void 0 && internalOpen !== propsOpen) setInternalOpen(propsOpen);
	let Anchor;
	const anchorRef = useProvidedRefOrCreate(providedAnchorRef);
	const onAnchorClick = () => {
		if (!internalOpen) setInternalOpen(true);
		else onInternalCancel();
	};
	const contents = React.Children.map(props.children, (child) => {
		if (/* @__PURE__ */ React.isValidElement(child) && (child.type === SelectPanelButton || isSlot(child, SelectPanelButton))) {
			Anchor = /* @__PURE__ */ React.cloneElement(child, {
				ref: anchorRef,
				onClick: child.props.onClick || onAnchorClick,
				"aria-haspopup": true,
				"aria-expanded": internalOpen
			});
			return null;
		}
		return child;
	});
	const onInternalClose = React.useCallback(() => {
		if (internalOpen === false) return;
		if (propsOpen === void 0) setInternalOpen(false);
	}, [internalOpen, propsOpen]);
	const onInternalCancel = React.useCallback(() => {
		onInternalClose();
		if (typeof propsOnCancel === "function") propsOnCancel();
	}, [onInternalClose, propsOnCancel]);
	const onInternalSubmit = (event) => {
		event === null || event === void 0 || event.preventDefault();
		onInternalClose();
		if (typeof propsOnSubmit === "function") propsOnSubmit(event);
	};
	const onInternalClearSelection = () => {
		if (typeof propsOnClearSelection === "function") propsOnClearSelection();
	};
	const internalAfterSelect = (event) => {
		if (selectionVariant === "instant") onInternalSubmit();
		if (event.type === "keypress") {
			if (event.key === "Enter") onInternalSubmit();
		}
	};
	const [searchQuery, setSearchQuery] = React.useState("");
	const panelId = useId$1(id);
	const [slots, childrenInBody] = useSlots(contents, {
		header: SelectPanelHeader,
		footer: SelectPanelFooter
	});
	const moveFocusToList = () => {
		var _dialogRef$current;
		const firstListElement = (_dialogRef$current = dialogRef.current) === null || _dialogRef$current === void 0 ? void 0 : _dialogRef$current.querySelector("ul[role=listbox] li:not([role=none])");
		firstListElement === null || firstListElement === void 0 || firstListElement.focus();
	};
	const dialogRef = React.useRef(null);
	React.useEffect(() => {
		var _dialogRef$current2, _dialogRef$current3;
		if (internalOpen) (_dialogRef$current2 = dialogRef.current) === null || _dialogRef$current2 === void 0 || _dialogRef$current2.showModal();
		else if ((_dialogRef$current3 = dialogRef.current) !== null && _dialogRef$current3 !== void 0 && _dialogRef$current3.open) dialogRef.current.close();
	}, [internalOpen]);
	React.useEffect(() => {
		const dialogEl = dialogRef.current;
		dialogEl === null || dialogEl === void 0 || dialogEl.addEventListener("close", onInternalClose);
		return () => dialogEl === null || dialogEl === void 0 ? void 0 : dialogEl.removeEventListener("close", onInternalClose);
	}, [onInternalClose]);
	React.useEffect(() => {
		const dialogEl = dialogRef.current;
		const handler = (event) => {
			if (event.key === "Escape") onInternalCancel();
		};
		dialogEl === null || dialogEl === void 0 || dialogEl.addEventListener("keydown", handler);
		return () => dialogEl === null || dialogEl === void 0 ? void 0 : dialogEl.removeEventListener("keydown", handler);
	}, [onInternalCancel]);
	React.useEffect(function initialFocus() {
		if (internalOpen) {
			const searchInput = document.querySelector("dialog[open] input");
			if (searchInput) searchInput.focus();
			else moveFocusToList();
		}
	}, [internalOpen]);
	const { position } = useAnchoredPosition({
		anchorElementRef: anchorRef,
		floatingElementRef: dialogRef,
		side: "outside-bottom",
		align: "start",
		...anchoredPositionSettings
	}, [
		internalOpen,
		anchorRef.current,
		dialogRef.current
	]);
	const onClickOutside = onInternalCancel;
	let maxHeightValue = heightMap[maxHeight];
	if (currentVariant === "bottom-sheet") maxHeightValue = "calc(100vh - 64px)";
	else if (currentVariant === "full-screen") maxHeightValue = "100vh";
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [Anchor, /* @__PURE__ */ jsx(BaseOverlay, {
		as: "dialog",
		ref: dialogRef,
		"aria-labelledby": `${panelId}--title`,
		"aria-describedby": description ? `${panelId}--description` : void 0,
		width,
		height: "fit-content",
		maxHeight,
		"data-variant": currentVariant,
		style: {
			"--max-height": maxHeightValue,
			"--position-top": `${(_position$top = position === null || position === void 0 ? void 0 : position.top) !== null && _position$top !== void 0 ? _position$top : 0}px`,
			"--position-left": `${(_position$left = position === null || position === void 0 ? void 0 : position.left) !== null && _position$left !== void 0 ? _position$left : 0}px`,
			visibility: internalOpen ? "visible" : "hidden",
			display: "flex"
		},
		className: clsx(classes.Overlay, className),
		...props,
		onClick: (event) => {
			if (event.target === event.currentTarget) onClickOutside();
		},
		children: internalOpen && /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(SelectPanelContext.Provider, {
			value: {
				panelId,
				title,
				description,
				onCancel: onInternalCancel,
				onClearSelection: propsOnClearSelection ? onInternalClearSelection : void 0,
				searchQuery,
				setSearchQuery,
				selectionVariant,
				moveFocusToList
			},
			children: /* @__PURE__ */ jsxs("form", {
				method: "dialog",
				onSubmit: onInternalSubmit,
				className: classes.Form,
				children: [
					(_slots$header = slots.header) !== null && _slots$header !== void 0 ? _slots$header : /* @__PURE__ */ jsx(SelectPanelHeader, {}),
					/* @__PURE__ */ jsx("div", {
						className: classes.Container,
						children: /* @__PURE__ */ jsx(ActionListContainerContext.Provider, {
							value: {
								container: "SelectPanel",
								listRole: "listbox",
								selectionAttribute: "aria-selected",
								selectionVariant: selectionVariant === "instant" ? "single" : selectionVariant,
								afterSelect: internalAfterSelect,
								listLabelledBy: `${panelId}--title`,
								enableFocusZone: true
							},
							children: childrenInBody
						})
					}),
					slots.footer
				]
			})
		}) })
	})] });
};
var SelectPanelButton = /* @__PURE__ */ React.forwardRef((props, anchorRef) => {
	const inputProps = useFormControlForwardedProps(props);
	const [labelText, setLabelText] = useState("");
	useEffect(() => {
		const label = document.querySelector(`[for='${inputProps.id}']`);
		if (label !== null && label !== void 0 && label.textContent) setLabelText(label.textContent);
	}, [inputProps.id]);
	if (labelText) return /* @__PURE__ */ jsx(ButtonComponent, {
		ref: anchorRef,
		"aria-label": `${anchorRef.current.textContent}, ${labelText}`,
		...inputProps
	});
	else return /* @__PURE__ */ jsx(ButtonComponent, {
		ref: anchorRef,
		...props
	});
});
SelectPanelButton.__SLOT__ = Symbol("SelectPanel.Button");
var SelectPanelHeader = ({ children, onBack, className, ...props }) => {
	const [slots, childrenWithoutSlots] = useSlots(children, { searchInput: SelectPanelSearchInput });
	const { title, description, panelId, onCancel, onClearSelection } = React.useContext(SelectPanelContext);
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(classes.Header, className),
		...props,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: classes.HeaderContent,
				"data-description": description ? true : void 0,
				"data-search-input": slots.searchInput ? true : void 0,
				children: [/* @__PURE__ */ jsxs("div", {
					className: classes.FlexBox,
					children: [onBack ? /* @__PURE__ */ jsx(IconButton, {
						type: "button",
						variant: "invisible",
						icon: ArrowLeftIcon,
						"aria-label": "Back",
						onClick: () => onBack()
					}) : null, /* @__PURE__ */ jsxs("div", {
						className: classes.TitleWrapper,
						"data-description": description ? true : void 0,
						"data-on-back": onBack ? true : void 0,
						children: [/* @__PURE__ */ jsx(Heading$2, {
							as: "h1",
							id: `${panelId}--title`,
							className: classes.Title,
							children: title
						}), description ? /* @__PURE__ */ jsx("span", {
							id: `${panelId}--description`,
							className: classes.Description,
							children: description
						}) : null]
					})]
				}), /* @__PURE__ */ jsxs("div", { children: [onClearSelection ? /* @__PURE__ */ jsx(IconButton, {
					type: "button",
					variant: "invisible",
					icon: FilterRemoveIcon,
					"aria-label": "Clear selection",
					onClick: onClearSelection
				}) : null, /* @__PURE__ */ jsx(IconButton, {
					type: "button",
					variant: "invisible",
					icon: XIcon,
					"aria-label": "Close",
					onClick: () => onCancel()
				})] })]
			}),
			slots.searchInput,
			childrenWithoutSlots
		]
	});
};
SelectPanelHeader.displayName = "SelectPanelHeader";
SelectPanelHeader.__SLOT__ = Symbol("SelectPanel.Header");
var SelectPanelSearchInput = ({ onChange: propsOnChange, onKeyDown: propsOnKeyDown, className, ...props }) => {
	const inputRef = /* @__PURE__ */ React.createRef();
	const { setSearchQuery, moveFocusToList } = React.useContext(SelectPanelContext);
	const internalOnChange = (event) => {
		if (typeof propsOnChange === "function") propsOnChange(event);
		else setSearchQuery(event.target.value);
	};
	const internalKeyDown = (event) => {
		if (event.key === "ArrowDown") {
			event.preventDefault();
			moveFocusToList();
		}
		if (typeof propsOnKeyDown === "function") propsOnKeyDown(event);
	};
	return /* @__PURE__ */ jsx(TextInput$1, {
		ref: inputRef,
		block: true,
		leadingVisual: SearchIcon,
		placeholder: "Search",
		trailingAction: /* @__PURE__ */ jsx(TextInput$1.Action, {
			icon: XCircleFillIcon,
			"aria-label": "Clear",
			tooltipDirection: "w",
			className: classes.ClearAction,
			onClick: () => {
				if (inputRef.current) inputRef.current.value = "";
				if (typeof propsOnChange === "function") propsOnChange({
					target: inputRef.current,
					currentTarget: inputRef.current
				});
			}
		}),
		className: clsx(classes.TextInput, className),
		onChange: internalOnChange,
		onKeyDown: internalKeyDown,
		...props
	});
};
SelectPanelSearchInput.displayName = "SelectPanelSearchInput";
SelectPanelSearchInput.__SLOT__ = Symbol("SelectPanel.SearchInput");
var FooterContext = /* @__PURE__ */ React.createContext(false);
var SelectPanelFooter = ({ ...props }) => {
	const { onCancel, selectionVariant } = React.useContext(SelectPanelContext);
	const hidePrimaryActions = selectionVariant === "instant";
	const buttonSize = useResponsiveValue(responsiveButtonSizes, "small");
	if (hidePrimaryActions && !props.children) return null;
	return /* @__PURE__ */ jsx(FooterContext.Provider, {
		value: true,
		children: /* @__PURE__ */ jsxs("div", {
			className: classes.Footer,
			"data-hide-primary-actions": hidePrimaryActions || void 0,
			children: [/* @__PURE__ */ jsx("div", {
				className: classes.FooterContent,
				"data-hide-primary-actions": hidePrimaryActions || void 0,
				children: props.children
			}), hidePrimaryActions ? null : /* @__PURE__ */ jsxs("div", {
				className: classes.FooterActions,
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					type: "button",
					size: buttonSize,
					onClick: () => onCancel(),
					children: "Cancel"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					type: "submit",
					size: buttonSize,
					variant: "primary",
					children: "Save"
				})]
			})]
		})
	});
};
SelectPanelFooter.displayName = "SelectPanelFooter";
SelectPanelFooter.__SLOT__ = Symbol("SelectPanel.Footer");
var SecondaryButton = (props) => {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		type: "button",
		size: useResponsiveValue(responsiveButtonSizes, "small"),
		block: true,
		...props
	});
};
SecondaryButton.displayName = "SecondaryButton";
var SecondaryLink = ({ className, ...props }) => {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		as: Link,
		size: useResponsiveValue(responsiveButtonSizes, "small"),
		variant: "invisible",
		block: true,
		...props,
		className: clsx(classes.SmallText, className),
		children: props.children
	});
};
SecondaryLink.displayName = "SecondaryLink";
var SecondaryCheckbox = ({ id, children, className, ...props }) => {
	const checkboxId = useId$1(id);
	const { selectionVariant } = React.useContext(SelectPanelContext);
	!(selectionVariant !== "instant") && invariant(false);
	return /* @__PURE__ */ jsxs("div", {
		className: classes.SecondaryCheckbox,
		children: [/* @__PURE__ */ jsx(Checkbox, {
			id: checkboxId,
			className: clsx(classes.Checkbox, className),
			...props
		}), /* @__PURE__ */ jsx(InputLabel, {
			htmlFor: checkboxId,
			className: classes.SmallText,
			children
		})]
	});
};
SecondaryCheckbox.displayName = "SecondaryCheckbox";
var SelectPanelSecondaryAction = ({ variant, ...props }) => {
	!React.useContext(FooterContext) && invariant(false);
	if (variant === "button") return /* @__PURE__ */ jsx(SecondaryButton, { ...props });
	else if (variant === "link") return /* @__PURE__ */ jsx(SecondaryLink, { ...props });
	else if (variant === "checkbox") return /* @__PURE__ */ jsx(SecondaryCheckbox, { ...props });
};
var SelectPanelLoading = ({ children = "Fetching items..." }) => {
	return /* @__PURE__ */ jsxs(AriaStatus, {
		announceOnShow: true,
		className: classes.SelectPanelLoading,
		children: [/* @__PURE__ */ jsx(Spinner, {
			size: "medium",
			srText: null
		}), /* @__PURE__ */ jsx("span", {
			className: classes.LoadingText,
			children
		})]
	});
};
SelectPanelLoading.displayName = "SelectPanelLoading";
var SelectPanelMessage = ({ variant = "warning", size = variant === "empty" ? "full" : "inline", title, children }) => {
	const MessageWrapper = variant === "empty" ? "div" : AriaStatus;
	if (size === "full") return /* @__PURE__ */ jsxs(MessageWrapper, {
		className: classes.MessageFull,
		children: [
			variant !== "empty" ? /* @__PURE__ */ jsx(Octicon, {
				icon: AlertIcon,
				className: clsx(classes.Octicon, variant === "error" ? classes.Error : void 0, variant === "warning" ? classes.Warning : void 0)
			}) : null,
			/* @__PURE__ */ jsx("span", {
				className: classes.MessageTitle,
				children: title
			}),
			/* @__PURE__ */ jsx("span", {
				className: classes.MessageContent,
				children
			})
		]
	});
	else return /* @__PURE__ */ jsxs(MessageWrapper, {
		className: classes.MessageInline,
		"data-variant": variant,
		children: [/* @__PURE__ */ jsx(AlertIcon, { size: 16 }), /* @__PURE__ */ jsx("div", { children })]
	});
};
var SelectPanel = Object.assign(Panel, {
	Button: SelectPanelButton,
	Header: SelectPanelHeader,
	SearchInput: SelectPanelSearchInput,
	Footer: SelectPanelFooter,
	Loading: SelectPanelLoading,
	Message: SelectPanelMessage,
	SecondaryAction: SelectPanelSecondaryAction
});
function getSelectedThread(state) {
	if (!state.selectedThreadID) return null;
	return state.threads.get(state.selectedThreadID) || null;
}
/**
* Pulls the selected custom copilot (space) from either the URL or the selected thread per the chat state.
*/
function useSelectedCopilotSpaceId() {
	const $ = c(1);
	const previousValue = useRef(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (state) => {
			const id = copilotSpaceIdFromThread(getSelectedThread(state));
			if (customCopilotIdsAreEqual(previousValue.current, id)) return previousValue.current;
			else {
				previousValue.current = id;
				return id;
			}
		};
		$[0] = t0;
	} else t0 = $[0];
	const customCopilotId = useChatStateLens(t0);
	return useRouteSpaceId() || customCopilotId;
}
/**
* Custom hook to manage assigning a space to a pending (not persisted) chat thread
*
* @returns Object with space selection state and handlers
*/
function useSpaceSelection() {
	const initialCopilotSpaceId = useSelectedCopilotSpaceId();
	const { selectedCopilotSpaceId, setSelectedCopilotSpaceId, selectedThreadId } = useCopilotSpaceSelection();
	const readOnly = !!selectedThreadId || !!initialCopilotSpaceId;
	useEffect(() => {
		setSelectedCopilotSpaceId(initialCopilotSpaceId || void 0);
	}, [initialCopilotSpaceId, setSelectedCopilotSpaceId]);
	return {
		activeCopilotSpaceId: selectedCopilotSpaceId || initialCopilotSpaceId,
		readOnly,
		handleSpaceSelect: useCallback((space) => {
			if (!readOnly) setSelectedCopilotSpaceId({
				id: space.id,
				owner: space.owner
			});
		}, [setSelectedCopilotSpaceId, readOnly]),
		clearSpaceSelection: useCallback(() => {
			if (!readOnly) setSelectedCopilotSpaceId(void 0);
		}, [setSelectedCopilotSpaceId, readOnly])
	};
}
var referenceMentionPattern = /^@(?<repo>[\w-.]+\/[\w-.]+)(?:\/(?<type>\w+)\/(?<id>.+))?$/;
var threadScopedFileMentionPattern = /^@(?<id>[a-zA-Z0-9_.-]+)$/;
var ReferenceType = {
	fromUrlType(urlType) {
		switch (urlType) {
			case "issues": return "issue";
			case "pull": return "pull-request";
			case "discussions": return "discussion";
			case "blob":
			case "tree": return "file";
			case void 0: return "repository";
		}
	},
	fromMentionType(mentionType) {
		switch (mentionType) {
			case "issues": return "issue";
			case "pull": return "pull-request";
			case "discussions": return "discussion";
			case "files": return "file";
			case void 0: return "repository";
		}
	}
};
var ReferenceMention = {
	fromUrl(url) {
		let parsed;
		try {
			parsed = new URL(url);
		} catch {
			return;
		}
		if (parsed.hostname !== window.location.hostname || parsed.search || parsed.hash) return;
		const [, owner, repo, type, ...rest] = parsed.pathname.split("/");
		const id = rest.join("/");
		const referenceType = ReferenceType.fromUrlType(type);
		if (!owner || !repo || !referenceType) return;
		return {
			repo: `${owner}/${repo}`,
			type: id ? referenceType : "repository",
			id
		};
	},
	stringify(mention) {
		switch (mention.type) {
			case "issue": return `@${mention.repo}/issues/${mention.id ?? ""}`;
			case "pull-request": return `@${mention.repo}/pull/${mention.id ?? ""}`;
			case "discussion": return `@${mention.repo}/discussions/${mention.id ?? ""}`;
			case "repository": return `@${mention.repo}`;
			case "file": return `@${mention.repo}/files/${mention.id ?? ""}`;
			case "thread-scoped-file": return `@${mention.id ?? ""}`;
		}
	},
	parse(mention) {
		const match = referenceMentionPattern.exec(mention)?.groups;
		if (!match) {
			const fileMatch = threadScopedFileMentionPattern.exec(mention)?.groups;
			if (fileMatch) return {
				repo: "",
				type: "thread-scoped-file",
				id: fileMatch.id
			};
			return;
		}
		const type = ReferenceType.fromMentionType(match.type);
		return type ? {
			repo: match.repo,
			type,
			id: match.id
		} : void 0;
	},
	isEqual(a, b) {
		return ReferenceMention.stringify(a) === ReferenceMention.stringify(b);
	},
	refersTo(mention, reference) {
		const mentionForReference = ReferenceMention.for(reference);
		return mentionForReference !== null && ReferenceMention.isEqual(mention, mentionForReference);
	},
	for: (reference) => {
		switch (reference.type) {
			case "repository": return {
				type: "repository",
				repo: `${reference.ownerLogin}/${reference.name}`,
				reference
			};
			case "issue": return {
				type: "issue",
				repo: `${reference.repository.owner}/${reference.repository.name}`,
				id: reference.number.toString(),
				reference
			};
			case "pull-request": return {
				type: "pull-request",
				repo: `${reference.repository.ownerLogin}/${reference.repository.name}`,
				id: reference.number.toString(),
				reference
			};
			case "discussion": return {
				type: "discussion",
				repo: `${reference.repository.owner}/${reference.repository.name}`,
				id: reference.number.toString(),
				reference
			};
			case "file":
			case "folder": return {
				type: "file",
				repo: `${reference.repoOwner}/${reference.repoName}`,
				id: reference.path,
				reference
			};
			case "thread-scoped-file": return {
				type: "thread-scoped-file",
				repo: "",
				id: reference.name,
				reference
			};
			default: return null;
		}
	}
};
var AGENTS_MARKETPLACE_URL = "https://github.com/marketplace?type=apps&copilot_app=true";
/** Matches possible agent mentions and provides a `slug` capture group. */
var agentMentionPattern = /^@(?<slug>\S+)$/;
/**
* @param enabled Set to true when the agents list is rendered (ie, the menu is open). This enables lazy fetching. If
* always true, will start fetching as soon as the consuming component is mounted.
*/
function useAvailableAgents(t0) {
	const $ = c(25);
	const enabled = t0 === void 0 ? true : t0;
	const { agentsPath, model } = useChatStateValues("agentsPath", "model");
	const getChatState = useGetChatState();
	const manager = useChatManager();
	const isCopilotSpace = !!useSelectedCopilotSpaceId();
	const unsupportedModel = model?.hasLimitedCapabilities;
	let t1;
	if ($[0] !== getChatState || $[1] !== isCopilotSpace || $[2] !== unsupportedModel) {
		t1 = (agents) => {
			const { messages } = getChatState();
			if (unsupportedModel || isCopilotSpace) return {
				agents: [],
				showLimit: false
			};
			const previousAgent = findAgentCorrespondents(messages)[0];
			if (previousAgent) return {
				agents: agents.filter((agent) => agent.slug === previousAgent.name),
				showLimit: agents.length > 1
			};
			return {
				agents,
				showLimit: false
			};
		};
		$[0] = getChatState;
		$[1] = isCopilotSpace;
		$[2] = unsupportedModel;
		$[3] = t1;
	} else t1 = $[3];
	const selectAgents = t1;
	let t2;
	if ($[4] !== agentsPath) {
		t2 = [
			"copilot-chat",
			"agents",
			agentsPath
		];
		$[4] = agentsPath;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== agentsPath || $[7] !== manager) {
		t3 = () => agentsPath ? manager.fetchAgents(agentsPath) : [];
		$[6] = agentsPath;
		$[7] = manager;
		$[8] = t3;
	} else t3 = $[8];
	const t4 = enabled && !unsupportedModel && !isCopilotSpace;
	let t5;
	if ($[9] !== selectAgents || $[10] !== t2 || $[11] !== t3 || $[12] !== t4) {
		t5 = {
			queryKey: t2,
			queryFn: t3,
			select: selectAgents,
			enabled: t4
		};
		$[9] = selectAgents;
		$[10] = t2;
		$[11] = t3;
		$[12] = t4;
		$[13] = t5;
	} else t5 = $[13];
	const { isLoading, data, refetch, isStale, isFetched } = useQuery(t5);
	let t6;
	if ($[14] !== data || $[15] !== isFetched || $[16] !== isStale || $[17] !== refetch) {
		t6 = async () => {
			if (!isFetched || isStale) return (await refetch()).data;
			return data;
		};
		$[14] = data;
		$[15] = isFetched;
		$[16] = isStale;
		$[17] = refetch;
		$[18] = t6;
	} else t6 = $[18];
	const imperativelyFetch = t6;
	const t7 = data?.agents;
	const t8 = data?.showLimit ?? false;
	let t9;
	if ($[19] !== imperativelyFetch || $[20] !== isLoading || $[21] !== t7 || $[22] !== t8 || $[23] !== unsupportedModel) {
		t9 = {
			loading: isLoading,
			disabled: unsupportedModel,
			availableAgents: t7,
			showLimit: t8,
			imperativelyFetch
		};
		$[19] = imperativelyFetch;
		$[20] = isLoading;
		$[21] = t7;
		$[22] = t8;
		$[23] = unsupportedModel;
		$[24] = t9;
	} else t9 = $[24];
	return t9;
}
/**
* Returns a function that inserts an agent reference in the beginning of the target input.
*/
function useInsertAgent(t0) {
	const $ = c(6);
	const { inputOnChange, inputRef } = t0;
	let t1;
	if ($[0] !== inputOnChange || $[1] !== inputRef) {
		t1 = {
			inputRef,
			fallbackEventHandler: inputOnChange
		};
		$[0] = inputOnChange;
		$[1] = inputRef;
		$[2] = t1;
	} else t1 = $[2];
	const changeInput = useSyntheticChange(t1);
	let t2;
	if ($[3] !== changeInput || $[4] !== inputRef) {
		t2 = (t3) => {
			const agent = t3 === void 0 ? "" : t3;
			if (inputRef.current?.value) changeInput(" ", [0, 0]);
			const insertStr = `@${agent}`;
			changeInput(insertStr, [0, 0], insertStr.length);
		};
		$[3] = changeInput;
		$[4] = inputRef;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
function extractChatCommandType(text, availableCommandsKeys) {
	if (availableCommandsKeys.length === 0) return null;
	if (!copilotFeatureFlags.chatInputCommands) return null;
	const pattern = new RegExp(`^\\/(${availableCommandsKeys.join("|")})(?:\\s|$)`, "i");
	const match = text.match(pattern);
	if (match && match[1]) return match[1].toLowerCase();
	return null;
}
/**
* Checks if a slash command is incomplete (has no meaningful text after the command).
* Returns true if the text starts with a slash command but has no additional text after it.
* This is used to disable the submit button until the user provides the required prompt.
*
* @param text - The input text to check
* @param command - The extracted command type (or null if no command)
* @returns true if the text is an incomplete slash command, false otherwise
*
* @example
* isIncompleteSlashCommand('/agent', 'agent') // returns true
* isIncompleteSlashCommand('/agent ', 'agent') // returns true
* isIncompleteSlashCommand('/agent  ', 'agent') // returns true
* isIncompleteSlashCommand('/agent hi', 'agent') // returns false
* isIncompleteSlashCommand('hi', null) // returns false
*/
function isIncompleteSlashCommand(text, command) {
	if (!command) return false;
	return text.trim().toLowerCase() === `/${command.toLowerCase()}`;
}
/**
* Unified.js plugin that parses a user's message into an abstract syntax tree.
*/
var userMessageParser = function({ references, agents, commands }) {
	this.parser = function(text) {
		const tokens = text.split(/(\s+)/);
		const nodes = [];
		for (const [i, token] of tokens.entries()) {
			if (copilotFeatureFlags.chatInputCommands && i === 0) {
				const command = extractChatCommandType(token, commands);
				if (command) {
					nodes.push({
						type: "command",
						value: token,
						data: { command }
					});
					continue;
				}
			}
			const agentSlug = i === 0 && agentMentionPattern.exec(token)?.groups?.slug;
			const mentionedAgent = agentSlug && agents.find((agent) => agent.slug === agentSlug);
			if (mentionedAgent) {
				nodes.push({
					type: "agent-mention",
					value: token,
					data: { mentionedAgent }
				});
				continue;
			}
			const referenceMention = ReferenceMention.parse(token);
			const mentionedReference = referenceMention && references?.find((r) => ReferenceMention.refersTo(referenceMention, r));
			if (referenceMention) {
				nodes.push({
					type: "reference-mention",
					value: token,
					data: {
						mentionedReferenceId: mentionedReference && referenceID(mentionedReference),
						referenceMention
					}
				});
				continue;
			}
			const lastNode = nodes.at(-1);
			if (lastNode?.type === "text") lastNode.value += token;
			else nodes.push({
				type: "text",
				value: token
			});
		}
		return {
			type: "root",
			children: nodes
		};
	};
};
var getTypeParam = (itemRefType) => {
	switch (itemRefType) {
		case "issue": return "issue";
		case "pull-request": return "pull_request";
		case "discussion": return "discussion";
		case "thread-scoped-file":
		case "file": return "file";
	}
};
/**
* Checks if a reference type is allowed by the provided filter.
* If no filter is provided, all types are allowed.
*/
function isTypeAllowed$1(refType, typeFilter) {
	return !typeFilter || typeFilter.includes(refType);
}
/** Maximum number of references to handle when calling `addReferencesForMentions`. */
var MAX_REFERENCES_TO_ADD = 20;
function useAddMentionReferences() {
	const manager = useChatManager();
	const { currentReferences, mode } = useChatState();
	const mentionReferencesQuery = useMutation({
		mutationFn: async (mention) => {
			const response = await verifiedFetchJSON(`/copilot/chat/reference/${(mention.type === "repository" ? [mention.repo] : [
				mention.repo,
				getTypeParam(mention.type),
				mention.id ?? ""
			]).join("/")}`);
			if (!response.ok) throw new Error(`Failed to fetch reference data (${response.status}: ${response.statusText})`);
			sendEvent("dotcom_chat.activate", {
				target: "REFERENCE_LINK_PASTE",
				mode,
				linkType: mention.type
			});
			return await response.json();
		},
		onSuccess: (reference) => manager.addReference(reference, "chatInput")
	});
	const addReferenceForMention = (mention_0) => {
		if (currentReferences.every((reference_0) => !ReferenceMention.refersTo(mention_0, reference_0))) mentionReferencesQuery.mutate(mention_0);
	};
	const addReferencesForMentions = (text, typeFilter) => {
		const messageTree = unified().use(userMessageParser, {
			references: currentReferences,
			agents: [],
			commands: []
		}).parse(text);
		let count = 0;
		visit(messageTree, (node) => {
			if (node.type === "reference-mention" && node.data.mentionedReferenceId === void 0 && count < MAX_REFERENCES_TO_ADD) {
				if (!isTypeAllowed$1(node.data.referenceMention.type, typeFilter)) return;
				count++;
				addReferenceForMention(node.data.referenceMention);
			}
		});
	};
	return {
		isLoading: mentionReferencesQuery.isPending,
		addReferenceForMention,
		addReferencesForMentions
	};
}
var figmaUrlPattern = /^(?:https:\/\/)?(?:www\.)?(figma\.com\/.+)$/;
/**
* Checks if a reference type is allowed by the given type filter.
* Returns true if no filter is set (all types allowed) or if the type is in the filter.
*/
function isTypeAllowed(refType, typeFilter) {
	return !typeFilter || typeFilter.includes(refType);
}
var FigmaNotAuthorizedError = class extends Error {
	constructor() {
		super();
		this.name = "FigmaNotAuthorizedError";
	}
};
function useAddUrlReferences(t0) {
	const $ = c(35);
	const { figmaAuthUrl, textAreaRef, emitChange } = t0;
	const manager = useChatManager();
	const { currentReferences } = useChatState();
	let t1;
	if ($[0] !== emitChange || $[1] !== textAreaRef) {
		t1 = (search, replace, range) => {
			if (!textAreaRef.current || search === replace) return;
			const offset = range?.[0] ?? 0;
			let valueInRange = textAreaRef.current.value.slice(offset, range?.[1]);
			let start = valueInRange.indexOf(search);
			while (start > -1) {
				const end = start + search.length;
				emitChange(replace, [start + offset, end + offset]);
				valueInRange = valueInRange.replace(search, replace);
				start = valueInRange.indexOf(search);
			}
		};
		$[0] = emitChange;
		$[1] = textAreaRef;
		$[2] = t1;
	} else t1 = $[2];
	const findAndReplace = t1;
	let t2;
	if ($[3] !== manager) {
		t2 = (t3) => {
			const { itemUrl: itemUrl_0 } = t3;
			const placeholder = makePlaceholderReference(itemUrl_0);
			manager.addReference(placeholder, "url-attacher");
			manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: true,
				attachmentType: "url-reference"
			});
			return placeholder;
		};
		$[3] = manager;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	let t4;
	if ($[5] !== findAndReplace || $[6] !== manager) {
		t3 = (reference, t5, placeholder_0) => {
			const { parsedReferenceMention } = t5;
			manager.replaceReference(placeholder_0, reference);
			const resolvedReferenceMention = ReferenceMention.for(reference);
			if (!resolvedReferenceMention) return;
			const parsedReferenceMentionStr = ReferenceMention.stringify(parsedReferenceMention);
			const resolvedReferenceMentionStr = ReferenceMention.stringify(resolvedReferenceMention);
			if (parsedReferenceMentionStr === resolvedReferenceMentionStr) return;
			findAndReplace(parsedReferenceMentionStr, resolvedReferenceMentionStr);
		};
		t4 = (_, t6, placeholder_1) => {
			const { itemUrl: itemUrl_1, parsedReferenceMention: parsedReferenceMention_0 } = t6;
			manager.removeReference(placeholder_1);
			findAndReplace(ReferenceMention.stringify(parsedReferenceMention_0), itemUrl_1);
		};
		$[5] = findAndReplace;
		$[6] = manager;
		$[7] = t3;
		$[8] = t4;
	} else {
		t3 = $[7];
		t4 = $[8];
	}
	let t5;
	if ($[9] !== manager) {
		t5 = () => {
			manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: false
			});
		};
		$[9] = manager;
		$[10] = t5;
	} else t5 = $[10];
	let t6;
	if ($[11] !== t2 || $[12] !== t3 || $[13] !== t4 || $[14] !== t5) {
		t6 = {
			mutationFn: _temp$19,
			onMutate: t2,
			onSuccess: t3,
			onError: t4,
			onSettled: t5
		};
		$[11] = t2;
		$[12] = t3;
		$[13] = t4;
		$[14] = t5;
		$[15] = t6;
	} else t6 = $[15];
	const githubReferenceQuery = useMutation(t6);
	let t7;
	let t8;
	if ($[16] !== manager) {
		t7 = (itemUrl_3) => {
			const placeholder_2 = makePlaceholderReference(itemUrl_3);
			manager.addReference(placeholder_2, "figma-attacher");
			manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: true,
				attachmentType: "url-reference"
			});
			return placeholder_2;
		};
		t8 = (reference_0, __0, placeholder_3) => {
			manager.replaceReference(placeholder_3, reference_0);
		};
		$[16] = manager;
		$[17] = t7;
		$[18] = t8;
	} else {
		t7 = $[17];
		t8 = $[18];
	}
	let t9;
	if ($[19] !== figmaAuthUrl || $[20] !== manager) {
		t9 = (error, itemUrl_4, placeholder_4) => {
			if (placeholder_4 && figmaAuthUrl && error instanceof FigmaNotAuthorizedError) manager.replaceReference(placeholder_4, {
				type: "figma",
				title: "Sign in to Figma",
				id: `forbidden-${itemUrl_4}`,
				url: figmaAuthUrl,
				thumbnailUrl: "",
				fullImageUrl: "",
				authenticationRequired: true
			});
			else manager.removeReference(placeholder_4);
		};
		$[19] = figmaAuthUrl;
		$[20] = manager;
		$[21] = t9;
	} else t9 = $[21];
	let t10;
	if ($[22] !== manager) {
		t10 = () => {
			manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: false
			});
		};
		$[22] = manager;
		$[23] = t10;
	} else t10 = $[23];
	let t11;
	if ($[24] !== t10 || $[25] !== t7 || $[26] !== t8 || $[27] !== t9) {
		t11 = {
			mutationFn: _temp2$5,
			onMutate: t7,
			onSuccess: t8,
			onError: t9,
			onSettled: t10
		};
		$[24] = t10;
		$[25] = t7;
		$[26] = t8;
		$[27] = t9;
		$[28] = t11;
	} else t11 = $[28];
	const figmaReferenceQuery = useMutation(t11);
	let t12;
	if ($[29] !== currentReferences || $[30] !== figmaReferenceQuery || $[31] !== findAndReplace || $[32] !== githubReferenceQuery || $[33] !== textAreaRef) {
		const replaceUrlWithReferenceMention = (range_0, typeFilter) => {
			const text = textAreaRef.current?.value.slice(...range_0) ?? "";
			if (/\s/.test(text)) return text;
			const parsedReferenceMention_1 = ReferenceMention.fromUrl(text);
			if (parsedReferenceMention_1) {
				if (!isTypeAllowed(parsedReferenceMention_1.type, typeFilter)) return text;
				if (currentReferences.every((ref) => !ReferenceMention.refersTo(parsedReferenceMention_1, ref))) githubReferenceQuery.mutate({
					itemUrl: text,
					parsedReferenceMention: parsedReferenceMention_1
				});
				findAndReplace(text, ReferenceMention.stringify(parsedReferenceMention_1), range_0);
			}
			const figmaReferenceMatch = figmaUrlPattern.exec(text);
			if (figmaReferenceMatch) {
				if (!isTypeAllowed("figma", typeFilter)) return text;
				figmaReferenceQuery.mutate(text);
				findAndReplace(text, figmaReferenceMatch[1], range_0);
			}
			return text;
		};
		t12 = { replaceUrlWithReferenceMention };
		$[29] = currentReferences;
		$[30] = figmaReferenceQuery;
		$[31] = findAndReplace;
		$[32] = githubReferenceQuery;
		$[33] = textAreaRef;
		$[34] = t12;
	} else t12 = $[34];
	return t12;
}
async function _temp2$5(itemUrl_2) {
	const response_0 = await verifiedFetchJSON(`/copilot/immersive/figma-link?item_url=${itemUrl_2}`);
	if (!response_0.ok) {
		if (response_0.status === 403) throw new FigmaNotAuthorizedError();
		throw new Error(`Failed to fetch Figma reference data (${response_0.status}: ${response_0.statusText})`);
	}
	return await response_0.json();
}
async function _temp$19(t0) {
	const { itemUrl } = t0;
	const response = await verifiedFetchJSON(`/copilot/chat-links?item_url=${itemUrl}`);
	if (!response.ok) throw new Error(`Failed to fetch reference data (${response.status}: ${response.statusText})`);
	return await response.json();
}
function useAvailableCommands(t0) {
	const $ = c(8);
	const { enabled } = t0;
	const plugins = usePlugins();
	let t1;
	if ($[0] !== enabled || $[1] !== plugins) {
		bb0: {
			const commands = [];
			if (!enabled) {
				t1 = commands;
				break bb0;
			}
			for (const plugin of plugins) if (plugin.slashCommand) commands.push({
				key: plugin.slashCommand.key,
				name: plugin.slashCommand.name,
				description: plugin.slashCommand.description,
				icon: plugin.slashCommand.icon,
				isNew: plugin.slashCommand.isNew,
				order: plugin.slashCommand.order,
				suggestions: plugin.slashCommand.suggestions,
				enabled: plugin.slashCommand.enabled,
				disabledAction: plugin.slashCommand.disabledAction,
				customModelPicker: plugin.slashCommand.customModelPicker,
				execute: async (params, state, navigate) => await plugin.slashCommand.execute(params, state, navigate),
				mode: plugin.slashCommand.mode
			});
			if (copilotFeatureFlags.askModeDropdown) commands.push({
				key: "ask",
				name: "Ask",
				description: "Get an answer to a question",
				icon: CommentIcon,
				order: 0,
				suggestions: [],
				execute: _temp$18,
				mode: {
					name: ModeSupportName.Ask,
					icon: CommentIcon,
					supportsAttachments: true,
					supportsModelSwitching: true,
					supportsSpaces: true,
					supportsAutocompletion: true
				}
			});
			commands.push({
				key: "create-issue",
				name: "Create issue",
				description: "Create a GitHub issue from your conversation",
				icon: IssueDraftIcon,
				suggestions: ["First, create a new draft issue. Then ask for additional information to fill out the issue.", "First, create an issue with sub issues. Then ask for additional information to fill out these issues."],
				execute: _temp2$4
			});
			t1 = commands.sort(_temp3);
		}
		$[0] = enabled;
		$[1] = plugins;
		$[2] = t1;
	} else t1 = $[2];
	const availableCommands = t1;
	let t2;
	if ($[3] !== availableCommands) {
		t2 = availableCommands.map(_temp4);
		$[3] = availableCommands;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== availableCommands || $[6] !== t2) {
		t3 = {
			availableCommands,
			availableCommandKeys: t2
		};
		$[5] = availableCommands;
		$[6] = t2;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
function _temp4(cmd) {
	return cmd.key;
}
function _temp3(a, b) {
	if (a.order !== void 0 && b.order !== void 0) return a.order - b.order;
	if (a.order !== void 0) return -1;
	if (b.order !== void 0) return 1;
	return a.name.localeCompare(b.name);
}
function _temp2$4() {
	return false;
}
function _temp$18() {
	return false;
}
var getSlashCommands = ({ manager, chatState, availableCommands }) => {
	const slashCommands = chatState.mode === "assistive" ? [
		{
			label: "Delete chat",
			key: "delete",
			icon: TrashIcon,
			action: async (_params, state) => {
				manager.dispatch({ type: "SLASH_COMMANDS_LOADING" });
				try {
					const selectedThread = getSelectedThread(state);
					if (!selectedThread) throw new Error("Thread not found");
					await manager.deleteThread(selectedThread);
					sendEvent("dotcom_chat.activate", {
						target: "SLASH_COMMAND_DELETE_THREAD",
						mode: state.mode
					});
					manager.dispatch({ type: "SLASH_COMMANDS_LOADED" });
				} catch {
					manager.dispatch({ type: "SLASH_COMMANDS_ERROR" });
				}
				return true;
			}
		},
		{
			label: "Rename conversation",
			key: "rename",
			icon: PencilIcon,
			action: async (params, state) => {
				manager.dispatch({ type: "SLASH_COMMANDS_LOADING" });
				try {
					const selectedThread = getSelectedThread(state);
					if (!selectedThread) throw new Error("Thread not found");
					await manager.renameThread(selectedThread, params);
					sendEvent("dotcom_chat.activate", {
						target: "SLASH_COMMAND_RENAME",
						mode: state.mode
					});
					manager.dispatch({ type: "SLASH_COMMANDS_LOADED" });
				} catch {
					manager.dispatch({ type: "SLASH_COMMANDS_ERROR" });
				}
				return true;
			}
		},
		{
			label: "Start a new conversation",
			key: "new",
			icon: PlusIcon,
			action: async (_params, state) => {
				manager.dispatch({ type: "SLASH_COMMANDS_LOADING" });
				try {
					await manager.selectThread(null);
					sendEvent("dotcom_chat.activate", {
						target: "SLASH_COMMAND_NEW_THREAD",
						mode: state.mode
					});
					manager.dispatch({ type: "SLASH_COMMANDS_LOADED" });
				} catch {
					manager.dispatch({ type: "SLASH_COMMANDS_ERROR" });
				}
				return true;
			}
		}
	] : [];
	if (chatState.mode === "immersive" && copilotFeatureFlags.chatInputCommands) {
		for (const command of availableCommands) if (command.execute) slashCommands.push({
			key: command.key,
			action: async (params, state, navigate) => {
				return await command.execute(params, state, navigate, manager);
			}
		});
	}
	return slashCommands;
};
var executePotentialSlashCommand = async (input, state, manager, navigate, availableCommands, activeModeName, context) => {
	const isAgentMode = copilotFeatureFlags.askModeDropdown && activeModeName === ModeSupportName.Agent;
	if (!isAgentMode) {
		if ((input[0] ?? "") !== "/") return false;
		input = input.substring(1);
	}
	const slashCommands = getSlashCommands({
		manager,
		chatState: state,
		availableCommands
	});
	const matchingCommands = isAgentMode ? slashCommands.filter((slashCommand) => slashCommand.key.toLowerCase() === activeModeName?.toLowerCase()) : slashCommands.filter((slashCommand) => {
		const firstInputWord = (input.split(" ", 1)[0] ?? "").toLowerCase().trim();
		return slashCommand.key.toLowerCase() === firstInputWord;
	});
	if (matchingCommands.length !== 1) return false;
	const matchingCommand = matchingCommands[0];
	let params = isAgentMode ? input.trim() : input.substring(matchingCommand.key.length).trim();
	if (context && (context.selectedRepo || context.selectedBranch || context.selectedAgent)) params = JSON.stringify({
		text: params,
		selectedRepo: context.selectedRepo,
		selectedBranch: context.selectedBranch,
		selectedAgent: context.selectedAgent
	});
	sendEvent("dotcom_chat.activate", {
		target: "SLASH_COMMAND_EXECUTED",
		mode: state.mode,
		command: matchingCommand.key,
		activeModeName
	});
	return await matchingCommand.action(params, state, navigate);
};
/**
* Custom error class for validation failures in chat input components.
* This allows us to distinguish between validation errors (where we want to preserve user input)
* and unexpected errors (which should be re-thrown).
*/
var ChatInputValidationError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "ChatInputValidationError";
	}
};
/**
* Custom hook that manages the last used repository state and automatically
* loads it from local storage on mount.
*/
function useLastUsedRepository() {
	const $ = c(3);
	const [lastUsedRepo, setLastUsedRepo] = useState(_temp$17);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (repo) => {
			setLastUsedRepo(repo);
			if (repo) copilotLocalStorage.setLastUsedRepository(repo);
		};
		$[0] = t0;
	} else t0 = $[0];
	const setRepo = t0;
	let t1;
	if ($[1] !== lastUsedRepo) {
		t1 = [lastUsedRepo, setRepo];
		$[1] = lastUsedRepo;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
function _temp$17() {
	return copilotLocalStorage.getLastUsedRepository();
}
var MAX_HEIGHT = 300;
var MIN_HEIGHT = 56;
/**
* Helper function to determine if the current mode is an agent command.
* Checks either the active mode name (when askModeDropdown is enabled) or the command type.
*/
function isAgentCommand(activeModeName, command) {
	return copilotFeatureFlags.askModeDropdown ? activeModeName === ModeSupportName.Agent : command === "agent";
}
/**
* Does a bunch of stuff, too much really, to manage a chat input for a copilot chat.
*/
function useChatInput(props) {
	const state = useChatState();
	const manager = useChatManager();
	const navigate = useNavigate$1();
	const { selectedThreadID: contextThreadID, mode, autoSubmit, model } = state;
	const { activeModeName, clearPastedFile, isLoading, onSubmit, onChatCommandChange, isInPortal, shouldClearTextOnCommandSubmit = true, shouldClearTextOnSubmit = true, availableCommands = [], storageKeySuffix, source = "immersive" } = props;
	const selectedThreadID = storageKeySuffix ?? contextThreadID;
	const savedUserMessage = copilotLocalStorage.getSavedMessage(selectedThreadID, source);
	const savedUserMessageOnError = copilotLocalStorage.getSavedUserMessageOnError(selectedThreadID);
	const { pathname } = useLocation$1();
	const [searchParams, setSearchParams] = useSearchParams();
	const [text, setText] = useState(() => {
		if (props.initialText) return props.initialText;
		return getPromptFromSearchParams(state.mode, pathname, searchParams) ?? savedUserMessageOnError ?? savedUserMessage ?? "";
	});
	const [isAgentTaskSubmitInProgress, setIsAgentTaskSubmitInProgress] = useState(false);
	const [command, setCommand] = useState(null);
	const [typingHasStarted, setTypingHasStarted] = useState(false);
	const internalRef = useRef(null);
	const textAreaRef = props.textAreaRef || internalRef;
	const textareaPreviewRef = useRef(null);
	const textAreaPreviewContainerRef = useRef(null);
	const recallIndex = useRef(0);
	const reloadThreadTimerRef = useRef(null);
	const reloadThreadFetchMessagesCallbackRef = useRef(() => {});
	const handleAutoSubmitRef = useRef(false);
	const defaultModel = useDefaultModel(state.availableModels);
	const prevThreadID = useRef(selectedThreadID);
	const { safeSetTimeout } = useSafeTimeout();
	const prevContainerHeight = useRef(0);
	const [lastUsedRepo, setLastUsedRepo] = useLastUsedRepository();
	const [selectedRepo, setSelectedRepo] = useState(void 0);
	const repoReference = state.currentReferences.find((ref) => ref.type === "repository");
	const initialRepoNWO = repoReference ? `${repoReference.ownerLogin}/${repoReference.name}` : `${lastUsedRepo?.ownerLogin}/${lastUsedRepo?.name}`;
	const onSelectRepo = useCallback((repo) => {
		setSelectedRepo(repo);
	}, []);
	const [selectedBranch, setSelectedBranch] = useState(void 0);
	const [selectedAgent, setSelectedAgent] = useLastSelectedAgent();
	useEffect(() => {
		if (selectedThreadID === prevThreadID.current) copilotLocalStorage.setSavedMessage(selectedThreadID, source, text);
		else {
			setText(copilotLocalStorage.getSavedMessage(selectedThreadID, source) || "");
			prevThreadID.current = selectedThreadID;
		}
	}, [
		selectedThreadID,
		source,
		text
	]);
	useLayoutEffect(() => {
		let tries = 0;
		function adjustHeight() {
			if (!textAreaRef.current || !textAreaPreviewContainerRef.current || !textareaPreviewRef.current) return;
			tries++;
			if ((isInPortal || mode === "assistive") && textAreaRef.current.scrollHeight === 0 && tries < 10) {
				safeSetTimeout(adjustHeight, 1);
				return;
			}
			if (text.length === 0 && prevContainerHeight.current === MIN_HEIGHT) return;
			textAreaRef.current.style.height = "0";
			const scrollHeight = Math.max(textAreaRef.current.scrollHeight, MIN_HEIGHT);
			const maxHeight = props.maxTextareaHeight ?? MAX_HEIGHT;
			const containerHeight = Math.min(scrollHeight, maxHeight);
			textareaPreviewRef.current.style.height = `${scrollHeight}px`;
			textAreaRef.current.style.height = `${scrollHeight}px`;
			textAreaPreviewContainerRef.current.style.height = `${containerHeight}px`;
			textAreaPreviewContainerRef.current.style.maxHeight = props.maxTextareaHeight ? `${props.maxTextareaHeight}px` : "";
			prevContainerHeight.current = containerHeight;
		}
		adjustHeight();
	}, [
		mode,
		safeSetTimeout,
		text,
		textAreaRef,
		textareaPreviewRef,
		isInPortal,
		activeModeName,
		props.maxTextareaHeight
	]);
	const handleFocus = (e) => {
		if (e.currentTarget.selectionStart > 0) return;
		e.currentTarget.setSelectionRange(e.currentTarget.value.length, e.currentTarget.value.length);
	};
	const handleScroll = useCallback(() => {
		if (!textAreaRef?.current || !textareaPreviewRef?.current || !textAreaPreviewContainerRef?.current) return;
		if (copilotFeatureFlags.chatInputPerformanceOptimizations) requestAnimationFrame(() => {
			if (!textAreaRef?.current || !textareaPreviewRef?.current) return;
			textareaPreviewRef.current.scrollTop = textAreaRef.current.scrollTop;
			textareaPreviewRef.current.scrollLeft = textAreaRef.current.scrollLeft;
		});
		else {
			textareaPreviewRef.current.scrollTop = textAreaRef.current.scrollTop;
			textareaPreviewRef.current.scrollLeft = textAreaRef.current.scrollLeft;
		}
	}, [textAreaRef]);
	const throttledHandleScroll = useMemo(() => copilotFeatureFlags.chatInputPerformanceOptimizations ? throttle$1(handleScroll, 16, {
		leading: true,
		trailing: true
	}) : handleScroll, [handleScroll]);
	useEffect(() => {
		const scrollHandler = throttledHandleScroll;
		return () => {
			if (copilotFeatureFlags.chatInputPerformanceOptimizations && "cancel" in scrollHandler) scrollHandler.cancel();
		};
	}, [throttledHandleScroll]);
	const sendableReferences = useMemo(() => state.currentReferences.filter((ref_0) => !("isClientOnly" in ref_0) || !ref_0.isClientOnly), [state.currentReferences]);
	const handleSubmit = useCallback(async (e_0) => {
		setTypingHasStarted(false);
		copilotLocalStorage.clearSavedUserMessage(selectedThreadID, source);
		copilotLocalStorage.clearSavedUserMessageOnError(selectedThreadID);
		if (state.defaultRecipient && !text.includes(`@${state.defaultRecipient}`)) manager.clearDefaultRecipient();
		e_0?.preventDefault();
		const isAgent = isAgentCommand(activeModeName, command);
		if (isAgent && selectedRepo?.id != null) {
			const result = await manager.service.fetchRepo(selectedRepo.id);
			if (result.ok && result.payload) setLastUsedRepo(result.payload);
		}
		if (await executePotentialSlashCommand(text, state, manager, navigate, availableCommands, activeModeName, isAgent ? {
			selectedRepo,
			selectedBranch,
			selectedAgent
		} : {})) {
			if (text.trim() === "/new") copilotLocalStorage.setSavedMessageFast(selectedThreadID, source, null);
			if (shouldClearTextOnCommandSubmit) setText("");
			else {
				const textAfterCommand = text.substring(text.indexOf(" ") + 1).trim();
				setIsAgentTaskSubmitInProgress(true);
				setText(`Creating ${textAfterCommand}...`);
			}
			return;
		}
		if (!isLoading) {
			let messageToSubmit = text;
			if (!messageToSubmit) {
				const refs = sendableReferences;
				const [inferred, newMessage] = manager.tryInferMessage(refs);
				if (!inferred || !newMessage) return;
				else messageToSubmit = newMessage;
			}
			if (activeModeName === ModeSupportName.CreateIssue) messageToSubmit = `/create-issue ${messageToSubmit}`;
			try {
				if (shouldClearTextOnSubmit) setText("");
				else {
					setIsAgentTaskSubmitInProgress(true);
					setText(`Creating ${text}...`);
				}
				const additionalReferences = [];
				if (isAgent && selectedRepo) {
					const taskRequestReference = {
						type: "task-request",
						description: messageToSubmit,
						repoOwner: selectedRepo.owner,
						repoName: selectedRepo.nameOnly,
						ref: selectedBranch || selectedRepo.defaultBranch,
						customAgent: selectedAgent.subAgentSlug,
						agentId: selectedAgent.topLevelAgentId
					};
					additionalReferences.push(taskRequestReference);
				}
				await onSubmit?.(messageToSubmit, additionalReferences.length > 0 ? additionalReferences : void 0);
				if (!shouldClearTextOnSubmit) copilotLocalStorage.clearSavedUserMessage(selectedThreadID, source);
			} catch (error) {
				setIsAgentTaskSubmitInProgress(false);
				if (error instanceof ChatInputValidationError) {
					setText(messageToSubmit);
					return;
				}
				throw error;
			}
		}
	}, [
		selectedThreadID,
		source,
		state,
		text,
		activeModeName,
		command,
		selectedRepo,
		manager,
		navigate,
		availableCommands,
		selectedBranch,
		selectedAgent,
		isLoading,
		setLastUsedRepo,
		shouldClearTextOnCommandSubmit,
		sendableReferences,
		shouldClearTextOnSubmit,
		onSubmit
	]);
	const handleSubmitToNewThread = useCallback(() => manager.sendMessageToNewThread(selectedThreadID, text, sendableReferences, state.context, defaultModel, source), [
		manager,
		selectedThreadID,
		text,
		sendableReferences,
		state.context,
		defaultModel,
		source
	]);
	useEffect(() => {
		const handlePrompt = async () => {
			const prompt_0 = getPromptFromSearchParams(mode, pathname, searchParams);
			const updatedSearchParams = new URLSearchParams(searchParams);
			const queryModel = updatedSearchParams.get("model");
			const modelAvailable = !queryModel || queryModel === model.id;
			if (prompt_0 && modelAvailable && !handleAutoSubmitRef.current) {
				updatedSearchParams.delete("prompt");
				updatedSearchParams.delete("model");
				sendEvent("dotcom_chat.activate", {
					target: "COPILOT_PROMPT_LOADED_FROM_URL",
					mode: "immersive"
				});
				setSearchParams(updatedSearchParams, { replace: true });
				if (autoSubmit) {
					handleAutoSubmitRef.current = true;
					await Promise.resolve();
					await handleSubmit();
				}
			}
		};
		handlePrompt();
	}, [
		pathname,
		searchParams,
		setSearchParams,
		mode,
		autoSubmit,
		model,
		handleSubmit
	]);
	const handleChange = useCallback((e_1) => {
		setTypingHasStarted(true);
		if (!textAreaRef?.current) return;
		const newValue = e_1.target.value;
		setText(newValue);
		clearPastedFile?.();
		recallIndex.current = 0;
		throttledHandleScroll();
	}, [
		throttledHandleScroll,
		clearPastedFile,
		textAreaRef
	]);
	const handleStop = useCallback(async () => {
		await manager.stopStreaming();
		if (selectedThreadID != null) {
			manager.startThreadReload();
			await new Promise((timerDone) => {
				reloadThreadTimerRef.current = setTimeout(() => timerDone(selectedThreadID), 6 * 1e3);
			});
			reloadThreadFetchMessagesCallbackRef.current = await manager.fetchMessages(selectedThreadID, true, true);
		}
	}, [manager, selectedThreadID]);
	useEffect(() => {
		if (reloadThreadFetchMessagesCallbackRef.current) {
			reloadThreadFetchMessagesCallbackRef.current();
			reloadThreadFetchMessagesCallbackRef.current = () => {};
		}
	}, [state.messages]);
	useEffect(() => {
		return () => {
			if (reloadThreadTimerRef.current) {
				clearTimeout(reloadThreadTimerRef.current);
				reloadThreadTimerRef.current = null;
			}
			manager.cancelThreadReload();
			reloadThreadFetchMessagesCallbackRef.current = () => {};
		};
	}, [manager]);
	useEffect(() => {
		if (availableCommands.length === 0 && !copilotFeatureFlags.taskWithinChatThread) return;
		const newCommand = extractChatCommandType(text, availableCommands.map((cmd) => cmd.key));
		if (command !== newCommand) {
			setCommand(newCommand);
			onChatCommandChange?.(newCommand);
		}
	}, [
		text,
		command,
		onChatCommandChange,
		availableCommands
	]);
	return {
		typingHasStarted,
		textAreaRef,
		textareaPreviewRef,
		textAreaPreviewContainerRef,
		text,
		setText,
		isAgentTaskSubmitInProgress,
		command,
		setCommand,
		handleSubmit,
		handleSubmitToNewThread,
		handleScroll: throttledHandleScroll,
		handleChange,
		handleStop,
		handleFocus,
		lastUsedRepo,
		setLastUsedRepo,
		selectedRepo,
		setSelectedRepo: onSelectRepo,
		selectedBranch,
		setSelectedBranch,
		selectedAgent,
		setSelectedAgent,
		initialRepoNWO
	};
}
function getPromptFromSearchParams(mode, pathname, searchParams) {
	if (mode === "immersive" && /^\/copilot(\/agents|\/spaces\/[a-zA-Z0-9-_]+\/[0-9]+)?\/?$/.test(pathname)) {
		const prompt = searchParams.get("prompt");
		if (prompt) return prompt;
	}
}
function sendVisionErrorEvent(type, context) {
	sendEvent("dotcom_chat.vision.error", {
		type,
		...context
	});
}
var ACCEPTED_BASE64_IMAGE_FILE_MIME_TYPES = [
	"image/gif",
	"image/jpeg",
	"image/png",
	"image/webp"
];
var DOTCOM_CHAT_ATTACHMENT_LIMIT = 1;
var DOTCOM_CHAT_ATTACHMENT_LIMIT_MULTIPLE = 4;
var DOTCOM_CHAT_ATTACHMENT_SIZE_LIMIT = 3.75 * 1024 * 1024;
var CopilotImageAttacher = class CopilotImageAttacher {
	state;
	manager;
	constructor(state, manager) {
		this.state = state;
		this.manager = manager;
	}
	static getAllowedImageFileExtensions(model) {
		return this.getFileExtensions(model).join(",");
	}
	static isTypeAllowed(itemType, model) {
		itemType = itemType.toLowerCase();
		return this.getMimeTypes(model).includes(itemType);
	}
	static getAllowedFiles(files, model) {
		const [allowedImages, otherFiles] = files.reduce(([images, other], file) => this.isTypeAllowed(file.type, model) ? [[...images, file], other] : [images, [...other, file]], [[], []]);
		return [allowedImages, otherFiles];
	}
	static getAttachmentLimit() {
		return copilotFeatureFlags.attachMultipleImages ? DOTCOM_CHAT_ATTACHMENT_LIMIT_MULTIPLE : DOTCOM_CHAT_ATTACHMENT_LIMIT;
	}
	static getAttachmentSizeLimit() {
		return DOTCOM_CHAT_ATTACHMENT_SIZE_LIMIT;
	}
	static makeImageReference(file, threadIDToAssociate) {
		const referenceId = crypto.randomUUID();
		return {
			id: referenceId,
			attachment: new UploadableFileAttachment(referenceId, file, threadIDToAssociate),
			type: "image",
			name: file.name || "Image"
		};
	}
	static getFileExtensions(model) {
		if (Array.isArray(model)) {
			const extensions = model.flatMap((m) => this.getFileExtensions(m));
			return Array.from(new Set(extensions));
		}
		const extensions = this.getMimeTypes(model).map((type) => `.${type.split("/")[1]}`);
		if (extensions.includes(".jpeg")) extensions.push(".jpg");
		return extensions;
	}
	static getMimeTypes(model) {
		if (Array.isArray(model)) {
			const allowedTypes = model.flatMap((m) => this.getMimeTypes(m));
			return Array.from(new Set(allowedTypes));
		}
		if (model.capabilities.limits.vision) return model.capabilities.limits.vision.supported_media_types.filter((type) => ACCEPTED_BASE64_IMAGE_FILE_MIME_TYPES.includes(type));
		return [];
	}
	/**
	* Adds image attachments to the current chat thread. If no thread is selected and file upload is enabled,
	* a new thread will be created.
	*
	* @param files - The list of image files to attach.
	* @param uploadType - The type of upload action (e.g., 'drag', 'paste', 'menu', or 'unknown').
	* @param customCopilotId - (Optional) A custom Copilot ID to associate with the thread being created.
	* @param preventThreadSelection - (Optional) If true, prevents the selection of the thread being created. By default, it is false.
	*/
	async addImageAttachments(files, uploadType = "unknown") {
		if (files.length === 0) return [];
		if (copilotFeatureFlags.previewFeaturesVisionGate && this.state.hasCEorCBAccess && !this.state.optedInToPreviewFeatures) {
			this.manager.addAmbientError("Copilot in GitHub.com preview features must be enabled to upload images. Please request access from your administrator and try again.");
			sendVisionErrorEvent("preview_features_not_enabled");
			return [];
		}
		const imageReferenceCount = this.state.currentReferences.filter((reference) => reference.type === "image").length;
		const imageLimit = CopilotImageAttacher.getAttachmentLimit();
		if (imageReferenceCount + files.length > imageLimit) {
			const errorMessage = copilotFeatureFlags.attachMultipleImages ? `You can add up to ${imageLimit} image files per message.` : "Only one image can be uploaded at a time";
			this.manager.addAmbientError(errorMessage);
			sendVisionErrorEvent("file_limit_reached");
			return [];
		}
		const newReferences = [];
		const validFilesWithPlaceholders = [];
		for (const file of files) {
			if (!CopilotImageAttacher.isTypeAllowed(file.type, this.state.model)) {
				sendVisionErrorEvent("included_unsupported_file", {
					fileTypes: file.type,
					uploadType
				});
				return [];
			}
			if (file.size > CopilotImageAttacher.getAttachmentSizeLimit()) {
				this.manager.addAmbientError("Only images below 3.75MB are supported");
				sendVisionErrorEvent("size_limit_exceeded", { size: file.size });
				return [];
			}
			const reference = CopilotImageAttacher.makeImageReference(file, this.state.selectedThreadID);
			if (this.state.model.id.startsWith("claude") && this.state.model.capabilities.supports.vision) {
				const dimensions = await reference.attachment.getDimensions();
				if (dimensions.width && dimensions.height) {
					if (dimensions.width > 8e3 || dimensions.height > 8e3) {
						this.manager.addAmbientError("The image you uploaded exceeds the maximum allowed dimensions for Claude models. Please try again with another model.");
						sendVisionErrorEvent("dimension_limit_exceeded", {
							width: dimensions.width,
							height: dimensions.height
						});
						continue;
					}
				}
			}
			const placeholder = makePlaceholderReference(file.name);
			this.manager.addReference(placeholder, "image-attacher");
			if (validFilesWithPlaceholders.length === 0) this.manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: true,
				attachmentType: "file-upload"
			});
			validFilesWithPlaceholders.push({
				file,
				placeholder,
				reference
			});
		}
		try {
			validFilesWithPlaceholders.forEach(({ file, placeholder, reference }) => {
				try {
					this.manager.setImageAttachmentUploaded(reference.id, reference.attachment);
					this.manager.replaceReference(placeholder, reference);
					sendEvent("dotcom_chat.vision.image_added", { uploadType });
					newReferences.push(reference);
				} catch (error) {
					this.manager.removeReference(placeholder);
					const UNEXPECTED_ERROR = `An unexpected error occurred while reading the file`;
					if (typeof error === "string") {
						this.manager.addAmbientError(`An error occurred uploading the attachment ${file.name}`);
						sendVisionErrorEvent("ErrorString", { message: error });
						throw Error(error);
					} else if (error instanceof Error) {
						sendVisionErrorEvent(error.name, { message: error.message });
						if (error.name === "GenericServerError" && error.message.includes("Error creating policy")) this.manager.addAmbientError(UNEXPECTED_ERROR);
						else {
							this.manager.addAmbientError(UNEXPECTED_ERROR);
							throw error;
						}
					} else {
						this.manager.addAmbientError(UNEXPECTED_ERROR);
						throw error;
					}
				}
			});
		} finally {
			this.manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: false
			});
		}
		return newReferences;
	}
};
var TEXT_ATTACHMENT_SIZE_LIMIT = 500 * 1024;
var CLIPBOARD_MIME_TYPE = "application/x.clipboard";
var FILE_NAME_REGEX = /^\s*`?([\w-_]{3,40}\.\w{1,10})`?\s*$/;
var PREFERRED_MAX_FILE_NAME_LENGTH = 20;
var CopilotTextAttacher = class CopilotTextAttacher {
	manager;
	existingFileNames;
	constructor(manager, existingFileNames = /* @__PURE__ */ new Set()) {
		this.manager = manager;
		this.existingFileNames = existingFileNames;
	}
	static async isAttachable(file) {
		if (file.size > CopilotTextAttacher.getAttachmentSizeLimit()) return false;
		const text = await file.text();
		return CopilotTextAttacher.isPlainText(text);
	}
	static fileExtensionsCache;
	static getTextFileExtensions() {
		return CopilotTextAttacher.fileExtensionsCache ??= Object.values(languageMap).flatMap((l) => l.extensions ?? []).filter((ext) => ext !== "stl").join(",");
	}
	static getAttachmentSizeLimit() {
		return TEXT_ATTACHMENT_SIZE_LIMIT;
	}
	/**
	* Heuristically detect if a string is plain text (as opposed to binary) by counting null bytes and non-ASCII
	* characters.
	*/
	static isPlainText(data) {
		const sampleSize = Math.min(data.length, 1e3);
		let nullBytes = 0;
		let nonAsciiChars = 0;
		for (let i = 0; i < sampleSize; i++) {
			const charCode = data.charCodeAt(i);
			if (charCode === 0) nullBytes++;
			else if (charCode > 127) nonAsciiChars++;
		}
		const nullByteRatio = nullBytes / sampleSize;
		const nonAsciiRatio = nonAsciiChars / sampleSize;
		return nullByteRatio <= .1 && nonAsciiRatio <= .2;
	}
	async makeReference(file, namePromise) {
		const text = await file.text();
		const name = file.name || (namePromise ? await namePromise : await this.generateFileName(text, file.type));
		return this.makeReferenceSync(text, name);
	}
	makeReferenceSync(text, name) {
		sendEvent("copilot.attach_pasted_file", {
			extension: name.split(".").pop(),
			characters: text.length
		});
		return {
			type: "thread-scoped-file",
			name,
			text,
			language: ""
		};
	}
	async addAttachment(file, namePromise, name) {
		if (file.size > CopilotTextAttacher.getAttachmentSizeLimit()) {
			this.manager.addAmbientError("Attached text files must be smaller than 500KB");
			return;
		}
		const text = await file.text();
		if (!CopilotTextAttacher.isPlainText(text)) {
			this.manager.addAmbientError(`"${file.name}" has an unsupported file type. Please try again with a plain text file`);
			return;
		}
		let reference;
		if (name) {
			reference = this.makeReferenceSync(text, name);
			this.manager.addReference(reference, "text-attacher");
		} else {
			const placeholder = makePlaceholderReference(file.name);
			this.manager.addReference(placeholder, "text-attacher");
			this.manager.dispatch({
				type: "WAITING_ON_ATTACHMENT",
				loading: true,
				attachmentType: "file-upload"
			});
			try {
				reference = await this.makeReference(file, namePromise);
				this.manager.replaceReference(placeholder, reference);
			} catch {
				this.manager.addAmbientError("Failed to process file. Please try again.");
				this.manager.removeReference(placeholder);
			} finally {
				this.manager.dispatch({
					type: "WAITING_ON_ATTACHMENT",
					loading: false
				});
			}
		}
		return reference;
	}
	async generateFileName(text, type) {
		const namingConventionPrompt = this.existingFileNames.size > 0 ? `\n\nFollow the naming formats used by these existing files: ${Array.from(this.existingFileNames).slice(0, 5).join(", ")}` : "";
		const nameResponse = await this.manager.service.getSimpleCompletion(`Return a suitable filename for the following file contents.
      Follow the file naming conventions of the language and do not include any special characters except for period, underscore or hyphens.
      Try to limit the name to ${PREFERRED_MAX_FILE_NAME_LENGTH} characters or less.
      You MUST include the file extension. Include only the filename in your response and nothing else.${namingConventionPrompt}

File contents:
\`\`\`
${text}
\`\`\`
`);
		const name = nameResponse.ok ? FILE_NAME_REGEX.exec(nameResponse.payload)?.[1] : null;
		if (name) sendEvent("copilot.generate_pasted_file_name.success");
		else sendEvent("copilot.generate_pasted_file_name.failure");
		return this.uniqueFileName(name ?? this.defaultFileName(type));
	}
	uniqueFileName(name) {
		if (!this.existingFileNames.has(name)) return name;
		const lastDotIndex = name.lastIndexOf(".");
		const hasExtension = lastDotIndex > 0 && lastDotIndex < name.length - 1;
		const baseName = hasExtension ? name.substring(0, lastDotIndex) : name;
		const extension = hasExtension ? name.substring(lastDotIndex) : "";
		let counter = 2;
		while (this.existingFileNames.has(`${baseName}${counter}${extension}`)) counter++;
		return `${baseName}${counter}${extension}`;
	}
	defaultFileName(mimeType) {
		switch (mimeType) {
			case CLIPBOARD_MIME_TYPE: return "pasted.txt";
			default: return "untitled.txt";
		}
	}
};
var AgentCapabilitiesPopover_module_default = {
	heading: "AgentCapabilitiesPopover-module_z7iQwa_heading",
	popover: "AgentCapabilitiesPopover-module_z7iQwa_popover",
	popoverAnchor: "AgentCapabilitiesPopover-module_z7iQwa_popoverAnchor",
	text: "AgentCapabilitiesPopover-module_z7iQwa_text"
};
var CHANGELOG_URL = "https://docs.github.com/early-access/github/articles/cca-march-update";
function AgentCapabilitiesPopover(t0) {
	const $ = c(9);
	const { onDismiss } = t0;
	const shownEventSentRef = useRef(false);
	let t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			if (!shownEventSentRef.current) {
				shownEventSentRef.current = true;
				sendEvent("dotcom_chat.activate", {
					target: "AGENT_CAPABILITIES_TOOLTIP",
					action: "shown"
				});
			}
		};
		t2 = [];
		$[0] = t1;
		$[1] = t2;
	} else {
		t1 = $[0];
		t2 = $[1];
	}
	useEffect(t1, t2);
	let t3;
	if ($[2] !== onDismiss) {
		t3 = () => {
			copilotLocalStorage.setAgentCapabilitiesTooltipDismissed();
			onDismiss();
			sendEvent("dotcom_chat.activate", {
				target: "AGENT_CAPABILITIES_TOOLTIP",
				action: "dismiss"
			});
		};
		$[2] = onDismiss;
		$[3] = t3;
	} else t3 = $[3];
	const dismiss = t3;
	let t4;
	let t5;
	if ($[4] !== onDismiss) {
		t4 = () => {
			const handleKeyDown = (e) => {
				if (e.key === "Escape" && !e.defaultPrevented) {
					onDismiss();
					sendEvent("dotcom_chat.activate", {
						target: "AGENT_CAPABILITIES_TOOLTIP",
						action: "dismiss_temporary"
					});
				}
			};
			document.addEventListener("keydown", handleKeyDown);
			return () => document.removeEventListener("keydown", handleKeyDown);
		};
		t5 = [onDismiss];
		$[4] = onDismiss;
		$[5] = t4;
		$[6] = t5;
	} else {
		t4 = $[5];
		t5 = $[6];
	}
	useEffect(t4, t5);
	let t6;
	if ($[7] !== dismiss) {
		t6 = jsx("div", {
			className: AgentCapabilitiesPopover_module_default.popoverAnchor,
			children: jsx(Popover_default, {
				open: true,
				caret: "top-left",
				className: AgentCapabilitiesPopover_module_default.popover,
				children: jsxs(Popover_default.Content, {
					"aria-label": "New Agent mode",
					children: [
						jsxs(Heading$2, {
							as: "h2",
							variant: "small",
							className: AgentCapabilitiesPopover_module_default.heading,
							children: ["Agent mode", jsx(Label, {
								variant: "accent",
								children: "New"
							})]
						}),
						jsxs("p", {
							className: AgentCapabilitiesPopover_module_default.text,
							children: [
								"Agents now support a broader set of functionality, like helping you create an implementation plan or conducting deep research on a codebase.",
								" ",
								jsx(Link, {
									inline: true,
									href: CHANGELOG_URL,
									target: "_blank",
									rel: "noopener noreferrer",
									onClick: _temp$16,
									children: "Learn more about Copilot coding agent"
								})
							]
						}),
						jsx(ButtonComponent, {
							size: "small",
							onClick: dismiss,
							children: "Got it!"
						})
					]
				})
			})
		});
		$[7] = dismiss;
		$[8] = t6;
	} else t6 = $[8];
	return t6;
}
AgentCapabilitiesPopover.displayName = "AgentCapabilitiesPopover";
function _temp$16() {
	return sendEvent("dotcom_chat.activate", {
		target: "AGENT_CAPABILITIES_TOOLTIP",
		action: "read_more"
	});
}
var CopilotSpaceNotFoundError = class extends Error {
	constructor(message = "Copilot Space not found") {
		super(message);
		this.name = "CopilotSpaceNotFoundError";
	}
};
var CopilotSpaceSSOError = class extends Error {
	protectedOrganizations;
	constructor(protectedOrganizations, message = "Copilot Space SSO error") {
		super(message);
		this.protectedOrganizations = protectedOrganizations;
		this.name = "CopilotSpaceSSOError";
	}
};
function hasCopilotSpaceData(payload) {
	return payload.id !== void 0;
}
function useFetchCopilotSpace(customCopilotId) {
	return useQuery({
		queryKey: copilotSpacesQueryKey(customCopilotId),
		queryFn: async () => {
			const response = await fetchCopilotSpace(customCopilotId);
			if (!response.ok) {
				if (response.status === 404) throw new CopilotSpaceNotFoundError();
				throw new Error(response.error);
			}
			if (!hasCopilotSpaceData(response.payload)) throw new CopilotSpaceSSOError(response.payload.protectedOrganizations);
			return response.payload;
		},
		enabled: !!customCopilotId
	});
}
/**
* Custom copilots are enabled for:
* 1. users with the :copilot_custom_copilots feature flag, which some will be individually opted into
* 2. The following types of users with the :copilot_custom_copilots_feature_preview feature flag:
*    a. users with Copilot Individual (CI) licenses, for whom preview features are always enabled
*    b. CB and CE users whose orgs have opted into preview features
*    c. Copilot Free users, signified by `has_limited_access` on their plan
* This values is serialized down from the copilot_chat_helper and put into the chat state.
*/
function useCustomCopilotsEnabled() {
	return useChatStateValue("customCopilotsEnabled");
}
/**
* Hook that returns the current number of Copilot spaces.
*
* @returns The total count of existing Copilot spaces
*/
function useNumberOfSpaces() {
	return useChatStateValue("customCopilots")?.length ?? 0;
}
function useAutoSpaceName() {
	const copilotSpacesCount = useNumberOfSpaces();
	return useMemo(() => `New Space ${copilotSpacesCount + 1}`, [copilotSpacesCount]);
}
var useUpsertCopilotSpace = (id) => {
	const manager = useChatManager();
	const queryClient = useQueryClient();
	const { mutateAsync: upsertCopilotSpace, ...rest } = useMutation({
		onSuccess: async () => {
			queryClient.invalidateQueries({ queryKey: COPILOT_SPACES_QUERY_KEY });
			if (id) await queryClient.invalidateQueries({ queryKey: copilotSpacesQueryKey(id) });
		},
		mutationFn: async (input) => {
			const response = await verifiedFetchJSON(id ? customCopilotApiPath(id) : "/custom_copilots", {
				method: id ? "PUT" : "POST",
				body: { custom_copilot: {
					owner_id: input.ownerId,
					owner_type: input.ownerType,
					name: input.name,
					icon_type: input.iconType,
					icon_color: input.iconColor,
					description: input.description,
					general_instructions: input.generalInstructions,
					resources_attributes: input.resources?.map((r) => ({
						id: r.databaseId,
						copilot_chat_attachment_id: r.copilotChatAttachmentId,
						resource_type: r.type,
						_destroy: r.markedForDestroy,
						metadata: resourceMetadataToRailsPayload(r)
					})),
					visibility: input.visibility,
					base_role: input.baseRole
				} }
			});
			const data = await response.json();
			if (!response.ok) throw data.errorMessages;
			manager?.dispatch({
				type: "SET_CUSTOM_COPILOT",
				customCopilot: data
			});
			return data;
		}
	});
	return {
		upsertCopilotSpace,
		...rest
	};
};
var CreateSpaceDialog_module_default = { createSpaceDialog: "CreateSpaceDialog-module_ZlvN_q_createSpaceDialog" };
/**
* Determines which resources can be saved when duplicating a space to a new owner
* and which will not transfer due to access restrictions.
*
* Private resources owned by a different organization/user than the target owner
* will not be transferable if the target owner is an Organization.
*
* If the target owner is an individual user, all resources can be transferred.
*
* @param resources - The resources from the original space
* @param targetOwner - The new owner for the duplicated space
* @returns An object containing resources that can be saved and those that cannot transfer
*/
function resourcesForDuplication(resources, targetOwner) {
	const resourcesToSave = [];
	const resourcesThatWillNotTransfer = [];
	if (targetOwner.type === "Organization" && !targetOwner.allowsPrivateReposFromOtherOrgs) {
		for (const resource of resources) if ("ownerId" in resource && "private" in resource && resource.private && resource.ownerId !== targetOwner.id) resourcesThatWillNotTransfer.push(resource);
		else resourcesToSave.push(resource);
		return {
			resourcesToSave,
			resourcesThatWillNotTransfer
		};
	} else return {
		resourcesToSave: resources,
		resourcesThatWillNotTransfer: []
	};
}
function CreateSpaceDialog({ dialogTitle = "New Space", closeDialog, initialSpace, onSubmit, returnFocusRef }) {
	const navigate = useNavigate$1();
	const nameInputRef = useRef(null);
	const defaultName = useAutoSpaceName();
	const [name, setName] = useState(initialSpace?.name ?? defaultName);
	const [owner, setOwner] = useState(null);
	const [errorMessages, setErrorMessages] = useState({});
	const [genericErrorSavingSpace, setGenericErrorSavingSpace] = useState(false);
	const { upsertCopilotSpace, isPending: isSaving } = useUpsertCopilotSpace();
	const confirm = useConfirm();
	const clearErrors = useCallback((fields) => {
		setGenericErrorSavingSpace(false);
		const updatedErrorMessages = { ...errorMessages };
		for (const field of fields) if (updatedErrorMessages[field]) delete updatedErrorMessages[field];
		setErrorMessages(updatedErrorMessages);
	}, [errorMessages]);
	const dropdownOnSelect = useCallback((newOwner) => setOwner(newOwner), []);
	useEffect(() => {
		sendEvent("copilot_spaces.create_space_v3_dialog_opened", {});
	}, []);
	useEffect(() => {
		nameInputRef.current?.focus();
	}, [errorMessages.name, errorMessages.slug]);
	useEffect(() => {
		if (initialSpace) nameInputRef.current?.focus();
		else nameInputRef.current?.select();
	}, [initialSpace]);
	const saveSpace = async () => {
		if (isSaving) return;
		let resourcesToSave = initialSpace?.resources ? [...initialSpace.resources] : [];
		let resourcesThatWillNotTransfer = [];
		if (initialSpace && owner) {
			const duplicationResult = resourcesForDuplication(initialSpace.resources || [], owner);
			resourcesToSave = duplicationResult.resourcesToSave;
			resourcesThatWillNotTransfer = duplicationResult.resourcesThatWillNotTransfer;
		}
		let confirmed = true;
		if (resourcesThatWillNotTransfer.length > 0) confirmed = await confirm({
			title: "Some resources will not be duplicated",
			content: /* @__PURE__ */ jsx(UnsafeHTMLText, { html: `Private resources owned by <strong>${new Intl.ListFormat().format(Array.from(new Set(resourcesThatWillNotTransfer.map((r) => r.ownerLogin).filter((login) => login !== void 0))))}</strong> will not be duplicated to the new space.` }),
			cancelButtonContent: "Never mind",
			confirmButtonContent: "Continue",
			confirmButtonType: "primary"
		});
		if (!confirmed) return;
		try {
			const newSpace = await upsertCopilotSpace({
				name,
				ownerId: owner?.id,
				ownerType: owner?.type,
				resources: resourcesToSave,
				generalInstructions: initialSpace?.generalInstructions
			});
			setErrorMessages({});
			setGenericErrorSavingSpace(false);
			closeDialog();
			onSubmit?.();
			copilotLocalStorage.setLastSelectedSpace(newSpace);
			return navigate(getCopilotSpacePath(newSpace));
		} catch (errors) {
			if (errors && typeof errors === "object" && Object.keys(errors).length > 0) {
				setGenericErrorSavingSpace(false);
				setErrorMessages(errors);
			} else {
				setErrorMessages({});
				setGenericErrorSavingSpace(true);
			}
		}
	};
	const handleCancel = () => {
		closeDialog();
		setTimeout(() => returnFocusRef?.current?.focus(), 0);
	};
	return /* @__PURE__ */ jsx(Dialog, {
		position: { narrow: "fullscreen" },
		title: dialogTitle,
		onClose: handleCancel,
		width: "large",
		"aria-label": dialogTitle,
		className: CreateSpaceDialog_module_default.createSpaceDialog,
		renderFooter: () => /* @__PURE__ */ jsx(SpaceDialogFooter, {
			onCancel: handleCancel,
			onSave: saveSpace,
			isLoading: isSaving,
			disabled: !owner,
			saveButtonText: "Create Space"
		}),
		children: /* @__PURE__ */ jsxs("form", {
			onSubmit: async (e) => {
				e.preventDefault();
				e.stopPropagation();
				await saveSpace();
			},
			children: [genericErrorSavingSpace && /* @__PURE__ */ jsx(Banner, {
				className: "tmp-mb-3",
				variant: "critical",
				title: "Error saving space",
				hideTitle: true,
				description: "Something went wrong while saving."
			}), /* @__PURE__ */ jsxs(Stack, { children: [/* @__PURE__ */ jsxs(FormControl$1, { children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, {
					required: true,
					children: "Space name"
				}),
				/* @__PURE__ */ jsx(TextInput$1, {
					ref: nameInputRef,
					autoFocus: true,
					block: true,
					"data-testid": "copilot-space-name-input",
					name: "copilot-space-name",
					value: name,
					onChange: (e) => {
						setName(e.target.value);
						clearErrors(["name", "slug"]);
					}
				}),
				/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Choose a name that describes your project or use case" }),
				errorMessages.name ? /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: /* @__PURE__ */ jsxs("span", { children: ["Name ", errorMessages.name] })
				}) : errorMessages.slug ? /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: /* @__PURE__ */ jsx("span", { children: SLUG_ERROR_MESSAGE })
				}) : null
			] }), /* @__PURE__ */ jsx(SpacesOwnerDropdown, { onSelect: dropdownOnSelect })] })]
		})
	});
}
CreateSpaceDialog.displayName = "CreateSpaceDialog";
var SEARCH_DEBOUNCE_MS = 350;
var MAX_SPACE_NAME_LENGTH = 40;
var StarredIcon = () => /* @__PURE__ */ jsx("span", {
	role: "img",
	"aria-label": "Starred",
	style: { color: "var(--button-star-iconColor)" },
	children: /* @__PURE__ */ jsx(StarFillIcon, {})
});
StarredIcon.displayName = "StarredIcon";
var getSpaceKey = (space) => `${space.owner}-${space.id}`;
function SpacesSelectNew({ openCreateSpaceDialog, setPendingSpace, clearSpaceSelection, activeCopilotSpaceId, readOnly }) {
	const manager = useChatManager();
	const [open, setOpen] = useState(false);
	const debounceTimeoutRef = useRef(null);
	const [filter, setFilter] = useState("");
	const [debouncedFilter, setDebouncedFilter] = useState("");
	const [filteredSpaces, setFilteredSpaces] = useState([]);
	const [loading, setLoading] = useState(false);
	const [showCreateSpace, setShowCreateSpace] = useState(false);
	useEffect(() => {
		setShowCreateSpace(window.location.pathname.startsWith(COPILOT_PATH));
	}, []);
	const handleMenuOpen = (value) => {
		if (value) sendEvent("dotcom_chat.activate", {
			target: "ATTACHMENT_MENU_COPILOT_SPACES",
			mode: "immersive"
		});
		setOpen(value);
	};
	const handleCreateSpace = () => {
		setOpen(false);
		openCreateSpaceDialog(true);
		sendEvent("dotcom_chat.activate", {
			target: "ATTACHMENT_MENU_COPILOT_SPACES_CREATE_SPACE",
			mode: "immersive"
		});
	};
	const handleSpaceSelect = useCallback((space) => {
		if (activeCopilotSpaceId && space.id === activeCopilotSpaceId.id && space.owner === activeCopilotSpaceId.owner) clearSpaceSelection();
		else {
			manager.addReference({
				...space,
				type: "copilot-space"
			}, "spaces");
			setPendingSpace({
				id: space.id,
				owner: space.owner
			});
			sendEvent("dotcom_chat.activate", {
				target: "ATTACHMENT_MENU_COPILOT_SPACES_SELECT_SPACE",
				space: `${space.owner}/${space.id}`
			});
		}
		setOpen(false);
	}, [
		activeCopilotSpaceId,
		clearSpaceSelection,
		manager,
		setPendingSpace
	]);
	const fetchResults = useCallback(async (searchQuery) => {
		try {
			const res = await verifiedFetchJSON(`/github-copilot/chat/custom_copilots/search?${new URLSearchParams({ q: searchQuery }).toString()}`);
			if (!res.ok) throw new Error("Failed to fetch spaces");
			return await res.json();
		} catch {
			return [];
		}
	}, []);
	useEffect(() => {
		let cancelled = false;
		const fetchAndSetSpaces = async () => {
			if (!open) return;
			setLoading(true);
			const spaces = await fetchResults(debouncedFilter);
			if (cancelled) return;
			setFilteredSpaces(spaces);
			setLoading(false);
		};
		fetchAndSetSpaces();
		return () => {
			cancelled = true;
		};
	}, [
		fetchResults,
		debouncedFilter,
		open
	]);
	useEffect(() => {
		return () => {
			if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
		};
	}, []);
	const onSelectedChange = (selectedItem) => {
		const selectedSpace = filteredSpaces.find((space) => getSpaceKey(space) === selectedItem?.id);
		if (selectedSpace) {
			handleSpaceSelect(selectedSpace);
			copilotLocalStorage.setLastSelectedSpace(selectedSpace);
		}
	};
	const copilotSpacesEnabled = useCustomCopilotsEnabled();
	const items = useMemo(() => filteredSpaces.map((space) => ({
		id: getSpaceKey(space),
		key: getSpaceKey(space),
		text: space.name.length > MAX_SPACE_NAME_LENGTH ? `${space.name.slice(0, MAX_SPACE_NAME_LENGTH)}...` : space.name,
		description: space.owner,
		descriptionVariant: "inline",
		value: getSpaceKey(space),
		trailingVisual: space.starred ? StarredIcon : void 0
	})), [filteredSpaces]);
	if (!copilotSpacesEnabled || readOnly) return null;
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(SelectPanel$1, {
		align: "end",
		title: "Select a space",
		subtitle: "Recent spaces",
		renderAnchor: (props) => /* @__PURE__ */ jsxs(ActionList.Item, {
			as: "button",
			...props,
			children: [
				/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(SpaceIcon, {}) }),
				"Spaces…",
				/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(ChevronRightIcon, {}) })
			]
		}),
		open,
		onOpenChange: handleMenuOpen,
		loading,
		items,
		filterValue: filter,
		onFilterChange: (value) => {
			setFilter(value);
			if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
			debounceTimeoutRef.current = setTimeout(() => {
				setDebouncedFilter(value);
			}, SEARCH_DEBOUNCE_MS);
		},
		selected: activeCopilotSpaceId ? items.find((item) => item.id === getSpaceKey(activeCopilotSpaceId)) : void 0,
		onSelectedChange,
		overlayProps: {
			height: "auto",
			width: "large",
			anchorSide: "outside-right"
		},
		message: filteredSpaces.length === 0 && !loading ? {
			title: "No spaces found",
			body: "You can create a new space to get started.",
			variant: "empty",
			action: /* @__PURE__ */ jsx(ButtonComponent, {
				variant: "default",
				size: "small",
				onClick: handleCreateSpace,
				children: "Create a new space"
			})
		} : void 0,
		secondaryAction: showCreateSpace && filteredSpaces.length > 0 ? /* @__PURE__ */ jsx(SelectPanel$1.SecondaryActionButton, {
			onClick: handleCreateSpace,
			children: "Create a space"
		}) : void 0
	}) });
}
SpacesSelectNew.displayName = "SpacesSelectNew";
/**
* Generates a label for the multi-file-picker menu item based on which reference types are supported.
*/
function getReferenceTypeLabel(supportedReferenceTypes) {
	const includeFiles = supportedReferenceTypes.includes("files");
	const includeFolders = supportedReferenceTypes.includes("folders");
	const includeSymbols = supportedReferenceTypes.includes("symbols");
	if (includeFiles && includeFolders && includeSymbols) return "Files, folders, and symbols";
	if (includeFiles && includeFolders) return "Files and folders";
	if (includeFiles && includeSymbols) return "Files and symbols";
	if (includeFolders && includeSymbols) return "Folders and symbols";
	if (includeFiles) return "Files";
	if (includeFolders) return "Folders";
	if (includeSymbols) return "Symbols";
	return "References";
}
/**
* Returns the supported attachment types and reference types based on the current state of the chat.
* Reference types are specifically used in the ReferencesSelectPanel component.
*/
function useSupportedAttachmentTypes() {
	const $ = c(2);
	const isCopilotSpaceAttachments = useSelectedCopilotSpaceId() !== null;
	let t0;
	if ($[0] !== isCopilotSpaceAttachments) {
		const supportedAttachmentTypes = ["upload"];
		if (!isCopilotSpaceAttachments) supportedAttachmentTypes.push("repositories");
		if (!isCopilotSpaceAttachments) supportedAttachmentTypes.push("copilot-spaces");
		if (!isCopilotSpaceAttachments) supportedAttachmentTypes.push("agents");
		if (!isCopilotSpaceAttachments) supportedAttachmentTypes.push("plugin-attachment-contribution");
		t0 = {
			supportedAttachmentTypes,
			supportedReferenceTypes: isCopilotSpaceAttachments ? ["files"] : ["files", "folders"]
		};
		$[0] = isCopilotSpaceAttachments;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function AgentMenu(t0) {
	const $ = c(12);
	const { onSelectPanel, onSelectAgent } = t0;
	const { availableAgents, showLimit, disabled, loading } = useAvailableAgents();
	const agentsAreAvailable = availableAgents && availableAgents.length > 0;
	if (loading) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsxs(ActionList.Item, {
				disabled: true,
				children: [jsx(ActionList.LeadingVisual, { children: jsx(AppsIcon, {}) }), "Extensions…"]
			});
			$[0] = t1;
		} else t1 = $[0];
		return t1;
	}
	if (disabled) {
		let t1;
		if ($[1] !== onSelectPanel) {
			t1 = jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("dotcom_chat.activate", {
						target: "ATTACHMENT_MENU_EXTENSION_NOT_SUPPORTED",
						mode: "immersive"
					});
					onSelectPanel("agents-not-supported");
				},
				children: [jsx(ActionList.LeadingVisual, { children: jsx(AppsIcon, {}) }), "Extensions…"]
			});
			$[1] = onSelectPanel;
			$[2] = t1;
		} else t1 = $[2];
		return t1;
	}
	if (!agentsAreAvailable) {
		let t1;
		if ($[3] !== onSelectPanel) {
			t1 = jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("dotcom_chat.activate", {
						target: "ATTACHMENT_MENU_EXTENSION_NOT_AVAILABLE",
						mode: "immersive"
					});
					onSelectPanel("no-agents-available");
				},
				children: [jsx(ActionList.LeadingVisual, { children: jsx(AppsIcon, {}) }), "Extensions…"]
			});
			$[3] = onSelectPanel;
			$[4] = t1;
		} else t1 = $[4];
		return t1;
	}
	let t1;
	if ($[5] !== availableAgents || $[6] !== onSelectAgent || $[7] !== showLimit) {
		let t2;
		if ($[9] !== onSelectAgent || $[10] !== showLimit) {
			t2 = (agent) => jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("dotcom_chat.activate", {
						target: "ATTACHMENT_MENU_EXTENSION_SELECTED",
						mode: "immersive"
					});
					onSelectAgent(agent);
				},
				children: [
					jsx(ActionList.LeadingVisual, { children: jsx(GitHubAvatar, { src: agent.avatarUrl }) }),
					agent.name,
					!showLimit && jsxs(ActionList.Description, {
						variant: "inline",
						truncate: true,
						children: ["@", agent.slug]
					}),
					showLimit && jsx(ActionList.Description, {
						variant: "block",
						children: "Start a new chat to use other extensions."
					})
				]
			}, agent.slug);
			$[9] = onSelectAgent;
			$[10] = showLimit;
			$[11] = t2;
		} else t2 = $[11];
		t1 = jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsxs(ActionList.Item, {
			onSelect: _temp$15,
			children: [jsx(ActionList.LeadingVisual, { children: jsx(AppsIcon, {}) }), "Extensions…"]
		}) }), jsx(ActionMenu.Overlay, {
			width: "small",
			children: jsxs(ActionList, { children: [
				availableAgents.map(t2),
				jsx(ActionList.Divider, {}),
				jsxs(ActionList.LinkItem, {
					href: AGENTS_MARKETPLACE_URL,
					onClick: _temp2$3,
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(TelescopeIcon, {}) }),
						"Marketplace",
						jsx(ActionList.TrailingVisual, { children: jsx(LinkExternalIcon, {}) })
					]
				})
			] })
		})] });
		$[5] = availableAgents;
		$[6] = onSelectAgent;
		$[7] = showLimit;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
AgentMenu.displayName = "AgentMenu";
function _temp2$3() {
	sendEvent("dotcom_chat.activate", {
		target: "ATTACHMENT_MENU_EXTENSION_MARKETPLACE",
		mode: "immersive"
	});
}
function _temp$15() {
	sendEvent("dotcom_chat.activate", {
		target: "ATTACHMENT_MENU_EXTENSION",
		mode: "immersive"
	});
}
var AgentsDialogs_module_default = {
	AgentsDialogsAlternateContainer: "AgentsDialogs-module_5AEUcq_AgentsDialogsAlternateContainer",
	AgentsDialogsMainContainer: "AgentsDialogs-module_5AEUcq_AgentsDialogsMainContainer",
	alertIconContainer: "AgentsDialogs-module_5AEUcq_alertIconContainer",
	dialogContentWrapper: "AgentsDialogs-module_5AEUcq_dialogContentWrapper",
	dialogDescription: "AgentsDialogs-module_5AEUcq_dialogDescription",
	dialogTitle: "AgentsDialogs-module_5AEUcq_dialogTitle",
	documentationLinkContainer: "AgentsDialogs-module_5AEUcq_documentationLinkContainer"
};
function NoAgentsAvailableDialog({ onClose, returnFocusRef }) {
	return /* @__PURE__ */ jsx(Dialog, {
		width: "large",
		title: "Extensions",
		position: {
			narrow: "fullscreen",
			regular: "center"
		},
		onClose,
		returnFocusRef,
		renderBody: () => /* @__PURE__ */ jsx("div", {
			className: AgentsDialogs_module_default.AgentsDialogsMainContainer,
			children: /* @__PURE__ */ jsxs("div", {
				className: AgentsDialogs_module_default.dialogContentWrapper,
				children: [
					/* @__PURE__ */ jsx(TelescopeIcon, { size: 24 }),
					/* @__PURE__ */ jsx("h3", {
						className: AgentsDialogs_module_default.dialogTitle,
						children: "Chat with your favorite tools and services"
					}),
					/* @__PURE__ */ jsx("p", {
						className: AgentsDialogs_module_default.dialogDescription,
						children: "Browse the marketplace to find extensions for the tools and services you rely on"
					}),
					/* @__PURE__ */ jsx(ButtonComponent, {
						as: "a",
						href: AGENTS_MARKETPLACE_URL,
						children: "Browse marketplace"
					}),
					/* @__PURE__ */ jsx("div", {
						className: AgentsDialogs_module_default.documentationLinkContainer,
						children: /* @__PURE__ */ jsx(Link, {
							href: "https://gh.io/copilot-extensions-docs",
							children: "Documentation"
						})
					})
				]
			})
		})
	});
}
NoAgentsAvailableDialog.displayName = "NoAgentsAvailableDialog";
function AgentsNotSupportedDialog(t0) {
	const $ = c(10);
	const { onClose, returnFocusRef } = t0;
	const manager = useChatManager();
	const state = useChatState();
	const customCopilotsEnabled = useCustomCopilotsEnabled();
	const defaultModel = useDefaultModel(state.availableModels);
	let t1;
	if ($[0] !== customCopilotsEnabled || $[1] !== defaultModel || $[2] !== manager || $[3] !== onClose || $[4] !== returnFocusRef) {
		let t2;
		if ($[6] !== customCopilotsEnabled || $[7] !== defaultModel || $[8] !== manager) {
			t2 = () => jsx("div", {
				className: AgentsDialogs_module_default.AgentsDialogsAlternateContainer,
				children: jsxs("div", {
					className: AgentsDialogs_module_default.dialogContentWrapper,
					children: [
						jsx("div", {
							className: AgentsDialogs_module_default.alertIconContainer,
							children: jsx(AlertIcon, { size: 24 })
						}),
						jsxs("h3", {
							className: AgentsDialogs_module_default.dialogTitle,
							children: [customCopilotsEnabled ? "Copilots and extensions" : "Extensions", " aren't supported by this model"]
						}),
						jsxs("p", {
							className: AgentsDialogs_module_default.dialogDescription,
							children: [
								"Switch back to the ",
								defaultModel.displayName,
								" model or start a new chat"
							]
						}),
						jsx(ButtonComponent, {
							onClick: () => {
								manager.selectThread(null);
								manager.selectModel(defaultModel);
							},
							children: "New chat"
						})
					]
				})
			});
			$[6] = customCopilotsEnabled;
			$[7] = defaultModel;
			$[8] = manager;
			$[9] = t2;
		} else t2 = $[9];
		t1 = jsx(Dialog, {
			width: "large",
			title: "Extensions",
			position: {
				narrow: "fullscreen",
				regular: "center"
			},
			onClose,
			returnFocusRef,
			renderBody: t2
		});
		$[0] = customCopilotsEnabled;
		$[1] = defaultModel;
		$[2] = manager;
		$[3] = onClose;
		$[4] = returnFocusRef;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
AgentsNotSupportedDialog.displayName = "AgentsNotSupportedDialog";
/**
* Fetches repository details from the GitHub Copilot chat API.
* @param repoID - The ID of the repository to fetch
* @returns Promise containing the repository details
* @throws Error if the fetch fails or returns a non-ok response
*/
async function fetchRepo(repoID) {
	const res = await verifiedFetchJSON(`/github-copilot/chat/repositories/${repoID}`, { method: "GET" });
	if (!res.ok) throw new Error(`Failed to fetch repository details: ${res.status}`);
	return await res.json();
}
function buildTreeFromPaths(response) {
	const { paths, directories } = response;
	const treeData = {};
	const directorySet = new Set(directories);
	treeData[""] = {
		items: [],
		totalCount: 0
	};
	const sortedDirectories = [...directories].sort();
	for (const dirPath of sortedDirectories) {
		const parentPath = dirPath.substring(0, dirPath.lastIndexOf("/")) || "";
		const dirItem = {
			name: dirPath.substring(dirPath.lastIndexOf("/") + 1),
			path: dirPath,
			contentType: "directory"
		};
		if (!treeData[parentPath]) treeData[parentPath] = {
			items: [],
			totalCount: 0
		};
		treeData[parentPath].items.push(dirItem);
		if (!treeData[dirPath]) treeData[dirPath] = {
			items: [],
			totalCount: 0
		};
	}
	const sortedPaths = paths.filter((p) => !directorySet.has(p)).sort();
	for (const filePath of sortedPaths) {
		const parentPath = filePath.substring(0, filePath.lastIndexOf("/")) || "";
		const fileItem = {
			name: filePath.substring(filePath.lastIndexOf("/") + 1),
			path: filePath,
			contentType: "file"
		};
		if (!treeData[parentPath]) treeData[parentPath] = {
			items: [],
			totalCount: 0
		};
		treeData[parentPath].items.push(fileItem);
	}
	for (const dirPath in treeData) {
		const dirData = treeData[dirPath];
		if (!dirData) continue;
		dirData.items.sort((a, b) => {
			if (a.contentType === "directory" && b.contentType !== "directory") return -1;
			if (a.contentType !== "directory" && b.contentType === "directory") return 1;
			return a.name.localeCompare(b.name);
		});
	}
	const calculateTotalCount = (path) => {
		const dir = treeData[path];
		if (!dir) return 0;
		return dir.items.reduce((total, item) => {
			if (item.contentType === "directory") return total + 1 + calculateTotalCount(item.path);
			return total + 1;
		}, 0);
	};
	for (const dirPath in treeData) {
		const dirData = treeData[dirPath];
		if (!dirData) continue;
		dirData.totalCount = calculateTotalCount(dirPath);
	}
	return treeData;
}
function convertTreeDataToTreeItems(treeData, path) {
	const directory = treeData[path];
	if (!directory) return [];
	return directory.items.map((item) => ({
		data: item,
		items: item.contentType === "directory" ? convertTreeDataToTreeItems(treeData, item.path) : []
	})).sort((a, b) => {
		if (a.data.contentType === "directory" && b.data.contentType !== "directory") return -1;
		if (a.data.contentType !== "directory" && b.data.contentType === "directory") return 1;
		return a.data.name.localeCompare(b.data.name);
	});
}
function convertFlatPathsToTreeItems(response) {
	return convertTreeDataToTreeItems(buildTreeFromPaths(response), "");
}
/**
* Given a list of file paths that only exist on the client, returns a list of TreeItem<DirectoryItem> objects that represent
* the client-only files and directories.
*/
function getClientItemsToInsert(currentPath, clientOnlyFilePaths, existingItems) {
	const clientOnlyItemsToInsert = [];
	for (const filePath of clientOnlyFilePaths) if (filePath.startsWith(currentPath)) {
		const relativePath = filePath.slice(currentPath.length + 1);
		const nextDirectoryIndex = relativePath.indexOf("/");
		const name = nextDirectoryIndex > 0 ? relativePath.slice(0, nextDirectoryIndex) : relativePath;
		const path = `${currentPath}/${name}`;
		if (existingItems && existingItems.some((item) => item.path === path)) continue;
		const clientOnlyItem = {
			items: [],
			data: {
				contentType: path === filePath ? "file" : "directory",
				name,
				path,
				isClientOnly: true
			}
		};
		clientOnlyItemsToInsert.push(clientOnlyItem);
	}
	return clientOnlyItemsToInsert;
}
function useFetchFolder(directory, dispatchKnownFolders, getItemUrl) {
	const [items, setItems] = React.useState(directory.items);
	const [totalCount, setTotalCount] = React.useState(directory.data.totalCount || 0);
	const [loading, setLoading] = React.useState(false);
	const [error, setError] = React.useState(false);
	const { safeSetTimeout } = useSafeTimeout();
	React.useEffect(() => {
		setItems(directory.items);
	}, [directory.items]);
	React.useEffect(() => {
		if (directory.data.totalCount !== void 0) setTotalCount(directory.data.totalCount);
	}, [directory.data.totalCount]);
	const clearError = React.useCallback(() => {
		setError(false);
	}, []);
	const incrementallyShowItems = React.useCallback((folderItems, newTotalCount) => {
		const newItems = folderItems || [...items];
		setItems(newItems.slice(0, 100));
		safeSetTimeout(() => {
			setItems(newItems);
			if (newTotalCount !== void 0) setTotalCount(newTotalCount);
		}, 1);
	}, [items, safeSetTimeout]);
	return [
		React.useCallback(async (clientOnlyFilePaths) => {
			const newKnownFolders = /* @__PURE__ */ new Map();
			if (!directory.data.isClientOnly) {
				const contentUrl = getItemUrl(directory.data);
				setError(false);
				setLoading(true);
				const start = Date.now();
				const response = await verifiedFetchJSON(`${contentUrl}?noancestors=1`);
				try {
					if (response.ok) {
						const folderPayload = await response.json();
						const folderItems = folderPayload.payload.tree.items.map((payloadItem) => {
							const treeItem = {
								items: [],
								data: { ...payloadItem },
								autoExpand: payloadItem.contentType === "directory" && folderPayload.payload.tree.items.length === 1
							};
							newKnownFolders.set(payloadItem.path, treeItem);
							if (payloadItem.hasSimplifiedPath) return splitSimplifiedTreeItem(treeItem, payloadItem, newKnownFolders);
							return treeItem;
						});
						if (clientOnlyFilePaths) {
							const currentPath = directory.data.path;
							const clientOnlyItemsToInsert = getClientItemsToInsert(currentPath, clientOnlyFilePaths, folderPayload.payload.tree.items);
							folderItems.push(...clientOnlyItemsToInsert);
							for (const item of clientOnlyItemsToInsert) newKnownFolders.set(item.data.path, item);
						}
						dispatchKnownFolders({
							type: "add",
							folders: newKnownFolders,
							processingTime: Date.now() - start
						});
						directory.items = folderItems;
						directory.data.totalCount = folderPayload.payload.tree.totalCount;
						if (folderItems.length > 100) incrementallyShowItems(folderItems, folderPayload.payload.tree.totalCount);
						else {
							setItems(folderItems);
							setTotalCount(folderPayload.payload.tree.totalCount);
						}
					} else setError(true);
				} catch {
					setError(true);
				}
			} else if (clientOnlyFilePaths) {
				const currentPath = directory.data.path;
				const clientOnlyItemsToInsert = getClientItemsToInsert(currentPath, clientOnlyFilePaths);
				for (const item of clientOnlyItemsToInsert) newKnownFolders.set(item.data.path, item);
				dispatchKnownFolders({
					type: "add",
					folders: newKnownFolders,
					processingTime: 0
				});
				if (clientOnlyItemsToInsert.length > 100) incrementallyShowItems(clientOnlyItemsToInsert, clientOnlyItemsToInsert.length);
				else {
					setItems(clientOnlyItemsToInsert);
					setTotalCount(clientOnlyItemsToInsert.length);
				}
			}
			setLoading(false);
		}, [
			getItemUrl,
			directory,
			dispatchKnownFolders,
			incrementallyShowItems
		]),
		incrementallyShowItems,
		items,
		loading,
		error,
		clearError,
		totalCount
	];
}
function splitSimplifiedTreeItem(treeItem, payloadItem, knownFolders) {
	treeItem.data.name = treeItem.data.name.slice(treeItem.data.name.lastIndexOf("/") + 1, treeItem.data.name.length);
	const topItemName = payloadItem.name.slice(0, payloadItem.name.lastIndexOf("/"));
	const hasSimplifiedPath = topItemName.indexOf("/") > -1;
	const topItem = {
		path: payloadItem.path.slice(0, payloadItem.path.lastIndexOf("/")),
		contentType: payloadItem.contentType,
		name: topItemName,
		hasSimplifiedPath
	};
	const topTreeItem = {
		items: [treeItem],
		data: topItem
	};
	knownFolders.set(topItem.path, topTreeItem);
	if (hasSimplifiedPath) return splitSimplifiedTreeItem(topTreeItem, { ...topItem }, knownFolders);
	else return topTreeItem;
}
var FileTreePicker_module_default = {
	Box: "FileTreePicker-module_ZmzRyW_Box",
	Box_1: "FileTreePicker-module_ZmzRyW_Box_1",
	Box_2: "FileTreePicker-module_ZmzRyW_Box_2",
	checkbox: "FileTreePicker-module_ZmzRyW_checkbox",
	itemContainer: "FileTreePicker-module_ZmzRyW_itemContainer",
	Octicon: "FileTreePicker-module_ZmzRyW_Octicon"
};
var LARGE_DIR_THRESHOLD = 1e3;
function selectionReducer(state, action) {
	const newState = new Set(state);
	switch (action.type) {
		case "SINGLE_SELECT_FILE":
			newState.clear();
			newState.add(action.path);
			sendEvent("copilot-spaces.click", {
				target: "FILE_PICKER",
				action: "SINGLE_SELECT_FILE",
				newFileCount: newState.size
			});
			break;
		case "SELECT_FILE":
			newState.add(action.path);
			sendEvent("copilot-spaces.click", {
				target: "FILE_PICKER",
				action: "SELECT_FILE",
				newFileCount: newState.size
			});
			break;
		case "DESELECT_FILE":
			newState.delete(action.path);
			sendEvent("copilot-spaces.click", {
				target: "FILE_PICKER",
				action: "DESELECT_FILE",
				newFileCount: newState.size
			});
			break;
		case "SELECT_DIRECTORY":
			for (const path of action.paths) newState.add(path);
			sendEvent("copilot-spaces.click", {
				target: "FILE_PICKER",
				action: "SELECT_DIRECTORY",
				newFileCount: newState.size,
				directoryCount: action.paths.length
			});
			break;
		case "DESELECT_DIRECTORY":
			for (const path of action.paths) newState.delete(path);
			sendEvent("copilot-spaces.click", {
				target: "FILE_PICKER",
				action: "DESELECT_DIRECTORY",
				newFileCount: newState.size,
				directoryCount: action.paths.length
			});
			break;
	}
	return newState;
}
function WrappedFileTreeRow({ isActive, file, onItemSelected, getItemUrl, selectedItemRef, navigate, onRenderRow, getFileTrailingVisual, getFileIcon, navigateOnClick, isSelected, singleSelect }) {
	const { sendRepoClickEvent } = useReposAnalytics();
	const rowRef = React.useRef(null);
	const showTooltip = useFileTreeTooltip({
		focusRowRef: rowRef,
		mouseRowRef: rowRef
	});
	const isSubModule = file.data.contentType === "submodule";
	const trailingVisualData = getFileTrailingVisual?.(file.data);
	useEffect(() => {
		if (isActive && rowRef.current) requestAnimationFrame(() => {
			rowRef.current?.scrollIntoView({ block: "center" });
		});
	}, [isActive]);
	const onSelect = React.useCallback((e) => {
		if (isSubModule) {
			e.preventDefault();
			if (file.data.submoduleUrl) window.location.href = file.data.submoduleUrl;
		} else if (e.metaKey || e.ctrlKey || e.button === 1) {
			window.open(getItemUrl?.(file.data), "_blank");
			e.preventDefault();
		} else {
			onItemSelected?.(file.data, file);
			sendRepoClickEvent("FILES_TREE.ITEM", { ["item_path"]: file.data.path });
			if (navigateOnClick) navigate(getItemUrl?.(file.data) || "");
			e.stopPropagation();
		}
	}, [
		file,
		getItemUrl,
		isSubModule,
		navigate,
		navigateOnClick,
		onItemSelected,
		sendRepoClickEvent
	]);
	onRenderRow?.();
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		ref: rowRef,
		onSelect,
		current: isActive,
		id: `${file.data.path}-item`,
		containIntrinsicSize: !isActive ? "auto 2rem" : void 0,
		children: [
			/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: getFileIcon ? getFileIcon(file.data) : isSubModule ? /* @__PURE__ */ jsx(FileSubmoduleIcon, {}) : /* @__PURE__ */ jsx(FileIcon, {}) }),
			/* @__PURE__ */ jsxs("div", {
				className: FileTreePicker_module_default.itemContainer,
				children: [!singleSelect && /* @__PURE__ */ jsx(Checkbox, {
					className: FileTreePicker_module_default.checkbox,
					checked: isSelected || false,
					readOnly: true,
					"aria-label": `Select ${file.data.name}`
				}), /* @__PURE__ */ jsx("span", {
					ref: selectedItemRef,
					style: { color: isSubModule ? "var(--fgColor-accent, var(--color-accent-fg))" : void 0 },
					children: /* @__PURE__ */ jsx("span", {
						"data-testid": `${file.data.path}-file-item`,
						children: file.data.name
					})
				})]
			}),
			showTooltip && /* @__PURE__ */ jsx(PortalTooltip, {
				"data-testid": `${file.data.name}-item-tooltip`,
				id: `${file.data.name}-item-tooltip`,
				contentRef: rowRef,
				"aria-label": file.data.name,
				open: true,
				direction: "ne"
			}),
			!!trailingVisualData?.screenReaderText && /* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children: trailingVisualData.screenReaderText
			}),
			!!trailingVisualData?.trailingVisual && /* @__PURE__ */ jsx(TreeView.TrailingVisual, { children: trailingVisualData.trailingVisual })
		]
	});
}
WrappedFileTreeRow.displayName = "WrappedFileTreeRow";
var FileTreeRow = React.memo(WrappedFileTreeRow);
FileTreeRow.displayName = "FileTreeRow";
function getDirectorySelectionState(directory, selectedChildren, options) {
	if (options?.selectedSelf && options?.isLarge) return "all";
	if (!selectedChildren || selectedChildren.length === 0) return "none";
	const selectedPathsSet = new Set(selectedChildren);
	if (options?.isLarge && selectedPathsSet.has(directory.data.path)) return "all";
	const getAllPathsInDir = (dir) => {
		const paths = /* @__PURE__ */ new Set();
		for (const item of dir.items) if (item.data.contentType === "directory") {
			const childPaths = getAllPathsInDir(item);
			for (const path of childPaths) paths.add(path);
		} else paths.add(item.data.path);
		return paths;
	};
	const allPossiblePaths = getAllPathsInDir(directory);
	const selectedCount = Array.from(allPossiblePaths).filter((path) => selectedPathsSet.has(path)).length;
	if (selectedCount === 0) return "none";
	if (selectedCount === allPossiblePaths.size) return "all";
	return "partial";
}
var MemoizedCheckbox = React.memo(Checkbox);
MemoizedCheckbox.displayName = "MemoizedCheckbox";
function WrappedDirectoryTreeRow({ clientOnlyFilePaths, directory, isActive, isAncestorOfActive, leadingPath, onItemSelected, getItemUrl, getFetchUrl, selectedItemRef, navigate, onRenderRow, getFileTrailingVisual, getFileIcon, navigateOnClick, selectedChildren, expandedPath, singleSelect }) {
	const [isExpanded, setIsExpanded] = useState(isAncestorOfActive);
	const { sendRepoClickEvent } = useReposAnalytics();
	const rowRef = React.useRef(null);
	const listItemRef = React.useRef(null);
	const showTooltip = useFileTreeTooltip({
		focusRowRef: listItemRef,
		mouseRowRef: rowRef
	});
	const filteredChildren = React.useMemo(() => {
		if (!selectedChildren) return [];
		return selectedChildren.filter((path) => path === directory.data.path || path.startsWith(`${directory.data.path}/`));
	}, [selectedChildren, directory.data.path]);
	const selectedSelf = React.useMemo(() => selectedChildren?.includes(directory.data.path) ?? false, [selectedChildren, directory.data.path]);
	const isLargeDirectory = directory.items.length > LARGE_DIR_THRESHOLD;
	const selectionState = React.useMemo(() => getDirectorySelectionState(directory, filteredChildren, {
		selectedSelf,
		isLarge: isLargeDirectory
	}), [
		directory,
		filteredChildren,
		selectedSelf,
		isLargeDirectory
	]);
	const [fetchFolder, incrementallyShowItems, items, loading, error, clearError, _totalCount] = useFetchFolder(directory, () => {}, getFetchUrl);
	const pathPrefix = leadingPath ? `${leadingPath}/` : "";
	const truncatedRows = _totalCount - items.length;
	useEffect(() => {
		if (isActive && rowRef.current) requestAnimationFrame(() => {
			rowRef.current?.scrollIntoView({ block: "center" });
		});
	}, [isActive]);
	const onToggleExpanded = React.useCallback((expanded) => {
		if (expanded && !isExpanded && !loading && !error) {
			if (directory.items.length > 100) incrementallyShowItems();
		}
		if (expanded !== isExpanded) setIsExpanded(expanded);
	}, [
		isExpanded,
		loading,
		error,
		directory.items.length,
		incrementallyShowItems
	]);
	const onClick = React.useCallback((e) => {
		if (e.metaKey || e.ctrlKey || e.button === 1 && navigateOnClick) {
			window.open(getItemUrl?.(directory.data), "_blank");
			e.preventDefault();
		} else {
			if (singleSelect) onToggleExpanded(!isExpanded);
			else {
				onItemSelected?.(directory.data, directory);
				sendRepoClickEvent("FILES_TREE.ITEM", { ["item_path"]: directory.data.path });
				if (navigateOnClick) navigate(getItemUrl?.(directory.data) || "");
			}
			e.stopPropagation();
		}
	}, [
		directory,
		getItemUrl,
		isExpanded,
		navigate,
		navigateOnClick,
		onItemSelected,
		onToggleExpanded,
		sendRepoClickEvent,
		singleSelect
	]);
	React.useEffect(() => {
		if (isAncestorOfActive && !isExpanded) onToggleExpanded?.(true);
	}, [isAncestorOfActive]);
	React.useEffect(() => {
		if (directory.items.length === 0 && isExpanded) onToggleExpanded?.(false);
		else if (!isExpanded && directory.autoExpand) onToggleExpanded?.(true);
	}, [directory.items.length]);
	const setRowRef = React.useCallback((refElem) => {
		if (selectedItemRef && isActive) selectedItemRef(refElem);
		rowRef.current = refElem;
	}, [selectedItemRef, isActive]);
	if (directory.items.length === 1) {
		const firstItem = directory.items[0];
		if (firstItem && firstItem.data.contentType === "directory") return /* @__PURE__ */ jsx(DirectoryContents, {
			clientOnlyFilePaths,
			directoryItems: directory.items,
			leadingPath: pathPrefix + directory.data.name,
			inheritsActive: isActive,
			onItemSelected,
			selectedItemRef,
			getItemUrl,
			directoryNavigateOnClick: navigateOnClick,
			navigateOnClick,
			getFileTrailingVisual,
			getFileIcon,
			selectedChildren: filteredChildren,
			expandedPath,
			singleSelect
		});
	}
	onRenderRow?.();
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		ref: listItemRef,
		expanded: isExpanded,
		onExpandedChange: onToggleExpanded,
		current: isActive,
		onSelect: onClick,
		id: `${directory.data.path}-item`,
		containIntrinsicSize: !isActive ? "auto 2rem" : void 0,
		children: [
			/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(TreeView.DirectoryIcon, {}) }),
			/* @__PURE__ */ jsxs("div", {
				className: FileTreePicker_module_default.itemContainer,
				children: [!singleSelect && /* @__PURE__ */ jsx(MemoizedCheckbox, {
					className: FileTreePicker_module_default.checkbox,
					checked: selectionState === "all",
					indeterminate: selectionState === "partial",
					readOnly: true,
					"aria-label": `Select ${directory.data.name}`,
					"data-indeterminate": selectionState === "partial" ? "true" : void 0
				}), /* @__PURE__ */ jsxs("span", {
					ref: setRowRef,
					children: [pathPrefix && /* @__PURE__ */ jsx("span", { children: pathPrefix }), /* @__PURE__ */ jsx("span", {
						"data-testid": `${directory.data.path}-directory-item`,
						children: directory.data.name
					})]
				})]
			}),
			showTooltip && /* @__PURE__ */ jsx(PortalTooltip, {
				"data-testid": `${directory.data.name}-directory-item-tooltip`,
				id: `${directory.data.name}-directory-item-tooltip`,
				contentRef: listItemRef,
				"aria-label": `${pathPrefix}${directory.data.name}`,
				open: true,
				direction: "ne"
			}),
			/* @__PURE__ */ jsx(TreeView.SubTree, {
				state: loading ? "loading" : error ? "error" : "done",
				children: error ? /* @__PURE__ */ jsx(TreeView.ErrorDialog, {
					onRetry: fetchFolder,
					onDismiss: clearError,
					children: "There was an error loading the folder contents."
				}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(DirectoryContents, {
					clientOnlyFilePaths,
					directoryItems: items,
					onItemSelected,
					selectedItemRef,
					getItemUrl,
					directoryNavigateOnClick: navigateOnClick,
					navigateOnClick,
					getFileTrailingVisual,
					getFileIcon,
					selectedChildren: filteredChildren,
					expandedPath,
					singleSelect
				}), truncatedRows > 0 && /* @__PURE__ */ jsx(ErrorTreeRow, { message: `${truncatedRows} entries not shown` })] })
			})
		]
	});
}
WrappedDirectoryTreeRow.displayName = "WrappedDirectoryTreeRow";
var DirectoryTreeRow = React.memo(WrappedDirectoryTreeRow, (prevProps, nextProps) => {
	return prevProps.isActive === nextProps.isActive && prevProps.isAncestorOfActive === nextProps.isAncestorOfActive && prevProps.directory === nextProps.directory && (prevProps.selectedChildren === nextProps.selectedChildren || prevProps.selectedChildren.length === 0 && nextProps.selectedChildren.length === 0) && prevProps.expandedPath === nextProps.expandedPath;
});
DirectoryTreeRow.displayName = "DirectoryTreeRow";
function WrappedDirectoryContents({ clientOnlyFilePaths, directoryItems, leadingPath, inheritsActive, onItemSelected, selectedItemRef, onRenderRow, getItemUrl, getFileTrailingVisual, getFileIcon, directoryNavigateOnClick, navigateOnClick, selectedChildren, expandedPath, singleSelect }) {
	const urlCreator = useUrlCreator();
	const navigate = useNavigate$1();
	const navigateRef = React.useRef(navigate);
	const onItemSelectedRef = React.useRef(onItemSelected);
	React.useEffect(() => {
		onItemSelectedRef.current = onItemSelected;
		navigateRef.current = navigate;
	}, [onItemSelected, navigate]);
	const handleItemSelection = React.useCallback((itemData, item) => {
		onItemSelectedRef.current?.(itemData, item);
	}, []);
	return /* @__PURE__ */ jsx(Fragment$1, { children: React.useMemo(() => directoryItems.map((item) => {
		const isActive = expandedPath === item.data.path;
		const isSelected = selectedChildren?.includes(item.data.path);
		const isAncestorOfActive = isActive || expandedPath.startsWith(`${item.data.path}/`);
		const itemSelectedChildren = selectedChildren?.filter((path) => path === item.data.path || path.startsWith(`${item.data.path}/`)) || [];
		if (item.data.contentType === "directory") return /* @__PURE__ */ jsx(DirectoryTreeRow, {
			clientOnlyFilePaths,
			isActive: inheritsActive || isActive,
			isAncestorOfActive,
			onItemSelected: handleItemSelection,
			leadingPath,
			directory: item,
			getItemUrl,
			getFetchUrl: urlCreator.getItemUrl,
			selectedItemRef: isAncestorOfActive ? selectedItemRef : void 0,
			navigate,
			onRenderRow,
			navigateOnClick: directoryNavigateOnClick,
			getFileTrailingVisual,
			getFileIcon,
			itemCount: item.items.length,
			isSelected,
			selectedChildren: itemSelectedChildren,
			expandedPath,
			singleSelect
		}, item.data.name);
		return /* @__PURE__ */ jsx(FileTreeRow, {
			onItemSelected: handleItemSelection,
			file: item,
			isActive,
			getItemUrl,
			selectedItemRef: isActive ? selectedItemRef : void 0,
			navigate,
			navigateOnClick,
			onRenderRow,
			getFileTrailingVisual,
			getFileIcon,
			isSelected,
			singleSelect
		}, item.data.name);
	}), [
		directoryItems,
		expandedPath,
		selectedChildren,
		handleItemSelection,
		getItemUrl,
		selectedItemRef,
		navigate,
		navigateOnClick,
		onRenderRow,
		getFileTrailingVisual,
		getFileIcon,
		singleSelect,
		clientOnlyFilePaths,
		inheritsActive,
		leadingPath,
		urlCreator.getItemUrl,
		directoryNavigateOnClick
	]) });
}
WrappedDirectoryContents.displayName = "WrappedDirectoryContents";
var DirectoryContents = React.memo(WrappedDirectoryContents);
DirectoryContents.displayName = "DirectoryContents";
function FileTreePicker(props) {
	const { clientOnlyFilePaths, rootItems, fetchError, loading, onRenderRow, getItemUrl, getFileTrailingVisual, getFileIcon, expandedPath, onSelectionChange } = props;
	const [internalSelectedItems, dispatch] = useReducer(selectionReducer, /* @__PURE__ */ new Set());
	const selectedItems = props.selectedItems || internalSelectedItems;
	const getAllFilePaths = useCallback((item) => {
		const pathsSet = /* @__PURE__ */ new Set();
		pathsSet.add(item.data.path);
		if (item.data.contentType === "directory") for (const child of item.items) {
			const childPaths = getAllFilePaths(child);
			for (const path of childPaths) pathsSet.add(path);
		}
		return Array.from(pathsSet);
	}, []);
	function getSelectionAction(singleSelect, isSelected, path) {
		if (singleSelect) return {
			type: "SINGLE_SELECT_FILE",
			path
		};
		if (isSelected) return {
			type: "DESELECT_FILE",
			path
		};
		return {
			type: "SELECT_FILE",
			path
		};
	}
	const handleFileSelection = useCallback((path, isSelected) => {
		const action = getSelectionAction(!!props.singleSelect, isSelected, path);
		if (onSelectionChange) onSelectionChange(selectionReducer(selectedItems, action));
		else dispatch(action);
	}, [
		onSelectionChange,
		props.singleSelect,
		selectedItems
	]);
	const handleDirectorySelection = useCallback((treeItem, isFullySelected) => {
		if (!!props.allowFolderReferences && treeItem.items.length > LARGE_DIR_THRESHOLD) {
			const dirPath = treeItem.data.path;
			const action = selectedItems.has(dirPath) ? {
				type: "DESELECT_FILE",
				path: dirPath
			} : {
				type: "SELECT_FILE",
				path: dirPath
			};
			if (onSelectionChange) onSelectionChange(selectionReducer(selectedItems, action));
			else dispatch(action);
			return;
		}
		const paths = getAllFilePaths(treeItem);
		const action = isFullySelected ? {
			type: "DESELECT_DIRECTORY",
			paths
		} : {
			type: "SELECT_DIRECTORY",
			paths
		};
		if (onSelectionChange) onSelectionChange(selectionReducer(selectedItems, action));
		else dispatch(action);
	}, [
		getAllFilePaths,
		onSelectionChange,
		selectedItems,
		props.allowFolderReferences
	]);
	const handleItemSelected = useCallback((item, treeItem) => {
		if (item.contentType === "directory") {
			if (!!props.allowFolderReferences && treeItem.items.length > LARGE_DIR_THRESHOLD) {
				handleDirectorySelection(treeItem, selectedItems.has(item.path));
				return;
			}
			const paths = getAllFilePaths(treeItem);
			const selectedPathsInThisDirectory = paths.filter((path) => selectedItems.has(path));
			const hasAnySelected = selectedPathsInThisDirectory.length > 0;
			const isFullySelected = paths.length === selectedPathsInThisDirectory.length;
			if (hasAnySelected && !isFullySelected) handleDirectorySelection(treeItem, true);
			else handleDirectorySelection(treeItem, isFullySelected);
		} else handleFileSelection(item.path, selectedItems.has(item.path));
	}, [
		getAllFilePaths,
		handleDirectorySelection,
		handleFileSelection,
		selectedItems,
		props.allowFolderReferences
	]);
	return /* @__PURE__ */ jsx("div", {
		onMouseDown: useCallback((event) => {
			if (event.button === 1) event.preventDefault();
		}, []),
		"data-testid": "repos-file-tree-container",
		className: FileTreePicker_module_default.Box,
		children: loading ? /* @__PURE__ */ jsxs("div", {
			className: FileTreePicker_module_default.Box_1,
			children: [/* @__PURE__ */ jsx(Spinner, { "aria-label": "Loading file tree" }), /* @__PURE__ */ jsx("span", {
				className: "fgColor-muted",
				children: "Fetching files..."
			})]
		}) : /* @__PURE__ */ jsx("nav", {
			"aria-label": "File Tree Navigation",
			children: /* @__PURE__ */ jsxs(TreeView, {
				"aria-label": "Files",
				children: [fetchError && /* @__PURE__ */ jsx(ErrorTreeRow, { message: "Some files could not be loaded." }), /* @__PURE__ */ jsx(DirectoryContents, {
					clientOnlyFilePaths,
					directoryItems: rootItems,
					onItemSelected: handleItemSelected,
					selectedChildren: selectedItems ? Array.from(selectedItems) : [],
					selectedItemRef: props.selectedItemRef,
					onRenderRow,
					directoryNavigateOnClick: props.directoryNavigateOnClick,
					navigateOnClick: props.navigateOnClick,
					getItemUrl,
					getFileTrailingVisual,
					getFileIcon,
					expandedPath,
					singleSelect: props.singleSelect
				})]
			})
		})
	});
}
FileTreePicker.displayName = "FileTreePicker";
function ErrorTreeRow({ message }) {
	const errorMessage = message || "Couldn't load.";
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		id: "error-tree-row",
		children: [/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, {
			icon: AlertFillIcon,
			className: FileTreePicker_module_default.Octicon
		}) }), /* @__PURE__ */ jsx("div", {
			className: FileTreePicker_module_default.Box_2,
			children: errorMessage
		})]
	});
}
ErrorTreeRow.displayName = "ErrorTreeRow";
/**
* Fetches repository items from a custom endpoint.
*
* Note: `_searchUserReposFirst` is unused because the backend now automatically
* detects user login prefix in queries and prioritizes those repos.
*/
function useRepositoryItems(filterText, open, topicDisplayCount, ownerDisplayLogin, includeForks = false, isActive = true) {
	const { topRepositoriesCache, currentRepository } = useChatState();
	const chatManager = useChatManager();
	const { service } = chatManager;
	const [repositories, setRepositories] = useState([]);
	const [loading, setLoading] = useState(!topRepositoriesCache ? "initial" : false);
	const hasFetchedTopReposRef = useRef(false);
	const resetTopRepoResults = useCallback(() => {
		chatManager.setTopRepositoryTopics(void 0);
		hasFetchedTopReposRef.current = false;
	}, [chatManager]);
	const isOrgOwned = ownerDisplayLogin && ownerDisplayLogin.trim() !== "";
	useEffect(() => {
		if (!isActive) return;
		const fetchTopRepos = async () => {
			if (!open || hasFetchedTopReposRef.current || topRepositoriesCache) return;
			setLoading("initial");
			try {
				const topRepos = await service.fetchRepositoriesSearch(void 0, topicDisplayCount, includeForks, currentRepository?.id);
				chatManager.setTopRepositoryTopics(topRepos);
				hasFetchedTopReposRef.current = true;
			} catch {} finally {
				setLoading(false);
			}
		};
		if (!isOrgOwned) fetchTopRepos();
	}, [
		isActive,
		open,
		service,
		isOrgOwned,
		topicDisplayCount,
		currentRepository,
		chatManager,
		topRepositoriesCache,
		includeForks
	]);
	useEffect(() => {
		if (!isActive) return;
		const abortController = new AbortController();
		const fetchSearchedRepos = async (query) => {
			setLoading(true);
			try {
				const results = await service.fetchRepositoriesSearch(query, void 0, includeForks, currentRepository?.id, isOrgOwned ? ownerDisplayLogin : void 0);
				if (!abortController.signal.aborted) setRepositories(results);
			} catch {
				if (!abortController.signal.aborted) setRepositories([]);
			} finally {
				if (!abortController.signal.aborted) setLoading(false);
			}
		};
		if (filterText || isOrgOwned) fetchSearchedRepos(filterText);
		else if (topRepositoriesCache) setRepositories(topRepositoriesCache);
		return () => {
			abortController.abort();
		};
	}, [
		isActive,
		filterText,
		isOrgOwned,
		ownerDisplayLogin,
		currentRepository,
		service,
		topRepositoriesCache,
		includeForks
	]);
	useEffect(() => {
		if (!isActive) return;
		chatManager.setTopRepositoryTopics(void 0);
		hasFetchedTopReposRef.current = false;
	}, [
		isActive,
		chatManager,
		ownerDisplayLogin
	]);
	if (topRepositoriesCache && !filterText && !isOrgOwned) return {
		repositories: topRepositoriesCache,
		loading: false,
		resetTopRepoResults
	};
	return {
		repositories,
		loading,
		resetTopRepoResults
	};
}
/**
* Split an array into groups based on unique values returned by the differentiator.
* @example
* // Split numbers into even and odd
* const groups = partition([1,2,3,4,5], n => n % 2)
* const evens = groups.get(0) ?? []
* const odds = groups.get(1) ?? []
*/
function group(array, differentiator) {
	const result = {};
	for (const el of array) {
		const key = differentiator(el);
		result[key] ??= [];
		result[key].push(el);
	}
	return result;
}
/**
* Creates a new array of unique values from the provided array based on a key function.
* Duplicate items are determined by the return value of the key function.
* When duplicates are found, the first item with the same key is kept.
*
* @param array - The array to filter for unique values.
* @param fn - A function that returns a key for each item in the array.
* @returns An array of unique items based on the provided key function.
*/
function uniqueBy(array, fn) {
	const result = [];
	const seenKeys = /* @__PURE__ */ new Set();
	for (const item of array) {
		const key = fn(item);
		if (seenKeys.has(key)) continue;
		seenKeys.add(key);
		result.push(item);
	}
	return result;
}
var DelayedComponent = (t0) => {
	const $ = c(6);
	const { children, delay: t1, assertive: t2 } = t0;
	const delay = t1 === void 0 ? 500 : t1;
	const assertive = t2 === void 0 ? false : t2;
	const [shouldAnnounce, setShouldAnnounce] = useState(false);
	let t3;
	let t4;
	if ($[0] !== delay) {
		t3 = () => {
			setShouldAnnounce(false);
			const timer = setTimeout(() => setShouldAnnounce(true), delay);
			return () => clearTimeout(timer);
		};
		t4 = [delay, setShouldAnnounce];
		$[0] = delay;
		$[1] = t3;
		$[2] = t4;
	} else {
		t3 = $[1];
		t4 = $[2];
	}
	useEffect(t3, t4);
	if (!shouldAnnounce) return null;
	const t5 = assertive ? "assertive" : "polite";
	let t6;
	if ($[3] !== children || $[4] !== t5) {
		t6 = jsx("div", {
			role: "alert",
			"aria-live": t5,
			"aria-atomic": "true",
			children
		});
		$[3] = children;
		$[4] = t5;
		$[5] = t6;
	} else t6 = $[5];
	return t6;
};
DelayedComponent.displayName = "DelayedComponent";
var RepoSelectPanel_module_default = {
	ActionList: "RepoSelectPanel-module_vWlVeq_ActionList",
	CopilotRepoSelectPanelAnchored: "RepoSelectPanel-module_vWlVeq_CopilotRepoSelectPanelAnchored",
	emptyStateMessage: "RepoSelectPanel-module_vWlVeq_emptyStateMessage"
};
function RepositoryListItem({ onSelect, repo, selected, trailingVisualComponent }) {
	const { databaseId, isInOrganization, nwo, ownerAvatarUrl } = repo;
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		onSelect: () => onSelect(databaseId),
		selected,
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, {
				src: ownerAvatarUrl,
				square: isInOrganization,
				size: 16
			}) }),
			nwo,
			trailingVisualComponent && /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: trailingVisualComponent })
		]
	}, nwo);
}
RepositoryListItem.displayName = "RepositoryListItem";
/** Select one or more repos to use as references (attachments). */
function RepoReferencesSelectPanel(props) {
	const { currentReferences } = useChatState();
	const manager = useChatManager();
	const selectedRepoReferences = currentReferences.filter(_temp$14);
	const selectedRepoIds = new Set(selectedRepoReferences.map(_temp2$2));
	const [error, setError] = useState();
	const toggleRepoReference = async (repoId, queryLength) => {
		setError(void 0);
		const selectedReference = selectedRepoReferences.find((r_1) => r_1.id === repoId);
		if (selectedReference) {
			manager.removeReference(selectedReference);
			sendEvent("dotcom_chat.activate", {
				target: "ATTACHMENT_MENU_REPOSITORIES",
				action: "removed",
				component: "ATTACHMENT_MENU",
				mode: "immersive"
			});
			return;
		}
		const repoResponse = await manager.service.fetchRepo(repoId);
		if (!repoResponse.ok) {
			setError("Error: failed to attach repository. Please try again.");
			props.onOpenChange(true);
			return;
		}
		props.onRepoSelect?.(repoResponse.payload);
		const reference = makeRepositoryReference(repoResponse.payload);
		manager.addReference(reference, "repoMenu");
		sendEvent("dotcom_chat.activate", {
			target: "ATTACHMENT_MENU_REPOSITORIES",
			action: "selected",
			component: "ATTACHMENT_MENU",
			mode: "immersive",
			queryLength
		});
	};
	return jsx(RepoSelectPanel, {
		...props,
		selectionVariant: "multiple",
		selectedRepoIds,
		onSelectRepo: toggleRepoReference,
		description: "Choose repositories to chat about.",
		error
	});
}
RepoReferencesSelectPanel.displayName = "RepoReferencesSelectPanel";
function _temp2$2(r_0) {
	return r_0.id;
}
function _temp$14(r) {
	return r.type === "repository";
}
function RepoSelectPanel({ open, onOpenChange, submitReturnFocusRef, cancelReturnFocusRef, selectedRepoIds, featuredRepoIds = selectedRepoIds, onSelectRepo, selectionVariant, description, error, ownerDisplayLogin, includeForks = false, anchorRef }) {
	const { ssoOrganizations } = useChatState();
	const [filter, setFilter] = useState("");
	const debouncedSetFilter = useMemo(() => debounce((newFilter) => setFilter(newFilter), 150, { start: false }), []);
	useEffect(() => {
		if (!open) setFilter("");
	}, [open]);
	const { repositories, loading: reposLoading } = useRepositoryItems(filter, open, void 0, ownerDisplayLogin, includeForks);
	const srRepoSearchStatus = useMemo(() => {
		if (reposLoading) return "Loading repositories";
		if (repositories.length === 0) return "No repositories found";
		if (repositories.length === 1) return "1 repository found";
		return `${repositories.length} repositories found`;
	}, [reposLoading, repositories.length]);
	const onSearchInputChange = (event) => {
		debouncedSetFilter(event.currentTarget.value);
	};
	const ssoOrgNames = useMemo(() => {
		if (!ssoOrganizations) return [];
		return ssoOrganizations.map((org) => org.login);
	}, [ssoOrganizations]);
	const { featuredRepos, nonFeaturedRepos } = group(repositories, (r) => featuredRepoIds.has(r.databaseId) ? "featuredRepos" : "nonFeaturedRepos");
	const [selecting, setSelecting] = useState(false);
	const onSelect = async (repoId) => {
		setSelecting(true);
		await onSelectRepo(repoId, filter.length);
		setSelecting(false);
	};
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("repo-select-panel"),
		children: /* @__PURE__ */ jsxs(SelectPanel, {
			className: clsx(anchorRef && RepoSelectPanel_module_default.CopilotRepoSelectPanelAnchored),
			width: "large",
			maxHeight: "xlarge",
			onCancel: () => {
				flushSync(() => onOpenChange(false));
				cancelReturnFocusRef.current?.focus();
				sendEvent("dotcom_chat.activate", {
					target: "REPOSITORY_DIALOG_CLOSE",
					mode: "immersive"
				});
			},
			onSubmit: () => {
				flushSync(() => onOpenChange(false));
				submitReturnFocusRef.current?.focus();
			},
			open,
			variant: anchorRef ? "anchored" : "modal",
			selectionVariant,
			title: selectionVariant === "multiple" ? "Select repositories" : "Select a repository",
			description,
			anchorRef,
			children: [
				/* @__PURE__ */ jsx(SelectPanel.Header, {
					className: clsx(ssoOrgNames.length > 0 && "border-bottom-0"),
					children: /* @__PURE__ */ jsx(SelectPanel.SearchInput, {
						loading: reposLoading === true || selecting,
						onChange: onSearchInputChange,
						placeholder: "Search repositories",
						"aria-label": "Search repositories"
					})
				}),
				/* @__PURE__ */ jsx(TopicPickerPortalContainer, {}),
				error && /* @__PURE__ */ jsx(SelectPanel.Message, {
					variant: "error",
					size: "inline",
					children: error
				}),
				reposLoading === "initial" ? /* @__PURE__ */ jsxs("div", {
					className: RepoSelectPanel_module_default.ActionList,
					children: [/* @__PURE__ */ jsx("div", {
						className: "sr-only",
						children: srRepoSearchStatus
					}), /* @__PURE__ */ jsx(SelectPanel.Loading, { children: "Fetching repositories…" })]
				}) : repositories.length === 0 && !reposLoading ? /* @__PURE__ */ jsxs("div", {
					className: RepoSelectPanel_module_default.ActionList,
					children: [/* @__PURE__ */ jsx("div", {
						className: "sr-only",
						children: srRepoSearchStatus
					}), /* @__PURE__ */ jsx("div", {
						className: RepoSelectPanel_module_default.emptyStateMessage,
						children: /* @__PURE__ */ jsx(DelayedComponent, {
							delay: 750,
							children: /* @__PURE__ */ jsx(SelectPanel.Message, {
								variant: "empty",
								title: "No repositories found",
								children: "Try a different search term"
							})
						})
					})]
				}) : /* @__PURE__ */ jsxs(ActionList, {
					className: RepoSelectPanel_module_default.ActionList,
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "sr-only",
							children: srRepoSearchStatus
						}),
						featuredRepos?.map((repo) => /* @__PURE__ */ jsx(RepositoryListItem, {
							repo,
							onSelect,
							selected: selectedRepoIds.has(repo.databaseId)
						}, repo.databaseId)),
						featuredRepos && nonFeaturedRepos && /* @__PURE__ */ jsx(ActionList.Divider, {}),
						nonFeaturedRepos?.map((repo_0) => /* @__PURE__ */ jsx(RepositoryListItem, {
							repo: repo_0,
							onSelect,
							selected: selectedRepoIds.has(repo_0.databaseId)
						}, repo_0.databaseId))
					]
				})
			]
		})
	});
}
RepoSelectPanel.displayName = "RepoSelectPanel";
var FilesSearchBox$1 = ({ ref, ariaActiveDescendant, ariaControls, ariaExpanded, ariaHasPopup, className, onBlur, onFocus, onKeyDown, onPreload, onSearch, query, searchPlaceholder, loading }) => {
	const { sendRepoClickEvent } = useReposAnalytics();
	const [textValue, setTextValue] = React.useState(query);
	const debouncedOnSearch = React.useRef(debounce((newQuery) => onSearch(newQuery), 250));
	React.useEffect(() => {
		setTextValue(query);
	}, [query]);
	const clearAction = query ? /* @__PURE__ */ jsx(TextInput$1.Action, {
		onClick: () => {
			sendRepoClickEvent("FILE_TREE.CANCEL_SEARCH");
			onSearch("");
		},
		icon: XCircleFillIcon,
		"aria-label": "Clear",
		className: "fgColor-muted"
	}) : void 0;
	return /* @__PURE__ */ jsx(TextInput$1, {
		autoFocus: isSearchUrl(),
		className: clsx("d-flex", className),
		ref,
		value: textValue,
		onKeyDown,
		onChange: (e) => {
			setTextValue(e.target.value);
			onPreload();
			debouncedOnSearch.current(e.target.value);
		},
		"aria-label": searchPlaceholder || "Go to file",
		"aria-activedescendant": ariaActiveDescendant,
		role: ariaHasPopup ? "combobox" : void 0,
		"aria-controls": ariaControls,
		"aria-expanded": ariaExpanded,
		"aria-haspopup": ariaHasPopup ? "dialog" : void 0,
		autoCorrect: "off",
		spellCheck: "false",
		placeholder: searchPlaceholder || "Go to file",
		loading: query !== "" && loading,
		leadingVisual: SearchIcon,
		trailingAction: clearAction,
		trailingVisual: clearAction ? void 0 : () => /* @__PURE__ */ jsx(AllShortcutsEnabled, { children: /* @__PURE__ */ jsx("kbd", { children: "t" }) }),
		onFocus: (e) => {
			onPreload();
			e.target.select();
			onFocus?.(e);
		},
		onBlur,
		onClick: () => sendRepoClickEvent("FILE_TREE.SEARCH_BOX")
	});
};
/**
* Whether the URL contains ?search=1 which indicates user is searching for a file
*/
FilesSearchBox$1.displayName = "FilesSearchBox";
function isSearchUrl() {
	return new URLSearchParams(ssrSafeLocation.search).get("search") === "1";
}
FilesSearchBox$1.displayName = "FilesSearchBox";
var FileResultsList_module_default = {
	ActionList: "FileResultsList-module_IWTxTW_ActionList",
	actionListDefault: "FileResultsList-module_IWTxTW_actionListDefault",
	actionListOverlay: "FileResultsList-module_IWTxTW_actionListOverlay",
	Box: "FileResultsList-module_IWTxTW_Box",
	boxDefault: "FileResultsList-module_IWTxTW_boxDefault",
	boxOverlay: "FileResultsList-module_IWTxTW_boxOverlay",
	fileResultItem: "FileResultsList-module_IWTxTW_fileResultItem",
	fileResultItemFocused: "FileResultsList-module_IWTxTW_fileResultItemFocused",
	FilesSearchBox: "FileResultsList-module_IWTxTW_FilesSearchBox",
	HighlightMatch: "FileResultsList-module_IWTxTW_HighlightMatch",
	Octicon: "FileResultsList-module_IWTxTW_Octicon"
};
var LIST_SIZE = 20;
var defaultConfig = {
	excludeDirectories: false,
	excludeSeeAllResults: false
};
function FileResultsList({ additionalResults, className, commitOid, config = defaultConfig, findFileWorkerPath, getItemUrl, onRenderRow, onItemSelected, searchBoxRef }) {
	const { excludeDirectories, excludeSeeAllResults } = config;
	const { query, setQuery } = useFileQueryContext();
	const repo = useCurrentRepository();
	const internalInputRef = React.useRef(null);
	const inputRef = searchBoxRef ?? internalInputRef;
	const [preloadSearch, setPreloadSearch] = React.useState(query.length > 0);
	const [overlayOpen, setOverlayOpen] = React.useState(!!query);
	const { list, directories, loading, error } = useTreeList(commitOid, preloadSearch, !!excludeDirectories);
	const path = usePath();
	const { getUrl } = useUrlCreator();
	const { queryText, queryLine } = parseQuery(query);
	const { matches, clearMatches } = useFilter(useMemo(() => [...list, ...additionalResults ?? []].sort(), [additionalResults, list]), queryText, findFileWorkerPath, preloadSearch);
	const { sendRepoClickEvent } = useReposAnalytics();
	const navigate = useNavigate$1();
	const [focusedSearchIndex, setFocusedSearchIndex] = React.useState(0);
	const [listFocusVisible, setListFocusVisible] = React.useState(() => isSearchUrl());
	const allResultsLink = React.useRef(null);
	const textInputContainerRef = React.useRef(null);
	const overlayId = "file-results-list";
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	const { screenSize } = useScreenSize();
	const enableOverlay = config.enableOverlay ?? screenSize >= ScreenSize.large;
	const onRowClick = React.useCallback((selectedPath) => {
		sendRepoClickEvent("FILE_TREE.SEARCH_RESULT_CLICK");
		onItemSelected?.(selectedPath);
		setOverlayOpen(false);
	}, [sendRepoClickEvent, onItemSelected]);
	const buildUrl = (itemPath, isDirectory, hash) => {
		if (getItemUrl) return getItemUrl(itemPath, isDirectory, hash);
		return getUrl({
			path: itemPath,
			action: isDirectory ? "tree" : "blob",
			hash
		});
	};
	const { containerRef: listRef } = useFocusZone({
		bindKeys: FocusKeys.ArrowVertical | FocusKeys.HomeAndEnd,
		focusInStrategy: "previous"
	}, [loading, error]);
	React.useEffect(() => {
		if (!query) setOverlayOpen(false);
	}, [query]);
	React.useEffect(() => {
		if (document.activeElement !== inputRef.current && enableOverlay) setOverlayOpen(false);
	}, [
		path,
		inputRef,
		enableOverlay
	]);
	const displayMatches = matches?.slice(0, LIST_SIZE) || [];
	const matchesTruncated = matches && matches.length > displayMatches.length;
	const navigationEnabled = !config.disableNavigation;
	const handleSearchBoxKeyDown = (event) => {
		const { key, shiftKey, metaKey, altKey, ctrlKey } = event;
		if (shiftKey || metaKey || altKey) return;
		if (key === "Escape") {
			if (query) {
				sendRepoKeyDownEvent("FILE_TREE.CANCEL_SEARCH");
				setQuery("");
				clearMatches();
			} else if (document.activeElement) document.activeElement.blur();
		} else if (!query) return;
		else if (key === "Enter") {
			if (!excludeSeeAllResults && matchesTruncated && focusedSearchIndex === displayMatches.length) {
				if (navigationEnabled) navigate(codeNavSearchPath({
					owner: repo.ownerLogin,
					repo: repo.name,
					searchTerm: `path:${queryText}`
				}));
				onItemSelected?.();
			} else if (displayMatches[focusedSearchIndex]) {
				const selectedPath = displayMatches[focusedSearchIndex];
				if (navigationEnabled) navigate(buildUrl(displayMatches[focusedSearchIndex], false, queryLine ? `L${queryLine}` : ""));
				setOverlayOpen(false);
				onItemSelected?.(selectedPath);
			}
		} else if (key === "ArrowDown" || ctrlKey && key === "n") {
			if (!excludeSeeAllResults && matchesTruncated && focusedSearchIndex >= displayMatches.length - 1) {
				setFocusedSearchIndex(displayMatches.length);
				if (allResultsLink.current && listRef.current) {
					const container = getScrollableParent(listRef.current);
					scrollIntoView(allResultsLink.current, container, { behavior: "instant" });
				}
			} else setFocusedSearchIndex(Math.min(focusedSearchIndex + 1, displayMatches.length - 1));
			event.preventDefault();
			return;
		} else if (key === "ArrowUp" || ctrlKey && key === "p") {
			setFocusedSearchIndex(Math.max(focusedSearchIndex - 1, 0));
			event.preventDefault();
			return;
		}
	};
	const inputWidth = textInputContainerRef.current?.getBoundingClientRect().width;
	const listContents = /* @__PURE__ */ jsx("div", {
		className: clsx(FileResultsList_module_default.Box, enableOverlay ? FileResultsList_module_default.boxOverlay : FileResultsList_module_default.boxDefault),
		style: enableOverlay ? { width: inputWidth } : void 0,
		children: error ? /* @__PURE__ */ jsx(Flash, {
			variant: "danger",
			className: "tmp-m-3",
			children: "Failed to search"
		}) : /* @__PURE__ */ jsxs(ActionList, {
			ref: listRef,
			role: "listbox",
			className: clsx(FileResultsList_module_default.ActionList, enableOverlay ? FileResultsList_module_default.actionListOverlay : FileResultsList_module_default.actionListDefault),
			children: [!loading && displayMatches.map((match, index) => {
				const isDirectory = directories.includes(match);
				const itemUrl = buildUrl(match, isDirectory, queryLine ? `L${queryLine}` : "");
				return /* @__PURE__ */ jsx(MemoizedFileResultRow, {
					active: false,
					index,
					focused: listFocusVisible && focusedSearchIndex === index,
					match,
					onRender: onRenderRow,
					query: queryText,
					onClick: onRowClick,
					isDirectory,
					to: itemUrl,
					useOverlay: enableOverlay,
					listRef,
					noAnchor: config.disableNavigation
				}, match);
			}), displayMatches.length === 0 && /* @__PURE__ */ jsx("div", {
				role: "status",
				className: "text-center fgColor-muted",
				children: "No matches found"
			})]
		})
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("div", {
			className,
			ref: textInputContainerRef,
			children: /* @__PURE__ */ jsx(FilesSearchBox$1, {
				ariaActiveDescendant: (enableOverlay || !query) && (!enableOverlay || !overlayOpen) ? void 0 : listFocusVisible && focusedSearchIndex > -1 ? matchesTruncated && focusedSearchIndex === displayMatches.length ? "see-all-results-link" : `file-result-${focusedSearchIndex}` : void 0,
				ariaExpanded: enableOverlay ? overlayOpen : void 0,
				ariaHasPopup: enableOverlay,
				ariaControls: enableOverlay ? overlayId : void 0,
				ref: inputRef,
				loading,
				query,
				onKeyDown: handleSearchBoxKeyDown,
				onPreload: () => setPreloadSearch(true),
				onSearch: (newQuery) => {
					setQuery(newQuery);
					if (newQuery) setOverlayOpen(true);
					else {
						clearMatches();
						setOverlayOpen(false);
					}
					setFocusedSearchIndex(0);
				},
				onBlur: (e) => {
					if (!listRef.current?.contains(e.relatedTarget)) {
						setOverlayOpen(false);
						setListFocusVisible(false);
					}
				},
				onFocus: () => {
					if (query) setOverlayOpen(true);
					setListFocusVisible(true);
				},
				searchPlaceholder: config.searchPlaceholder,
				className: FileResultsList_module_default.FilesSearchBox
			})
		}),
		enableOverlay && displayMatches.length > 0 && /* @__PURE__ */ jsx(AnchoredOverlay, {
			anchorRef: textInputContainerRef,
			open: enableOverlay && overlayOpen,
			renderAnchor: null,
			onClose: () => {
				setOverlayOpen(false);
			},
			focusZoneSettings: { disabled: true },
			focusTrapSettings: { disabled: true },
			align: "end",
			overlayProps: {
				id: overlayId,
				role: "dialog"
			},
			children: listContents
		}),
		!enableOverlay && query && listContents
	] });
}
FileResultsList.displayName = "FileResultsList";
var FileResultRow = ({ active, focused, index, match, query, to, isDirectory, onClick, onRender, useOverlay, listRef, noAnchor }) => {
	const positionsList = positions(query, match);
	onRender?.();
	const ref = React.useRef(null);
	const leadingIcon = isDirectory ? DirectoryIcon : FileResultIcon;
	React.useEffect(() => {
		if (focused && ref.current && listRef?.current) {
			const container = getScrollableParent(listRef.current);
			scrollIntoView(ref.current, container, { behavior: "instant" });
		}
	}, [focused, listRef]);
	const onClickWrapped = useCallback(() => {
		onClick?.(match);
	}, [match, onClick]);
	const sharedItemProps = {
		id: `file-result-${index}`,
		active,
		onSelect: onClickWrapped,
		className: clsx(FileResultsList_module_default.fileResultItem, focused && FileResultsList_module_default.fileResultItemFocused),
		role: "option",
		"data-focus-visible-added": focused || void 0,
		tabIndex: useOverlay ? -1 : 0
	};
	const innerContent = /* @__PURE__ */ jsx("div", {
		className: "d-flex",
		children: /* @__PURE__ */ jsx("div", {
			className: "d-flex flex-1 flex-column overflow-hidden",
			children: /* @__PURE__ */ jsx(HighlightMatch, {
				text: match,
				positionsList,
				LeadingIcon: leadingIcon,
				className: FileResultsList_module_default.HighlightMatch
			})
		})
	});
	return noAnchor ? /* @__PURE__ */ jsx(ActionList.Item, {
		...sharedItemProps,
		children: innerContent
	}, match) : /* @__PURE__ */ jsx(ActionList.LinkItem, {
		...sharedItemProps,
		ref,
		as: Link$1,
		to,
		children: innerContent
	}, match);
};
FileResultRow.displayName = "FileResultRow";
var DirectoryIcon = () => /* @__PURE__ */ jsx(Octicon, {
	"aria-label": "Directory",
	icon: FileDirectoryFillIcon,
	size: "small",
	className: FileResultsList_module_default.Octicon
});
DirectoryIcon.displayName = "DirectoryIcon";
var FileResultIcon = () => /* @__PURE__ */ jsx(Octicon, {
	"aria-label": "File",
	icon: FileIcon,
	className: "fgColor-muted mr-2",
	size: "small"
});
FileResultIcon.displayName = "FileResultIcon";
var MemoizedFileResultRow = React.memo(FileResultRow);
MemoizedFileResultRow.displayName = "MemoizedFileResultRow";
function HighlightMatch({ className, text, positionsList, LeadingIcon }) {
	const parts = [];
	let lastPosition = 0;
	for (const i of positionsList) {
		if (Number(i) !== i || i < lastPosition || i > text.length) continue;
		const slice = text.slice(lastPosition, i);
		if (slice) parts.push(allowSlashWrapping(slice));
		lastPosition = i + 1;
		parts.push(/* @__PURE__ */ jsx("mark", {
			className: "text-bold bgColor-transparent fgColor-default",
			children: text[i]
		}, i));
	}
	parts.push(allowSlashWrapping(text.slice(lastPosition)));
	return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsxs(Fragment$1, { children: [LeadingIcon && /* @__PURE__ */ jsx(LeadingIcon, {}), parts] })
	});
}
HighlightMatch.displayName = "HighlightMatch";
function allowSlashWrapping(text) {
	return text.replaceAll("/", "/​");
}
function useFilter(list, query, workerPath, startWorker) {
	const [matches, setMatches] = React.useState();
	const lastQueryRef = React.useRef("");
	const workerRef = React.useRef(null);
	const { sendStats } = useReposAnalytics();
	const isWorkerWorking = React.useRef(false);
	const createWorker = React.useCallback(() => {
		const worker = new WebWorker(workerPath, findFileWorkerJob);
		worker.onmessage = ({ data }) => {
			isWorkerWorking.current = false;
			setMatches(data.list);
			lastQueryRef.current = data.query;
			if (data.startTime) sendStats("repository.find-file", {
				"find-file-base-count": data.baseCount,
				"find-file-results-count": data.list.length,
				"find-file-duration-ms": performance.now() - data.startTime
			});
		};
		workerRef.current = worker;
	}, [sendStats, workerPath]);
	React.useEffect(() => {
		if (!startWorker) return;
		createWorker();
		return function destroy() {
			workerRef.current?.terminate();
		};
	}, [createWorker, startWorker]);
	React.useEffect(() => {
		if (list.length && query) {
			if (isWorkerWorking.current) {
				workerRef.current?.terminate();
				createWorker();
			}
			const canFilterPreviousMatches = lastQueryRef.current && query.startsWith(lastQueryRef.current);
			isWorkerWorking.current = true;
			workerRef.current?.postMessage({
				baseList: canFilterPreviousMatches && matches || list,
				query,
				startTime: performance.now()
			});
		}
	}, [
		list,
		query,
		createWorker
	]);
	return {
		matches,
		clearMatches: () => setMatches(void 0)
	};
}
function parseQuery(query) {
	query = query.replaceAll(" ", "");
	const colonIndex = query.indexOf(":");
	if (colonIndex >= 0) return {
		queryText: query.substring(0, colonIndex),
		queryLine: parseInt(query.substring(colonIndex + 1), 10)
	};
	return {
		queryText: query,
		queryLine: void 0
	};
}
var MultiFilePicker_module_default = {
	Box: "MultiFilePicker-module_Sv_5ma_Box",
	Dialog: "MultiFilePicker-module_Sv_5ma_Dialog",
	Dialog_1: "MultiFilePicker-module_Sv_5ma_Dialog_1",
	dialogHeader: "MultiFilePicker-module_Sv_5ma_dialogHeader"
};
var SUPPORTED_FILE_EXTENSIONS = new Set(Object.values(languageMap).flatMap((lang) => lang.extensions ?? []));
var DENIED_FILE_EXTENSIONS = new Set([
	".png",
	".jpg",
	".jpeg",
	".gif",
	".bmp",
	".svg",
	".webp",
	".ico",
	".tiff",
	".tif"
]);
/**
* Checks if a file path has a supported extension for Copilot Spaces.
* Uses an allowlist approach based on GitHub Linguist data (1400+ file types).
* Files without extensions are always supported.
* Directories are always considered supported.
*
* @param filePath - The path of the file to check
* @param isDirectory - Whether the path represents a directory
* @returns true if the file is supported or is a directory, false otherwise
*/
function isSupportedFileType(filePath, isDirectory) {
	if (isDirectory) return true;
	const lastDotIndex = filePath.lastIndexOf(".");
	const lastSlashIndex = filePath.lastIndexOf("/");
	if (lastDotIndex === -1 || lastDotIndex < lastSlashIndex) return true;
	const extension = filePath.substring(lastDotIndex).toLowerCase();
	return SUPPORTED_FILE_EXTENSIONS.has(extension) && !DENIED_FILE_EXTENSIONS.has(extension);
}
function createFormDataEntry(path, type, currentRepo) {
	return {
		id: `${currentRepo.id}${type === "github_folder" ? "-folder" : ""}-${path}`,
		repositoryId: currentRepo.id,
		nwo: `${currentRepo.ownerLogin}/${currentRepo.name}`,
		filePath: path,
		sha: currentRepo.defaultBranch,
		type
	};
}
function processFileSelection(selectedItems, allDirectories, currentRepo, shouldAutoFolderize, effectiveMaxFileCount, allowFolderReferences) {
	const selectedFolders = Array.from(selectedItems).filter((path) => allDirectories.has(path));
	const selectedFiles = Array.from(selectedItems).filter((path) => !allDirectories.has(path));
	if (!allowFolderReferences) return selectedFiles.map((path) => createFormDataEntry(path, "github_file", currentRepo));
	const formData = [];
	const processedPaths = /* @__PURE__ */ new Set();
	for (const folder of selectedFolders) {
		if (selectedFolders.some((other) => other !== folder && folder.startsWith(`${other}/`))) continue;
		const filesInFolder = selectedFiles.filter((file) => file.startsWith(`${folder}/`));
		if (allowFolderReferences && filesInFolder.length === 0) {
			formData.push(createFormDataEntry(folder, "github_folder", currentRepo));
			continue;
		}
		if (allowFolderReferences && filesInFolder.length >= effectiveMaxFileCount) {
			formData.push(createFormDataEntry(folder, "github_folder", currentRepo));
			for (const file of filesInFolder) processedPaths.add(file);
		} else for (const file of filesInFolder) {
			formData.push(createFormDataEntry(file, "github_file", currentRepo));
			processedPaths.add(file);
		}
	}
	const uncoveredFiles = selectedFiles.filter((file) => !processedPaths.has(file));
	if (!shouldAutoFolderize || !allowFolderReferences) for (const file of uncoveredFiles) formData.push(createFormDataEntry(file, "github_file", currentRepo));
	else {
		const filesByDirectory = /* @__PURE__ */ new Map();
		for (const file of uncoveredFiles) {
			const lastSlash = file.lastIndexOf("/");
			const parentDir = lastSlash > 0 ? file.substring(0, lastSlash) : "";
			if (!filesByDirectory.has(parentDir)) filesByDirectory.set(parentDir, []);
			filesByDirectory.get(parentDir)?.push(file);
		}
		for (const [parentDir, files] of filesByDirectory) if (parentDir === "") for (const file of files) formData.push(createFormDataEntry(file, "github_file", currentRepo));
		else formData.push(createFormDataEntry(parentDir, "github_folder", currentRepo));
	}
	return formData;
}
function truncatePathsByLength(path, maxLength = 30) {
	return path.length <= maxLength ? path : `...${path.slice(-maxLength)}`;
}
function FilteredFilesWarning({ files, error }) {
	if (files.length === 0) return null;
	if (files.length === 1 && files[0]) return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		error ? "This file can't be submitted: " : "This file was filtered out: ",
		" ",
		/* @__PURE__ */ jsx("strong", { children: truncatePathsByLength(files[0]) }),
		". Only supported file types are allowed."
	] });
	const displayFiles = files.slice(0, 3);
	const remainingCount = files.length - 3;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("span", { children: error ? "These files can't be submitted: " : "These files were filtered out: " }),
		displayFiles.map((path, index) => /* @__PURE__ */ jsxs("span", { children: [index > 0 && /* @__PURE__ */ jsx("span", { children: ", " }), /* @__PURE__ */ jsx("strong", { children: truncatePathsByLength(path) })] }, path)),
		remainingCount > 0 && /* @__PURE__ */ jsxs("span", { children: [
			", and ",
			remainingCount,
			" more"
		] }),
		/* @__PURE__ */ jsx("span", { children: ". Only supported file types are allowed." })
	] });
}
FilteredFilesWarning.displayName = "FilteredFilesWarning";
function FilePickerForm({ currentRepo, setLocalFormData, fetchError, onFileCountChange, expandedPath, resourceCounts, allowFolderReferences, maxFileCount, onRejectionMessage, onDisplayCountChange, onFilteredFilesChange }) {
	const [selectedItems, setSelectedItems] = useState(() => /* @__PURE__ */ new Set());
	const [allDirectories, setAllDirectories] = useState(() => /* @__PURE__ */ new Set());
	const effectiveMaxFileCount = maxFileCount ?? 50;
	const { list, directories, loading } = useTreeList(currentRepo.commitOID, true);
	const [rootItems, setRootItems] = useState([]);
	useEffect(() => {
		setRootItems(convertFlatPathsToTreeItems({
			paths: list,
			directories
		}));
		setAllDirectories(new Set(directories));
	}, [
		list,
		directories,
		setRootItems,
		currentRepo.commitOID
	]);
	useEffect(() => {
		const selectedFiles = Array.from(selectedItems).filter((path) => !allDirectories.has(path));
		const selectedDirectories = Array.from(selectedItems).filter((path) => allDirectories.has(path));
		onFileCountChange?.(selectedFiles.length);
		let shouldAutoFolderize = false;
		if (allowFolderReferences && selectedFiles.length > 0) {
			const selectedFolderPrefixes = selectedDirectories.map((f) => `${f}/`);
			const uncoveredFiles = selectedFiles.filter((path) => !selectedFolderPrefixes.some((prefix) => path.startsWith(prefix)));
			const hasGroupableFiles = uncoveredFiles.some((path) => path.includes("/"));
			shouldAutoFolderize = uncoveredFiles.length > effectiveMaxFileCount && hasGroupableFiles;
		}
		const result = processFileSelection(selectedItems, allDirectories, currentRepo, shouldAutoFolderize, effectiveMaxFileCount, allowFolderReferences ?? false);
		setLocalFormData(result);
		if (onDisplayCountChange) onDisplayCountChange(result.length);
	}, [
		selectedItems,
		allDirectories,
		currentRepo,
		setLocalFormData,
		onFileCountChange,
		onDisplayCountChange,
		allowFolderReferences,
		effectiveMaxFileCount
	]);
	const getItemUrl = useCallback((item) => `/${`${currentRepo.name}/${currentRepo.ownerLogin}`}/tree/${currentRepo.refInfo.name}/${item.path}`, [currentRepo]);
	const handleSelectionChange = useCallback((newSelectedItems) => {
		const newlySelectedPaths = Array.from(newSelectedItems).filter((path) => !selectedItems.has(path));
		const unsupportedFiles = [];
		const filteredPaths = [];
		for (const path of newlySelectedPaths) if (isSupportedFileType(path, allDirectories.has(path))) filteredPaths.push(path);
		else unsupportedFiles.push(path);
		const filteredSelection = /* @__PURE__ */ new Set();
		for (const path of selectedItems) if (newSelectedItems.has(path)) filteredSelection.add(path);
		for (const path of filteredPaths) filteredSelection.add(path);
		if (unsupportedFiles.length > 0) onFilteredFilesChange?.(unsupportedFiles);
		else if (filteredSelection.size <= selectedItems.size) onFilteredFilesChange?.([]);
		if (filteredSelection.size <= selectedItems.size) {
			setSelectedItems(filteredSelection);
			onRejectionMessage?.(null);
			return;
		}
		if (!allowFolderReferences) {
			const selectedFiles = Array.from(filteredSelection).filter((path) => !allDirectories.has(path));
			const capacity = resourceCounts ? resourceCounts.maxResourceCount - resourceCounts.currentResourceCount : effectiveMaxFileCount;
			if (selectedFiles.length > capacity) {
				const errorMessage = resourceCounts ? `${resourceCounts.currentResourceCount + selectedFiles.length} / ${resourceCounts.maxResourceCount} possible sources selected, add fewer files.` : `Up to ${effectiveMaxFileCount} files can be added at a time.`;
				onRejectionMessage?.(errorMessage);
				setSelectedItems(filteredSelection);
				return;
			}
			onRejectionMessage?.(null);
			setSelectedItems(filteredSelection);
			return;
		}
		const selectedFiles = Array.from(filteredSelection).filter((path) => !allDirectories.has(path));
		const selectedFolderPrefixes = Array.from(filteredSelection).filter((path) => allDirectories.has(path)).map((f) => `${f}/`);
		const uncoveredFiles = selectedFiles.filter((path) => !selectedFolderPrefixes.some((prefix) => path.startsWith(prefix)));
		const hasGroupableFiles = uncoveredFiles.some((path) => path.includes("/"));
		if (processFileSelection(filteredSelection, allDirectories, currentRepo, uncoveredFiles.length > effectiveMaxFileCount && hasGroupableFiles, effectiveMaxFileCount, allowFolderReferences).length > effectiveMaxFileCount) {
			setSelectedItems(filteredSelection);
			return;
		}
		setSelectedItems(filteredSelection);
	}, [
		selectedItems,
		effectiveMaxFileCount,
		allDirectories,
		allowFolderReferences,
		onRejectionMessage,
		currentRepo,
		resourceCounts,
		onFilteredFilesChange
	]);
	return /* @__PURE__ */ jsx("div", {
		className: MultiFilePicker_module_default.Box,
		children: /* @__PURE__ */ jsx(FileTreePicker, {
			rootItems,
			expandedPath,
			selectedItemRef: () => {},
			setRootItems,
			navigateOnClick: false,
			directoryNavigateOnClick: false,
			selectedItems,
			onSelectionChange: handleSelectionChange,
			loading: loading || false,
			fetchError: !!fetchError,
			getItemUrl,
			allowFolderReferences: Boolean(allowFolderReferences),
			sortDirectoryItems: (items) => items.sort((a, b) => a.data.name.localeCompare(b.data.name))
		})
	});
}
FilePickerForm.displayName = "FilePickerForm";
function CloseButton({ onClose }) {
	return /* @__PURE__ */ jsx(IconButton, {
		icon: XIcon,
		"aria-label": "Close",
		onClick: onClose,
		variant: "invisible"
	});
}
CloseButton.displayName = "CloseButton";
function MultiFilePicker({ formData, onCancel, onSaveFiles, findFileWorkerPath, attachmentButtonRef, owner, resourceCounts, initialRepo, onRepoSelect, hideBackButton = false, allowFolderReferences = false, maxFileCount = 50 }) {
	const [repoDetailsCache, setRepoDetailsCache] = useState({});
	const [fetchError, setFetchError] = useState(null);
	const [currentRepo, setCurrentRepo] = useState(initialRepo || null);
	const [openRepoPicker, setOpenRepoPicker] = useState(true);
	const [localFormData, setLocalFormData] = useState(formData);
	const [isSaving, setIsSaving] = useState(false);
	const [savingError, setSavingError] = useState(null);
	const [expandedPath, setExpandedPath] = useState("");
	const [rejectionMessage, setRejectionMessage] = useState(null);
	const [displayCount, setDisplayCount] = useState(0);
	const [selectedFileCount, setSelectedFileCount] = useState(0);
	const [filteredFiles, setFilteredFiles] = useState([]);
	const selectingRepo = useRef(false);
	const fetchRepoAndUpdateState = async (repoID) => {
		selectingRepo.current = true;
		let payload;
		if (repoDetailsCache[repoID]) {
			payload = repoDetailsCache[repoID];
			setCurrentRepo(payload);
			onRepoSelect?.(payload);
			return;
		}
		try {
			payload = await fetchRepo(repoID);
			setRepoDetailsCache((prev) => ({
				...prev,
				[repoID]: payload
			}));
			setCurrentRepo(payload);
			onRepoSelect?.(payload);
			setOpenRepoPicker(false);
		} catch (error) {
			setFetchError(error instanceof Error ? error.message : "An unknown error occurred");
		}
		selectingRepo.current = false;
	};
	const onSelectRepo = () => {
		onRepoSelect?.(null);
		setCurrentRepo(null);
		setLocalFormData([]);
		setOpenRepoPicker(true);
	};
	const validateTotalResourceCount = resourceCounts !== void 0;
	const fileCountExceeded = (validateTotalResourceCount ? selectedFileCount : displayCount) > (validateTotalResourceCount ? resourceCounts.maxResourceCount - resourceCounts.currentResourceCount : maxFileCount);
	const handleSave = async () => {
		setIsSaving(true);
		try {
			if (fileCountExceeded) return;
			sendEvent("copilot-spaces.click", { target: "SAVED_FILES_FROM_FILE_PICKER" });
			await onSaveFiles(localFormData);
		} catch (error) {
			const errorMessageObj = {
				errorMessage: "An unknown error occurred",
				filePaths: []
			};
			if (error && typeof error === "object" && "base" in error && typeof error.base === "string") if (error.base.startsWith("unsupported_file_type") && "files" in error) errorMessageObj.filePaths = error.files;
			else if (error.base.startsWith("The size of the space exceeds the current limit")) errorMessageObj.errorMessage = "The size of the space exceeds the current limit";
			else errorMessageObj.errorMessage = error.base;
			setSavingError(errorMessageObj);
		} finally {
			setIsSaving(false);
		}
	};
	useEffect(() => {
		setSavingError(null);
	}, [localFormData]);
	const errorMessage = fileCountExceeded ? validateTotalResourceCount ? `${resourceCounts.currentResourceCount + selectedFileCount} / ${resourceCounts.maxResourceCount} possible sources selected, add fewer files.` : `Up to ${maxFileCount} items can be added at a time.` : rejectionMessage;
	const hasError = fileCountExceeded || Boolean(rejectionMessage);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(RepoSelectPanel, {
		selectionVariant: "instant",
		open: !currentRepo && openRepoPicker,
		onOpenChange: (newOpen) => {
			if (!selectingRepo.current) {
				setOpenRepoPicker(newOpen);
				onCancel();
			}
		},
		selectedRepoIds: /* @__PURE__ */ new Set(),
		onSelectRepo: async (repoId) => {
			if (!repoId) return;
			setLocalFormData([]);
			sendEvent("copilot-spaces.click", { target: "SELECTED_REPO_FROM_REPO_PICKER" });
			await fetchRepoAndUpdateState(repoId);
		},
		cancelReturnFocusRef: attachmentButtonRef,
		submitReturnFocusRef: attachmentButtonRef,
		error: fetchError ?? void 0,
		ownerDisplayLogin: owner,
		includeForks: true
	}), currentRepo && /* @__PURE__ */ jsx(Dialog, {
		onClose: onCancel,
		title: `Add files from ${currentRepo.ownerLogin}/${currentRepo.name}`,
		width: "large",
		position: { narrow: "fullscreen" },
		renderHeader: ({ onClose, dialogLabelId }) => {
			return /* @__PURE__ */ jsxs(Dialog.Header, { children: [/* @__PURE__ */ jsx("div", {
				className: MultiFilePicker_module_default.dialogHeader,
				children: /* @__PURE__ */ jsx(Dialog.Title, {
					id: dialogLabelId,
					children: /* @__PURE__ */ jsxs(Stack, {
						align: "center",
						direction: "horizontal",
						gap: "none",
						children: [
							!hideBackButton && /* @__PURE__ */ jsx(Stack.Item, { children: /* @__PURE__ */ jsx(IconButton, {
								icon: ArrowLeftIcon,
								"aria-label": "Back",
								onClick: onSelectRepo,
								variant: "invisible"
							}) }),
							/* @__PURE__ */ jsxs(Stack.Item, {
								grow: true,
								className: "mx-1",
								children: [
									"Select folders and files in ",
									currentRepo.ownerLogin,
									"/",
									currentRepo.name
								]
							}),
							/* @__PURE__ */ jsx(Stack.Item, { children: /* @__PURE__ */ jsx(CloseButton, { onClose: () => onClose("close-button") }) })
						]
					})
				})
			}), /* @__PURE__ */ jsx(Dialog.Subtitle, {
				className: "mt-0",
				children: /* @__PURE__ */ jsx(CurrentRepositoryProvider, {
					repository: currentRepo,
					children: /* @__PURE__ */ jsx(FileQueryProvider, { children: /* @__PURE__ */ jsx(PathProvider, {
						path: "test",
						children: /* @__PURE__ */ jsx(ActionProvider, {
							action: "tree",
							children: /* @__PURE__ */ jsx(CopilotSettingsProvider, {
								copilotAccessAllowed: true,
								children: /* @__PURE__ */ jsx(RefInfoProvider, {
									refInfo: {
										name: currentRepo.refInfo.name,
										canEdit: true,
										listCacheKey: "anything",
										currentOid: currentRepo.commitOID
									},
									children: /* @__PURE__ */ jsx(EditPermissionsProvider, {
										canEdit: true,
										canEditOnDefaultBranch: false,
										fileExistsOnDefault: false,
										children: /* @__PURE__ */ jsx(AllShortcutsEnabledProvider, {
											allShortcutsEnabled: false,
											children: /* @__PURE__ */ jsx(FileResultsList, {
												commitOid: currentRepo.commitOID,
												findFileWorkerPath,
												onItemSelected: (path) => {
													if (path) setExpandedPath(path);
												},
												config: {
													enableOverlay: true,
													disableNavigation: true,
													searchPlaceholder: "Search for files or folders",
													actionText: "Search for files or folders"
												}
											})
										})
									})
								})
							})
						})
					}) })
				})
			})] });
		},
		renderFooter: () => /* @__PURE__ */ jsx(Dialog.Footer, { children: /* @__PURE__ */ jsxs("div", {
			className: "d-flex flex-justify-between flex-items-center width-full",
			children: [/* @__PURE__ */ jsx("div", {
				className: "d-flex flex-items-center",
				children: errorMessage && /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: errorMessage
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: "d-flex flex-row flex-justify-end gap-2",
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					onClick: onCancel,
					children: "Cancel"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					...testIdProps("save-resource-button"),
					variant: "primary",
					onClick: handleSave,
					count: isSaving ? void 0 : (validateTotalResourceCount ? selectedFileCount : displayCount) || void 0,
					loading: isSaving,
					disabled: hasError,
					children: "Add"
				})]
			})]
		}) }),
		renderBody: () => /* @__PURE__ */ jsxs("div", {
			className: "d-flex flex-column",
			children: [
				fetchError && /* @__PURE__ */ jsx("span", { children: fetchError }),
				savingError && /* @__PURE__ */ jsx("div", {
					className: "position-sticky top-0 bgColor-default flash-banner",
					children: /* @__PURE__ */ jsx(Flash, {
						full: true,
						variant: "danger",
						children: savingError.filePaths.length > 0 ? /* @__PURE__ */ jsx(FilteredFilesWarning, {
							files: savingError.filePaths,
							error: true
						}) : /* @__PURE__ */ jsx("span", { children: savingError.errorMessage })
					})
				}),
				filteredFiles.length > 0 && /* @__PURE__ */ jsx("div", {
					className: "position-sticky top-0 bgColor-default flash-banner",
					children: /* @__PURE__ */ jsx(Flash, {
						full: true,
						variant: "warning",
						children: /* @__PURE__ */ jsx(FilteredFilesWarning, { files: filteredFiles })
					})
				}),
				/* @__PURE__ */ jsx(CurrentRepositoryProvider, {
					repository: currentRepo,
					children: /* @__PURE__ */ jsx(FileQueryProvider, { children: /* @__PURE__ */ jsx(PathProvider, {
						path: "test",
						children: /* @__PURE__ */ jsx(ActionProvider, {
							action: "tree",
							children: /* @__PURE__ */ jsx(CopilotSettingsProvider, {
								copilotAccessAllowed: true,
								children: /* @__PURE__ */ jsx(RefInfoProvider, {
									refInfo: {
										name: currentRepo.refInfo.name,
										canEdit: true,
										listCacheKey: "anything",
										currentOid: currentRepo.commitOID
									},
									children: /* @__PURE__ */ jsx(EditPermissionsProvider, {
										canEdit: true,
										canEditOnDefaultBranch: false,
										fileExistsOnDefault: false,
										children: /* @__PURE__ */ jsx(FilePickerForm, {
											expandedPath,
											currentRepo,
											localFormData,
											setLocalFormData,
											onFileCountChange: setSelectedFileCount,
											onDisplayCountChange: setDisplayCount,
											fetchError,
											resourceCounts,
											allowFolderReferences,
											maxFileCount,
											onRejectionMessage: setRejectionMessage,
											onFilteredFilesChange: setFilteredFiles
										})
									})
								})
							})
						})
					}) })
				})
			]
		}),
		className: MultiFilePicker_module_default.Dialog
	})] });
}
MultiFilePicker.displayName = "MultiFilePicker";
function CopilotFilePicker({ isOpen, onClose, initialRepo, onRepoSelect }) {
	const manager = useChatManager();
	const { findFileWorkerPath } = useChatState();
	const attachmentButtonRef = useRef(null);
	const handleSaveFiles = useCallback(async (formData) => {
		if (formData.length === 0) {
			onClose();
			return;
		}
		const repo = await fetchRepo(formData[0].repositoryId);
		const references = formData.map((item) => {
			if (item.type === "github_folder") return makeFolderReference(item.filePath, repo);
			else return makeFileReference(item.filePath, repo);
		});
		for (const reference of references) manager.addReference(reference, "references-menu");
		onClose();
	}, [manager, onClose]);
	if (!isOpen) return null;
	return /* @__PURE__ */ jsx(MultiFilePicker, {
		formData: [],
		onCancel: onClose,
		onSaveFiles: handleSaveFiles,
		findFileWorkerPath,
		attachmentButtonRef,
		initialRepo,
		onRepoSelect,
		allowFolderReferences: true,
		maxFileCount: 20
	});
}
CopilotFilePicker.displayName = "CopilotFilePicker";
var AttachmentMenu = memo(({ panel, onPanelChange: setPanel, anchorRef, initialRepo, onRepoSelect, ...props }) => {
	const { inputRef } = props;
	const manager = useChatManager();
	const state = useChatState();
	const plugins = usePlugins();
	const { supportedAttachmentTypes, supportedReferenceTypes } = useSupportedAttachmentTypes();
	const { model } = useChatStateValues("model");
	const previewFeaturesDisabled = copilotFeatureFlags.previewFeaturesVisionGate && state.hasCEorCBAccess && !state.optedInToPreviewFeatures;
	const imageUploadsEnabled = state.mode === "immersive" && !!model.capabilities?.supports?.vision && !previewFeaturesDisabled || false;
	const insertAgent = useInsertAgent(props);
	const fileInputRef = useRef(null);
	const { handleSpaceSelect: setPendingSpace, clearSpaceSelection, activeCopilotSpaceId, readOnly } = useSpaceSelection();
	const [showCreateSpaceDialog, setShowCreateSpaceDialog] = useState(false);
	return /* @__PURE__ */ jsxs("div", { children: [
		supportedAttachmentTypes.includes("upload") && /* @__PURE__ */ jsx("input", {
			id: "image-uploader",
			...testIdProps("image-uploader"),
			hidden: true,
			ref: fileInputRef,
			type: "file",
			accept: [imageUploadsEnabled ? CopilotImageAttacher.getAllowedImageFileExtensions(model) : "", CopilotTextAttacher.getTextFileExtensions()].join(","),
			multiple: true,
			onChange: (e) => {
				if (!e.target.files) return;
				const [imageFiles, otherFiles] = CopilotImageAttacher.getAllowedFiles([...e.target.files], model);
				const unsupportedFiles = [];
				if (imageUploadsEnabled) new CopilotImageAttacher(state, manager).addImageAttachments(imageFiles, "menu");
				else unsupportedFiles.push(...imageFiles);
				for (const file of otherFiles) new CopilotTextAttacher(manager).addAttachment(file);
				for (const file_0 of unsupportedFiles) sendEvent("dotcom_chat.upload_unsupported_file", {
					name: file_0.name,
					type: file_0.type,
					size: file_0.size
				});
				e.currentTarget.value = "";
			}
		}),
		/* @__PURE__ */ jsx(ActionMenu, {
			anchorRef,
			open: panel === "attachment-types",
			onOpenChange: (newOpen) => setPanel((currentOpen) => {
				if (newOpen && currentOpen === null) return "attachment-types";
				if (!newOpen && currentOpen === "attachment-types") return null;
				return currentOpen;
			}),
			children: /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "small",
				side: props.side ?? "outside-bottom",
				position: state.mode === "assistive" ? "relative" : void 0,
				align: "start",
				portalContainerName: state.mode === "assistive" ? COPILOT_CHAT_MENU_PORTAL_ROOT : void 0,
				children: /* @__PURE__ */ jsxs(ActionList, { children: [
					!copilotFeatureFlags.copilotChatRepositoryPicker && supportedAttachmentTypes.includes("repositories") && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							sendEvent("dotcom_chat.activate", {
								target: "ATTACHMENT_MENU_REPOSITORIES",
								action: "open",
								component: "ATTACHMENT_MENU",
								mode: state.mode
							});
							setPanel("repositories");
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(RepoIcon, {}) }), "Repositories…"]
					}),
					/* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							sendEvent("dotcom_chat.activate", {
								target: "ATTACHMENT_MENU_MULTI_FILE_PICKER",
								mode: state.mode
							});
							setPanel("multi-file-picker");
						},
						children: [
							/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(FileCodeIcon, {}) }),
							getReferenceTypeLabel(supportedReferenceTypes),
							"…"
						]
					}),
					supportedAttachmentTypes.includes("copilot-spaces") && /* @__PURE__ */ jsx(SpacesSelectNew, {
						openCreateSpaceDialog: setShowCreateSpaceDialog,
						setPendingSpace,
						clearSpaceSelection,
						activeCopilotSpaceId,
						readOnly
					}),
					plugins.map((p) => {
						const contribution = p.attachmentMenuContribution;
						if (!contribution) return null;
						return /* @__PURE__ */ jsx(contribution.MenuItemComponent, { onSelect: () => setPanel(contribution.attachmentType) }, p.id);
					}),
					supportedAttachmentTypes.includes("upload") && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							sendEvent("dotcom_chat.activate", {
								target: "ATTACHMENT_MENU_IMAGES",
								mode: state.mode
							});
							setPanel(null);
							fileInputRef.current?.click();
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(UploadIcon, {}) }), "Upload from computer"]
					})] }),
					supportedAttachmentTypes.includes("agents") && !copilotFeatureFlags.hideExtensionsInDotcomChat && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsx(AgentMenu, {
						onSelectPanel: (value) => setPanel(value),
						onSelectAgent: (agent) => setTimeout(() => insertAgent(agent.slug))
					})] })
				] })
			})
		}),
		panel === "multi-file-picker" && /* @__PURE__ */ jsx(CopilotFilePicker, {
			isOpen: true,
			onClose: () => setPanel(null),
			initialRepo,
			onRepoSelect
		}),
		!copilotFeatureFlags.copilotChatRepositoryPicker && /* @__PURE__ */ jsx(RepoReferencesSelectPanel, {
			open: panel === "repositories",
			onOpenChange: (val) => setPanel(val ? "repositories" : null),
			submitReturnFocusRef: inputRef,
			cancelReturnFocusRef: anchorRef,
			onRepoSelect
		}),
		showCreateSpaceDialog && /* @__PURE__ */ jsx(CreateSpaceDialog, {
			closeDialog: () => setShowCreateSpaceDialog(false),
			onSubmit: () => {
				sendEvent("dotcom_chat.activate", {
					target: "ATTACHMENT_MENU_COPILOT_SPACES_SPACE_CREATED",
					mode: "immersive"
				});
			}
		}),
		panel === "no-agents-available" && /* @__PURE__ */ jsx(NoAgentsAvailableDialog, {
			onClose: () => setPanel(null),
			returnFocusRef: anchorRef
		}),
		panel === "agents-not-supported" && /* @__PURE__ */ jsx(AgentsNotSupportedDialog, {
			onClose: () => setPanel(null),
			returnFocusRef: anchorRef
		}),
		supportedAttachmentTypes.includes("plugin-attachment-contribution") && plugins.map((p_0) => {
			if (!p_0.attachmentMenuContribution) return null;
			if (p_0.attachmentMenuContribution.attachmentType !== panel) return null;
			return /* @__PURE__ */ jsx(p_0.attachmentMenuContribution.PanelComponent, {
				onSubmit: () => {
					setPanel(null);
					inputRef.current?.focus();
				},
				onDismiss: () => {
					setPanel(null);
					anchorRef.current?.focus();
				}
			}, p_0.id);
		})
	] });
});
AttachmentMenu.displayName = "AttachmentMenu";
AttachmentMenu.displayName = "AttachmentMenu";
var categoryNames = {
	agents: "Extensions",
	repositories: "Repositories",
	files: "Files and folders",
	issues: "Issues",
	pulls: "Pull requests",
	discussions: "Discussions"
};
var topLevelCategories = [
	{
		name: categoryNames.agents,
		icon: AppsIcon,
		value: "agents",
		where: "start"
	},
	{
		name: categoryNames.repositories,
		icon: RepoIcon,
		value: "repositories",
		where: "anywhere"
	},
	{
		name: categoryNames.files,
		icon: FileIcon,
		value: "repositories:files",
		where: "anywhere"
	},
	{
		name: categoryNames.issues,
		icon: IssueOpenedIcon,
		value: "repositories:issues",
		where: "anywhere"
	},
	{
		name: categoryNames.pulls,
		icon: GitPullRequestIcon,
		value: "repositories:pulls",
		where: "anywhere"
	},
	{
		name: categoryNames.discussions,
		icon: CommentDiscussionIcon,
		value: "repositories:discussions",
		where: "anywhere"
	}
];
function getTopLevelCategories() {
	if (copilotFeatureFlags.hideExtensionsInDotcomChat) return topLevelCategories.filter((cat) => cat.value !== "agents");
	return topLevelCategories;
}
var CategoryValue = { is: (str) => topLevelCategories.some((category) => category.value === str) };
/**
* Handles opening the appropriate agents dialog when required.
*/
function useAutocompleteAgentsDialogs(t0) {
	const $ = c(12);
	const { query, onShowAgentsDialog } = t0;
	const active = query?.category === "agents";
	const { availableAgents, loading, disabled } = useAvailableAgents(active);
	let t1;
	if ($[0] !== active || $[1] !== availableAgents?.length || $[2] !== disabled || $[3] !== loading || $[4] !== onShowAgentsDialog) {
		t1 = () => {
			if (!active || loading) return;
			if (disabled) onShowAgentsDialog("agents-not-supported");
			else if (!availableAgents?.length) onShowAgentsDialog("no-agents-available");
		};
		$[0] = active;
		$[1] = availableAgents?.length;
		$[2] = disabled;
		$[3] = loading;
		$[4] = onShowAgentsDialog;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== active || $[7] !== availableAgents || $[8] !== disabled || $[9] !== loading || $[10] !== onShowAgentsDialog) {
		t2 = [
			active,
			loading,
			availableAgents,
			disabled,
			onShowAgentsDialog
		];
		$[6] = active;
		$[7] = availableAgents;
		$[8] = disabled;
		$[9] = loading;
		$[10] = onShowAgentsDialog;
		$[11] = t2;
	} else t2 = $[11];
	useEffect(t1, t2);
}
function AgentSuggestion({ agent, ...props }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, { src: agent.avatarUrl }) }),
			agent.name,
			/* @__PURE__ */ jsxs(ActionList.Description, {
				variant: "inline",
				truncate: true,
				children: ["@", agent.slug]
			})
		]
	});
}
AgentSuggestion.displayName = "AgentSuggestion";
function LinkSuggestion(t0) {
	const { leadingVisual, ...props } = t0;
	const nameId = useId();
	const hintId = useId();
	return jsxs(ActionList.Item, {
		...props,
		"aria-labelledby": clsx(nameId, hintId),
		children: [
			leadingVisual !== void 0 && jsx(ActionList.LeadingVisual, { children: leadingVisual }),
			jsx("span", {
				id: nameId,
				children: props.children
			}),
			jsx("span", {
				className: "d-none",
				"aria-hidden": true,
				id: hintId,
				children: "Opens in new tab."
			}),
			jsx(ActionList.TrailingVisual, { children: jsx(LinkExternalIcon, {}) })
		]
	});
}
LinkSuggestion.displayName = "LinkSuggestion";
function useAgentsSuggestions(query) {
	const $ = c(4);
	const { availableAgents, loading, showLimit, disabled } = useAvailableAgents(query !== null);
	let t0;
	bb0: {
		if (disabled || !query) {
			t0 = null;
			break bb0;
		}
		if (loading && !availableAgents) {
			t0 = "loading";
			break bb0;
		}
		let t1;
		if ($[0] !== availableAgents || $[1] !== query || $[2] !== showLimit) {
			t1 = availableAgents?.filter((agent) => query?.category === "agents" && agent.name.toLowerCase().includes(query.filter.toLowerCase())).map(_temp$13).concat({
				value: null,
				key: `open-link:https://github.com/marketplace?type=apps&copilot_app=true`,
				render: (props_0) => jsxs(Fragment$1, { children: [availableAgents.length > 0 && jsx(ActionList.Divider, {}), jsx(LinkSuggestion, {
					leadingVisual: jsx(TelescopeIcon, {}),
					...props_0,
					inactiveText: showLimit ? "Start a new conversation to use other extensions." : void 0,
					children: "Marketplace"
				})] })
			}) ?? null;
			$[0] = availableAgents;
			$[1] = query;
			$[2] = showLimit;
			$[3] = t1;
		} else t1 = $[3];
		t0 = t1;
	}
	return t0;
}
function _temp$13(agent_0) {
	return {
		value: `@${agent_0.slug}`,
		render: (props) => jsx(AgentSuggestion, {
			agent: agent_0,
			...props
		})
	};
}
function MultistepSuggestion({ leadingVisual, ...props }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		"aria-haspopup": true,
		...props,
		children: [
			leadingVisual !== void 0 && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: leadingVisual }),
			props.children,
			/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(ArrowRightIcon, {}) })
		]
	});
}
MultistepSuggestion.displayName = "MultistepSuggestion";
function CategorySuggestion({ category: { name, icon: Icon }, ...props }) {
	return /* @__PURE__ */ jsx(MultistepSuggestion, {
		leadingVisual: /* @__PURE__ */ jsx(Icon, {}),
		...props,
		children: name
	});
}
CategorySuggestion.displayName = "CategorySuggestion";
var shared_module_default = {
	asyncSuggestion: "shared-module_9ie0lW_asyncSuggestion",
	stale: "shared-module_9ie0lW_stale"
};
function DiscussionSuggestion({ discussion, stale, className, ...props }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		className: clsx(shared_module_default.asyncSuggestion, stale && shared_module_default.stale, className),
		children: [
			/* @__PURE__ */ jsxs(ActionList.LeadingVisual, { children: [discussion.state === "open" && /* @__PURE__ */ jsx(CommentDiscussionIcon, { className: "fgColor-open" }), discussion.state === "closed" && /* @__PURE__ */ jsx(DiscussionClosedIcon, { className: "fgColor-muted" })] }),
			/* @__PURE__ */ jsx(Truncate, {
				title: discussion.title,
				maxWidth: 350,
				children: discussion.title
			}),
			/* @__PURE__ */ jsxs(ActionList.Description, { children: ["#", discussion.number] })
		]
	});
}
DiscussionSuggestion.displayName = "DiscussionSuggestion";
function FileSuggestion({ type, path, stale, className, ...props }) {
	const parts = path.split("/");
	const name = parts.pop();
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		className: clsx(shared_module_default.asyncSuggestion, stale && shared_module_default.stale, className),
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: type === "folder" ? /* @__PURE__ */ jsx(FileDirectoryFillIcon, {}) : /* @__PURE__ */ jsx(FileIcon, {}) }),
			name,
			/* @__PURE__ */ jsxs(ActionList.Description, {
				variant: "inline",
				children: [parts.join("/"), "/"]
			})
		]
	});
}
FileSuggestion.displayName = "FileSuggestion";
function IssueSuggestion({ issue, stale, className, ...props }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		className: clsx(shared_module_default.asyncSuggestion, stale && shared_module_default.stale, className),
		children: [
			/* @__PURE__ */ jsxs(ActionList.LeadingVisual, { children: [
				issue.state === "draft" && /* @__PURE__ */ jsx(IssueDraftIcon, { className: "fgColor-draft" }),
				issue.state === "open" && /* @__PURE__ */ jsx(IssueOpenedIcon, { className: "fgColor-open" }),
				issue.state === "closed" && /* @__PURE__ */ jsx(IssueClosedIcon, { className: "fgColor-done" })
			] }),
			/* @__PURE__ */ jsx(Truncate, {
				title: issue.title,
				maxWidth: 350,
				children: issue.title
			}),
			/* @__PURE__ */ jsxs(ActionList.Description, { children: ["#", issue.number] })
		]
	});
}
IssueSuggestion.displayName = "IssueSuggestion";
function PullRequestSuggestion({ pullRequest, stale, className, ...props }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		className: clsx(shared_module_default.asyncSuggestion, stale && shared_module_default.stale, className),
		children: [
			/* @__PURE__ */ jsxs(ActionList.LeadingVisual, { children: [
				pullRequest.state === "draft" && /* @__PURE__ */ jsx(GitPullRequestDraftIcon, { className: "fgColor-draft" }),
				pullRequest.state === "open" && /* @__PURE__ */ jsx(GitPullRequestIcon, { className: "fgColor-open" }),
				pullRequest.state === "closed" && /* @__PURE__ */ jsx(GitPullRequestClosedIcon, { className: "fgColor-done" })
			] }),
			/* @__PURE__ */ jsx(Truncate, {
				title: pullRequest.title,
				maxWidth: 350,
				children: pullRequest.title
			}),
			/* @__PURE__ */ jsxs(ActionList.Description, { children: ["#", pullRequest.number] })
		]
	});
}
PullRequestSuggestion.displayName = "PullRequestSuggestion";
function RepositorySuggestion({ repository, isMultistep, stale, className, ...props }) {
	const combinedClassName = clsx(shared_module_default.asyncSuggestion, stale && shared_module_default.stale, className);
	const avatar = repository.ownerAvatarUrl ? /* @__PURE__ */ jsx(GitHubAvatar, {
		src: repository.ownerAvatarUrl,
		alt: "",
		size: 16,
		square: repository.isInOrganization
	}) : /* @__PURE__ */ jsx(RepoIcon, {});
	return isMultistep ? /* @__PURE__ */ jsx(MultistepSuggestion, {
		...props,
		className: combinedClassName,
		leadingVisual: avatar,
		children: repository.nwo
	}, repository.nwo) : /* @__PURE__ */ jsxs(ActionList.Item, {
		...props,
		className: combinedClassName,
		children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: avatar }), repository.nwo]
	}, repository.nwo);
}
RepositorySuggestion.displayName = "RepositorySuggestion";
function isAt(where, query) {
	switch (where) {
		case "start": return query.index === 0;
		case "anywhere": return true;
	}
}
function useCategoriesSuggestions(query) {
	const $ = c(3);
	const { currentReferences } = useChatState();
	let t0;
	bb0: {
		if (!query) {
			t0 = null;
			break bb0;
		}
		let t1;
		if ($[0] !== currentReferences || $[1] !== query) {
			const filterText = query.filter.toLowerCase();
			const filterMatches = (value) => value.toLowerCase().includes(filterText) && value.toLowerCase() !== filterText;
			const currentReferenceSuggestions = currentReferences.map((ref) => {
				const mention = ReferenceMention.for(ref);
				switch (mention?.type) {
					case void 0: return null;
					case "repository": {
						const nwo = `${mention.reference.ownerLogin}/${mention.reference.name}`;
						if (!filterMatches(nwo)) return null;
						return {
							value: ReferenceMention.stringify(mention),
							render: (props_3) => jsx(RepositorySuggestion, {
								repository: {
									databaseId: mention.reference.id,
									isInOrganization: mention.reference.ownerType === "Organization",
									name: mention.reference.name,
									nwo,
									ownerLogin: mention.reference.ownerLogin
								},
								...props_3
							})
						};
					}
					case "issue": {
						const title_1 = mention.reference.title ?? "";
						if (!filterMatches(title_1)) return null;
						return {
							value: ReferenceMention.stringify(mention),
							render: (props_2) => jsx(IssueSuggestion, {
								issue: {
									number: mention.reference.number,
									state: mention.reference.state ?? "",
									title: title_1
								},
								...props_2
							})
						};
					}
					case "pull-request": {
						const title_0 = mention.reference.title ?? "";
						if (!filterMatches(title_0)) return null;
						return {
							value: ReferenceMention.stringify(mention),
							render: (props_1) => jsx(PullRequestSuggestion, {
								pullRequest: {
									number: mention.reference.number,
									state: mention.reference.state ?? "",
									title: title_0
								},
								...props_1
							})
						};
					}
					case "discussion": {
						const title = mention.reference.title ?? "";
						if (!filterMatches(title)) return null;
						return {
							value: ReferenceMention.stringify(mention),
							render: (props_0) => jsx(DiscussionSuggestion, {
								discussion: {
									number: mention.reference.number,
									state: mention.reference.state,
									title
								},
								...props_0
							})
						};
					}
					case "file": {
						const path = mention.reference.path;
						if (!filterMatches(path)) return null;
						return {
							value: ReferenceMention.stringify(mention),
							render: (props) => jsx(FileSuggestion, {
								type: mention.reference.type === "folder" ? "folder" : "file",
								path,
								...props
							})
						};
					}
				}
				return null;
			}).filter(_temp$12);
			const categorySuggestions = getTopLevelCategories().filter((category) => category.name.toLowerCase().includes(filterText) && isAt(category.where, query)).map(_temp2$1);
			if (categorySuggestions.length > 0) {
				const lastReferenceSuggestion = currentReferenceSuggestions.at(-1);
				if (lastReferenceSuggestion && typeof lastReferenceSuggestion === "object") {
					const WithoutDivider = lastReferenceSuggestion.render;
					lastReferenceSuggestion.render = (props_5) => jsxs(Fragment$1, { children: [jsx(WithoutDivider, { ...props_5 }), jsx(ActionList.Divider, {})] });
				}
			}
			t1 = currentReferenceSuggestions.concat(categorySuggestions);
			$[0] = currentReferences;
			$[1] = query;
			$[2] = t1;
		} else t1 = $[2];
		t0 = t1;
	}
	return t0;
}
function _temp2$1(category_0) {
	return {
		value: null,
		key: category_0.value,
		render: (props_4) => jsx(CategorySuggestion, {
			category: category_0,
			...props_4
		})
	};
}
function _temp$12(s) {
	return s !== null;
}
function useCommandsSuggestions(availableCommands, query) {
	const $ = c(5);
	let t0;
	bb0: {
		if (!query) {
			t0 = null;
			break bb0;
		}
		let t1;
		if ($[0] !== availableCommands || $[1] !== query.filter) {
			t1 = query.filter.trim() === "" ? availableCommands : availableCommands.filter((command) => fuzzyScore(command.name, query.filter) > .5 && command.key !== query.filter.toLowerCase());
			$[0] = availableCommands;
			$[1] = query.filter;
			$[2] = t1;
		} else t1 = $[2];
		const filteredCommands = t1;
		let t2;
		if ($[3] !== filteredCommands) {
			t2 = filteredCommands.map(_temp$11);
			$[3] = filteredCommands;
			$[4] = t2;
		} else t2 = $[4];
		t0 = t2;
	}
	return t0;
}
function _temp$11(command_0) {
	return {
		value: `/${command_0.key}`,
		key: command_0.key,
		render: (props) => jsxs(ActionList.Item, {
			...props,
			children: [
				jsx(ActionList.LeadingVisual, { children: jsx(command_0.icon, {}) }),
				command_0.name,
				jsx(ActionList.Description, {
					variant: "block",
					children: command_0.description
				})
			]
		})
	};
}
function useDebouncedFilterQuery(query) {
	const $ = c(3);
	const [debouncedQuery, setDebouncedQuery] = useState(null);
	if (debouncedQuery === null && query !== null || debouncedQuery !== null && query === null) setDebouncedQuery(query);
	let t0;
	let t1;
	if ($[0] !== query) {
		t0 = () => {
			const timeout = setTimeout(() => setDebouncedQuery(query), 200);
			return () => clearTimeout(timeout);
		};
		t1 = [query];
		$[0] = query;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	return debouncedQuery;
}
function useDiscussionsSuggestions(query) {
	const $ = c(18);
	const { service } = useChatManager();
	const debouncedQuery = useDebouncedFilterQuery(query);
	const isDebouncing = query !== debouncedQuery;
	const t0 = debouncedQuery !== null;
	const t1 = debouncedQuery?.repository;
	const t2 = debouncedQuery?.filter;
	let t3;
	if ($[0] !== t1 || $[1] !== t2) {
		t3 = [
			"copilot-autocomplete-discussions",
			t1,
			t2
		];
		$[0] = t1;
		$[1] = t2;
		$[2] = t3;
	} else t3 = $[2];
	let t4;
	if ($[3] !== debouncedQuery || $[4] !== service) {
		t4 = async () => service.fetchAutocompleteDiscussions(debouncedQuery.repository, debouncedQuery.filter);
		$[3] = debouncedQuery;
		$[4] = service;
		$[5] = t4;
	} else t4 = $[5];
	let t5;
	if ($[6] !== t0 || $[7] !== t3 || $[8] !== t4) {
		t5 = {
			enabled: t0,
			queryKey: t3,
			queryFn: t4,
			placeholderData: _temp$10
		};
		$[6] = t0;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
	} else t5 = $[9];
	const discussionsQuery = useQuery(t5);
	let t6;
	bb0: {
		if (!debouncedQuery) {
			t6 = null;
			break bb0;
		}
		if (discussionsQuery.isLoading) {
			t6 = "loading";
			break bb0;
		}
		let t7;
		if ($[10] !== debouncedQuery || $[11] !== discussionsQuery.data || $[12] !== discussionsQuery.isPlaceholderData || $[13] !== isDebouncing) {
			t7 = discussionsQuery.data?.map((discussion) => ({
				value: ReferenceMention.stringify({
					type: "discussion",
					repo: debouncedQuery.repository,
					id: discussion.number.toString()
				}),
				key: discussion.number.toString(),
				render: (props) => jsx(DiscussionSuggestion, {
					...props,
					discussion,
					stale: discussionsQuery.isPlaceholderData || isDebouncing
				})
			})) ?? null;
			$[10] = debouncedQuery;
			$[11] = discussionsQuery.data;
			$[12] = discussionsQuery.isPlaceholderData;
			$[13] = isDebouncing;
			$[14] = t7;
		} else t7 = $[14];
		t6 = t7;
	}
	const suggestions = t6;
	let t7;
	if ($[15] !== discussionsQuery.isPlaceholderData || $[16] !== suggestions) {
		t7 = {
			suggestions,
			stale: discussionsQuery.isPlaceholderData
		};
		$[15] = discussionsQuery.isPlaceholderData;
		$[16] = suggestions;
		$[17] = t7;
	} else t7 = $[17];
	return t7;
}
function _temp$10(prev) {
	return prev;
}
async function workerFilter(data, query, workerPath, abortSignal) {
	return new Promise((resolve, reject) => {
		if (!window.Worker) {
			setTimeout(() => resolve(data.filter((item) => item.includes(query))));
			return;
		}
		const worker = new Worker(workerPath);
		worker.addEventListener("message", (message) => resolve(message.data.list));
		worker.addEventListener("error", (error) => reject(/* @__PURE__ */ new Error(`Worker error: ${error.message}`)));
		abortSignal.addEventListener("abort", () => {
			worker.terminate();
			reject(/* @__PURE__ */ new Error("Worker aborted"));
		});
		worker.postMessage({
			baseList: data,
			query
		});
	});
}
/** Asynchronously filter big data in a Web Worker thread. */
function useFilterQuery(list, query) {
	const $ = c(9);
	const { findFileWorkerPath: workerPath } = useChatState();
	let t0;
	let t1;
	if ($[0] !== list || $[1] !== query || $[2] !== workerPath) {
		t0 = [
			"copilot-worker-filter",
			workerPath,
			list,
			query
		];
		t1 = async (t2) => {
			const { signal } = t2;
			if (!list) return [];
			if (query.length === 0) return list;
			return workerFilter(list, query, workerPath, signal);
		};
		$[0] = list;
		$[1] = query;
		$[2] = workerPath;
		$[3] = t0;
		$[4] = t1;
	} else {
		t0 = $[3];
		t1 = $[4];
	}
	const t2 = list !== null;
	let t3;
	if ($[5] !== t0 || $[6] !== t1 || $[7] !== t2) {
		t3 = {
			queryKey: t0,
			queryFn: t1,
			enabled: t2,
			staleTime: Infinity,
			gcTime: 1e4,
			networkMode: "always",
			retry: false,
			placeholderData: _temp$9
		};
		$[5] = t0;
		$[6] = t1;
		$[7] = t2;
		$[8] = t3;
	} else t3 = $[8];
	return useQuery(t3);
}
function _temp$9(prev) {
	return prev;
}
function useRepositoryFilesQuery(repository, t0) {
	const $ = c(11);
	const includeDirectories = t0 === void 0 ? true : t0;
	const manager = useChatManager();
	const t1 = repository !== null;
	let t2;
	if ($[0] !== includeDirectories || $[1] !== repository) {
		t2 = [
			"copilot-repository-files",
			repository,
			includeDirectories
		];
		$[0] = includeDirectories;
		$[1] = repository;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== includeDirectories || $[4] !== manager || $[5] !== repository) {
		t3 = async () => {
			if (!repository) return {};
			const response = await manager.service.listRepoFiles(repository, includeDirectories);
			if (!response.ok) throw new Error("Failed to fetch files for repository");
			return response.payload;
		};
		$[3] = includeDirectories;
		$[4] = manager;
		$[5] = repository;
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== t1 || $[8] !== t2 || $[9] !== t3) {
		t4 = {
			enabled: t1,
			queryKey: t2,
			queryFn: t3,
			staleTime: 3e5
		};
		$[7] = t1;
		$[8] = t2;
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	return useQuery(t4);
}
function useFilesSuggestions(query) {
	const $ = c(23);
	const manager = useChatManager();
	const t0 = query !== null;
	const t1 = query?.repository;
	let t2;
	if ($[0] !== t1) {
		t2 = ["copilot-repository", t1];
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== manager || $[3] !== query?.repository) {
		t3 = async () => {
			if (!query?.repository) return null;
			const response = await manager.service.fetchRepo(query?.repository);
			if (!response.ok) throw new Error("Failed to fetch repository");
			return response.payload;
		};
		$[2] = manager;
		$[3] = query?.repository;
		$[4] = t3;
	} else t3 = $[4];
	let t4;
	if ($[5] !== t0 || $[6] !== t2 || $[7] !== t3) {
		t4 = {
			enabled: t0,
			queryKey: t2,
			queryFn: t3,
			staleTime: 3e5
		};
		$[5] = t0;
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
	} else t4 = $[8];
	const repoQuery = useQuery(t4);
	const filesAndFoldersQuery = useRepositoryFilesQuery(repoQuery.data ?? null);
	filesAndFoldersQuery.data?.directories;
	let t5;
	if ($[9] !== filesAndFoldersQuery.data?.directories) {
		t5 = filesAndFoldersQuery.data?.directories ?? [];
		$[9] = filesAndFoldersQuery.data?.directories;
		$[10] = t5;
	} else t5 = $[10];
	let t6;
	if ($[11] !== t5) {
		t6 = new Set(t5);
		$[11] = t5;
		$[12] = t6;
	} else t6 = $[12];
	const directoriesSet = t6;
	let t7;
	if ($[13] !== filesAndFoldersQuery.data) {
		t7 = filesAndFoldersQuery.data ? (filesAndFoldersQuery.data.paths ?? []).concat(filesAndFoldersQuery.data.directories ?? []) : null;
		$[13] = filesAndFoldersQuery.data;
		$[14] = t7;
	} else t7 = $[14];
	const filterQuery = useFilterQuery(t7, query?.filter ?? "");
	let t8;
	bb0: {
		if (!query) {
			t8 = null;
			break bb0;
		}
		if (repoQuery.isLoading || filesAndFoldersQuery.isLoading || filterQuery.isLoading) {
			t8 = "loading";
			break bb0;
		}
		let t9;
		if ($[15] !== directoriesSet || $[16] !== filterQuery.data || $[17] !== filterQuery.isPlaceholderData || $[18] !== query) {
			t9 = [...filterQuery.data?.slice(0, 5).map((file) => ({
				value: ReferenceMention.stringify({
					repo: query.repository,
					type: "file",
					id: file
				}),
				key: file,
				render: (props) => jsx(FileSuggestion, {
					...props,
					path: file,
					type: directoriesSet.has(file) ? "folder" : "file",
					stale: filterQuery.isPlaceholderData
				})
			})) ?? []];
			$[15] = directoriesSet;
			$[16] = filterQuery.data;
			$[17] = filterQuery.isPlaceholderData;
			$[18] = query;
			$[19] = t9;
		} else t9 = $[19];
		const result = t9;
		t8 = result.length > 0 ? result : null;
	}
	const suggestions = t8;
	let t9;
	if ($[20] !== repoQuery.isPlaceholderData || $[21] !== suggestions) {
		t9 = {
			suggestions,
			stale: repoQuery.isPlaceholderData
		};
		$[20] = repoQuery.isPlaceholderData;
		$[21] = suggestions;
		$[22] = t9;
	} else t9 = $[22];
	return t9;
}
function useIssuesSuggestions(query) {
	const $ = c(18);
	const { service } = useChatManager();
	const debouncedQuery = useDebouncedFilterQuery(query);
	const isDebouncing = query !== debouncedQuery;
	const t0 = debouncedQuery !== null;
	const t1 = debouncedQuery?.repository;
	const t2 = debouncedQuery?.filter;
	let t3;
	if ($[0] !== t1 || $[1] !== t2) {
		t3 = [
			"copilot-autocomplete-issues",
			t1,
			t2
		];
		$[0] = t1;
		$[1] = t2;
		$[2] = t3;
	} else t3 = $[2];
	let t4;
	if ($[3] !== debouncedQuery || $[4] !== service) {
		t4 = async () => service.fetchAutocompleteIssues(debouncedQuery.repository, debouncedQuery.filter);
		$[3] = debouncedQuery;
		$[4] = service;
		$[5] = t4;
	} else t4 = $[5];
	let t5;
	if ($[6] !== t0 || $[7] !== t3 || $[8] !== t4) {
		t5 = {
			enabled: t0,
			queryKey: t3,
			queryFn: t4,
			placeholderData: _temp$8
		};
		$[6] = t0;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
	} else t5 = $[9];
	const issuesQuery = useQuery(t5);
	let t6;
	bb0: {
		if (!debouncedQuery) {
			t6 = null;
			break bb0;
		}
		if (issuesQuery.isLoading) {
			t6 = "loading";
			break bb0;
		}
		let t7;
		if ($[10] !== debouncedQuery || $[11] !== isDebouncing || $[12] !== issuesQuery.data || $[13] !== issuesQuery.isPlaceholderData) {
			t7 = issuesQuery.data?.map((issue) => ({
				value: ReferenceMention.stringify({
					type: "issue",
					repo: debouncedQuery.repository,
					id: issue.number.toString()
				}),
				key: issue.number.toString(),
				render: (props) => jsx(IssueSuggestion, {
					...props,
					issue,
					stale: issuesQuery.isPlaceholderData || isDebouncing
				})
			})) ?? null;
			$[10] = debouncedQuery;
			$[11] = isDebouncing;
			$[12] = issuesQuery.data;
			$[13] = issuesQuery.isPlaceholderData;
			$[14] = t7;
		} else t7 = $[14];
		t6 = t7;
	}
	const suggestions = t6;
	let t7;
	if ($[15] !== issuesQuery.isPlaceholderData || $[16] !== suggestions) {
		t7 = {
			suggestions,
			stale: issuesQuery.isPlaceholderData
		};
		$[15] = issuesQuery.isPlaceholderData;
		$[16] = suggestions;
		$[17] = t7;
	} else t7 = $[17];
	return t7;
}
function _temp$8(prev) {
	return prev;
}
function usePullRequestsSuggestions(query) {
	const $ = c(18);
	const { service } = useChatManager();
	const debouncedQuery = useDebouncedFilterQuery(query);
	const isDebouncing = query !== debouncedQuery;
	const t0 = debouncedQuery !== null;
	const t1 = debouncedQuery?.repository;
	const t2 = debouncedQuery?.filter;
	let t3;
	if ($[0] !== t1 || $[1] !== t2) {
		t3 = [
			"copilot-autocomplete-pulls",
			t1,
			t2
		];
		$[0] = t1;
		$[1] = t2;
		$[2] = t3;
	} else t3 = $[2];
	let t4;
	if ($[3] !== debouncedQuery || $[4] !== service) {
		t4 = async () => service.fetchAutocompletePullRequests(debouncedQuery.repository, debouncedQuery.filter);
		$[3] = debouncedQuery;
		$[4] = service;
		$[5] = t4;
	} else t4 = $[5];
	let t5;
	if ($[6] !== t0 || $[7] !== t3 || $[8] !== t4) {
		t5 = {
			enabled: t0,
			queryKey: t3,
			queryFn: t4,
			placeholderData: _temp$7
		};
		$[6] = t0;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
	} else t5 = $[9];
	const pullRequestsQuery = useQuery(t5);
	let t6;
	bb0: {
		if (!debouncedQuery) {
			t6 = null;
			break bb0;
		}
		if (pullRequestsQuery.isLoading) {
			t6 = "loading";
			break bb0;
		}
		let t7;
		if ($[10] !== debouncedQuery || $[11] !== isDebouncing || $[12] !== pullRequestsQuery.data || $[13] !== pullRequestsQuery.isPlaceholderData) {
			t7 = pullRequestsQuery.data?.map((pull) => ({
				value: ReferenceMention.stringify({
					type: "pull-request",
					repo: debouncedQuery.repository,
					id: pull.number.toString()
				}),
				key: pull.number.toString(),
				render: (props) => jsx(PullRequestSuggestion, {
					...props,
					pullRequest: pull,
					stale: pullRequestsQuery.isPlaceholderData || isDebouncing
				})
			})) ?? null;
			$[10] = debouncedQuery;
			$[11] = isDebouncing;
			$[12] = pullRequestsQuery.data;
			$[13] = pullRequestsQuery.isPlaceholderData;
			$[14] = t7;
		} else t7 = $[14];
		t6 = t7;
	}
	const suggestions = t6;
	let t7;
	if ($[15] !== pullRequestsQuery.isPlaceholderData || $[16] !== suggestions) {
		t7 = {
			suggestions,
			stale: pullRequestsQuery.isPlaceholderData
		};
		$[15] = pullRequestsQuery.isPlaceholderData;
		$[16] = suggestions;
		$[17] = t7;
	} else t7 = $[17];
	return t7;
}
function _temp$7(prev) {
	return prev;
}
function SSOOrgSuggestion({ org, ...props }) {
	return /* @__PURE__ */ jsx(LinkSuggestion, {
		leadingVisual: /* @__PURE__ */ jsx(GitHubAvatar, {
			square: true,
			src: org.avatarUrl
		}),
		...props,
		children: org.login
	});
}
SSOOrgSuggestion.displayName = "SSOOrgSuggestion";
function SSOPromptSuggestion({ orgs, ...props }) {
	return orgs.length === 1 ? /* @__PURE__ */ jsxs(LinkSuggestion, {
		leadingVisual: /* @__PURE__ */ jsx(ShieldLockIcon, {}),
		...props,
		children: [
			"Single sign-on to ",
			/* @__PURE__ */ jsx("strong", { children: orgs[0]?.login }),
			" for more"
		]
	}) : /* @__PURE__ */ jsx(MultistepSuggestion, {
		leadingVisual: /* @__PURE__ */ jsx(ShieldLockIcon, {}),
		...props,
		children: "Single sign-on for more"
	});
}
SSOPromptSuggestion.displayName = "SSOPromptSuggestion";
var ssoUrl = (org) => `/orgs/${encodeURIComponent(org.login)}/sso?return_to=${encodeURIComponent(location.href)}`;
function useSSOOrgsSuggestions(query) {
	const $ = c(5);
	const { ssoOrganizations } = useChatState();
	let t0;
	bb0: {
		if (!query) {
			t0 = null;
			break bb0;
		}
		let t1;
		if ($[0] !== query || $[1] !== ssoOrganizations) {
			let t2;
			if ($[3] !== query) {
				t2 = (org) => org.login.toLowerCase().includes(query.filter.toLowerCase());
				$[3] = query;
				$[4] = t2;
			} else t2 = $[4];
			t1 = ssoOrganizations.filter(t2).slice(0, 10).map(_temp$6);
			$[0] = query;
			$[1] = ssoOrganizations;
			$[2] = t1;
		} else t1 = $[2];
		t0 = t1;
	}
	return t0;
}
function _temp$6(org_0) {
	return {
		value: null,
		key: `open-link:${ssoUrl(org_0)}`,
		render: (props) => jsx(SSOOrgSuggestion, {
			org: org_0,
			...props
		})
	};
}
/**
* Sorts repos in the set of selected repo IDs to the top of the list.
*/
var sortSelectedToTop = (selectedRepoIds) => (a, b) => {
	if (selectedRepoIds.has(a.databaseId) && !selectedRepoIds.has(b.databaseId)) return -1;
	if (selectedRepoIds.has(b.databaseId) && !selectedRepoIds.has(a.databaseId)) return 1;
	return 0;
};
function useRepositoriesSuggestions(query) {
	const $ = c(17);
	const { currentReferences } = useChatState();
	const debouncedQuery = useDebouncedFilterQuery(query);
	const isDebouncing = query !== debouncedQuery;
	const { repositories, loading } = useRepositoryItems(debouncedQuery?.filter ?? "", debouncedQuery !== null);
	let t0;
	if ($[0] !== currentReferences) {
		t0 = new Set(currentReferences.filter(_temp$5).map(_temp2));
		$[0] = currentReferences;
		$[1] = t0;
	} else t0 = $[1];
	const selectedRepoIds = t0;
	const { ssoOrganizations } = useChatState();
	let t1;
	bb0: {
		if (!debouncedQuery) {
			t1 = null;
			break bb0;
		}
		if (loading === "initial") {
			t1 = "loading";
			break bb0;
		}
		const isMultistep = debouncedQuery.nextCategory !== void 0;
		let results;
		if ($[2] !== isDebouncing || $[3] !== isMultistep || $[4] !== loading || $[5] !== repositories || $[6] !== selectedRepoIds || $[7] !== ssoOrganizations) {
			results = repositories.toSorted(sortSelectedToTop(selectedRepoIds)).slice(0, 5).map((repo) => ({
				value: isMultistep ? null : ReferenceMention.stringify({
					type: "repository",
					repo: repo.nwo
				}),
				key: repo.nwo,
				render: (props) => jsx(RepositorySuggestion, {
					repository: repo,
					isMultistep,
					stale: !!loading || isDebouncing,
					...props
				})
			})) ?? [];
			if (ssoOrganizations.length > 0) {
				let t2;
				if ($[9] !== ssoOrganizations[0] || $[10] !== ssoOrganizations.length) {
					t2 = ssoOrganizations.length === 1 ? `open-link:${ssoUrl(ssoOrganizations[0])}` : "sso-orgs";
					$[9] = ssoOrganizations[0];
					$[10] = ssoOrganizations.length;
					$[11] = t2;
				} else t2 = $[11];
				let t3;
				if ($[12] !== ssoOrganizations) {
					t3 = (props_0) => jsxs(Fragment$1, { children: [jsx(ActionList.Divider, {}), jsx(SSOPromptSuggestion, {
						orgs: ssoOrganizations,
						...props_0
					})] });
					$[12] = ssoOrganizations;
					$[13] = t3;
				} else t3 = $[13];
				results.push({
					value: null,
					key: t2,
					render: t3
				});
			}
			$[2] = isDebouncing;
			$[3] = isMultistep;
			$[4] = loading;
			$[5] = repositories;
			$[6] = selectedRepoIds;
			$[7] = ssoOrganizations;
			$[8] = results;
		} else results = $[8];
		t1 = results;
	}
	const suggestions = t1;
	const t2 = loading === true;
	let t3;
	if ($[14] !== suggestions || $[15] !== t2) {
		t3 = {
			suggestions,
			stale: t2
		};
		$[14] = suggestions;
		$[15] = t2;
		$[16] = t3;
	} else t3 = $[16];
	return t3;
}
function _temp2(r_0) {
	return r_0.id;
}
function _temp$5(r) {
	return r.type === "repository";
}
function useAutocompleteSuggestions(t0) {
	const $ = c(9);
	const { query, availableCommands } = t0;
	const commands = useCommandsSuggestions(availableCommands, query?.category === "commands" ? query : null);
	const categories = useCategoriesSuggestions(query?.category === "categories" ? query : null);
	const agents = useAgentsSuggestions(query?.category === "agents" ? query : null);
	const repositories = useRepositoriesSuggestions(query?.category === "repositories" ? query : null);
	const issues = useIssuesSuggestions(query?.category === "issues" ? query : null);
	const pulls = usePullRequestsSuggestions(query?.category === "pulls" ? query : null);
	const discussions = useDiscussionsSuggestions(query?.category === "discussions" ? query : null);
	const files = useFilesSuggestions(query?.category === "files" ? query : null);
	const ssoOrgs = useSSOOrgsSuggestions(query?.category === "sso-orgs" ? query : null);
	switch (query?.category) {
		case "commands": {
			let t1;
			if ($[0] !== commands) {
				t1 = {
					suggestions: commands,
					stale: false
				};
				$[0] = commands;
				$[1] = t1;
			} else t1 = $[1];
			return t1;
		}
		case void 0: {
			let t1;
			if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
				t1 = {
					suggestions: null,
					stale: false
				};
				$[2] = t1;
			} else t1 = $[2];
			return t1;
		}
		case "categories": {
			let t1;
			if ($[3] !== categories) {
				t1 = {
					suggestions: categories,
					stale: false
				};
				$[3] = categories;
				$[4] = t1;
			} else t1 = $[4];
			return t1;
		}
		case "repositories": return repositories;
		case "issues": return issues;
		case "agents": {
			let t1;
			if ($[5] !== agents) {
				t1 = {
					suggestions: agents,
					stale: false
				};
				$[5] = agents;
				$[6] = t1;
			} else t1 = $[6];
			return t1;
		}
		case "discussions": return discussions;
		case "pulls": return pulls;
		case "files": return files;
		case "sso-orgs": {
			let t1;
			if ($[7] !== ssoOrgs) {
				t1 = {
					suggestions: ssoOrgs,
					stale: false
				};
				$[7] = ssoOrgs;
				$[8] = t1;
			} else t1 = $[8];
			return t1;
		}
	}
}
/** Returns a blank query corresponding to the selected category. */
function selectedCategoryQuery(category) {
	switch (category) {
		case "repositories": return {
			category: "repositories",
			filter: ""
		};
		case "agents": return {
			category: "agents",
			filter: ""
		};
		case "repositories:discussions": return {
			category: "repositories",
			filter: "",
			nextCategory: "discussions"
		};
		case "repositories:issues": return {
			category: "repositories",
			filter: "",
			nextCategory: "issues"
		};
		case "repositories:pulls": return {
			category: "repositories",
			filter: "",
			nextCategory: "pulls"
		};
		case "repositories:files": return {
			category: "repositories",
			filter: "",
			nextCategory: "files"
		};
	}
}
function getTitleForQuery(query) {
	switch (query.category) {
		case "categories":
		case "commands": return null;
		case "repositories": switch (query.nextCategory) {
			case "discussions":
			case "issues":
			case "pulls":
			case "files": return `${categoryNames[query.nextCategory]} ›`;
			default: return "Repositories ›";
		}
		case "agents": return categoryNames[query.category];
		case "discussions":
		case "issues":
		case "pulls":
		case "files": return `${categoryNames[query.category]} › ${query.repository} ›`;
		case "sso-orgs": return "Single sign-on";
	}
}
function ChatInputAutocomplete(t0) {
	const $ = c(21);
	const { children, onSelectCommand, onSelectReference, onShowAgentsDialog, hideAutocomplete, availableCommands, availableModes } = t0;
	const { mode } = useChatState();
	const triggers = [{
		triggerChar: "@",
		insertSpaceOnCommit: true,
		keepTriggerCharOnCommit: false,
		multiWord: true
	}];
	if (copilotFeatureFlags.chatInputCommands) triggers.push({
		triggerChar: "/",
		insertSpaceOnCommit: true,
		keepTriggerCharOnCommit: false,
		multiWord: false
	});
	const [mounted, setMounted] = useState(_temp$4);
	let t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => setMounted(true);
		t2 = [];
		$[0] = t1;
		$[1] = t2;
	} else {
		t1 = $[0];
		t2 = $[1];
	}
	useEffect(t1, t2);
	const [query, setQuery] = useState(null);
	let t3;
	if ($[2] !== availableCommands || $[3] !== query) {
		t3 = {
			query,
			availableCommands
		};
		$[2] = availableCommands;
		$[3] = query;
		$[4] = t3;
	} else t3 = $[4];
	const { suggestions, stale: suggestionsDataStale } = useAutocompleteSuggestions(t3);
	let t4;
	if ($[5] !== onShowAgentsDialog || $[6] !== query) {
		t4 = {
			query,
			onShowAgentsDialog
		};
		$[5] = onShowAgentsDialog;
		$[6] = query;
		$[7] = t4;
	} else t4 = $[7];
	useAutocompleteAgentsDialogs(t4);
	if (!mounted || hideAutocomplete) {
		let t5;
		if ($[8] !== children) {
			t5 = jsx("div", { children });
			$[8] = children;
			$[9] = t5;
		} else t5 = $[9];
		return t5;
	}
	let t5;
	if ($[10] !== mode || $[11] !== onSelectCommand || $[12] !== onSelectReference || $[13] !== query) {
		t5 = (t6) => {
			const { suggestion } = t6;
			const suggestionValue = typeof suggestion === "string" ? suggestion : suggestion.value;
			sendEvent("dotcom_chat.activate", {
				target: "AUTOCOMPLETE_ITEM_SELECTED",
				mode,
				suggestion: suggestionValue
			});
			if (typeof suggestion === "object" && query?.category === "commands") {
				onSelectCommand?.(suggestion.key);
				return;
			}
			const mention = suggestionValue !== null && query?.category !== "agents" ? ReferenceMention.parse(suggestionValue) : void 0;
			if (mention) onSelectReference(mention);
			if (!(typeof suggestion === "object" && suggestion.value === null)) return;
			const openLinkMatch = /^open-link:(.+)$/.exec(suggestion.key);
			if (openLinkMatch) {
				setQuery(null);
				window.open(openLinkMatch[1], "_blank");
				return;
			}
			bb58: switch (query?.category) {
				case "categories":
					if (CategoryValue.is(suggestion.key)) setQuery(selectedCategoryQuery(suggestion.key));
					break bb58;
				case "repositories": if (suggestion.key === "sso-orgs") setQuery({
					category: "sso-orgs",
					filter: ""
				});
				else if (query.nextCategory) setQuery({
					category: query.nextCategory,
					filter: "",
					repository: suggestion.key
				});
			}
		};
		$[10] = mode;
		$[11] = onSelectCommand;
		$[12] = onSelectReference;
		$[13] = query;
		$[14] = t5;
	} else t5 = $[14];
	const onSelectSuggestion = t5;
	let t6;
	if ($[15] !== query) {
		t6 = (event) => {
			const eventTarget = event.target;
			if (event.trigger.triggerChar === "/") {
				if (query === null && eventTarget.selectionStart === 1 && eventTarget.selectionEnd === 1 || query?.category === "commands") setQuery({
					category: "commands",
					filter: event.query
				});
				return;
			}
			setQuery((q) => q ? {
				...q,
				filter: event.query
			} : {
				category: "categories",
				filter: event.query,
				index: (eventTarget.selectionStart ?? 0) - (event.query.length + event.trigger.triggerChar.length)
			});
		};
		$[15] = query;
		$[16] = t6;
	} else t6 = $[16];
	const onShowSuggestions = t6;
	let t7;
	if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = () => setQuery(null);
		$[17] = t7;
	} else t7 = $[17];
	const onHideSuggestions = t7;
	let t8;
	if ($[18] !== availableModes || $[19] !== query?.category) {
		t8 = (t9) => {
			const { suggestion: suggestion_0 } = t9;
			if (typeof suggestion_0 === "object" && query?.category === "commands" && suggestion_0.key !== void 0 && copilotFeatureFlags.askModeDropdown) {
				if (availableModes.some((availableMode) => availableMode.name.toLowerCase() === suggestion_0.key.toLowerCase())) return false;
			}
			return true;
		};
		$[18] = availableModes;
		$[19] = query?.category;
		$[20] = t8;
	} else t8 = $[20];
	return jsxs(Fragment$1, { children: [jsx(InlineAutocomplete, {
		fullWidth: true,
		suggestions,
		triggers,
		tabInsertsSuggestions: false,
		onHideSuggestions,
		onShowSuggestions,
		onSelectSuggestion,
		shouldReplaceText: t8,
		suggestionsPlacement: "below",
		title: query && getTitleForQuery(query) || void 0,
		asMenu: true,
		children
	}), suggestionsDataStale && jsx("span", {
		role: "status",
		"aria-live": "polite",
		className: "sr-only",
		children: "Loading"
	})] });
}
ChatInputAutocomplete.displayName = "ChatInputAutocomplete";
function _temp$4() {
	return typeof document !== "undefined";
}
var ChatInput_module_default = {
	actions: "ChatInput-module_y3XEOW_actions",
	actionsMultiple: "ChatInput-module_y3XEOW_actionsMultiple",
	attachmentButton: "ChatInput-module_y3XEOW_attachmentButton",
	attachmentButtonText: "ChatInput-module_y3XEOW_attachmentButtonText",
	attachmentIconButton: "ChatInput-module_y3XEOW_attachmentIconButton",
	attachments: "ChatInput-module_y3XEOW_attachments",
	chatForm: "ChatInput-module_y3XEOW_chatForm",
	clicked: "ChatInput-module_y3XEOW_clicked",
	CommandIconButton: "ChatInput-module_y3XEOW_CommandIconButton",
	container: "ChatInput-module_y3XEOW_container",
	containerDisabled: "ChatInput-module_y3XEOW_containerDisabled",
	containerSmall: "ChatInput-module_y3XEOW_containerSmall",
	extra: "ChatInput-module_y3XEOW_extra",
	input: "ChatInput-module_y3XEOW_input",
	inputContainer: "ChatInput-module_y3XEOW_inputContainer",
	inputContainerNewConversation: "ChatInput-module_y3XEOW_inputContainerNewConversation",
	inputDisabled: "ChatInput-module_y3XEOW_inputDisabled",
	inputPreview: "ChatInput-module_y3XEOW_inputPreview",
	lighterSegmentedControl: "ChatInput-module_y3XEOW_lighterSegmentedControl",
	mode: "ChatInput-module_y3XEOW_mode",
	modeButton: "ChatInput-module_y3XEOW_modeButton",
	modeSelectButton: "ChatInput-module_y3XEOW_modeSelectButton",
	submitButtonInForm: "ChatInput-module_y3XEOW_submitButtonInForm",
	submitButtonOutsideForm: "ChatInput-module_y3XEOW_submitButtonOutsideForm",
	submitSpinner: "ChatInput-module_y3XEOW_submitSpinner",
	toolbar: "ChatInput-module_y3XEOW_toolbar",
	toolbarButtons: "ChatInput-module_y3XEOW_toolbarButtons",
	toolbarNoModes: "ChatInput-module_y3XEOW_toolbarNoModes"
};
function getAllMentionedReferenceIds(tree) {
	const result = /* @__PURE__ */ new Set();
	visit(tree, (node) => {
		if (node.type === "reference-mention" && node.data.mentionedReferenceId !== void 0) result.add(node.data.mentionedReferenceId);
	});
	return result;
}
function hasPotentialAgentMention(messageText) {
	return agentMentionPattern.test(messageText.split(/\s/)[0] ?? "");
}
var UserMessage_module_default = {
	command: "UserMessage-module_5v_gha_command",
	container: "UserMessage-module_5v_gha_container",
	mention: "UserMessage-module_5v_gha_mention"
};
/**
* This is displayed over the <textarea> for the ChatInput and is used to display rich text e.g. to highlight mentions
* and references.
*/
function ChatInputPreview({ ref, text, availableCommandKeys }) {
	const deferredText = useDeferredValue(text);
	const textToUse = copilotFeatureFlags.chatInputPerformanceOptimizations ? deferredText : text;
	const { availableAgents = [] } = useAvailableAgents(hasPotentialAgentMention(textToUse));
	const { currentReferences } = useChatState();
	const manager = useChatManager();
	const messageTree = unified().use(userMessageParser, {
		references: currentReferences,
		agents: availableAgents,
		commands: availableCommandKeys
	}).parse(textToUse);
	const mentionedReferences = getAllMentionedReferenceIds(messageTree);
	const previouslyMentionedReferences = useRef(mentionedReferences);
	useEffect(function removeReferencesForDeletedMentions() {
		for (const id of previouslyMentionedReferences.current) if (!mentionedReferences.has(id)) {
			const toRemove = currentReferences.find((r) => referenceID(r) === id);
			if (toRemove) manager.removeReference(toRemove);
		}
		previouslyMentionedReferences.current = mentionedReferences;
	});
	return /* @__PURE__ */ jsx("div", {
		id: "copilot-chat-textarea-preview",
		...testIdProps("copilot-chat-input-textarea-preview"),
		"aria-hidden": true,
		className: ChatInput_module_default.inputPreview,
		ref,
		role: "presentation",
		children: messageTree.children.map((node, i) => {
			switch (node.type) {
				case "text": return node.value;
				case "command": return /* @__PURE__ */ jsx("span", {
					className: UserMessage_module_default.command,
					...testIdProps("input-preview-command"),
					children: node.value
				}, i);
				case "reference-mention": return node.data.mentionedReferenceId !== void 0 ? /* @__PURE__ */ jsx("span", {
					className: UserMessage_module_default.mention,
					...testIdProps("input-preview-ref"),
					children: node.value
				}, i) : node.value;
				case "agent-mention": return /* @__PURE__ */ jsx("span", {
					className: UserMessage_module_default.mention,
					children: node.value
				}, i);
			}
		})
	});
}
ChatInputPreview.displayName = "ChatInputPreview";
function useIsScrolledToEnd(scrollContainerRef) {
	const $ = c(2);
	const [scrolledToEnd, setScrolledToEnd] = useState(false);
	let t0;
	if ($[0] !== scrollContainerRef) {
		t0 = () => {
			const root = scrollContainerRef.current;
			const lastChild = root?.lastElementChild;
			if (!lastChild) return;
			const observer = new IntersectionObserver((t1) => {
				const [entry] = t1;
				return setScrolledToEnd(entry?.isIntersecting ?? true);
			}, {
				root,
				threshold: 1
			});
			observer.observe(lastChild);
			return () => observer.disconnect();
		};
		$[0] = scrollContainerRef;
		$[1] = t0;
	} else t0 = $[1];
	useEffect(t0);
	return scrolledToEnd;
}
/**
* Hook for detecting text overflow in reference token elements.
*
* Uses a single ResizeObserver on the container — when tokens are added, removed,
* or the container resizes, the observer fires and we check for overflow.
* Layout reads are deferred to rAF so the ResizeObserver callback stays off the
* critical path.
*/
function useOverflowDetection(selectedReferences, tokenElementsRef, containerRef, textElementSelector) {
	const $ = c(8);
	const [hasOverflowingText, setHasOverflowingText] = useState(false);
	let t0;
	if ($[0] !== textElementSelector || $[1] !== tokenElementsRef) {
		t0 = () => {
			if (!tokenElementsRef.current) {
				setHasOverflowingText(false);
				return;
			}
			const textElements = [];
			for (const token of tokenElementsRef.current) {
				if (!token) continue;
				const el = token.querySelector(textElementSelector);
				if (el) textElements.push(el);
			}
			setHasOverflowingText(textElements.some(_temp$3));
		};
		$[0] = textElementSelector;
		$[1] = tokenElementsRef;
		$[2] = t0;
	} else t0 = $[2];
	const checkForOverflow = useEffectEvent(t0);
	let t1;
	if ($[3] !== checkForOverflow || $[4] !== containerRef) {
		t1 = () => {
			const container = containerRef.current;
			if (!container) return;
			let frameId;
			const scheduleCheck = () => {
				if (frameId !== void 0) cancelAnimationFrame(frameId);
				frameId = requestAnimationFrame(checkForOverflow);
			};
			const resizeObserver = new ResizeObserver(scheduleCheck);
			resizeObserver.observe(container);
			scheduleCheck();
			return () => {
				if (frameId !== void 0) cancelAnimationFrame(frameId);
				resizeObserver.disconnect();
			};
		};
		$[3] = checkForOverflow;
		$[4] = containerRef;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== containerRef) {
		t2 = [containerRef];
		$[6] = containerRef;
		$[7] = t2;
	} else t2 = $[7];
	useEffect(t1, t2);
	if (hasOverflowingText && selectedReferences.length === 0) setHasOverflowingText(false);
	return hasOverflowingText && selectedReferences.length > 0;
}
function _temp$3(el_0) {
	return el_0.scrollWidth > el_0.clientWidth;
}
var TopicIndexStatus = {
	Unindexed: "not_indexed",
	Indexed: "indexed",
	Indexing: "indexing",
	PartiallyIndexed: "partially_indexed",
	Unknown: "unknown"
};
var CanIndexStatus = {
	Requested: "requested",
	NotFound: "not_found",
	Unauthorized: "unauthorized",
	ServiceUnavailable: "service_unavailable",
	QuotaExhausted: "quota_exhausted",
	Forbidden: "forbidden",
	CanIndex: "ok",
	IndexingError: "indexing_error",
	RequestFailed: "request_failed",
	Unknown: "unknown"
};
CanIndexStatus.NotFound, CanIndexStatus.Unauthorized, CanIndexStatus.ServiceUnavailable, CanIndexStatus.QuotaExhausted, CanIndexStatus.Forbidden, CanIndexStatus.RequestFailed;
var UNKNOWN_INDEXING_STATE = {
	requestStatus: CanIndexStatus.Unknown,
	code: TopicIndexStatus.Unknown,
	docs: TopicIndexStatus.Unknown
};
function useRepoIndexingState(nwo) {
	const $ = c(18);
	const client = useQueryClient();
	let t0;
	if ($[0] !== client || $[1] !== nwo) {
		t0 = () => Promise.resolve(client.invalidateQueries({ queryKey: ["repo-indexing-state", nwo] }));
		$[0] = client;
		$[1] = nwo;
		$[2] = t0;
	} else t0 = $[2];
	const invalidateIndexingStatus = t0;
	let t1;
	if ($[3] !== nwo) {
		t1 = {
			queryKey: [
				"copilot-chat",
				"repo-indexing-state",
				nwo
			],
			queryFn: () => fetchIndexingStatus(nwo),
			placeholderData: UNKNOWN_INDEXING_STATE,
			staleTime: Infinity
		};
		$[3] = nwo;
		$[4] = t1;
	} else t1 = $[4];
	const result = useQuery(t1);
	let t2;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = ["repo-indexing-state"];
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== nwo) {
		t3 = () => triggerIndexing([nwo]);
		$[6] = nwo;
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== invalidateIndexingStatus || $[9] !== t3) {
		t4 = {
			mutationKey: t2,
			mutationFn: t3,
			onSuccess: invalidateIndexingStatus
		};
		$[8] = invalidateIndexingStatus;
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	const { mutate: triggerIndexingForRepos } = useMutation(t4);
	const indexingStatus = result.data ?? UNKNOWN_INDEXING_STATE;
	const isIndexingInProgress = indexingStatus.code === TopicIndexStatus.Indexing && indexingStatus.requestStatus !== CanIndexStatus.IndexingError;
	let t5;
	if ($[11] !== invalidateIndexingStatus) {
		t5 = () => void invalidateIndexingStatus();
		$[11] = invalidateIndexingStatus;
		$[12] = t5;
	} else t5 = $[12];
	useInterval(t5, isIndexingInProgress ? 1e4 : 0);
	let t6;
	if ($[13] !== triggerIndexingForRepos) {
		t6 = () => triggerIndexingForRepos();
		$[13] = triggerIndexingForRepos;
		$[14] = t6;
	} else t6 = $[14];
	let t7;
	if ($[15] !== indexingStatus || $[16] !== t6) {
		t7 = [indexingStatus, t6];
		$[15] = indexingStatus;
		$[16] = t6;
		$[17] = t7;
	} else t7 = $[17];
	return t7;
}
function useResizablePanel() {
	const initialPanelHeight = copilotLocalStorage.getPanelHeight();
	const initialPanelWidth = copilotLocalStorage.getPanelWidth();
	const resizeStartYRef = useRef(null);
	const resizeStartHeightRef = useRef(initialPanelHeight);
	const newHeightRef = useRef(initialPanelHeight);
	const resizeStartXRef = useRef(null);
	const resizeStartWidthRef = useRef(initialPanelWidth);
	const newWidthRef = useRef(initialPanelWidth);
	const [panelHeight, setPanelHeight] = useState(initialPanelHeight);
	const [panelWidth, setPanelWidth] = useState(initialPanelWidth);
	const remSizeRef = useRef(0);
	useEffect(() => {
		remSizeRef.current = parseFloat(getComputedStyle(document.documentElement).fontSize);
	}, []);
	const getPanelHeight = (height) => {
		return Math.min(Math.max(height, 256), window.innerHeight - remSizeRef.current);
	};
	const getPanelWidth = (width) => {
		return Math.min(Math.max(width, 400), window.innerWidth - 2 * remSizeRef.current);
	};
	const resize = useCallback((e) => {
		if (resizeStartYRef.current !== null) {
			const dy = resizeStartYRef.current - e.clientY;
			const height_0 = getPanelHeight(resizeStartHeightRef.current + dy);
			setPanelHeight(height_0);
			newHeightRef.current = height_0;
		}
		if (resizeStartXRef.current !== null) {
			const dx = resizeStartXRef.current - e.clientX;
			const width_0 = getPanelWidth(resizeStartWidthRef.current + dx);
			setPanelWidth(width_0);
			newWidthRef.current = width_0;
		}
	}, []);
	const stopResize = useCallback(() => {
		window.removeEventListener("mousemove", resize);
		window.removeEventListener("mouseup", stopResize);
		if (resizeStartYRef.current !== null) {
			copilotLocalStorage.setPanelHeight(newHeightRef.current);
			resizeStartYRef.current = null;
		}
		if (resizeStartXRef.current !== null) {
			copilotLocalStorage.setPanelWidth(newWidthRef.current);
			resizeStartXRef.current = null;
		}
	}, [resize]);
	return {
		panelWidth,
		panelHeight,
		startResize: useCallback((e_0, horizontal, vertical) => {
			if (e_0.button === 0) {
				e_0.preventDefault();
				if (vertical) {
					resizeStartYRef.current = e_0.clientY;
					resizeStartHeightRef.current = panelHeight;
				}
				if (horizontal) {
					resizeStartXRef.current = e_0.clientX;
					resizeStartWidthRef.current = panelWidth;
				}
				window.addEventListener("mousemove", resize);
				window.addEventListener("mouseup", stopResize);
			}
		}, [
			panelHeight,
			panelWidth,
			resize,
			stopResize
		]),
		onResizerKeyDown: useCallback((e_1) => {
			if (e_1.key === "ArrowUp") {
				const newPanelHeight = getPanelHeight(panelHeight + 4);
				setPanelHeight(newPanelHeight);
				copilotLocalStorage.setPanelHeight(newPanelHeight);
				e_1.preventDefault();
			} else if (e_1.key === "ArrowDown") {
				const newPanelHeight_0 = getPanelHeight(panelHeight - 4);
				setPanelHeight(newPanelHeight_0);
				copilotLocalStorage.setPanelHeight(newPanelHeight_0);
				e_1.preventDefault();
			} else if (e_1.key === "ArrowRight") {
				const newPanelWidth = getPanelWidth(panelWidth - 4);
				setPanelWidth(newPanelWidth);
				copilotLocalStorage.setPanelWidth(newPanelWidth);
				e_1.preventDefault();
			} else if (e_1.key === "ArrowLeft") {
				const newPanelWidth_0 = getPanelWidth(panelWidth + 4);
				setPanelWidth(newPanelWidth_0);
				copilotLocalStorage.setPanelWidth(newPanelWidth_0);
				e_1.preventDefault();
			}
		}, [panelHeight, panelWidth])
	};
}
async function fetchIndexingStatus(nwo) {
	const res = await fetch(`/search/check_indexing_status?nwo=${encodeURIComponent(nwo)}`, { headers: {
		Accept: "application/json",
		...getBaseFetchHeaders()
	} });
	if (!res.ok) return {
		requestStatus: CanIndexStatus.RequestFailed,
		code: TopicIndexStatus.Unknown,
		docs: TopicIndexStatus.Unknown
	};
	const data = await res.json();
	return {
		requestStatus: data.can_index,
		code: data.code_status,
		docs: data.docs_status
	};
}
async function triggerIndexing(nwos) {
	return verifiedFetch(`/search/index_embeddings?${nwos.length === 1 ? `nwo=${encodeURIComponent(nwos[0])}` : `nwos=${encodeURIComponent(JSON.stringify(nwos))}`}&index_code=true`, { method: "POST" });
}
function useInterval(callback, delay) {
	const $ = c(5);
	const intervalRef = useRef(void 0);
	const savedCallback = useEffectEvent(callback);
	let t0;
	if ($[0] !== delay || $[1] !== savedCallback) {
		t0 = () => {
			const tick = () => savedCallback();
			if (delay > 0) {
				intervalRef.current = window.setInterval(tick, delay);
				return () => window.clearInterval(intervalRef.current);
			}
		};
		$[0] = delay;
		$[1] = savedCallback;
		$[2] = t0;
	} else t0 = $[2];
	let t1;
	if ($[3] !== delay) {
		t1 = [delay];
		$[3] = delay;
		$[4] = t1;
	} else t1 = $[4];
	useEffect(t0, t1);
	return intervalRef;
}
var ChatInputReferences_module_default = {
	attachmentsList: "ChatInputReferences-module_5SZ2sa_attachmentsList",
	container: "ChatInputReferences-module_5SZ2sa_container",
	convertToFileButton: "ChatInputReferences-module_5SZ2sa_convertToFileButton",
	convertToFileContainer: "ChatInputReferences-module_5SZ2sa_convertToFileContainer",
	divider: "ChatInputReferences-module_5SZ2sa_divider",
	functionLoading: "ChatInputReferences-module_5SZ2sa_functionLoading",
	loading: "ChatInputReferences-module_5SZ2sa_loading",
	menuButton: "ChatInputReferences-module_5SZ2sa_menuButton",
	scrolledToEnd: "ChatInputReferences-module_5SZ2sa_scrolledToEnd"
};
var ReferencePreview_module_default = {
	collapsibleButton: "ReferencePreview-module_3aKm1G_collapsibleButton",
	content: "ReferencePreview-module_3aKm1G_content",
	dismissButton: "ReferencePreview-module_3aKm1G_dismissButton",
	errorContainer: "ReferencePreview-module_3aKm1G_errorContainer",
	errorMessage: "ReferencePreview-module_3aKm1G_errorMessage",
	expanderAbove: "ReferencePreview-module_3aKm1G_expanderAbove",
	expanderBelow: "ReferencePreview-module_3aKm1G_expanderBelow",
	expanderButton: "ReferencePreview-module_3aKm1G_expanderButton",
	expanderContent: "ReferencePreview-module_3aKm1G_expanderContent",
	frame: "ReferencePreview-module_3aKm1G_frame",
	frameContent: "ReferencePreview-module_3aKm1G_frameContent",
	frameInner: "ReferencePreview-module_3aKm1G_frameInner",
	header: "ReferencePreview-module_3aKm1G_header",
	headerContent: "ReferencePreview-module_3aKm1G_headerContent",
	iconMarginRight: "ReferencePreview-module_3aKm1G_iconMarginRight",
	loadingContainer: "ReferencePreview-module_3aKm1G_loadingContainer",
	loadingSpinner: "ReferencePreview-module_3aKm1G_loadingSpinner",
	sectionDivider: "ReferencePreview-module_3aKm1G_sectionDivider"
};
function Frame({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: ReferencePreview_module_default.frame,
		children: /* @__PURE__ */ jsx("div", {
			className: ReferencePreview_module_default.frameInner,
			children: /* @__PURE__ */ jsx("div", {
				className: ReferencePreview_module_default.frameContent,
				children
			})
		})
	});
}
Frame.displayName = "Frame";
function Header({ children, onDismiss }) {
	return /* @__PURE__ */ jsxs("h3", {
		className: ReferencePreview_module_default.header,
		children: [/* @__PURE__ */ jsx("div", {
			className: ReferencePreview_module_default.headerContent,
			children
		}), onDismiss && /* @__PURE__ */ jsx(IconButton, {
			unsafeDisableTooltip: true,
			"aria-label": "Dismiss",
			icon: XIcon,
			onClick: onDismiss,
			variant: "invisible",
			className: ReferencePreview_module_default.dismissButton
		})]
	});
}
Header.displayName = "Header";
function SectionDivider({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: ReferencePreview_module_default.sectionDivider,
		children
	});
}
SectionDivider.displayName = "SectionDivider";
function CollapsibleSubsection(t0) {
	const $ = c(5);
	const { children, title, initiallyOpen } = t0;
	const [open, setOpen] = useState(initiallyOpen ?? false);
	let t1;
	if ($[0] !== children || $[1] !== open || $[2] !== title) {
		let t2;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = () => setOpen(_temp$2);
			$[4] = t2;
		} else t2 = $[4];
		t1 = jsxs(Fragment$1, { children: [jsxs(ButtonComponent, {
			onClick: t2,
			className: ReferencePreview_module_default.collapsibleButton,
			children: [jsx(Octicon, {
				icon: open ? ChevronDownIcon : ChevronRightIcon,
				className: ReferencePreview_module_default.iconMarginRight
			}), title]
		}), open && children] });
		$[0] = children;
		$[1] = open;
		$[2] = title;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
CollapsibleSubsection.displayName = "CollapsibleSubsection";
function _temp$2(wasOpen) {
	return !wasOpen;
}
function Content({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: ReferencePreview_module_default.content,
		children
	});
}
Content.displayName = "Content";
function ContentExpander({ direction, onExpand }) {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		onClick: onExpand,
		className: clsx(ReferencePreview_module_default.expanderButton, direction === "above" ? ReferencePreview_module_default.expanderAbove : ReferencePreview_module_default.expanderBelow),
		children: /* @__PURE__ */ jsxs("div", {
			className: ReferencePreview_module_default.expanderContent,
			children: [
				/* @__PURE__ */ jsx(Octicon, {
					icon: direction === "below" ? FoldDownIcon : FoldUpIcon,
					className: ReferencePreview_module_default.iconMarginRight
				}),
				"Show content ",
				direction
			]
		})
	});
}
ContentExpander.displayName = "ContentExpander";
function Details({ children }) {
	return /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
		as: "h3",
		children: "Reference details"
	}), children] }) });
}
Details.displayName = "Details";
function DetailLink({ children, href, icon }) {
	return /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		href,
		children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon }) }), children]
	});
}
DetailLink.displayName = "DetailLink";
function Loading() {
	return /* @__PURE__ */ jsxs("div", {
		className: ReferencePreview_module_default.loadingContainer,
		children: [/* @__PURE__ */ jsx(Spinner, { className: ReferencePreview_module_default.loadingSpinner }), /* @__PURE__ */ jsx("div", { children: "Loading..." })]
	});
}
Loading.displayName = "Loading";
function Error$1() {
	return /* @__PURE__ */ jsx("div", {
		className: ReferencePreview_module_default.errorContainer,
		children: /* @__PURE__ */ jsx("div", {
			className: ReferencePreview_module_default.errorMessage,
			children: "Failed to load reference details"
		})
	});
}
Error$1.displayName = "Error";
function Body({ children, detailsError, detailsLoading }) {
	return detailsError ? /* @__PURE__ */ jsx(Error$1, {}) : detailsLoading ? /* @__PURE__ */ jsx(Loading, {}) : /* @__PURE__ */ jsx(Fragment$1, { children });
}
Body.displayName = "Body";
var ReferencePreview = {
	Frame,
	Header,
	Body,
	Content,
	CollapsibleSubsection,
	ContentExpander,
	Details,
	DetailLink,
	SectionDivider
};
var headerContent = "WebSearchReferencePreview-module_y211Ta_headerContent";
var privacyNote = "WebSearchReferencePreview-module_y211Ta_privacyNote";
var resultCard = "WebSearchReferencePreview-module_y211Ta_resultCard";
var resultCount = "WebSearchReferencePreview-module_y211Ta_resultCount";
var resultLink = "WebSearchReferencePreview-module_y211Ta_resultLink";
var resultsList = "WebSearchReferencePreview-module_y211Ta_resultsList";
var resultUrl = "WebSearchReferencePreview-module_y211Ta_resultUrl";
var searchSummary = "WebSearchReferencePreview-module_y211Ta_searchSummary";
var WebSearchReferencePreview_module_default = {
	"bing-icon": "WebSearchReferencePreview-module_y211Ta_bing-icon",
	headerContent,
	privacyNote,
	resultCard,
	resultCount,
	resultLink,
	resultsList,
	resultUrl,
	searchSummary
};
function WebSearchReferencePreview({ reference, onDismiss }) {
	return /* @__PURE__ */ jsxs(ReferencePreview.Frame, { children: [/* @__PURE__ */ jsx(ReferencePreview.Header, {
		onDismiss,
		children: /* @__PURE__ */ jsxs("div", {
			className: WebSearchReferencePreview_module_default.headerContent,
			children: [/* @__PURE__ */ jsx(BingIcon, {}), /* @__PURE__ */ jsxs("span", {
				className: WebSearchReferencePreview_module_default.searchSummary,
				children: [/* @__PURE__ */ jsxs("span", {
					className: WebSearchReferencePreview_module_default.resultCount,
					children: [
						reference.results.length,
						" ",
						reference.results.length === 1 ? " result " : " results "
					]
				}), "from Bing search."]
			})]
		})
	}), /* @__PURE__ */ jsx(ReferencePreview.Body, {
		detailsError: false,
		detailsLoading: false,
		children: /* @__PURE__ */ jsxs("div", {
			className: WebSearchReferencePreview_module_default.resultsList,
			children: [reference.results.map((result, index) => /* @__PURE__ */ jsxs("div", {
				className: WebSearchReferencePreview_module_default.resultCard,
				children: [
					/* @__PURE__ */ jsx(Link, {
						className: WebSearchReferencePreview_module_default.resultLink,
						href: result.url,
						rel: "nofollow",
						children: result.title
					}),
					/* @__PURE__ */ jsx("div", { children: result.excerpt }),
					/* @__PURE__ */ jsx("div", {
						className: WebSearchReferencePreview_module_default.resultUrl,
						children: result.url
					})
				]
			}, index)), /* @__PURE__ */ jsx("span", {
				className: WebSearchReferencePreview_module_default.privacyNote,
				children: /* @__PURE__ */ jsx(Link, {
					href: "https://privacy.microsoft.com/en-us/privacystatement",
					rel: "nofollow",
					target: "_blank",
					children: "Microsoft Privacy Statement"
				})
			})]
		})
	})] });
}
WebSearchReferencePreview.displayName = "WebSearchReferencePreview";
var BingIcon = () => /* @__PURE__ */ jsx("div", { className: WebSearchReferencePreview_module_default["bing-icon"] });
BingIcon.displayName = "BingIcon";
function FigmaIcon({ className, ...rest }) {
	return /* @__PURE__ */ jsxs("svg", {
		"aria-label": "Figma logo",
		width: "16",
		height: "16",
		viewBox: "0 0 16 16",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		className,
		...rest,
		children: [/* @__PURE__ */ jsxs("g", {
			clipPath: "url(#clip0_216_3161)",
			children: [
				/* @__PURE__ */ jsx("path", {
					d: "M7.99837 7.99967C7.99837 6.52683 9.1922 5.33301 10.665 5.33301C12.1379 5.33301 13.3317 6.52683 13.3317 7.99967C13.3317 9.47252 12.1379 10.6663 10.665 10.6663C9.1922 10.6663 7.99837 9.47252 7.99837 7.99967Z",
					fill: "#1ABCFE"
				}),
				/* @__PURE__ */ jsx("path", {
					d: "M2.66504 13.3337C2.66504 11.8608 3.85886 10.667 5.33171 10.667H7.99837V13.3337C7.99837 14.8065 6.80455 16.0003 5.33171 16.0003C3.85886 16.0003 2.66504 14.8065 2.66504 13.3337Z",
					fill: "#0ACF83"
				}),
				/* @__PURE__ */ jsx("path", {
					d: "M7.99837 0V5.33333H10.665C12.1379 5.33333 13.3317 4.13951 13.3317 2.66667C13.3317 1.19382 12.1379 0 10.665 0H7.99837Z",
					fill: "#FF7262"
				}),
				/* @__PURE__ */ jsx("path", {
					d: "M2.665 2.66667C2.665 4.13951 3.85883 5.33333 5.33167 5.33333H7.99833V0H5.33167C3.85883 0 2.665 1.19382 2.665 2.66667Z",
					fill: "#F24E1E"
				}),
				/* @__PURE__ */ jsx("path", {
					d: "M2.66504 7.99967C2.66504 9.47252 3.85886 10.6663 5.33171 10.6663H7.99837V5.33301H5.33171C3.85886 5.33301 2.66504 6.52683 2.66504 7.99967Z",
					fill: "#A259FF"
				})
			]
		}), /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("clipPath", {
			id: "clip0_216_3161",
			children: /* @__PURE__ */ jsx("rect", {
				width: "10.6667",
				height: "16",
				fill: "white",
				transform: "translate(2.665)"
			})
		}) })]
	});
}
FigmaIcon.displayName = "FigmaIcon";
var ReferenceToken_module_default = {
	closedIcon: "ReferenceToken-module_3-DVzW_closedIcon",
	description: "ReferenceToken-module_3-DVzW_description",
	figmaIcon: "ReferenceToken-module_3-DVzW_figmaIcon",
	figmaIconOuter: "ReferenceToken-module_3-DVzW_figmaIconOuter",
	fullWidth: "ReferenceToken-module_3-DVzW_fullWidth",
	icon: "ReferenceToken-module_3-DVzW_icon",
	implicitReference: "ReferenceToken-module_3-DVzW_implicitReference",
	jobIconOuter: "ReferenceToken-module_3-DVzW_jobIconOuter",
	loadingName: "ReferenceToken-module_3-DVzW_loadingName",
	loopsIcon: "ReferenceToken-module_3-DVzW_loopsIcon",
	loopsIconOuter: "ReferenceToken-module_3-DVzW_loopsIconOuter",
	name: "ReferenceToken-module_3-DVzW_name",
	nodeIconOuter: "ReferenceToken-module_3-DVzW_nodeIconOuter",
	openIcon: "ReferenceToken-module_3-DVzW_openIcon",
	pullRequestClosedIcon: "ReferenceToken-module_3-DVzW_pullRequestClosedIcon",
	pullRequestMergedIcon: "ReferenceToken-module_3-DVzW_pullRequestMergedIcon",
	referenceToken: "ReferenceToken-module_3-DVzW_referenceToken",
	removeButton: "ReferenceToken-module_3-DVzW_removeButton",
	small: "ReferenceToken-module_3-DVzW_small",
	trailingVisual: "ReferenceToken-module_3-DVzW_trailingVisual"
};
var VersionName_module_default = { version: "VersionName-module_xiaA6G_version" };
function VersionName({ "data-testid": testid, version }) {
	return /* @__PURE__ */ jsxs(BranchName_default, {
		className: VersionName_module_default.version,
		as: "span",
		"data-testid": testid,
		children: ["v", version]
	});
}
VersionName.displayName = "VersionName";
function ReferenceToken({ ref, reference, message, onClick, onRemove, size, fullWidth, getReferenceVersion, isImplicitReference }) {
	const manager = useChatManager();
	const isImmersive = useChatStateLens((s) => s.mode === "immersive");
	const threadID = useChatStateValue("selectedThreadID");
	const descriptionId = useId();
	if (!renderableReferenceTypes().has(reference.type)) return null;
	const onKeyDown = (event) => {
		if (!onRemove) return;
		if (event.key === "Delete" || event.key === "Backspace") {
			event.preventDefault();
			onRemove();
		}
	};
	const clickHandler = (event_0) => {
		if (onClick) {
			onClick(reference, event_0);
			if (event_0.defaultPrevented) return;
		}
		if (isImmersive) return;
		if (reference.type === "issue" || reference.type === "pull-request" || reference.type === "discussion") {
			window.open(reference.url, "_blank");
			self.focus();
		}
		if (["file", "thread-scoped-file"].includes(reference.type)) {
			let immersivePath = threadID ? `/copilot/c/${threadID}` : "/copilot";
			immersivePath += `?reference_id=${referenceID(reference)}`;
			if (message) immersivePath += `&message_index=${message.messageIndex}`;
			window.open(immersivePath, "_blank");
			return;
		}
		if ([
			"repository",
			"folder",
			"third-party",
			"image",
			"issue",
			"pull-request",
			"loop-node",
			"github-url",
			"job"
		].includes(reference.type)) return;
		event_0.preventDefault();
		manager.selectReference(reference);
	};
	const Icon = iconForReference(reference);
	const version = getReferenceVersion?.(reference);
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("a", {
		href: referenceURL(reference),
		className: clsx(ReferenceToken_module_default.referenceToken, size === "small" && ReferenceToken_module_default.small, fullWidth && ReferenceToken_module_default.fullWidth, isImplicitReference && ReferenceToken_module_default.implicitReference),
		onKeyDown,
		onClick: clickHandler,
		ref,
		"aria-describedby": onRemove && descriptionId,
		children: [
			Icon && /* @__PURE__ */ jsx(Icon, {
				size: "small",
				className: clsx(ReferenceToken_module_default.icon, Icon === IssueOpenedIcon && ReferenceToken_module_default.openIcon, Icon === GitPullRequestIcon && ReferenceToken_module_default.openIcon, Icon === IssueClosedIcon && ReferenceToken_module_default.closedIcon, Icon === GitPullRequestClosedIcon && ReferenceToken_module_default.pullRequestClosedIcon, Icon === GitMergeIcon && ReferenceToken_module_default.pullRequestMergedIcon),
				"data-testid": reference.type === "loading" ? "reference-token-loading" : void 0
			}),
			reference.type === "loading" ? /* @__PURE__ */ jsx("span", {
				className: ReferenceToken_module_default.loadingName,
				children: /* @__PURE__ */ jsx(SkeletonText, { "aria-hidden": "true" })
			}) : /* @__PURE__ */ jsx("span", {
				className: ReferenceToken_module_default.name,
				children: referenceName(reference)
			}),
			reference.type === "thread-scoped-snippet" && reference.range && /* @__PURE__ */ jsx("span", {
				className: ReferenceToken_module_default.description,
				children: reference.range.start === reference.range.end ? `L${reference.range.start}` : `L${reference.range.start}-L${reference.range.end}`
			}),
			version !== void 0 && /* @__PURE__ */ jsx("span", {
				className: ReferenceToken_module_default.trailingVisual,
				children: /* @__PURE__ */ jsx(VersionName, { version })
			}),
			onRemove && /* @__PURE__ */ jsx(RemoveReferenceTokenButton, {
				size,
				onRemove,
				descriptionId
			})
		]
	}) });
}
ReferenceToken.displayName = "ReferenceToken";
function iconForIssueReference(reference) {
	if (reference.type !== "issue") return;
	switch (reference.state) {
		case "open": return IssueOpenedIcon;
		case "closed": return IssueClosedIcon;
		case "not_planned": return SkipIcon;
		default: return IssueOpenedIcon;
	}
}
function iconForPullRequestReference(reference) {
	if (reference.type !== "pull-request") return;
	if (reference.draft && reference.state === "open") return GitPullRequestDraftIcon;
	switch (reference.state) {
		case "open": return GitPullRequestIcon;
		case "closed": return GitPullRequestClosedIcon;
		case "merged": return GitMergeIcon;
		default: return GitPullRequestIcon;
	}
}
function iconForWebSearchReference(reference) {
	if (reference.type !== "web-search-result") return;
	switch (reference.reference_type) {
		case "bing_search": return BingIcon;
		default: return GlobeIcon;
	}
}
function iconForReference(reference) {
	switch (reference.type) {
		case "figma": return StylizedFigmaIcon;
		case "file": return FileIcon;
		case "folder": return FileDirectoryFillIcon;
		case "file-diff": return FileDiffIcon;
		case "snippet": return CodeIcon;
		case "repository": return RepoIcon;
		case "symbol": return CodeSquareIcon;
		case "commit": return GitCommitIcon;
		case "pull-request": return iconForPullRequestReference(reference);
		case "repo-instructions":
		case "org-instructions": return NoteIcon;
		case "issue": return iconForIssueReference(reference);
		case "draft-issue":
		case "draft-update-issue": return IssueDraftIcon;
		case "discussion": return CommentDiscussionIcon;
		case "web-search-result": return iconForWebSearchReference(reference);
		case "thread-scoped-file": return "language" in reference && docLanguages.has(reference.language) ? MarkdownIcon : CodeIcon;
		case "thread-scoped-snippet": return "language" in reference && docLanguages.has(reference.language) ? MarkdownIcon : CodeIcon;
		case "loop-node": return StylizedNodeIcon;
		case "loop-execution": return LoopReferenceIcon;
		case "loading": return Spinner;
		case "copilot-space": return SpaceIcon;
		case "github-url": return LinkIcon;
		case "job": return () => StylizedJobIcon(reference);
		default: return;
	}
}
function LoopReferenceIcon() {
	return /* @__PURE__ */ jsx("div", {
		className: ReferenceToken_module_default.loopsIconOuter,
		children: /* @__PURE__ */ jsx(LoopsIcon, { className: ReferenceToken_module_default.loopsIcon })
	});
}
LoopReferenceIcon.displayName = "LoopReferenceIcon";
function StylizedJobIcon(reference) {
	if (reference.jobFailed) return /* @__PURE__ */ jsx("span", {
		className: ReferenceToken_module_default.jobIconOuter,
		style: { color: "var(--bgColor-danger-emphasis, var(--color-scale-red-4))" },
		children: /* @__PURE__ */ jsx(XCircleFillIcon, {})
	});
	else return /* @__PURE__ */ jsx("span", {
		className: ReferenceToken_module_default.jobIconOuter,
		children: /* @__PURE__ */ jsx(PlayIcon, {})
	});
}
StylizedJobIcon.displayName = "StylizedJobIcon";
function StylizedFigmaIcon() {
	return /* @__PURE__ */ jsx("div", {
		className: ReferenceToken_module_default.figmaIconOuter,
		children: /* @__PURE__ */ jsx(FigmaIcon, { className: ReferenceToken_module_default.figmaIcon })
	});
}
StylizedFigmaIcon.displayName = "StylizedFigmaIcon";
function StylizedNodeIcon() {
	return /* @__PURE__ */ jsx("div", {
		className: ReferenceToken_module_default.nodeIconOuter,
		children: /* @__PURE__ */ jsx(NodeIcon, { size: 16 })
	});
}
StylizedNodeIcon.displayName = "StylizedNodeIcon";
var RemoveReferenceTokenButton = ({ size, onRemove, descriptionId, onMouseOver, onMouseLeave }) => {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
		tabIndex: -1,
		"aria-hidden": true,
		size,
		icon: XIcon,
		"aria-label": "Remove",
		onClick: (e) => {
			e.stopPropagation();
			e.preventDefault();
			onRemove();
		},
		tooltipDirection: "n",
		variant: "invisible",
		className: ReferenceToken_module_default.removeButton,
		onMouseOver,
		onMouseLeave
	}), /* @__PURE__ */ jsx("span", {
		hidden: true,
		id: descriptionId,
		children: "press backspace or delete to remove"
	})] });
};
RemoveReferenceTokenButton.displayName = "RemoveReferenceTokenButton";
var ChatInputReferences = memo(({ className, isLoading, returnFocusRef, tokenSize = "medium", onSelectReference, onPromoteImplicitReference, getReferenceVersion, showConvertToFileText, onConvertToFile, onConvertToFileDismiss, hideAttachmentsMenu, onRemoveReference, referenceTypeFilter }) => {
	const { currentReferences, implicitReferences, selectedThreadID } = useChatStateValues("currentReferences", "implicitReferences", "selectedThreadID");
	const manager = useChatManager();
	const scrollContainerRef = useRef(null);
	const scrolledToEnd = useIsScrolledToEnd(scrollContainerRef);
	const [showFullAttachmentNames, setShowFullAttachmentNames] = useState(false);
	const selectedReferences = useMemo(() => {
		let renderableRefs = getRenderableReferences(currentReferences);
		if (copilotFeatureFlags.copilotChatRepositoryPicker && !selectedThreadID) renderableRefs = renderableRefs.filter((ref) => ref.type !== "repository");
		if (referenceTypeFilter) renderableRefs = renderableRefs.filter((ref_0) => referenceTypeFilter.includes(ref_0.type));
		return renderableRefs;
	}, [
		currentReferences,
		selectedThreadID,
		referenceTypeFilter
	]);
	const { setSelectedCopilotSpaceId } = useCopilotSpaceSelection();
	const containerRef = useRef(null);
	useFocusZone({
		containerRef,
		focusableElementFilter: (el) => !el.hasAttribute("aria-hidden"),
		bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd,
		focusInStrategy: "previous",
		focusOutBehavior: "stop"
	}, [selectedReferences]);
	const tokensRef = useRef([]);
	const onRemove = (reference, index) => {
		(tokensRef.current[index + 1] ?? tokensRef.current[index - 1] ?? returnFocusRef.current)?.focus();
		onRemoveReference?.(reference);
		if (isCopilotSpaceReference(reference)) setSelectedCopilotSpaceId(void 0);
		manager.removeReference(reference);
	};
	const onRemoveAll = () => {
		setTimeout(() => returnFocusRef.current?.focus());
		if (selectedReferences.filter(isCopilotSpaceReference).length > 0) setSelectedCopilotSpaceId(void 0);
		manager.clearCurrentReferences();
	};
	const prevSelectedReferences = useRef(selectedReferences);
	useLayoutEffect(() => {
		if (prevSelectedReferences.current.length < selectedReferences.length) {
			const newReference = selectedReferences.find((reference_0) => !prevSelectedReferences.current.find((prevRef) => referencesAreEqual(prevRef, reference_0)));
			const lastIndex = newReference ? selectedReferences.indexOf(newReference) : -1;
			tokensRef?.current?.[lastIndex]?.scrollIntoView({
				behavior: "smooth",
				block: "nearest",
				inline: "end"
			});
		}
		prevSelectedReferences.current = selectedReferences;
	}, [selectedReferences]);
	const handleSelectReference = useCallback((reference_1, event) => {
		if (implicitReferences.has(reference_1)) {
			manager.promoteImplicitReference(reference_1);
			onPromoteImplicitReference?.(reference_1);
			event?.preventDefault();
			return;
		}
		onSelectReference?.(reference_1, event);
	}, [
		implicitReferences,
		manager,
		onSelectReference,
		onPromoteImplicitReference
	]);
	const handleConvertToDismiss = useCallback(() => {
		onConvertToFileDismiss?.();
	}, [onConvertToFileDismiss]);
	const handleToggleFullAttachmentNames = useCallback(() => {
		setShowFullAttachmentNames((prev) => !prev);
	}, []);
	const hasOverflowingText = useOverflowDetection(selectedReferences, tokensRef, containerRef, `.${ReferenceToken_module_default.name}`);
	const descriptionId = useId();
	const onKeyDown = (event_0) => {
		if (event_0.key === "Delete" || event_0.key === "Backspace") {
			event_0.preventDefault();
			event_0.stopPropagation();
			if (showConvertToFileText) handleConvertToDismiss();
		}
	};
	if (selectedReferences.length === 0 && !isLoading && !showConvertToFileText) return null;
	return /* @__PURE__ */ jsxs("div", {
		role: "toolbar",
		"aria-label": "Attachments",
		className: clsx(className, ChatInputReferences_module_default.container),
		ref: containerRef,
		children: [/* @__PURE__ */ jsxs("div", {
			className: clsx(ChatInputReferences_module_default.attachmentsList, scrolledToEnd && ChatInputReferences_module_default.scrolledToEnd, isLoading && ChatInputReferences_module_default.loading),
			ref: scrollContainerRef,
			children: [
				showConvertToFileText && /* @__PURE__ */ jsxs("div", {
					className: ChatInputReferences_module_default.convertToFileContainer,
					children: [/* @__PURE__ */ jsx(ButtonComponent, {
						onClick: onConvertToFile,
						leadingVisual: FileIcon,
						className: ChatInputReferences_module_default.convertToFileButton,
						"aria-describedby": descriptionId,
						onKeyDown,
						children: "Convert to file"
					}), /* @__PURE__ */ jsx(RemoveReferenceTokenButton, {
						size: tokenSize,
						onRemove: handleConvertToDismiss,
						descriptionId
					})]
				}),
				selectedReferences.map((reference_2, index_0) => {
					const customRef = reference_2;
					if (customRef.TokenComponent) {
						const TokenComp = customRef.TokenComponent;
						return /* @__PURE__ */ jsx(TokenComp, {
							reference: reference_2,
							onRemove: () => onRemove(reference_2, index_0),
							size: tokenSize,
							fullWidth: showFullAttachmentNames,
							tokenRef: (el_0) => {
								tokensRef.current[index_0] = el_0;
							}
						}, referenceID(reference_2));
					}
					return reference_2.type === "repository" ? /* @__PURE__ */ jsx(RepoReferenceToken, {
						reference: reference_2,
						ref: (el_1) => {
							tokensRef.current[index_0] = el_1;
						},
						"data-index": index_0,
						size: tokenSize,
						fullWidth: showFullAttachmentNames,
						onRemove: () => onRemove(reference_2, index_0),
						onClick: handleSelectReference,
						getReferenceVersion
					}, referenceID(reference_2)) : /* @__PURE__ */ jsx(ReferenceToken, {
						reference: reference_2,
						ref: (el_2) => {
							tokensRef.current[index_0] = el_2;
						},
						"data-index": index_0,
						size: tokenSize,
						fullWidth: showFullAttachmentNames,
						onRemove: () => onRemove(reference_2, index_0),
						onClick: handleSelectReference,
						getReferenceVersion,
						isImplicitReference: implicitReferences.has(reference_2)
					}, referenceID(reference_2));
				}),
				isLoading && /* @__PURE__ */ jsxs("div", {
					className: ChatInputReferences_module_default.functionLoading,
					...testIdProps("loading-indicator"),
					children: [/* @__PURE__ */ jsx(Spinner, { size: "small" }), "Retrieving…"]
				})
			]
		}), selectedReferences.length > 0 && !hideAttachmentsMenu && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", { className: ChatInputReferences_module_default.divider }), /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			icon: KebabHorizontalIcon,
			"aria-label": "Attachments options",
			variant: "invisible",
			tooltipDirection: "n",
			className: ChatInputReferences_module_default.menuButton,
			size: tokenSize
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			width: "small",
			children: /* @__PURE__ */ jsxs(ActionList, { children: [hasOverflowingText && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: handleToggleFullAttachmentNames,
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: showFullAttachmentNames ? /* @__PURE__ */ jsx(EyeClosedIcon, {}) : /* @__PURE__ */ jsx(EyeIcon, {}) }), showFullAttachmentNames ? "Hide full attachment names" : "Show full attachment names"]
			}), /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: onRemoveAll,
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(TrashIcon, {}) }), "Remove attachments"]
			})] })
		})] })] })]
	});
});
ChatInputReferences.displayName = "ChatInputReferences";
ChatInputReferences.displayName = "ChatInputReferences";
/**
* It's just a ReferenceToken but it automatically kicks off repo indexing when mounted (if needed).
*/
function RepoReferenceToken({ ref, ...props }) {
	const repo = props.reference;
	const indexingAllowed = useChatStateLens((s) => s.model && !s.model.hasLimitedCapabilities);
	const [indexingState, triggerIndexing] = useRepoIndexingState(`${repo.ownerLogin}/${repo.name}`);
	const autoTriggeredIndexing = useRef(false);
	const isNotIndexed = indexingState.code === TopicIndexStatus.Unindexed || indexingState.docs === TopicIndexStatus.Unindexed;
	useEffect(function startIndexing() {
		if (!autoTriggeredIndexing.current && isNotIndexed && indexingAllowed) {
			autoTriggeredIndexing.current = true;
			triggerIndexing();
		}
	}, [
		indexingAllowed,
		isNotIndexed,
		triggerIndexing
	]);
	return /* @__PURE__ */ jsx(ReferenceToken, {
		...props,
		ref
	});
}
RepoReferenceToken.displayName = "RepoReferenceToken";
var REPO_RESULTS_LIMIT = 10;
/**
* ChatReposPicker - Repository selection component for Copilot Chat
*/
function ChatReposPicker({ showIconOnly = false, tooltipDirection }) {
	const manager = useChatManager();
	const preferredOverlaySide = useOverlayDirection();
	const topReposCacheRef = useRef(void 0);
	const { currentReferences, currentRepository, mode } = useChatStateValues("currentReferences", "currentRepository", "mode");
	const [pinnedReposSnapshot, setPinnedReposSnapshot] = useState([]);
	const [recentlyUncheckedRepos, setRecentlyUncheckedRepos] = useState([]);
	const previousQueryRef = useRef("");
	const [selectedReposAtQueryChange, setSelectedReposAtQueryChange] = useState([]);
	const selectedRepoReferences = currentReferences.filter((r) => r.type === "repository");
	const selectedRepos = useMemo(() => {
		const repos = [];
		for (const ref of selectedRepoReferences) repos.push({
			id: ref.id,
			name: `${ref.ownerLogin}/${ref.name}`,
			enabled: true,
			private: ref.visibility !== "public"
		});
		return repos;
	}, [selectedRepoReferences]);
	const setPreviouslySelectedRepos = useCallback((query) => {
		const previousQuery = previousQueryRef.current;
		previousQueryRef.current = query;
		if (query.trim() && !previousQuery.trim()) {
			setRecentlyUncheckedRepos([]);
			setSelectedReposAtQueryChange(selectedRepos);
		}
		if (query.trim() && previousQuery.trim() && query.trim() !== previousQuery.trim()) setSelectedReposAtQueryChange(selectedRepos);
		if (!query.trim() && previousQuery.trim()) {
			setPinnedReposSnapshot(uniqueBy([...selectedRepos, ...recentlyUncheckedRepos], (r_0) => r_0.id));
			setRecentlyUncheckedRepos([]);
		}
	}, [recentlyUncheckedRepos, selectedRepos]);
	const repositoryLoader = useCallback(async (query_0) => {
		setPreviouslySelectedRepos(query_0);
		if (!topReposCacheRef.current) topReposCacheRef.current = mapTopicItemsToDropdown(await manager.service.fetchTopRepositories(REPO_RESULTS_LIMIT, true, currentRepository?.id), currentRepository);
		let results;
		if (!query_0.trim()) {
			const pinnedRepos = uniqueBy([...pinnedReposSnapshot, ...recentlyUncheckedRepos], (r_1) => r_1.id);
			results = prependPinnedRepos(topReposCacheRef.current ?? [], pinnedRepos);
		} else results = mapTopicItemsToDropdown(await manager.service.fetchRepositoriesSearch(query_0.trim(), REPO_RESULTS_LIMIT, true, currentRepository?.id), currentRepository);
		if (query_0.trim()) {
			const lowerQuery = query_0.toLowerCase();
			const matchingSelectedRepos = selectedReposAtQueryChange.filter((r_2) => r_2.name.toLowerCase().includes(lowerQuery));
			if (matchingSelectedRepos.length > 0) results = prependMatchingSelectedRepos(results, matchingSelectedRepos);
		}
		return results.slice(0, REPO_RESULTS_LIMIT);
	}, [
		setPreviouslySelectedRepos,
		manager.service,
		currentRepository,
		pinnedReposSnapshot,
		recentlyUncheckedRepos,
		selectedReposAtQueryChange
	]);
	const handleRepoSelect = useCallback(async (repos_1) => {
		if (!repos_1) {
			const uncheckedRepos = [];
			for (const ref_0 of selectedRepoReferences) {
				uncheckedRepos.push({
					id: ref_0.id,
					name: `${ref_0.ownerLogin}/${ref_0.name}`,
					enabled: true,
					private: ref_0.visibility !== "public"
				});
				manager.removeReference(ref_0);
				sendEvent("dotcom_chat.activate", {
					target: "ATTACHMENT_MENU_REPOSITORIES",
					action: "removed",
					component: "REPOSITORY_PICKER",
					mode
				});
			}
			setRecentlyUncheckedRepos((prev) => uniqueBy([...prev, ...uncheckedRepos], (r_3) => r_3.id));
			return;
		}
		const newSelectedIds = new Set(repos_1.map((r_4) => r_4.id));
		const newlyUnchecked = [];
		for (const ref_1 of selectedRepoReferences) if (!newSelectedIds.has(ref_1.id)) {
			newlyUnchecked.push({
				id: ref_1.id,
				name: `${ref_1.ownerLogin}/${ref_1.name}`,
				enabled: true,
				private: ref_1.visibility !== "public"
			});
			manager.removeReference(ref_1);
			sendEvent("dotcom_chat.activate", {
				target: "ATTACHMENT_MENU_REPOSITORIES",
				action: "removed",
				component: "REPOSITORY_PICKER",
				mode
			});
		}
		if (newlyUnchecked.length > 0) setRecentlyUncheckedRepos((prev_0) => uniqueBy([...prev_0, ...newlyUnchecked], (r_5) => r_5.id));
		const reSelectedIds = repos_1.filter((r_6) => !selectedRepoReferences.some((ref_2) => ref_2.id === r_6.id)).map((r_7) => r_7.id);
		if (reSelectedIds.length > 0) setRecentlyUncheckedRepos((prev_1) => prev_1.filter((r_8) => !reSelectedIds.includes(r_8.id)));
		for (const repo of repos_1) if (!selectedRepoReferences.some((ref_3) => ref_3.id === repo.id) && repo.id != null) {
			const repoResponse = await manager.service.fetchRepo(repo.id);
			if (repoResponse.ok) {
				const reference = makeRepositoryReference(repoResponse.payload);
				manager.addReference(reference, "repoMenu");
				sendEvent("dotcom_chat.activate", {
					target: "ATTACHMENT_MENU_REPOSITORIES",
					action: "selected",
					component: "REPOSITORY_PICKER",
					mode
				});
			}
		}
	}, [
		selectedRepoReferences,
		manager,
		mode
	]);
	const buttonText = useMemo(() => {
		const count = selectedRepos.length;
		if (count === 0) return "All repositories";
		if (count === 1) return selectedRepos[0]?.name || "Select repositories";
		return `${count} repositories`;
	}, [selectedRepos]);
	const buttonIcon = useMemo(() => {
		const count_0 = selectedRepos.length;
		if (count_0 === 0) return RepoIcon;
		if (count_0 === 1) return selectedRepos?.[0]?.private ? RepoLockedIcon : RepoIcon;
		return RepoCloneIcon;
	}, [selectedRepos]);
	const handleOpen = useCallback(() => {
		previousQueryRef.current = "";
		setPinnedReposSnapshot(selectedRepos);
		setSelectedReposAtQueryChange(selectedRepos);
		setRecentlyUncheckedRepos([]);
		sendEvent("dotcom_chat.activate", {
			target: "ATTACHMENT_MENU_REPOSITORIES",
			action: "open",
			component: "REPOSITORY_PICKER",
			mode
		});
	}, [selectedRepos, mode]);
	const handleClose = useCallback(() => {
		setRecentlyUncheckedRepos([]);
		setPinnedReposSnapshot(selectedRepos);
	}, [selectedRepos]);
	return /* @__PURE__ */ jsx(ReposSelector, {
		repositoryLoader,
		fullscreenOnNarrow: true,
		selectionVariant: "multiple",
		selectAllOption: false,
		onSelect: handleRepoSelect,
		currentSelection: selectedRepos,
		width: "large",
		disableItemTruncation: true,
		responsiveStyle: "icon-on-mobile",
		iconOnly: showIconOnly,
		liveSelection: true,
		buttonText,
		anchorSide: preferredOverlaySide,
		tooltipDirection,
		portalContainerName: mode === "assistive" ? COPILOT_CHAT_MENU_PORTAL_ROOT : void 0,
		overlayPosition: mode === "assistive" ? "relative" : void 0,
		additionalButtonProps: {
			leadingVisual: buttonIcon,
			"aria-label": "Select repositories to attach to conversation"
		},
		onOpen: handleOpen,
		onClose: handleClose
	});
}
/**
* Prepends pinned repositories (selected + recently unchecked) to the top of the list.
* Pinned repos appear first (preserving their order), followed by remaining non-pinned repos.
*/
ChatReposPicker.displayName = "ChatReposPicker";
function prependPinnedRepos(repos, pinnedRepos) {
	if (pinnedRepos.length === 0) return repos;
	const repoIds = new Set(repos.map((r) => r.id));
	const pinnedIds = new Set(pinnedRepos.map((r) => r.id));
	const pinnedNotInList = pinnedRepos.filter((r) => !repoIds.has(r.id));
	const pinnedInList = repos.filter((r) => pinnedIds.has(r.id));
	const notPinned = repos.filter((r) => !pinnedIds.has(r.id));
	const totalPinned = pinnedNotInList.length + pinnedInList.length;
	const remainingSlots = Math.max(0, REPO_RESULTS_LIMIT - totalPinned);
	return [
		...pinnedNotInList,
		...pinnedInList,
		...notPinned.slice(0, remainingSlots)
	];
}
/**
* Prepends selected repos that match the search query to the top of search results.
* This ensures selected items remain visible and at the top when filtering.
*/
function prependMatchingSelectedRepos(repos, matchingSelectedRepos) {
	if (matchingSelectedRepos.length === 0) return repos;
	const selectedIds = new Set(matchingSelectedRepos.map((r) => r.id));
	const reposWithoutSelected = repos.filter((r) => !selectedIds.has(r.id));
	return [...matchingSelectedRepos, ...reposWithoutSelected];
}
/**
* Maps TopicItem (from REST API) to ChatDropdownRepository format.
* Optionally prepends the current repository if provided and not already in the list.
*/
function mapTopicItemsToDropdown(repos, currentRepository) {
	const mapped = repos.filter((repo) => repo.databaseId != null).map((repo) => ({
		id: repo.databaseId,
		name: repo.nwo,
		enabled: true,
		private: void 0
	}));
	if (currentRepository) {
		const currentNwo = `${currentRepository.ownerLogin}/${currentRepository.name}`;
		if (!mapped.some((r) => r.name === currentNwo)) mapped.unshift({
			id: currentRepository.id,
			name: currentNwo,
			enabled: true,
			private: void 0
		});
	}
	return mapped;
}
function useDragDrop(t0) {
	const $ = c(6);
	const { onFilesDrop, targetElement } = t0;
	const [isDragging, setIsDragging] = useState(false);
	const dragCounterRef = useRef(0);
	let t1;
	let t2;
	if ($[0] !== onFilesDrop || $[1] !== targetElement) {
		t1 = () => {
			if (!targetElement) return;
			const handleDragOver = _temp$1;
			const handleDragEnter = (event_0) => {
				if (!isDragEvent(event_0)) return;
				event_0.preventDefault();
				event_0.stopPropagation();
				if (event_0.dataTransfer?.types.includes("Files")) {
					dragCounterRef.current = dragCounterRef.current + 1;
					if (dragCounterRef.current === 1) setIsDragging(true);
				}
			};
			const handleDragLeave = (event_1) => {
				event_1.preventDefault();
				event_1.stopPropagation();
				dragCounterRef.current = dragCounterRef.current - 1;
				if (dragCounterRef.current <= 0) {
					dragCounterRef.current = 0;
					setIsDragging(false);
				}
			};
			const handleDrop = (event_2) => {
				if (!isDragEvent(event_2)) return;
				event_2.preventDefault();
				event_2.stopPropagation();
				dragCounterRef.current = 0;
				setIsDragging(false);
				const files = event_2.dataTransfer?.files;
				if (!files || files.length === 0) return;
				onFilesDrop(files);
			};
			targetElement.addEventListener("dragover", handleDragOver);
			targetElement.addEventListener("dragenter", handleDragEnter);
			targetElement.addEventListener("dragleave", handleDragLeave);
			targetElement.addEventListener("drop", handleDrop);
			return () => {
				targetElement.removeEventListener("dragover", handleDragOver);
				targetElement.removeEventListener("dragenter", handleDragEnter);
				targetElement.removeEventListener("dragleave", handleDragLeave);
				targetElement.removeEventListener("drop", handleDrop);
			};
		};
		t2 = [onFilesDrop, targetElement];
		$[0] = onFilesDrop;
		$[1] = targetElement;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] !== isDragging) {
		t3 = { isDragging };
		$[4] = isDragging;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
function _temp$1(event) {
	event.preventDefault();
	event.stopPropagation();
}
function isDragEvent(event) {
	return event instanceof DragEvent;
}
var DragAndDropSVG = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "226",
	height: "103",
	fill: "none",
	viewBox: "0 0 226 103",
	...props,
	children: [
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-default)",
			fillRule: "evenodd",
			d: "M56.66 10.322v.002l16.824 7.846L92.44 70.254a8.75 8.75 0 0 1-5.23 11.217l-37.009 13.47a8.75 8.75 0 0 1-11.217-5.23L18.531 33.512a8.75 8.75 0 0 1 5.23-11.217z",
			clipRule: "evenodd"
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-open-muted)",
			fillRule: "evenodd",
			d: "M56.66 10.322v.002l16.824 7.846L92.44 70.254a8.75 8.75 0 0 1-5.23 11.217l-37.009 13.47a8.75 8.75 0 0 1-11.217-5.23L18.531 33.512a8.75 8.75 0 0 1 5.23-11.217z",
			clipRule: "evenodd"
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-open-emphasis)",
			fillRule: "evenodd",
			d: "m55.29 10.822.802-.293a1.46 1.46 0 0 1 1.116.049l15.73 7.335c.35.163.62.459.753.822l.294.804 18.458 50.715a8.75 8.75 0 0 1-5.23 11.217l-37.008 13.47a8.75 8.75 0 0 1-11.218-5.23L18.533 33.512a8.75 8.75 0 0 1 5.231-11.217zm.997 2.74L24.762 25.038a5.835 5.835 0 0 0-3.487 7.478l20.454 56.198a5.835 5.835 0 0 0 7.478 3.487l37.008-13.47a5.835 5.835 0 0 0 3.487-7.478L71.243 20.537l-5.482 1.996a5.82 5.82 0 0 1-4.461-.195 5.82 5.82 0 0 1-3.017-3.293z",
			clipRule: "evenodd",
			opacity: "0.12"
		}),
		/* @__PURE__ */ jsx("g", {
			clipPath: "url(#clip0_12526_110155)",
			children: /* @__PURE__ */ jsx("path", {
				fill: "var(--bgColor-open-emphasis)",
				fillRule: "evenodd",
				d: "M64.035 44.691c-.703 2.448-1.974 5.334-3.06 7.703-.93 2.029-1.94 3.575-2.932 4.66a5.46 5.46 0 0 1 .165 4.949c-.376.806-1.116 1.478-1.841 2.006-.754.549-1.631 1.04-2.446 1.445a31 31 0 0 1-3.066 1.318l-.053.02-.015.004-.004.002h-.002a1.095 1.095 0 0 1-1.388-.647v-.002l-.002-.004-.006-.015-.02-.053-.07-.196a30.973 30.973 0 0 1-.89-2.999c-.214-.885-.402-1.872-.466-2.803-.062-.895-.022-1.894.354-2.7a5.46 5.46 0 0 1 3.883-3.052c.178-1.474.697-3.268 1.635-5.314 1.092-2.383 2.494-5.198 3.94-7.294.718-1.039 1.498-1.978 2.313-2.587.804-.603 1.896-1.056 3.022-.53 1.134.53 1.46 1.673 1.497 2.667.037 1.011-.2 2.208-.548 3.422m-9.653 9.647a5.5 5.5 0 0 1 2.228 1.035c.515-.598 1.067-1.388 1.623-2.394l-3.1-1.445c-.397 1.08-.635 2.02-.751 2.804m7.55-10.25c-.61 2.121-1.702 4.662-2.733 6.928l-3.212-1.498c1.049-2.259 2.309-4.736 3.565-6.556.672-.973 1.292-1.682 1.823-2.08.541-.404.74-.318.783-.297h.003c.026.012.21.096.235.764.024.663-.136 1.594-.464 2.739m-8.986 19.408c-.682.34-1.342.627-1.862.84a29 29 0 0 1-.553-1.966c-.198-.823-.357-1.68-.41-2.441-.054-.796.02-1.336.155-1.625a3.282 3.282 0 1 1 5.949 2.774c-.135.29-.5.693-1.146 1.162-.617.45-1.375.878-2.133 1.256",
				clipRule: "evenodd"
			})
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-default)",
			fillRule: "evenodd",
			d: "M198.941 19.499 166.042 7.525a8.75 8.75 0 0 0-11.217 5.23L134.37 68.953a8.75 8.75 0 0 0 5.231 11.217l37.008 13.47a8.75 8.75 0 0 0 11.217-5.231l18.959-52.089z",
			clipRule: "evenodd"
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-sponsors-muted)",
			fillRule: "evenodd",
			d: "M198.941 19.499 166.042 7.525a8.75 8.75 0 0 0-11.217 5.23L134.37 68.953a8.75 8.75 0 0 0 5.231 11.217l37.008 13.47a8.75 8.75 0 0 0 11.217-5.231l18.959-52.089z",
			clipRule: "evenodd"
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-sponsors-emphasis)",
			fillRule: "evenodd",
			d: "m197.568 19.003.803.292c.363.132.659.404.823.754l7.335 15.73c.163.35.181.751.049 1.114l-.293.805-18.458 50.715a8.75 8.75 0 0 1-11.217 5.23l-37.008-13.47a8.75 8.75 0 0 1-5.231-11.217l20.454-56.197a8.75 8.75 0 0 1 11.217-5.23zm-.998 2.741L165.045 10.27a5.836 5.836 0 0 0-7.479 3.487l-20.454 56.197a5.834 5.834 0 0 0 3.487 7.478l37.008 13.47a5.836 5.836 0 0 0 7.479-3.487L203.544 36.7l-5.483-1.995a5.82 5.82 0 0 1-3.292-3.017 5.82 5.82 0 0 1-.195-4.461z",
			clipRule: "evenodd",
			opacity: "0.12"
		}),
		/* @__PURE__ */ jsx("g", {
			clipPath: "url(#clip1_12526_110155)",
			children: /* @__PURE__ */ jsx("path", {
				fill: "var(--bgColor-sponsors-emphasis)",
				fillRule: "evenodd",
				d: "M179.168 44.01a2.553 2.553 0 0 1 3.393 1.235l.946 2.03a2.55 2.55 0 0 1-1.235 3.392l-16.096 7.506a2.55 2.55 0 0 1-1.259.232l-4.919-.348a1.094 1.094 0 0 1-.808-1.734l2.894-3.992c.255-.351.595-.632.988-.815zm1.41 2.16a.365.365 0 0 0-.485-.177l-2.36 1.1 1.254 2.692 2.361-1.101a.365.365 0 0 0 .176-.485zm-3.574 4.54-1.254-2.692-11.753 5.48a.36.36 0 0 0-.141.117l-1.739 2.399 2.955.209a.36.36 0 0 0 .18-.033z",
				clipRule: "evenodd"
			})
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-default)",
			fillRule: "evenodd",
			d: "M128.059 0H93.052A8.75 8.75 0 0 0 84.3 8.752v59.804a8.75 8.75 0 0 0 8.752 8.751h39.383a8.75 8.75 0 0 0 8.751-8.751v-55.43z",
			clipRule: "evenodd"
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-accent-muted)",
			fillRule: "evenodd",
			d: "M128.059 0H93.052A8.75 8.75 0 0 0 84.3 8.752v59.804a8.75 8.75 0 0 0 8.752 8.751h39.383a8.75 8.75 0 0 0 8.751-8.751v-55.43z",
			clipRule: "evenodd"
		}),
		/* @__PURE__ */ jsx("path", {
			fill: "var(--bgColor-accent-emphasis)",
			fillRule: "evenodd",
			d: "M126.6 0h.855c.386 0 .757.154 1.031.427L140.758 12.7c.274.273.427.644.428 1.03v54.826a8.75 8.75 0 0 1-8.751 8.751H93.052a8.75 8.75 0 0 1-8.752-8.751V8.752A8.75 8.75 0 0 1 93.052 0zm0 2.917H93.052a5.835 5.835 0 0 0-5.835 5.835v59.804a5.835 5.835 0 0 0 5.835 5.834h39.383a5.834 5.834 0 0 0 5.834-5.834v-53.97h-5.834a5.82 5.82 0 0 1-4.126-1.709 5.82 5.82 0 0 1-1.709-4.125z",
			clipRule: "evenodd",
			opacity: "0.12"
		}),
		/* @__PURE__ */ jsx("g", {
			clipPath: "url(#clip2_12526_110155)",
			children: /* @__PURE__ */ jsx("path", {
				fill: "var(--bgColor-accent-emphasis)",
				fillRule: "evenodd",
				d: "M104.354 31.356a.364.364 0 0 0-.364.365v15.315c0 .202.163.365.364.365h1.373l.042-.045 8.864-8.864c.962-.962 2.509-1 3.518-.088l4.801 4.344V31.72a.365.365 0 0 0-.365-.365zM122.587 47.4h-13.768l7.361-7.362a.365.365 0 0 1 .503-.013l6.269 5.672v1.338a.365.365 0 0 1-.365.365m2.553-.365V31.721a2.553 2.553 0 0 0-2.553-2.553h-18.233a2.553 2.553 0 0 0-2.552 2.553v15.315a2.553 2.553 0 0 0 2.552 2.553h18.233a2.553 2.553 0 0 0 2.553-2.553m-15.316-10.575a.729.729 0 1 1-1.458 0 .729.729 0 0 1 1.458 0m2.188 0a2.917 2.917 0 1 1-5.834 0 2.917 2.917 0 0 1 5.834 0",
				clipRule: "evenodd"
			})
		}),
		/* @__PURE__ */ jsxs("defs", { children: [
			/* @__PURE__ */ jsx("clipPath", {
				id: "clip0_12526_110155",
				children: /* @__PURE__ */ jsx("path", {
					fill: "var(--bgColor-default)",
					d: "m41.466 45.344 21.93-7.982 7.982 21.93-21.93 7.982z"
				})
			}),
			/* @__PURE__ */ jsx("clipPath", {
				id: "clip1_12526_110155",
				children: /* @__PURE__ */ jsx("path", {
					fill: "var(--bgColor-default)",
					d: "m164.786 36.563 21.93 7.982-7.982 21.93-21.93-7.982z"
				})
			}),
			/* @__PURE__ */ jsx("clipPath", {
				id: "clip2_12526_110155",
				children: /* @__PURE__ */ jsx("path", {
					fill: "var(--bgColor-default)",
					d: "M101.802 27.71h23.338V51.05h-23.338z"
				})
			})
		] })
	]
});
DragAndDropSVG.displayName = "DragAndDropSVG";
var FullScreenDragOverlay_module_default = {
	centeredContent: "FullScreenDragOverlay-module_ix9YPq_centeredContent",
	overlay: "FullScreenDragOverlay-module_ix9YPq_overlay",
	text: "FullScreenDragOverlay-module_ix9YPq_text"
};
/**
* A generic fullscreen drag-and-drop overlay component that provides visual feedback
* during file drag operations and handles file upload workflows.
*
* This component displays a fullscreen overlay when files are being dragged over the page,
* showing appropriate UI states for drag feedback and upload progress.
*
* @param onFilesDrop - Callback fired when files are dropped.
* @param isUploading - Whether files are currently being uploaded (shows upload progress UI).
*
* @example
* ```tsx
* <FullScreenDragOverlay
*   onFilesDrop={handleUpload}
*   isUploading={isUploading}
* />
* ```
*/
function FullScreenDragOverlay(t0) {
	const $ = c(9);
	const { onFilesDrop, isUploading: t1 } = t0;
	const isUploading = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== isUploading || $[1] !== onFilesDrop) {
		t2 = (files) => {
			if (isUploading) return;
			onFilesDrop(files);
		};
		$[0] = isUploading;
		$[1] = onFilesDrop;
		$[2] = t2;
	} else t2 = $[2];
	const handleFilesDrop = t2;
	let t3;
	if ($[3] !== handleFilesDrop) {
		t3 = {
			onFilesDrop: handleFilesDrop,
			targetElement: ssrSafeDocument
		};
		$[3] = handleFilesDrop;
		$[4] = t3;
	} else t3 = $[4];
	const { isDragging } = useDragDrop(t3);
	let t4;
	let t5;
	if ($[5] !== isDragging || $[6] !== isUploading) {
		t5 = Symbol.for("react.early_return_sentinel");
		bb0: {
			let content = null;
			if (isUploading) content = jsxs(Fragment$1, { children: [jsx(Spinner, { size: "large" }), jsx("p", {
				className: FullScreenDragOverlay_module_default.text,
				children: "Uploading files..."
			})] });
			else if (isDragging) content = jsxs(Fragment$1, { children: [jsx(DragAndDropSVG, {}), jsx("p", {
				className: FullScreenDragOverlay_module_default.text,
				children: "Drop files to upload"
			})] });
			if (!content) {
				t5 = null;
				break bb0;
			}
			t4 = jsx("div", {
				className: FullScreenDragOverlay_module_default.overlay,
				children: jsx("div", {
					className: FullScreenDragOverlay_module_default.centeredContent,
					children: content
				})
			});
		}
		$[5] = isDragging;
		$[6] = isUploading;
		$[7] = t4;
		$[8] = t5;
	} else {
		t4 = $[7];
		t5 = $[8];
	}
	if (t5 !== Symbol.for("react.early_return_sentinel")) return t5;
	return t4;
}
FullScreenDragOverlay.displayName = "FullScreenDragOverlay";
/** When the user pastes text that is longer than this many characters, we will automatically convert it to a file. */
var PASTE_TEXT_AS_FILE_THRESHOLD = 1e3;
var LIMITED_KEYBINDING_COMMAND_IDS = [
	"github:cancel",
	"copilot-chat:send-message",
	"copilot-chat:edit-last-message"
];
var START_TASK_BUTTON_TEXT = "Start task";
var ChatInput = (props) => {
	const state = useChatStateValues("defaultRecipient", "isWaitingOnAttachment", "attachmentProcessingType", "isWaitingOnCopilot", "messages", "mode", "model", "selectedThreadID", "showDecoupledPRModeBanner", "skillOptions", "slashCommandLoading");
	const { model } = state;
	const getChatState = useGetChatState();
	const manager = useChatManager();
	const maxMessagesReached = manager.maxMessagesReached();
	const [pastedFile, setPastedFile] = useState(null);
	const slashCommandLoading = state.slashCommandLoading.state === "loading";
	const { safeSetTimeout } = useSafeTimeout();
	const { onSelectReference, containerRef, shouldClearTextOnCommandSubmit = true, shouldClearTextOnSubmit = true, slashCommandsEnabled = false, shouldSubmitWithModifier = false, extraToolbar } = props;
	const pastedFileNamePromise = useRef(null);
	const pastedFileName = useRef("");
	const convertToFileShownLogged = useRef(false);
	const navigate = useNavigate$1();
	const { availableCommands, availableCommandKeys } = useAvailableCommands({ enabled: slashCommandsEnabled });
	const commandModes = availableCommands.map((cmd) => cmd.mode).filter((mode) => mode !== void 0);
	const chatModes = copilotFeatureFlags.askModeDropdown && commandModes.length > 0 ? commandModes : props.modes;
	const [activeMode, setActiveMode] = useState(() => {
		if (props.activeModeName) {
			const activeModeFromProps = chatModes.find((m) => m.name === props.activeModeName);
			if (activeModeFromProps) return activeModeFromProps;
		}
		const savedModeName = copilotLocalStorage.getActiveMode();
		if (savedModeName) {
			const savedMode = chatModes.find((m_0) => m_0.name === savedModeName);
			if (savedMode) return savedMode;
		}
		return chatModes[0];
	});
	const onModeSelect = useCallback((mode_0, autoComplete) => {
		props.onClickMode?.(mode_0.name);
		if (!props.activeModeName) setActiveMode(mode_0);
		copilotLocalStorage.setActiveMode(mode_0.name);
		sendEvent("dotcom_chat.activate", {
			target: "MODE_SWITCH",
			mode: mode_0.name,
			autoComplete
		});
	}, [props]);
	const { activeCopilotSpaceId } = useSpaceSelection();
	const currentMode = copilotFeatureFlags.askModeDropdown ? activeMode : chatModes.find((m_1) => m_1.name === props.activeModeName) || chatModes[0];
	const onClickMode = useCallback((modeName) => {
		if (copilotFeatureFlags.askModeDropdown) {
			const mode_1 = chatModes.find((m_2) => m_2?.name === modeName);
			if (mode_1) onModeSelect(mode_1);
		}
	}, [chatModes, onModeSelect]);
	const addedInitialReference = useRef(void 0);
	useEffect(() => {
		if (!props.initialReference) return;
		if (referencesAreEqual(addedInitialReference.current, props.initialReference)) return;
		manager.addReference(props.initialReference, "page-file-reference");
		addedInitialReference.current = props.initialReference;
	}, [props.initialReference, manager]);
	useEffect(() => {
		if (props.activeModeName) {
			const modeFromProps = chatModes.find((m_3) => m_3.name === props.activeModeName);
			if (modeFromProps && modeFromProps !== activeMode) setActiveMode(modeFromProps);
		}
	}, [
		props.activeModeName,
		chatModes,
		activeMode
	]);
	useEffect(() => {
		const updatedMode = chatModes.find((m_4) => m_4.name === activeMode.name);
		if (updatedMode && updatedMode !== activeMode) setActiveMode(updatedMode);
	}, [chatModes, activeMode]);
	const clearPastedFile = useCallback((logDismiss = false) => {
		pastedFileNamePromise.current = null;
		pastedFileName.current = "";
		convertToFileShownLogged.current = false;
		if (pastedFile) {
			setPastedFile(null);
			if (logDismiss) sendEvent("dotcom_chat.activate", {
				target: "CONVERT_TO_FILE_DISMISS",
				mode: state.mode
			});
		}
	}, [pastedFile, state.mode]);
	const { typingHasStarted, textAreaRef, textareaPreviewRef, textAreaPreviewContainerRef, text, setText, isAgentTaskSubmitInProgress, handleSubmit, handleSubmitToNewThread, handleScroll, handleChange, handleStop, handleFocus, command, setLastUsedRepo, selectedRepo, setSelectedRepo, selectedBranch, setSelectedBranch, selectedAgent, setSelectedAgent, initialRepoNWO } = useChatInput({
		isLoading: state.isWaitingOnCopilot || state.isWaitingOnAttachment || slashCommandLoading,
		onSubmit: props.onSubmit,
		textAreaRef: props.textAreaRef,
		clearPastedFile,
		onChatCommandChange: props.onChatCommandChange,
		isInPortal: props.isInPortal,
		shouldClearTextOnCommandSubmit,
		shouldClearTextOnSubmit,
		availableCommands,
		activeModeName: currentMode?.name,
		storageKeySuffix: props.storageKeySuffix,
		initialText: props.initialText,
		maxTextareaHeight: props.maxTextareaHeight,
		source: props.source
	});
	useEffect(() => {
		if (text.startsWith("/agent ") && copilotFeatureFlags.askModeDropdown) {
			const agentCommand = availableCommands.find((cmd_0) => cmd_0.key === "agent");
			if (agentCommand?.mode && agentCommand.mode !== activeMode) {
				onModeSelect(agentCommand.mode, true);
				setText(text.slice(7));
			}
		}
	}, [
		text,
		availableCommands,
		activeMode,
		setText,
		onModeSelect
	]);
	const { onTextChange } = props;
	useEffect(() => {
		onTextChange?.(text);
	}, [text, onTextChange]);
	const customModelPicker = useMemo(() => availableCommands.find((cmd_1) => cmd_1.key === command || cmd_1.mode?.name === activeMode.name), [
		availableCommands,
		command,
		activeMode
	])?.customModelPicker ?? props.customModelPicker;
	const disabled = props.disabled || isAgentTaskSubmitInProgress || maxMessagesReached;
	useImperativeHandle(props.chatInputRef, () => ({ setText }), [setText]);
	const emitChange = useSyntheticChange({
		inputRef: textAreaRef,
		fallbackEventHandler: handleChange
	});
	const { replaceUrlWithReferenceMention } = useAddUrlReferences({
		figmaAuthUrl: props.figmaAuthUrl,
		textAreaRef,
		emitChange
	});
	const { isLoading: mentionReferencesPending, addReferenceForMention, addReferencesForMentions } = useAddMentionReferences();
	const isCopilotSpacePath = useIsCopilotSpacePath();
	const isCopilotSpacePage = activeCopilotSpaceId && isCopilotSpacePath;
	const preferredOverlaySide = useOverlayDirection();
	const isIncompleteCommand = useMemo(() => isIncompleteSlashCommand(text, command), [text, command]);
	const isAgent = isAgentCommand(activeMode?.name, command);
	const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
	const submitDisabled = slashCommandLoading || mentionReferencesPending || state.isWaitingOnAttachment || !!props.submitDisabled || isAgent && commandModes.includes(currentMode) && !selectedRepo && !selectedBranch || isAgentTaskSubmitInProgress || isIncompleteCommand;
	const textAreaEmpty = text.length === 0;
	const stopResponse = useCallback(() => {
		sendEvent("dotcom_chat.activate", {
			target: "CHAT_MESSAGE_STOP",
			mode: state.mode
		});
		handleStop();
	}, [handleStop, state.mode]);
	const sendMessage = useCallback(() => {
		if (submitDisabled) return;
		const spaceIdString = activeCopilotSpaceId ? `${activeCopilotSpaceId.owner}/${activeCopilotSpaceId.id}` : "";
		sendEvent("dotcom_chat.activate", {
			target: "CHAT_MESSAGE_SUBMIT",
			mode: state.mode,
			selectedThreadId: state.selectedThreadID,
			copilotSpace: spaceIdString,
			fromSpaceUI: isCopilotSpacePath,
			askModeDropdown: copilotFeatureFlags.askModeDropdown,
			activeMode: currentMode.name
		});
		if (pastedFile) clearPastedFile(false);
		handleSubmit();
	}, [
		submitDisabled,
		activeCopilotSpaceId,
		state.mode,
		state.selectedThreadID,
		isCopilotSpacePath,
		currentMode.name,
		pastedFile,
		handleSubmit,
		clearPastedFile
	]);
	const sendMessageToNewThread = useCallback(() => {
		if (submitDisabled) return;
		handleSubmitToNewThread();
	}, [handleSubmitToNewThread, submitDisabled]);
	const editLastMessage = useCallback(() => {
		const id = state.messages.findLast((m_5) => m_5.role === "user")?.id;
		if (id) manager.startEditingMessage(id);
	}, [manager, state.messages]);
	const placeholderText = (() => {
		if (state.isWaitingOnCopilot) return "Copilot is responding…";
		if (state.defaultRecipient) return void 0;
		if (maxMessagesReached) return "Message limit reached. To continue chatting with Copilot, start a new conversation.";
		return currentMode.placeholder ?? "Ask anything";
	})();
	if (state.defaultRecipient && text === "" && !typingHasStarted) setText(`@${state.defaultRecipient} `);
	const attachmentButtonRef = useRef(null);
	const [attachmentMenuPanel, setAttachmentMenuPanel] = useState(null);
	const [lastAttachedRepo, setLastAttachedRepo] = useState(null);
	const addAttachment = useCallback(() => {
		sendEvent("dotcom_chat.activate", {
			target: "ATTACHMENT_MENU",
			mode: state.mode
		});
		setAttachmentMenuPanel((panel) => panel === "attachment-types" ? null : "attachment-types");
	}, [state.mode, setAttachmentMenuPanel]);
	const setDeepCodeSearch = useCallback(() => {
		sendEvent("dotcom_chat.activate", {
			target: "DEEP_CODESEARCH",
			mode: state.mode
		});
		manager.dispatch({
			type: "SET_DEEP_CODESEARCH",
			deepCodeSearch: !state.skillOptions?.deepCodeSearch
		});
	}, [
		manager,
		state.mode,
		state.skillOptions?.deepCodeSearch
	]);
	const shouldShowImages = state.mode === "immersive" && !!model.capabilities?.supports?.vision || false;
	const handleFileAttachment = useCallback(async (files, uploadType, namePromise, name) => {
		const imageAttacher = new CopilotImageAttacher(getChatState(), manager);
		const textAttacher = new CopilotTextAttacher(manager, props.existingFileNames);
		const attachedFiles = [];
		if ([...files].some((file) => file.type.startsWith("image/")) && !model.capabilities?.supports?.vision) {
			manager.addAmbientError(`The ${model.displayName} model doesn't support answering questions about images. Select a different model and try again.`);
			sendVisionErrorEvent("vision_not_supported_for_model", {
				modelId: model.id,
				uploadType
			});
		}
		const [imageFiles, otherFiles] = CopilotImageAttacher.getAllowedFiles([...files], model);
		if (shouldShowImages) {
			const imageAttachments = await imageAttacher.addImageAttachments(imageFiles, uploadType);
			if (imageAttachments) attachedFiles.push(...imageAttachments);
		}
		const disallowedFileTypes = [];
		for (const file_0 of otherFiles) if (await CopilotTextAttacher.isAttachable(file_0)) {
			const attachedFile = await textAttacher.addAttachment(file_0, namePromise, name);
			if (attachedFile) attachedFiles.push(attachedFile);
		} else disallowedFileTypes.push(file_0.type);
		if (shouldShowImages && disallowedFileTypes.length > 0) sendVisionErrorEvent("included_unsupported_file", {
			fileTypes: disallowedFileTypes.join(","),
			uploadType
		});
		return attachedFiles;
	}, [
		shouldShowImages,
		model,
		getChatState,
		manager,
		props.existingFileNames
	]);
	const handleConvertToFile = useCallback(async () => {
		if (!pastedFile) return;
		const attachments = await handleFileAttachment([pastedFile], "paste", pastedFileNamePromise.current || void 0, pastedFileName.current);
		if (attachments.length > 0 && attachments[0]?.type === "thread-scoped-file") {
			const pastedText = await pastedFile.text();
			setText(text.replaceAll(pastedText, `@${attachments[0].name}`));
			clearPastedFile(false);
			sendEvent("dotcom_chat.activate", {
				target: "CONVERT_TO_FILE_CONVERT",
				mode: state.mode
			});
		}
	}, [
		pastedFile,
		handleFileAttachment,
		state.mode,
		text,
		setText,
		clearPastedFile
	]);
	const handleConvertToFileDismiss = useCallback(() => {
		clearPastedFile(true);
	}, [clearPastedFile]);
	useEffect(() => {
		if (pastedFile && !state.isWaitingOnAttachment && !convertToFileShownLogged.current) {
			convertToFileShownLogged.current = true;
			sendEvent("dotcom_chat.activate", {
				target: "CONVERT_TO_FILE_TRIGGER",
				mode: state.mode
			});
		}
	}, [
		pastedFile,
		state.isWaitingOnAttachment,
		state.mode
	]);
	const supportsReferenceAttachments = (currentMode.supportsReferenceAttachments ?? true) && command !== "agent";
	const supportedReferenceTypes = currentMode.supportedReferenceTypes;
	const handlePaste = useCallback((event) => {
		const clipboardData = event.clipboardData;
		if (!clipboardData?.items) return;
		const fileArray_0 = [];
		const items = Array.from(clipboardData.items);
		for (const item of items) if (item.kind === "file") {
			const file_1 = item.getAsFile();
			if (file_1) fileArray_0.push(file_1);
		} else if (item.kind === "string" && ["text", "text/plain"].includes(item.type)) {
			const pastedText_0 = clipboardData.getData(item.type);
			if (pastedText_0.length > PASTE_TEXT_AS_FILE_THRESHOLD && pastedText_0.length <= CopilotTextAttacher.getAttachmentSizeLimit()) safeSetTimeout(() => {
				convertToFileShownLogged.current = false;
				const file_2 = new File([pastedText_0], "", { type: CLIPBOARD_MIME_TYPE });
				const textAttacher_0 = new CopilotTextAttacher(manager, props.existingFileNames);
				setPastedFile(file_2);
				pastedFileNamePromise.current = textAttacher_0.generateFileName(pastedText_0, file_2.type).then((name_0) => pastedFileName.current = name_0);
			}, 0);
			else if (supportsReferenceAttachments) {
				addReferencesForMentions(pastedText_0, supportedReferenceTypes);
				const insertionIndex = textAreaRef.current?.selectionStart ?? 0;
				setTimeout(() => replaceUrlWithReferenceMention([insertionIndex, insertionIndex + pastedText_0.length], supportedReferenceTypes));
			}
			return;
		}
		if (fileArray_0.length > 0) {
			event.preventDefault();
			handleFileAttachment(fileArray_0, "paste");
		}
	}, [
		safeSetTimeout,
		manager,
		props.existingFileNames,
		supportsReferenceAttachments,
		supportedReferenceTypes,
		addReferencesForMentions,
		textAreaRef,
		replaceUrlWithReferenceMention,
		handleFileAttachment
	]);
	const handleFileDrop = useCallback((files_0) => {
		handleFileAttachment(files_0, "drag");
	}, [handleFileAttachment]);
	const onRepoAttach = useCallback((repo) => {
		if (repo) setLastUsedRepo(repo);
		setLastAttachedRepo(repo);
	}, [setLastUsedRepo, setLastAttachedRepo]);
	const onCommandAutoComplete = useCallback((commandKey) => {
		const selectedCommand = availableCommands.find((cmd_2) => cmd_2.key === commandKey);
		if (selectedCommand?.enabled?.() === false && selectedCommand.disabledAction) {
			selectedCommand.disabledAction(navigate);
			return;
		}
		if (copilotFeatureFlags.askModeDropdown) {
			if (selectedCommand?.mode) {
				onModeSelect(selectedCommand.mode, true);
				const commandPattern = new RegExp(`^/${commandKey}\\s*`);
				if (commandPattern.test(text)) setText(text.replace(commandPattern, ""));
			} else if (activeMode.name !== ModeSupportName.Ask) {
				const askMode = chatModes.find((m_6) => m_6.name === ModeSupportName.Ask);
				if (askMode) onModeSelect(askMode, true);
			}
		}
	}, [
		availableCommands,
		navigate,
		activeMode.name,
		onModeSelect,
		text,
		setText,
		chatModes
	]);
	const stoppable = props.isStreaming || state.isWaitingOnCopilot;
	const supportsAttachments = Boolean(currentMode.supportsAttachments) && command !== "agent";
	return /* @__PURE__ */ jsxs("div", {
		className: ChatInput_module_default.container,
		children: [
			/* @__PURE__ */ jsxs(ScopedCommands, {
				commands: useMemo(() => ({
					"github:cancel": stoppable ? stopResponse : void 0,
					"copilot-chat:send-message": shouldSubmitWithModifier ? void 0 : sendMessage,
					"github:submit-form": sendMessage,
					"copilot-chat:send-message-new-conversation": sendMessageToNewThread,
					"copilot-chat:add-attachment": addAttachment,
					"copilot-chat:edit-last-message": textAreaEmpty ? editLastMessage : void 0,
					"copilot-chat:deep-codesearch": setDeepCodeSearch
				}), [
					addAttachment,
					editLastMessage,
					sendMessage,
					sendMessageToNewThread,
					setDeepCodeSearch,
					shouldSubmitWithModifier,
					stopResponse,
					stoppable,
					textAreaEmpty
				]),
				children: [/* @__PURE__ */ jsxs("form", {
					className: clsx(ChatInput_module_default.chatForm, {
						[ChatInput_module_default.containerSmall]: props.size === "small",
						[ChatInput_module_default.containerDisabled]: disabled
					}, props.className),
					ref: containerRef,
					...testIdProps("copilot-chat-input-form"),
					...props.dropTargetProps,
					children: [
						supportsReferenceAttachments && /* @__PURE__ */ jsx(ChatInputReferences, {
							className: ChatInput_module_default.attachments,
							returnFocusRef: attachmentButtonRef,
							tokenSize: props.size === "small" ? "small" : "medium",
							isLoading: mentionReferencesPending,
							onSelectReference,
							onPromoteImplicitReference: props.onPromoteImplicitReference,
							onRemoveReference: props.onRemoveReference,
							getReferenceVersion: props.getReferenceVersion,
							showConvertToFileText: !!pastedFile && !state.isWaitingOnAttachment,
							onConvertToFile: handleConvertToFile,
							onConvertToFileDismiss: handleConvertToFileDismiss,
							hideAttachmentsMenu: !!props.initialReference || currentMode.supportsAttachmentsMenu === false,
							referenceTypeFilter: supportedReferenceTypes
						}),
						/* @__PURE__ */ jsxs(ScopedCommands.LimitKeybindingScope, {
							commandIds: LIMITED_KEYBINDING_COMMAND_IDS,
							className: clsx(ChatInput_module_default.inputContainer, { [ChatInput_module_default.inputContainerNewConversation]: props.isNewConversation }),
							ref: textAreaPreviewContainerRef,
							children: [/* @__PURE__ */ jsx(ChatInputAutocomplete, {
								onSelectReference: addReferenceForMention,
								onShowAgentsDialog: setAttachmentMenuPanel,
								onSelectCommand: onCommandAutoComplete,
								hideAutocomplete: !currentMode.supportsAutocompletion,
								availableCommands,
								availableModes: chatModes,
								children: /* @__PURE__ */ jsx("textarea", {
									autoFocus: !props.disableAutoFocus,
									id: copilotChatTextAreaId,
									className: clsx(ChatInput_module_default.input, { [ChatInput_module_default.inputDisabled]: disabled }),
									autoComplete: "off",
									autoCorrect: props.enableAutoCorrect ? "on" : "off",
									"aria-label": currentMode.textAreaAriaLabel || placeholderText,
									"aria-multiline": "true",
									onPaste: props.onPaste ?? handlePaste,
									ref: textAreaRef,
									onScroll: handleScroll,
									onChange: handleChange,
									onFocus: handleFocus,
									placeholder: placeholderText,
									value: text,
									"data-react-autofocus": true,
									disabled,
									maxLength: props.maxPromptLength,
									...testIdProps("copilot-chat-input-textarea")
								})
							}), /* @__PURE__ */ jsx(ChatInputPreview, {
								text,
								ref: textareaPreviewRef,
								availableCommandKeys
							})]
						}),
						/* @__PURE__ */ jsx(ChatInputToolbar, {
							addAttachment,
							currentMode,
							attachmentButtonRef,
							deepCodeSearch: state.skillOptions?.deepCodeSearch,
							modes: chatModes,
							onClickMode,
							stoppable,
							submitDisabled,
							isNewConversation: props.isNewConversation,
							onNewThreadSelected: props.onNewThreadSelected,
							supportsAttachments,
							disabled,
							shouldSubmitWithModifier,
							extraToolbarByMode: {
								default: extraToolbar,
								agent: extraToolbar ?? /* @__PURE__ */ jsx(TaskChatInputToolbar, {
									iconOnly: !props.isNewConversation || props.forceIconOnly,
									selectedRepo,
									selectedBranch,
									selectedAgent,
									onRepoSelect: setSelectedRepo,
									onBranchSelect: setSelectedBranch,
									onAgentSelect: (agent) => setSelectedAgent(agent),
									agentSelectionEnabled: copilotFeatureFlags.sweAgentUseSubagents,
									initialRepoNWO,
									textAreaRef
								})
							},
							chatCommand: command,
							isAssistive: state.mode === "assistive",
							isCopilotSpace: !!activeCopilotSpaceId,
							isAgentTaskSubmitInProgress,
							isIncompleteCommand,
							customModelPicker,
							selectedAgent,
							showStartTaskButton: props.showStartTaskButton,
							availableCommands,
							navigate,
							forceIconOnly: props.forceIconOnly
						})
					]
				}), props.showStartTaskButton && /* @__PURE__ */ jsx(SubmitButton, {
					disabled: submitDisabled,
					label: currentMode.submitLabel,
					isAgentTaskSubmitInProgress,
					isIncompleteCommand,
					showStartTaskButton: props.showStartTaskButton,
					shouldSubmitWithModifier,
					className: clsx(ChatInput_module_default.submitButtonOutsideForm)
				})]
			}),
			!copilotFeatureFlags.codingAgentPullRequestToggle && decoupledModeEnabled && isAgent && /* @__PURE__ */ jsx(DecoupledModeBanner, { enabled: state.showDecoupledPRModeBanner ?? true }),
			/* @__PURE__ */ jsx(AttachmentMenu, {
				inputRef: textAreaRef,
				inputOnChange: handleChange,
				anchorRef: attachmentButtonRef,
				panel: attachmentMenuPanel,
				onPanelChange: setAttachmentMenuPanel,
				initialRepo: lastAttachedRepo,
				onRepoSelect: onRepoAttach,
				side: props.attachmentMenuSide ?? preferredOverlaySide
			}),
			supportsAttachments && !isCopilotSpacePage && /* @__PURE__ */ jsx(FullScreenDragOverlay, {
				onFilesDrop: handleFileDrop,
				isUploading: state.isWaitingOnAttachment && state.attachmentProcessingType === "file-upload"
			})
		]
	});
};
ChatInput.displayName = "ChatInput";
var extraToolbarByModeDefault = {
	default: null,
	agent: null
};
/** Maps overlay anchor side to tooltip direction */
var getTooltipDirection = (overlaySide) => overlaySide === "outside-top" ? "n" : "s";
var ChatInputToolbar = memo((props) => {
	const $ = c(2);
	const { chatCommand, extraToolbarByMode: t0, currentMode, supportsAttachments, submitDisabled, isAssistive, isCopilotSpace, isAgentTaskSubmitInProgress: t1, isIncompleteCommand, showStartTaskButton, availableCommands, navigate, shouldSubmitWithModifier: t2 } = props;
	const extraToolbarByMode = t0 === void 0 ? extraToolbarByModeDefault : t0;
	const isAgentTaskSubmitInProgress = t1 === void 0 ? false : t1;
	const shouldSubmitWithModifier = t2 === void 0 ? false : t2;
	const preferredOverlaySide = useOverlayDirection();
	const tooltipDirection = getTooltipDirection(preferredOverlaySide);
	const commandSupportsModelPickerAndMcp = (chatCommand !== "agent" || copilotFeatureFlags.codingAgentModelSelection) && chatCommand !== "loop" && chatCommand !== "spark";
	const showModelPicker = !!(props.onNewThreadSelected && currentMode.supportsModelSwitching && commandSupportsModelPickerAndMcp);
	const isAgent = isAgentCommand(currentMode.name, chatCommand);
	const attachmentButtonLabel = isCopilotSpace ? "Add files" : copilotFeatureFlags.copilotChatRepositoryPicker ? "Add files, and spaces" : "Add repositories, files, and spaces";
	const { customModelPicker, selectedAgent, onNewThreadSelected, disabled, isNewConversation, forceIconOnly } = props;
	let t3;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = { narrow: true };
		$[0] = t3;
	} else t3 = $[0];
	const isNarrow = useResponsiveValue(t3, false);
	const showIconOnly = isNarrow || !isNewConversation || forceIconOnly;
	const [isPopoverDismissed, setIsPopoverDismissed] = useState(_temp);
	const showAgentCapabilitiesPopover = copilotFeatureFlags.agentExpandedCapabilitiesTooltip && currentMode.name === ModeSupportName.Ask && !isPopoverDismissed && !isNarrow && isNewConversation;
	let t4;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => {
			setIsPopoverDismissed(true);
		};
		$[1] = t4;
	} else t4 = $[1];
	const handlePopoverDismiss = t4;
	return jsxs("div", {
		className: clsx(ChatInput_module_default.toolbar, { [ChatInput_module_default.toolbarNoModes]: props.modes.length === 1 }),
		children: [
			props.modes.length > 1 && jsx("div", {
				className: ChatInput_module_default.mode,
				children: jsxs("div", {
					className: "d-flex",
					children: [jsxs(ActionMenu, { children: [showIconOnly ? jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
						"aria-label": currentMode.name,
						className: ChatInput_module_default.modeSelectButton,
						variant: "invisible",
						icon: currentMode.icon,
						tooltipDirection,
						onClick: handlePopoverDismiss
					}) }) : jsx(ActionMenu.Button, {
						className: ChatInput_module_default.modeSelectButton,
						leadingVisual: jsx(currentMode.icon, {}),
						variant: "invisible",
						trailingAction: TriangleDownIcon,
						onClick: handlePopoverDismiss,
						children: currentMode.name
					}), jsx(ActionMenu.Overlay, {
						width: "auto",
						side: preferredOverlaySide,
						position: isAssistive ? "relative" : void 0,
						portalContainerName: isAssistive ? "copilotChatMenuPortalRoot" : void 0,
						children: jsx(ActionList, {
							selectionVariant: "single",
							role: "menu",
							"aria-label": "Item",
							children: props.modes.map((mode) => {
								const modeCommand = availableCommands.find((cmd) => cmd.mode?.name === mode.name);
								let isCommandDisabled = false;
								if (modeCommand?.enabled) isCommandDisabled = modeCommand.enabled() === false;
								return jsxs(ActionList.Item, {
									selected: currentMode.name === mode.name,
									onSelect: () => {
										if (isCommandDisabled && modeCommand?.disabledAction) modeCommand.disabledAction(navigate);
										else props.onClickMode?.(mode.name);
									},
									children: [
										jsx(ActionList.LeadingVisual, { children: jsx(mode.icon, {}) }),
										mode.name,
										isCommandDisabled && jsx(ActionList.TrailingVisual, { children: jsx(Label, { children: "Upgrade" }) })
									]
								}, mode.name);
							})
						})
					})] }), showAgentCapabilitiesPopover && jsx(AgentCapabilitiesPopover, { onDismiss: handlePopoverDismiss })]
				})
			}),
			jsxs("div", {
				className: ChatInput_module_default.extra,
				children: [
					supportsAttachments && copilotFeatureFlags.copilotChatRepositoryPicker && !isCopilotSpace && jsx(ChatReposPicker, {
						showIconOnly,
						tooltipDirection
					}),
					supportsAttachments && (copilotFeatureFlags.askModeDropdown ? jsx(IconButton, {
						ref: props.attachmentButtonRef,
						icon: PlusIcon,
						className: ChatInput_module_default.attachmentIconButton,
						"aria-label": attachmentButtonLabel,
						tooltipDirection,
						onClick: props.addAttachment,
						"data-testid": "attachment-menu-button"
					}) : jsx(ButtonComponent, {
						ref: props.attachmentButtonRef,
						leadingVisual: PlusIcon,
						variant: "invisible",
						"aria-label": attachmentButtonLabel,
						className: ChatInput_module_default.attachmentButton,
						onClick: props.addAttachment,
						"data-testid": "attachment-menu-button",
						children: jsx("span", {
							className: clsx(ChatInput_module_default.attachmentButtonText, { "sr-only": isAgent }),
							children: attachmentButtonLabel
						})
					})),
					copilotFeatureFlags.showDeepCodeSearchButton && jsx(CommandIconButton, {
						commandId: "copilot-chat:deep-codesearch",
						icon: RocketIcon,
						variant: "invisible",
						tooltipDirection,
						className: clsx({ [ChatInput_module_default.clicked]: props.deepCodeSearch })
					}),
					extraToolbarByMode[isAgent ? "agent" : "default"]
				]
			}),
			jsxs("div", {
				className: clsx(ChatInput_module_default.actions, { [ChatInput_module_default.actionsMultiple]: showModelPicker }),
				children: [showModelPicker && (customModelPicker ? customModelPicker({ selectedAgent }) : jsx(ModelPicker, {
					onNewThreadSelected,
					disabled
				})), jsx("div", {
					className: ChatInput_module_default.toolbarButtons,
					children: props.stoppable ? jsx(StopButton, { tooltipDirection }) : jsx(SubmitButton, {
						disabled: submitDisabled,
						label: currentMode.submitLabel,
						isAgentTaskSubmitInProgress,
						isIncompleteCommand,
						showStartTaskButton,
						shouldSubmitWithModifier,
						tooltipDirection,
						className: showStartTaskButton ? ChatInput_module_default.submitButtonInForm : void 0
					})
				})]
			})
		]
	});
});
ChatInputToolbar.displayName = "ChatInputToolbar";
function SubmitButton({ disabled, label, isAgentTaskSubmitInProgress = false, isIncompleteCommand, showStartTaskButton, shouldSubmitWithModifier = false, tooltipDirection = "s", className }) {
	const getAriaLabel = () => {
		if (!disabled) return label || "Send now";
		if (isIncompleteCommand) return "Complete your slash command before sending";
		return label || "Sending a message is unavailable";
	};
	const buttonContent = isAgentTaskSubmitInProgress ? /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-items-center height-full mx-2",
		children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
	}) : showStartTaskButton && disabled ? /* @__PURE__ */ jsx(ButtonComponent, {
		size: "medium",
		leadingVisual: PaperAirplaneIcon,
		inactive: true,
		children: START_TASK_BUTTON_TEXT
	}) : disabled ? /* @__PURE__ */ jsx(IconButton, {
		variant: "invisible",
		size: "medium",
		icon: PaperAirplaneIcon,
		"aria-label": getAriaLabel(),
		tooltipDirection,
		inactive: true,
		"aria-disabled": true
	}) : showStartTaskButton ? /* @__PURE__ */ jsx(CommandButton, {
		commandId: shouldSubmitWithModifier ? "github:submit-form" : "copilot-chat:send-message",
		leadingVisual: PaperAirplaneIcon,
		children: START_TASK_BUTTON_TEXT
	}) : /* @__PURE__ */ jsx(CommandIconButton, {
		commandId: shouldSubmitWithModifier ? "github:submit-form" : "copilot-chat:send-message",
		variant: "invisible",
		size: "medium",
		icon: PaperAirplaneIcon,
		"aria-label": getAriaLabel(),
		tooltipDirection
	});
	return className ? /* @__PURE__ */ jsx("div", {
		className,
		children: buttonContent
	}) : buttonContent;
}
SubmitButton.displayName = "SubmitButton";
function StopButton({ tooltipDirection }) {
	return /* @__PURE__ */ jsx(CommandIconButton, {
		...testIdProps("copilot-chat-stop-button"),
		commandId: "github:cancel",
		variant: "invisible",
		size: "medium",
		icon: SquareFillIcon,
		tooltipDirection,
		className: ChatInput_module_default.CommandIconButton
	});
}
StopButton.displayName = "StopButton";
function _temp() {
	return copilotLocalStorage.getAgentCapabilitiesTooltipDismissed();
}
export { useSpaceSelection as A, useCustomCopilotsEnabled as C, useRepositoryItems as D, useLastUsedRepository as E, useResizablePanel as O, useAvailableCommands as S, useIsScrolledToEnd as T, extractChatCommandType as _, CopilotSpaceSSOError as a, iconForReference as b, FileTreePicker as c, RepoSelectPanel as d, RepositoryListItem as f, convertFlatPathsToTreeItems as g, WebSearchReferencePreview as h, CopilotSpaceNotFoundError as i, userMessageParser as j, useSelectedCopilotSpaceId as k, ReferencePreview as l, VersionName as m, ChatInput as n, CopilotTextAttacher as o, UserMessage_module_default as p, ChatInputValidationError as r, FigmaIcon as s, BingIcon as t, ReferenceToken as u, getSelectedThread as v, useFetchCopilotSpace as w, useAvailableAgents as x, hasPotentialAgentMention as y };
