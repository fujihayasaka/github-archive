import { bn as Link, cn as InfoIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { a as isEnterprise } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Box } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { o as updateNavigationTabCount } from "./server-global-navigation-CMV1pRiF-CAlzMUki.js";
import { Fragment, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var ContributorFooter_module_default = { ContributorFooterContainer: "ContributorFooter-module_9YUx4a_ContributorFooterContainer" };
function ContributorFooter(props) {
	const { contributingFileUrl, securityPolicyUrl, codeOfConductFileUrl, supportFileUrl } = props;
	if (isEnterprise() || !contributingFileUrl && !securityPolicyUrl && !codeOfConductFileUrl && !supportFileUrl) return null;
	return /* @__PURE__ */ jsx(ContributorFooterContent, { ...props });
}
ContributorFooter.displayName = "ContributorFooter";
function ContributorFooterContent(t0) {
	const $ = c(9);
	const { contributingFileUrl, securityPolicyUrl, codeOfConductFileUrl, supportFileUrl, sx, className } = t0;
	let t1;
	if ($[0] !== codeOfConductFileUrl || $[1] !== contributingFileUrl || $[2] !== securityPolicyUrl || $[3] !== supportFileUrl) {
		bb0: {
			const existingLinks = [];
			if (contributingFileUrl) existingLinks.push(jsx(Link, {
				inline: true,
				href: contributingFileUrl,
				children: "contributing guidelines"
			}));
			if (securityPolicyUrl) existingLinks.push(jsx(Link, {
				inline: true,
				href: securityPolicyUrl,
				children: "security policy"
			}));
			if (codeOfConductFileUrl) existingLinks.push(jsx(Link, {
				inline: true,
				href: codeOfConductFileUrl,
				children: "code of conduct"
			}));
			if (supportFileUrl) existingLinks.push(jsx(Link, {
				inline: true,
				href: supportFileUrl,
				children: "Support"
			}));
			if (existingLinks.length === 1) {
				t1 = jsx(Fragment$1, { children: existingLinks[0] });
				break bb0;
			}
			const allLinksExceptLast = existingLinks.slice(0, -1);
			const lastLink = existingLinks[existingLinks.length - 1];
			t1 = jsxs(Fragment$1, { children: [allLinksExceptLast.map((link, i) => jsxs(Fragment, { children: [link, jsx("span", { children: i !== allLinksExceptLast.length - 1 ? ", " : " " })] }, i)), jsxs("span", { children: ["and ", lastLink] })] });
		}
		$[0] = codeOfConductFileUrl;
		$[1] = contributingFileUrl;
		$[2] = securityPolicyUrl;
		$[3] = supportFileUrl;
		$[4] = t1;
	} else t1 = $[4];
	const links = t1;
	let t2;
	if ($[5] !== className || $[6] !== links || $[7] !== sx) {
		t2 = jsxs(Box, {
			"data-testid": "contributor-footer",
			sx,
			className: clsx(ContributorFooter_module_default.ContributorFooterContainer, className),
			children: [jsx(Octicon, { icon: InfoIcon }), jsxs("div", {
				"data-testid": "contributor-footer-text",
				children: [
					jsx("span", { children: "Remember, contributions to this repository should follow its " }),
					jsx("span", { children: links }),
					jsx("span", { children: "." })
				]
			})]
		});
		$[5] = className;
		$[6] = links;
		$[7] = sx;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
ContributorFooterContent.displayName = "ContributorFooterContent";
function changeIssuesTabCounter(delta) {
	if (updateNavigationTabCount("issues", delta)) return true;
	const issuesTab = document.getElementById("issues-repo-tab-count");
	if (issuesTab === null) return false;
	const currentCount = Number(issuesTab.title.replace(/\D/g, ""));
	const newCount = Math.max(currentCount + delta, 0);
	if (currentCount === 0 && newCount > 0) unhideIssuesTabCounter(issuesTab);
	else if (newCount === 0) hideIssuesTabCounter(issuesTab);
	issuesTab.title = newCount.toLocaleString();
	if (!!/^\d+$/.test(issuesTab.textContent || "") && newCount <= 999) issuesTab.textContent = newCount.toString();
	return true;
}
function incrementIssuesTabCounter() {
	changeIssuesTabCounter(1);
}
function decrementIssuesTabCounter() {
	changeIssuesTabCounter(-1);
}
function hideIssuesTabCounter(issuesTab) {
	issuesTab.setAttribute("hidden", "true");
}
function unhideIssuesTabCounter(issuesTab) {
	issuesTab.removeAttribute("hidden");
}
export { decrementIssuesTabCounter as n, incrementIssuesTabCounter as r, ContributorFooter as t };
