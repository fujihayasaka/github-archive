import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as QueryRouteQueryType, r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
var codeViewBlameRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewBlameRoute", {
	path: "/:owner/:repo/blame/:branch/*",
	queries: [mainQuery({ encodeFetchPath: true }), {
		queryName: "contributors",
		queryDeps: ({ params }) => {
			return { pathname: repositoryTreePath({
				repo: {
					ownerLogin: params.owner,
					name: params.repo
				},
				commitish: params.branch,
				path: params["*"] || "",
				action: "file-contributors"
			}) };
		},
		queryFn: async (queryKey) => queryFnFetch(queryKey),
		type: QueryRouteQueryType.Deferred
	}]
});
export { codeViewBlameRoute as t };
