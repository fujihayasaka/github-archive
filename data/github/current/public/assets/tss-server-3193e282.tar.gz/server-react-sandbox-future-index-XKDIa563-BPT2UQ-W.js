performance.mark("js-parse-end:server-react-sandbox-future-index-XKDIa563-BPT2UQ-W.js");
import { jsx, jsxs } from "react/jsx-runtime";
import { getRouteApi } from "@tanstack/react-router";
performance.mark("js-parse-end:react-sandbox-future-index-XKDIa563.js");
function ReactSandboxFutureIndex() {
	const { serverTime, someField: message } = getRouteApi("/_nav/_react_sandbox_future/react_sandbox_future/").useLoaderData();
	return /* @__PURE__ */ jsxs("main", { children: [
		/* @__PURE__ */ jsx("h2", { children: "Welcome to the React Sandbox Future Index" }),
		/* @__PURE__ */ jsxs("p", { children: ["Server message: ", message] }),
		/* @__PURE__ */ jsxs("p", { children: ["Server time: ", serverTime] })
	] });
}
ReactSandboxFutureIndex.displayName = "ReactSandboxFutureIndex";
var SplitComponent = ReactSandboxFutureIndex;
export { SplitComponent as component };
