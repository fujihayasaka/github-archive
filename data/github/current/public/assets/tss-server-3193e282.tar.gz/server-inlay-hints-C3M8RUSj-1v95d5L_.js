performance.mark("js-parse-end:server-inlay-hints-C3M8RUSj-1v95d5L_.js");
import { t as getDocumentUri } from "./server-document-uri-CiR3FLCW-BF5w9Niz.js";
import { Decoration, EditorView, WidgetType } from "@codemirror/view";
import { StateEffect, StateField } from "@codemirror/state";
import { getInlayHints } from "@actions/languageservice";
import { clearCacheEntry } from "@actions/languageservice/utils/workflow-cache";
import { TextDocument } from "vscode-languageserver-textdocument";
performance.mark("js-parse-end:inlay-hints-C3M8RUSj.js");
/**
* Inlay hints for workflow YAML editor
*
* Displays inline hints for cron expressions showing human-readable schedule descriptions.
* Uses @actions/languageservice getInlayHints to get the hint text.
*/
/** Delay before updating hints after typing stops, to avoid excessive re-computation */
var DEBOUNCE_MS = 300;
/**
* Create a text document for the language service, clearing any cached parse results first.
*/
function createTextDocument(content) {
	const documentUri = getDocumentUri();
	clearCacheEntry(documentUri);
	return TextDocument.create(documentUri, "yaml", 1, content);
}
/**
* Widget that renders an inlay hint as an inline element
*/
var InlayHintWidget = class extends WidgetType {
	label;
	paddingLeft;
	paddingRight;
	constructor(label, paddingLeft, paddingRight) {
		super();
		this.label = label;
		this.paddingLeft = paddingLeft;
		this.paddingRight = paddingRight;
	}
	eq(other) {
		return this.label === other.label && this.paddingLeft === other.paddingLeft && this.paddingRight === other.paddingRight;
	}
	toDOM() {
		const span = document.createElement("span");
		span.className = "cm-inlay-hint";
		span.setAttribute("aria-hidden", "true");
		span.textContent = this.label;
		if (this.paddingLeft) span.style.paddingLeft = "1ch";
		if (this.paddingRight) span.style.paddingRight = "1ch";
		return span;
	}
	ignoreEvent() {
		return true;
	}
};
/**
* Convert LSP InlayHint to CodeMirror position
*/
function getLabelText(hint) {
	if (typeof hint.label === "string") return hint.label;
	return hint.label.map((part) => part.value).join("");
}
/**
* Effect to update inlay hint decorations
*/
var setInlayHints = StateEffect.define();
/**
* Build decorations from inlay hints
*/
function buildInlayHintDecorations(view) {
	try {
		const doc = view.state.doc;
		const hints = getInlayHints(createTextDocument(doc.toString()));
		if (hints.length === 0) return Decoration.none;
		const decorations = [];
		for (const hint of hints) {
			const pos = doc.line(hint.position.line + 1).from + hint.position.character;
			const widget = new InlayHintWidget(getLabelText(hint), hint.paddingLeft ?? false, hint.paddingRight ?? false);
			decorations.push({
				from: pos,
				to: pos,
				decoration: Decoration.widget({
					widget,
					side: 1
				})
			});
		}
		decorations.sort((a, b) => a.from - b.from);
		return Decoration.set(decorations.map((d) => d.decoration.range(d.from, d.to)));
	} catch (error) {
		console.error("[Language Service] Inlay hints error:", error);
		return Decoration.none;
	}
}
/**
* StateField that manages inlay hint decorations
*/
var inlayHintsField = StateField.define({
	create(_state) {
		return Decoration.none;
	},
	update(decorations, tr) {
		for (const effect of tr.effects) if (effect.is(setInlayHints)) return effect.value;
		if (tr.docChanged) return decorations.map(tr.changes);
		return decorations;
	},
	provide(field) {
		return EditorView.decorations.from(field);
	}
});
/**
* Per-editor debounce timers to avoid race conditions when multiple editors are open
*/
var debounceTimers = /* @__PURE__ */ new WeakMap();
/**
* Track whether initial update has been scheduled
*/
var initialUpdateScheduled = /* @__PURE__ */ new WeakSet();
/**
* Schedule an update of inlay hints for a specific editor
*/
function scheduleUpdate(view) {
	const existingTimer = debounceTimers.get(view);
	if (existingTimer) clearTimeout(existingTimer);
	const timer = setTimeout(() => {
		debounceTimers.delete(view);
		const decorations = buildInlayHintDecorations(view);
		view.dispatch({ effects: setInlayHints.of(decorations) });
	}, DEBOUNCE_MS);
	debounceTimers.set(view, timer);
}
/**
* Update listener that triggers inlay hint updates on document changes
*/
var inlayHintsUpdateListener = EditorView.updateListener.of((update) => {
	if (update.docChanged || update.viewportChanged) scheduleUpdate(update.view);
});
/**
* Theme for inlay hints
*/
var inlayHintsTheme = EditorView.baseTheme({
	".cm-inlay-hint": {
		color: "var(--fgColor-muted, var(--color-fg-muted))",
		fontStyle: "italic",
		fontSize: "0.9em"
	},
	"@media (forced-colors: active)": { ".cm-inlay-hint": {
		color: "GrayText",
		fontStyle: "italic"
	} }
});
/**
* Extension that provides inlay hints for workflow YAML files
*
* This shows human-readable descriptions inline after cron expressions.
*/
function workflowInlayHints() {
	return [
		inlayHintsField,
		inlayHintsUpdateListener,
		inlayHintsTheme,
		EditorView.updateListener.of((update) => {
			if (!update.view.state.field(inlayHintsField, false)) return;
			if (!initialUpdateScheduled.has(update.view)) {
				initialUpdateScheduled.add(update.view);
				scheduleUpdate(update.view);
			}
		})
	];
}
export { workflowInlayHints };
