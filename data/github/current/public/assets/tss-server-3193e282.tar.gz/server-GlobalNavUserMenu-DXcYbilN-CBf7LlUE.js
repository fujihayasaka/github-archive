performance.mark("js-parse-end:server-GlobalNavUserMenu-DXcYbilN-CBf7LlUE.js");
import { G as CodeSquareIcon, Or as ShieldIcon, Pr as SignOutIcon, Rr as SmileyIcon, Wn as OrganizationIcon, Yt as GlobeIcon, Zr as StarIcon, _i as Truncate, en as HeartIcon, er as PersonIcon, et as CopilotIcon, gr as RepoIcon, h as BeakerIcon, n as ActionList, pi as Tooltip$1, qn as PaintbrushIcon, qr as Stack, t as AccessibilityIcon, wi as UploadIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { n as ErrorDialog, t as AccountSwitcher } from "./server-ErrorDialog-DGbSeS_Q-C-O7tuGz.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { l as useQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as UnsafeHTMLDiv } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as getCookie } from "./server-cookies-DndQO37X-vNR87gG9.js";
import { t as useExternalAnchor } from "./server-react-partial-anchor-DSxm7g5E-DAe-R2_8.js";
import { n as COOKIE_NAME } from "./server-constants-xMVBIU7B-COI4NwYP.js";
import { t as LoadingSkeleton } from "./server-LoadingSkeleton-Dd8-Bxdj-C5S_-f5d.js";
import { t as lazyWithPreload } from "./server-lazy-with-preload-CGaVyU2--DP3_troP.js";
import { t as Emoji } from "./server-Emoji-BFUUoP8k-D2ScGNcm.js";
import { t as analyticsCategory } from "./server-constants-CqVh5mOx-CvujeEpf.js";
import { Suspense, memo, useCallback, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:GlobalNavUserMenu-DXcYbilN.js");
var styles_module_default = {
	emojiContainer: "styles-module_8BWW1q_emojiContainer",
	emojiIcon: "styles-module_8BWW1q_emojiIcon"
};
var ENTERPRISE_TASKS_ENDPOINT = "/in-product-messaging/enterprise-new-tasks-indicator.json";
function useEnterpriseTasksData() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			queryKey: ["enterprise-tasks-data", ENTERPRISE_TASKS_ENDPOINT],
			queryFn: _temp$1
		};
		$[0] = t0;
	} else t0 = $[0];
	return useQuery(t0);
}
async function _temp$1() {
	const response = await fetch(ENTERPRISE_TASKS_ENDPOINT, { credentials: "include" });
	if (!response.ok) throw new Error(`Network response was not ok: ${response.statusText}`);
	return response.json();
}
var erroredLazyLoadItemData = {
	userStatus: {},
	hasUnseenFeatures: false,
	stashedAccounts: []
};
var LAZY_DATA__DEFAULT_ENDPOINT = "/_side-panels/user.json";
function useLazyData(t0) {
	const $ = c(10);
	const url = t0 === void 0 ? LAZY_DATA__DEFAULT_ENDPOINT : t0;
	const queryClient = useQueryClient();
	let t1;
	if ($[0] !== url) {
		t1 = {
			queryKey: [
				"global-nav-user-menu",
				"lazy-data",
				url
			],
			queryFn: async () => {
				const response = await fetch(url, { credentials: "include" });
				if (!response.ok) throw new Error(`Network response was not ok: ${response.statusText}`);
				return response.json();
			}
		};
		$[0] = url;
		$[1] = t1;
	} else t1 = $[1];
	const { data, error, isLoading } = useQuery(t1);
	let t2;
	if ($[2] !== queryClient || $[3] !== url) {
		t2 = (userStatus) => {
			queryClient.setQueryData([
				"global-nav-user-menu",
				"lazy-data",
				url
			], (oldData) => {
				if (!oldData) return oldData;
				return {
					...oldData,
					userStatus
				};
			});
		};
		$[2] = queryClient;
		$[3] = url;
		$[4] = t2;
	} else t2 = $[4];
	const updateUserStatus = t2;
	const t3 = error ? erroredLazyLoadItemData : data;
	let t4;
	if ($[5] !== error || $[6] !== isLoading || $[7] !== t3 || $[8] !== updateUserStatus) {
		t4 = {
			data: t3,
			updateUserStatus,
			error,
			isLoading
		};
		$[5] = error;
		$[6] = isLoading;
		$[7] = t3;
		$[8] = updateUserStatus;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
}
var ORG_TASKS_ENDPOINT = "/in-product-messaging/organization-new-tasks-indicator.json";
function useOrgTasksData() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			queryKey: ["org-tasks-data", ORG_TASKS_ENDPOINT],
			queryFn: _temp
		};
		$[0] = t0;
	} else t0 = $[0];
	return useQuery(t0);
}
async function _temp() {
	const response = await fetch(ORG_TASKS_ENDPOINT, { credentials: "include" });
	if (!response.ok) throw new Error(`Network response was not ok: ${response.statusText}`);
	return response.json();
}
function hasSSOBannerCookie() {
	const ssoCookie = getCookie(COOKIE_NAME);
	return Boolean(ssoCookie?.value);
}
var emptyAnalytics = {
	category: "",
	action: "",
	label: ""
};
function NavLink(t0) {
	const $ = c(13);
	const { href, icon: NavIcon, children, className, analyticsAction, extraAnalytics: t1, extraOnClick } = t0;
	const extraAnalytics = t1 === void 0 ? emptyAnalytics : t1;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t2;
	if ($[0] !== analyticsAction || $[1] !== extraAnalytics.action || $[2] !== extraAnalytics.category || $[3] !== extraAnalytics.label || $[4] !== extraOnClick || $[5] !== sendClickAnalyticsEvent) {
		t2 = () => {
			if (extraAnalytics.category) sendClickAnalyticsEvent({
				category: extraAnalytics.category,
				action: extraAnalytics.action,
				label: extraAnalytics.label
			});
			sendClickAnalyticsEvent({
				category: analyticsCategory,
				action: analyticsAction
			});
			extraOnClick?.();
		};
		$[0] = analyticsAction;
		$[1] = extraAnalytics.action;
		$[2] = extraAnalytics.category;
		$[3] = extraAnalytics.label;
		$[4] = extraOnClick;
		$[5] = sendClickAnalyticsEvent;
		$[6] = t2;
	} else t2 = $[6];
	const onClick = t2;
	let t3;
	if ($[7] !== NavIcon || $[8] !== children || $[9] !== className || $[10] !== href || $[11] !== onClick) {
		t3 = jsxs(ActionList.LinkItem, {
			href,
			onClick,
			className,
			children: [jsx(ActionList.LeadingVisual, { children: jsx(NavIcon, {}) }), children]
		});
		$[7] = NavIcon;
		$[8] = children;
		$[9] = className;
		$[10] = href;
		$[11] = onClick;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
}
NavLink.displayName = "NavLink";
var UserStatusWrapper = ({ children, hasStatusMessage }) => hasStatusMessage ? /* @__PURE__ */ jsx(Tooltip$1, {
	direction: "sw",
	delay: "long",
	text: "Edit status",
	children
}) : children;
UserStatusWrapper.displayName = "UserStatusWrapper";
var UserStatusNavItem = memo(function UserStatusNavItem(t0) {
	const $ = c(3);
	const { lazyLoadItemData, onClick } = t0;
	const loadingAttributes = lazyLoadItemData ? void 0 : {
		"aria-label": "Set status",
		"aria-labelledby": void 0
	};
	const hasStatusMessage = (lazyLoadItemData?.userStatus?.messageHtml?.length ?? 0) > 0;
	const [isLoading, setIsLoading] = useState(true);
	const [shouldShowLoading, setShouldShowLoading] = useState(false);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = async () => {
			await LazyUserStatusDialog.preload();
			setIsLoading(false);
		};
		$[0] = t1;
	} else t1 = $[0];
	const loadUserStatusDialog = t1;
	let t2;
	if ($[1] !== onClick) {
		t2 = () => {
			setShouldShowLoading(true);
			onClick();
		};
		$[1] = onClick;
		$[2] = t2;
	} else t2 = $[2];
	const onClickWrapper = t2;
	return jsx(UserStatusWrapper, {
		hasStatusMessage,
		children: jsxs(ActionList.Item, {
			...testIdProps("global-user-nav-set-status-item"),
			...loadingAttributes,
			onSelect: onClickWrapper,
			onMouseEnter: loadUserStatusDialog,
			onFocus: loadUserStatusDialog,
			loading: shouldShowLoading && isLoading,
			children: [jsx(ActionList.LeadingVisual, { children: lazyLoadItemData?.userStatus?.emojiAttributes ? jsx(Emoji, {
				...lazyLoadItemData?.userStatus.emojiAttributes,
				tone: lazyLoadItemData?.userPreferences?.tone
			}) : jsx(SmileyIcon, {}) }), lazyLoadItemData ? jsx(UnsafeHTMLDiv, {
				className: styles_module_default.emojiContainer,
				html: lazyLoadItemData.userStatus.messageHtml || "Set status"
			}) : jsx(LoadingSkeleton, { height: "md" })]
		})
	});
});
UserStatusNavItem.displayName = "UserStatusNavItem";
function UpgradeNavItem({ lazyLoadItemData }) {
	const enterpriseTrialUrl = lazyLoadItemData?.enterpriseTrialUrl;
	if (enterpriseTrialUrl) return /* @__PURE__ */ jsxs(NavLink, {
		href: enterpriseTrialUrl,
		icon: UploadIcon,
		extraAnalytics: {
			category: "start_a_free_trial",
			action: "click_to_set_up_enterprise_trial",
			label: "ref_loc:side_panel;ref_cta:try_enterprise"
		},
		analyticsAction: "TRY_ENTERPRISE",
		children: ["Try Enterprise", /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(Label, {
			variant: "primary",
			children: "Free"
		}) })]
	});
	else return /* @__PURE__ */ jsx(NavLink, {
		href: "/account/choose?action=upgrade",
		icon: UploadIcon,
		analyticsAction: "UPGRADE_PLAN",
		children: "Upgrade"
	});
}
UpgradeNavItem.displayName = "UpgradeNavItem";
function GlobalNavUserMenu({ lazyLoadItemDataFetchUrl, onClose: onCloseBase, owner, canAddAccount, addAccountPath, switchAccountPath, loginAccountPath, showAccountSwitcher, open, anchorRef, showGists, gistsUrl, showOrganizations, showSponsors, showUpgrade, showEnterprises, showEnterprise, yourEnterpriseUrl, showEnterpriseSettings, enterpriseSettingsUrl, showCopilot, showFeaturesPreviews }) {
	const { data: lazyLoadItemData, updateUserStatus } = useLazyData(lazyLoadItemDataFetchUrl);
	const { data: lazyOrganizationNewTasksData } = useOrgTasksData();
	const { data: lazyEnterpriseNewTasksData } = useEnterpriseTasksData();
	const [showUserStatusDialog, setShowUserStatusDialog] = useState(false);
	const [showFeaturePreviewDialog, setShowFeaturePreviewDialog] = useState(false);
	const profilePath = `/${owner.login}`;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const onClose = useCallback((gesture) => {
		onCloseBase(gesture);
	}, [onCloseBase]);
	const openUserStatusDialog = useCallback(() => {
		setShowUserStatusDialog(true);
		sendClickAnalyticsEvent({
			category: analyticsCategory,
			action: "USER_STATUS"
		});
	}, [sendClickAnalyticsEvent]);
	const onUserStatusClosed = useCallback(async (statusPromise) => {
		setShowUserStatusDialog(false);
		if (statusPromise && typeof statusPromise !== "string") try {
			updateUserStatus(await statusPromise);
		} catch {}
	}, [updateUserStatus]);
	const [isLoadingFeaturePreview, setIsLoadingFeaturePreview] = useState(true);
	const [shouldShowLoadingFeaturePreview, setShouldShowLoadingFeaturePreview] = useState(false);
	const openFeaturePreviewDialog = useCallback(() => {
		setShouldShowLoadingFeaturePreview(true);
		setShowFeaturePreviewDialog(true);
		sendClickAnalyticsEvent({
			category: analyticsCategory,
			action: "FEATURE_PREVIEW"
		});
	}, [sendClickAnalyticsEvent]);
	const loadFeaturePreviewDialog = useCallback(async () => {
		await LazyFeaturePreviewDialog.preload();
		setIsLoadingFeaturePreview(false);
	}, []);
	const stashedAccounts = lazyLoadItemData?.stashedAccounts;
	const [error, setError] = useState(false);
	const renderHeader = useCallback(({ dialogLabelId }) => {
		return /* @__PURE__ */ jsxs("div", {
			className: "d-flex tmp-pr-3 tmp-pl-3 tmp-pt-3",
			id: dialogLabelId,
			"aria-label": "User navigation",
			role: "heading",
			"aria-level": 1,
			children: [
				/* @__PURE__ */ jsx("div", {
					className: "d-flex flex-1",
					children: /* @__PURE__ */ jsxs("div", {
						className: "d-flex",
						children: [/* @__PURE__ */ jsx(GitHubAvatar, {
							src: owner.avatarUrl,
							size: 32
						}), /* @__PURE__ */ jsxs("div", {
							className: "lh-condensed overflow-hidden d-flex flex-column flex-justify-center ml-2 f5 mr-auto",
							children: [/* @__PURE__ */ jsx("div", {
								className: "text-bold",
								children: /* @__PURE__ */ jsx(Truncate, {
									title: owner.login,
									maxWidth: 120,
									children: owner.login
								})
							}), /* @__PURE__ */ jsx("div", {
								className: "fgColor-muted",
								children: /* @__PURE__ */ jsx(Truncate, {
									title: owner.name,
									maxWidth: 120,
									children: owner.name
								})
							})]
						})]
					})
				}),
				showAccountSwitcher && /* @__PURE__ */ jsx(AccountSwitcher, {
					canAddAccount,
					addAccountPath,
					switchAccountPath,
					stashedAccounts: stashedAccounts ?? null,
					loginAccountPath,
					setError
				}),
				/* @__PURE__ */ jsx("div", {
					className: "d-md-none",
					children: /* @__PURE__ */ jsx(Dialog.CloseButton, { onClose: () => onClose("close-button") })
				})
			]
		});
	}, [
		onClose,
		owner,
		stashedAccounts,
		canAddAccount,
		addAccountPath,
		switchAccountPath,
		loginAccountPath,
		showAccountSwitcher
	]);
	const featurePreviewRef = useRef(null);
	const userStatusRef = useRef(null);
	const ignoreClickRefs = useMemo(() => [featurePreviewRef, userStatusRef], [featurePreviewRef, userStatusRef]);
	if (!open) return null;
	if (error) return /* @__PURE__ */ jsx(ErrorDialog, {
		...error,
		onClose: () => setError(false)
	});
	return /* @__PURE__ */ jsxs(ReductiveUserMenu, {
		onClose: (reason) => {
			if (showFeaturePreviewDialog) return;
			if (showUserStatusDialog) return;
			onClose(reason);
		},
		renderHeader,
		anchorRef,
		ignoreClickRefs,
		children: [
			showUserStatusDialog && /* @__PURE__ */ jsx(Suspense, {
				fallback: null,
				children: /* @__PURE__ */ jsx(LazyUserStatusDialog, {
					userStatusData: lazyLoadItemData?.userStatus,
					userPreferences: lazyLoadItemData?.userPreferences,
					ref: userStatusRef,
					onClose: onUserStatusClosed
				})
			}),
			showFeaturePreviewDialog && /* @__PURE__ */ jsx(Suspense, {
				fallback: null,
				children: /* @__PURE__ */ jsx(LazyFeaturePreviewDialog, {
					ref: featurePreviewRef,
					onClose: () => setShowFeaturePreviewDialog(false),
					login: owner.login
				})
			}),
			/* @__PURE__ */ jsx(Stack, {
				gap: "condensed",
				children: /* @__PURE__ */ jsxs(ActionList, {
					variant: "full",
					children: [
						/* @__PURE__ */ jsx(UserStatusNavItem, {
							lazyLoadItemData,
							onClick: openUserStatusDialog
						}),
						/* @__PURE__ */ jsx(SSONavLink, { lazyLoadItemData }),
						/* @__PURE__ */ jsx(ActionList.Divider, {}),
						/* @__PURE__ */ jsx(CreateNewRepoItem, {}),
						/* @__PURE__ */ jsx(NavLink, {
							href: profilePath,
							icon: PersonIcon,
							analyticsAction: "PROFILE",
							children: "Profile"
						}),
						/* @__PURE__ */ jsx(NavLink, {
							href: `${profilePath}?tab=repositories`,
							icon: RepoIcon,
							analyticsAction: "YOUR_REPOSITORIES",
							children: "Repositories"
						}),
						/* @__PURE__ */ jsx(NavLink, {
							href: `${profilePath}?tab=stars`,
							icon: StarIcon,
							analyticsAction: "YOUR_STARS",
							children: "Stars"
						}),
						showGists && /* @__PURE__ */ jsx(NavLink, {
							href: gistsUrl,
							icon: CodeSquareIcon,
							analyticsAction: "YOUR_GISTS",
							children: "Gists"
						}),
						showOrganizations && /* @__PURE__ */ jsxs(NavLink, {
							href: "/settings/organizations",
							icon: OrganizationIcon,
							analyticsAction: "YOUR_ORGANIZATIONS",
							extraOnClick: () => {
								if (lazyOrganizationNewTasksData?.enableOrganizationNewTasksExperiment) sendClickAnalyticsEvent({
									location: "global_user_nav_drawer",
									category: lazyOrganizationNewTasksData.showNewTasksButton ? "nav_organizations_new_tasks_nudge_1" : "nav_organizations_new_tasks_nudge_0",
									action: "new_task",
									tag: "a",
									group: "engage"
								});
							},
							children: ["Organizations", lazyOrganizationNewTasksData?.enableOrganizationNewTasksExperiment && (lazyOrganizationNewTasksData.showNewTasksButton ? /* @__PURE__ */ jsxs(ActionList.TrailingVisual, { children: [/* @__PURE__ */ jsx("span", {
								...testIdProps("analytics-data"),
								"data-analytics-visible": "{\"category\":\"nav_organizations_new_tasks_nudge_1\",\"action\":\"visible\",\"group\":\"engage\"}"
							}), /* @__PURE__ */ jsx(Label, {
								...testIdProps("new-task-label"),
								variant: "done",
								children: "New"
							})] }) : /* @__PURE__ */ jsx("span", {
								...testIdProps("analytics-data"),
								"data-analytics-visible": "{\"category\":\"nav_organizations_new_tasks_nudge_0\",\"action\":\"visible\",\"group\":\"engage\"}"
							}))]
						}),
						showEnterprises && /* @__PURE__ */ jsxs(NavLink, {
							href: "/settings/enterprises",
							icon: GlobeIcon,
							extraAnalytics: {
								category: "enterprises_more_discoverable",
								action: "click_your_enterprises",
								label: "ref_loc:side_panel;ref_cta:your_enterprises;is_navigation_redesign:true"
							},
							analyticsAction: "YOUR_ENTERPRISES",
							extraOnClick: () => {
								if (lazyEnterpriseNewTasksData?.enableEnterpriseNewTasksExperiment) {
									sendClickAnalyticsEvent({
										location: "global_user_nav_drawer",
										category: lazyEnterpriseNewTasksData.showNewTasksButton ? "nav_enterprises_new_tasks_nudge_1" : "nav_enterprises_new_tasks_nudge_0",
										action: "new_task",
										tag: "a",
										group: "engage"
									});
									sendClickAnalyticsEvent({
										location: "global_user_nav_drawer",
										category: "dfd_nav_new_tasks_nudge_1",
										action: "new_task",
										tag: "a",
										group: "engage"
									});
								}
							},
							children: ["Enterprises", lazyEnterpriseNewTasksData?.enableEnterpriseNewTasksExperiment && (lazyEnterpriseNewTasksData.showNewTasksButton ? /* @__PURE__ */ jsxs(ActionList.TrailingVisual, { children: [
								/* @__PURE__ */ jsx("span", {
									...testIdProps("analytics-data"),
									"data-analytics-visible": "{\"category\":\"dfd_nav_new_tasks_nudge_1\",\"action\":\"visible\",\"group\":\"engage\"}"
								}),
								/* @__PURE__ */ jsx("span", {
									...testIdProps("analytics-data"),
									"data-analytics-visible": "{\"category\":\"nav_enterprises_new_tasks_nudge_1\",\"action\":\"visible\",\"group\":\"engage\"}"
								}),
								/* @__PURE__ */ jsx(Label, {
									...testIdProps("new-task-label"),
									variant: "done",
									children: "New"
								})
							] }) : /* @__PURE__ */ jsx("span", {
								...testIdProps("analytics-data"),
								"data-analytics-visible": "{\"category\":\"nav_enterprises_new_tasks_nudge_0\",\"action\":\"visible\",\"group\":\"engage\"}"
							}))]
						}),
						showEnterprise && /* @__PURE__ */ jsx(NavLink, {
							href: yourEnterpriseUrl,
							icon: GlobeIcon,
							analyticsAction: "YOUR_ENTERPRISE",
							children: "Enterprise"
						}),
						showSponsors && /* @__PURE__ */ jsx(NavLink, {
							href: "/sponsors/accounts",
							icon: HeartIcon,
							analyticsAction: "SPONSORS",
							children: "Sponsors"
						}),
						/* @__PURE__ */ jsx(ActionList.Divider, {}),
						/* @__PURE__ */ jsx(NavLink, {
							href: "/settings/profile",
							icon: GearIcon,
							analyticsAction: "SETTINGS",
							children: "Settings"
						}),
						showEnterpriseSettings && /* @__PURE__ */ jsx(NavLink, {
							href: enterpriseSettingsUrl,
							icon: GlobeIcon,
							analyticsAction: "ENTERPRISE_SETTINGS",
							children: "Enterprise settings"
						}),
						showCopilot && /* @__PURE__ */ jsx(NavLink, {
							href: "/settings/copilot",
							icon: CopilotIcon,
							extraAnalytics: {
								category: "try_copilot",
								action: "click_to_try_copilot",
								label: "ref_loc:side_panel;ref_cta:your_copilot"
							},
							analyticsAction: "COPILOT_SETTINGS",
							children: "Copilot settings"
						}),
						showFeaturesPreviews && /* @__PURE__ */ jsxs(ActionList.Item, {
							onSelect: openFeaturePreviewDialog,
							onMouseEnter: loadFeaturePreviewDialog,
							onFocus: loadFeaturePreviewDialog,
							loading: shouldShowLoadingFeaturePreview && isLoadingFeaturePreview,
							children: [
								/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(BeakerIcon, {}) }),
								lazyLoadItemData?.hasUnseenFeatures && /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(Label, {
									variant: "accent",
									children: "New"
								}) }),
								/* @__PURE__ */ jsx("span", { children: "Feature preview" })
							]
						}),
						/* @__PURE__ */ jsx(NavLink, {
							href: "/settings/appearance",
							icon: PaintbrushIcon,
							analyticsAction: "APPEARANCE_SETTINGS",
							children: "Appearance"
						}),
						/* @__PURE__ */ jsx(NavLink, {
							href: "/settings/accessibility",
							icon: AccessibilityIcon,
							analyticsAction: "ACCESSIBILITY_SETTINGS",
							children: "Accessibility"
						}),
						showUpgrade && /* @__PURE__ */ jsx(UpgradeNavItem, { lazyLoadItemData }),
						/* @__PURE__ */ jsx(ActionList.Divider, {}),
						/* @__PURE__ */ jsx(NavLink, {
							href: "/logout",
							icon: SignOutIcon,
							analyticsAction: "LOGOUT",
							children: "Sign out"
						})
					]
				})
			})
		]
	});
}
GlobalNavUserMenu.displayName = "GlobalNavUserMenu";
function GlobalNavUserMenuPartial({ reactPartialAnchor, ...props }) {
	const { open, setOpen, ref: anchorRef } = useExternalAnchor(reactPartialAnchor);
	const onClose = useCallback(() => {
		setOpen(false);
		setTimeout(() => {
			anchorRef.current?.focus();
		});
	}, [setOpen, anchorRef]);
	return /* @__PURE__ */ jsx(GlobalNavUserMenu, {
		...props,
		open,
		anchorRef,
		onClose
	});
}
GlobalNavUserMenuPartial.displayName = "GlobalNavUserMenuPartial";
function SSONavLink({ lazyLoadItemData }) {
	if (!lazyLoadItemData && hasSSOBannerCookie() || lazyLoadItemData?.showSSO) return /* @__PURE__ */ jsx(NavLink, {
		href: lazyLoadItemData?.ssoUrl ?? "/settings/organizations",
		icon: ShieldIcon,
		analyticsAction: "SSO",
		children: "Single sign-on"
	});
	return null;
}
SSONavLink.displayName = "SSONavLink";
function CreateNewRepoItem() {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(NavLink, {
		className: "hide-whenRegular",
		href: "/new",
		icon: RepoIcon,
		analyticsAction: "CREATE_NEW_REPOSITORY",
		children: "Create new repository"
	}), /* @__PURE__ */ jsx(ActionList.Divider, { className: "hide-whenRegular" })] });
}
CreateNewRepoItem.displayName = "CreateNewRepoItem";
function ReductiveUserMenu(t0) {
	const $ = c(14);
	const { onClose: onCloseDefault, anchorRef, ignoreClickRefs, renderHeader, children } = t0;
	let t1;
	if ($[0] !== onCloseDefault) {
		t1 = (gesture) => {
			if (gesture === "anchor-click" || gesture === "click-outside" || gesture === "close") {
				onCloseDefault("close-button");
				return;
			}
			onCloseDefault("escape");
		};
		$[0] = onCloseDefault;
		$[1] = t1;
	} else t1 = $[1];
	const onClose = t1;
	let t2;
	if ($[2] !== ignoreClickRefs) {
		t2 = ignoreClickRefs ?? [];
		$[2] = ignoreClickRefs;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== anchorRef || $[5] !== t2) {
		t3 = {
			ignoreClickRefs: [anchorRef, ...t2],
			overflow: "auto",
			maxHeight: "fit-content",
			role: "dialog",
			"aria-labelledby": "global-nav-user-menu-header",
			"aria-describedby": "global-nav-user-menu-description"
		};
		$[4] = anchorRef;
		$[5] = t2;
		$[6] = t3;
	} else t3 = $[6];
	const overlayProps = t3;
	let t4;
	if ($[7] !== anchorRef || $[8] !== children || $[9] !== onClose || $[10] !== onCloseDefault || $[11] !== overlayProps || $[12] !== renderHeader) {
		t4 = jsxs(AnchoredOverlay, {
			open: true,
			onClose,
			renderAnchor: null,
			anchorRef,
			displayCloseButton: false,
			width: "small",
			variant: {
				narrow: "fullscreen",
				regular: "anchored"
			},
			focusZoneSettings: { activeDescendantFocus: true },
			overlayProps,
			children: [renderHeader?.({
				dialogLabelId: "global-nav-user-menu-header",
				dialogDescriptionId: "global-nav-user-menu-description",
				onClose: onCloseDefault
			}), jsx("div", {
				className: "p-2",
				children
			})]
		});
		$[7] = anchorRef;
		$[8] = children;
		$[9] = onClose;
		$[10] = onCloseDefault;
		$[11] = overlayProps;
		$[12] = renderHeader;
		$[13] = t4;
	} else t4 = $[13];
	return t4;
}
ReductiveUserMenu.displayName = "ReductiveUserMenu";
var LazyFeaturePreviewDialog = lazyWithPreload(async () => {
	return { default: (await import("./server-FeaturePreviewDialog-DDZsvNNn-C_dbP94X.js")).FeaturePreviewDialog };
});
var LazyUserStatusDialog = lazyWithPreload(async () => {
	return { default: (await import("./server-UserStatusDialog-CU-yuSTH-5VhI6Ws-.js")).UserStatusDialog };
});
export { GlobalNavUserMenu };
