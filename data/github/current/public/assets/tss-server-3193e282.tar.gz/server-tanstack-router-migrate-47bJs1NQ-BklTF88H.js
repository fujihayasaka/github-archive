import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { n as isExternalToApp, r as useNavigate$1$1, t as PREVENT_AUTOFOCUS_KEY } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { f as sendStats, r as getCurrentReactAppName, t as SOFT_NAV_STATE } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { a as getSoftNavReactAppName, c as reactAppPresent, d as setLatestMechanism, f as setSoftNavMechanism, h as unsetSoftNav, i as getSoftNavMechanism, m as setSoftNavReferrer, o as getSoftNavReferrer, p as setSoftNavReactAppName, r as getSoftNavFailReason, s as inSoftNav, t as clearSoftNav } from "./server-utils-4Tqzfq5z-FwA7hod1.js";
import * as React$1 from "react";
import { createContext, use, useCallback, useEffect, useMemo, useRef } from "react";
import { jsx } from "react/jsx-runtime";
import { Link, Outlet as Outlet$1, useBlocker, useLinkProps, useLoaderData, useLocation, useMatch, useMatches, useParams, useRouter, useRouterState } from "@tanstack/react-router";
import { c } from "react/compiler-runtime";
function invariant(value, message) {
	if (value === false || value === null || typeof value === "undefined") throw new Error(message);
}
function warning(cond, message) {
	if (!cond) {
		if (typeof console !== "undefined") console.warn(message);
		try {
			throw new Error(message);
		} catch (e) {}
	}
}
function createPath({ pathname = "/", search = "", hash = "" }) {
	if (search && search !== "?") pathname += search.charAt(0) === "?" ? search : "?" + search;
	if (hash && hash !== "#") pathname += hash.charAt(0) === "#" ? hash : "#" + hash;
	return pathname;
}
function parsePath(path) {
	let parsedPath = {};
	if (path) {
		let hashIndex = path.indexOf("#");
		if (hashIndex >= 0) {
			parsedPath.hash = path.substring(hashIndex);
			path = path.substring(0, hashIndex);
		}
		let searchIndex = path.indexOf("?");
		if (searchIndex >= 0) {
			parsedPath.search = path.substring(searchIndex);
			path = path.substring(0, searchIndex);
		}
		if (path) parsedPath.pathname = path;
	}
	return parsedPath;
}
function matchRoutes(routes, locationArg, basename = "/") {
	return matchRoutesImpl(routes, locationArg, basename, false);
}
function matchRoutesImpl(routes, locationArg, basename, allowPartial) {
	let pathname = stripBasename((typeof locationArg === "string" ? parsePath(locationArg) : locationArg).pathname || "/", basename);
	if (pathname == null) return null;
	let branches = flattenRoutes(routes);
	rankRouteBranches(branches);
	let matches = null;
	for (let i = 0; matches == null && i < branches.length; ++i) {
		let decoded = decodePath(pathname);
		matches = matchRouteBranch(branches[i], decoded, allowPartial);
	}
	return matches;
}
function convertRouteMatchToUiMatch(match, loaderData) {
	let { route, pathname, params } = match;
	return {
		id: route.id,
		pathname,
		params,
		data: loaderData[route.id],
		loaderData: loaderData[route.id],
		handle: route.handle
	};
}
function flattenRoutes(routes, branches = [], parentsMeta = [], parentPath = "", _hasParentOptionalSegments = false) {
	let flattenRoute = (route, index, hasParentOptionalSegments = _hasParentOptionalSegments, relativePath) => {
		let meta = {
			relativePath: relativePath === void 0 ? route.path || "" : relativePath,
			caseSensitive: route.caseSensitive === true,
			childrenIndex: index,
			route
		};
		if (meta.relativePath.startsWith("/")) {
			if (!meta.relativePath.startsWith(parentPath) && hasParentOptionalSegments) return;
			invariant(meta.relativePath.startsWith(parentPath), `Absolute route path "${meta.relativePath}" nested under path "${parentPath}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`);
			meta.relativePath = meta.relativePath.slice(parentPath.length);
		}
		let path = joinPaths([parentPath, meta.relativePath]);
		let routesMeta = parentsMeta.concat(meta);
		if (route.children && route.children.length > 0) {
			invariant(route.index !== true, `Index routes must not have child routes. Please remove all child routes from route path "${path}".`);
			flattenRoutes(route.children, branches, routesMeta, path, hasParentOptionalSegments);
		}
		if (route.path == null && !route.index) return;
		branches.push({
			path,
			score: computeScore(path, route.index),
			routesMeta
		});
	};
	routes.forEach((route, index) => {
		if (route.path === "" || !route.path?.includes("?")) flattenRoute(route, index);
		else for (let exploded of explodeOptionalSegments(route.path)) flattenRoute(route, index, true, exploded);
	});
	return branches;
}
function explodeOptionalSegments(path) {
	let segments = path.split("/");
	if (segments.length === 0) return [];
	let [first, ...rest] = segments;
	let isOptional = first.endsWith("?");
	let required = first.replace(/\?$/, "");
	if (rest.length === 0) return isOptional ? [required, ""] : [required];
	let restExploded = explodeOptionalSegments(rest.join("/"));
	let result = [];
	result.push(...restExploded.map((subpath) => subpath === "" ? required : [required, subpath].join("/")));
	if (isOptional) result.push(...restExploded);
	return result.map((exploded) => path.startsWith("/") && exploded === "" ? "/" : exploded);
}
function rankRouteBranches(branches) {
	branches.sort((a, b) => a.score !== b.score ? b.score - a.score : compareIndexes(a.routesMeta.map((meta) => meta.childrenIndex), b.routesMeta.map((meta) => meta.childrenIndex)));
}
var paramRe = /^:[\w-]+$/;
var dynamicSegmentValue = 3;
var indexRouteValue = 2;
var emptySegmentValue = 1;
var staticSegmentValue = 10;
var splatPenalty = -2;
var isSplat = (s) => s === "*";
function computeScore(path, index) {
	let segments = path.split("/");
	let initialScore = segments.length;
	if (segments.some(isSplat)) initialScore += splatPenalty;
	if (index) initialScore += indexRouteValue;
	return segments.filter((s) => !isSplat(s)).reduce((score, segment) => score + (paramRe.test(segment) ? dynamicSegmentValue : segment === "" ? emptySegmentValue : staticSegmentValue), initialScore);
}
function compareIndexes(a, b) {
	return a.length === b.length && a.slice(0, -1).every((n, i) => n === b[i]) ? a[a.length - 1] - b[b.length - 1] : 0;
}
function matchRouteBranch(branch, pathname, allowPartial = false) {
	let { routesMeta } = branch;
	let matchedParams = {};
	let matchedPathname = "/";
	let matches = [];
	for (let i = 0; i < routesMeta.length; ++i) {
		let meta = routesMeta[i];
		let end = i === routesMeta.length - 1;
		let remainingPathname = matchedPathname === "/" ? pathname : pathname.slice(matchedPathname.length) || "/";
		let match = matchPath({
			path: meta.relativePath,
			caseSensitive: meta.caseSensitive,
			end
		}, remainingPathname);
		let route = meta.route;
		if (!match && end && allowPartial && !routesMeta[routesMeta.length - 1].route.index) match = matchPath({
			path: meta.relativePath,
			caseSensitive: meta.caseSensitive,
			end: false
		}, remainingPathname);
		if (!match) return null;
		Object.assign(matchedParams, match.params);
		matches.push({
			params: matchedParams,
			pathname: joinPaths([matchedPathname, match.pathname]),
			pathnameBase: normalizePathname(joinPaths([matchedPathname, match.pathnameBase])),
			route
		});
		if (match.pathnameBase !== "/") matchedPathname = joinPaths([matchedPathname, match.pathnameBase]);
	}
	return matches;
}
function generatePath(originalPath, params = {}) {
	let path = originalPath;
	if (path.endsWith("*") && path !== "*" && !path.endsWith("/*")) {
		warning(false, `Route path "${path}" will be treated as if it were "${path.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${path.replace(/\*$/, "/*")}".`);
		path = path.replace(/\*$/, "/*");
	}
	const prefix = path.startsWith("/") ? "/" : "";
	const stringify2 = (p) => p == null ? "" : typeof p === "string" ? p : String(p);
	return prefix + path.split(/\/+/).map((segment, index, array) => {
		if (index === array.length - 1 && segment === "*") return stringify2(params["*"]);
		const keyMatch = segment.match(/^:([\w-]+)(\??)(.*)/);
		if (keyMatch) {
			const [, key, optional, suffix] = keyMatch;
			let param = params[key];
			invariant(optional === "?" || param != null, `Missing ":${key}" param`);
			return encodeURIComponent(stringify2(param)) + suffix;
		}
		return segment.replace(/\?$/g, "");
	}).filter((segment) => !!segment).join("/");
}
function matchPath(pattern, pathname) {
	if (typeof pattern === "string") pattern = {
		path: pattern,
		caseSensitive: false,
		end: true
	};
	let [matcher, compiledParams] = compilePath(pattern.path, pattern.caseSensitive, pattern.end);
	let match = pathname.match(matcher);
	if (!match) return null;
	let matchedPathname = match[0];
	let pathnameBase = matchedPathname.replace(/(.)\/+$/, "$1");
	let captureGroups = match.slice(1);
	return {
		params: compiledParams.reduce((memo2, { paramName, isOptional }, index) => {
			if (paramName === "*") {
				let splatValue = captureGroups[index] || "";
				pathnameBase = matchedPathname.slice(0, matchedPathname.length - splatValue.length).replace(/(.)\/+$/, "$1");
			}
			const value = captureGroups[index];
			if (isOptional && !value) memo2[paramName] = void 0;
			else memo2[paramName] = (value || "").replace(/%2F/g, "/");
			return memo2;
		}, {}),
		pathname: matchedPathname,
		pathnameBase,
		pattern
	};
}
function compilePath(path, caseSensitive = false, end = true) {
	warning(path === "*" || !path.endsWith("*") || path.endsWith("/*"), `Route path "${path}" will be treated as if it were "${path.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${path.replace(/\*$/, "/*")}".`);
	let params = [];
	let regexpSource = "^" + path.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (_, paramName, isOptional) => {
		params.push({
			paramName,
			isOptional: isOptional != null
		});
		return isOptional ? "/?([^\\/]+)?" : "/([^\\/]+)";
	}).replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
	if (path.endsWith("*")) {
		params.push({ paramName: "*" });
		regexpSource += path === "*" || path === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$";
	} else if (end) regexpSource += "\\/*$";
	else if (path !== "" && path !== "/") regexpSource += "(?:(?=\\/|$))";
	return [new RegExp(regexpSource, caseSensitive ? void 0 : "i"), params];
}
function decodePath(value) {
	try {
		return value.split("/").map((v) => decodeURIComponent(v).replace(/\//g, "%2F")).join("/");
	} catch (error) {
		warning(false, `The URL path "${value}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${error}).`);
		return value;
	}
}
function stripBasename(pathname, basename) {
	if (basename === "/") return pathname;
	if (!pathname.toLowerCase().startsWith(basename.toLowerCase())) return null;
	let startIndex = basename.endsWith("/") ? basename.length - 1 : basename.length;
	let nextChar = pathname.charAt(startIndex);
	if (nextChar && nextChar !== "/") return null;
	return pathname.slice(startIndex) || "/";
}
var ABSOLUTE_URL_REGEX = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;
var isAbsoluteUrl = (url) => ABSOLUTE_URL_REGEX.test(url);
function resolvePath(to, fromPathname = "/") {
	let { pathname: toPathname, search = "", hash = "" } = typeof to === "string" ? parsePath(to) : to;
	let pathname;
	if (toPathname) if (isAbsoluteUrl(toPathname)) pathname = toPathname;
	else {
		if (toPathname.includes("//")) {
			let oldPathname = toPathname;
			toPathname = toPathname.replace(/\/\/+/g, "/");
			warning(false, `Pathnames cannot have embedded double slashes - normalizing ${oldPathname} -> ${toPathname}`);
		}
		if (toPathname.startsWith("/")) pathname = resolvePathname(toPathname.substring(1), "/");
		else pathname = resolvePathname(toPathname, fromPathname);
	}
	else pathname = fromPathname;
	return {
		pathname,
		search: normalizeSearch(search),
		hash: normalizeHash(hash)
	};
}
function resolvePathname(relativePath, fromPathname) {
	let segments = fromPathname.replace(/\/+$/, "").split("/");
	relativePath.split("/").forEach((segment) => {
		if (segment === "..") {
			if (segments.length > 1) segments.pop();
		} else if (segment !== ".") segments.push(segment);
	});
	return segments.length > 1 ? segments.join("/") : "/";
}
function getInvalidPathError(char, field, dest, path) {
	return `Cannot include a '${char}' character in a manually specified \`to.${field}\` field [${JSON.stringify(path)}].  Please separate it out to the \`to.${dest}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
}
function getPathContributingMatches(matches) {
	return matches.filter((match, index) => index === 0 || match.route.path && match.route.path.length > 0);
}
function getResolveToMatches(matches) {
	let pathMatches = getPathContributingMatches(matches);
	return pathMatches.map((match, idx) => idx === pathMatches.length - 1 ? match.pathname : match.pathnameBase);
}
function resolveTo(toArg, routePathnames, locationPathname, isPathRelative = false) {
	let to;
	if (typeof toArg === "string") to = parsePath(toArg);
	else {
		to = { ...toArg };
		invariant(!to.pathname || !to.pathname.includes("?"), getInvalidPathError("?", "pathname", "search", to));
		invariant(!to.pathname || !to.pathname.includes("#"), getInvalidPathError("#", "pathname", "hash", to));
		invariant(!to.search || !to.search.includes("#"), getInvalidPathError("#", "search", "hash", to));
	}
	let isEmptyPath = toArg === "" || to.pathname === "";
	let toPathname = isEmptyPath ? "/" : to.pathname;
	let from;
	if (toPathname == null) from = locationPathname;
	else {
		let routePathnameIndex = routePathnames.length - 1;
		if (!isPathRelative && toPathname.startsWith("..")) {
			let toSegments = toPathname.split("/");
			while (toSegments[0] === "..") {
				toSegments.shift();
				routePathnameIndex -= 1;
			}
			to.pathname = toSegments.join("/");
		}
		from = routePathnameIndex >= 0 ? routePathnames[routePathnameIndex] : "/";
	}
	let path = resolvePath(to, from);
	let hasExplicitTrailingSlash = toPathname && toPathname !== "/" && toPathname.endsWith("/");
	let hasCurrentTrailingSlash = (isEmptyPath || toPathname === ".") && locationPathname.endsWith("/");
	if (!path.pathname.endsWith("/") && (hasExplicitTrailingSlash || hasCurrentTrailingSlash)) path.pathname += "/";
	return path;
}
var joinPaths = (paths) => paths.join("/").replace(/\/\/+/g, "/");
var normalizePathname = (pathname) => pathname.replace(/\/+$/, "").replace(/^\/*/, "/");
var normalizeSearch = (search) => !search || search === "?" ? "" : search.startsWith("?") ? search : "?" + search;
var normalizeHash = (hash) => !hash || hash === "#" ? "" : hash.startsWith("#") ? hash : "#" + hash;
var ErrorResponseImpl = class {
	constructor(status, statusText, data2, internal = false) {
		this.status = status;
		this.statusText = statusText || "";
		this.internal = internal;
		if (data2 instanceof Error) {
			this.data = data2.toString();
			this.error = data2;
		} else this.data = data2;
	}
};
function isRouteErrorResponse(error) {
	return error != null && typeof error.status === "number" && typeof error.statusText === "string" && typeof error.internal === "boolean" && "data" in error;
}
function getRoutePattern(matches) {
	return matches.map((m) => m.route.path).filter(Boolean).join("/").replace(/\/\/*/g, "/") || "/";
}
var isBrowser = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
function parseToInfo(_to, basename) {
	let to = _to;
	if (typeof to !== "string" || !ABSOLUTE_URL_REGEX.test(to)) return {
		absoluteURL: void 0,
		isExternal: false,
		to
	};
	let absoluteURL = to;
	let isExternal = false;
	if (isBrowser) try {
		let currentUrl = new URL(window.location.href);
		let targetUrl = to.startsWith("//") ? new URL(currentUrl.protocol + to) : new URL(to);
		let path = stripBasename(targetUrl.pathname, basename);
		if (targetUrl.origin === currentUrl.origin && path != null) to = path + targetUrl.search + targetUrl.hash;
		else isExternal = true;
	} catch (e) {
		warning(false, `<Link to="${to}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`);
	}
	return {
		absoluteURL,
		isExternal,
		to
	};
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
var DataRouterContext = React$1.createContext(null);
DataRouterContext.displayName = "DataRouter";
var DataRouterStateContext = React$1.createContext(null);
DataRouterStateContext.displayName = "DataRouterState";
var RSCRouterContext = React$1.createContext(false);
var ViewTransitionContext = React$1.createContext({ isTransitioning: false });
ViewTransitionContext.displayName = "ViewTransition";
var FetchersContext = React$1.createContext(/* @__PURE__ */ new Map());
FetchersContext.displayName = "Fetchers";
var AwaitContext = React$1.createContext(null);
AwaitContext.displayName = "Await";
var NavigationContext = React$1.createContext(null);
NavigationContext.displayName = "Navigation";
var LocationContext = React$1.createContext(null);
LocationContext.displayName = "Location";
var RouteContext = React$1.createContext({
	outlet: null,
	matches: [],
	isDataRoute: false
});
RouteContext.displayName = "Route";
var RouteErrorContext = React$1.createContext(null);
RouteErrorContext.displayName = "RouteError";
var ERROR_DIGEST_BASE = "REACT_ROUTER_ERROR";
var ERROR_DIGEST_REDIRECT = "REDIRECT";
var ERROR_DIGEST_ROUTE_ERROR_RESPONSE = "ROUTE_ERROR_RESPONSE";
function decodeRedirectErrorDigest(digest) {
	if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_REDIRECT}:{`)) try {
		let parsed = JSON.parse(digest.slice(28));
		if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string" && typeof parsed.location === "string" && typeof parsed.reloadDocument === "boolean" && typeof parsed.replace === "boolean") return parsed;
	} catch {}
}
function decodeRouteErrorResponseDigest(digest) {
	if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_ROUTE_ERROR_RESPONSE}:{`)) try {
		let parsed = JSON.parse(digest.slice(40));
		if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string") return new ErrorResponseImpl(parsed.status, parsed.statusText, parsed.data);
	} catch {}
}
function useHref(to, { relative } = {}) {
	invariant(useInRouterContext(), `useHref() may be used only in the context of a <Router> component.`);
	let { basename, navigator } = React$1.useContext(NavigationContext);
	let { hash, pathname, search } = useResolvedPath(to, { relative });
	let joinedPathname = pathname;
	if (basename !== "/") joinedPathname = pathname === "/" ? basename : joinPaths([basename, pathname]);
	return navigator.createHref({
		pathname: joinedPathname,
		search,
		hash
	});
}
function useInRouterContext() {
	return React$1.useContext(LocationContext) != null;
}
function useLocation$2() {
	invariant(useInRouterContext(), `useLocation() may be used only in the context of a <Router> component.`);
	return React$1.useContext(LocationContext).location;
}
var navigateEffectWarning = `You should call navigate() in a React.useEffect(), not when your component is first rendered.`;
function useIsomorphicLayoutEffect(cb) {
	if (!React$1.useContext(NavigationContext).static) React$1.useLayoutEffect(cb);
}
function useNavigate$1() {
	let { isDataRoute } = React$1.useContext(RouteContext);
	return isDataRoute ? useNavigateStable() : useNavigateUnstable();
}
function useNavigateUnstable() {
	invariant(useInRouterContext(), `useNavigate() may be used only in the context of a <Router> component.`);
	let dataRouterContext = React$1.useContext(DataRouterContext);
	let { basename, navigator } = React$1.useContext(NavigationContext);
	let { matches } = React$1.useContext(RouteContext);
	let { pathname: locationPathname } = useLocation$2();
	let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
	let activeRef = React$1.useRef(false);
	useIsomorphicLayoutEffect(() => {
		activeRef.current = true;
	});
	return React$1.useCallback((to, options = {}) => {
		warning(activeRef.current, navigateEffectWarning);
		if (!activeRef.current) return;
		if (typeof to === "number") {
			navigator.go(to);
			return;
		}
		let path = resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, options.relative === "path");
		if (dataRouterContext == null && basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
		(!!options.replace ? navigator.replace : navigator.push)(path, options.state, options);
	}, [
		basename,
		navigator,
		routePathnamesJson,
		locationPathname,
		dataRouterContext
	]);
}
React$1.createContext(null);
function useResolvedPath(to, { relative } = {}) {
	let { matches } = React$1.useContext(RouteContext);
	let { pathname: locationPathname } = useLocation$2();
	let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
	return React$1.useMemo(() => resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, relative === "path"), [
		to,
		routePathnamesJson,
		locationPathname,
		relative
	]);
}
function useRoutesImpl(routes, locationArg, dataRouterState, onError, future) {
	invariant(useInRouterContext(), `useRoutes() may be used only in the context of a <Router> component.`);
	let { navigator } = React$1.useContext(NavigationContext);
	let { matches: parentMatches } = React$1.useContext(RouteContext);
	let routeMatch = parentMatches[parentMatches.length - 1];
	let parentParams = routeMatch ? routeMatch.params : {};
	let parentPathname = routeMatch ? routeMatch.pathname : "/";
	let parentPathnameBase = routeMatch ? routeMatch.pathnameBase : "/";
	let parentRoute = routeMatch && routeMatch.route;
	{
		let parentPath = parentRoute && parentRoute.path || "";
		warningOnce(parentPathname, !parentRoute || parentPath.endsWith("*") || parentPath.endsWith("*?"), `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${parentPathname}" (under <Route path="${parentPath}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${parentPath}"> to <Route path="${parentPath === "/" ? "*" : `${parentPath}/*`}">.`);
	}
	let locationFromContext = useLocation$2();
	let location;
	if (locationArg) {
		let parsedLocationArg = typeof locationArg === "string" ? parsePath(locationArg) : locationArg;
		invariant(parentPathnameBase === "/" || parsedLocationArg.pathname?.startsWith(parentPathnameBase), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${parentPathnameBase}" but pathname "${parsedLocationArg.pathname}" was given in the \`location\` prop.`);
		location = parsedLocationArg;
	} else location = locationFromContext;
	let pathname = location.pathname || "/";
	let remainingPathname = pathname;
	if (parentPathnameBase !== "/") {
		let parentSegments = parentPathnameBase.replace(/^\//, "").split("/");
		remainingPathname = "/" + pathname.replace(/^\//, "").split("/").slice(parentSegments.length).join("/");
	}
	let matches = matchRoutes(routes, { pathname: remainingPathname });
	warning(parentRoute || matches != null, `No routes matched location "${location.pathname}${location.search}${location.hash}" `);
	warning(matches == null || matches[matches.length - 1].route.element !== void 0 || matches[matches.length - 1].route.Component !== void 0 || matches[matches.length - 1].route.lazy !== void 0, `Matched leaf route at location "${location.pathname}${location.search}${location.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);
	let renderedMatches = _renderMatches(matches && matches.map((match) => Object.assign({}, match, {
		params: Object.assign({}, parentParams, match.params),
		pathname: joinPaths([parentPathnameBase, navigator.encodeLocation ? navigator.encodeLocation(match.pathname.replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : match.pathname]),
		pathnameBase: match.pathnameBase === "/" ? parentPathnameBase : joinPaths([parentPathnameBase, navigator.encodeLocation ? navigator.encodeLocation(match.pathnameBase.replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : match.pathnameBase])
	})), parentMatches, dataRouterState, onError, future);
	if (locationArg && renderedMatches) return /* @__PURE__ */ React$1.createElement(LocationContext.Provider, { value: {
		location: {
			pathname: "/",
			search: "",
			hash: "",
			state: null,
			key: "default",
			...location
		},
		navigationType: "POP"
	} }, renderedMatches);
	return renderedMatches;
}
function DefaultErrorComponent() {
	let error = useRouteError();
	let message = isRouteErrorResponse(error) ? `${error.status} ${error.statusText}` : error instanceof Error ? error.message : JSON.stringify(error);
	let stack = error instanceof Error ? error.stack : null;
	let lightgrey = "rgba(200,200,200, 0.5)";
	let preStyles = {
		padding: "0.5rem",
		backgroundColor: lightgrey
	};
	let codeStyles = {
		padding: "2px 4px",
		backgroundColor: lightgrey
	};
	let devInfo = null;
	console.error("Error handled by React Router default ErrorBoundary:", error);
	devInfo = /* @__PURE__ */ React$1.createElement(React$1.Fragment, null, /* @__PURE__ */ React$1.createElement("p", null, "💿 Hey developer 👋"), /* @__PURE__ */ React$1.createElement("p", null, "You can provide a way better UX than this when your app throws errors by providing your own ", /* @__PURE__ */ React$1.createElement("code", { style: codeStyles }, "ErrorBoundary"), " or", " ", /* @__PURE__ */ React$1.createElement("code", { style: codeStyles }, "errorElement"), " prop on your route."));
	return /* @__PURE__ */ React$1.createElement(React$1.Fragment, null, /* @__PURE__ */ React$1.createElement("h2", null, "Unexpected Application Error!"), /* @__PURE__ */ React$1.createElement("h3", { style: { fontStyle: "italic" } }, message), stack ? /* @__PURE__ */ React$1.createElement("pre", { style: preStyles }, stack) : null, devInfo);
}
var defaultErrorElement = /* @__PURE__ */ React$1.createElement(DefaultErrorComponent, null);
var RenderErrorBoundary = class extends React$1.Component {
	constructor(props) {
		super(props);
		this.state = {
			location: props.location,
			revalidation: props.revalidation,
			error: props.error
		};
	}
	static getDerivedStateFromError(error) {
		return { error };
	}
	static getDerivedStateFromProps(props, state) {
		if (state.location !== props.location || state.revalidation !== "idle" && props.revalidation === "idle") return {
			error: props.error,
			location: props.location,
			revalidation: props.revalidation
		};
		return {
			error: props.error !== void 0 ? props.error : state.error,
			location: state.location,
			revalidation: props.revalidation || state.revalidation
		};
	}
	componentDidCatch(error, errorInfo) {
		if (this.props.onError) this.props.onError(error, errorInfo);
		else console.error("React Router caught the following error during render", error);
	}
	render() {
		let error = this.state.error;
		if (this.context && typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
			const decoded = decodeRouteErrorResponseDigest(error.digest);
			if (decoded) error = decoded;
		}
		let result = error !== void 0 ? /* @__PURE__ */ React$1.createElement(RouteContext.Provider, { value: this.props.routeContext }, /* @__PURE__ */ React$1.createElement(RouteErrorContext.Provider, {
			value: error,
			children: this.props.component
		})) : this.props.children;
		if (this.context) return /* @__PURE__ */ React$1.createElement(RSCErrorHandler, { error }, result);
		return result;
	}
};
RenderErrorBoundary.contextType = RSCRouterContext;
var errorRedirectHandledMap = /* @__PURE__ */ new WeakMap();
function RSCErrorHandler({ children, error }) {
	let { basename } = React$1.useContext(NavigationContext);
	if (typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
		let redirect2 = decodeRedirectErrorDigest(error.digest);
		if (redirect2) {
			let existingRedirect = errorRedirectHandledMap.get(error);
			if (existingRedirect) throw existingRedirect;
			let parsed = parseToInfo(redirect2.location, basename);
			if (isBrowser && !errorRedirectHandledMap.get(error)) if (parsed.isExternal || redirect2.reloadDocument) window.location.href = parsed.absoluteURL || parsed.to;
			else {
				const redirectPromise = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(parsed.to, { replace: redirect2.replace }));
				errorRedirectHandledMap.set(error, redirectPromise);
				throw redirectPromise;
			}
			return /* @__PURE__ */ React$1.createElement("meta", {
				httpEquiv: "refresh",
				content: `0;url=${parsed.absoluteURL || parsed.to}`
			});
		}
	}
	return children;
}
function RenderedRoute({ routeContext, match, children }) {
	let dataRouterContext = React$1.useContext(DataRouterContext);
	if (dataRouterContext && dataRouterContext.static && dataRouterContext.staticContext && (match.route.errorElement || match.route.ErrorBoundary)) dataRouterContext.staticContext._deepestRenderedBoundaryId = match.route.id;
	return /* @__PURE__ */ React$1.createElement(RouteContext.Provider, { value: routeContext }, children);
}
function _renderMatches(matches, parentMatches = [], dataRouterState = null, onErrorHandler = null, future = null) {
	if (matches == null) {
		if (!dataRouterState) return null;
		if (dataRouterState.errors) matches = dataRouterState.matches;
		else if (parentMatches.length === 0 && !dataRouterState.initialized && dataRouterState.matches.length > 0) matches = dataRouterState.matches;
		else return null;
	}
	let renderedMatches = matches;
	let errors = dataRouterState?.errors;
	if (errors != null) {
		let errorIndex = renderedMatches.findIndex((m) => m.route.id && errors?.[m.route.id] !== void 0);
		invariant(errorIndex >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(errors).join(",")}`);
		renderedMatches = renderedMatches.slice(0, Math.min(renderedMatches.length, errorIndex + 1));
	}
	let renderFallback = false;
	let fallbackIndex = -1;
	if (dataRouterState) for (let i = 0; i < renderedMatches.length; i++) {
		let match = renderedMatches[i];
		if (match.route.HydrateFallback || match.route.hydrateFallbackElement) fallbackIndex = i;
		if (match.route.id) {
			let { loaderData, errors: errors2 } = dataRouterState;
			let needsToRunLoader = match.route.loader && !loaderData.hasOwnProperty(match.route.id) && (!errors2 || errors2[match.route.id] === void 0);
			if (match.route.lazy || needsToRunLoader) {
				renderFallback = true;
				if (fallbackIndex >= 0) renderedMatches = renderedMatches.slice(0, fallbackIndex + 1);
				else renderedMatches = [renderedMatches[0]];
				break;
			}
		}
	}
	let onError = dataRouterState && onErrorHandler ? (error, errorInfo) => {
		onErrorHandler(error, {
			location: dataRouterState.location,
			params: dataRouterState.matches?.[0]?.params ?? {},
			unstable_pattern: getRoutePattern(dataRouterState.matches),
			errorInfo
		});
	} : void 0;
	return renderedMatches.reduceRight((outlet, match, index) => {
		let error;
		let shouldRenderHydrateFallback = false;
		let errorElement = null;
		let hydrateFallbackElement = null;
		if (dataRouterState) {
			error = errors && match.route.id ? errors[match.route.id] : void 0;
			errorElement = match.route.errorElement || defaultErrorElement;
			if (renderFallback) {
				if (fallbackIndex < 0 && index === 0) {
					warningOnce("route-fallback", false, "No `HydrateFallback` element provided to render during initial hydration");
					shouldRenderHydrateFallback = true;
					hydrateFallbackElement = null;
				} else if (fallbackIndex === index) {
					shouldRenderHydrateFallback = true;
					hydrateFallbackElement = match.route.hydrateFallbackElement || null;
				}
			}
		}
		let matches2 = parentMatches.concat(renderedMatches.slice(0, index + 1));
		let getChildren = () => {
			let children;
			if (error) children = errorElement;
			else if (shouldRenderHydrateFallback) children = hydrateFallbackElement;
			else if (match.route.Component) children = /* @__PURE__ */ React$1.createElement(match.route.Component, null);
			else if (match.route.element) children = match.route.element;
			else children = outlet;
			return /* @__PURE__ */ React$1.createElement(RenderedRoute, {
				match,
				routeContext: {
					outlet,
					matches: matches2,
					isDataRoute: dataRouterState != null
				},
				children
			});
		};
		return dataRouterState && (match.route.ErrorBoundary || match.route.errorElement || index === 0) ? /* @__PURE__ */ React$1.createElement(RenderErrorBoundary, {
			location: dataRouterState.location,
			revalidation: dataRouterState.revalidation,
			component: errorElement,
			error,
			children: getChildren(),
			routeContext: {
				outlet: null,
				matches: matches2,
				isDataRoute: true
			},
			onError
		}) : getChildren();
	}, null);
}
function getDataRouterConsoleError(hookName) {
	return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function useDataRouterContext(hookName) {
	let ctx = React$1.useContext(DataRouterContext);
	invariant(ctx, getDataRouterConsoleError(hookName));
	return ctx;
}
function useDataRouterState(hookName) {
	let state = React$1.useContext(DataRouterStateContext);
	invariant(state, getDataRouterConsoleError(hookName));
	return state;
}
function useRouteContext(hookName) {
	let route = React$1.useContext(RouteContext);
	invariant(route, getDataRouterConsoleError(hookName));
	return route;
}
function useCurrentRouteId(hookName) {
	let route = useRouteContext(hookName);
	let thisRoute = route.matches[route.matches.length - 1];
	invariant(thisRoute.route.id, `${hookName} can only be used on routes that contain a unique "id"`);
	return thisRoute.route.id;
}
function useRouteId() {
	return useCurrentRouteId("useRouteId");
}
function useNavigation$1() {
	return useDataRouterState("useNavigation").navigation;
}
function useMatches$2() {
	let { matches, loaderData } = useDataRouterState("useMatches");
	return React$1.useMemo(() => matches.map((m) => convertRouteMatchToUiMatch(m, loaderData)), [matches, loaderData]);
}
function useRouteError() {
	let error = React$1.useContext(RouteErrorContext);
	let state = useDataRouterState("useRouteError");
	let routeId = useCurrentRouteId("useRouteError");
	if (error !== void 0) return error;
	return state.errors?.[routeId];
}
function useNavigateStable() {
	let { router } = useDataRouterContext("useNavigate");
	let id = useCurrentRouteId("useNavigate");
	let activeRef = React$1.useRef(false);
	useIsomorphicLayoutEffect(() => {
		activeRef.current = true;
	});
	return React$1.useCallback(async (to, options = {}) => {
		warning(activeRef.current, navigateEffectWarning);
		if (!activeRef.current) return;
		if (typeof to === "number") await router.navigate(to);
		else await router.navigate(to, {
			fromRouteId: id,
			...options
		});
	}, [router, id]);
}
var alreadyWarned = {};
function warningOnce(key, cond, message) {
	if (!cond && !alreadyWarned[key]) {
		alreadyWarned[key] = true;
		warning(false, message);
	}
}
React$1["useOptimistic"];
React$1.memo(DataRoutes);
function DataRoutes({ routes, future, state, onError }) {
	return useRoutesImpl(routes, void 0, state, onError, future);
}
function Router({ basename: basenameProp = "/", children = null, location: locationProp, navigationType = "POP", navigator, static: staticProp = false, unstable_useTransitions }) {
	invariant(!useInRouterContext(), `You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`);
	let basename = basenameProp.replace(/^\/*/, "/");
	let navigationContext = React$1.useMemo(() => ({
		basename,
		navigator,
		static: staticProp,
		unstable_useTransitions,
		future: {}
	}), [
		basename,
		navigator,
		staticProp,
		unstable_useTransitions
	]);
	if (typeof locationProp === "string") locationProp = parsePath(locationProp);
	let { pathname = "/", search = "", hash = "", state = null, key = "default" } = locationProp;
	let locationContext = React$1.useMemo(() => {
		let trailingPathname = stripBasename(pathname, basename);
		if (trailingPathname == null) return null;
		return {
			location: {
				pathname: trailingPathname,
				search,
				hash,
				state,
				key
			},
			navigationType
		};
	}, [
		basename,
		pathname,
		search,
		hash,
		state,
		key,
		navigationType
	]);
	warning(locationContext != null, `<Router basename="${basename}"> is not able to match the URL "${pathname}${search}${hash}" because it does not start with the basename, so the <Router> won't render anything.`);
	if (locationContext == null) return null;
	return /* @__PURE__ */ React$1.createElement(NavigationContext.Provider, { value: navigationContext }, /* @__PURE__ */ React$1.createElement(LocationContext.Provider, {
		children,
		value: locationContext
	}));
}
var defaultMethod = "get";
var defaultEncType = "application/x-www-form-urlencoded";
function isHtmlElement(object) {
	return typeof HTMLElement !== "undefined" && object instanceof HTMLElement;
}
function isButtonElement(object) {
	return isHtmlElement(object) && object.tagName.toLowerCase() === "button";
}
function isFormElement(object) {
	return isHtmlElement(object) && object.tagName.toLowerCase() === "form";
}
function isInputElement(object) {
	return isHtmlElement(object) && object.tagName.toLowerCase() === "input";
}
function isModifiedEvent(event) {
	return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
}
function shouldProcessLinkClick$1(event, target) {
	return event.button === 0 && (!target || target === "_self") && !isModifiedEvent(event);
}
var _formDataSupportsSubmitter = null;
function isFormDataSubmitterSupported() {
	if (_formDataSupportsSubmitter === null) try {
		new FormData(document.createElement("form"), 0);
		_formDataSupportsSubmitter = false;
	} catch (e) {
		_formDataSupportsSubmitter = true;
	}
	return _formDataSupportsSubmitter;
}
var supportedFormEncTypes = /* @__PURE__ */ new Set([
	"application/x-www-form-urlencoded",
	"multipart/form-data",
	"text/plain"
]);
function getFormEncType(encType) {
	if (encType != null && !supportedFormEncTypes.has(encType)) {
		warning(false, `"${encType}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${defaultEncType}"`);
		return null;
	}
	return encType;
}
function getFormSubmissionInfo(target, basename) {
	let method;
	let action;
	let encType;
	let formData;
	let body;
	if (isFormElement(target)) {
		let attr = target.getAttribute("action");
		action = attr ? stripBasename(attr, basename) : null;
		method = target.getAttribute("method") || defaultMethod;
		encType = getFormEncType(target.getAttribute("enctype")) || defaultEncType;
		formData = new FormData(target);
	} else if (isButtonElement(target) || isInputElement(target) && (target.type === "submit" || target.type === "image")) {
		let form = target.form;
		if (form == null) throw new Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);
		let attr = target.getAttribute("formaction") || form.getAttribute("action");
		action = attr ? stripBasename(attr, basename) : null;
		method = target.getAttribute("formmethod") || form.getAttribute("method") || defaultMethod;
		encType = getFormEncType(target.getAttribute("formenctype")) || getFormEncType(form.getAttribute("enctype")) || defaultEncType;
		formData = new FormData(form, target);
		if (!isFormDataSubmitterSupported()) {
			let { name, type, value } = target;
			if (type === "image") {
				let prefix = name ? `${name}.` : "";
				formData.append(`${prefix}x`, "0");
				formData.append(`${prefix}y`, "0");
			} else if (name) formData.append(name, value);
		}
	} else if (isHtmlElement(target)) throw new Error(`Cannot submit element that is not <form>, <button>, or <input type="submit|image">`);
	else {
		method = defaultMethod;
		action = null;
		encType = defaultEncType;
		body = target;
	}
	if (formData && encType === "text/plain") {
		body = formData;
		formData = void 0;
	}
	return {
		action,
		method: method.toLowerCase(),
		encType,
		formData,
		body
	};
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
var ESCAPE_LOOKUP = {
	"&": "\\u0026",
	">": "\\u003e",
	"<": "\\u003c",
	"\u2028": "\\u2028",
	"\u2029": "\\u2029"
};
var ESCAPE_REGEX = /[&><\u2028\u2029]/g;
function escapeHtml(html) {
	return html.replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
}
function invariant2(value, message) {
	if (value === false || value === null || typeof value === "undefined") throw new Error(message);
}
function singleFetchUrl(reqUrl, basename, trailingSlashAware, extension) {
	let url = typeof reqUrl === "string" ? new URL(reqUrl, typeof window === "undefined" ? "server://singlefetch/" : window.location.origin) : reqUrl;
	if (trailingSlashAware) if (url.pathname.endsWith("/")) url.pathname = `${url.pathname}_.${extension}`;
	else url.pathname = `${url.pathname}.${extension}`;
	else if (url.pathname === "/") url.pathname = `_root.${extension}`;
	else if (basename && stripBasename(url.pathname, basename) === "/") url.pathname = `${basename.replace(/\/$/, "")}/_root.${extension}`;
	else url.pathname = `${url.pathname.replace(/\/$/, "")}.${extension}`;
	return url;
}
async function loadRouteModule(route, routeModulesCache) {
	if (route.id in routeModulesCache) return routeModulesCache[route.id];
	try {
		let routeModule = await import(
			/* @vite-ignore */
			/* webpackIgnore: true */
			route.module
);
		routeModulesCache[route.id] = routeModule;
		return routeModule;
	} catch (error) {
		console.error(`Error loading route module \`${route.module}\`, reloading page...`);
		console.error(error);
		if (window.__reactRouterContext && window.__reactRouterContext.isSpaMode && void 0);
		window.location.reload();
		return new Promise(() => {});
	}
}
function isPageLinkDescriptor(object) {
	return object != null && typeof object.page === "string";
}
function isHtmlLinkDescriptor(object) {
	if (object == null) return false;
	if (object.href == null) return object.rel === "preload" && typeof object.imageSrcSet === "string" && typeof object.imageSizes === "string";
	return typeof object.rel === "string" && typeof object.href === "string";
}
async function getKeyedPrefetchLinks(matches, manifest, routeModules) {
	return dedupeLinkDescriptors((await Promise.all(matches.map(async (match) => {
		let route = manifest.routes[match.route.id];
		if (route) {
			let mod = await loadRouteModule(route, routeModules);
			return mod.links ? mod.links() : [];
		}
		return [];
	}))).flat(1).filter(isHtmlLinkDescriptor).filter((link) => link.rel === "stylesheet" || link.rel === "preload").map((link) => link.rel === "stylesheet" ? {
		...link,
		rel: "prefetch",
		as: "style"
	} : {
		...link,
		rel: "prefetch"
	}));
}
function getNewMatchesForLinks(page, nextMatches, currentMatches, manifest, location, mode) {
	let isNew = (match, index) => {
		if (!currentMatches[index]) return true;
		return match.route.id !== currentMatches[index].route.id;
	};
	let matchPathChanged = (match, index) => {
		return currentMatches[index].pathname !== match.pathname || currentMatches[index].route.path?.endsWith("*") && currentMatches[index].params["*"] !== match.params["*"];
	};
	if (mode === "assets") return nextMatches.filter((match, index) => isNew(match, index) || matchPathChanged(match, index));
	if (mode === "data") return nextMatches.filter((match, index) => {
		let manifestRoute = manifest.routes[match.route.id];
		if (!manifestRoute || !manifestRoute.hasLoader) return false;
		if (isNew(match, index) || matchPathChanged(match, index)) return true;
		if (match.route.shouldRevalidate) {
			let routeChoice = match.route.shouldRevalidate({
				currentUrl: new URL(location.pathname + location.search + location.hash, window.origin),
				currentParams: currentMatches[0]?.params || {},
				nextUrl: new URL(page, window.origin),
				nextParams: match.params,
				defaultShouldRevalidate: true
			});
			if (typeof routeChoice === "boolean") return routeChoice;
		}
		return true;
	});
	return [];
}
function getModuleLinkHrefs(matches, manifest, { includeHydrateFallback } = {}) {
	return dedupeHrefs(matches.map((match) => {
		let route = manifest.routes[match.route.id];
		if (!route) return [];
		let hrefs = [route.module];
		if (route.clientActionModule) hrefs = hrefs.concat(route.clientActionModule);
		if (route.clientLoaderModule) hrefs = hrefs.concat(route.clientLoaderModule);
		if (includeHydrateFallback && route.hydrateFallbackModule) hrefs = hrefs.concat(route.hydrateFallbackModule);
		if (route.imports) hrefs = hrefs.concat(route.imports);
		return hrefs;
	}).flat(1));
}
function dedupeHrefs(hrefs) {
	return [...new Set(hrefs)];
}
function sortKeys(obj) {
	let sorted = {};
	let keys = Object.keys(obj).sort();
	for (let key of keys) sorted[key] = obj[key];
	return sorted;
}
function dedupeLinkDescriptors(descriptors, preloads) {
	let set = /* @__PURE__ */ new Set();
	let preloadsSet = new Set(preloads);
	return descriptors.reduce((deduped, descriptor) => {
		if (preloads && !isPageLinkDescriptor(descriptor) && descriptor.as === "script" && descriptor.href && preloadsSet.has(descriptor.href)) return deduped;
		let key = JSON.stringify(sortKeys(descriptor));
		if (!set.has(key)) {
			set.add(key);
			deduped.push({
				key,
				link: descriptor
			});
		}
		return deduped;
	}, []);
}
function useDataRouterContext2() {
	let context = React$1.useContext(DataRouterContext);
	invariant2(context, "You must render this element inside a <DataRouterContext.Provider> element");
	return context;
}
function useDataRouterStateContext() {
	let context = React$1.useContext(DataRouterStateContext);
	invariant2(context, "You must render this element inside a <DataRouterStateContext.Provider> element");
	return context;
}
var FrameworkContext = React$1.createContext(void 0);
FrameworkContext.displayName = "FrameworkContext";
function useFrameworkContext() {
	let context = React$1.useContext(FrameworkContext);
	invariant2(context, "You must render this element inside a <HydratedRouter> element");
	return context;
}
function usePrefetchBehavior(prefetch, theirElementProps) {
	let frameworkContext = React$1.useContext(FrameworkContext);
	let [maybePrefetch, setMaybePrefetch] = React$1.useState(false);
	let [shouldPrefetch, setShouldPrefetch] = React$1.useState(false);
	let { onFocus, onBlur, onMouseEnter, onMouseLeave, onTouchStart } = theirElementProps;
	let ref = React$1.useRef(null);
	React$1.useEffect(() => {
		if (prefetch === "render") setShouldPrefetch(true);
		if (prefetch === "viewport") {
			let callback = (entries) => {
				entries.forEach((entry) => {
					setShouldPrefetch(entry.isIntersecting);
				});
			};
			let observer = new IntersectionObserver(callback, { threshold: .5 });
			if (ref.current) observer.observe(ref.current);
			return () => {
				observer.disconnect();
			};
		}
	}, [prefetch]);
	React$1.useEffect(() => {
		if (maybePrefetch) {
			let id = setTimeout(() => {
				setShouldPrefetch(true);
			}, 100);
			return () => {
				clearTimeout(id);
			};
		}
	}, [maybePrefetch]);
	let setIntent = () => {
		setMaybePrefetch(true);
	};
	let cancelIntent = () => {
		setMaybePrefetch(false);
		setShouldPrefetch(false);
	};
	if (!frameworkContext) return [
		false,
		ref,
		{}
	];
	if (prefetch !== "intent") return [
		shouldPrefetch,
		ref,
		{}
	];
	return [
		shouldPrefetch,
		ref,
		{
			onFocus: composeEventHandlers(onFocus, setIntent),
			onBlur: composeEventHandlers(onBlur, cancelIntent),
			onMouseEnter: composeEventHandlers(onMouseEnter, setIntent),
			onMouseLeave: composeEventHandlers(onMouseLeave, cancelIntent),
			onTouchStart: composeEventHandlers(onTouchStart, setIntent)
		}
	];
}
function composeEventHandlers(theirHandler, ourHandler) {
	return (event) => {
		theirHandler && theirHandler(event);
		if (!event.defaultPrevented) ourHandler(event);
	};
}
function PrefetchPageLinks({ page, ...linkProps }) {
	let { router } = useDataRouterContext2();
	let matches = React$1.useMemo(() => matchRoutes(router.routes, page, router.basename), [
		router.routes,
		page,
		router.basename
	]);
	if (!matches) return null;
	return /* @__PURE__ */ React$1.createElement(PrefetchPageLinksImpl, {
		page,
		matches,
		...linkProps
	});
}
function useKeyedPrefetchLinks(matches) {
	let { manifest, routeModules } = useFrameworkContext();
	let [keyedPrefetchLinks, setKeyedPrefetchLinks] = React$1.useState([]);
	React$1.useEffect(() => {
		let interrupted = false;
		getKeyedPrefetchLinks(matches, manifest, routeModules).then((links) => {
			if (!interrupted) setKeyedPrefetchLinks(links);
		});
		return () => {
			interrupted = true;
		};
	}, [
		matches,
		manifest,
		routeModules
	]);
	return keyedPrefetchLinks;
}
function PrefetchPageLinksImpl({ page, matches: nextMatches, ...linkProps }) {
	let location = useLocation$2();
	let { future, manifest, routeModules } = useFrameworkContext();
	let { basename } = useDataRouterContext2();
	let { loaderData, matches } = useDataRouterStateContext();
	let newMatchesForData = React$1.useMemo(() => getNewMatchesForLinks(page, nextMatches, matches, manifest, location, "data"), [
		page,
		nextMatches,
		matches,
		manifest,
		location
	]);
	let newMatchesForAssets = React$1.useMemo(() => getNewMatchesForLinks(page, nextMatches, matches, manifest, location, "assets"), [
		page,
		nextMatches,
		matches,
		manifest,
		location
	]);
	let dataHrefs = React$1.useMemo(() => {
		if (page === location.pathname + location.search + location.hash) return [];
		let routesParams = /* @__PURE__ */ new Set();
		let foundOptOutRoute = false;
		nextMatches.forEach((m) => {
			let manifestRoute = manifest.routes[m.route.id];
			if (!manifestRoute || !manifestRoute.hasLoader) return;
			if (!newMatchesForData.some((m2) => m2.route.id === m.route.id) && m.route.id in loaderData && routeModules[m.route.id]?.shouldRevalidate) foundOptOutRoute = true;
			else if (manifestRoute.hasClientLoader) foundOptOutRoute = true;
			else routesParams.add(m.route.id);
		});
		if (routesParams.size === 0) return [];
		let url = singleFetchUrl(page, basename, future.unstable_trailingSlashAwareDataRequests, "data");
		if (foundOptOutRoute && routesParams.size > 0) url.searchParams.set("_routes", nextMatches.filter((m) => routesParams.has(m.route.id)).map((m) => m.route.id).join(","));
		return [url.pathname + url.search];
	}, [
		basename,
		future.unstable_trailingSlashAwareDataRequests,
		loaderData,
		location,
		manifest,
		newMatchesForData,
		nextMatches,
		page,
		routeModules
	]);
	let moduleHrefs = React$1.useMemo(() => getModuleLinkHrefs(newMatchesForAssets, manifest), [newMatchesForAssets, manifest]);
	let keyedPrefetchLinks = useKeyedPrefetchLinks(newMatchesForAssets);
	return /* @__PURE__ */ React$1.createElement(React$1.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ React$1.createElement("link", {
		key: href,
		rel: "prefetch",
		as: "fetch",
		href,
		...linkProps
	})), moduleHrefs.map((href) => /* @__PURE__ */ React$1.createElement("link", {
		key: href,
		rel: "modulepreload",
		href,
		...linkProps
	})), keyedPrefetchLinks.map(({ key, link }) => /* @__PURE__ */ React$1.createElement("link", {
		key,
		nonce: linkProps.nonce,
		...link
	})));
}
function mergeRefs(...refs) {
	return (value) => {
		refs.forEach((ref) => {
			if (typeof ref === "function") ref(value);
			else if (ref != null) ref.current = value;
		});
	};
}
var isBrowser2 = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
try {
	if (isBrowser2) window.__reactRouterVersion = "7.12.0";
} catch (e) {}
function HistoryRouter({ basename, children, history, unstable_useTransitions }) {
	let [state, setStateImpl] = React$1.useState({
		action: history.action,
		location: history.location
	});
	let setState = React$1.useCallback((newState) => {
		if (unstable_useTransitions === false) setStateImpl(newState);
		else React$1.startTransition(() => setStateImpl(newState));
	}, [unstable_useTransitions]);
	React$1.useLayoutEffect(() => history.listen(setState), [history, setState]);
	return /* @__PURE__ */ React$1.createElement(Router, {
		basename,
		children,
		location: state.location,
		navigationType: state.action,
		navigator: history,
		unstable_useTransitions
	});
}
HistoryRouter.displayName = "unstable_HistoryRouter";
var ABSOLUTE_URL_REGEX2 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;
var Link$2 = React$1.forwardRef(function LinkWithRef({ onClick, discover = "render", prefetch = "none", relative, reloadDocument, replace: replace2, state, target, to, preventScrollReset, viewTransition, unstable_defaultShouldRevalidate, ...rest }, forwardedRef) {
	let { basename, unstable_useTransitions } = React$1.useContext(NavigationContext);
	let isAbsolute = typeof to === "string" && ABSOLUTE_URL_REGEX2.test(to);
	let parsed = parseToInfo(to, basename);
	to = parsed.to;
	let href = useHref(to, { relative });
	let [shouldPrefetch, prefetchRef, prefetchHandlers] = usePrefetchBehavior(prefetch, rest);
	let internalOnClick = useLinkClickHandler$1(to, {
		replace: replace2,
		state,
		target,
		preventScrollReset,
		relative,
		viewTransition,
		unstable_defaultShouldRevalidate,
		unstable_useTransitions
	});
	function handleClick(event) {
		if (onClick) onClick(event);
		if (!event.defaultPrevented) internalOnClick(event);
	}
	let link = /* @__PURE__ */ React$1.createElement("a", {
		...rest,
		...prefetchHandlers,
		href: parsed.absoluteURL || href,
		onClick: parsed.isExternal || reloadDocument ? onClick : handleClick,
		ref: mergeRefs(forwardedRef, prefetchRef),
		target,
		"data-discover": !isAbsolute && discover === "render" ? "true" : void 0
	});
	return shouldPrefetch && !isAbsolute ? /* @__PURE__ */ React$1.createElement(React$1.Fragment, null, link, /* @__PURE__ */ React$1.createElement(PrefetchPageLinks, { page: href })) : link;
});
Link$2.displayName = "Link";
var NavLink$1 = React$1.forwardRef(function NavLinkWithRef({ "aria-current": ariaCurrentProp = "page", caseSensitive = false, className: classNameProp = "", end = false, style: styleProp, to, viewTransition, children, ...rest }, ref) {
	let path = useResolvedPath(to, { relative: rest.relative });
	let location = useLocation$2();
	let routerState = React$1.useContext(DataRouterStateContext);
	let { navigator, basename } = React$1.useContext(NavigationContext);
	let isTransitioning = routerState != null && useViewTransitionState(path) && viewTransition === true;
	let toPathname = navigator.encodeLocation ? navigator.encodeLocation(path).pathname : path.pathname;
	let locationPathname = location.pathname;
	let nextLocationPathname = routerState && routerState.navigation && routerState.navigation.location ? routerState.navigation.location.pathname : null;
	if (!caseSensitive) {
		locationPathname = locationPathname.toLowerCase();
		nextLocationPathname = nextLocationPathname ? nextLocationPathname.toLowerCase() : null;
		toPathname = toPathname.toLowerCase();
	}
	if (nextLocationPathname && basename) nextLocationPathname = stripBasename(nextLocationPathname, basename) || nextLocationPathname;
	const endSlashPosition = toPathname !== "/" && toPathname.endsWith("/") ? toPathname.length - 1 : toPathname.length;
	let isActive = locationPathname === toPathname || !end && locationPathname.startsWith(toPathname) && locationPathname.charAt(endSlashPosition) === "/";
	let isPending = nextLocationPathname != null && (nextLocationPathname === toPathname || !end && nextLocationPathname.startsWith(toPathname) && nextLocationPathname.charAt(toPathname.length) === "/");
	let renderProps = {
		isActive,
		isPending,
		isTransitioning
	};
	let ariaCurrent = isActive ? ariaCurrentProp : void 0;
	let className;
	if (typeof classNameProp === "function") className = classNameProp(renderProps);
	else className = [
		classNameProp,
		isActive ? "active" : null,
		isPending ? "pending" : null,
		isTransitioning ? "transitioning" : null
	].filter(Boolean).join(" ");
	let style = typeof styleProp === "function" ? styleProp(renderProps) : styleProp;
	return /* @__PURE__ */ React$1.createElement(Link$2, {
		...rest,
		"aria-current": ariaCurrent,
		className,
		ref,
		style,
		to,
		viewTransition
	}, typeof children === "function" ? children(renderProps) : children);
});
NavLink$1.displayName = "NavLink";
var Form = React$1.forwardRef(({ discover = "render", fetcherKey, navigate, reloadDocument, replace: replace2, state, method = defaultMethod, action, onSubmit, relative, preventScrollReset, viewTransition, unstable_defaultShouldRevalidate, ...props }, forwardedRef) => {
	let { unstable_useTransitions } = React$1.useContext(NavigationContext);
	let submit = useSubmit();
	let formAction = useFormAction(action, { relative });
	let formMethod = method.toLowerCase() === "get" ? "get" : "post";
	let isAbsolute = typeof action === "string" && ABSOLUTE_URL_REGEX2.test(action);
	let submitHandler = (event) => {
		onSubmit && onSubmit(event);
		if (event.defaultPrevented) return;
		event.preventDefault();
		let submitter = event.nativeEvent.submitter;
		let submitMethod = submitter?.getAttribute("formmethod") || method;
		let doSubmit = () => submit(submitter || event.currentTarget, {
			fetcherKey,
			method: submitMethod,
			navigate,
			replace: replace2,
			state,
			relative,
			preventScrollReset,
			viewTransition,
			unstable_defaultShouldRevalidate
		});
		if (unstable_useTransitions && navigate !== false) React$1.startTransition(() => doSubmit());
		else doSubmit();
	};
	return /* @__PURE__ */ React$1.createElement("form", {
		ref: forwardedRef,
		method: formMethod,
		action: formAction,
		onSubmit: reloadDocument ? onSubmit : submitHandler,
		...props,
		"data-discover": !isAbsolute && discover === "render" ? "true" : void 0
	});
});
Form.displayName = "Form";
function ScrollRestoration({ getKey, storageKey, ...props }) {
	let remixContext = React$1.useContext(FrameworkContext);
	let { basename } = React$1.useContext(NavigationContext);
	let location = useLocation$2();
	let matches = useMatches$2();
	useScrollRestoration({
		getKey,
		storageKey
	});
	let ssrKey = React$1.useMemo(() => {
		if (!remixContext || !getKey) return null;
		let userKey = getScrollRestorationKey(location, matches, basename, getKey);
		return userKey !== location.key ? userKey : null;
	}, []);
	if (!remixContext || remixContext.isSpaMode) return null;
	let restoreScroll = ((storageKey2, restoreKey) => {
		if (!window.history.state || !window.history.state.key) {
			let key = Math.random().toString(32).slice(2);
			window.history.replaceState({ key }, "");
		}
		try {
			let storedY = JSON.parse(sessionStorage.getItem(storageKey2) || "{}")[restoreKey || window.history.state.key];
			if (typeof storedY === "number") window.scrollTo(0, storedY);
		} catch (error) {
			console.error(error);
			sessionStorage.removeItem(storageKey2);
		}
	}).toString();
	return /* @__PURE__ */ React$1.createElement("script", {
		...props,
		suppressHydrationWarning: true,
		dangerouslySetInnerHTML: { __html: `(${restoreScroll})(${escapeHtml(JSON.stringify(storageKey || SCROLL_RESTORATION_STORAGE_KEY))}, ${escapeHtml(JSON.stringify(ssrKey))})` }
	});
}
ScrollRestoration.displayName = "ScrollRestoration";
function getDataRouterConsoleError2(hookName) {
	return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function useDataRouterContext3(hookName) {
	let ctx = React$1.useContext(DataRouterContext);
	invariant(ctx, getDataRouterConsoleError2(hookName));
	return ctx;
}
function useDataRouterState2(hookName) {
	let state = React$1.useContext(DataRouterStateContext);
	invariant(state, getDataRouterConsoleError2(hookName));
	return state;
}
function useLinkClickHandler$1(to, { target, replace: replaceProp, state, preventScrollReset, relative, viewTransition, unstable_defaultShouldRevalidate, unstable_useTransitions } = {}) {
	let navigate = useNavigate$1();
	let location = useLocation$2();
	let path = useResolvedPath(to, { relative });
	return React$1.useCallback((event) => {
		if (shouldProcessLinkClick$1(event, target)) {
			event.preventDefault();
			let replace2 = replaceProp !== void 0 ? replaceProp : createPath(location) === createPath(path);
			let doNavigate = () => navigate(to, {
				replace: replace2,
				state,
				preventScrollReset,
				relative,
				viewTransition,
				unstable_defaultShouldRevalidate
			});
			if (unstable_useTransitions) React$1.startTransition(() => doNavigate());
			else doNavigate();
		}
	}, [
		location,
		navigate,
		path,
		replaceProp,
		state,
		target,
		to,
		preventScrollReset,
		relative,
		viewTransition,
		unstable_defaultShouldRevalidate,
		unstable_useTransitions
	]);
}
var fetcherId = 0;
var getUniqueFetcherId = () => `__${String(++fetcherId)}__`;
function useSubmit() {
	let { router } = useDataRouterContext3("useSubmit");
	let { basename } = React$1.useContext(NavigationContext);
	let currentRouteId = useRouteId();
	let routerFetch = router.fetch;
	let routerNavigate = router.navigate;
	return React$1.useCallback(async (target, options = {}) => {
		let { action, method, encType, formData, body } = getFormSubmissionInfo(target, basename);
		if (options.navigate === false) await routerFetch(options.fetcherKey || getUniqueFetcherId(), currentRouteId, options.action || action, {
			unstable_defaultShouldRevalidate: options.unstable_defaultShouldRevalidate,
			preventScrollReset: options.preventScrollReset,
			formData,
			body,
			formMethod: options.method || method,
			formEncType: options.encType || encType,
			flushSync: options.flushSync
		});
		else await routerNavigate(options.action || action, {
			unstable_defaultShouldRevalidate: options.unstable_defaultShouldRevalidate,
			preventScrollReset: options.preventScrollReset,
			formData,
			body,
			formMethod: options.method || method,
			formEncType: options.encType || encType,
			replace: options.replace,
			state: options.state,
			fromRouteId: currentRouteId,
			flushSync: options.flushSync,
			viewTransition: options.viewTransition
		});
	}, [
		routerFetch,
		routerNavigate,
		basename,
		currentRouteId
	]);
}
function useFormAction(action, { relative } = {}) {
	let { basename } = React$1.useContext(NavigationContext);
	let routeContext = React$1.useContext(RouteContext);
	invariant(routeContext, "useFormAction must be used inside a RouteContext");
	let [match] = routeContext.matches.slice(-1);
	let path = { ...useResolvedPath(action ? action : ".", { relative }) };
	let location = useLocation$2();
	if (action == null) {
		path.search = location.search;
		let params = new URLSearchParams(path.search);
		let indexValues = params.getAll("index");
		if (indexValues.some((v) => v === "")) {
			params.delete("index");
			indexValues.filter((v) => v).forEach((v) => params.append("index", v));
			let qs = params.toString();
			path.search = qs ? `?${qs}` : "";
		}
	}
	if ((!action || action === ".") && match.route.index) path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
	if (basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
	return createPath(path);
}
var SCROLL_RESTORATION_STORAGE_KEY = "react-router-scroll-positions";
var savedScrollPositions = {};
function getScrollRestorationKey(location, matches, basename, getKey) {
	let key = null;
	if (getKey) if (basename !== "/") key = getKey({
		...location,
		pathname: stripBasename(location.pathname, basename) || location.pathname
	}, matches);
	else key = getKey(location, matches);
	if (key == null) key = location.key;
	return key;
}
function useScrollRestoration({ getKey, storageKey } = {}) {
	let { router } = useDataRouterContext3("useScrollRestoration");
	let { restoreScrollPosition, preventScrollReset } = useDataRouterState2("useScrollRestoration");
	let { basename } = React$1.useContext(NavigationContext);
	let location = useLocation$2();
	let matches = useMatches$2();
	let navigation = useNavigation$1();
	React$1.useEffect(() => {
		window.history.scrollRestoration = "manual";
		return () => {
			window.history.scrollRestoration = "auto";
		};
	}, []);
	usePageHide(React$1.useCallback(() => {
		if (navigation.state === "idle") {
			let key = getScrollRestorationKey(location, matches, basename, getKey);
			savedScrollPositions[key] = window.scrollY;
		}
		try {
			sessionStorage.setItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY, JSON.stringify(savedScrollPositions));
		} catch (error) {
			warning(false, `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${error}).`);
		}
		window.history.scrollRestoration = "auto";
	}, [
		navigation.state,
		getKey,
		basename,
		location,
		matches,
		storageKey
	]));
	if (typeof document !== "undefined") {
		React$1.useLayoutEffect(() => {
			try {
				let sessionPositions = sessionStorage.getItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY);
				if (sessionPositions) savedScrollPositions = JSON.parse(sessionPositions);
			} catch (e) {}
		}, [storageKey]);
		React$1.useLayoutEffect(() => {
			let disableScrollRestoration = router?.enableScrollRestoration(savedScrollPositions, () => window.scrollY, getKey ? (location2, matches2) => getScrollRestorationKey(location2, matches2, basename, getKey) : void 0);
			return () => disableScrollRestoration && disableScrollRestoration();
		}, [
			router,
			basename,
			getKey
		]);
		React$1.useLayoutEffect(() => {
			if (restoreScrollPosition === false) return;
			if (typeof restoreScrollPosition === "number") {
				window.scrollTo(0, restoreScrollPosition);
				return;
			}
			try {
				if (location.hash) {
					let el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
					if (el) {
						el.scrollIntoView();
						return;
					}
				}
			} catch {
				warning(false, `"${location.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`);
			}
			if (preventScrollReset === true) return;
			window.scrollTo(0, 0);
		}, [
			location,
			restoreScrollPosition,
			preventScrollReset
		]);
	}
}
function useBeforeUnload(callback, options) {
	let { capture } = options || {};
	React$1.useEffect(() => {
		let opts = capture != null ? { capture } : void 0;
		window.addEventListener("beforeunload", callback, opts);
		return () => {
			window.removeEventListener("beforeunload", callback, opts);
		};
	}, [callback, capture]);
}
function usePageHide(callback, options) {
	let { capture } = options || {};
	React$1.useEffect(() => {
		let opts = capture != null ? { capture } : void 0;
		window.addEventListener("pagehide", callback, opts);
		return () => {
			window.removeEventListener("pagehide", callback, opts);
		};
	}, [callback, capture]);
}
function useViewTransitionState(to, { relative } = {}) {
	let vtContext = React$1.useContext(ViewTransitionContext);
	invariant(vtContext != null, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
	let { basename } = useDataRouterContext3("useViewTransitionState");
	let path = useResolvedPath(to, { relative });
	if (!vtContext.isTransitioning) return false;
	let currentPath = stripBasename(vtContext.currentLocation.pathname, basename) || vtContext.currentLocation.pathname;
	let nextPath = stripBasename(vtContext.nextLocation.pathname, basename) || vtContext.nextLocation.pathname;
	return matchPath(path.pathname, nextPath) != null || matchPath(path.pathname, currentPath) != null;
}
/**
* React Router-compatible useSearchParams implementation for TanStack Router.
* The setter wraps the useNavigate hook defined above.
*/
var useSearchParams = () => {
	const $ = c(9);
	const { pathname, searchStr } = useLocation();
	const navigate = useNavigate$1$1();
	let t0;
	if ($[0] !== searchStr) {
		t0 = new URLSearchParams(searchStr);
		$[0] = searchStr;
		$[1] = t0;
	} else t0 = $[1];
	const searchParams = t0;
	let t1;
	if ($[2] !== navigate || $[3] !== pathname || $[4] !== searchParams) {
		t1 = (nextInit, navigateOpts) => {
			navigate({
				pathname,
				search: createSearchParams(typeof nextInit === "function" ? nextInit(searchParams) : nextInit).toString()
			}, navigateOpts);
		};
		$[2] = navigate;
		$[3] = pathname;
		$[4] = searchParams;
		$[5] = t1;
	} else t1 = $[5];
	const setSearchParams = t1;
	let t2;
	if ($[6] !== searchParams || $[7] !== setSearchParams) {
		t2 = [searchParams, setSearchParams];
		$[6] = searchParams;
		$[7] = setSearchParams;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
};
function createSearchParams(init) {
	if (!init) return new URLSearchParams();
	if (typeof init === "string") return new URLSearchParams(init);
	if (init instanceof URLSearchParams) return new URLSearchParams(init);
	if (Array.isArray(init)) return new URLSearchParams(init);
	const params = new URLSearchParams();
	for (const [key, value] of Object.entries(init)) if (Array.isArray(value)) for (const item of value) params.append(key, item);
	else params.set(key, value);
	return params;
}
function useMatches$1() {
	const $ = c(2);
	const matches = useMatches();
	let t0;
	if ($[0] !== matches) {
		t0 = matches.map(_temp$2);
		$[0] = matches;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function _temp$2(match) {
	let id = match.routeId;
	if (typeof match.context === "object" && "dataRouterId" in match.context) id = match.context.dataRouterId;
	return {
		id,
		pathname: match.pathname,
		params: match.params,
		handle: void 0,
		loaderData: match.loaderData,
		data: match.loaderData
	};
}
/**
* Uses TanStack Router's useParams but maps _splat to * for react-router compatibility.
*/
function useParams$1() {
	const $ = c(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { strict: false };
		$[0] = t0;
	} else t0 = $[0];
	const params = useParams(t0);
	if ("_splat" in params) {
		let t1;
		if ($[1] !== params) {
			t1 = {
				...params,
				"*": params._splat
			};
			$[1] = params;
			$[2] = t1;
		} else t1 = $[2];
		return t1;
	}
	return params;
}
/**
* Strip internal TanStack Router state keys and return the remaining user state,
* or `null` if there is no user-defined state — matching React Router's behaviour
* where `location.state` defaults to `null`.
*/
function stripInternalState(state) {
	if (state == null || typeof state !== "object") return null;
	const { key: _key, __TSR_key: _tsrKey, __TSR_index: _tsrIndex, __hashScrollIntoViewOptions: _tsrHashScrollIntoViewOptions, ...userState } = state;
	return Object.keys(userState).length > 0 ? userState : null;
}
var toReactRouterLocation = (location) => ({
	search: location.searchStr,
	pathname: location.pathname,
	hash: location.hash,
	state: stripInternalState(location.state),
	key: location.state?.__TSR_key ?? "default"
});
/**
* React Router holds off updating `useLocation()` until a navigation fully commits, so it
* always returns the resolved (current) location. TanStack Router is different: `state.location`
* is set to the pending target as soon as a navigation begins, while `state.resolvedLocation`
* only updates once the transition completes.
*
* For same-route navigations (e.g. `/repos?q=foo` → `/repos?q=bar`) the pending location is useful:
* components can immediately derive the new query key and show stale cached data while the fetch runs
* (stale-while-revalidate). Locking to `resolvedLocation` would delay that cache hit until the
* navigation commits, making those navigations feel slower.
*
* Since existing components are designed on the assumption that `useLocation()` returns the resolved location,
* we split on pathname: if the pathname hasn't changed we're navigating within the same route
* and use the pending location for SWR; if the pathname changed we're leaving the route entirely
* and use `resolvedLocation` to prevent the still-mounted component from picking up the
* in-flight URL and flashing unrelated cached data.
*/
var useLocation$1 = () => {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			select: _temp$1,
			structuralSharing: true
		};
		$[0] = t0;
	} else t0 = $[0];
	return useRouterState(t0);
};
function _temp$1(s) {
	const resolved = s.resolvedLocation ?? s.location;
	return toReactRouterLocation(s.location.pathname === resolved.pathname ? s.location : resolved);
}
var useNavigation = () => {
	const $ = c(5);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { select: _temp };
		$[0] = t0;
	} else t0 = $[0];
	const { routerIsLoading, location } = useRouterState(t0);
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { strict: false };
		$[1] = t1;
	} else t1 = $[1];
	const routeMatchIsFetching = useMatch(t1).isFetching;
	const isLoading = routerIsLoading || routeMatchIsFetching;
	const t2 = isLoading ? "loading" : "idle";
	const t3 = isLoading ? location : void 0;
	let t4;
	if ($[2] !== t2 || $[3] !== t3) {
		t4 = {
			state: t2,
			location: t3
		};
		$[2] = t2;
		$[3] = t3;
		$[4] = t4;
	} else t4 = $[4];
	return t4;
};
function _temp(s) {
	return {
		routerIsLoading: s.isLoading,
		location: toReactRouterLocation(s.location)
	};
}
/**
* Adapt TanStack Router's useBlocker to the react-router interface.
*/
function useBlocker$1(shouldBlock) {
	const $ = c(12);
	let t0;
	if ($[0] !== shouldBlock) {
		t0 = typeof shouldBlock === "boolean" ? () => shouldBlock : (t1) => {
			const { current, next } = t1;
			return shouldBlock({
				currentLocation: { pathname: current.pathname },
				nextLocation: { pathname: next.pathname }
			});
		};
		$[0] = shouldBlock;
		$[1] = t0;
	} else t0 = $[1];
	const blockerFn = t0;
	let t1;
	if ($[2] !== blockerFn) {
		t1 = {
			shouldBlockFn: blockerFn,
			withResolver: true,
			enableBeforeUnload: false
		};
		$[2] = blockerFn;
		$[3] = t1;
	} else t1 = $[3];
	const { status, next: next_0, proceed, reset } = useBlocker(t1);
	if (status === "blocked") {
		let t2;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = {};
			$[4] = t2;
		} else t2 = $[4];
		let t3;
		if ($[5] !== next_0.pathname) {
			t3 = {
				search: "",
				pathname: next_0.pathname,
				hash: "",
				state: t2,
				key: "default"
			};
			$[5] = next_0.pathname;
			$[6] = t3;
		} else t3 = $[6];
		const location = t3;
		let t4;
		if ($[7] !== location || $[8] !== proceed || $[9] !== reset) {
			t4 = {
				state: "blocked",
				proceed,
				reset,
				location
			};
			$[7] = location;
			$[8] = proceed;
			$[9] = reset;
			$[10] = t4;
		} else t4 = $[10];
		return t4;
	}
	let t2;
	if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = { state: "unblocked" };
		$[11] = t2;
	} else t2 = $[11];
	return t2;
}
/**
* This bridges a legacy blocker implementation for Code View's `BlobEditor`
* Once Code View is fully migrated to DataRouter, this should be removed in favor of useBlocker.
*
* @deprecated - Prefer useBlocker
*/
function useBlockerLegacy(blocker, message, t0) {
	const $ = c(14);
	const when = t0 === void 0 ? true : t0;
	const handledBlockedStateRef = useRef(false);
	let t1;
	if ($[0] !== when) {
		t1 = () => when;
		$[0] = when;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== message || $[3] !== when) {
		t2 = () => when && Boolean(message);
		$[2] = message;
		$[3] = when;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== t1 || $[6] !== t2) {
		t3 = {
			shouldBlockFn: t1,
			enableBeforeUnload: t2,
			withResolver: true
		};
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
	} else t3 = $[7];
	const { status, proceed, reset } = useBlocker(t3);
	let t4;
	let t5;
	if ($[8] !== blocker || $[9] !== proceed || $[10] !== reset || $[11] !== status) {
		t4 = () => {
			if (status !== "blocked") {
				handledBlockedStateRef.current = false;
				return;
			}
			if (handledBlockedStateRef.current) return;
			handledBlockedStateRef.current = true;
			let didRetry = false;
			blocker({ retry() {
				didRetry = true;
				proceed?.();
			} });
			if (!didRetry) reset?.();
		};
		t5 = [
			blocker,
			proceed,
			reset,
			status
		];
		$[8] = blocker;
		$[9] = proceed;
		$[10] = reset;
		$[11] = status;
		$[12] = t4;
		$[13] = t5;
	} else {
		t4 = $[12];
		t5 = $[13];
	}
	useEffect(t4, t5);
}
/**
* Returns a click handler that navigates using TanStack Router.
*/
function useLinkClickHandler(to, options) {
	const $ = c(8);
	const navigate = useNavigate$1$1();
	let t0;
	if ($[0] !== options) {
		t0 = options || {};
		$[0] = options;
		$[1] = t0;
	} else t0 = $[1];
	const { replace, state, target } = t0;
	let t1;
	if ($[2] !== navigate || $[3] !== replace || $[4] !== state || $[5] !== target || $[6] !== to) {
		t1 = (event) => {
			if (shouldProcessLinkClick(event, target)) {
				event.preventDefault();
				navigate(to, {
					replace,
					state
				});
			}
		};
		$[2] = navigate;
		$[3] = replace;
		$[4] = state;
		$[5] = target;
		$[6] = to;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
}
/**
* A copy of react-router's internal shouldProcessLinkClick function to ensure consistent behavior with their useLinkClickHandler.
* https://github.com/remix-run/react-router/blob/00cb4d7b310663b2e84152700c05d3b503005e83/packages/react-router/lib/dom/dom.ts#L34C1-L43C2
*/
function shouldProcessLinkClick(mouseEvent, target) {
	return mouseEvent.button === 0 && (!target || target === "_self") && !(mouseEvent.metaKey || mouseEvent.altKey || mouseEvent.ctrlKey || mouseEvent.shiftKey);
}
function Link$1({ ref, to, href: _href, reloadDocument, preventAutofocus, children, ...props }) {
	const router = useRouter();
	const resolvedTo = toTanstackPathString(to, router.state.location.pathname);
	const shouldReload = Boolean(reloadDocument) || !!to && isExternalToApp(router, resolvedTo);
	const resolvedState = preventAutofocus ? {
		[PREVENT_AUTOFOCUS_KEY]: true,
		...props.state
	} : props.state;
	if (shouldReload) {
		const { state: _state, replace: _replace, ...anchorProps } = props;
		return /* @__PURE__ */ jsx("a", {
			...anchorProps,
			href: resolvedTo,
			ref,
			children
		});
	}
	return /* @__PURE__ */ jsx(Link, {
		to: resolvedTo,
		ref,
		...props,
		state: resolvedState,
		children
	});
}
Link$1.displayName = "Link";
function NavLink({ ref, to, end, href: _href, className, style, children, reloadDocument, preventAutofocus, ...props }) {
	const router = useRouter();
	const resolvedTo = toTanstackPathString(to, router.state.location.pathname);
	const isExternal = !!to && isExternalToApp(router, resolvedTo);
	const shouldReload = Boolean(reloadDocument) || isExternal;
	const resolvedState = preventAutofocus ? {
		[PREVENT_AUTOFOCUS_KEY]: true,
		...props.state
	} : props.state;
	const linkProps = useLinkProps({
		...props,
		state: resolvedState,
		to: resolvedTo,
		activeOptions: { exact: end }
	});
	const state = {
		isActive: ("data-status" in linkProps ? linkProps["data-status"] : void 0) === "active" && !isExternal,
		isPending: false,
		isTransitioning: false
	};
	const resolvedClassName = typeof className === "function" ? className(state) : className;
	const resolvedStyle = typeof style === "function" ? style(state) : style;
	const resolvedChildren = typeof children === "function" ? children(state) : children;
	const { state: _state, replace: _replace, ...anchorProps } = props;
	return /* @__PURE__ */ jsx("a", {
		...anchorProps,
		...shouldReload ? { href: resolvedTo } : linkProps,
		className: resolvedClassName,
		style: resolvedStyle,
		ref,
		children: resolvedChildren
	});
}
NavLink.displayName = "NavLink";
function toTanstackPathString(to, defaultPathname) {
	if (typeof to === "string") return to;
	const { pathname = defaultPathname, search = "", hash = "" } = to;
	return `${pathname}${search ? search.startsWith("?") ? search : `?${search}` : ""}${hash ? hash.startsWith("#") ? hash : `#${hash}` : ""}`;
}
var isHashNavigation = (currentUrl, targetUrl) => {
	const current = new URL(currentUrl, window.location.origin);
	const target = new URL(targetUrl, window.location.origin);
	return target.href.includes("#") && current.host === target.host && current.pathname === target.pathname && current.search === target.search;
};
var SoftNavEvent = class extends Event {
	mechanism;
	constructor(mechanism, type) {
		super(type);
		this.mechanism = mechanism;
	}
};
var SoftNavStartEvent = class extends SoftNavEvent {
	constructor(mechanism) {
		super(mechanism, SOFT_NAV_STATE.START);
	}
};
var SoftNavSuccessEvent = class extends SoftNavEvent {
	visitCount;
	constructor(mechanism, visitCount) {
		super(mechanism, SOFT_NAV_STATE.SUCCESS);
		this.visitCount = visitCount;
	}
};
var SoftNavErrorEvent = class extends SoftNavEvent {
	error;
	constructor(mechanism, error) {
		super(mechanism, SOFT_NAV_STATE.ERROR);
		this.error = error;
	}
};
var SoftNavEndEvent = class extends SoftNavEvent {
	constructor(mechanism) {
		super(mechanism, SOFT_NAV_STATE.END);
	}
};
var SOFT_NAV_DURATION_MARK = "stats:soft-nav-duration";
var MECHANISM_MAPPING = {
	turbo: "TURBO",
	react: "REACT",
	"turbo.frame": "FRAME",
	"turbo.error": "TURBO.ERROR",
	ui: "UI",
	hard: "HARD"
};
function markStart() {
	window.performance.clearResourceTimings();
	window.performance.mark(SOFT_NAV_DURATION_MARK);
}
function getDurationSinceLastSoftNav() {
	if (performance.getEntriesByName("stats:soft-nav-duration").length === 0) return null;
	performance.measure(SOFT_NAV_DURATION_MARK, {
		start: SOFT_NAV_DURATION_MARK,
		detail: { devtools: {
			dataType: "track-entry",
			track: "Navigation",
			trackGroup: "Performance Timeline",
			color: "secondary",
			tooltipText: "Soft nav duration"
		} }
	});
	const measure = performance.getEntriesByName(SOFT_NAV_DURATION_MARK).pop();
	return measure ? measure.duration : null;
}
function sendFailureStats(turboFailureReason) {
	sendStats({
		turboFailureReason,
		turboStartUrl: getSoftNavReferrer(),
		turboEndUrl: window.location.href
	});
}
function sendRenderStats() {
	const duration = getDurationSinceLastSoftNav();
	if (!duration) return;
	const mechanism = MECHANISM_MAPPING[getSoftNavMechanism()];
	const roundedDuration = Math.round(duration);
	if (mechanism === MECHANISM_MAPPING.react) document.dispatchEvent(new CustomEvent("staffbar-update", { detail: { duration: roundedDuration } }));
	sendStats({
		requestUrl: window.location.href,
		softNavigationTiming: {
			mechanism,
			destination: getCurrentReactAppName() || "rails",
			duration: roundedDuration,
			initiator: getSoftNavReactAppName() || "rails"
		}
	});
}
var visitCount = 0;
function startSoftNav(mechanism) {
	if (inSoftNav()) return;
	startProgressBar();
	document.dispatchEvent(new SoftNavStartEvent(mechanism));
	setSoftNavMechanism(mechanism);
	setSoftNavReactAppName();
	setSoftNavReferrer();
	markStart();
}
function succeedSoftNav(options = {}) {
	if (!canTriggerEvent(options)) return;
	visitCount += 1;
	document.dispatchEvent(new SoftNavSuccessEvent(getSoftNavMechanism(), visitCount));
	endSoftNav(options);
}
function failSoftNav(options = {}) {
	if (!canTriggerEvent(options)) return;
	visitCount = 0;
	const reason = getSoftNavFailReason() || "reload";
	document.dispatchEvent(new SoftNavErrorEvent(getSoftNavMechanism(), reason));
	endProgressBar();
	sendFailureStats(reason);
	clearSoftNav();
}
function endSoftNav(options = {}) {
	if (!canTriggerEvent(options)) return;
	const mechanism = getSoftNavMechanism();
	endProgressBar();
	document.dispatchEvent(new SoftNavEndEvent(mechanism));
	unsetSoftNav();
	setLatestMechanism(mechanism);
}
function renderedSoftNav(options = {}) {
	if (!canTriggerEvent(options)) return;
	sendRenderStats();
	document.dispatchEvent(new Event(SOFT_NAV_STATE.RENDER));
}
function startProgressBar() {
	document.dispatchEvent(new Event(SOFT_NAV_STATE.PROGRESS_BAR.START));
}
function endProgressBar() {
	document.dispatchEvent(new Event(SOFT_NAV_STATE.PROGRESS_BAR.END));
}
function canTriggerEvent({ skipIfGoingToReactApp, allowedMechanisms = [] } = {}) {
	return inSoftNav() && (allowedMechanisms.length === 0 || allowedMechanisms.includes(getSoftNavMechanism())) && (!skipIfGoingToReactApp || !reactAppPresent());
}
var RoutesContext = createContext({ routes: [] });
/**
* A wrapper around `react-router`'s useNavigate that adds support for:
* - Soft navigation with Turbo for external links (when `reloadDocument` is not set)
* - Preventing autofocus on navigation when `preventAutofocus` is set
* - Starting a soft navigation with `@github-ui/soft-nav` for non-hash internal links to allow
*   for features like the progress bar and transition animations
*/
RoutesContext.displayName = "RoutesContext";
/**
* React Router Link that supports preventAutofocus and resolves
* reloadDocument based on whether the target route is within the app's RoutesContext.
*/
var ExtendedLink = ({ to, reloadDocument, preventAutofocus, ...props }) => {
	const { routes } = use(RoutesContext);
	const pathname = resolvePath(to, ssrSafeLocation.pathname).pathname;
	reloadDocument = reloadDocument ?? !matchRoutes(routes, pathname);
	return /* @__PURE__ */ jsx(Link$2, {
		to,
		...props,
		state: preventAutofocus ? {
			[PREVENT_AUTOFOCUS_KEY]: true,
			...props.state
		} : props.state,
		reloadDocument
	});
};
/**
* React Router NavLink that supports preventAutofocus and resolves
* reloadDocument based on whether the target route is within the app's RoutesContext.
*/
ExtendedLink.displayName = "ExtendedLink";
function ExtendedNavLink({ to, reloadDocument, preventAutofocus, ...props }) {
	const { routes } = use(RoutesContext);
	const pathname = resolvePath(to, ssrSafeLocation.pathname).pathname;
	reloadDocument = reloadDocument ?? !matchRoutes(routes, pathname);
	return /* @__PURE__ */ jsx(NavLink$1, {
		to,
		...props,
		state: preventAutofocus ? {
			[PREVENT_AUTOFOCUS_KEY]: true,
			...props.state
		} : props.state,
		reloadDocument
	});
}
ExtendedNavLink.displayName = "ExtendedNavLink";
/**
* We export this here and not from `./tanstack-router/index` because the shim relies
* on React Router's matchPath utility. ./tanstack-router/* exports should be TanStack-only.
* Reimplementating the internals of matchPath is non-trivial and not currently worth the maintenance burden.
*/
function useMatch$1(pattern) {
	const $ = c(3);
	const location = useLocation$1();
	let t0;
	if ($[0] !== location.pathname || $[1] !== pattern) {
		t0 = matchPath(pattern, location.pathname);
		$[0] = location.pathname;
		$[1] = pattern;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
export { useSearchParams as S, useMatch$1 as _, failSoftNav as a, useParams$1 as b, isRouteErrorResponse as c, succeedSoftNav as d, useBeforeUnload as f, useLocation$1 as g, useLinkClickHandler as h, createPath as i, renderedSoftNav as l, useBlockerLegacy as m, Outlet$1 as n, generatePath as o, useBlocker$1 as p, RoutesContext as r, isHashNavigation as s, Link$1 as t, startSoftNav as u, useMatches$1 as v, useRouteError as x, useNavigation as y };
